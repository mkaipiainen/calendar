import { AfterViewInit, ChangeDetectorRef, EventEmitter } from '@angular/core';
import { IOuiIconOptions } from 'orbital-ui/icon';
import * as i0 from "@angular/core";
/**
 * Creates a clickable icon, with a little hover effect to signal clickability.
 *
 *  example use:
 *
 *  <oui-icon-button color="primary" icon="assets/icons/my-example-icon.svg" [options]="{fillColor: 'color-white'}" (onClick)="onIconClick($event)"></oui-icon-button>
 */
export declare class OuiIconButtonComponent implements AfterViewInit {
    private cdr;
    /**
     *   The path to the icon
     */
    icon: string;
    /**
     *   if set to true, icon is replaced with a loading spinner
     */
    isLoading: boolean;
    /**
     *   The options of the icon
     */
    set options(newOptions: IOuiIconOptions);
    get options(): IOuiIconOptions;
    /**
     *   Emitted when icon is clicked. Usually you want to tie a function to this.
     */
    onClick: EventEmitter<any>;
    private defaultOptions;
    combinedOptions: IOuiIconOptions;
    spinnerColor: string;
    spinnerSize: string;
    constructor(cdr: ChangeDetectorRef);
    ngAfterViewInit(): void;
    emitClick(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiIconButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiIconButtonComponent, "oui-icon-button", never, { "icon": { "alias": "icon"; "required": false; }; "isLoading": { "alias": "isLoading"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, { "onClick": "onClick"; }, never, never, true, never>;
}
//# sourceMappingURL=icon-button.component.d.ts.map