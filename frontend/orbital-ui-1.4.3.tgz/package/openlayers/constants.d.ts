import { OuiOpenLayersCommonOptions } from './types';
export declare const OPENLAYERS_EDITABLE_GEOJSON_DRAW_MODES: {
    POLYGON: string;
    MODIFY: string;
};
export declare const DEFAULT_COMMON_OPTIONS: OuiOpenLayersCommonOptions;
//# sourceMappingURL=constants.d.ts.map