import { BaseDeckLayer } from '../base-deck-layer.component';
import { BindCommonDeckOptions } from '../deck/bind-default-deck-options';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { OuiMeasureDistanceMode } from './measure-distance-mode';
import { EditableGeoJsonLayer } from '@nebula.gl/layers';
import * as i0 from "@angular/core";
export class DeckMeasureLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        const modeConfig = {
            ...{
                centerTooltipsOnLine: true,
                formatTooltip: (distance) => {
                    if (distance >= 1) {
                        return `${distance.toFixed(2)} km`;
                    }
                    else {
                        return `${(distance * 1000).toFixed(2)} m`;
                    }
                },
            },
            ...(this.options.modeConfig ?? {}),
        };
        // @ts-ignore
        return new EditableGeoJsonLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            selectedFeatureIndexes: this.options.selectedFeatureIndexes ?? [],
            mode: OuiMeasureDistanceMode,
            // Styles
            modeConfig: modeConfig,
            filled: this.options.filled ?? true,
            editHandlePointStrokeWidth: this.options.editHandlePointStrokeWidth ?? 2,
            getEditHandlePointColor: this.options.getEditHandlePointColor ?? [
                255, 0, 0, 255,
            ],
            getEditHandlePointOutlineColor: this.options
                .getEditHandlePointOutlineColor ?? [255, 255, 255, 255],
            pointRadiusMinPixels: this.options.pointRadiusMinPixels ?? 2,
            getEditHandlePointRadius: this.options.getEditHandlePointRadius ?? 8,
            pointRadiusScale: this.options.pointRadiusScale ?? 1,
            getFillColor: this.options.getFillColor
                ? this.options.getFillColor
                : [200, 0, 80, 180],
            getTentativeFillColor: this.options.getTentativeFillColor
                ? this.options.getTentativeFillColor
                : [200, 0, 80, 180],
            autoHighlight: this.options.autoHighlight ?? false,
            onEdit: this.options.onEdit ? this.options.onEdit : () => { },
            pickingRadius: this.options.pickingRadius ?? 10,
            _subLayerProps: this.options._subLayerProps ?? {},
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckMeasureLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckMeasureLayer, isStandalone: true, selector: "oui-deck-measure-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckMeasureLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-measure-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay1tZWFzdXJlLWxheWVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9tYXBib3gvbWVhc3VyaW5nLWxheWVyL2RlY2stbWVhc3VyZS1sYXllci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFJQSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDN0QsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sbUNBQW1DLENBQUM7QUFDMUUsT0FBTyxFQUFFLHVCQUF1QixFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDMUUsT0FBTyxFQUFFLHNCQUFzQixFQUFFLE1BQU0seUJBQXlCLENBQUM7QUFDakUsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sbUJBQW1CLENBQUM7O0FBU3pELE1BQU0sT0FBTyxnQkFBaUIsU0FBUSxhQUFrQjtJQUNuQixPQUFPLENBQTJCO0lBQ3JFO1FBQ0UsS0FBSyxFQUFFLENBQUM7SUFDVixDQUFDO0lBRU0sUUFBUTtRQUNiLE1BQU0sVUFBVSxHQUFHO1lBQ2pCLEdBQUc7Z0JBQ0Qsb0JBQW9CLEVBQUUsSUFBSTtnQkFDMUIsYUFBYSxFQUFFLENBQUMsUUFBZ0IsRUFBRSxFQUFFO29CQUNsQyxJQUFJLFFBQVEsSUFBSSxDQUFDLEVBQUUsQ0FBQzt3QkFDbEIsT0FBTyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztvQkFDckMsQ0FBQzt5QkFBTSxDQUFDO3dCQUNOLE9BQU8sR0FBRyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztvQkFDN0MsQ0FBQztnQkFDSCxDQUFDO2FBQ0Y7WUFDRCxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLElBQUksRUFBRSxDQUFDO1NBQ0osQ0FBQztRQUNqQyxhQUFhO1FBQ2IsT0FBTyxJQUFJLG9CQUFvQixDQUFDO1lBQzlCLEdBQUcscUJBQXFCLENBQUMsSUFBSSxDQUFDO1lBQzlCLElBQUksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQVc7WUFDOUIsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsSUFBSSxFQUFFO1lBQ2pFLElBQUksRUFBRSxzQkFBc0I7WUFDNUIsU0FBUztZQUNULFVBQVUsRUFBRSxVQUFVO1lBQ3RCLE1BQU0sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sSUFBSSxJQUFJO1lBQ25DLDBCQUEwQixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsMEJBQTBCLElBQUksQ0FBQztZQUN4RSx1QkFBdUIsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLHVCQUF1QixJQUFJO2dCQUMvRCxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHO2FBQ2Y7WUFDRCw4QkFBOEIsRUFBRSxJQUFJLENBQUMsT0FBTztpQkFDekMsOEJBQThCLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7WUFDekQsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsSUFBSSxDQUFDO1lBQzVELHdCQUF3QixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsd0JBQXdCLElBQUksQ0FBQztZQUNwRSxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixJQUFJLENBQUM7WUFDcEQsWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWTtnQkFDckMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWTtnQkFDM0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsR0FBRyxDQUFDO1lBQ3JCLHFCQUFxQixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMscUJBQXFCO2dCQUN2RCxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxxQkFBcUI7Z0JBQ3BDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQztZQUNyQixhQUFhLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLElBQUksS0FBSztZQUNsRCxNQUFNLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRSxDQUFDO1lBQzVELGFBQWEsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsSUFBSSxFQUFFO1lBQy9DLGNBQWMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsSUFBSSxFQUFFO1NBQ2xELENBQUMsQ0FBQztJQUNMLENBQUM7dUdBakRVLGdCQUFnQjsyRkFBaEIsZ0JBQWdCLHlJQUxqQixFQUFFOzsyRkFLRCxnQkFBZ0I7a0JBUDVCLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLHdCQUF3QjtvQkFDbEMsUUFBUSxFQUFFLEVBQUU7b0JBQ1osVUFBVSxFQUFFLElBQUk7b0JBQ2hCLE9BQU8sRUFBRSxFQUFFO29CQUNYLGVBQWUsRUFBRSx1QkFBdUIsQ0FBQyxNQUFNO2lCQUNoRDt3REFFb0MsT0FBTztzQkFBekMsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBJRGVja01lYXN1cmVMYXllck1vZGVDb25maWcsXG4gIElEZWNrTWVhc3VyZUxheWVyT3B0aW9ucyxcbn0gZnJvbSAnLi4vdHlwaW5ncyc7XG5pbXBvcnQgeyBCYXNlRGVja0xheWVyIH0gZnJvbSAnLi4vYmFzZS1kZWNrLWxheWVyLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBCaW5kQ29tbW9uRGVja09wdGlvbnMgfSBmcm9tICcuLi9kZWNrL2JpbmQtZGVmYXVsdC1kZWNrLW9wdGlvbnMnO1xuaW1wb3J0IHsgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksIENvbXBvbmVudCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE91aU1lYXN1cmVEaXN0YW5jZU1vZGUgfSBmcm9tICcuL21lYXN1cmUtZGlzdGFuY2UtbW9kZSc7XG5pbXBvcnQgeyBFZGl0YWJsZUdlb0pzb25MYXllciB9IGZyb20gJ0BuZWJ1bGEuZ2wvbGF5ZXJzJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLWRlY2stbWVhc3VyZS1sYXllcicsXG4gIHRlbXBsYXRlOiAnJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW10sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBEZWNrTWVhc3VyZUxheWVyIGV4dGVuZHMgQmFzZURlY2tMYXllcjxhbnk+IHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSkgZGVjbGFyZSBvcHRpb25zOiBJRGVja01lYXN1cmVMYXllck9wdGlvbnM7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKCk7XG4gIH1cblxuICBwdWJsaWMgZ2V0TGF5ZXIoKTogRWRpdGFibGVHZW9Kc29uTGF5ZXIge1xuICAgIGNvbnN0IG1vZGVDb25maWcgPSB7XG4gICAgICAuLi57XG4gICAgICAgIGNlbnRlclRvb2x0aXBzT25MaW5lOiB0cnVlLFxuICAgICAgICBmb3JtYXRUb29sdGlwOiAoZGlzdGFuY2U6IG51bWJlcikgPT4ge1xuICAgICAgICAgIGlmIChkaXN0YW5jZSA+PSAxKSB7XG4gICAgICAgICAgICByZXR1cm4gYCR7ZGlzdGFuY2UudG9GaXhlZCgyKX0ga21gO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gYCR7KGRpc3RhbmNlICogMTAwMCkudG9GaXhlZCgyKX0gbWA7XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIC4uLih0aGlzLm9wdGlvbnMubW9kZUNvbmZpZyA/PyB7fSksXG4gICAgfSBhcyBJRGVja01lYXN1cmVMYXllck1vZGVDb25maWc7XG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHJldHVybiBuZXcgRWRpdGFibGVHZW9Kc29uTGF5ZXIoe1xuICAgICAgLi4uQmluZENvbW1vbkRlY2tPcHRpb25zKHRoaXMpLFxuICAgICAgZGF0YTogdGhpcy5vcHRpb25zLmRhdGEgYXMgYW55LFxuICAgICAgc2VsZWN0ZWRGZWF0dXJlSW5kZXhlczogdGhpcy5vcHRpb25zLnNlbGVjdGVkRmVhdHVyZUluZGV4ZXMgPz8gW10sXG4gICAgICBtb2RlOiBPdWlNZWFzdXJlRGlzdGFuY2VNb2RlLFxuICAgICAgLy8gU3R5bGVzXG4gICAgICBtb2RlQ29uZmlnOiBtb2RlQ29uZmlnLFxuICAgICAgZmlsbGVkOiB0aGlzLm9wdGlvbnMuZmlsbGVkID8/IHRydWUsXG4gICAgICBlZGl0SGFuZGxlUG9pbnRTdHJva2VXaWR0aDogdGhpcy5vcHRpb25zLmVkaXRIYW5kbGVQb2ludFN0cm9rZVdpZHRoID8/IDIsXG4gICAgICBnZXRFZGl0SGFuZGxlUG9pbnRDb2xvcjogdGhpcy5vcHRpb25zLmdldEVkaXRIYW5kbGVQb2ludENvbG9yID8/IFtcbiAgICAgICAgMjU1LCAwLCAwLCAyNTUsXG4gICAgICBdLFxuICAgICAgZ2V0RWRpdEhhbmRsZVBvaW50T3V0bGluZUNvbG9yOiB0aGlzLm9wdGlvbnNcbiAgICAgICAgLmdldEVkaXRIYW5kbGVQb2ludE91dGxpbmVDb2xvciA/PyBbMjU1LCAyNTUsIDI1NSwgMjU1XSxcbiAgICAgIHBvaW50UmFkaXVzTWluUGl4ZWxzOiB0aGlzLm9wdGlvbnMucG9pbnRSYWRpdXNNaW5QaXhlbHMgPz8gMixcbiAgICAgIGdldEVkaXRIYW5kbGVQb2ludFJhZGl1czogdGhpcy5vcHRpb25zLmdldEVkaXRIYW5kbGVQb2ludFJhZGl1cyA/PyA4LFxuICAgICAgcG9pbnRSYWRpdXNTY2FsZTogdGhpcy5vcHRpb25zLnBvaW50UmFkaXVzU2NhbGUgPz8gMSxcbiAgICAgIGdldEZpbGxDb2xvcjogdGhpcy5vcHRpb25zLmdldEZpbGxDb2xvclxuICAgICAgICA/IHRoaXMub3B0aW9ucy5nZXRGaWxsQ29sb3JcbiAgICAgICAgOiBbMjAwLCAwLCA4MCwgMTgwXSxcbiAgICAgIGdldFRlbnRhdGl2ZUZpbGxDb2xvcjogdGhpcy5vcHRpb25zLmdldFRlbnRhdGl2ZUZpbGxDb2xvclxuICAgICAgICA/IHRoaXMub3B0aW9ucy5nZXRUZW50YXRpdmVGaWxsQ29sb3JcbiAgICAgICAgOiBbMjAwLCAwLCA4MCwgMTgwXSxcbiAgICAgIGF1dG9IaWdobGlnaHQ6IHRoaXMub3B0aW9ucy5hdXRvSGlnaGxpZ2h0ID8/IGZhbHNlLFxuICAgICAgb25FZGl0OiB0aGlzLm9wdGlvbnMub25FZGl0ID8gdGhpcy5vcHRpb25zLm9uRWRpdCA6ICgpID0+IHt9LFxuICAgICAgcGlja2luZ1JhZGl1czogdGhpcy5vcHRpb25zLnBpY2tpbmdSYWRpdXMgPz8gMTAsXG4gICAgICBfc3ViTGF5ZXJQcm9wczogdGhpcy5vcHRpb25zLl9zdWJMYXllclByb3BzID8/IHt9LFxuICAgIH0pO1xuICB9XG59XG4iXX0=