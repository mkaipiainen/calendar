import { ICommonDeckLayerOptions } from '../typings';
export declare function BindCommonDeckOptions(layer: any): ICommonDeckLayerOptions;
//# sourceMappingURL=bind-default-deck-options.d.ts.map