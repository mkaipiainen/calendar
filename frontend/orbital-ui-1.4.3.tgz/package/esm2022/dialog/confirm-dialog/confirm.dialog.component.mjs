import { Component, Input } from '@angular/core';
import { OuiDialogComponent } from '../dialog.component';
import { OuiButtonComponent } from 'orbital-ui/button';
import * as i0 from "@angular/core";
/**
 * Represents a confirmation dialog component that extends OuiDialogComponent.
 * Displays a dialog box with a message asking the user to confirm or cancel an action.
 *
 */
export class OuiConfirmDialogComponent extends OuiDialogComponent {
    /**
     * The title of the confirmation dialog. Default is 'Are you sure?'.
     */
    title = 'Are you sure?';
    /**
     * The message to display in the confirmation dialog. Default is 'Please either confirm or cancel.'.
     */
    content = 'Please either confirm or cancel.';
    /**
     * The label for the submit button. Default is 'Submit'.
     */
    submitLabel = 'Submit';
    /**
     * The label for the cancel button. Default is 'Cancel'.
     */
    cancelLabel = 'Cancel';
    /**
     * The variant of the submit button
     */
    submitVariant = 'primary';
    /**
     * The variant of the cancel button
     */
    cancelVariant = 'muted';
    constructor() {
        super();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiConfirmDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiConfirmDialogComponent, isStandalone: true, selector: "oui-confirm-dialog", inputs: { title: "title", content: "content", submitLabel: "submitLabel", cancelLabel: "cancelLabel", submitVariant: "submitVariant", cancelVariant: "cancelVariant" }, usesInheritance: true, ngImport: i0, template: "<div class=\"confirm-dialog\">\n  <div class=\"confirm-dialog-inner\">\n    <div class=\"dialog-head\" [innerHTML]=\"title\"></div>\n    <div class=\"dialog-content\" [innerHTML]=\"content\"></div>\n    <div class=\"dialog-actions\">\n      <oui-button\n        class=\"cancel-button\"\n        [options]=\"{\n          variant: cancelVariant\n        }\"\n        (onClick)=\"cancel()\"\n        >{{ cancelLabel }}</oui-button\n      >\n      <oui-button [options]=\"{variant: submitVariant}\" (onClick)=\"submit()\">{{\n        submitLabel\n      }}</oui-button>\n    </div>\n  </div>\n</div>\n", styles: [":host{min-width:35rem;min-height:20rem;width:35rem;height:20rem;display:flex;position:relative;border-radius:5px}:host .confirm-dialog{flex:1;display:flex;background-image:var(--oui-confirm-dialog-background-image);background-repeat:no-repeat;background-position:center;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover}:host .confirm-dialog .confirm-dialog-inner{flex:1;display:flex;flex-direction:column}:host .confirm-dialog .confirm-dialog-inner .dialog-head{border-bottom:1px solid var(--border-color-primary);background-color:var(--oui-confirm-dialog-title-background-color);color:var(--oui-confirm-dialog-title-text-color);padding:1rem;display:flex;align-items:center}:host .confirm-dialog .confirm-dialog-inner .dialog-content{flex:1;background-color:var(--oui-confirm-dialog-content-background-color);color:var(--oui-confirm-dialog-content-text-color);padding:1rem}:host .confirm-dialog .confirm-dialog-inner .dialog-actions{background-color:var(--oui-confirm-dialog-actions-background-color);padding:1rem;display:flex;justify-content:flex-end;align-items:center}:host .confirm-dialog .confirm-dialog-inner .dialog-actions .cancel-button{margin-right:1rem}:host .confirm-dialog .confirm-dialog-inner .dialog-actions oui-button{flex:0 1 auto;width:10rem;height:4rem}\n"], dependencies: [{ kind: "component", type: OuiButtonComponent, selector: "oui-button", inputs: ["options"], outputs: ["onClick"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiConfirmDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-confirm-dialog', standalone: true, imports: [OuiButtonComponent], template: "<div class=\"confirm-dialog\">\n  <div class=\"confirm-dialog-inner\">\n    <div class=\"dialog-head\" [innerHTML]=\"title\"></div>\n    <div class=\"dialog-content\" [innerHTML]=\"content\"></div>\n    <div class=\"dialog-actions\">\n      <oui-button\n        class=\"cancel-button\"\n        [options]=\"{\n          variant: cancelVariant\n        }\"\n        (onClick)=\"cancel()\"\n        >{{ cancelLabel }}</oui-button\n      >\n      <oui-button [options]=\"{variant: submitVariant}\" (onClick)=\"submit()\">{{\n        submitLabel\n      }}</oui-button>\n    </div>\n  </div>\n</div>\n", styles: [":host{min-width:35rem;min-height:20rem;width:35rem;height:20rem;display:flex;position:relative;border-radius:5px}:host .confirm-dialog{flex:1;display:flex;background-image:var(--oui-confirm-dialog-background-image);background-repeat:no-repeat;background-position:center;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover}:host .confirm-dialog .confirm-dialog-inner{flex:1;display:flex;flex-direction:column}:host .confirm-dialog .confirm-dialog-inner .dialog-head{border-bottom:1px solid var(--border-color-primary);background-color:var(--oui-confirm-dialog-title-background-color);color:var(--oui-confirm-dialog-title-text-color);padding:1rem;display:flex;align-items:center}:host .confirm-dialog .confirm-dialog-inner .dialog-content{flex:1;background-color:var(--oui-confirm-dialog-content-background-color);color:var(--oui-confirm-dialog-content-text-color);padding:1rem}:host .confirm-dialog .confirm-dialog-inner .dialog-actions{background-color:var(--oui-confirm-dialog-actions-background-color);padding:1rem;display:flex;justify-content:flex-end;align-items:center}:host .confirm-dialog .confirm-dialog-inner .dialog-actions .cancel-button{margin-right:1rem}:host .confirm-dialog .confirm-dialog-inner .dialog-actions oui-button{flex:0 1 auto;width:10rem;height:4rem}\n"] }]
        }], ctorParameters: () => [], propDecorators: { title: [{
                type: Input
            }], content: [{
                type: Input
            }], submitLabel: [{
                type: Input
            }], cancelLabel: [{
                type: Input
            }], submitVariant: [{
                type: Input
            }], cancelVariant: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlybS5kaWFsb2cuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9kaWFsb2cvY29uZmlybS1kaWFsb2cvY29uZmlybS5kaWFsb2cuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9kaWFsb2cvY29uZmlybS1kaWFsb2cvY29uZmlybS5kaWFsb2cuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDakQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0scUJBQXFCLENBQUM7QUFDekQsT0FBTyxFQUFFLGtCQUFrQixFQUFvQixNQUFNLG1CQUFtQixDQUFDOztBQUd6RTs7OztHQUlHO0FBUUgsTUFBTSxPQUFPLHlCQUEwQixTQUFRLGtCQUFrQjtJQUMvRDs7T0FFRztJQUNhLEtBQUssR0FBRyxlQUFlLENBQUM7SUFFeEM7O09BRUc7SUFDYSxPQUFPLEdBQUcsa0NBQWtDLENBQUM7SUFFN0Q7O09BRUc7SUFDYSxXQUFXLEdBQUcsUUFBUSxDQUFDO0lBRXZDOztPQUVHO0lBQ2EsV0FBVyxHQUFHLFFBQVEsQ0FBQztJQUV2Qzs7T0FFRztJQUNhLGFBQWEsR0FBcUIsU0FBUyxDQUFDO0lBRTVEOztPQUVHO0lBQ2EsYUFBYSxHQUFxQixPQUFPLENBQUM7SUFFMUQ7UUFDRSxLQUFLLEVBQUUsQ0FBQztJQUNWLENBQUM7dUdBakNVLHlCQUF5QjsyRkFBekIseUJBQXlCLDZRQ2pCdEMsc2xCQW1CQSw0MkNESlksa0JBQWtCOzsyRkFFakIseUJBQXlCO2tCQVByQyxTQUFTOytCQUNFLG9CQUFvQixjQUdsQixJQUFJLFdBQ1AsQ0FBQyxrQkFBa0IsQ0FBQzt3REFNYixLQUFLO3NCQUFwQixLQUFLO2dCQUtVLE9BQU87c0JBQXRCLEtBQUs7Z0JBS1UsV0FBVztzQkFBMUIsS0FBSztnQkFLVSxXQUFXO3NCQUExQixLQUFLO2dCQUtVLGFBQWE7c0JBQTVCLEtBQUs7Z0JBS1UsYUFBYTtzQkFBNUIsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE91aURpYWxvZ0NvbXBvbmVudCB9IGZyb20gJy4uL2RpYWxvZy5jb21wb25lbnQnO1xuaW1wb3J0IHsgT3VpQnV0dG9uQ29tcG9uZW50LCBPdWlCdXR0b25WYXJpYW50IH0gZnJvbSAnb3JiaXRhbC11aS9idXR0b24nO1xuaW1wb3J0IHsgT3VpRGlhbG9nU2VydmljZSB9IGZyb20gJy4uL2RpYWxvZy5zZXJ2aWNlJztcblxuLyoqXG4gKiBSZXByZXNlbnRzIGEgY29uZmlybWF0aW9uIGRpYWxvZyBjb21wb25lbnQgdGhhdCBleHRlbmRzIE91aURpYWxvZ0NvbXBvbmVudC5cbiAqIERpc3BsYXlzIGEgZGlhbG9nIGJveCB3aXRoIGEgbWVzc2FnZSBhc2tpbmcgdGhlIHVzZXIgdG8gY29uZmlybSBvciBjYW5jZWwgYW4gYWN0aW9uLlxuICpcbiAqL1xuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLWNvbmZpcm0tZGlhbG9nJyxcbiAgdGVtcGxhdGVVcmw6ICcuL2NvbmZpcm0uZGlhbG9nLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vY29uZmlybS5kaWFsb2cuY29tcG9uZW50LnNjc3MnXSxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW091aUJ1dHRvbkNvbXBvbmVudF0sXG59KVxuZXhwb3J0IGNsYXNzIE91aUNvbmZpcm1EaWFsb2dDb21wb25lbnQgZXh0ZW5kcyBPdWlEaWFsb2dDb21wb25lbnQge1xuICAvKipcbiAgICogVGhlIHRpdGxlIG9mIHRoZSBjb25maXJtYXRpb24gZGlhbG9nLiBEZWZhdWx0IGlzICdBcmUgeW91IHN1cmU/Jy5cbiAgICovXG4gIEBJbnB1dCgpIHB1YmxpYyB0aXRsZSA9ICdBcmUgeW91IHN1cmU/JztcblxuICAvKipcbiAgICogVGhlIG1lc3NhZ2UgdG8gZGlzcGxheSBpbiB0aGUgY29uZmlybWF0aW9uIGRpYWxvZy4gRGVmYXVsdCBpcyAnUGxlYXNlIGVpdGhlciBjb25maXJtIG9yIGNhbmNlbC4nLlxuICAgKi9cbiAgQElucHV0KCkgcHVibGljIGNvbnRlbnQgPSAnUGxlYXNlIGVpdGhlciBjb25maXJtIG9yIGNhbmNlbC4nO1xuXG4gIC8qKlxuICAgKiBUaGUgbGFiZWwgZm9yIHRoZSBzdWJtaXQgYnV0dG9uLiBEZWZhdWx0IGlzICdTdWJtaXQnLlxuICAgKi9cbiAgQElucHV0KCkgcHVibGljIHN1Ym1pdExhYmVsID0gJ1N1Ym1pdCc7XG5cbiAgLyoqXG4gICAqIFRoZSBsYWJlbCBmb3IgdGhlIGNhbmNlbCBidXR0b24uIERlZmF1bHQgaXMgJ0NhbmNlbCcuXG4gICAqL1xuICBASW5wdXQoKSBwdWJsaWMgY2FuY2VsTGFiZWwgPSAnQ2FuY2VsJztcblxuICAvKipcbiAgICogVGhlIHZhcmlhbnQgb2YgdGhlIHN1Ym1pdCBidXR0b25cbiAgICovXG4gIEBJbnB1dCgpIHB1YmxpYyBzdWJtaXRWYXJpYW50OiBPdWlCdXR0b25WYXJpYW50ID0gJ3ByaW1hcnknO1xuXG4gIC8qKlxuICAgKiBUaGUgdmFyaWFudCBvZiB0aGUgY2FuY2VsIGJ1dHRvblxuICAgKi9cbiAgQElucHV0KCkgcHVibGljIGNhbmNlbFZhcmlhbnQ6IE91aUJ1dHRvblZhcmlhbnQgPSAnbXV0ZWQnO1xuXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKCk7XG4gIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJjb25maXJtLWRpYWxvZ1wiPlxuICA8ZGl2IGNsYXNzPVwiY29uZmlybS1kaWFsb2ctaW5uZXJcIj5cbiAgICA8ZGl2IGNsYXNzPVwiZGlhbG9nLWhlYWRcIiBbaW5uZXJIVE1MXT1cInRpdGxlXCI+PC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImRpYWxvZy1jb250ZW50XCIgW2lubmVySFRNTF09XCJjb250ZW50XCI+PC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cImRpYWxvZy1hY3Rpb25zXCI+XG4gICAgICA8b3VpLWJ1dHRvblxuICAgICAgICBjbGFzcz1cImNhbmNlbC1idXR0b25cIlxuICAgICAgICBbb3B0aW9uc109XCJ7XG4gICAgICAgICAgdmFyaWFudDogY2FuY2VsVmFyaWFudFxuICAgICAgICB9XCJcbiAgICAgICAgKG9uQ2xpY2spPVwiY2FuY2VsKClcIlxuICAgICAgICA+e3sgY2FuY2VsTGFiZWwgfX08L291aS1idXR0b25cbiAgICAgID5cbiAgICAgIDxvdWktYnV0dG9uIFtvcHRpb25zXT1cInt2YXJpYW50OiBzdWJtaXRWYXJpYW50fVwiIChvbkNsaWNrKT1cInN1Ym1pdCgpXCI+e3tcbiAgICAgICAgc3VibWl0TGFiZWxcbiAgICAgIH19PC9vdWktYnV0dG9uPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvZGl2PlxuIl19