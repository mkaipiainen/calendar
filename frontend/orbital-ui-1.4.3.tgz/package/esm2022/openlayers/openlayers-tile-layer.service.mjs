import { Injectable } from '@angular/core';
import { take } from 'rxjs';
import { IsS2Image, IsWmsImageBrokerImage, IsWmtsImageBrokerImage, } from 'orbital-ui/core';
import * as i0 from "@angular/core";
import * as i1 from "orbital-ui/core";
/**
 * Service to handle fetching of raster-layers for the map.
 * Caches tiles in memory to prevent unnecessary requests.
 * Handles canceling of requests in case of the layer getting removed from the map, or the map being destroyed, and so on.
 * Also handles attaching the access token to the requests.
 */
export class OpenlayersTileLayerService {
    requestQueueService;
    zone;
    constructor(requestQueueService, zone) {
        this.requestQueueService = requestQueueService;
        this.zone = zone;
    }
    /**
     * Returns a Deck.GL tileLayer-configuration for a map. This should work out of the gate by just giving the function
     * a unique ID (IMPORTANT), and the desired opticalImage-object. The function will then handle the rest.
     * @param id
     * @param data
     * @param options
     * @param layerOptions
     */
    getTileLayer(options) {
        const defaultOptions = {
            isWebMercator: false,
            useCache: true,
        };
        const combinedOptions = {
            ...defaultOptions,
            ...options,
        };
        let url = options.tileLayerOptions?.url ?? '';
        if (options.data) {
            url = options.buildUrl
                ? options.buildUrl(options.data, options)
                : this.defaultUrlBuilder(options.data, options);
            if (typeof options.data === 'string') {
                return {
                    getTileData: (tile, src) => {
                        this.responseToObjectUrl(tile, url, combinedOptions);
                    },
                    url: url,
                    ...(options.tileLayerOptions ?? {}),
                };
            }
            else if (IsWmtsImageBrokerImage(options.data)) {
                const layer = options.data.wmts_data.layer;
                return {
                    getTileData: (tile, src) => {
                        return this.responseToObjectUrl(tile, url, combinedOptions);
                    },
                    url: url,
                    layer,
                    ...(options.tileLayerOptions ?? {}),
                };
            }
            else if (IsWmsImageBrokerImage(options.data)) {
                const layers = [options.data.wms_data.wms_layer_name];
                return {
                    getTileData: (tile, src) => {
                        return this.responseToObjectUrl(tile, src, combinedOptions);
                    },
                    url: url,
                    layers,
                    ...(options.tileLayerOptions ?? {}),
                };
            }
            else if (IsS2Image(options.data)) {
                const layers = [options.data.wms_layer_name];
                return {
                    getTileData: (tile, src) => {
                        return this.responseToObjectUrl(tile, src, combinedOptions);
                    },
                    url: url,
                    layers,
                    ...(options.tileLayerOptions ?? {}),
                };
            }
            else {
                throw new Error('Unknown image type');
            }
        }
        else {
            return {
                getTileData: (tile, src) => {
                    src = (options.origin ?? '') + src;
                    this.responseToObjectUrl(tile, src, combinedOptions);
                },
                url: url,
                ...(options.tileLayerOptions ?? {}),
            };
        }
    }
    defaultUrlBuilder(data, options) {
        let url = '';
        const origin = options.origin;
        if (typeof data === 'string') {
            return `${origin}${data}`;
        }
        else {
            if (IsWmtsImageBrokerImage(data)) {
                url = `${origin}${data.wmts_data.url}`;
            }
            else if (IsWmsImageBrokerImage(data)) {
                url = `${origin}${data?.wms_data.image_url}`;
            }
            else if (IsS2Image(data)) {
                url = `${origin}${data?.image_url}`;
            }
        }
        return url;
    }
    responseToObjectUrl(tile, src, options) {
        options.accessToken$.pipe(take(1)).subscribe(token => {
            let finalUrl = src;
            let headers = {};
            const authHeader = `Bearer ${token}`;
            headers = {
                Authorization: authHeader,
            };
            const promise = fetch(finalUrl, {
                signal: tile.signal,
                headers: headers,
            });
            this.zone.runOutsideAngular(async () => {
                try {
                    this.requestQueueService
                        .addToQueue(promise, tile.signal, options.refreshedAccessToken$)
                        .then(response => response.blob())
                        .then(blob => {
                        try {
                            if (options.blobToUrlTransformer) {
                                options.blobToUrlTransformer(blob).then(url => {
                                    tile.getImage().src = url;
                                    setTimeout(() => {
                                        window.URL.revokeObjectURL(url);
                                    }, 1000);
                                });
                            }
                            else {
                                const blobUrl = window.URL.createObjectURL(blob);
                                tile.getImage().src = blobUrl;
                                setTimeout(() => {
                                    window.URL.revokeObjectURL(blobUrl);
                                }, 1000);
                            }
                        }
                        catch (e) {
                            throw e;
                        }
                    });
                }
                catch (e) {
                    throw e;
                }
            });
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersTileLayerService, deps: [{ token: i1.RequestQueueService }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersTileLayerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersTileLayerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.RequestQueueService }, { type: i0.NgZone }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BlbmxheWVycy10aWxlLWxheWVyLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL29wZW5sYXllcnMvb3BlbmxheWVycy10aWxlLWxheWVyLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBVSxNQUFNLGVBQWUsQ0FBQztBQUNuRCxPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQzVCLE9BQU8sRUFDTCxTQUFTLEVBQ1QscUJBQXFCLEVBQ3JCLHNCQUFzQixHQUV2QixNQUFNLGlCQUFpQixDQUFDOzs7QUFNekI7Ozs7O0dBS0c7QUFJSCxNQUFNLE9BQU8sMEJBQTBCO0lBRTNCO0lBQ0E7SUFGVixZQUNVLG1CQUF3QyxFQUN4QyxJQUFZO1FBRFosd0JBQW1CLEdBQW5CLG1CQUFtQixDQUFxQjtRQUN4QyxTQUFJLEdBQUosSUFBSSxDQUFRO0lBQ25CLENBQUM7SUFFSjs7Ozs7OztPQU9HO0lBQ0ksWUFBWSxDQUNqQixPQUF3QztRQUV4QyxNQUFNLGNBQWMsR0FBRztZQUNyQixhQUFhLEVBQUUsS0FBSztZQUNwQixRQUFRLEVBQUUsSUFBSTtTQUNmLENBQUM7UUFDRixNQUFNLGVBQWUsR0FBb0M7WUFDdkQsR0FBRyxjQUFjO1lBQ2pCLEdBQUcsT0FBTztTQUNYLENBQUM7UUFDRixJQUFJLEdBQUcsR0FBRyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsR0FBRyxJQUFJLEVBQUUsQ0FBQztRQUM5QyxJQUFJLE9BQU8sQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNqQixHQUFHLEdBQUcsT0FBTyxDQUFDLFFBQVE7Z0JBQ3BCLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDO2dCQUN6QyxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFFbEQsSUFBSSxPQUFPLE9BQU8sQ0FBQyxJQUFJLEtBQUssUUFBUSxFQUFFLENBQUM7Z0JBQ3JDLE9BQU87b0JBQ0wsV0FBVyxFQUFFLENBQUMsSUFBUyxFQUFFLEdBQVcsRUFBRSxFQUFFO3dCQUN0QyxJQUFJLENBQUMsbUJBQW1CLENBQUksSUFBSSxFQUFFLEdBQUcsRUFBRSxlQUFlLENBQUMsQ0FBQztvQkFDMUQsQ0FBQztvQkFDRCxHQUFHLEVBQUUsR0FBRztvQkFDUixHQUFHLENBQUMsT0FBTyxDQUFDLGdCQUFnQixJQUFJLEVBQUUsQ0FBQztpQkFDSCxDQUFDO1lBQ3JDLENBQUM7aUJBQU0sSUFBSSxzQkFBc0IsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztnQkFDaEQsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO2dCQUMzQyxPQUFPO29CQUNMLFdBQVcsRUFBRSxDQUFDLElBQVMsRUFBRSxHQUFXLEVBQUUsRUFBRTt3QkFDdEMsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUksSUFBSSxFQUFFLEdBQUcsRUFBRSxlQUFlLENBQUMsQ0FBQztvQkFDakUsQ0FBQztvQkFDRCxHQUFHLEVBQUUsR0FBRztvQkFDUixLQUFLO29CQUNMLEdBQUcsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLElBQUksRUFBRSxDQUFDO2lCQUNILENBQUM7WUFDckMsQ0FBQztpQkFBTSxJQUFJLHFCQUFxQixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO2dCQUMvQyxNQUFNLE1BQU0sR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUN0RCxPQUFPO29CQUNMLFdBQVcsRUFBRSxDQUFDLElBQVMsRUFBRSxHQUFXLEVBQUUsRUFBRTt3QkFDdEMsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUksSUFBSSxFQUFFLEdBQUcsRUFBRSxlQUFlLENBQUMsQ0FBQztvQkFDakUsQ0FBQztvQkFDRCxHQUFHLEVBQUUsR0FBRztvQkFDUixNQUFNO29CQUNOLEdBQUcsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLElBQUksRUFBRSxDQUFDO2lCQUNILENBQUM7WUFDckMsQ0FBQztpQkFBTSxJQUFJLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztnQkFDbkMsTUFBTSxNQUFNLEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUM3QyxPQUFPO29CQUNMLFdBQVcsRUFBRSxDQUFDLElBQVMsRUFBRSxHQUFXLEVBQUUsRUFBRTt3QkFDdEMsT0FBTyxJQUFJLENBQUMsbUJBQW1CLENBQUksSUFBSSxFQUFFLEdBQUcsRUFBRSxlQUFlLENBQUMsQ0FBQztvQkFDakUsQ0FBQztvQkFDRCxHQUFHLEVBQUUsR0FBRztvQkFDUixNQUFNO29CQUNOLEdBQUcsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLElBQUksRUFBRSxDQUFDO2lCQUNILENBQUM7WUFDckMsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLE1BQU0sSUFBSSxLQUFLLENBQUMsb0JBQW9CLENBQUMsQ0FBQztZQUN4QyxDQUFDO1FBQ0gsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPO2dCQUNMLFdBQVcsRUFBRSxDQUFDLElBQVMsRUFBRSxHQUFXLEVBQUUsRUFBRTtvQkFDdEMsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sSUFBSSxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUM7b0JBQ25DLElBQUksQ0FBQyxtQkFBbUIsQ0FBSSxJQUFJLEVBQUUsR0FBRyxFQUFFLGVBQWUsQ0FBQyxDQUFDO2dCQUMxRCxDQUFDO2dCQUNELEdBQUcsRUFBRSxHQUFHO2dCQUNSLEdBQUcsQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLElBQUksRUFBRSxDQUFDO2FBQ0gsQ0FBQztRQUNyQyxDQUFDO0lBQ0gsQ0FBQztJQUVPLGlCQUFpQixDQUN2QixJQUFTLEVBQ1QsT0FBd0M7UUFFeEMsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO1FBQ2IsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztRQUM5QixJQUFJLE9BQU8sSUFBSSxLQUFLLFFBQVEsRUFBRSxDQUFDO1lBQzdCLE9BQU8sR0FBRyxNQUFNLEdBQUcsSUFBSSxFQUFFLENBQUM7UUFDNUIsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLHNCQUFzQixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQ2pDLEdBQUcsR0FBRyxHQUFHLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ3pDLENBQUM7aUJBQU0sSUFBSSxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO2dCQUN2QyxHQUFHLEdBQUcsR0FBRyxNQUFNLEdBQUcsSUFBSSxFQUFFLFFBQVEsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUMvQyxDQUFDO2lCQUFNLElBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7Z0JBQzNCLEdBQUcsR0FBRyxHQUFHLE1BQU0sR0FBRyxJQUFJLEVBQUUsU0FBUyxFQUFFLENBQUM7WUFDdEMsQ0FBQztRQUNILENBQUM7UUFFRCxPQUFPLEdBQUcsQ0FBQztJQUNiLENBQUM7SUFFTyxtQkFBbUIsQ0FDekIsSUFBUyxFQUNULEdBQVcsRUFDWCxPQUF3QztRQUV4QyxPQUFPLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDbkQsSUFBSSxRQUFRLEdBQUcsR0FBRyxDQUFDO1lBQ25CLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUNqQixNQUFNLFVBQVUsR0FBRyxVQUFVLEtBQUssRUFBRSxDQUFDO1lBQ3JDLE9BQU8sR0FBRztnQkFDUixhQUFhLEVBQUUsVUFBVTthQUMxQixDQUFDO1lBQ0YsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBRTtnQkFDOUIsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO2dCQUNuQixPQUFPLEVBQUUsT0FBTzthQUNqQixDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEtBQUssSUFBSSxFQUFFO2dCQUNyQyxJQUFJLENBQUM7b0JBQ0gsSUFBSSxDQUFDLG1CQUFtQjt5QkFDckIsVUFBVSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxxQkFBcUIsQ0FBQzt5QkFDL0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO3lCQUNqQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUU7d0JBQ1gsSUFBSSxDQUFDOzRCQUNILElBQUksT0FBTyxDQUFDLG9CQUFvQixFQUFFLENBQUM7Z0NBQ2pDLE9BQU8sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7b0NBQzVDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDO29DQUMxQixVQUFVLENBQUMsR0FBRyxFQUFFO3dDQUNkLE1BQU0sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDO29DQUNsQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7Z0NBQ1gsQ0FBQyxDQUFDLENBQUM7NEJBQ0wsQ0FBQztpQ0FBTSxDQUFDO2dDQUNOLE1BQU0sT0FBTyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFDO2dDQUNqRCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsR0FBRyxHQUFHLE9BQU8sQ0FBQztnQ0FDOUIsVUFBVSxDQUFDLEdBQUcsRUFBRTtvQ0FDZCxNQUFNLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQ0FDdEMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDOzRCQUNYLENBQUM7d0JBQ0gsQ0FBQzt3QkFBQyxPQUFPLENBQUMsRUFBRSxDQUFDOzRCQUNYLE1BQU0sQ0FBQyxDQUFDO3dCQUNWLENBQUM7b0JBQ0gsQ0FBQyxDQUFDLENBQUM7Z0JBQ1AsQ0FBQztnQkFBQyxPQUFPLENBQUMsRUFBRSxDQUFDO29CQUNYLE1BQU0sQ0FBQyxDQUFDO2dCQUNWLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQzt1R0F2SlUsMEJBQTBCOzJHQUExQiwwQkFBMEIsY0FGekIsTUFBTTs7MkZBRVAsMEJBQTBCO2tCQUh0QyxVQUFVO21CQUFDO29CQUNWLFVBQVUsRUFBRSxNQUFNO2lCQUNuQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUsIE5nWm9uZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgdGFrZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHtcbiAgSXNTMkltYWdlLFxuICBJc1dtc0ltYWdlQnJva2VySW1hZ2UsXG4gIElzV210c0ltYWdlQnJva2VySW1hZ2UsXG4gIFJlcXVlc3RRdWV1ZVNlcnZpY2UsXG59IGZyb20gJ29yYml0YWwtdWkvY29yZSc7XG5pbXBvcnQge1xuICBPdWlPcGVubGF5ZXJzVGlsZUxheWVyT3B0aW9ucyxcbiAgT3VpT3BlbmxheWVyc1RpbGVTZXJ2aWNlT3B0aW9ucyxcbn0gZnJvbSAnLi90eXBlcyc7XG5cbi8qKlxuICogU2VydmljZSB0byBoYW5kbGUgZmV0Y2hpbmcgb2YgcmFzdGVyLWxheWVycyBmb3IgdGhlIG1hcC5cbiAqIENhY2hlcyB0aWxlcyBpbiBtZW1vcnkgdG8gcHJldmVudCB1bm5lY2Vzc2FyeSByZXF1ZXN0cy5cbiAqIEhhbmRsZXMgY2FuY2VsaW5nIG9mIHJlcXVlc3RzIGluIGNhc2Ugb2YgdGhlIGxheWVyIGdldHRpbmcgcmVtb3ZlZCBmcm9tIHRoZSBtYXAsIG9yIHRoZSBtYXAgYmVpbmcgZGVzdHJveWVkLCBhbmQgc28gb24uXG4gKiBBbHNvIGhhbmRsZXMgYXR0YWNoaW5nIHRoZSBhY2Nlc3MgdG9rZW4gdG8gdGhlIHJlcXVlc3RzLlxuICovXG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290Jyxcbn0pXG5leHBvcnQgY2xhc3MgT3BlbmxheWVyc1RpbGVMYXllclNlcnZpY2Uge1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJlcXVlc3RRdWV1ZVNlcnZpY2U6IFJlcXVlc3RRdWV1ZVNlcnZpY2UsXG4gICAgcHJpdmF0ZSB6b25lOiBOZ1pvbmVcbiAgKSB7fVxuXG4gIC8qKlxuICAgKiBSZXR1cm5zIGEgRGVjay5HTCB0aWxlTGF5ZXItY29uZmlndXJhdGlvbiBmb3IgYSBtYXAuIFRoaXMgc2hvdWxkIHdvcmsgb3V0IG9mIHRoZSBnYXRlIGJ5IGp1c3QgZ2l2aW5nIHRoZSBmdW5jdGlvblxuICAgKiBhIHVuaXF1ZSBJRCAoSU1QT1JUQU5UKSwgYW5kIHRoZSBkZXNpcmVkIG9wdGljYWxJbWFnZS1vYmplY3QuIFRoZSBmdW5jdGlvbiB3aWxsIHRoZW4gaGFuZGxlIHRoZSByZXN0LlxuICAgKiBAcGFyYW0gaWRcbiAgICogQHBhcmFtIGRhdGFcbiAgICogQHBhcmFtIG9wdGlvbnNcbiAgICogQHBhcmFtIGxheWVyT3B0aW9uc1xuICAgKi9cbiAgcHVibGljIGdldFRpbGVMYXllcjxUPihcbiAgICBvcHRpb25zOiBPdWlPcGVubGF5ZXJzVGlsZVNlcnZpY2VPcHRpb25zXG4gICk6IE91aU9wZW5sYXllcnNUaWxlTGF5ZXJPcHRpb25zIHtcbiAgICBjb25zdCBkZWZhdWx0T3B0aW9ucyA9IHtcbiAgICAgIGlzV2ViTWVyY2F0b3I6IGZhbHNlLFxuICAgICAgdXNlQ2FjaGU6IHRydWUsXG4gICAgfTtcbiAgICBjb25zdCBjb21iaW5lZE9wdGlvbnM6IE91aU9wZW5sYXllcnNUaWxlU2VydmljZU9wdGlvbnMgPSB7XG4gICAgICAuLi5kZWZhdWx0T3B0aW9ucyxcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgfTtcbiAgICBsZXQgdXJsID0gb3B0aW9ucy50aWxlTGF5ZXJPcHRpb25zPy51cmwgPz8gJyc7XG4gICAgaWYgKG9wdGlvbnMuZGF0YSkge1xuICAgICAgdXJsID0gb3B0aW9ucy5idWlsZFVybFxuICAgICAgICA/IG9wdGlvbnMuYnVpbGRVcmwob3B0aW9ucy5kYXRhLCBvcHRpb25zKVxuICAgICAgICA6IHRoaXMuZGVmYXVsdFVybEJ1aWxkZXIob3B0aW9ucy5kYXRhLCBvcHRpb25zKTtcblxuICAgICAgaWYgKHR5cGVvZiBvcHRpb25zLmRhdGEgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgZ2V0VGlsZURhdGE6ICh0aWxlOiBhbnksIHNyYzogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgICB0aGlzLnJlc3BvbnNlVG9PYmplY3RVcmw8VD4odGlsZSwgdXJsLCBjb21iaW5lZE9wdGlvbnMpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgdXJsOiB1cmwsXG4gICAgICAgICAgLi4uKG9wdGlvbnMudGlsZUxheWVyT3B0aW9ucyA/PyB7fSksXG4gICAgICAgIH0gYXMgT3VpT3BlbmxheWVyc1RpbGVMYXllck9wdGlvbnM7XG4gICAgICB9IGVsc2UgaWYgKElzV210c0ltYWdlQnJva2VySW1hZ2Uob3B0aW9ucy5kYXRhKSkge1xuICAgICAgICBjb25zdCBsYXllciA9IG9wdGlvbnMuZGF0YS53bXRzX2RhdGEubGF5ZXI7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgZ2V0VGlsZURhdGE6ICh0aWxlOiBhbnksIHNyYzogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5yZXNwb25zZVRvT2JqZWN0VXJsPFQ+KHRpbGUsIHVybCwgY29tYmluZWRPcHRpb25zKTtcbiAgICAgICAgICB9LFxuICAgICAgICAgIHVybDogdXJsLFxuICAgICAgICAgIGxheWVyLFxuICAgICAgICAgIC4uLihvcHRpb25zLnRpbGVMYXllck9wdGlvbnMgPz8ge30pLFxuICAgICAgICB9IGFzIE91aU9wZW5sYXllcnNUaWxlTGF5ZXJPcHRpb25zO1xuICAgICAgfSBlbHNlIGlmIChJc1dtc0ltYWdlQnJva2VySW1hZ2Uob3B0aW9ucy5kYXRhKSkge1xuICAgICAgICBjb25zdCBsYXllcnMgPSBbb3B0aW9ucy5kYXRhLndtc19kYXRhLndtc19sYXllcl9uYW1lXTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBnZXRUaWxlRGF0YTogKHRpbGU6IGFueSwgc3JjOiBzdHJpbmcpID0+IHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnJlc3BvbnNlVG9PYmplY3RVcmw8VD4odGlsZSwgc3JjLCBjb21iaW5lZE9wdGlvbnMpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgdXJsOiB1cmwsXG4gICAgICAgICAgbGF5ZXJzLFxuICAgICAgICAgIC4uLihvcHRpb25zLnRpbGVMYXllck9wdGlvbnMgPz8ge30pLFxuICAgICAgICB9IGFzIE91aU9wZW5sYXllcnNUaWxlTGF5ZXJPcHRpb25zO1xuICAgICAgfSBlbHNlIGlmIChJc1MySW1hZ2Uob3B0aW9ucy5kYXRhKSkge1xuICAgICAgICBjb25zdCBsYXllcnMgPSBbb3B0aW9ucy5kYXRhLndtc19sYXllcl9uYW1lXTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBnZXRUaWxlRGF0YTogKHRpbGU6IGFueSwgc3JjOiBzdHJpbmcpID0+IHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLnJlc3BvbnNlVG9PYmplY3RVcmw8VD4odGlsZSwgc3JjLCBjb21iaW5lZE9wdGlvbnMpO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgdXJsOiB1cmwsXG4gICAgICAgICAgbGF5ZXJzLFxuICAgICAgICAgIC4uLihvcHRpb25zLnRpbGVMYXllck9wdGlvbnMgPz8ge30pLFxuICAgICAgICB9IGFzIE91aU9wZW5sYXllcnNUaWxlTGF5ZXJPcHRpb25zO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmtub3duIGltYWdlIHR5cGUnKTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgZ2V0VGlsZURhdGE6ICh0aWxlOiBhbnksIHNyYzogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgc3JjID0gKG9wdGlvbnMub3JpZ2luID8/ICcnKSArIHNyYztcbiAgICAgICAgICB0aGlzLnJlc3BvbnNlVG9PYmplY3RVcmw8VD4odGlsZSwgc3JjLCBjb21iaW5lZE9wdGlvbnMpO1xuICAgICAgICB9LFxuICAgICAgICB1cmw6IHVybCxcbiAgICAgICAgLi4uKG9wdGlvbnMudGlsZUxheWVyT3B0aW9ucyA/PyB7fSksXG4gICAgICB9IGFzIE91aU9wZW5sYXllcnNUaWxlTGF5ZXJPcHRpb25zO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZGVmYXVsdFVybEJ1aWxkZXIoXG4gICAgZGF0YTogYW55LFxuICAgIG9wdGlvbnM6IE91aU9wZW5sYXllcnNUaWxlU2VydmljZU9wdGlvbnNcbiAgKSB7XG4gICAgbGV0IHVybCA9ICcnO1xuICAgIGNvbnN0IG9yaWdpbiA9IG9wdGlvbnMub3JpZ2luO1xuICAgIGlmICh0eXBlb2YgZGF0YSA9PT0gJ3N0cmluZycpIHtcbiAgICAgIHJldHVybiBgJHtvcmlnaW59JHtkYXRhfWA7XG4gICAgfSBlbHNlIHtcbiAgICAgIGlmIChJc1dtdHNJbWFnZUJyb2tlckltYWdlKGRhdGEpKSB7XG4gICAgICAgIHVybCA9IGAke29yaWdpbn0ke2RhdGEud210c19kYXRhLnVybH1gO1xuICAgICAgfSBlbHNlIGlmIChJc1dtc0ltYWdlQnJva2VySW1hZ2UoZGF0YSkpIHtcbiAgICAgICAgdXJsID0gYCR7b3JpZ2lufSR7ZGF0YT8ud21zX2RhdGEuaW1hZ2VfdXJsfWA7XG4gICAgICB9IGVsc2UgaWYgKElzUzJJbWFnZShkYXRhKSkge1xuICAgICAgICB1cmwgPSBgJHtvcmlnaW59JHtkYXRhPy5pbWFnZV91cmx9YDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gdXJsO1xuICB9XG5cbiAgcHJpdmF0ZSByZXNwb25zZVRvT2JqZWN0VXJsPFQ+KFxuICAgIHRpbGU6IGFueSxcbiAgICBzcmM6IHN0cmluZyxcbiAgICBvcHRpb25zOiBPdWlPcGVubGF5ZXJzVGlsZVNlcnZpY2VPcHRpb25zXG4gICkge1xuICAgIG9wdGlvbnMuYWNjZXNzVG9rZW4kLnBpcGUodGFrZSgxKSkuc3Vic2NyaWJlKHRva2VuID0+IHtcbiAgICAgIGxldCBmaW5hbFVybCA9IHNyYztcbiAgICAgIGxldCBoZWFkZXJzID0ge307XG4gICAgICBjb25zdCBhdXRoSGVhZGVyID0gYEJlYXJlciAke3Rva2VufWA7XG4gICAgICBoZWFkZXJzID0ge1xuICAgICAgICBBdXRob3JpemF0aW9uOiBhdXRoSGVhZGVyLFxuICAgICAgfTtcbiAgICAgIGNvbnN0IHByb21pc2UgPSBmZXRjaChmaW5hbFVybCwge1xuICAgICAgICBzaWduYWw6IHRpbGUuc2lnbmFsLFxuICAgICAgICBoZWFkZXJzOiBoZWFkZXJzLFxuICAgICAgfSk7XG4gICAgICB0aGlzLnpvbmUucnVuT3V0c2lkZUFuZ3VsYXIoYXN5bmMgKCkgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHRoaXMucmVxdWVzdFF1ZXVlU2VydmljZVxuICAgICAgICAgICAgLmFkZFRvUXVldWUocHJvbWlzZSwgdGlsZS5zaWduYWwsIG9wdGlvbnMucmVmcmVzaGVkQWNjZXNzVG9rZW4kKVxuICAgICAgICAgICAgLnRoZW4ocmVzcG9uc2UgPT4gcmVzcG9uc2UuYmxvYigpKVxuICAgICAgICAgICAgLnRoZW4oYmxvYiA9PiB7XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgaWYgKG9wdGlvbnMuYmxvYlRvVXJsVHJhbnNmb3JtZXIpIHtcbiAgICAgICAgICAgICAgICAgIG9wdGlvbnMuYmxvYlRvVXJsVHJhbnNmb3JtZXIoYmxvYikudGhlbih1cmwgPT4ge1xuICAgICAgICAgICAgICAgICAgICB0aWxlLmdldEltYWdlKCkuc3JjID0gdXJsO1xuICAgICAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cuVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpO1xuICAgICAgICAgICAgICAgICAgICB9LCAxMDAwKTtcbiAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBibG9iVXJsID0gd2luZG93LlVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYik7XG4gICAgICAgICAgICAgICAgICB0aWxlLmdldEltYWdlKCkuc3JjID0gYmxvYlVybDtcbiAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICB3aW5kb3cuVVJMLnJldm9rZU9iamVjdFVSTChibG9iVXJsKTtcbiAgICAgICAgICAgICAgICAgIH0sIDEwMDApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cbn1cbiJdfQ==