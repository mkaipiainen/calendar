import { AfterViewInit, ChangeDetectorRef, ElementRef, EventEmitter, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export interface IOuiTextareaOptions {
    label?: string;
    placeholder?: string;
    disabled?: boolean;
    hasError?: boolean;
    disableResize?: boolean;
    autoSizeOptions?: {
        isEnabled: boolean;
        maxHeight?: string;
        minHeight?: string;
    };
}
/**
 * Component to add input-fields.
 *
 *   Example use:
 *   <oui-textarea [(model)]="model"></oui-input>
 */
export declare class OuiTextareaComponent implements AfterViewInit {
    private cdr;
    private renderer;
    private elementRef;
    textarea: ElementRef;
    autosizeWrapper: ElementRef;
    /**
     *   The model that's bound to the input field
     */
    model: any;
    /**
     * Options of the input-field. See IOuiInputOptions for more information
     */
    set options(newOptions: IOuiTextareaOptions);
    get options(): IOuiTextareaOptions;
    /**
     *   The event emitted when input field changes.
     */
    modelChange: EventEmitter<any>;
    /**
     *   The event emitted when the hasError-field changes
     */
    hasErrorChange: EventEmitter<boolean>;
    private defaultOptions;
    private resizeListener;
    isFocused: import("@angular/core").WritableSignal<boolean>;
    isInitialized: import("@angular/core").WritableSignal<boolean>;
    optionsSignal: import("@angular/core").WritableSignal<IOuiTextareaOptions>;
    className: import("@angular/core").Signal<string>;
    constructor(cdr: ChangeDetectorRef, renderer: Renderer2, elementRef: ElementRef);
    onModelChange(): void;
    private updateHeight;
    private initResizeListener;
    private onInput;
    ngAfterViewInit(): void;
    setFocus(value: boolean): void;
    setError(value: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiTextareaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiTextareaComponent, "oui-textarea", never, { "model": { "alias": "model"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, { "modelChange": "modelChange"; "hasErrorChange": "hasErrorChange"; }, never, never, true, never>;
}
//# sourceMappingURL=textarea.component.d.ts.map