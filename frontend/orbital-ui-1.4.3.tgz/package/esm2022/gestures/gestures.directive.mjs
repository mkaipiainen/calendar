/**
 * TinyGesture.js
 *
 * This service uses passive listeners, so you can't call event.preventDefault()
 * on any of the events.
 *
 * Adapted from https://gist.github.com/SleepWalker/da5636b1abcbaff48c4d
 * and https://github.com/uxitten/xwiper
 */
import { Directive, Inject, Input, } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import * as i0 from "@angular/core";
export class OuiGesturesDirective {
    renderer;
    elementRef;
    document;
    destroyRef;
    set gestureOptions(options) {
        this.#combinedOptions = {
            disabled: options.disabled ?? false,
            swipe: options.swipe
                ? {
                    velocityThreshold: 0,
                    requiredSwipeDistance: 50,
                    distanceToDisregardVelocity: Infinity,
                    hasDiagonalSwipes: false,
                    diagonalLimit: Math.tan(((45 * 1.5) / 180) * Math.PI),
                    ...options.swipe,
                }
                : undefined,
            doubleTap: options.doubleTap
                ? {
                    ...options.doubleTap,
                }
                : undefined,
            longPress: options.longPress
                ? { pressThreshold: 10, ...options.longPress }
                : undefined,
        };
        this.#originalOptions = options;
    }
    get gestureOptions() {
        return this.#originalOptions;
    }
    #isPassiveSupported = {
        passive: false,
    };
    #longPressTimer = null;
    #originalOptions;
    #combinedOptions;
    touchStartX = null;
    touchStartY = null;
    touchEndX = null;
    touchEndY = null;
    touchMoveX = null;
    touchMoveY = null;
    velocityX = 0;
    velocityY = 0;
    longPressTimer = null;
    doubleTapTimer = null;
    doubleTapWaiting = false;
    swipingHorizontal = false;
    swipingVertical = false;
    swipingDirection = null;
    swipedHorizontal = false;
    swipedVertical = false;
    unlisteners = {};
    constructor(renderer, elementRef, document, destroyRef) {
        // Check if passive is supported
        this.renderer = renderer;
        this.elementRef = elementRef;
        this.document = document;
        this.destroyRef = destroyRef;
        try {
            window.addEventListener('test', null, Object.defineProperty({}, 'passive', {
                get: () => {
                    this.#isPassiveSupported = { passive: true };
                },
            }));
        }
        catch (err) { }
    }
    ngAfterViewInit() {
        this.renderer.setStyle(this.elementRef.nativeElement, 'user-gestures', 'none');
        this.renderer.setStyle(this.elementRef.nativeElement, 'touch-action', 'none');
        this.unlisteners['touchstart'] = this.renderer.listen(this.elementRef.nativeElement, 'touchstart', this.onTouchStart.bind(this));
        this.unlisteners['touchmove'] = this.renderer.listen(this.document.body, 'touchmove', this.onTouchMove.bind(this));
        this.unlisteners['touchend'] = this.renderer.listen(this.document.body, 'touchend', this.onTouchEnd.bind(this));
        this.unlisteners['mousedown'] = this.renderer.listen(this.elementRef.nativeElement, 'mousedown', this.onTouchStart.bind(this));
        this.unlisteners['mousemove'] = this.renderer.listen(this.document.body, 'mousemove', this.onTouchMove.bind(this));
        this.unlisteners['mouseup'] = this.renderer.listen(this.document.body, 'mouseup', this.onTouchEnd.bind(this));
        this.destroyRef.onDestroy(() => {
            for (let unlistener of Object.values(this.unlisteners)) {
                unlistener();
            }
        });
    }
    ngOnDestroy() {
        clearTimeout(this.longPressTimer ?? undefined);
        clearTimeout(this.doubleTapTimer ?? undefined);
        for (let unlistener of Object.values(this.unlisteners)) {
            unlistener();
        }
    }
    onTouchStart(event) {
        if (this.#combinedOptions.disabled) {
            return;
        }
        this.touchStartX =
            event.type === 'mousedown'
                ? event.screenX
                : event.changedTouches[0].screenX;
        this.touchStartY =
            event.type === 'mousedown'
                ? event.screenY
                : event.changedTouches[0].screenY;
        this.touchMoveX = null;
        this.touchMoveY = null;
        this.touchEndX = null;
        this.touchEndY = null;
        this.swipingDirection = null;
        // Long press.
        if (this.#combinedOptions.longPress) {
            this.#longPressTimer = setTimeout(() => {
                if (this.#combinedOptions.longPress) {
                    this.#combinedOptions.longPress.onLongPress(event);
                }
            }, this.#combinedOptions.longPress.time);
        }
    }
    onTouchMove(event) {
        if (this.#combinedOptions.disabled) {
            return;
        }
        if (event.type === 'mousemove' &&
            (!this.touchStartX || this.touchEndX !== null)) {
            return;
        }
        const touchMoveX = (event.type === 'mousemove'
            ? event.screenX
            : event.changedTouches[0].screenX) -
            (this.touchStartX ?? 0);
        this.velocityX = touchMoveX - (this.touchMoveX ?? 0);
        this.touchMoveX = touchMoveX;
        const touchMoveY = (event.type === 'mousemove'
            ? event.screenY
            : event.changedTouches[0].screenY) -
            (this.touchStartY ?? 0);
        this.velocityY = touchMoveY - (this.touchMoveY ?? 0);
        this.touchMoveY = touchMoveY;
        const absTouchMoveX = Math.abs(this.touchMoveX);
        const absTouchMoveY = Math.abs(this.touchMoveY);
        this.swipingHorizontal = this.#combinedOptions.swipe
            ? absTouchMoveX > this.#combinedOptions.swipe.requiredSwipeDistance
            : false;
        this.swipingVertical = this.#combinedOptions.swipe
            ? absTouchMoveY > this.#combinedOptions.swipe.requiredSwipeDistance
            : false;
        if (this.#combinedOptions.longPress) {
            if (Math.max(absTouchMoveX, absTouchMoveY) >
                this.#combinedOptions.longPress.pressThreshold) {
                clearTimeout(this.longPressTimer ?? undefined);
            }
        }
    }
    onTouchEnd(event) {
        if (this.#combinedOptions.disabled ||
            !this.touchStartX ||
            !this.touchStartY ||
            !this.touchMoveX ||
            !this.touchMoveY) {
            return;
        }
        if (event.type === 'mouseup' &&
            (!this.touchStartX || this.touchEndX !== null)) {
            return;
        }
        this.touchEndX =
            event.type === 'mouseup'
                ? event.screenX
                : event.changedTouches[0].screenX;
        this.touchEndY =
            event.type === 'mouseup'
                ? event.screenY
                : event.changedTouches[0].screenY;
        clearTimeout(this.longPressTimer ?? undefined);
        const x = this.touchEndX - (this.touchStartX ?? 0);
        const absX = Math.abs(x);
        const y = this.touchEndY - (this.touchStartY ?? 0);
        const absY = Math.abs(y);
        if (this.#combinedOptions.swipe) {
            if (absX > this.#combinedOptions.swipe.requiredSwipeDistance ||
                absY > this.#combinedOptions.swipe.requiredSwipeDistance) {
                this.swipedHorizontal = this.#combinedOptions.swipe.hasDiagonalSwipes
                    ? Math.abs(x / y) <= this.#combinedOptions.swipe.diagonalLimit
                    : absX >= absY &&
                        absX > this.#combinedOptions.swipe.requiredSwipeDistance;
                this.swipedVertical = this.#combinedOptions.swipe.hasDiagonalSwipes
                    ? Math.abs(y / x) <= this.#combinedOptions.swipe.diagonalLimit
                    : absY > absX &&
                        absY > this.#combinedOptions.swipe.requiredSwipeDistance;
                if (this.swipedHorizontal) {
                    if (x < 0) {
                        // Left swipe.
                        if ((this.velocityX ?? 0) <
                            -this.#combinedOptions.swipe.velocityThreshold ||
                            x < -this.#combinedOptions.swipe.distanceToDisregardVelocity) {
                            this.#combinedOptions.swipe.onSwipe({
                                type: 'left',
                                velocityX: this.velocityX,
                                velocityY: this.velocityY,
                                distanceX: absX,
                                distanceY: absY,
                                event,
                            });
                        }
                    }
                    else {
                        // Right swipe.
                        if ((this.velocityX ?? 0) >
                            this.#combinedOptions.swipe.velocityThreshold ||
                            x > this.#combinedOptions.swipe.distanceToDisregardVelocity) {
                            this.#combinedOptions.swipe.onSwipe({
                                type: 'right',
                                velocityX: this.velocityX,
                                velocityY: this.velocityY,
                                distanceX: absX,
                                distanceY: absY,
                                event,
                            });
                        }
                    }
                }
                if (this.swipedVertical) {
                    if (y < 0) {
                        // Upward swipe.
                        if ((this.velocityY ?? 0) <
                            -this.#combinedOptions.swipe.velocityThreshold ||
                            y < -this.#combinedOptions.swipe.distanceToDisregardVelocity) {
                            this.#combinedOptions.swipe.onSwipe({
                                type: 'up',
                                velocityX: this.velocityX,
                                velocityY: this.velocityY,
                                distanceX: absX,
                                distanceY: absY,
                                event,
                            });
                        }
                    }
                    else {
                        // Downward swipe.
                        if ((this.velocityY ?? 0) >
                            this.#combinedOptions.swipe.velocityThreshold ||
                            y > this.#combinedOptions.swipe.distanceToDisregardVelocity) {
                            this.#combinedOptions.swipe.onSwipe({
                                type: 'down',
                                velocityX: this.velocityX,
                                velocityY: this.velocityY,
                                distanceX: absX,
                                distanceY: absY,
                                event,
                            });
                        }
                    }
                }
            }
        }
        if (this.#combinedOptions.doubleTap) {
            if (this.doubleTapWaiting) {
                this.doubleTapWaiting = false;
                clearTimeout(this.doubleTapTimer ?? undefined);
                this.#combinedOptions.doubleTap.onDoubleTap(event);
            }
            else {
                this.doubleTapWaiting = true;
                this.doubleTapTimer = setTimeout(() => (this.doubleTapWaiting = false), this.#combinedOptions.doubleTap.time);
            }
        }
        this.touchStartX = null;
        this.touchStartY = null;
        this.touchMoveX = null;
        this.touchMoveY = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiGesturesDirective, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }, { token: DOCUMENT }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.1", type: OuiGesturesDirective, isStandalone: true, selector: "[oui-gestures]", inputs: { gestureOptions: "gestureOptions" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiGesturesDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[oui-gestures]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.DestroyRef }], propDecorators: { gestureOptions: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2VzdHVyZXMuZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9nZXN0dXJlcy9nZXN0dXJlcy5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7O0dBUUc7QUFDSCxPQUFPLEVBR0wsU0FBUyxFQUVULE1BQU0sRUFDTixLQUFLLEdBR04sTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDOztBQXFFM0MsTUFBTSxPQUFPLG9CQUFvQjtJQTREckI7SUFDQTtJQUNrQjtJQUNsQjtJQTlEVixJQUFhLGNBQWMsQ0FBQyxPQUEyQjtRQUNyRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUc7WUFDdEIsUUFBUSxFQUFFLE9BQU8sQ0FBQyxRQUFRLElBQUksS0FBSztZQUNuQyxLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUs7Z0JBQ2xCLENBQUMsQ0FBQztvQkFDRSxpQkFBaUIsRUFBRSxDQUFDO29CQUNwQixxQkFBcUIsRUFBRSxFQUFFO29CQUN6QiwyQkFBMkIsRUFBRSxRQUFRO29CQUNyQyxpQkFBaUIsRUFBRSxLQUFLO29CQUN4QixhQUFhLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUM7b0JBQ3JELEdBQUcsT0FBTyxDQUFDLEtBQUs7aUJBQ2pCO2dCQUNILENBQUMsQ0FBQyxTQUFTO1lBQ2IsU0FBUyxFQUFFLE9BQU8sQ0FBQyxTQUFTO2dCQUMxQixDQUFDLENBQUM7b0JBQ0UsR0FBRyxPQUFPLENBQUMsU0FBUztpQkFDckI7Z0JBQ0gsQ0FBQyxDQUFDLFNBQVM7WUFDYixTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVM7Z0JBQzFCLENBQUMsQ0FBQyxFQUFFLGNBQWMsRUFBRSxFQUFFLEVBQUUsR0FBRyxPQUFPLENBQUMsU0FBUyxFQUFFO2dCQUM5QyxDQUFDLENBQUMsU0FBUztTQUNkLENBQUM7UUFDRixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsT0FBTyxDQUFDO0lBQ2xDLENBQUM7SUFFRCxJQUFJLGNBQWM7UUFDaEIsT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7SUFDL0IsQ0FBQztJQUVELG1CQUFtQixHQUFHO1FBQ3BCLE9BQU8sRUFBRSxLQUFLO0tBQ2YsQ0FBQztJQUNGLGVBQWUsR0FBUSxJQUFJLENBQUM7SUFDNUIsZ0JBQWdCLENBQXFCO0lBQ3JDLGdCQUFnQixDQUE0QjtJQUVyQyxXQUFXLEdBQWtCLElBQUksQ0FBQztJQUNsQyxXQUFXLEdBQWtCLElBQUksQ0FBQztJQUNsQyxTQUFTLEdBQWtCLElBQUksQ0FBQztJQUNoQyxTQUFTLEdBQWtCLElBQUksQ0FBQztJQUNoQyxVQUFVLEdBQWtCLElBQUksQ0FBQztJQUNqQyxVQUFVLEdBQWtCLElBQUksQ0FBQztJQUNqQyxTQUFTLEdBQVcsQ0FBQyxDQUFDO0lBQ3RCLFNBQVMsR0FBVyxDQUFDLENBQUM7SUFFdEIsY0FBYyxHQUFlLElBQUksQ0FBQztJQUNsQyxjQUFjLEdBQWUsSUFBSSxDQUFDO0lBRWxDLGdCQUFnQixHQUFZLEtBQUssQ0FBQztJQUVsQyxpQkFBaUIsR0FBWSxLQUFLLENBQUM7SUFDbkMsZUFBZSxHQUFZLEtBQUssQ0FBQztJQUNqQyxnQkFBZ0IsR0FBNEIsSUFBSSxDQUFDO0lBQ2pELGdCQUFnQixHQUFZLEtBQUssQ0FBQztJQUNsQyxjQUFjLEdBQVksS0FBSyxDQUFDO0lBRWhDLFdBQVcsR0FBK0IsRUFBRSxDQUFDO0lBRXBELFlBQ1UsUUFBbUIsRUFDbkIsVUFBc0IsRUFDSixRQUFrQixFQUNwQyxVQUFzQjtRQUU5QixnQ0FBZ0M7UUFMeEIsYUFBUSxHQUFSLFFBQVEsQ0FBVztRQUNuQixlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQ0osYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUNwQyxlQUFVLEdBQVYsVUFBVSxDQUFZO1FBSTlCLElBQUksQ0FBQztZQUNILE1BQU0sQ0FBQyxnQkFBZ0IsQ0FDckIsTUFBTSxFQUNOLElBQVcsRUFDWCxNQUFNLENBQUMsY0FBYyxDQUFDLEVBQUUsRUFBRSxTQUFTLEVBQUU7Z0JBQ25DLEdBQUcsRUFBRSxHQUFHLEVBQUU7b0JBQ1IsSUFBSSxDQUFDLG1CQUFtQixHQUFHLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFDO2dCQUMvQyxDQUFDO2FBQ0YsQ0FBQyxDQUNILENBQUM7UUFDSixDQUFDO1FBQUMsT0FBTyxHQUFHLEVBQUUsQ0FBQyxDQUFBLENBQUM7SUFDbEIsQ0FBQztJQUVNLGVBQWU7UUFDcEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQ3BCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUM3QixlQUFlLEVBQ2YsTUFBTSxDQUNQLENBQUM7UUFDRixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FDcEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQzdCLGNBQWMsRUFDZCxNQUFNLENBQ1AsQ0FBQztRQUNGLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQ25ELElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUM3QixZQUFZLEVBQ1osSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQzdCLENBQUM7UUFDRixJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUNsRCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFDbEIsV0FBVyxFQUNYLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUM1QixDQUFDO1FBQ0YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FDakQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQ2xCLFVBQVUsRUFDVixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FDM0IsQ0FBQztRQUVGLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQ2xELElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUM3QixXQUFXLEVBQ1gsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQzdCLENBQUM7UUFDRixJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUNsRCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFDbEIsV0FBVyxFQUNYLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUM1QixDQUFDO1FBQ0YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FDaEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQ2xCLFNBQVMsRUFDVCxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FDM0IsQ0FBQztRQUNGLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRTtZQUM3QixLQUFLLElBQUksVUFBVSxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7Z0JBQ3ZELFVBQVUsRUFBRSxDQUFDO1lBQ2YsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELFdBQVc7UUFDVCxZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsSUFBSSxTQUFTLENBQUMsQ0FBQztRQUMvQyxZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsSUFBSSxTQUFTLENBQUMsQ0FBQztRQUMvQyxLQUFLLElBQUksVUFBVSxJQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7WUFDdkQsVUFBVSxFQUFFLENBQUM7UUFDZixDQUFDO0lBQ0gsQ0FBQztJQUVELFlBQVksQ0FBQyxLQUE4QjtRQUN6QyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNuQyxPQUFPO1FBQ1QsQ0FBQztRQUNELElBQUksQ0FBQyxXQUFXO1lBQ2QsS0FBSyxDQUFDLElBQUksS0FBSyxXQUFXO2dCQUN4QixDQUFDLENBQUUsS0FBb0IsQ0FBQyxPQUFPO2dCQUMvQixDQUFDLENBQUUsS0FBb0IsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQ3RELElBQUksQ0FBQyxXQUFXO1lBQ2QsS0FBSyxDQUFDLElBQUksS0FBSyxXQUFXO2dCQUN4QixDQUFDLENBQUUsS0FBb0IsQ0FBQyxPQUFPO2dCQUMvQixDQUFDLENBQUUsS0FBb0IsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQ3RELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDO1FBQ3RCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUM7UUFDN0IsY0FBYztRQUNkLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ3BDLElBQUksQ0FBQyxlQUFlLEdBQUcsVUFBVSxDQUFDLEdBQUcsRUFBRTtnQkFDckMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLENBQUM7b0JBQ3BDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNyRCxDQUFDO1lBQ0gsQ0FBQyxFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDM0MsQ0FBQztJQUNILENBQUM7SUFFRCxXQUFXLENBQUMsS0FBOEI7UUFDeEMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDbkMsT0FBTztRQUNULENBQUM7UUFDRCxJQUNFLEtBQUssQ0FBQyxJQUFJLEtBQUssV0FBVztZQUMxQixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLElBQUksQ0FBQyxFQUM5QyxDQUFDO1lBQ0QsT0FBTztRQUNULENBQUM7UUFDRCxNQUFNLFVBQVUsR0FDZCxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssV0FBVztZQUN6QixDQUFDLENBQUUsS0FBb0IsQ0FBQyxPQUFPO1lBQy9CLENBQUMsQ0FBRSxLQUFvQixDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7WUFDcEQsQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzFCLElBQUksQ0FBQyxTQUFTLEdBQUcsVUFBVSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUNyRCxJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztRQUM3QixNQUFNLFVBQVUsR0FDZCxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssV0FBVztZQUN6QixDQUFDLENBQUUsS0FBb0IsQ0FBQyxPQUFPO1lBQy9CLENBQUMsQ0FBRSxLQUFvQixDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7WUFDcEQsQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzFCLElBQUksQ0FBQyxTQUFTLEdBQUcsVUFBVSxHQUFHLENBQUMsSUFBSSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUNyRCxJQUFJLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztRQUM3QixNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNoRCxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUNoRCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUs7WUFDbEQsQ0FBQyxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLHFCQUFxQjtZQUNuRSxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQ1YsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSztZQUNoRCxDQUFDLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMscUJBQXFCO1lBQ25FLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDVixJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNwQyxJQUNFLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLGFBQWEsQ0FBQztnQkFDdEMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQzlDLENBQUM7Z0JBQ0QsWUFBWSxDQUFDLElBQUksQ0FBQyxjQUFjLElBQUksU0FBUyxDQUFDLENBQUM7WUFDakQsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRUQsVUFBVSxDQUFDLEtBQThCO1FBQ3ZDLElBQ0UsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVE7WUFDOUIsQ0FBQyxJQUFJLENBQUMsV0FBVztZQUNqQixDQUFDLElBQUksQ0FBQyxXQUFXO1lBQ2pCLENBQUMsSUFBSSxDQUFDLFVBQVU7WUFDaEIsQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUNoQixDQUFDO1lBQ0QsT0FBTztRQUNULENBQUM7UUFDRCxJQUNFLEtBQUssQ0FBQyxJQUFJLEtBQUssU0FBUztZQUN4QixDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLENBQUMsU0FBUyxLQUFLLElBQUksQ0FBQyxFQUM5QyxDQUFDO1lBQ0QsT0FBTztRQUNULENBQUM7UUFDRCxJQUFJLENBQUMsU0FBUztZQUNaLEtBQUssQ0FBQyxJQUFJLEtBQUssU0FBUztnQkFDdEIsQ0FBQyxDQUFFLEtBQW9CLENBQUMsT0FBTztnQkFDL0IsQ0FBQyxDQUFFLEtBQW9CLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztRQUN0RCxJQUFJLENBQUMsU0FBUztZQUNaLEtBQUssQ0FBQyxJQUFJLEtBQUssU0FBUztnQkFDdEIsQ0FBQyxDQUFFLEtBQW9CLENBQUMsT0FBTztnQkFDL0IsQ0FBQyxDQUFFLEtBQW9CLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztRQUN0RCxZQUFZLENBQUMsSUFBSSxDQUFDLGNBQWMsSUFBSSxTQUFTLENBQUMsQ0FBQztRQUMvQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsSUFBSSxDQUFDLFdBQVcsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUNuRCxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3pCLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQ25ELE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDekIsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDaEMsSUFDRSxJQUFJLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxxQkFBcUI7Z0JBQ3hELElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLHFCQUFxQixFQUN4RCxDQUFDO2dCQUNELElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLGlCQUFpQjtvQkFDbkUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsYUFBYTtvQkFDOUQsQ0FBQyxDQUFDLElBQUksSUFBSSxJQUFJO3dCQUNaLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLHFCQUFxQixDQUFDO2dCQUM3RCxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsaUJBQWlCO29CQUNqRSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxhQUFhO29CQUM5RCxDQUFDLENBQUMsSUFBSSxHQUFHLElBQUk7d0JBQ1gsSUFBSSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUM7Z0JBQzdELElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7b0JBQzFCLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO3dCQUNWLGNBQWM7d0JBQ2QsSUFDRSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDOzRCQUNuQixDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsaUJBQWlCOzRCQUNoRCxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLDJCQUEyQixFQUM1RCxDQUFDOzRCQUNELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO2dDQUNsQyxJQUFJLEVBQUUsTUFBTTtnQ0FDWixTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7Z0NBQ3pCLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztnQ0FDekIsU0FBUyxFQUFFLElBQUk7Z0NBQ2YsU0FBUyxFQUFFLElBQUk7Z0NBQ2YsS0FBSzs2QkFDTixDQUFDLENBQUM7d0JBQ0wsQ0FBQztvQkFDSCxDQUFDO3lCQUFNLENBQUM7d0JBQ04sZUFBZTt3QkFDZixJQUNFLENBQUMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLENBQUM7NEJBQ25CLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsaUJBQWlCOzRCQUMvQyxDQUFDLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQywyQkFBMkIsRUFDM0QsQ0FBQzs0QkFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQ0FDbEMsSUFBSSxFQUFFLE9BQU87Z0NBQ2IsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2dDQUN6QixTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7Z0NBQ3pCLFNBQVMsRUFBRSxJQUFJO2dDQUNmLFNBQVMsRUFBRSxJQUFJO2dDQUNmLEtBQUs7NkJBQ04sQ0FBQyxDQUFDO3dCQUNMLENBQUM7b0JBQ0gsQ0FBQztnQkFDSCxDQUFDO2dCQUNELElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO29CQUN4QixJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQzt3QkFDVixnQkFBZ0I7d0JBQ2hCLElBQ0UsQ0FBQyxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsQ0FBQzs0QkFDbkIsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLGlCQUFpQjs0QkFDaEQsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQywyQkFBMkIsRUFDNUQsQ0FBQzs0QkFDRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQ0FDbEMsSUFBSSxFQUFFLElBQUk7Z0NBQ1YsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2dDQUN6QixTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7Z0NBQ3pCLFNBQVMsRUFBRSxJQUFJO2dDQUNmLFNBQVMsRUFBRSxJQUFJO2dDQUNmLEtBQUs7NkJBQ04sQ0FBQyxDQUFDO3dCQUNMLENBQUM7b0JBQ0gsQ0FBQzt5QkFBTSxDQUFDO3dCQUNOLGtCQUFrQjt3QkFDbEIsSUFDRSxDQUFDLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDOzRCQUNuQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLGlCQUFpQjs0QkFDL0MsQ0FBQyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLENBQUMsMkJBQTJCLEVBQzNELENBQUM7NEJBQ0QsSUFBSSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0NBQ2xDLElBQUksRUFBRSxNQUFNO2dDQUNaLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztnQ0FDekIsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO2dDQUN6QixTQUFTLEVBQUUsSUFBSTtnQ0FDZixTQUFTLEVBQUUsSUFBSTtnQ0FDZixLQUFLOzZCQUNOLENBQUMsQ0FBQzt3QkFDTCxDQUFDO29CQUNILENBQUM7Z0JBQ0gsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDcEMsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDMUIsSUFBSSxDQUFDLGdCQUFnQixHQUFHLEtBQUssQ0FBQztnQkFDOUIsWUFBWSxDQUFDLElBQUksQ0FBQyxjQUFjLElBQUksU0FBUyxDQUFDLENBQUM7Z0JBQy9DLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3JELENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDO2dCQUM3QixJQUFJLENBQUMsY0FBYyxHQUFHLFVBQVUsQ0FDOUIsR0FBRyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDLEVBQ3JDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUNyQyxDQUFDO1lBQ0osQ0FBQztRQUNILENBQUM7UUFFRCxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztRQUN4QixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztRQUN4QixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztRQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQztJQUN6QixDQUFDO3VHQWxWVSxvQkFBb0IscUVBOERyQixRQUFROzJGQTlEUCxvQkFBb0I7OzJGQUFwQixvQkFBb0I7a0JBSmhDLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLGdCQUFnQjtvQkFDMUIsVUFBVSxFQUFFLElBQUk7aUJBQ2pCOzswQkErREksTUFBTTsyQkFBQyxRQUFRO2tFQTdETCxjQUFjO3NCQUExQixLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBUaW55R2VzdHVyZS5qc1xuICpcbiAqIFRoaXMgc2VydmljZSB1c2VzIHBhc3NpdmUgbGlzdGVuZXJzLCBzbyB5b3UgY2FuJ3QgY2FsbCBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gKiBvbiBhbnkgb2YgdGhlIGV2ZW50cy5cbiAqXG4gKiBBZGFwdGVkIGZyb20gaHR0cHM6Ly9naXN0LmdpdGh1Yi5jb20vU2xlZXBXYWxrZXIvZGE1NjM2YjFhYmNiYWZmNDhjNGRcbiAqIGFuZCBodHRwczovL2dpdGh1Yi5jb20vdXhpdHRlbi94d2lwZXJcbiAqL1xuaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgRGVzdHJveVJlZixcbiAgRGlyZWN0aXZlLFxuICBFbGVtZW50UmVmLFxuICBJbmplY3QsXG4gIElucHV0LFxuICBPbkRlc3Ryb3ksXG4gIFJlbmRlcmVyMixcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBET0NVTUVOVCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5cbmV4cG9ydCBpbnRlcmZhY2UgSU91aUdlc3R1cmVPcHRpb25zIHtcbiAgZGlzYWJsZWQ/OiBib29sZWFuO1xuICBzd2lwZT86IElPdWlHZXN0dXJlU3dpcGVPcHRpb25zO1xuICBkb3VibGVUYXA/OiBJT3VpRG91YmxlVGFwT3B0aW9ucztcbiAgbG9uZ1ByZXNzPzogSU91aUxvbmdQcmVzc09wdGlvbnM7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSU91aUdlc3R1cmVEZWZhdWx0T3B0aW9ucyB7XG4gIGRpc2FibGVkOiBib29sZWFuO1xuICBzd2lwZT86IElPdWlHZXN0dXJlU3dpcGVEZWZhdWx0T3B0aW9ucztcbiAgZG91YmxlVGFwPzogSU91aURvdWJsZVRhcERlZmF1bHRPcHRpb25zO1xuICBsb25nUHJlc3M/OiBJT3VpTG9uZ1ByZXNzRGVmYXVsdE9wdGlvbnM7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSU91aUdlc3R1cmVTd2lwZU9wdGlvbnMge1xuICB2ZWxvY2l0eVRocmVzaG9sZD86IG51bWJlcjtcbiAgaGFzRGlhZ29uYWxTd2lwZXM/OiBib29sZWFuO1xuICBkaWFnb25hbExpbWl0PzogbnVtYmVyO1xuICByZXF1aXJlZFN3aXBlRGlzdGFuY2U/OiBudW1iZXI7XG4gIGRpc3RhbmNlVG9EaXNyZWdhcmRWZWxvY2l0eT86IG51bWJlcjtcbiAgb25Td2lwZTogKGV2ZW50OiBJT3VpR2VzdHVyZVN3aXBlRXZlbnQpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSU91aUdlc3R1cmVTd2lwZURlZmF1bHRPcHRpb25zIHtcbiAgdmVsb2NpdHlUaHJlc2hvbGQ6IG51bWJlcjtcbiAgaGFzRGlhZ29uYWxTd2lwZXM6IGJvb2xlYW47XG4gIHJlcXVpcmVkU3dpcGVEaXN0YW5jZTogbnVtYmVyO1xuICBkaXN0YW5jZVRvRGlzcmVnYXJkVmVsb2NpdHk6IG51bWJlcjtcbiAgZGlhZ29uYWxMaW1pdDogbnVtYmVyO1xuICBvblN3aXBlOiAoZXZlbnQ6IElPdWlHZXN0dXJlU3dpcGVFdmVudCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJT3VpR2VzdHVyZVN3aXBlRXZlbnQge1xuICB0eXBlOiBTd2lwaW5nRGlyZWN0aW9uO1xuICBldmVudDogTW91c2VFdmVudCB8IFRvdWNoRXZlbnQ7XG4gIGRpc3RhbmNlWDogbnVtYmVyO1xuICBkaXN0YW5jZVk6IG51bWJlcjtcbiAgdmVsb2NpdHlYOiBudW1iZXI7XG4gIHZlbG9jaXR5WTogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElPdWlEb3VibGVUYXBPcHRpb25zIHtcbiAgdGltZTogbnVtYmVyO1xuICBvbkRvdWJsZVRhcDogKGV2ZW50OiBNb3VzZUV2ZW50IHwgVG91Y2hFdmVudCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJT3VpRG91YmxlVGFwRGVmYXVsdE9wdGlvbnMge1xuICB0aW1lOiBudW1iZXI7XG4gIG9uRG91YmxlVGFwOiAoZXZlbnQ6IE1vdXNlRXZlbnQgfCBUb3VjaEV2ZW50KSA9PiB2b2lkO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElPdWlMb25nUHJlc3NPcHRpb25zIHtcbiAgdGltZTogbnVtYmVyO1xuICBvbkxvbmdQcmVzczogKGV2ZW50OiBNb3VzZUV2ZW50IHwgVG91Y2hFdmVudCkgPT4gdm9pZDtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJT3VpTG9uZ1ByZXNzRGVmYXVsdE9wdGlvbnMge1xuICB0aW1lOiBudW1iZXI7XG4gIHByZXNzVGhyZXNob2xkOiBudW1iZXI7XG4gIG9uTG9uZ1ByZXNzOiAoZXZlbnQ6IE1vdXNlRXZlbnQgfCBUb3VjaEV2ZW50KSA9PiB2b2lkO1xufVxuXG5leHBvcnQgdHlwZSBTd2lwaW5nRGlyZWN0aW9uID0gJ3VwJyB8ICdkb3duJyB8ICdsZWZ0JyB8ICdyaWdodCc7XG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdbb3VpLWdlc3R1cmVzXScsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG59KVxuZXhwb3J0IGNsYXNzIE91aUdlc3R1cmVzRGlyZWN0aXZlIGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95IHtcbiAgQElucHV0KCkgc2V0IGdlc3R1cmVPcHRpb25zKG9wdGlvbnM6IElPdWlHZXN0dXJlT3B0aW9ucykge1xuICAgIHRoaXMuI2NvbWJpbmVkT3B0aW9ucyA9IHtcbiAgICAgIGRpc2FibGVkOiBvcHRpb25zLmRpc2FibGVkID8/IGZhbHNlLFxuICAgICAgc3dpcGU6IG9wdGlvbnMuc3dpcGVcbiAgICAgICAgPyB7XG4gICAgICAgICAgICB2ZWxvY2l0eVRocmVzaG9sZDogMCxcbiAgICAgICAgICAgIHJlcXVpcmVkU3dpcGVEaXN0YW5jZTogNTAsXG4gICAgICAgICAgICBkaXN0YW5jZVRvRGlzcmVnYXJkVmVsb2NpdHk6IEluZmluaXR5LFxuICAgICAgICAgICAgaGFzRGlhZ29uYWxTd2lwZXM6IGZhbHNlLFxuICAgICAgICAgICAgZGlhZ29uYWxMaW1pdDogTWF0aC50YW4oKCg0NSAqIDEuNSkgLyAxODApICogTWF0aC5QSSksXG4gICAgICAgICAgICAuLi5vcHRpb25zLnN3aXBlLFxuICAgICAgICAgIH1cbiAgICAgICAgOiB1bmRlZmluZWQsXG4gICAgICBkb3VibGVUYXA6IG9wdGlvbnMuZG91YmxlVGFwXG4gICAgICAgID8ge1xuICAgICAgICAgICAgLi4ub3B0aW9ucy5kb3VibGVUYXAsXG4gICAgICAgICAgfVxuICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICAgIGxvbmdQcmVzczogb3B0aW9ucy5sb25nUHJlc3NcbiAgICAgICAgPyB7IHByZXNzVGhyZXNob2xkOiAxMCwgLi4ub3B0aW9ucy5sb25nUHJlc3MgfVxuICAgICAgICA6IHVuZGVmaW5lZCxcbiAgICB9O1xuICAgIHRoaXMuI29yaWdpbmFsT3B0aW9ucyA9IG9wdGlvbnM7XG4gIH1cblxuICBnZXQgZ2VzdHVyZU9wdGlvbnMoKSB7XG4gICAgcmV0dXJuIHRoaXMuI29yaWdpbmFsT3B0aW9ucztcbiAgfVxuXG4gICNpc1Bhc3NpdmVTdXBwb3J0ZWQgPSB7XG4gICAgcGFzc2l2ZTogZmFsc2UsXG4gIH07XG4gICNsb25nUHJlc3NUaW1lcjogYW55ID0gbnVsbDtcbiAgI29yaWdpbmFsT3B0aW9uczogSU91aUdlc3R1cmVPcHRpb25zO1xuICAjY29tYmluZWRPcHRpb25zOiBJT3VpR2VzdHVyZURlZmF1bHRPcHRpb25zO1xuXG4gIHB1YmxpYyB0b3VjaFN0YXJ0WDogbnVtYmVyIHwgbnVsbCA9IG51bGw7XG4gIHB1YmxpYyB0b3VjaFN0YXJ0WTogbnVtYmVyIHwgbnVsbCA9IG51bGw7XG4gIHB1YmxpYyB0b3VjaEVuZFg6IG51bWJlciB8IG51bGwgPSBudWxsO1xuICBwdWJsaWMgdG91Y2hFbmRZOiBudW1iZXIgfCBudWxsID0gbnVsbDtcbiAgcHVibGljIHRvdWNoTW92ZVg6IG51bWJlciB8IG51bGwgPSBudWxsO1xuICBwdWJsaWMgdG91Y2hNb3ZlWTogbnVtYmVyIHwgbnVsbCA9IG51bGw7XG4gIHB1YmxpYyB2ZWxvY2l0eVg6IG51bWJlciA9IDA7XG4gIHB1YmxpYyB2ZWxvY2l0eVk6IG51bWJlciA9IDA7XG5cbiAgcHVibGljIGxvbmdQcmVzc1RpbWVyOiBhbnkgfCBudWxsID0gbnVsbDtcbiAgcHVibGljIGRvdWJsZVRhcFRpbWVyOiBhbnkgfCBudWxsID0gbnVsbDtcblxuICBwdWJsaWMgZG91YmxlVGFwV2FpdGluZzogYm9vbGVhbiA9IGZhbHNlO1xuXG4gIHB1YmxpYyBzd2lwaW5nSG9yaXpvbnRhbDogYm9vbGVhbiA9IGZhbHNlO1xuICBwdWJsaWMgc3dpcGluZ1ZlcnRpY2FsOiBib29sZWFuID0gZmFsc2U7XG4gIHB1YmxpYyBzd2lwaW5nRGlyZWN0aW9uOiBTd2lwaW5nRGlyZWN0aW9uIHwgbnVsbCA9IG51bGw7XG4gIHB1YmxpYyBzd2lwZWRIb3Jpem9udGFsOiBib29sZWFuID0gZmFsc2U7XG4gIHB1YmxpYyBzd2lwZWRWZXJ0aWNhbDogYm9vbGVhbiA9IGZhbHNlO1xuXG4gIHB1YmxpYyB1bmxpc3RlbmVyczogUmVjb3JkPHN0cmluZywgKCkgPT4gdm9pZD4gPSB7fTtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjIsXG4gICAgcHJpdmF0ZSBlbGVtZW50UmVmOiBFbGVtZW50UmVmLFxuICAgIEBJbmplY3QoRE9DVU1FTlQpIHByaXZhdGUgZG9jdW1lbnQ6IERvY3VtZW50LFxuICAgIHByaXZhdGUgZGVzdHJveVJlZjogRGVzdHJveVJlZlxuICApIHtcbiAgICAvLyBDaGVjayBpZiBwYXNzaXZlIGlzIHN1cHBvcnRlZFxuXG4gICAgdHJ5IHtcbiAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFxuICAgICAgICAndGVzdCcsXG4gICAgICAgIG51bGwgYXMgYW55LFxuICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoe30sICdwYXNzaXZlJywge1xuICAgICAgICAgIGdldDogKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy4jaXNQYXNzaXZlU3VwcG9ydGVkID0geyBwYXNzaXZlOiB0cnVlIH07XG4gICAgICAgICAgfSxcbiAgICAgICAgfSlcbiAgICAgICk7XG4gICAgfSBjYXRjaCAoZXJyKSB7fVxuICB9XG5cbiAgcHVibGljIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKFxuICAgICAgdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQsXG4gICAgICAndXNlci1nZXN0dXJlcycsXG4gICAgICAnbm9uZSdcbiAgICApO1xuICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUoXG4gICAgICB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCxcbiAgICAgICd0b3VjaC1hY3Rpb24nLFxuICAgICAgJ25vbmUnXG4gICAgKTtcbiAgICB0aGlzLnVubGlzdGVuZXJzWyd0b3VjaHN0YXJ0J10gPSB0aGlzLnJlbmRlcmVyLmxpc3RlbihcbiAgICAgIHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LFxuICAgICAgJ3RvdWNoc3RhcnQnLFxuICAgICAgdGhpcy5vblRvdWNoU3RhcnQuYmluZCh0aGlzKVxuICAgICk7XG4gICAgdGhpcy51bmxpc3RlbmVyc1sndG91Y2htb3ZlJ10gPSB0aGlzLnJlbmRlcmVyLmxpc3RlbihcbiAgICAgIHRoaXMuZG9jdW1lbnQuYm9keSxcbiAgICAgICd0b3VjaG1vdmUnLFxuICAgICAgdGhpcy5vblRvdWNoTW92ZS5iaW5kKHRoaXMpXG4gICAgKTtcbiAgICB0aGlzLnVubGlzdGVuZXJzWyd0b3VjaGVuZCddID0gdGhpcy5yZW5kZXJlci5saXN0ZW4oXG4gICAgICB0aGlzLmRvY3VtZW50LmJvZHksXG4gICAgICAndG91Y2hlbmQnLFxuICAgICAgdGhpcy5vblRvdWNoRW5kLmJpbmQodGhpcylcbiAgICApO1xuXG4gICAgdGhpcy51bmxpc3RlbmVyc1snbW91c2Vkb3duJ10gPSB0aGlzLnJlbmRlcmVyLmxpc3RlbihcbiAgICAgIHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LFxuICAgICAgJ21vdXNlZG93bicsXG4gICAgICB0aGlzLm9uVG91Y2hTdGFydC5iaW5kKHRoaXMpXG4gICAgKTtcbiAgICB0aGlzLnVubGlzdGVuZXJzWydtb3VzZW1vdmUnXSA9IHRoaXMucmVuZGVyZXIubGlzdGVuKFxuICAgICAgdGhpcy5kb2N1bWVudC5ib2R5LFxuICAgICAgJ21vdXNlbW92ZScsXG4gICAgICB0aGlzLm9uVG91Y2hNb3ZlLmJpbmQodGhpcylcbiAgICApO1xuICAgIHRoaXMudW5saXN0ZW5lcnNbJ21vdXNldXAnXSA9IHRoaXMucmVuZGVyZXIubGlzdGVuKFxuICAgICAgdGhpcy5kb2N1bWVudC5ib2R5LFxuICAgICAgJ21vdXNldXAnLFxuICAgICAgdGhpcy5vblRvdWNoRW5kLmJpbmQodGhpcylcbiAgICApO1xuICAgIHRoaXMuZGVzdHJveVJlZi5vbkRlc3Ryb3koKCkgPT4ge1xuICAgICAgZm9yIChsZXQgdW5saXN0ZW5lciBvZiBPYmplY3QudmFsdWVzKHRoaXMudW5saXN0ZW5lcnMpKSB7XG4gICAgICAgIHVubGlzdGVuZXIoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIG5nT25EZXN0cm95KCkge1xuICAgIGNsZWFyVGltZW91dCh0aGlzLmxvbmdQcmVzc1RpbWVyID8/IHVuZGVmaW5lZCk7XG4gICAgY2xlYXJUaW1lb3V0KHRoaXMuZG91YmxlVGFwVGltZXIgPz8gdW5kZWZpbmVkKTtcbiAgICBmb3IgKGxldCB1bmxpc3RlbmVyIG9mIE9iamVjdC52YWx1ZXModGhpcy51bmxpc3RlbmVycykpIHtcbiAgICAgIHVubGlzdGVuZXIoKTtcbiAgICB9XG4gIH1cblxuICBvblRvdWNoU3RhcnQoZXZlbnQ6IE1vdXNlRXZlbnQgfCBUb3VjaEV2ZW50KSB7XG4gICAgaWYgKHRoaXMuI2NvbWJpbmVkT3B0aW9ucy5kaXNhYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLnRvdWNoU3RhcnRYID1cbiAgICAgIGV2ZW50LnR5cGUgPT09ICdtb3VzZWRvd24nXG4gICAgICAgID8gKGV2ZW50IGFzIE1vdXNlRXZlbnQpLnNjcmVlblhcbiAgICAgICAgOiAoZXZlbnQgYXMgVG91Y2hFdmVudCkuY2hhbmdlZFRvdWNoZXNbMF0uc2NyZWVuWDtcbiAgICB0aGlzLnRvdWNoU3RhcnRZID1cbiAgICAgIGV2ZW50LnR5cGUgPT09ICdtb3VzZWRvd24nXG4gICAgICAgID8gKGV2ZW50IGFzIE1vdXNlRXZlbnQpLnNjcmVlbllcbiAgICAgICAgOiAoZXZlbnQgYXMgVG91Y2hFdmVudCkuY2hhbmdlZFRvdWNoZXNbMF0uc2NyZWVuWTtcbiAgICB0aGlzLnRvdWNoTW92ZVggPSBudWxsO1xuICAgIHRoaXMudG91Y2hNb3ZlWSA9IG51bGw7XG4gICAgdGhpcy50b3VjaEVuZFggPSBudWxsO1xuICAgIHRoaXMudG91Y2hFbmRZID0gbnVsbDtcbiAgICB0aGlzLnN3aXBpbmdEaXJlY3Rpb24gPSBudWxsO1xuICAgIC8vIExvbmcgcHJlc3MuXG4gICAgaWYgKHRoaXMuI2NvbWJpbmVkT3B0aW9ucy5sb25nUHJlc3MpIHtcbiAgICAgIHRoaXMuI2xvbmdQcmVzc1RpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIGlmICh0aGlzLiNjb21iaW5lZE9wdGlvbnMubG9uZ1ByZXNzKSB7XG4gICAgICAgICAgdGhpcy4jY29tYmluZWRPcHRpb25zLmxvbmdQcmVzcy5vbkxvbmdQcmVzcyhldmVudCk7XG4gICAgICAgIH1cbiAgICAgIH0sIHRoaXMuI2NvbWJpbmVkT3B0aW9ucy5sb25nUHJlc3MudGltZSk7XG4gICAgfVxuICB9XG5cbiAgb25Ub3VjaE1vdmUoZXZlbnQ6IE1vdXNlRXZlbnQgfCBUb3VjaEV2ZW50KSB7XG4gICAgaWYgKHRoaXMuI2NvbWJpbmVkT3B0aW9ucy5kaXNhYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoXG4gICAgICBldmVudC50eXBlID09PSAnbW91c2Vtb3ZlJyAmJlxuICAgICAgKCF0aGlzLnRvdWNoU3RhcnRYIHx8IHRoaXMudG91Y2hFbmRYICE9PSBudWxsKVxuICAgICkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCB0b3VjaE1vdmVYID1cbiAgICAgIChldmVudC50eXBlID09PSAnbW91c2Vtb3ZlJ1xuICAgICAgICA/IChldmVudCBhcyBNb3VzZUV2ZW50KS5zY3JlZW5YXG4gICAgICAgIDogKGV2ZW50IGFzIFRvdWNoRXZlbnQpLmNoYW5nZWRUb3VjaGVzWzBdLnNjcmVlblgpIC1cbiAgICAgICh0aGlzLnRvdWNoU3RhcnRYID8/IDApO1xuICAgIHRoaXMudmVsb2NpdHlYID0gdG91Y2hNb3ZlWCAtICh0aGlzLnRvdWNoTW92ZVggPz8gMCk7XG4gICAgdGhpcy50b3VjaE1vdmVYID0gdG91Y2hNb3ZlWDtcbiAgICBjb25zdCB0b3VjaE1vdmVZID1cbiAgICAgIChldmVudC50eXBlID09PSAnbW91c2Vtb3ZlJ1xuICAgICAgICA/IChldmVudCBhcyBNb3VzZUV2ZW50KS5zY3JlZW5ZXG4gICAgICAgIDogKGV2ZW50IGFzIFRvdWNoRXZlbnQpLmNoYW5nZWRUb3VjaGVzWzBdLnNjcmVlblkpIC1cbiAgICAgICh0aGlzLnRvdWNoU3RhcnRZID8/IDApO1xuICAgIHRoaXMudmVsb2NpdHlZID0gdG91Y2hNb3ZlWSAtICh0aGlzLnRvdWNoTW92ZVkgPz8gMCk7XG4gICAgdGhpcy50b3VjaE1vdmVZID0gdG91Y2hNb3ZlWTtcbiAgICBjb25zdCBhYnNUb3VjaE1vdmVYID0gTWF0aC5hYnModGhpcy50b3VjaE1vdmVYKTtcbiAgICBjb25zdCBhYnNUb3VjaE1vdmVZID0gTWF0aC5hYnModGhpcy50b3VjaE1vdmVZKTtcbiAgICB0aGlzLnN3aXBpbmdIb3Jpem9udGFsID0gdGhpcy4jY29tYmluZWRPcHRpb25zLnN3aXBlXG4gICAgICA/IGFic1RvdWNoTW92ZVggPiB0aGlzLiNjb21iaW5lZE9wdGlvbnMuc3dpcGUucmVxdWlyZWRTd2lwZURpc3RhbmNlXG4gICAgICA6IGZhbHNlO1xuICAgIHRoaXMuc3dpcGluZ1ZlcnRpY2FsID0gdGhpcy4jY29tYmluZWRPcHRpb25zLnN3aXBlXG4gICAgICA/IGFic1RvdWNoTW92ZVkgPiB0aGlzLiNjb21iaW5lZE9wdGlvbnMuc3dpcGUucmVxdWlyZWRTd2lwZURpc3RhbmNlXG4gICAgICA6IGZhbHNlO1xuICAgIGlmICh0aGlzLiNjb21iaW5lZE9wdGlvbnMubG9uZ1ByZXNzKSB7XG4gICAgICBpZiAoXG4gICAgICAgIE1hdGgubWF4KGFic1RvdWNoTW92ZVgsIGFic1RvdWNoTW92ZVkpID5cbiAgICAgICAgdGhpcy4jY29tYmluZWRPcHRpb25zLmxvbmdQcmVzcy5wcmVzc1RocmVzaG9sZFxuICAgICAgKSB7XG4gICAgICAgIGNsZWFyVGltZW91dCh0aGlzLmxvbmdQcmVzc1RpbWVyID8/IHVuZGVmaW5lZCk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgb25Ub3VjaEVuZChldmVudDogTW91c2VFdmVudCB8IFRvdWNoRXZlbnQpIHtcbiAgICBpZiAoXG4gICAgICB0aGlzLiNjb21iaW5lZE9wdGlvbnMuZGlzYWJsZWQgfHxcbiAgICAgICF0aGlzLnRvdWNoU3RhcnRYIHx8XG4gICAgICAhdGhpcy50b3VjaFN0YXJ0WSB8fFxuICAgICAgIXRoaXMudG91Y2hNb3ZlWCB8fFxuICAgICAgIXRoaXMudG91Y2hNb3ZlWVxuICAgICkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoXG4gICAgICBldmVudC50eXBlID09PSAnbW91c2V1cCcgJiZcbiAgICAgICghdGhpcy50b3VjaFN0YXJ0WCB8fCB0aGlzLnRvdWNoRW5kWCAhPT0gbnVsbClcbiAgICApIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy50b3VjaEVuZFggPVxuICAgICAgZXZlbnQudHlwZSA9PT0gJ21vdXNldXAnXG4gICAgICAgID8gKGV2ZW50IGFzIE1vdXNlRXZlbnQpLnNjcmVlblhcbiAgICAgICAgOiAoZXZlbnQgYXMgVG91Y2hFdmVudCkuY2hhbmdlZFRvdWNoZXNbMF0uc2NyZWVuWDtcbiAgICB0aGlzLnRvdWNoRW5kWSA9XG4gICAgICBldmVudC50eXBlID09PSAnbW91c2V1cCdcbiAgICAgICAgPyAoZXZlbnQgYXMgTW91c2VFdmVudCkuc2NyZWVuWVxuICAgICAgICA6IChldmVudCBhcyBUb3VjaEV2ZW50KS5jaGFuZ2VkVG91Y2hlc1swXS5zY3JlZW5ZO1xuICAgIGNsZWFyVGltZW91dCh0aGlzLmxvbmdQcmVzc1RpbWVyID8/IHVuZGVmaW5lZCk7XG4gICAgY29uc3QgeCA9IHRoaXMudG91Y2hFbmRYIC0gKHRoaXMudG91Y2hTdGFydFggPz8gMCk7XG4gICAgY29uc3QgYWJzWCA9IE1hdGguYWJzKHgpO1xuICAgIGNvbnN0IHkgPSB0aGlzLnRvdWNoRW5kWSAtICh0aGlzLnRvdWNoU3RhcnRZID8/IDApO1xuICAgIGNvbnN0IGFic1kgPSBNYXRoLmFicyh5KTtcbiAgICBpZiAodGhpcy4jY29tYmluZWRPcHRpb25zLnN3aXBlKSB7XG4gICAgICBpZiAoXG4gICAgICAgIGFic1ggPiB0aGlzLiNjb21iaW5lZE9wdGlvbnMuc3dpcGUucmVxdWlyZWRTd2lwZURpc3RhbmNlIHx8XG4gICAgICAgIGFic1kgPiB0aGlzLiNjb21iaW5lZE9wdGlvbnMuc3dpcGUucmVxdWlyZWRTd2lwZURpc3RhbmNlXG4gICAgICApIHtcbiAgICAgICAgdGhpcy5zd2lwZWRIb3Jpem9udGFsID0gdGhpcy4jY29tYmluZWRPcHRpb25zLnN3aXBlLmhhc0RpYWdvbmFsU3dpcGVzXG4gICAgICAgICAgPyBNYXRoLmFicyh4IC8geSkgPD0gdGhpcy4jY29tYmluZWRPcHRpb25zLnN3aXBlLmRpYWdvbmFsTGltaXRcbiAgICAgICAgICA6IGFic1ggPj0gYWJzWSAmJlxuICAgICAgICAgICAgYWJzWCA+IHRoaXMuI2NvbWJpbmVkT3B0aW9ucy5zd2lwZS5yZXF1aXJlZFN3aXBlRGlzdGFuY2U7XG4gICAgICAgIHRoaXMuc3dpcGVkVmVydGljYWwgPSB0aGlzLiNjb21iaW5lZE9wdGlvbnMuc3dpcGUuaGFzRGlhZ29uYWxTd2lwZXNcbiAgICAgICAgICA/IE1hdGguYWJzKHkgLyB4KSA8PSB0aGlzLiNjb21iaW5lZE9wdGlvbnMuc3dpcGUuZGlhZ29uYWxMaW1pdFxuICAgICAgICAgIDogYWJzWSA+IGFic1ggJiZcbiAgICAgICAgICAgIGFic1kgPiB0aGlzLiNjb21iaW5lZE9wdGlvbnMuc3dpcGUucmVxdWlyZWRTd2lwZURpc3RhbmNlO1xuICAgICAgICBpZiAodGhpcy5zd2lwZWRIb3Jpem9udGFsKSB7XG4gICAgICAgICAgaWYgKHggPCAwKSB7XG4gICAgICAgICAgICAvLyBMZWZ0IHN3aXBlLlxuICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAodGhpcy52ZWxvY2l0eVggPz8gMCkgPFxuICAgICAgICAgICAgICAgIC10aGlzLiNjb21iaW5lZE9wdGlvbnMuc3dpcGUudmVsb2NpdHlUaHJlc2hvbGQgfHxcbiAgICAgICAgICAgICAgeCA8IC10aGlzLiNjb21iaW5lZE9wdGlvbnMuc3dpcGUuZGlzdGFuY2VUb0Rpc3JlZ2FyZFZlbG9jaXR5XG4gICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgdGhpcy4jY29tYmluZWRPcHRpb25zLnN3aXBlLm9uU3dpcGUoe1xuICAgICAgICAgICAgICAgIHR5cGU6ICdsZWZ0JyxcbiAgICAgICAgICAgICAgICB2ZWxvY2l0eVg6IHRoaXMudmVsb2NpdHlYLFxuICAgICAgICAgICAgICAgIHZlbG9jaXR5WTogdGhpcy52ZWxvY2l0eVksXG4gICAgICAgICAgICAgICAgZGlzdGFuY2VYOiBhYnNYLFxuICAgICAgICAgICAgICAgIGRpc3RhbmNlWTogYWJzWSxcbiAgICAgICAgICAgICAgICBldmVudCxcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIC8vIFJpZ2h0IHN3aXBlLlxuICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgICAodGhpcy52ZWxvY2l0eVggPz8gMCkgPlxuICAgICAgICAgICAgICAgIHRoaXMuI2NvbWJpbmVkT3B0aW9ucy5zd2lwZS52ZWxvY2l0eVRocmVzaG9sZCB8fFxuICAgICAgICAgICAgICB4ID4gdGhpcy4jY29tYmluZWRPcHRpb25zLnN3aXBlLmRpc3RhbmNlVG9EaXNyZWdhcmRWZWxvY2l0eVxuICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgIHRoaXMuI2NvbWJpbmVkT3B0aW9ucy5zd2lwZS5vblN3aXBlKHtcbiAgICAgICAgICAgICAgICB0eXBlOiAncmlnaHQnLFxuICAgICAgICAgICAgICAgIHZlbG9jaXR5WDogdGhpcy52ZWxvY2l0eVgsXG4gICAgICAgICAgICAgICAgdmVsb2NpdHlZOiB0aGlzLnZlbG9jaXR5WSxcbiAgICAgICAgICAgICAgICBkaXN0YW5jZVg6IGFic1gsXG4gICAgICAgICAgICAgICAgZGlzdGFuY2VZOiBhYnNZLFxuICAgICAgICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuc3dpcGVkVmVydGljYWwpIHtcbiAgICAgICAgICBpZiAoeSA8IDApIHtcbiAgICAgICAgICAgIC8vIFVwd2FyZCBzd2lwZS5cbiAgICAgICAgICAgIGlmIChcbiAgICAgICAgICAgICAgKHRoaXMudmVsb2NpdHlZID8/IDApIDxcbiAgICAgICAgICAgICAgICAtdGhpcy4jY29tYmluZWRPcHRpb25zLnN3aXBlLnZlbG9jaXR5VGhyZXNob2xkIHx8XG4gICAgICAgICAgICAgIHkgPCAtdGhpcy4jY29tYmluZWRPcHRpb25zLnN3aXBlLmRpc3RhbmNlVG9EaXNyZWdhcmRWZWxvY2l0eVxuICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgIHRoaXMuI2NvbWJpbmVkT3B0aW9ucy5zd2lwZS5vblN3aXBlKHtcbiAgICAgICAgICAgICAgICB0eXBlOiAndXAnLFxuICAgICAgICAgICAgICAgIHZlbG9jaXR5WDogdGhpcy52ZWxvY2l0eVgsXG4gICAgICAgICAgICAgICAgdmVsb2NpdHlZOiB0aGlzLnZlbG9jaXR5WSxcbiAgICAgICAgICAgICAgICBkaXN0YW5jZVg6IGFic1gsXG4gICAgICAgICAgICAgICAgZGlzdGFuY2VZOiBhYnNZLFxuICAgICAgICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gRG93bndhcmQgc3dpcGUuXG4gICAgICAgICAgICBpZiAoXG4gICAgICAgICAgICAgICh0aGlzLnZlbG9jaXR5WSA/PyAwKSA+XG4gICAgICAgICAgICAgICAgdGhpcy4jY29tYmluZWRPcHRpb25zLnN3aXBlLnZlbG9jaXR5VGhyZXNob2xkIHx8XG4gICAgICAgICAgICAgIHkgPiB0aGlzLiNjb21iaW5lZE9wdGlvbnMuc3dpcGUuZGlzdGFuY2VUb0Rpc3JlZ2FyZFZlbG9jaXR5XG4gICAgICAgICAgICApIHtcbiAgICAgICAgICAgICAgdGhpcy4jY29tYmluZWRPcHRpb25zLnN3aXBlLm9uU3dpcGUoe1xuICAgICAgICAgICAgICAgIHR5cGU6ICdkb3duJyxcbiAgICAgICAgICAgICAgICB2ZWxvY2l0eVg6IHRoaXMudmVsb2NpdHlYLFxuICAgICAgICAgICAgICAgIHZlbG9jaXR5WTogdGhpcy52ZWxvY2l0eVksXG4gICAgICAgICAgICAgICAgZGlzdGFuY2VYOiBhYnNYLFxuICAgICAgICAgICAgICAgIGRpc3RhbmNlWTogYWJzWSxcbiAgICAgICAgICAgICAgICBldmVudCxcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICAgIGlmICh0aGlzLiNjb21iaW5lZE9wdGlvbnMuZG91YmxlVGFwKSB7XG4gICAgICBpZiAodGhpcy5kb3VibGVUYXBXYWl0aW5nKSB7XG4gICAgICAgIHRoaXMuZG91YmxlVGFwV2FpdGluZyA9IGZhbHNlO1xuICAgICAgICBjbGVhclRpbWVvdXQodGhpcy5kb3VibGVUYXBUaW1lciA/PyB1bmRlZmluZWQpO1xuICAgICAgICB0aGlzLiNjb21iaW5lZE9wdGlvbnMuZG91YmxlVGFwLm9uRG91YmxlVGFwKGV2ZW50KTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuZG91YmxlVGFwV2FpdGluZyA9IHRydWU7XG4gICAgICAgIHRoaXMuZG91YmxlVGFwVGltZXIgPSBzZXRUaW1lb3V0KFxuICAgICAgICAgICgpID0+ICh0aGlzLmRvdWJsZVRhcFdhaXRpbmcgPSBmYWxzZSksXG4gICAgICAgICAgdGhpcy4jY29tYmluZWRPcHRpb25zLmRvdWJsZVRhcC50aW1lXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgdGhpcy50b3VjaFN0YXJ0WCA9IG51bGw7XG4gICAgdGhpcy50b3VjaFN0YXJ0WSA9IG51bGw7XG4gICAgdGhpcy50b3VjaE1vdmVYID0gbnVsbDtcbiAgICB0aGlzLnRvdWNoTW92ZVkgPSBudWxsO1xuICB9XG59XG4iXX0=