import { Component, Input, ViewChild, } from '@angular/core';
import { GUID } from 'orbital-ui/helpers';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NgClass, NgTemplateOutlet } from '@angular/common';
import * as i0 from "@angular/core";
import * as i1 from "./tabs.service";
import * as i2 from "@angular/router";
export class OuiTabComponent {
    tabService;
    elementRef;
    cdr;
    destroyRef;
    router;
    titleTemplate;
    tabContentTemplate;
    title;
    tabTitleTemplate;
    parentId;
    id = GUID();
    disabled = false;
    isActive = false;
    options;
    constructor(tabService, elementRef, cdr, destroyRef, router) {
        this.tabService = tabService;
        this.elementRef = elementRef;
        this.cdr = cdr;
        this.destroyRef = destroyRef;
        this.router = router;
    }
    ngAfterViewInit() {
        this.tabService.tabSelected$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(tab => {
            this.isActive = tab.id === this.id;
            this.cdr.detectChanges();
        });
    }
    setOptions(options) {
        this.options = options;
        this.cdr.detectChanges();
    }
    selectTab() {
        this.tabService.selectTab(this);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTabComponent, deps: [{ token: i1.OuiTabsService }, { token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i0.DestroyRef }, { token: i2.Router }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiTabComponent, isStandalone: true, selector: "oui-tab", inputs: { title: "title", tabTitleTemplate: "tabTitleTemplate", parentId: "parentId", id: "id", disabled: "disabled" }, viewQueries: [{ propertyName: "titleTemplate", first: true, predicate: ["titleTemplate"], descendants: true }, { propertyName: "tabContentTemplate", first: true, predicate: ["tabContentTemplate"], descendants: true }], ngImport: i0, template: ` <div
        class="tab-title {{ options?.variant }}"
        [ngClass]="{ active: isActive, disabled: disabled }"
        (click)="selectTab()"
        >
        @if (tabTitleTemplate) {
          <ng-container
            [ngTemplateOutlet]="tabTitleTemplate"
            >
          </ng-container>
        }
        @if (!tabTitleTemplate) {
          <span>
            {{ title }}
          </span>
        }
      </div>
      <ng-template #tabContentTemplate>
        <ng-content></ng-content>
      </ng-template>`, isInline: true, styles: [":host{min-width:var(--oui-tab-width);min-height:var(--oui-tab-height);width:var(--oui-tab-width);height:var(--oui-tab-height);display:flex;align-items:center;background-color:transparent;position:relative}:host .tab-title{width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:var(--oui-tab-text-color);transition:color .3s;border-radius:var(--oui-tab-border-radius)}:host .tab-title:hover{cursor:pointer;background-color:var(--oui-tab-background-color-hover)}:host .tab-title.disabled{opacity:.7;pointer-events:none}:host .tab-title.active{color:var(--oui-tab-text-color-active)}:host .tab-title:hover{color:var(--oui-tab-text-color-hover)}:host .tab-title.bordered{border:1px solid #ccc;padding:1rem}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTabComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-tab', template: ` <div
        class="tab-title {{ options?.variant }}"
        [ngClass]="{ active: isActive, disabled: disabled }"
        (click)="selectTab()"
        >
        @if (tabTitleTemplate) {
          <ng-container
            [ngTemplateOutlet]="tabTitleTemplate"
            >
          </ng-container>
        }
        @if (!tabTitleTemplate) {
          <span>
            {{ title }}
          </span>
        }
      </div>
      <ng-template #tabContentTemplate>
        <ng-content></ng-content>
      </ng-template>`, standalone: true, imports: [NgClass, NgTemplateOutlet], styles: [":host{min-width:var(--oui-tab-width);min-height:var(--oui-tab-height);width:var(--oui-tab-width);height:var(--oui-tab-height);display:flex;align-items:center;background-color:transparent;position:relative}:host .tab-title{width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:var(--oui-tab-text-color);transition:color .3s;border-radius:var(--oui-tab-border-radius)}:host .tab-title:hover{cursor:pointer;background-color:var(--oui-tab-background-color-hover)}:host .tab-title.disabled{opacity:.7;pointer-events:none}:host .tab-title.active{color:var(--oui-tab-text-color-active)}:host .tab-title:hover{color:var(--oui-tab-text-color-hover)}:host .tab-title.bordered{border:1px solid #ccc;padding:1rem}\n"] }]
        }], ctorParameters: () => [{ type: i1.OuiTabsService }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i0.DestroyRef }, { type: i2.Router }], propDecorators: { titleTemplate: [{
                type: ViewChild,
                args: ['titleTemplate']
            }], tabContentTemplate: [{
                type: ViewChild,
                args: ['tabContentTemplate']
            }], title: [{
                type: Input
            }], tabTitleTemplate: [{
                type: Input
            }], parentId: [{
                type: Input
            }], id: [{
                type: Input
            }], disabled: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGFiLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvdGFicy90YWIuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFHTCxTQUFTLEVBR1QsS0FBSyxFQUVMLFNBQVMsR0FDVixNQUFNLGVBQWUsQ0FBQztBQUd2QixPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDMUMsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDaEUsT0FBTyxFQUFFLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGlCQUFpQixDQUFDOzs7O0FBNkI1RCxNQUFNLE9BQU8sZUFBZTtJQWFoQjtJQUNEO0lBQ0M7SUFDQTtJQUNBO0lBaEJrQixhQUFhLENBQW1CO0lBQzNCLGtCQUFrQixDQUFtQjtJQUM3RCxLQUFLLENBQVM7SUFDZCxnQkFBZ0IsQ0FBbUI7SUFDbkMsUUFBUSxDQUFTO0lBQ2pCLEVBQUUsR0FBRyxJQUFJLEVBQUUsQ0FBQztJQUNaLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFFbkIsUUFBUSxHQUFHLEtBQUssQ0FBQztJQUNqQixPQUFPLENBQXVCO0lBRXJDLFlBQ1UsVUFBMEIsRUFDM0IsVUFBc0IsRUFDckIsR0FBc0IsRUFDdEIsVUFBc0IsRUFDdEIsTUFBYztRQUpkLGVBQVUsR0FBVixVQUFVLENBQWdCO1FBQzNCLGVBQVUsR0FBVixVQUFVLENBQVk7UUFDckIsUUFBRyxHQUFILEdBQUcsQ0FBbUI7UUFDdEIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtRQUN0QixXQUFNLEdBQU4sTUFBTSxDQUFRO0lBQ3JCLENBQUM7SUFFRyxlQUFlO1FBQ3BCLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWTthQUN6QixJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ3pDLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNmLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDLEVBQUUsS0FBSyxJQUFJLENBQUMsRUFBRSxDQUFDO1lBQ25DLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDM0IsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU0sVUFBVSxDQUFDLE9BQXNCO1FBQ3RDLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVNLFNBQVM7UUFDZCxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNsQyxDQUFDO3VHQXBDVSxlQUFlOzJGQUFmLGVBQWUsc1pBeEJoQjs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkFtQlMsdXlCQUdULE9BQU8sb0ZBQUUsZ0JBQWdCOzsyRkFFeEIsZUFBZTtrQkExQjNCLFNBQVM7K0JBQ0UsU0FBUyxZQUNUOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O3FCQW1CUyxjQUVQLElBQUksV0FDUCxDQUFDLE9BQU8sRUFBRSxnQkFBZ0IsQ0FBQzswTEFHUixhQUFhO3NCQUF4QyxTQUFTO3VCQUFDLGVBQWU7Z0JBQ08sa0JBQWtCO3NCQUFsRCxTQUFTO3VCQUFDLG9CQUFvQjtnQkFDdEIsS0FBSztzQkFBYixLQUFLO2dCQUNHLGdCQUFnQjtzQkFBeEIsS0FBSztnQkFDRyxRQUFRO3NCQUFoQixLQUFLO2dCQUNHLEVBQUU7c0JBQVYsS0FBSztnQkFDRyxRQUFRO3NCQUFoQixLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgQ2hhbmdlRGV0ZWN0b3JSZWYsXG4gIENvbXBvbmVudCxcbiAgRGVzdHJveVJlZixcbiAgRWxlbWVudFJlZixcbiAgSW5wdXQsXG4gIFRlbXBsYXRlUmVmLFxuICBWaWV3Q2hpbGQsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgT3VpVGFic1NlcnZpY2UgfSBmcm9tICcuL3RhYnMuc2VydmljZSc7XG5pbXBvcnQgeyBPdWlUYWJPcHRpb25zIH0gZnJvbSAnLi90YWJzLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBHVUlEIH0gZnJvbSAnb3JiaXRhbC11aS9oZWxwZXJzJztcbmltcG9ydCB7IHRha2VVbnRpbERlc3Ryb3llZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUvcnhqcy1pbnRlcm9wJztcbmltcG9ydCB7IE5nQ2xhc3MsIE5nVGVtcGxhdGVPdXRsZXQgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgUm91dGVyIH0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLXRhYicsXG4gIHRlbXBsYXRlOiBgIDxkaXZcbiAgICAgICAgY2xhc3M9XCJ0YWItdGl0bGUge3sgb3B0aW9ucz8udmFyaWFudCB9fVwiXG4gICAgICAgIFtuZ0NsYXNzXT1cInsgYWN0aXZlOiBpc0FjdGl2ZSwgZGlzYWJsZWQ6IGRpc2FibGVkIH1cIlxuICAgICAgICAoY2xpY2spPVwic2VsZWN0VGFiKClcIlxuICAgICAgICA+XG4gICAgICAgIEBpZiAodGFiVGl0bGVUZW1wbGF0ZSkge1xuICAgICAgICAgIDxuZy1jb250YWluZXJcbiAgICAgICAgICAgIFtuZ1RlbXBsYXRlT3V0bGV0XT1cInRhYlRpdGxlVGVtcGxhdGVcIlxuICAgICAgICAgICAgPlxuICAgICAgICAgIDwvbmctY29udGFpbmVyPlxuICAgICAgICB9XG4gICAgICAgIEBpZiAoIXRhYlRpdGxlVGVtcGxhdGUpIHtcbiAgICAgICAgICA8c3Bhbj5cbiAgICAgICAgICAgIHt7IHRpdGxlIH19XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICB9XG4gICAgICA8L2Rpdj5cbiAgICAgIDxuZy10ZW1wbGF0ZSAjdGFiQ29udGVudFRlbXBsYXRlPlxuICAgICAgICA8bmctY29udGVudD48L25nLWNvbnRlbnQ+XG4gICAgICA8L25nLXRlbXBsYXRlPmAsXG4gIHN0eWxlVXJsczogWycuL3RhYi5jb21wb25lbnQuc2NzcyddLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbTmdDbGFzcywgTmdUZW1wbGF0ZU91dGxldF0sXG59KVxuZXhwb3J0IGNsYXNzIE91aVRhYkNvbXBvbmVudCBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQge1xuICBAVmlld0NoaWxkKCd0aXRsZVRlbXBsYXRlJykgdGl0bGVUZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PjtcbiAgQFZpZXdDaGlsZCgndGFiQ29udGVudFRlbXBsYXRlJykgdGFiQ29udGVudFRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xuICBASW5wdXQoKSB0aXRsZTogc3RyaW5nO1xuICBASW5wdXQoKSB0YWJUaXRsZVRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xuICBASW5wdXQoKSBwYXJlbnRJZDogc3RyaW5nO1xuICBASW5wdXQoKSBpZCA9IEdVSUQoKTtcbiAgQElucHV0KCkgZGlzYWJsZWQgPSBmYWxzZTtcblxuICBwdWJsaWMgaXNBY3RpdmUgPSBmYWxzZTtcbiAgcHVibGljIG9wdGlvbnM6IE91aVRhYk9wdGlvbnMgfCBudWxsO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgdGFiU2VydmljZTogT3VpVGFic1NlcnZpY2UsXG4gICAgcHVibGljIGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsXG4gICAgcHJpdmF0ZSBjZHI6IENoYW5nZURldGVjdG9yUmVmLFxuICAgIHByaXZhdGUgZGVzdHJveVJlZjogRGVzdHJveVJlZixcbiAgICBwcml2YXRlIHJvdXRlcjogUm91dGVyXG4gICkge31cblxuICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCkge1xuICAgIHRoaXMudGFiU2VydmljZS50YWJTZWxlY3RlZCRcbiAgICAgIC5waXBlKHRha2VVbnRpbERlc3Ryb3llZCh0aGlzLmRlc3Ryb3lSZWYpKVxuICAgICAgLnN1YnNjcmliZSh0YWIgPT4ge1xuICAgICAgICB0aGlzLmlzQWN0aXZlID0gdGFiLmlkID09PSB0aGlzLmlkO1xuICAgICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICB9KTtcbiAgfVxuXG4gIHB1YmxpYyBzZXRPcHRpb25zKG9wdGlvbnM6IE91aVRhYk9wdGlvbnMpIHtcbiAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcbiAgfVxuXG4gIHB1YmxpYyBzZWxlY3RUYWIoKSB7XG4gICAgdGhpcy50YWJTZXJ2aWNlLnNlbGVjdFRhYih0aGlzKTtcbiAgfVxufVxuIl19