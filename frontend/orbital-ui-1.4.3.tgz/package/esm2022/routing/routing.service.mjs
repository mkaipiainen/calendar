import { inject, Injectable } from '@angular/core';
import { NavigationEnd, NavigationStart, Router, } from '@angular/router';
import { buffer, debounceTime, map, ReplaySubject, Subject, } from 'rxjs';
import { isEqual, merge } from 'lodash-es';
import * as i0 from "@angular/core";
export class OuiRoutingService {
    router = inject(Router);
    previousPath;
    routeHistory = [];
    navigationStartSubject = new Subject();
    queryParamsSubject = new ReplaySubject(1);
    bufferedNavigationSubject = new Subject();
    bufferedNavigationTrigger$ = this.bufferedNavigationSubject
        .asObservable()
        .pipe(buffer(this.bufferedNavigationSubject.asObservable().pipe(debounceTime(300))), map(navigationEvents => {
        return navigationEvents.reduce((acc, curr) => {
            if (isEqual(curr.commands, acc.commands)) {
                const mergedQueryParams = merge({
                    ...acc.extras.queryParams,
                    ...curr.extras.queryParams,
                });
                const mergedExtras = merge({ ...acc.extras }, { ...curr.extras }, { queryParams: mergedQueryParams });
                return merge({
                    ...acc,
                    ...{ commands: curr.commands, extras: mergedExtras },
                });
            }
            else {
                return curr;
            }
        }, { commands: [], extras: {} });
    }));
    routeHistorySubject = new Subject();
    navigationStart$ = this.navigationStartSubject.asObservable();
    routeHistory$ = this.routeHistorySubject.asObservable();
    queryParams$ = this.router.routerState.root.queryParams;
    constructor() {
        this.bufferedNavigationTrigger$.subscribe(({ commands, extras }) => {
            this.router.navigate(commands, extras ?? {});
        });
        this.router.events.subscribe(event => {
            if (event instanceof NavigationStart) {
                const currentPath = this.getUrlWithoutParams(event.url);
                this.navigationStartSubject.next({
                    currentUrl: currentPath,
                    previousUrl: this.previousPath,
                    event,
                });
            }
            else if (event instanceof NavigationEnd) {
                this.previousPath = this.getUrlWithoutParams(event.url);
                this.routeHistory = [...this.routeHistory, event.url];
                this.routeHistorySubject.next(this.routeHistory);
            }
        });
    }
    getUrlWithoutParams(url) {
        const urlTree = this.router.parseUrl(url);
        const primaryChildren = urlTree.root.children['primary'];
        return primaryChildren
            ? primaryChildren.segments.map(it => it.path).join('/')
            : urlTree.root.segments.map(it => it.path).join('/');
    }
    /**
     * Sometimes we want to navigate to the same route repeatedly and add different query params
     * (for example when initialising filters). This allows us to do that without triggering
     * navigation for each query param change (which can lead to navigationEnd never triggering in angular).
     * This method collects all the changed query params and merges them together, finally navigating to the
     * target route with all the query params (after 300 ms)
     * @param commands
     * @param extras
     */
    bufferedNavigate(commands, extras) {
        this.bufferedNavigationSubject.next({ commands, extras });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiRoutingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiRoutingService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiRoutingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicm91dGluZy5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9yb3V0aW5nL3JvdXRpbmcuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNuRCxPQUFPLEVBQ0wsYUFBYSxFQUNiLGVBQWUsRUFFZixNQUFNLEdBQ1AsTUFBTSxpQkFBaUIsQ0FBQztBQUN6QixPQUFPLEVBQ0wsTUFBTSxFQUNOLFlBQVksRUFFWixHQUFHLEVBRUgsYUFBYSxFQUNiLE9BQU8sR0FFUixNQUFNLE1BQU0sQ0FBQztBQUNkLE9BQU8sRUFBRSxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sV0FBVyxDQUFDOztBQVczQyxNQUFNLE9BQU8saUJBQWlCO0lBQ3BCLE1BQU0sR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDeEIsWUFBWSxDQUFTO0lBQ3JCLFlBQVksR0FBYSxFQUFFLENBQUM7SUFDNUIsc0JBQXNCLEdBQUcsSUFBSSxPQUFPLEVBQXVCLENBQUM7SUFDNUQsa0JBQWtCLEdBQUcsSUFBSSxhQUFhLENBRTNDLENBQUMsQ0FBQyxDQUFDO0lBQ0UseUJBQXlCLEdBQUcsSUFBSSxPQUFPLEVBQU8sQ0FBQztJQUNoRCwwQkFBMEIsR0FBRyxJQUFJLENBQUMseUJBQXlCO1NBQy9ELFlBQVksRUFBRTtTQUNkLElBQUksQ0FDSCxNQUFNLENBQ0osSUFBSSxDQUFDLHlCQUF5QixDQUFDLFlBQVksRUFBRSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FDdEUsRUFDRCxHQUFHLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtRQUNyQixPQUFPLGdCQUFnQixDQUFDLE1BQU0sQ0FDNUIsQ0FBQyxHQUFHLEVBQUUsSUFBSSxFQUFFLEVBQUU7WUFDWixJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDO2dCQUN6QyxNQUFNLGlCQUFpQixHQUFHLEtBQUssQ0FBQztvQkFDOUIsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLFdBQVc7b0JBQ3pCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXO2lCQUMzQixDQUFDLENBQUM7Z0JBQ0gsTUFBTSxZQUFZLEdBQUcsS0FBSyxDQUN4QixFQUFFLEdBQUcsR0FBRyxDQUFDLE1BQU0sRUFBRSxFQUNqQixFQUFFLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUNsQixFQUFFLFdBQVcsRUFBRSxpQkFBaUIsRUFBRSxDQUNuQyxDQUFDO2dCQUNGLE9BQU8sS0FBSyxDQUFDO29CQUNYLEdBQUcsR0FBRztvQkFDTixHQUFHLEVBQUUsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRTtpQkFDckQsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztRQUNILENBQUMsRUFDRCxFQUFFLFFBQVEsRUFBRSxFQUFFLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRSxDQUM3QixDQUFDO0lBQ0osQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUNJLG1CQUFtQixHQUFHLElBQUksT0FBTyxFQUFZLENBQUM7SUFDL0MsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFlBQVksRUFBRSxDQUFDO0lBQzlELGFBQWEsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDeEQsWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7SUFFL0Q7UUFDRSxJQUFJLENBQUMsMEJBQTBCLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxRQUFRLEVBQUUsTUFBTSxFQUFFLEVBQUUsRUFBRTtZQUNqRSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsTUFBTSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1FBQy9DLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ25DLElBQUksS0FBSyxZQUFZLGVBQWUsRUFBRSxDQUFDO2dCQUNyQyxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsbUJBQW1CLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUN4RCxJQUFJLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDO29CQUMvQixVQUFVLEVBQUUsV0FBVztvQkFDdkIsV0FBVyxFQUFFLElBQUksQ0FBQyxZQUFZO29CQUM5QixLQUFLO2lCQUNOLENBQUMsQ0FBQztZQUNMLENBQUM7aUJBQU0sSUFBSSxLQUFLLFlBQVksYUFBYSxFQUFFLENBQUM7Z0JBQzFDLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDeEQsSUFBSSxDQUFDLFlBQVksR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBRSxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ3RELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1lBQ25ELENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxtQkFBbUIsQ0FBQyxHQUFXO1FBQ3BDLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQzFDLE1BQU0sZUFBZSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRXpELE9BQU8sZUFBZTtZQUNwQixDQUFDLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztZQUN2RCxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN6RCxDQUFDO0lBRUQ7Ozs7Ozs7O09BUUc7SUFDSSxnQkFBZ0IsQ0FBQyxRQUFlLEVBQUUsTUFBZTtRQUN0RCxJQUFJLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxDQUFDLENBQUM7SUFDNUQsQ0FBQzt1R0F0RlUsaUJBQWlCOzJHQUFqQixpQkFBaUIsY0FGaEIsTUFBTTs7MkZBRVAsaUJBQWlCO2tCQUg3QixVQUFVO21CQUFDO29CQUNWLFVBQVUsRUFBRSxNQUFNO2lCQUNuQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGluamVjdCwgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgTmF2aWdhdGlvbkVuZCxcbiAgTmF2aWdhdGlvblN0YXJ0LFxuICBQYXJhbXMsXG4gIFJvdXRlcixcbn0gZnJvbSAnQGFuZ3VsYXIvcm91dGVyJztcbmltcG9ydCB7XG4gIGJ1ZmZlcixcbiAgZGVib3VuY2VUaW1lLFxuICBmaWx0ZXIsXG4gIG1hcCxcbiAgb2YsXG4gIFJlcGxheVN1YmplY3QsXG4gIFN1YmplY3QsXG4gIHN3aXRjaE1hcCxcbn0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBpc0VxdWFsLCBtZXJnZSB9IGZyb20gJ2xvZGFzaC1lcyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgSU91aU5hdmlnYXRpb25TdGFydCB7XG4gIGN1cnJlbnRVcmw6IHN0cmluZztcbiAgcHJldmlvdXNVcmw6IHN0cmluZztcbiAgZXZlbnQ6IE5hdmlnYXRpb25TdGFydDtcbn1cblxuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCcsXG59KVxuZXhwb3J0IGNsYXNzIE91aVJvdXRpbmdTZXJ2aWNlIHtcbiAgcHJpdmF0ZSByb3V0ZXIgPSBpbmplY3QoUm91dGVyKTtcbiAgcHJpdmF0ZSBwcmV2aW91c1BhdGg6IHN0cmluZztcbiAgcHJpdmF0ZSByb3V0ZUhpc3Rvcnk6IHN0cmluZ1tdID0gW107XG4gIHByaXZhdGUgbmF2aWdhdGlvblN0YXJ0U3ViamVjdCA9IG5ldyBTdWJqZWN0PElPdWlOYXZpZ2F0aW9uU3RhcnQ+KCk7XG4gIHByaXZhdGUgcXVlcnlQYXJhbXNTdWJqZWN0ID0gbmV3IFJlcGxheVN1YmplY3Q8e1xuICAgIFtrZXk6IHN0cmluZ106IHN0cmluZyB8IHN0cmluZ1tdO1xuICB9PigxKTtcbiAgcHJpdmF0ZSBidWZmZXJlZE5hdmlnYXRpb25TdWJqZWN0ID0gbmV3IFN1YmplY3Q8YW55PigpO1xuICBwdWJsaWMgYnVmZmVyZWROYXZpZ2F0aW9uVHJpZ2dlciQgPSB0aGlzLmJ1ZmZlcmVkTmF2aWdhdGlvblN1YmplY3RcbiAgICAuYXNPYnNlcnZhYmxlKClcbiAgICAucGlwZShcbiAgICAgIGJ1ZmZlcihcbiAgICAgICAgdGhpcy5idWZmZXJlZE5hdmlnYXRpb25TdWJqZWN0LmFzT2JzZXJ2YWJsZSgpLnBpcGUoZGVib3VuY2VUaW1lKDMwMCkpXG4gICAgICApLFxuICAgICAgbWFwKG5hdmlnYXRpb25FdmVudHMgPT4ge1xuICAgICAgICByZXR1cm4gbmF2aWdhdGlvbkV2ZW50cy5yZWR1Y2UoXG4gICAgICAgICAgKGFjYywgY3VycikgPT4ge1xuICAgICAgICAgICAgaWYgKGlzRXF1YWwoY3Vyci5jb21tYW5kcywgYWNjLmNvbW1hbmRzKSkge1xuICAgICAgICAgICAgICBjb25zdCBtZXJnZWRRdWVyeVBhcmFtcyA9IG1lcmdlKHtcbiAgICAgICAgICAgICAgICAuLi5hY2MuZXh0cmFzLnF1ZXJ5UGFyYW1zLFxuICAgICAgICAgICAgICAgIC4uLmN1cnIuZXh0cmFzLnF1ZXJ5UGFyYW1zLFxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgY29uc3QgbWVyZ2VkRXh0cmFzID0gbWVyZ2UoXG4gICAgICAgICAgICAgICAgeyAuLi5hY2MuZXh0cmFzIH0sXG4gICAgICAgICAgICAgICAgeyAuLi5jdXJyLmV4dHJhcyB9LFxuICAgICAgICAgICAgICAgIHsgcXVlcnlQYXJhbXM6IG1lcmdlZFF1ZXJ5UGFyYW1zIH1cbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgcmV0dXJuIG1lcmdlKHtcbiAgICAgICAgICAgICAgICAuLi5hY2MsXG4gICAgICAgICAgICAgICAgLi4ueyBjb21tYW5kczogY3Vyci5jb21tYW5kcywgZXh0cmFzOiBtZXJnZWRFeHRyYXMgfSxcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICByZXR1cm4gY3VycjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIHsgY29tbWFuZHM6IFtdLCBleHRyYXM6IHt9IH1cbiAgICAgICAgKTtcbiAgICAgIH0pXG4gICAgKTtcbiAgcHJpdmF0ZSByb3V0ZUhpc3RvcnlTdWJqZWN0ID0gbmV3IFN1YmplY3Q8c3RyaW5nW10+KCk7XG4gIHB1YmxpYyBuYXZpZ2F0aW9uU3RhcnQkID0gdGhpcy5uYXZpZ2F0aW9uU3RhcnRTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuICBwdWJsaWMgcm91dGVIaXN0b3J5JCA9IHRoaXMucm91dGVIaXN0b3J5U3ViamVjdC5hc09ic2VydmFibGUoKTtcbiAgcHVibGljIHF1ZXJ5UGFyYW1zJCA9IHRoaXMucm91dGVyLnJvdXRlclN0YXRlLnJvb3QucXVlcnlQYXJhbXM7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5idWZmZXJlZE5hdmlnYXRpb25UcmlnZ2VyJC5zdWJzY3JpYmUoKHsgY29tbWFuZHMsIGV4dHJhcyB9KSA9PiB7XG4gICAgICB0aGlzLnJvdXRlci5uYXZpZ2F0ZShjb21tYW5kcywgZXh0cmFzID8/IHt9KTtcbiAgICB9KTtcblxuICAgIHRoaXMucm91dGVyLmV2ZW50cy5zdWJzY3JpYmUoZXZlbnQgPT4ge1xuICAgICAgaWYgKGV2ZW50IGluc3RhbmNlb2YgTmF2aWdhdGlvblN0YXJ0KSB7XG4gICAgICAgIGNvbnN0IGN1cnJlbnRQYXRoID0gdGhpcy5nZXRVcmxXaXRob3V0UGFyYW1zKGV2ZW50LnVybCk7XG4gICAgICAgIHRoaXMubmF2aWdhdGlvblN0YXJ0U3ViamVjdC5uZXh0KHtcbiAgICAgICAgICBjdXJyZW50VXJsOiBjdXJyZW50UGF0aCxcbiAgICAgICAgICBwcmV2aW91c1VybDogdGhpcy5wcmV2aW91c1BhdGgsXG4gICAgICAgICAgZXZlbnQsXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIGlmIChldmVudCBpbnN0YW5jZW9mIE5hdmlnYXRpb25FbmQpIHtcbiAgICAgICAgdGhpcy5wcmV2aW91c1BhdGggPSB0aGlzLmdldFVybFdpdGhvdXRQYXJhbXMoZXZlbnQudXJsKTtcbiAgICAgICAgdGhpcy5yb3V0ZUhpc3RvcnkgPSBbLi4udGhpcy5yb3V0ZUhpc3RvcnksIGV2ZW50LnVybF07XG4gICAgICAgIHRoaXMucm91dGVIaXN0b3J5U3ViamVjdC5uZXh0KHRoaXMucm91dGVIaXN0b3J5KTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIHB1YmxpYyBnZXRVcmxXaXRob3V0UGFyYW1zKHVybDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICBjb25zdCB1cmxUcmVlID0gdGhpcy5yb3V0ZXIucGFyc2VVcmwodXJsKTtcbiAgICBjb25zdCBwcmltYXJ5Q2hpbGRyZW4gPSB1cmxUcmVlLnJvb3QuY2hpbGRyZW5bJ3ByaW1hcnknXTtcblxuICAgIHJldHVybiBwcmltYXJ5Q2hpbGRyZW5cbiAgICAgID8gcHJpbWFyeUNoaWxkcmVuLnNlZ21lbnRzLm1hcChpdCA9PiBpdC5wYXRoKS5qb2luKCcvJylcbiAgICAgIDogdXJsVHJlZS5yb290LnNlZ21lbnRzLm1hcChpdCA9PiBpdC5wYXRoKS5qb2luKCcvJyk7XG4gIH1cblxuICAvKipcbiAgICogU29tZXRpbWVzIHdlIHdhbnQgdG8gbmF2aWdhdGUgdG8gdGhlIHNhbWUgcm91dGUgcmVwZWF0ZWRseSBhbmQgYWRkIGRpZmZlcmVudCBxdWVyeSBwYXJhbXNcbiAgICogKGZvciBleGFtcGxlIHdoZW4gaW5pdGlhbGlzaW5nIGZpbHRlcnMpLiBUaGlzIGFsbG93cyB1cyB0byBkbyB0aGF0IHdpdGhvdXQgdHJpZ2dlcmluZ1xuICAgKiBuYXZpZ2F0aW9uIGZvciBlYWNoIHF1ZXJ5IHBhcmFtIGNoYW5nZSAod2hpY2ggY2FuIGxlYWQgdG8gbmF2aWdhdGlvbkVuZCBuZXZlciB0cmlnZ2VyaW5nIGluIGFuZ3VsYXIpLlxuICAgKiBUaGlzIG1ldGhvZCBjb2xsZWN0cyBhbGwgdGhlIGNoYW5nZWQgcXVlcnkgcGFyYW1zIGFuZCBtZXJnZXMgdGhlbSB0b2dldGhlciwgZmluYWxseSBuYXZpZ2F0aW5nIHRvIHRoZVxuICAgKiB0YXJnZXQgcm91dGUgd2l0aCBhbGwgdGhlIHF1ZXJ5IHBhcmFtcyAoYWZ0ZXIgMzAwIG1zKVxuICAgKiBAcGFyYW0gY29tbWFuZHNcbiAgICogQHBhcmFtIGV4dHJhc1xuICAgKi9cbiAgcHVibGljIGJ1ZmZlcmVkTmF2aWdhdGUoY29tbWFuZHM6IGFueVtdLCBleHRyYXM/OiBQYXJhbXMpIHtcbiAgICB0aGlzLmJ1ZmZlcmVkTmF2aWdhdGlvblN1YmplY3QubmV4dCh7IGNvbW1hbmRzLCBleHRyYXMgfSk7XG4gIH1cbn1cbiJdfQ==