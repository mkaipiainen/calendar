import { GeoJsonLayer } from '@deck.gl/layers/typed';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { BindCommonDeckOptions } from '../deck/bind-default-deck-options';
import * as i0 from "@angular/core";
export class DeckGeojsonLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new GeoJsonLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            pointType: this.options.pointType,
            lineWidthScale: this.options.lineWidthScale ?? 1,
            lineWidthMinPixels: this.options.lineWidthMinPixels ?? 1,
            lineWidthMaxPixels: this.options.lineWidthMaxPixels ?? 999,
            lineWithUnits: this.options.lineWithUnits ?? 'pixels',
            getFillColor: this.options.getFillColor,
            getLineColor: this.options.getLineColor,
            getPointRadius: this.options.getPointRadius ?? 20,
            getLineWidth: this.options.getLineWidth ?? 1,
            getElevation: this.options.getElevation ?? 20,
            extruded: this.options.extruded ?? false,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckGeojsonLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckGeojsonLayer, isStandalone: true, selector: "oui-deck-geojson-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckGeojsonLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-geojson-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay1nZW9qc29uLWxheWVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9tYXBib3gvZ2VvanNvbi1sYXllci9kZWNrLWdlb2pzb24tbGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBRXJELE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM3RCxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQzs7QUFTMUUsTUFBTSxPQUFPLGdCQUFpQixTQUFRLGFBQXNDO0lBQ3ZDLE9BQU8sQ0FBMkI7SUFFckU7UUFDRSxLQUFLLEVBQUUsQ0FBQztJQUNWLENBQUM7SUFFTSxRQUFRO1FBQ2IsT0FBTyxJQUFJLFlBQVksQ0FBQztZQUN0QixHQUFHLHFCQUFxQixDQUFDLElBQUksQ0FBQztZQUM5QixJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ3ZCLFNBQVMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVM7WUFDakMsY0FBYyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxJQUFJLENBQUM7WUFDaEQsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsSUFBSSxDQUFDO1lBQ3hELGtCQUFrQixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsa0JBQWtCLElBQUksR0FBRztZQUMxRCxhQUFhLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLElBQUksUUFBUTtZQUNyRCxZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZO1lBQ3ZDLFlBQVksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVk7WUFDdkMsY0FBYyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxJQUFJLEVBQUU7WUFDakQsWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxJQUFJLENBQUM7WUFDNUMsWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxJQUFJLEVBQUU7WUFDN0MsUUFBUSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxJQUFJLEtBQUs7U0FDekMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQzt1R0F2QlUsZ0JBQWdCOzJGQUFoQixnQkFBZ0IseUlBTGpCLEVBQUU7OzJGQUtELGdCQUFnQjtrQkFQNUIsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsd0JBQXdCO29CQUNsQyxRQUFRLEVBQUUsRUFBRTtvQkFDWixVQUFVLEVBQUUsSUFBSTtvQkFDaEIsT0FBTyxFQUFFLEVBQUU7b0JBQ1gsZUFBZSxFQUFFLHVCQUF1QixDQUFDLE1BQU07aUJBQ2hEO3dEQUVvQyxPQUFPO3NCQUF6QyxLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEdlb0pzb25MYXllciB9IGZyb20gJ0BkZWNrLmdsL2xheWVycy90eXBlZCc7XG5pbXBvcnQgeyBJQ29tbW9uRGVja0xheWVyT3B0aW9ucywgSURlY2tHZW9Kc29uTGF5ZXJPcHRpb25zIH0gZnJvbSAnLi4vdHlwaW5ncyc7XG5pbXBvcnQgeyBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSwgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURlY2tMYXllciB9IGZyb20gJy4uL2Jhc2UtZGVjay1sYXllci5jb21wb25lbnQnO1xuaW1wb3J0IHsgQmluZENvbW1vbkRlY2tPcHRpb25zIH0gZnJvbSAnLi4vZGVjay9iaW5kLWRlZmF1bHQtZGVjay1vcHRpb25zJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLWRlY2stZ2VvanNvbi1sYXllcicsXG4gIHRlbXBsYXRlOiAnJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW10sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBEZWNrR2VvanNvbkxheWVyIGV4dGVuZHMgQmFzZURlY2tMYXllcjxJQ29tbW9uRGVja0xheWVyT3B0aW9ucz4ge1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KSBkZWNsYXJlIG9wdGlvbnM6IElEZWNrR2VvSnNvbkxheWVyT3B0aW9ucztcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpO1xuICB9XG5cbiAgcHVibGljIGdldExheWVyKCkge1xuICAgIHJldHVybiBuZXcgR2VvSnNvbkxheWVyKHtcbiAgICAgIC4uLkJpbmRDb21tb25EZWNrT3B0aW9ucyh0aGlzKSxcbiAgICAgIGRhdGE6IHRoaXMub3B0aW9ucy5kYXRhLFxuICAgICAgcG9pbnRUeXBlOiB0aGlzLm9wdGlvbnMucG9pbnRUeXBlLFxuICAgICAgbGluZVdpZHRoU2NhbGU6IHRoaXMub3B0aW9ucy5saW5lV2lkdGhTY2FsZSA/PyAxLFxuICAgICAgbGluZVdpZHRoTWluUGl4ZWxzOiB0aGlzLm9wdGlvbnMubGluZVdpZHRoTWluUGl4ZWxzID8/IDEsXG4gICAgICBsaW5lV2lkdGhNYXhQaXhlbHM6IHRoaXMub3B0aW9ucy5saW5lV2lkdGhNYXhQaXhlbHMgPz8gOTk5LFxuICAgICAgbGluZVdpdGhVbml0czogdGhpcy5vcHRpb25zLmxpbmVXaXRoVW5pdHMgPz8gJ3BpeGVscycsXG4gICAgICBnZXRGaWxsQ29sb3I6IHRoaXMub3B0aW9ucy5nZXRGaWxsQ29sb3IsXG4gICAgICBnZXRMaW5lQ29sb3I6IHRoaXMub3B0aW9ucy5nZXRMaW5lQ29sb3IsXG4gICAgICBnZXRQb2ludFJhZGl1czogdGhpcy5vcHRpb25zLmdldFBvaW50UmFkaXVzID8/IDIwLFxuICAgICAgZ2V0TGluZVdpZHRoOiB0aGlzLm9wdGlvbnMuZ2V0TGluZVdpZHRoID8/IDEsXG4gICAgICBnZXRFbGV2YXRpb246IHRoaXMub3B0aW9ucy5nZXRFbGV2YXRpb24gPz8gMjAsXG4gICAgICBleHRydWRlZDogdGhpcy5vcHRpb25zLmV4dHJ1ZGVkID8/IGZhbHNlLFxuICAgIH0pO1xuICB9XG59XG4iXX0=