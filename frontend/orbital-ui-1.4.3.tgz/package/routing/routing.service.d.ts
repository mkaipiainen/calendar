import { NavigationStart, Params } from '@angular/router';
import * as i0 from "@angular/core";
export interface IOuiNavigationStart {
    currentUrl: string;
    previousUrl: string;
    event: NavigationStart;
}
export declare class OuiRoutingService {
    private router;
    private previousPath;
    private routeHistory;
    private navigationStartSubject;
    private queryParamsSubject;
    private bufferedNavigationSubject;
    bufferedNavigationTrigger$: import("rxjs").Observable<any>;
    private routeHistorySubject;
    navigationStart$: import("rxjs").Observable<IOuiNavigationStart>;
    routeHistory$: import("rxjs").Observable<string[]>;
    queryParams$: import("rxjs").Observable<Params>;
    constructor();
    getUrlWithoutParams(url: string): string;
    /**
     * Sometimes we want to navigate to the same route repeatedly and add different query params
     * (for example when initialising filters). This allows us to do that without triggering
     * navigation for each query param change (which can lead to navigationEnd never triggering in angular).
     * This method collects all the changed query params and merges them together, finally navigating to the
     * target route with all the query params (after 300 ms)
     * @param commands
     * @param extras
     */
    bufferedNavigate(commands: any[], extras?: Params): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiRoutingService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiRoutingService>;
}
//# sourceMappingURL=routing.service.d.ts.map