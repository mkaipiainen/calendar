import { AfterViewInit, ChangeDetectorRef, ElementRef, ViewContainerRef } from '@angular/core';
import { ICombinedOuiToastOptions, OuiToastService } from './toast.service';
import { IOuiIconOptions } from 'orbital-ui/icon';
import * as i0 from "@angular/core";
/**
 * Not used directly, only triggered through ouiToastService. A component to display toast-messages to the user.
 */
export declare class OuiToastComponent implements AfterViewInit {
    private toastService;
    private cdr;
    options: ICombinedOuiToastOptions;
    contentRef: ElementRef;
    contentVCR: ViewContainerRef;
    show: boolean;
    toastIcon: string;
    toastIconOptions: IOuiIconOptions;
    constructor(toastService: OuiToastService, cdr: ChangeDetectorRef);
    ngAfterViewInit(): void;
    disable(): void;
    close(): void;
    getType(): "bg-color-success" | "bg-color-danger" | "bg-color-warning" | "bg-color-info" | "bg-color-transparent";
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiToastComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiToastComponent, "oui-toast", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=toast.component.d.ts.map