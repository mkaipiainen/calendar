import { Feature, FeatureCollection, Geometry, Position } from '@turf/helpers';
import { RGBA } from 'orbital-ui/core';
import { OpenlayersPathLayerComponent } from './layers/openlayers-path-layer.component';
import { OpenlayersGeoJsonLayerComponent } from './layers/openlayers-geojson-layer.component';
import { OPENLAYERS_EDITABLE_GEOJSON_DRAW_MODES } from './constants';
import { OpenlayersIconLayerComponent } from './layers/openlayers-icon-layer.component';
import { OpenlayersEditableGeojsonLayerComponent } from './layers/openlayers-editable-geojson-layer.component';
import { OpenlayersTileLayerComponent } from './layers/openlayers-tile-layer.component';
import { Observable } from 'rxjs';
import { Type } from 'ol/geom/Geometry';
import { ServerType } from 'ol/source/wms';
import { DrawEvent } from 'ol/interaction/Draw';
import { ModifyEvent } from 'ol/interaction/Modify';
import { Feature as OlFeature } from 'ol';
import { OpenlayersMeasureLayerComponent } from './layers/openlayers-measure-layer.component';
import { OpenlayersGeolocateLayerComponent } from './layers/openlayers-geolocate-layer.component';
export type OuiOpenlayersViewState = {
    latitude: number;
    longitude: number;
    zoom: number;
    bounds: OuiLonLatBounds;
    width: number;
    height: number;
};
type OuiOpenlayersCommonMapOptions = {
    accessToken?: string;
    style?: string;
    isHiddenOnInitialLoad?: boolean;
    pipelineOptions?: {
        endpoint: string;
        requestType: 'GET' | 'POST';
        requestData?: Record<string, any>;
        isEnabled?: boolean;
        options?: OuiOpenlayersPathLayerOptions;
    };
};
type OuiOpenlayersBoundsOptions = OuiOpenlayersCommonMapOptions & {
    bounds: OuiOpenlayersMapBounds;
};
export type OuiOpenlayersMapBounds = {
    ne: LonLatCoordinate;
    sw: LonLatCoordinate;
};
export type OuiOpenlayersFlyToOptions = {
    lat: number;
    lon: number;
    zoom: number;
    duration?: number | 'auto';
};
type OuiOpenlayersLatLonZoomOptions = OuiOpenlayersCommonMapOptions & {
    latitude: number;
    longitude: number;
    zoom: number;
};
export type OuiOpenlayersOptions = OuiOpenlayersBoundsOptions | OuiOpenlayersLatLonZoomOptions;
export type OuiOpenlayersPathLayerOptions = OuiOpenLayersCommonOptions & {
    data: Record<string, any>[];
    getLineColor?: ((feature: Feature<Geometry>) => RGBA) | RGBA;
    getLineWidth?: ((feature: Feature<Geometry>) => number) | number;
    autoHighlight?: boolean;
    highlightColor?: RGBA;
    getPath: (feature: any) => Position;
    pickable?: boolean;
};
export type OpenlayersSideBySideOptions = {
    enabledEvents?: {
        moveSlider?: boolean;
        zoomInOut?: boolean;
    };
};
export type LonLatCoordinate = {
    lon: number;
    lat: number;
};
export type OuiLonLatBounds = {
    nw: LonLatCoordinate;
    se: LonLatCoordinate;
    ne: LonLatCoordinate;
    sw: LonLatCoordinate;
};
export type OuiOpenLayersIconLayerOptions = Omit<OuiOpenLayersCombinedIconLayerOptions, 'anchor' | 'anchorUnits'> & {
    anchor?: {
        x: number;
        y: number;
    };
    anchorUnits?: {
        x: 'fraction' | 'pixels';
        y: 'fraction' | 'pixels';
    };
    pickable?: boolean;
};
export type OuiOpenLayersCombinedIconLayerOptions = OuiOpenLayersCommonOptions & {
    data: Record<string, any>[];
    getPosition: (feature: any) => Position;
    getIcon: (feature: any) => string;
    unitSystem?: 'metric' | 'imperial';
    anchor: {
        x: number;
        y: number;
    };
    anchorUnits: {
        x: 'fraction' | 'pixels';
        y: 'fraction' | 'pixels';
    };
    pickable?: boolean;
};
export type OpenlayersDrawMode = (typeof OPENLAYERS_EDITABLE_GEOJSON_DRAW_MODES)[keyof typeof OPENLAYERS_EDITABLE_GEOJSON_DRAW_MODES];
export type OuiOpenLayersEditableGeoJsonLayerOptions = OuiOpenLayersCommonOptions & {
    data: FeatureCollection<Geometry, any>;
    getFillColor: ((feature: OlFeature) => RGBA) | RGBA;
    getStrokeColor: ((feature: OlFeature) => RGBA) | RGBA;
    getLineWidth: ((feature: OlFeature) => number) | number;
    pointRadius?: number;
    autoHighlight?: boolean;
    highlightColor?: RGBA;
    mode: Type;
    pickable?: boolean;
    onCreate?: (evt: DrawEvent) => void;
    onEdit?: (evt: ModifyEvent) => void;
    onRemove?: (evt: DrawEvent) => void;
    isFeatureEditable?: (feature: OlFeature) => boolean;
};
export type OuiOpenlayersGeoJsonLayerOptions = OuiOpenLayersCommonOptions & {
    data: FeatureCollection<Geometry, any>;
    getFillColor: ((feature: OlFeature) => RGBA) | RGBA;
    getStrokeColor: ((feature: OlFeature) => RGBA) | RGBA;
    getLineWidth: ((feature: OlFeature) => number) | number;
    pointRadius?: number;
    autoHighlight?: boolean;
    highlightColor?: RGBA;
    filled?: boolean;
    stroked?: boolean;
    pickable?: boolean;
};
export type OuiOpenLayersCommonOptions = {
    onClick?: (feature: OlFeature) => void;
    onHover?: (feature: OlFeature) => void;
    getCursor?: (feature: OlFeature) => string;
    id: string;
    order?: number;
    isVisible?: boolean;
    isEnabled?: boolean;
    sideBySideType?: 'left' | 'right';
};
export type OuiOpenlayersTileLayerOptions = OuiOpenlayersTileLayerWmsOptions | OuiOpenlayersTileLayerWmtsOptions;
export type OuiOpenlayersTileLayerCommonOptions = OuiOpenLayersCommonOptions & {
    blobToUrlTransformer?: Promise<string>;
    url: string;
    getTileData?: (tile: any, src: string) => any;
    projection: string;
};
export type OuiOpenlayersTileLayerWmsOptions = OuiOpenlayersTileLayerCommonOptions & {
    layers: string[];
    bounds?: [number, number, number, number];
    transition?: number;
    serverType?: ServerType;
    tiled?: boolean;
};
export type OuiOpenlayersTileLayerWmtsOptions = OuiOpenlayersTileLayerCommonOptions & {
    layer: string;
    format?: string;
    style?: string;
    wrapX?: boolean;
    maxZoom?: number;
};
export type OuiOpenlayersTileServiceOptions = {
    tileLayerOptions: Partial<OuiOpenlayersTileLayerOptions> & {
        id: string;
    };
    isWebMercator?: boolean;
    data?: any;
    origin: string;
    useCache?: boolean;
    isWmts?: boolean;
    accessToken$: Observable<string>;
    refreshedAccessToken$: Observable<string>;
    blobToUrlTransformer?: (blob: Blob) => Promise<string>;
    buildUrl?: (data: any, options: OuiOpenlayersTileServiceOptions) => string;
};
export type OuiOpenlayersMeasureLayerOptions = OuiOpenLayersCommonOptions & {
    unitSystem?: 'metric' | 'imperial';
};
export type OuiOpenlayersGeolocateLayerOptions = OuiOpenLayersCommonOptions;
export type OuiOpenlayersLayer = OpenlayersPathLayerComponent | OpenlayersGeoJsonLayerComponent | OpenlayersIconLayerComponent | OpenlayersEditableGeojsonLayerComponent | OpenlayersTileLayerComponent | OpenlayersMeasureLayerComponent | OpenlayersGeolocateLayerComponent;
export {};
//# sourceMappingURL=types.d.ts.map