import { ViewStateChangeParameters } from '@deck.gl/core/typed/controllers/controller';
import { OuiMapboxComponent } from '../mapbox.component';
import { MapboxEvent } from 'mapbox-gl';
import { OuiDeckComponent } from '../deck/deck.component';
import * as i0 from "@angular/core";
interface IMapboxSyncMap {
    map: OuiMapboxComponent;
    moveListener: (event: MapboxEvent) => void;
}
interface IDeckSyncMap {
    map: OuiMapboxComponent;
    deck: OuiDeckComponent;
    existingViewStateChangeListener: (params: ViewStateChangeParameters & {
        viewId: string;
    }) => void;
}
export declare class OuiMapSyncService {
    mapGroups: {
        [x: string]: {
            [mapId: string]: IMapboxSyncMap | IDeckSyncMap;
        };
    };
    constructor();
    registerMap(map: OuiMapboxComponent, group: string): void;
    deRegisterMap(map: OuiMapboxComponent, group: string): void;
    private initSyncDeck;
    private initSyncMapbox;
    private syncMapboxViewState;
    private syncDeckToMapboxViewState;
    private syncMapboxToDeckViewState;
    private moveMapToParent;
    syncDeckViewState(group: {
        [x: string]: IMapboxSyncMap | IDeckSyncMap;
    }, map: OuiMapboxComponent, viewStateChange: ViewStateChangeParameters & {
        viewId: string;
    }): void;
    private mapboxToDeckViewState;
    private deckToMapboxViewState;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiMapSyncService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiMapSyncService>;
}
export {};
//# sourceMappingURL=mapsync.service.d.ts.map