import { Inject, Injectable } from '@angular/core';
import { fromEvent } from 'rxjs';
import { DOCUMENT } from '@angular/common';
import * as i0 from "@angular/core";
/**
 * Service used to control inputs.
 * Mainly used right now just to keep track of them and to set focus to inputs when clicking on them.
 */
export class OuiInputService {
    document;
    inputs = [];
    constructor(document) {
        this.document = document;
        fromEvent(this.document.body, 'click').subscribe((event) => {
            if ((window.TouchEvent && event instanceof TouchEvent) ||
                event instanceof MouseEvent) {
                for (const input of this.inputs) {
                    if (input.isFocused &&
                        !input.inputWrapperElement.nativeElement.contains(event.target)) {
                        input.setFocus(false);
                    }
                }
            }
        });
    }
    defocusAll() {
        for (const input of this.inputs) {
            input.setFocus(false);
        }
    }
    register(input) {
        this.inputs.push(input);
    }
    deregister(input) {
        this.inputs = this.inputs.filter(i => i !== input);
    }
    setFocus(input, isFocused) {
        input.setFocus(isFocused);
    }
    setError(input, hasError) {
        input.setError(hasError);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiInputService, deps: [{ token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiInputService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiInputService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5wdXQuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvaW5wdXQvaW5wdXQuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNuRCxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBRWpDLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQzs7QUFFM0M7OztHQUdHO0FBSUgsTUFBTSxPQUFPLGVBQWU7SUFHWTtJQUY5QixNQUFNLEdBQXdCLEVBQUUsQ0FBQztJQUV6QyxZQUFzQyxRQUFrQjtRQUFsQixhQUFRLEdBQVIsUUFBUSxDQUFVO1FBQ3RELFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxLQUFZLEVBQUUsRUFBRTtZQUNoRSxJQUNFLENBQUMsTUFBTSxDQUFDLFVBQVUsSUFBSSxLQUFLLFlBQVksVUFBVSxDQUFDO2dCQUNsRCxLQUFLLFlBQVksVUFBVSxFQUMzQixDQUFDO2dCQUNELEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO29CQUNoQyxJQUNFLEtBQUssQ0FBQyxTQUFTO3dCQUNmLENBQUMsS0FBSyxDQUFDLG1CQUFtQixDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUMvRCxDQUFDO3dCQUNELEtBQUssQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3hCLENBQUM7Z0JBQ0gsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxVQUFVO1FBQ2YsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDaEMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN4QixDQUFDO0lBQ0gsQ0FBQztJQUVNLFFBQVEsQ0FBQyxLQUF3QjtRQUN0QyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBRU0sVUFBVSxDQUFDLEtBQXdCO1FBQ3hDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVNLFFBQVEsQ0FBQyxLQUF3QixFQUFFLFNBQWtCO1FBQzFELEtBQUssQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDNUIsQ0FBQztJQUVNLFFBQVEsQ0FBQyxLQUF3QixFQUFFLFFBQWlCO1FBQ3pELEtBQUssQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDM0IsQ0FBQzt1R0F6Q1UsZUFBZSxrQkFHTixRQUFROzJHQUhqQixlQUFlLGNBRmQsTUFBTTs7MkZBRVAsZUFBZTtrQkFIM0IsVUFBVTttQkFBQztvQkFDVixVQUFVLEVBQUUsTUFBTTtpQkFDbkI7OzBCQUljLE1BQU07MkJBQUMsUUFBUSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdCwgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgZnJvbUV2ZW50IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBPdWlJbnB1dENvbXBvbmVudCB9IGZyb20gJy4vaW5wdXQuY29tcG9uZW50JztcbmltcG9ydCB7IERPQ1VNRU5UIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcblxuLyoqXG4gKiBTZXJ2aWNlIHVzZWQgdG8gY29udHJvbCBpbnB1dHMuXG4gKiBNYWlubHkgdXNlZCByaWdodCBub3cganVzdCB0byBrZWVwIHRyYWNrIG9mIHRoZW0gYW5kIHRvIHNldCBmb2N1cyB0byBpbnB1dHMgd2hlbiBjbGlja2luZyBvbiB0aGVtLlxuICovXG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290Jyxcbn0pXG5leHBvcnQgY2xhc3MgT3VpSW5wdXRTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBpbnB1dHM6IE91aUlucHV0Q29tcG9uZW50W10gPSBbXTtcblxuICBjb25zdHJ1Y3RvcihASW5qZWN0KERPQ1VNRU5UKSBwcml2YXRlIGRvY3VtZW50OiBEb2N1bWVudCkge1xuICAgIGZyb21FdmVudCh0aGlzLmRvY3VtZW50LmJvZHksICdjbGljaycpLnN1YnNjcmliZSgoZXZlbnQ6IEV2ZW50KSA9PiB7XG4gICAgICBpZiAoXG4gICAgICAgICh3aW5kb3cuVG91Y2hFdmVudCAmJiBldmVudCBpbnN0YW5jZW9mIFRvdWNoRXZlbnQpIHx8XG4gICAgICAgIGV2ZW50IGluc3RhbmNlb2YgTW91c2VFdmVudFxuICAgICAgKSB7XG4gICAgICAgIGZvciAoY29uc3QgaW5wdXQgb2YgdGhpcy5pbnB1dHMpIHtcbiAgICAgICAgICBpZiAoXG4gICAgICAgICAgICBpbnB1dC5pc0ZvY3VzZWQgJiZcbiAgICAgICAgICAgICFpbnB1dC5pbnB1dFdyYXBwZXJFbGVtZW50Lm5hdGl2ZUVsZW1lbnQuY29udGFpbnMoZXZlbnQudGFyZ2V0KVxuICAgICAgICAgICkge1xuICAgICAgICAgICAgaW5wdXQuc2V0Rm9jdXMoZmFsc2UpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIGRlZm9jdXNBbGwoKSB7XG4gICAgZm9yIChjb25zdCBpbnB1dCBvZiB0aGlzLmlucHV0cykge1xuICAgICAgaW5wdXQuc2V0Rm9jdXMoZmFsc2UpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyByZWdpc3RlcihpbnB1dDogT3VpSW5wdXRDb21wb25lbnQpIHtcbiAgICB0aGlzLmlucHV0cy5wdXNoKGlucHV0KTtcbiAgfVxuXG4gIHB1YmxpYyBkZXJlZ2lzdGVyKGlucHV0OiBPdWlJbnB1dENvbXBvbmVudCkge1xuICAgIHRoaXMuaW5wdXRzID0gdGhpcy5pbnB1dHMuZmlsdGVyKGkgPT4gaSAhPT0gaW5wdXQpO1xuICB9XG5cbiAgcHVibGljIHNldEZvY3VzKGlucHV0OiBPdWlJbnB1dENvbXBvbmVudCwgaXNGb2N1c2VkOiBib29sZWFuKSB7XG4gICAgaW5wdXQuc2V0Rm9jdXMoaXNGb2N1c2VkKTtcbiAgfVxuXG4gIHB1YmxpYyBzZXRFcnJvcihpbnB1dDogT3VpSW5wdXRDb21wb25lbnQsIGhhc0Vycm9yOiBib29sZWFuKSB7XG4gICAgaW5wdXQuc2V0RXJyb3IoaGFzRXJyb3IpO1xuICB9XG59XG4iXX0=