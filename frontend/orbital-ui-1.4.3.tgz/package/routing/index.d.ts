/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/routing" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-routing.d.ts.map