export * from './table.component';
export * from './types';
//# sourceMappingURL=public-api.d.ts.map