import { OuiDialogComponent } from '../dialog.component';
import { OuiButtonVariant } from 'orbital-ui/button';
import * as i0 from "@angular/core";
/**
 * Represents a confirmation dialog component that extends OuiDialogComponent.
 * Displays a dialog box with a message asking the user to confirm or cancel an action.
 *
 */
export declare class OuiSimpleDialogComponent extends OuiDialogComponent {
    /**
     * The message to display in the confirmation dialog. Default is 'Please either confirm or cancel.'.
     */
    content: string;
    /**
     * The label for the submit button. Default is 'Submit'.
     */
    submitLabel: string;
    /**
     * The variant of the submit button
     */
    submitVariant: OuiButtonVariant;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiSimpleDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiSimpleDialogComponent, "oui-simple-dialog", never, { "content": { "alias": "content"; "required": false; }; "submitLabel": { "alias": "submitLabel"; "required": false; }; "submitVariant": { "alias": "submitVariant"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=simple.dialog.component.d.ts.map