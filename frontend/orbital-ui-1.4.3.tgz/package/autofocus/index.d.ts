/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/autofocus" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-autofocus.d.ts.map