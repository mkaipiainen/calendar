import * as i0 from '@angular/core';
import { EventEmitter, Component, ViewChild, Input, Output } from '@angular/core';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';

/**
 * A component that generates on/off switches. Functionally works the same as a checkbox, but looks visually different.
 * Can be used without labels, in which case behaves as a classic switch-component. Alternatively, can give labels to
 * the component in which case the outlook changes, and labels are added to the on/off sides.
 */
class OuiSwitchComponent {
    svgElement;
    pathElement;
    /**
     *   The model bound to the switch
     */
    model;
    /**
     *   The values attached to the different states to the switch. These values are bound to the model.
     */
    values = {
        on: true,
        off: false,
    };
    /**
     *   The labels that are shown on the on/off sides of the switch. Changes how the component looks.
     */
    labels;
    /**
     *   Changes how the switch looks visually based on the theme
     */
    type = '';
    /**
     * The mode of the switch. If using labels, remember to pass the labels-input.
     */
    mode = 'boolean';
    /**
     *  If true, the switch will not toggle when clicked
     */
    disableClickToggle = false;
    /**
     *   Triggered when the model changes
     */
    modelChange = new EventEmitter();
    constructor() { }
    getButtonClass() {
        return this.model === this.values.on ? 'on' : 'off';
    }
    onClick() {
        if (this.disableClickToggle) {
            return;
        }
        if (this.model === this.values.on) {
            this.model = this.values.off;
        }
        else {
            this.model = this.values.on;
        }
        this.modelChange.emit(this.model);
    }
    getOnLabel() {
        if (typeof this.values.on !== 'boolean') {
            return this.labels?.on ?? this.values.on;
        }
        else {
            return '';
        }
    }
    getOffLabel() {
        if (typeof this.values.off !== 'boolean') {
            return this.labels?.off ?? this.values.off;
        }
        else {
            return '';
        }
    }
    isSelected(side) {
        return this.model === this.values[side];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSwitchComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiSwitchComponent, isStandalone: true, selector: "oui-switch", inputs: { model: "model", values: "values", labels: "labels", type: "type", mode: "mode", disableClickToggle: "disableClickToggle" }, outputs: { modelChange: "modelChange" }, viewQueries: [{ propertyName: "svgElement", first: true, predicate: ["svgElement"], descendants: true }, { propertyName: "pathElement", first: true, predicate: ["pathElement"], descendants: true }], ngImport: i0, template: "<div class=\"oui-switch-container {{ mode }} {{ type }}\" (click)=\"onClick()\">\n  @if (mode === 'labels') {\n    <div class=\"label-switch-container\">\n      <div class=\"switch-off switch\" [ngClass]=\"{ selected: isSelected('off') }\">\n        {{ getOffLabel() }}\n      </div>\n      <div class=\"switch-on switch\" [ngClass]=\"{ selected: isSelected('on') }\">\n        {{ getOnLabel() }}\n      </div>\n      <div class=\"switch-button\" [ngClass]=\"getButtonClass()\"></div>\n    </div>\n  }\n  @if (mode === 'boolean') {\n    <div class=\"boolean-switch-container\">\n      <div class=\"track\">\n        <div class=\"switch-track\" [ngClass]=\"{ on: isSelected('on') }\"></div>\n        <div class=\"switch-button\" [ngClass]=\"getButtonClass()\"></div>\n      </div>\n      <div class=\"switch-label\">\n        <ng-content class=\"content\"></ng-content>\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{z-index:1;flex:1;min-width:3rem;position:relative;margin-right:8px;display:flex}:host:hover{cursor:pointer}:host .oui-switch-container{height:100%;width:100%;position:relative;display:flex;align-items:center;justify-content:center;border:0px solid transparent;border-radius:50%}:host .oui-switch-container.labels{flex:1;min-height:3rem;min-width:8rem;flex-direction:column}:host .oui-switch-container.labels .label-switch-container{flex:1}:host .oui-switch-container.labels .label-switch-container .switch{white-space:nowrap}:host .oui-switch-container.success .switch-track.on{background-color:var(--color-success)}:host .oui-switch-container.danger .switch-track.on{background-color:var(--color-danger)}:host .oui-switch-container.accent .switch-track.on{background-color:var(--color-accent)}:host .oui-switch-container.warning .switch-track.on{background-color:var(--color-warning)}:host .oui-switch-container.primary .switch-track.on{background-color:var(--color-primary)}:host .oui-switch-container.secondary .switch-track.on{background-color:var(--color-secondary)}:host .oui-switch-container.tertiary .switch-track.on{background-color:var(--color-tertiary)}:host .oui-switch-container .switch-track{background-color:var(--oui-switch-track-background-off)}:host .oui-switch-container .switch-track.on{background-color:var(--oui-switch-track-background-on)}:host .oui-switch-container .boolean-switch-container{display:flex;align-items:center;justify-content:center;flex:1}:host .oui-switch-container .boolean-switch-container:hover{cursor:pointer}:host .oui-switch-container .boolean-switch-container:hover .switch-button{background-color:var(--oui-switch-toggle-hover-color)}:host .oui-switch-container .boolean-switch-container .switch-label{margin-left:var(--oui-switch-toggle-label-spacing);font-size:var(--oui-switch-toggle-label-font-size);color:var(--oui-switch-toggle-label-color);font-weight:var(--oui-switch-toggle-label-font-weight)}:host .oui-switch-container .boolean-switch-container .track{position:relative;flex:1;display:flex;align-items:center;justify-content:center;min-width:3rem;max-width:var(--oui-switch-track-max-width)}:host .oui-switch-container .boolean-switch-container .track .switch-track{width:100%;height:10px;border-radius:20px;left:0;transition:background-color .3s}:host .oui-switch-container .boolean-switch-container .track .switch-button{position:absolute;left:0;width:16px;height:16px;border-radius:50%;background-color:var(--oui-switch-toggle-color);border:1px solid var(--border-color-primary);transition:left .3s,background-color .3s}:host .oui-switch-container .boolean-switch-container .track .switch-button.off{left:-8px}:host .oui-switch-container .boolean-switch-container .track .switch-button.on{left:calc(100% - 8px)}:host .oui-switch-container .label-switch-container{display:flex;flex-direction:row;background-color:var(--oui-switch-label-background-color-off);height:100%;width:100%;position:relative;border:0px solid transparent;border-radius:var(--border-radius-default)}:host .oui-switch-container .label-switch-container .switch{display:flex;justify-content:center;align-items:center;pointer-events:none;flex:1;z-index:2;color:var(--oui-switch-label-text-color-off);-webkit-user-select:none;user-select:none;transition:color .3s}:host .oui-switch-container .label-switch-container .switch.selected{color:var(--oui-switch-label-text-color-on)}:host .oui-switch-container .label-switch-container .switch-button{pointer-events:none;z-index:1;position:absolute;height:100%;width:50%;left:0;transition:transform .3s,border-radius .3s,box-shadow .3s;background-color:var(--oui-switch-label-background-color-on);border:0px solid transparent;border-radius:var(--border-radius-default)}:host .oui-switch-container .label-switch-container .switch-button.on{transform:translate(100%);box-shadow:var(--box-shadow-left-large)}:host .oui-switch-container .label-switch-container .switch-button.off{transform:translate(0);box-shadow:var(--box-shadow-right-large)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSwitchComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-switch', standalone: true, imports: [CommonModule], template: "<div class=\"oui-switch-container {{ mode }} {{ type }}\" (click)=\"onClick()\">\n  @if (mode === 'labels') {\n    <div class=\"label-switch-container\">\n      <div class=\"switch-off switch\" [ngClass]=\"{ selected: isSelected('off') }\">\n        {{ getOffLabel() }}\n      </div>\n      <div class=\"switch-on switch\" [ngClass]=\"{ selected: isSelected('on') }\">\n        {{ getOnLabel() }}\n      </div>\n      <div class=\"switch-button\" [ngClass]=\"getButtonClass()\"></div>\n    </div>\n  }\n  @if (mode === 'boolean') {\n    <div class=\"boolean-switch-container\">\n      <div class=\"track\">\n        <div class=\"switch-track\" [ngClass]=\"{ on: isSelected('on') }\"></div>\n        <div class=\"switch-button\" [ngClass]=\"getButtonClass()\"></div>\n      </div>\n      <div class=\"switch-label\">\n        <ng-content class=\"content\"></ng-content>\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{z-index:1;flex:1;min-width:3rem;position:relative;margin-right:8px;display:flex}:host:hover{cursor:pointer}:host .oui-switch-container{height:100%;width:100%;position:relative;display:flex;align-items:center;justify-content:center;border:0px solid transparent;border-radius:50%}:host .oui-switch-container.labels{flex:1;min-height:3rem;min-width:8rem;flex-direction:column}:host .oui-switch-container.labels .label-switch-container{flex:1}:host .oui-switch-container.labels .label-switch-container .switch{white-space:nowrap}:host .oui-switch-container.success .switch-track.on{background-color:var(--color-success)}:host .oui-switch-container.danger .switch-track.on{background-color:var(--color-danger)}:host .oui-switch-container.accent .switch-track.on{background-color:var(--color-accent)}:host .oui-switch-container.warning .switch-track.on{background-color:var(--color-warning)}:host .oui-switch-container.primary .switch-track.on{background-color:var(--color-primary)}:host .oui-switch-container.secondary .switch-track.on{background-color:var(--color-secondary)}:host .oui-switch-container.tertiary .switch-track.on{background-color:var(--color-tertiary)}:host .oui-switch-container .switch-track{background-color:var(--oui-switch-track-background-off)}:host .oui-switch-container .switch-track.on{background-color:var(--oui-switch-track-background-on)}:host .oui-switch-container .boolean-switch-container{display:flex;align-items:center;justify-content:center;flex:1}:host .oui-switch-container .boolean-switch-container:hover{cursor:pointer}:host .oui-switch-container .boolean-switch-container:hover .switch-button{background-color:var(--oui-switch-toggle-hover-color)}:host .oui-switch-container .boolean-switch-container .switch-label{margin-left:var(--oui-switch-toggle-label-spacing);font-size:var(--oui-switch-toggle-label-font-size);color:var(--oui-switch-toggle-label-color);font-weight:var(--oui-switch-toggle-label-font-weight)}:host .oui-switch-container .boolean-switch-container .track{position:relative;flex:1;display:flex;align-items:center;justify-content:center;min-width:3rem;max-width:var(--oui-switch-track-max-width)}:host .oui-switch-container .boolean-switch-container .track .switch-track{width:100%;height:10px;border-radius:20px;left:0;transition:background-color .3s}:host .oui-switch-container .boolean-switch-container .track .switch-button{position:absolute;left:0;width:16px;height:16px;border-radius:50%;background-color:var(--oui-switch-toggle-color);border:1px solid var(--border-color-primary);transition:left .3s,background-color .3s}:host .oui-switch-container .boolean-switch-container .track .switch-button.off{left:-8px}:host .oui-switch-container .boolean-switch-container .track .switch-button.on{left:calc(100% - 8px)}:host .oui-switch-container .label-switch-container{display:flex;flex-direction:row;background-color:var(--oui-switch-label-background-color-off);height:100%;width:100%;position:relative;border:0px solid transparent;border-radius:var(--border-radius-default)}:host .oui-switch-container .label-switch-container .switch{display:flex;justify-content:center;align-items:center;pointer-events:none;flex:1;z-index:2;color:var(--oui-switch-label-text-color-off);-webkit-user-select:none;user-select:none;transition:color .3s}:host .oui-switch-container .label-switch-container .switch.selected{color:var(--oui-switch-label-text-color-on)}:host .oui-switch-container .label-switch-container .switch-button{pointer-events:none;z-index:1;position:absolute;height:100%;width:50%;left:0;transition:transform .3s,border-radius .3s,box-shadow .3s;background-color:var(--oui-switch-label-background-color-on);border:0px solid transparent;border-radius:var(--border-radius-default)}:host .oui-switch-container .label-switch-container .switch-button.on{transform:translate(100%);box-shadow:var(--box-shadow-left-large)}:host .oui-switch-container .label-switch-container .switch-button.off{transform:translate(0);box-shadow:var(--box-shadow-right-large)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { svgElement: [{
                type: ViewChild,
                args: ['svgElement', { static: false }]
            }], pathElement: [{
                type: ViewChild,
                args: ['pathElement', { static: false }]
            }], model: [{
                type: Input
            }], values: [{
                type: Input
            }], labels: [{
                type: Input
            }], type: [{
                type: Input
            }], mode: [{
                type: Input
            }], disableClickToggle: [{
                type: Input
            }], modelChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiSwitchComponent };
//# sourceMappingURL=orbital-ui-switch.mjs.map
