import { AfterViewInit, DestroyRef, EventEmitter, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import { CursorState, ICommonDeckLayerOptions, ISlimCommonDeckLayerOptions } from './typings';
import { OuiDeckComponent } from './deck/deck.component';
import * as i0 from "@angular/core";
export declare abstract class BaseDeckLayer<T extends ISlimCommonDeckLayerOptions | ICommonDeckLayerOptions> implements OnChanges, AfterViewInit, OnDestroy {
    options: T;
    deck: OuiDeckComponent;
    onOptionsChange: EventEmitter<any>;
    private isAdded;
    private options$;
    protected destroyRef: DestroyRef;
    constructor();
    onHover(info: any): void;
    onClick(item: any, event: any): void;
    abstract getLayer(): any;
    getCursor(state: CursorState): string;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseDeckLayer<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BaseDeckLayer<any>, "oui-base-deck-layer", never, { "options": { "alias": "options"; "required": true; }; "deck": { "alias": "deck"; "required": true; }; }, { "onOptionsChange": "onOptionsChange"; }, never, never, true, never>;
}
//# sourceMappingURL=base-deck-layer.component.d.ts.map