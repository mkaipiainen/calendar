import { ScatterplotLayer } from '@deck.gl/layers/typed';
import { ICommonDeckLayerOptions, IDeckScatterplotLayerOptions } from '../typings';
import { BaseDeckLayer } from '../base-deck-layer.component';
import * as i0 from "@angular/core";
export declare class DeckScatterplotLayer extends BaseDeckLayer<ICommonDeckLayerOptions> {
    options: IDeckScatterplotLayerOptions;
    constructor();
    getLayer(): ScatterplotLayer<any, {
        data: any;
        getPosition: (d: any) => [number, number];
        stroked: boolean;
        filled: boolean;
        radiusScale: number;
        radiusMinPixels: number;
        radiusMaxPixels: number;
        lineWidthMinPixels: number;
        lineWidthMaxPixels: number;
        lineWidthUnits: "meters" | "common" | "pixels";
        getRadius: (d: any) => number;
        getFillColor: (d: any) => import("orbital-ui/core").RGBA;
        getLineColor: (d: any) => import("orbital-ui/core").RGBA;
        getLineWidth: (d: any) => number;
        id: string;
        autoHighlight: boolean;
        transitions: {
            [x: string]: number | {
                duration: number;
                easing: any;
            };
        };
        highlightColor: import("orbital-ui/core").RGBA | ((d: any) => import("orbital-ui/core").RGBA);
        isEnabled: boolean;
        _dataDiff: (oldData: any, newData: any) => [{
            startRow: number;
            endRow: number;
        }];
        onClick: (object: any, event: any) => void;
        onHover: (event: any) => boolean;
        updateTriggers: any;
        dataComparator: (<LayerDataT = import("@deck.gl/core/typed").LayerData<unknown>>(newData: LayerDataT, oldData?: LayerDataT | undefined) => boolean) | null;
        getCursor: (data: {
            isHovering: boolean;
            isDragging: boolean;
        }) => string;
        order: number;
        loadOptions: any;
        visible: boolean;
        opacity: number;
        extensions: any[];
        pickable: boolean;
        getDashArray: [number, number];
        dashJustified: boolean;
        dashGapPickable: boolean;
        getOffset: number | (() => number);
        clipBounds: [number, number, number, number];
        maskId: string;
        maskByInstance: boolean;
        maskInverted: boolean;
        operation: "mask";
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeckScatterplotLayer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeckScatterplotLayer, "oui-deck-scatterplot-layer", never, { "options": { "alias": "options"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=deck-scatterplot-layer.d.ts.map