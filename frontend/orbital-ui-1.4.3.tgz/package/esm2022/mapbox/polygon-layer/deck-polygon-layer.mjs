import { PolygonLayer } from '@deck.gl/layers/typed';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { BindCommonDeckOptions } from '../deck/bind-default-deck-options';
import * as i0 from "@angular/core";
export class DeckPolygonLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new PolygonLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            stroked: this.options.stroked ?? true,
            filled: this.options.filled ?? true,
            wireframe: this.options.wireframe ?? false,
            lineWidthMinPixels: this.options.lineWidthMinPixels ?? 1,
            getFillColor: this.options.getFillColor,
            getLineColor: this.options.getLineColor,
            getLineWidth: this.options.getLineWidth,
            getElevation: this.options.getElevation ?? 1,
            getPolygon: this.options.getPolygon,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckPolygonLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckPolygonLayer, isStandalone: true, selector: "oui-deck-polygon-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckPolygonLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-polygon-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay1wb2x5Z29uLWxheWVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9tYXBib3gvcG9seWdvbi1sYXllci9kZWNrLXBvbHlnb24tbGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBR3JELE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM3RCxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQzs7QUFTMUUsTUFBTSxPQUFPLGdCQUFpQixTQUFRLGFBQXNDO0lBQ3ZDLE9BQU8sQ0FBMkI7SUFFckU7UUFDRSxLQUFLLEVBQUUsQ0FBQztJQUNWLENBQUM7SUFFTSxRQUFRO1FBQ2IsT0FBTyxJQUFJLFlBQVksQ0FBQztZQUN0QixHQUFHLHFCQUFxQixDQUFDLElBQUksQ0FBQztZQUM5QixJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ3ZCLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sSUFBSSxJQUFJO1lBQ3JDLE1BQU0sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sSUFBSSxJQUFJO1lBQ25DLFNBQVMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsSUFBSSxLQUFLO1lBQzFDLGtCQUFrQixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsa0JBQWtCLElBQUksQ0FBQztZQUN4RCxZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZO1lBQ3ZDLFlBQVksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVk7WUFDdkMsWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWTtZQUN2QyxZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLElBQUksQ0FBQztZQUM1QyxVQUFVLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVO1NBQ3BDLENBQUMsQ0FBQztJQUNMLENBQUM7dUdBckJVLGdCQUFnQjsyRkFBaEIsZ0JBQWdCLHlJQUxqQixFQUFFOzsyRkFLRCxnQkFBZ0I7a0JBUDVCLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLHdCQUF3QjtvQkFDbEMsUUFBUSxFQUFFLEVBQUU7b0JBQ1osVUFBVSxFQUFFLElBQUk7b0JBQ2hCLE9BQU8sRUFBRSxFQUFFO29CQUNYLGVBQWUsRUFBRSx1QkFBdUIsQ0FBQyxNQUFNO2lCQUNoRDt3REFFb0MsT0FBTztzQkFBekMsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQb2x5Z29uTGF5ZXIgfSBmcm9tICdAZGVjay5nbC9sYXllcnMvdHlwZWQnO1xuaW1wb3J0IHsgR1VJRCB9IGZyb20gJ29yYml0YWwtdWkvaGVscGVycyc7XG5pbXBvcnQgeyBJQ29tbW9uRGVja0xheWVyT3B0aW9ucywgSURlY2tQb2x5Z29uTGF5ZXJPcHRpb25zIH0gZnJvbSAnLi4vdHlwaW5ncyc7XG5pbXBvcnQgeyBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSwgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURlY2tMYXllciB9IGZyb20gJy4uL2Jhc2UtZGVjay1sYXllci5jb21wb25lbnQnO1xuaW1wb3J0IHsgQmluZENvbW1vbkRlY2tPcHRpb25zIH0gZnJvbSAnLi4vZGVjay9iaW5kLWRlZmF1bHQtZGVjay1vcHRpb25zJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLWRlY2stcG9seWdvbi1sYXllcicsXG4gIHRlbXBsYXRlOiAnJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW10sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBEZWNrUG9seWdvbkxheWVyIGV4dGVuZHMgQmFzZURlY2tMYXllcjxJQ29tbW9uRGVja0xheWVyT3B0aW9ucz4ge1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KSBkZWNsYXJlIG9wdGlvbnM6IElEZWNrUG9seWdvbkxheWVyT3B0aW9ucztcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpO1xuICB9XG5cbiAgcHVibGljIGdldExheWVyKCkge1xuICAgIHJldHVybiBuZXcgUG9seWdvbkxheWVyKHtcbiAgICAgIC4uLkJpbmRDb21tb25EZWNrT3B0aW9ucyh0aGlzKSxcbiAgICAgIGRhdGE6IHRoaXMub3B0aW9ucy5kYXRhLFxuICAgICAgc3Ryb2tlZDogdGhpcy5vcHRpb25zLnN0cm9rZWQgPz8gdHJ1ZSxcbiAgICAgIGZpbGxlZDogdGhpcy5vcHRpb25zLmZpbGxlZCA/PyB0cnVlLFxuICAgICAgd2lyZWZyYW1lOiB0aGlzLm9wdGlvbnMud2lyZWZyYW1lID8/IGZhbHNlLFxuICAgICAgbGluZVdpZHRoTWluUGl4ZWxzOiB0aGlzLm9wdGlvbnMubGluZVdpZHRoTWluUGl4ZWxzID8/IDEsXG4gICAgICBnZXRGaWxsQ29sb3I6IHRoaXMub3B0aW9ucy5nZXRGaWxsQ29sb3IsXG4gICAgICBnZXRMaW5lQ29sb3I6IHRoaXMub3B0aW9ucy5nZXRMaW5lQ29sb3IsXG4gICAgICBnZXRMaW5lV2lkdGg6IHRoaXMub3B0aW9ucy5nZXRMaW5lV2lkdGgsXG4gICAgICBnZXRFbGV2YXRpb246IHRoaXMub3B0aW9ucy5nZXRFbGV2YXRpb24gPz8gMSxcbiAgICAgIGdldFBvbHlnb246IHRoaXMub3B0aW9ucy5nZXRQb2x5Z29uLFxuICAgIH0pO1xuICB9XG59XG4iXX0=