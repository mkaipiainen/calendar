// This component should not be used directly, but instead extended in each dialog component.
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { OuiDialogService } from './dialog.service';
import * as i0 from "@angular/core";
/**
 * A parent-component for dialogs. Not meant to be used directly, only inherited.
 */
export class OuiDialogComponent {
    ouiDialogService = inject(OuiDialogService);
    id;
    constructor() { }
    submit(data) {
        this.ouiDialogService.submitDialog(this.id, data);
    }
    cancel(data) {
        this.ouiDialogService.cancelDialog(this.id, data);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiDialogComponent, isStandalone: true, selector: "oui-dialog", ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDialogComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-dialog',
                    template: '',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlhbG9nLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvZGlhbG9nL2RpYWxvZy5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsNkZBQTZGO0FBRTdGLE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNFLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGtCQUFrQixDQUFDOztBQUVwRDs7R0FFRztBQU9ILE1BQU0sT0FBTyxrQkFBa0I7SUFDbkIsZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLGdCQUFnQixDQUFDLENBQUM7SUFDL0MsRUFBRSxDQUFTO0lBRWxCLGdCQUFlLENBQUM7SUFFVCxNQUFNLENBQUMsSUFBVTtRQUN0QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDcEQsQ0FBQztJQUVNLE1BQU0sQ0FBQyxJQUFVO1FBQ3RCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNwRCxDQUFDO3VHQVpVLGtCQUFrQjsyRkFBbEIsa0JBQWtCLHNFQUpuQixFQUFFOzsyRkFJRCxrQkFBa0I7a0JBTjlCLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLFlBQVk7b0JBQ3RCLFFBQVEsRUFBRSxFQUFFO29CQUNaLFVBQVUsRUFBRSxJQUFJO29CQUNoQixlQUFlLEVBQUUsdUJBQXVCLENBQUMsTUFBTTtpQkFDaEQiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBUaGlzIGNvbXBvbmVudCBzaG91bGQgbm90IGJlIHVzZWQgZGlyZWN0bHksIGJ1dCBpbnN0ZWFkIGV4dGVuZGVkIGluIGVhY2ggZGlhbG9nIGNvbXBvbmVudC5cblxuaW1wb3J0IHsgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksIENvbXBvbmVudCwgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPdWlEaWFsb2dTZXJ2aWNlIH0gZnJvbSAnLi9kaWFsb2cuc2VydmljZSc7XG5cbi8qKlxuICogQSBwYXJlbnQtY29tcG9uZW50IGZvciBkaWFsb2dzLiBOb3QgbWVhbnQgdG8gYmUgdXNlZCBkaXJlY3RseSwgb25seSBpbmhlcml0ZWQuXG4gKi9cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1kaWFsb2cnLFxuICB0ZW1wbGF0ZTogJycsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlEaWFsb2dDb21wb25lbnQge1xuICBwcm90ZWN0ZWQgb3VpRGlhbG9nU2VydmljZSA9IGluamVjdChPdWlEaWFsb2dTZXJ2aWNlKTtcbiAgcHVibGljIGlkOiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3IoKSB7fVxuXG4gIHB1YmxpYyBzdWJtaXQoZGF0YT86IGFueSkge1xuICAgIHRoaXMub3VpRGlhbG9nU2VydmljZS5zdWJtaXREaWFsb2codGhpcy5pZCwgZGF0YSk7XG4gIH1cblxuICBwdWJsaWMgY2FuY2VsKGRhdGE/OiBhbnkpIHtcbiAgICB0aGlzLm91aURpYWxvZ1NlcnZpY2UuY2FuY2VsRGlhbG9nKHRoaXMuaWQsIGRhdGEpO1xuICB9XG59XG4iXX0=