export declare function goForward(date: Date, mode: 'day' | 'month' | 'year'): Date;
export declare const DEFAULT_TRANSLATIONS: {
    months: string[];
    days: string[];
};
export declare function goBackwards(date: Date, mode: 'day' | 'month' | 'year'): Date;
export declare function generateWeeks(startDate: Date): Date[][];
export declare function generateMonths(currentDate: Date): Date[][];
export declare function generateYears(currentDate: Date): Date[][];
//# sourceMappingURL=date-picker-helpers.d.ts.map