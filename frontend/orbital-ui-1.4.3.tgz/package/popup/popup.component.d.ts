import { IPopup, OuiPopupService } from './popup.service';
import * as i0 from "@angular/core";
/**
 * This component should not be used directly, but instead extended in each popup component.
 * Popups can be opened with ouiPopupService.
 */
export declare class OuiPopupComponent {
    protected ouiPopupService: OuiPopupService;
    popup: IPopup;
    constructor();
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiPopupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiPopupComponent, "oui-popup", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=popup.component.d.ts.map