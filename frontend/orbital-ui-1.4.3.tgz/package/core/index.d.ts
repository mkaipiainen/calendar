/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/core" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-core.d.ts.map