/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/dropdown" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-dropdown.d.ts.map