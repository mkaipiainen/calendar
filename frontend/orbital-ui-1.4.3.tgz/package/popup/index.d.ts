/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/popup" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-popup.d.ts.map