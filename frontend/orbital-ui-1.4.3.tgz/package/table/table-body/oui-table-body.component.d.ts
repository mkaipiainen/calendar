import { AfterViewInit, ChangeDetectorRef, DestroyRef, ElementRef, Renderer2, ViewContainerRef } from '@angular/core';
import { TableService } from '../table.service';
import { IOuiTableCombinedOptions, IOuiTableInternalItem } from '../types';
import * as i0 from "@angular/core";
export declare class OuiTableBodyComponent implements AfterViewInit {
    private destroyRef;
    private cdr;
    private elementRef;
    private renderer;
    bodyWrapper: ElementRef;
    rowVCR: ViewContainerRef;
    tableService: TableService;
    options: IOuiTableCombinedOptions;
    private unlisteners;
    private throttledSetScrollTop;
    items: import("@angular/core").WritableSignal<IOuiTableInternalItem[]>;
    indexTo: import("@angular/core").WritableSignal<number>;
    constructor(destroyRef: DestroyRef, cdr: ChangeDetectorRef, elementRef: ElementRef, renderer: Renderer2);
    ngAfterViewInit(): void;
    trackItem: (index: number, item: IOuiTableInternalItem) => any;
    private setScrollTop;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiTableBodyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiTableBodyComponent, "oui-table-body", never, { "tableService": { "alias": "tableService"; "required": true; }; "options": { "alias": "options"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=oui-table-body.component.d.ts.map