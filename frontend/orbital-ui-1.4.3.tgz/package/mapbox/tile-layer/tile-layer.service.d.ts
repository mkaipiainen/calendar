import { NgZone } from '@angular/core';
import { IDeckTileLayerOptions } from '../typings';
import { Observable } from 'rxjs';
import { RequestQueueService } from 'orbital-ui/core';
import { ImageBrokerOpticalImage } from 'orbital-ui/core';
import * as i0 from "@angular/core";
export type IGetTileLayerOptions = IGetTileLayerOpticalImageOptions | IGetTileLayerCustomDataOptions;
export interface IGetCommonTileLayerOptions {
    id: string;
    isWebMercator?: boolean;
    useCache?: boolean;
    accessToken$?: Observable<string>;
    refreshedAccessToken$?: Observable<string>;
    isWmts?: boolean;
    origin: string;
}
export interface IGetTileLayerOpticalImageOptions extends IGetCommonTileLayerOptions {
    buildUrl?: (url: ImageBrokerOpticalImage, options: IGetTileLayerOptions) => string;
    data: ImageBrokerOpticalImage[] | string[];
}
export interface IGetTileLayerCustomDataOptions extends IGetCommonTileLayerOptions {
    id: string;
    isWebMercator?: boolean;
    useCache?: boolean;
    data: Exclude<any, ImageBrokerOpticalImage>[];
    buildUrl: (url: Exclude<any, ImageBrokerOpticalImage>, options: IGetTileLayerOptions) => string;
    origin: string;
    accessToken$: Observable<string>;
    refreshedAccessToken$: Observable<string>;
}
/**
 * Service to handle fetching of raster-layers for the map.
 * Caches tiles in memory to prevent unnecessary requests.
 * Handles canceling of requests in case of the layer getting removed from the map, or the map being destroyed, and so on.
 * Also handles attaching the access token to the requests.
 */
export declare class TileLayerService {
    private requestQueueService;
    private zone;
    private cachedTiles;
    constructor(requestQueueService: RequestQueueService, zone: NgZone);
    /**
     * Returns a Deck.GL tileLayer-configuration for a map. This should work out of the gate by just giving the function
     * a unique ID (IMPORTANT), and the desired opticalImage-object. The function will then handle the rest.
     * @param id
     * @param data
     * @param options
     * @param layerOptions
     */
    getTileLayer(options: IGetTileLayerOptions, layerOptions?: Partial<IDeckTileLayerOptions>): IDeckTileLayerOptions;
    private defaultUrlBuilder;
    private responseToObjectUrl;
    private latLonToMercator;
    clearCache(id?: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TileLayerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TileLayerService>;
}
//# sourceMappingURL=tile-layer.service.d.ts.map