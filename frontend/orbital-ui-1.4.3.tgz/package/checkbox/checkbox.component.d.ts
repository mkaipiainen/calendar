import { AfterViewInit, ChangeDetectorRef, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * A component used to display checkboxes. Can either work as a simple boolean on/off switch, or as a way to selectively
 * add/remove values from an array. If the passed in model is an array, then when turned on, the value of the checkbox will be
 * added to the array/vice versa. If the pasesd in model is a boolean, then checkbox functions as a on/off switch.
 *
 * Example-usage:
 *
 * Boolean mode:
 *
 * <oui-checkbox [(model)]="isEnabled">Check this if you want the item to be enabled</oui-checkbox>
 *
 * Array mode:
 *
 * <oui-checkbox [(model)]="selectedItems" value="'first_item'">First item</oui-checkbox>
 * <oui-checkbox [(model)]="selectedItems" value="'second_item'">Second item</oui-checkbox>
 * <oui-checkbox [(model)]="selectedItems" value="'third_item'">Third item</oui-checkbox>
 */
export declare class OuiCheckboxComponent implements AfterViewInit, OnChanges {
    private cdr;
    /**
     *  either a boolean or an array. If an array is given, then the value of the checkbox will either be
     *  removed or added to the model when checked/unchecked.
     */
    model: any;
    /**
     * if model is an array, then this value will be added to the array if checkbox is checked.
     * If using boolean mode, then this field is ignored.
     */
    value: any;
    /**
     * whether or not a faint 'ghost'-checkmark should appear on the checkbox.
     */
    ghostSelect: boolean;
    /**
     * Used together with array-mode if passing in an array of objects. This is the key that will be used to figure out
     * whether a given checkbox is selected.
     */
    idKey: string;
    /**
     * emitted when model changes (with the current model)
     */
    modelChange: EventEmitter<any>;
    disabled: boolean;
    internalModel: boolean;
    constructor(cdr: ChangeDetectorRef);
    ngAfterViewInit(): void;
    emitChange(value: any): void;
    private setIsChecked;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiCheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiCheckboxComponent, "oui-checkbox", never, { "model": { "alias": "model"; "required": false; }; "value": { "alias": "value"; "required": false; }; "ghostSelect": { "alias": "ghostSelect"; "required": false; }; "idKey": { "alias": "idKey"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "modelChange": "modelChange"; }, never, ["*"], true, never>;
}
//# sourceMappingURL=checkbox.component.d.ts.map