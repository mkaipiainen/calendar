export * from './ripple.directive';
//# sourceMappingURL=public-api.d.ts.map