import { ApplicationRef, EnvironmentInjector, NgZone, RendererFactory2 } from '@angular/core';
import { Router } from '@angular/router';
import { PositioningStrategy, State, VirtualElement } from '@popperjs/core';
import { Placement } from '@popperjs/core';
import { ComponentType } from '@angular/cdk/overlay';
import { OuiPopupComponent } from './popup.component';
import * as i0 from "@angular/core";
export interface IPopupOptions {
    modifiers?: {
        name: string;
        options: any;
    }[];
    placement?: Placement;
    strategy?: PositioningStrategy;
    onFirstUpdate?: (arg0: Partial<State>) => void;
    id?: string;
    closeOnEscape?: boolean;
    closeOnOutsideClick?: boolean;
}
export interface IPopup {
    popperRef: any;
    popupElement: HTMLElement;
    componentRef: any;
    id: string;
    options: IPopupOptions;
    isInitialised: boolean;
}
/**
 * Service to open popups. Uses popper.js under the hood.
 * You can create popups by passing any custom component together with options to the openPopup() method.
 *
 * The options object can contain the following properties:
 *
 * modifiers: Array of modifiers to be passed to popper.js. Optional and generally only necessary for edge-cases. See https://popper.js.org/docs/v2/modifiers/ for more info.
 * placement: Placement of the popup. Optional and defaults to 'bottom'. See https://popper.js.org/docs/v2/constructors/#placement for more info.
 * strategy: Positioning strategy. Optional and defaults to 'absolute'. Rarely needed. See https://popper.js.org/docs/v2/constructors/#strategy for more info.
 * onFirstUpdate: Callback to be called when the popup is first positioned. Optional. See https://popper.js.org/docs/v2/constructors/#onfirstupdate for more info.
 * id: Id of the popup. Optional. If not provided, a random id will be generated.
 * closeOnEscape: Whether the popup should be closed when the escape key is pressed.
 *
 * The last parameter takes an origin, which the popup will be positioned on. This can be either a DOM element or a virtual element.
 * A virtual element is an object with a getBoundingClientRect() method that returns a DOMRect object.
 * See https://popper.js.org/docs/v2/virtual-elements/ for more info.
 * If no origin is provided, the popup will be positioned on the document body.
 *
 * An arrow can be created automatically by passing in the arrow modifier. See https://popper.js.org/docs/v2/modifiers/arrow/ for more info.
 *
 * Some default modifiers are applied to each popup:
 * - PreventOverflow: prevents the popup from overflowing outside of the window. See https://popper.js.org/docs/v2/modifiers/prevent-overflow/ for more info.
 *
 *
 * An example usecase for a simple popup with an arrow, popup placed to the top left and closeOnEscape enabled.
 * The example popup uses a component called MyPopupComponent which has an input called myInput with a value 'myValue'.
 *
 * const popupOptions: IPopupOptions = {
 *    modifiers: [{
 *      name: 'arrow',
 *        options: {
 *          color: 'var(--color-background)',
 *        }
 *      }
 *    ],
 *    placement: 'top-start',
 *    closeOnEscape: true,
 *  }
 *
 *  this.popupService.openPopup(MyPopupComponent, {myInput: 'myValue'}, popupOptions);
 *
 */
export declare class OuiPopupService {
    private router;
    private zone;
    private appRef;
    private injector;
    private rendererFactory;
    private document;
    private openPopups;
    private popupOpenSubject;
    private popupClosedSubject;
    popupOpen$: import("rxjs").Observable<IPopup>;
    popupClosed$: import("rxjs").Observable<IPopup>;
    private renderer;
    constructor(router: Router, zone: NgZone, appRef: ApplicationRef, injector: EnvironmentInjector, rendererFactory: RendererFactory2, document: Document);
    onEscapePress(): void;
    private onDocumentClick;
    destroyPopups(): void;
    openPopup<T extends OuiPopupComponent>(content: ComponentType<T>, inputs: {
        [x: string]: unknown;
    }, options?: IPopupOptions, origin?: HTMLElement | VirtualElement): IPopup;
    dispose(id: string): void;
    private doDispose;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiPopupService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiPopupService>;
}
//# sourceMappingURL=popup.service.d.ts.map