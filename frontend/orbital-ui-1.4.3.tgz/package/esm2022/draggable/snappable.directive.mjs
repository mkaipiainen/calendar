import { Directive, Input, } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "./draggable.service";
export class OuiSnappableDirective {
    draggableService;
    elementRef;
    ouiSnappable;
    constructor(draggableService, elementRef) {
        this.draggableService = draggableService;
        this.elementRef = elementRef;
    }
    ngAfterViewInit() {
        this.draggableService.addSnappable(this.elementRef, this.ouiSnappable);
    }
    ngOnDestroy() {
        this.draggableService.removeSnappable(this.elementRef, this.ouiSnappable);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSnappableDirective, deps: [{ token: i1.OuiDraggableService }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.1", type: OuiSnappableDirective, isStandalone: true, selector: "[ouiSnappable]", inputs: { ouiSnappable: "ouiSnappable" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSnappableDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ouiSnappable]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i1.OuiDraggableService }, { type: i0.ElementRef }], propDecorators: { ouiSnappable: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic25hcHBhYmxlLmRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvZHJhZ2dhYmxlL3NuYXBwYWJsZS5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUVMLFNBQVMsRUFFVCxLQUFLLEdBRU4sTUFBTSxlQUFlLENBQUM7OztBQU92QixNQUFNLE9BQU8scUJBQXFCO0lBR3RCO0lBQ0E7SUFIaUIsWUFBWSxDQUFTO0lBQ2hELFlBQ1UsZ0JBQXFDLEVBQ3JDLFVBQXNCO1FBRHRCLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBcUI7UUFDckMsZUFBVSxHQUFWLFVBQVUsQ0FBWTtJQUM3QixDQUFDO0lBRUcsZUFBZTtRQUNwQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3pFLENBQUM7SUFFTSxXQUFXO1FBQ2hCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDNUUsQ0FBQzt1R0FiVSxxQkFBcUI7MkZBQXJCLHFCQUFxQjs7MkZBQXJCLHFCQUFxQjtrQkFKakMsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsZ0JBQWdCO29CQUMxQixVQUFVLEVBQUUsSUFBSTtpQkFDakI7aUhBRTRCLFlBQVk7c0JBQXRDLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgRGlyZWN0aXZlLFxuICBFbGVtZW50UmVmLFxuICBJbnB1dCxcbiAgT25EZXN0cm95LFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE91aURyYWdnYWJsZVNlcnZpY2UgfSBmcm9tICcuL2RyYWdnYWJsZS5zZXJ2aWNlJztcblxuQERpcmVjdGl2ZSh7XG4gIHNlbGVjdG9yOiAnW291aVNuYXBwYWJsZV0nLFxuICBzdGFuZGFsb25lOiB0cnVlLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlTbmFwcGFibGVEaXJlY3RpdmUgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KSBvdWlTbmFwcGFibGU6IHN0cmluZztcbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSBkcmFnZ2FibGVTZXJ2aWNlOiBPdWlEcmFnZ2FibGVTZXJ2aWNlLFxuICAgIHByaXZhdGUgZWxlbWVudFJlZjogRWxlbWVudFJlZlxuICApIHt9XG5cbiAgcHVibGljIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICB0aGlzLmRyYWdnYWJsZVNlcnZpY2UuYWRkU25hcHBhYmxlKHRoaXMuZWxlbWVudFJlZiwgdGhpcy5vdWlTbmFwcGFibGUpO1xuICB9XG5cbiAgcHVibGljIG5nT25EZXN0cm95KCkge1xuICAgIHRoaXMuZHJhZ2dhYmxlU2VydmljZS5yZW1vdmVTbmFwcGFibGUodGhpcy5lbGVtZW50UmVmLCB0aGlzLm91aVNuYXBwYWJsZSk7XG4gIH1cbn1cbiJdfQ==