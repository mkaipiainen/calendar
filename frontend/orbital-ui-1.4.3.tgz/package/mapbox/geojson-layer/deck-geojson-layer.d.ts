import { GeoJsonLayer } from '@deck.gl/layers/typed';
import { ICommonDeckLayerOptions, IDeckGeoJsonLayerOptions } from '../typings';
import { BaseDeckLayer } from '../base-deck-layer.component';
import * as i0 from "@angular/core";
export declare class DeckGeojsonLayer extends BaseDeckLayer<ICommonDeckLayerOptions> {
    options: IDeckGeoJsonLayerOptions;
    constructor();
    getLayer(): GeoJsonLayer<{
        data: import("@turf/helpers").FeatureCollection<import("@turf/helpers").Geometry | import("@turf/helpers").GeometryCollection, import("@turf/helpers").Properties>;
        pointType: "icon" | "text" | "circle";
        lineWidthScale: number;
        lineWidthMinPixels: number;
        lineWidthMaxPixels: number;
        lineWithUnits: "meters" | "common" | "pixels";
        getFillColor: import("orbital-ui/core").RGBA | ((d: any) => import("orbital-ui/core").RGBA);
        getLineColor: import("orbital-ui/core").RGBA | ((d: any) => import("orbital-ui/core").RGBA);
        getPointRadius: number | ((d: any) => number);
        getLineWidth: number | ((d: any) => number);
        getElevation: number | ((d: any) => number);
        extruded: boolean;
        id: string;
        autoHighlight: boolean;
        transitions: {
            [x: string]: number | {
                duration: number;
                easing: any;
            };
        };
        highlightColor: import("orbital-ui/core").RGBA | ((d: any) => import("orbital-ui/core").RGBA);
        isEnabled: boolean;
        _dataDiff: (oldData: any, newData: any) => [{
            startRow: number;
            endRow: number;
        }];
        onClick: (object: any, event: any) => void;
        onHover: (event: any) => boolean;
        updateTriggers: any;
        dataComparator: (<LayerDataT = import("@deck.gl/core/typed").LayerData<unknown>>(newData: LayerDataT, oldData?: LayerDataT | undefined) => boolean) | null;
        getCursor: (data: {
            isHovering: boolean;
            isDragging: boolean;
        }) => string;
        order: number;
        loadOptions: any;
        visible: boolean;
        opacity: number;
        extensions: any[];
        pickable: boolean;
        getDashArray: [number, number];
        dashJustified: boolean;
        dashGapPickable: boolean;
        getOffset: number | (() => number);
        clipBounds: [number, number, number, number];
        maskId: string;
        maskByInstance: boolean;
        maskInverted: boolean;
        operation: "mask";
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeckGeojsonLayer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeckGeojsonLayer, "oui-deck-geojson-layer", never, { "options": { "alias": "options"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=deck-geojson-layer.d.ts.map