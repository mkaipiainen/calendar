import { ApplicationRef, ComponentRef, ElementRef, EnvironmentInjector, RendererFactory2 } from '@angular/core';
import { OuiToastComponent } from './toast.component';
import { ComponentType } from '@angular/cdk/overlay';
import * as i0 from "@angular/core";
export type IToastType = 'success' | 'error' | 'warning' | 'info';
export type IToastPosition = IToastFixedPosition | IToastHardcodedPosition;
export type IToastFixedPosition = {
    x: number;
    y: number;
};
export type IToastHardcodedPosition = 'top-left' | 'top-right' | 'top' | 'bottom-left' | 'bottom-right' | 'bottom' | 'center';
export interface IOuiToastOptions {
    type: IToastType;
    duration?: number;
    hideOnClick?: boolean;
    xToClose?: boolean;
    id?: string;
    title?: string;
    position?: IToastPosition;
    content: string | ComponentType<any>;
}
export interface IOuiToastDefaultOptions {
    position: IToastPosition;
    xToClose: boolean;
    hideOnClick: boolean;
    duration: number;
}
export interface ICombinedOuiToastOptions extends IOuiToastOptions {
    duration: number;
    hideOnClick: boolean;
    xToClose: boolean;
    position: IToastPosition;
    id: string;
    inputs?: {
        [x: string]: unknown;
    };
}
/**
 * Service used to display toast-messages to the user. These are messages that usually happen in response to a user-action,
 * for example saving an entity, or creating a new one, or deleting an existign one, etc.
 *
 * You can decide which corner the toast appears in, as well as things like the duration, the type of the toast, and the content.
 * Generally you only want to pass in strings as the content, but in cases where you need something totally unique, you can pass in a
 * component as well.
 *
 * Usage-example:
 *
 * this.ouiToastService.open({
 *   type: 'success',
 *   content: 'Succesfully saved the entity!',
 *   duration: 5000
 * });
 */
export declare class OuiToastService {
    private injector;
    private appRef;
    private rendererFactory;
    private document;
    defaultOptions: IOuiToastDefaultOptions;
    currentToasts: Map<string, ComponentRef<OuiToastComponent>>;
    currentToastWrappers: Map<any, any>;
    private renderer;
    constructor(injector: EnvironmentInjector, appRef: ApplicationRef, rendererFactory: RendererFactory2, document: Document);
    open(options: IOuiToastOptions, inputs?: {
        [x: string]: unknown;
    }, parent?: ElementRef): void;
    private createWrapper;
    private createToast;
    disable(id: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiToastService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiToastService>;
}
//# sourceMappingURL=toast.service.d.ts.map