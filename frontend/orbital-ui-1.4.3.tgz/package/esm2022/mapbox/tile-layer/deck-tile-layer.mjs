import { TileLayer } from '@deck.gl/geo-layers/typed';
import { BitmapLayer } from '@deck.gl/layers/typed';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BindCommonDeckOptions } from '../deck/bind-default-deck-options';
import * as i0 from "@angular/core";
export class DeckTileLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new TileLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            minZoom: this.options.minZoom ?? 0,
            maxZoom: this.options.maxZoom ?? 24,
            tileSize: this.options.tileSize ?? 256,
            renderSubLayers: this.options.renderSubLayers
                ? this.options.renderSubLayers
                : (props) => {
                    const { bbox: { west, south, east, north }, } = props.tile;
                    return new BitmapLayer({ ...props }, {
                        data: undefined,
                        // image: parse(props.data.body, ImageLoader),
                        image: props.data,
                        transparentColor: [0, 0, 0, 0],
                        bounds: [west, south, east, north],
                    });
                },
            getTileData: this.options.getTileData,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckTileLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckTileLayer, isStandalone: true, selector: "oui-deck-tile-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckTileLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-tile-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay10aWxlLWxheWVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9tYXBib3gvdGlsZS1sYXllci9kZWNrLXRpbGUtbGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQ3RELE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUVwRCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDN0QsT0FBTyxFQUFFLHVCQUF1QixFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFFMUUsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sbUNBQW1DLENBQUM7O0FBUzFFLE1BQU0sT0FBTyxhQUFjLFNBQVEsYUFBc0M7SUFDcEMsT0FBTyxDQUF3QjtJQUVsRTtRQUNFLEtBQUssRUFBRSxDQUFDO0lBQ1YsQ0FBQztJQUVNLFFBQVE7UUFDYixPQUFPLElBQUksU0FBUyxDQUFDO1lBQ25CLEdBQUcscUJBQXFCLENBQUMsSUFBSSxDQUFDO1lBQzlCLElBQUksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUk7WUFDdkIsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxJQUFJLENBQUM7WUFDbEMsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxJQUFJLEVBQUU7WUFDbkMsUUFBUSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxJQUFJLEdBQUc7WUFDdEMsZUFBZSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZTtnQkFDM0MsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZTtnQkFDOUIsQ0FBQyxDQUFDLENBQUMsS0FBVSxFQUFFLEVBQUU7b0JBQ2IsTUFBTSxFQUNKLElBQUksRUFBRSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxHQUNuQyxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUM7b0JBQ2YsT0FBTyxJQUFJLFdBQVcsQ0FDcEIsRUFBRSxHQUFHLEtBQUssRUFBRSxFQUNaO3dCQUNFLElBQUksRUFBRSxTQUFTO3dCQUNmLDhDQUE4Qzt3QkFDOUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxJQUFJO3dCQUNqQixnQkFBZ0IsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQzt3QkFDOUIsTUFBTSxFQUFFLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSyxDQUFDO3FCQUNuQyxDQUNGLENBQUM7Z0JBQ0osQ0FBQztZQUNMLFdBQVcsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVc7U0FDdEMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQzt1R0FqQ1UsYUFBYTsyRkFBYixhQUFhLHNJQUxkLEVBQUU7OzJGQUtELGFBQWE7a0JBUHpCLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLHFCQUFxQjtvQkFDL0IsUUFBUSxFQUFFLEVBQUU7b0JBQ1osVUFBVSxFQUFFLElBQUk7b0JBQ2hCLE9BQU8sRUFBRSxFQUFFO29CQUNYLGVBQWUsRUFBRSx1QkFBdUIsQ0FBQyxNQUFNO2lCQUNoRDt3REFFb0MsT0FBTztzQkFBekMsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBUaWxlTGF5ZXIgfSBmcm9tICdAZGVjay5nbC9nZW8tbGF5ZXJzL3R5cGVkJztcbmltcG9ydCB7IEJpdG1hcExheWVyIH0gZnJvbSAnQGRlY2suZ2wvbGF5ZXJzL3R5cGVkJztcbmltcG9ydCB7IEdVSUQgfSBmcm9tICdvcmJpdGFsLXVpL2hlbHBlcnMnO1xuaW1wb3J0IHsgQmFzZURlY2tMYXllciB9IGZyb20gJy4uL2Jhc2UtZGVjay1sYXllci5jb21wb25lbnQnO1xuaW1wb3J0IHsgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksIENvbXBvbmVudCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IElDb21tb25EZWNrTGF5ZXJPcHRpb25zLCBJRGVja1RpbGVMYXllck9wdGlvbnMgfSBmcm9tICcuLi90eXBpbmdzJztcbmltcG9ydCB7IEJpbmRDb21tb25EZWNrT3B0aW9ucyB9IGZyb20gJy4uL2RlY2svYmluZC1kZWZhdWx0LWRlY2stb3B0aW9ucyc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1kZWNrLXRpbGUtbGF5ZXInLFxuICB0ZW1wbGF0ZTogJycsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtdLFxuICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcbn0pXG5leHBvcnQgY2xhc3MgRGVja1RpbGVMYXllciBleHRlbmRzIEJhc2VEZWNrTGF5ZXI8SUNvbW1vbkRlY2tMYXllck9wdGlvbnM+IHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSkgZGVjbGFyZSBvcHRpb25zOiBJRGVja1RpbGVMYXllck9wdGlvbnM7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHB1YmxpYyBnZXRMYXllcigpIHtcbiAgICByZXR1cm4gbmV3IFRpbGVMYXllcih7XG4gICAgICAuLi5CaW5kQ29tbW9uRGVja09wdGlvbnModGhpcyksXG4gICAgICBkYXRhOiB0aGlzLm9wdGlvbnMuZGF0YSxcbiAgICAgIG1pblpvb206IHRoaXMub3B0aW9ucy5taW5ab29tID8/IDAsXG4gICAgICBtYXhab29tOiB0aGlzLm9wdGlvbnMubWF4Wm9vbSA/PyAyNCxcbiAgICAgIHRpbGVTaXplOiB0aGlzLm9wdGlvbnMudGlsZVNpemUgPz8gMjU2LFxuICAgICAgcmVuZGVyU3ViTGF5ZXJzOiB0aGlzLm9wdGlvbnMucmVuZGVyU3ViTGF5ZXJzXG4gICAgICAgID8gdGhpcy5vcHRpb25zLnJlbmRlclN1YkxheWVyc1xuICAgICAgICA6IChwcm9wczogYW55KSA9PiB7XG4gICAgICAgICAgICBjb25zdCB7XG4gICAgICAgICAgICAgIGJib3g6IHsgd2VzdCwgc291dGgsIGVhc3QsIG5vcnRoIH0sXG4gICAgICAgICAgICB9ID0gcHJvcHMudGlsZTtcbiAgICAgICAgICAgIHJldHVybiBuZXcgQml0bWFwTGF5ZXIoXG4gICAgICAgICAgICAgIHsgLi4ucHJvcHMgfSxcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGRhdGE6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICAvLyBpbWFnZTogcGFyc2UocHJvcHMuZGF0YS5ib2R5LCBJbWFnZUxvYWRlciksXG4gICAgICAgICAgICAgICAgaW1hZ2U6IHByb3BzLmRhdGEsXG4gICAgICAgICAgICAgICAgdHJhbnNwYXJlbnRDb2xvcjogWzAsIDAsIDAsIDBdLFxuICAgICAgICAgICAgICAgIGJvdW5kczogW3dlc3QsIHNvdXRoLCBlYXN0LCBub3J0aF0sXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSxcbiAgICAgIGdldFRpbGVEYXRhOiB0aGlzLm9wdGlvbnMuZ2V0VGlsZURhdGEsXG4gICAgfSk7XG4gIH1cbn1cbiJdfQ==