export * from './tabs.component';
export * from './tabs.service';
export * from './tab.component';
//# sourceMappingURL=public-api.d.ts.map