import { Feature as OlFeature } from 'ol';
import { OpenlayersBaseLayerComponent } from './openlayers-base-layer.component';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import { OuiOpenLayersCombinedIconLayerOptions, OuiOpenLayersIconLayerOptions } from '../types';
import * as i0 from "@angular/core";
export declare class OpenlayersIconLayerComponent extends OpenlayersBaseLayerComponent<OuiOpenLayersIconLayerOptions> {
    options: import("@angular/core").InputSignal<OuiOpenLayersIconLayerOptions>;
    combinedOptions: import("@angular/core").Signal<OuiOpenLayersCombinedIconLayerOptions>;
    source: import("@angular/core").WritableSignal<VectorSource<OlFeature<import("ol/geom").Geometry>>>;
    layer: import("@angular/core").WritableSignal<VectorLayer<VectorSource<OlFeature<import("ol/geom").Geometry>>>>;
    constructor();
    private getStyleForFeature;
    onHover(feature: OlFeature): void;
    onUnHover(feature: OlFeature): void;
    updateLayer(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpenlayersIconLayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpenlayersIconLayerComponent, "oui-openlayers-icon-layer", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=openlayers-icon-layer.component.d.ts.map