import { ChangeDetectionStrategy, Component, EventEmitter, Output, ViewChild, } from '@angular/core';
import { fromEvent } from 'rxjs';
import { CommonModule } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
/**
 * Component that can be used to add a dropzone into which you can drop files.
 * The dropped files are then emited via the filesUploaded-output, after which you can do what you want with them
 * Example use:
 *
 * <oui-file-dropzone (filesUploaded)="onFileUpload($event)"></oui-file-dropzone>
 */
export class OuiFileDropzoneComponent {
    elementRef;
    destroyRef;
    dropzoneContainer;
    imageDisplay;
    icon;
    /**
     *   The event that's triggered after user drags files into the dropzone
     */
    filesUploaded = new EventEmitter();
    isImageDisplayed = false;
    constructor(elementRef, destroyRef) {
        this.elementRef = elementRef;
        this.destroyRef = destroyRef;
    }
    ngAfterViewInit() {
        fromEvent(this.elementRef.nativeElement, 'dragover')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            this.dropzoneContainer.nativeElement.classList.add('hovered');
            event.stopPropagation();
            event.preventDefault();
        });
        fromEvent(this.elementRef.nativeElement, 'dragleave')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            this.dropzoneContainer.nativeElement.classList.remove('hovered');
            event.stopPropagation();
            event.preventDefault();
        });
        fromEvent(this.elementRef.nativeElement, 'drop')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            event.stopPropagation();
            event.preventDefault();
            this.filesUploaded.emit(event.dataTransfer.files);
        });
        this.icon.nativeElement.style.backgroundImage =
            "url('assets/icons/attachments.svg')";
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiFileDropzoneComponent, deps: [{ token: i0.ElementRef }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiFileDropzoneComponent, isStandalone: true, selector: "oui-file-dropzone", outputs: { filesUploaded: "filesUploaded" }, viewQueries: [{ propertyName: "dropzoneContainer", first: true, predicate: ["dropzoneContainer"], descendants: true }, { propertyName: "imageDisplay", first: true, predicate: ["imageDisplay"], descendants: true }, { propertyName: "icon", first: true, predicate: ["icon"], descendants: true }], ngImport: i0, template: "<div class=\"oui-file-dropzone-container\" #dropzoneContainer>\n  <div\n    class=\"attachments-icon\"\n    [ngClass]=\"{ hide: isImageDisplayed }\"\n    #icon\n  ></div>\n  <div\n    class=\"image-display\"\n    [ngClass]=\"{ show: isImageDisplayed }\"\n    #imageDisplay\n  ></div>\n</div>\n", styles: [":host{width:100%;height:100%;position:relative}:host .oui-file-dropzone-container{width:100%;height:100%;display:flex;justify-content:center;align-items:center}:host .oui-file-dropzone-container:hover{cursor:pointer}:host .oui-file-dropzone-container:hover .attachments-icon{filter:brightness(2)}:host .oui-file-dropzone-container.hovered .attachments-icon{filter:brightness(2)}:host .oui-file-dropzone-container .attachments-icon{background-size:contain;background-repeat:no-repeat;background-position:center;flex:1;height:100%;width:100%;opacity:1;position:relative}:host .oui-file-dropzone-container .attachments-icon.hide{opacity:0;position:absolute;pointer-events:none}:host .oui-file-dropzone-container .image-display{height:100%;width:100%;opacity:0;pointer-events:none;position:absolute}:host .oui-file-dropzone-container .image-display.show{opacity:1;pointer-events:all;position:relative}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiFileDropzoneComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-file-dropzone', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"oui-file-dropzone-container\" #dropzoneContainer>\n  <div\n    class=\"attachments-icon\"\n    [ngClass]=\"{ hide: isImageDisplayed }\"\n    #icon\n  ></div>\n  <div\n    class=\"image-display\"\n    [ngClass]=\"{ show: isImageDisplayed }\"\n    #imageDisplay\n  ></div>\n</div>\n", styles: [":host{width:100%;height:100%;position:relative}:host .oui-file-dropzone-container{width:100%;height:100%;display:flex;justify-content:center;align-items:center}:host .oui-file-dropzone-container:hover{cursor:pointer}:host .oui-file-dropzone-container:hover .attachments-icon{filter:brightness(2)}:host .oui-file-dropzone-container.hovered .attachments-icon{filter:brightness(2)}:host .oui-file-dropzone-container .attachments-icon{background-size:contain;background-repeat:no-repeat;background-position:center;flex:1;height:100%;width:100%;opacity:1;position:relative}:host .oui-file-dropzone-container .attachments-icon.hide{opacity:0;position:absolute;pointer-events:none}:host .oui-file-dropzone-container .image-display{height:100%;width:100%;opacity:0;pointer-events:none;position:absolute}:host .oui-file-dropzone-container .image-display.show{opacity:1;pointer-events:all;position:relative}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.DestroyRef }], propDecorators: { dropzoneContainer: [{
                type: ViewChild,
                args: ['dropzoneContainer']
            }], imageDisplay: [{
                type: ViewChild,
                args: ['imageDisplay']
            }], icon: [{
                type: ViewChild,
                args: ['icon']
            }], filesUploaded: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmlsZS1kcm9wem9uZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL2ZpbGUtZHJvcHpvbmUvZmlsZS1kcm9wem9uZS5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL2ZpbGUtZHJvcHpvbmUvZmlsZS1kcm9wem9uZS5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBRUwsdUJBQXVCLEVBQ3ZCLFNBQVMsRUFHVCxZQUFZLEVBQ1osTUFBTSxFQUNOLFNBQVMsR0FDVixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQ2pDLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMvQyxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQzs7O0FBRWhFOzs7Ozs7R0FNRztBQVNILE1BQU0sT0FBTyx3QkFBd0I7SUFhekI7SUFDQTtJQWJzQixpQkFBaUIsQ0FBYTtJQUNuQyxZQUFZLENBQWE7SUFDakMsSUFBSSxDQUFhO0lBRXBDOztPQUVHO0lBQ08sYUFBYSxHQUFHLElBQUksWUFBWSxFQUFVLENBQUM7SUFFOUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO0lBRWhDLFlBQ1UsVUFBc0IsRUFDdEIsVUFBc0I7UUFEdEIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtRQUN0QixlQUFVLEdBQVYsVUFBVSxDQUFZO0lBQzdCLENBQUM7SUFFRyxlQUFlO1FBQ3BCLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxVQUFVLENBQUM7YUFDakQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzthQUN6QyxTQUFTLENBQUMsQ0FBQyxLQUFVLEVBQUUsRUFBRTtZQUN4QixJQUFJLENBQUMsaUJBQWlCLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDOUQsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3hCLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztRQUVMLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxXQUFXLENBQUM7YUFDbEQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzthQUN6QyxTQUFTLENBQUMsQ0FBQyxLQUFVLEVBQUUsRUFBRTtZQUN4QixJQUFJLENBQUMsaUJBQWlCLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDakUsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3hCLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN6QixDQUFDLENBQUMsQ0FBQztRQUVMLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUM7YUFDN0MsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzthQUN6QyxTQUFTLENBQUMsQ0FBQyxLQUFVLEVBQUUsRUFBRTtZQUN4QixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDeEIsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDcEQsQ0FBQyxDQUFDLENBQUM7UUFFTCxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsZUFBZTtZQUMzQyxxQ0FBcUMsQ0FBQztJQUMxQyxDQUFDO3VHQTVDVSx3QkFBd0I7MkZBQXhCLHdCQUF3QixnYUM3QnJDLHVTQVlBLDQ3QkRjWSxZQUFZOzsyRkFHWCx3QkFBd0I7a0JBUnBDLFNBQVM7K0JBQ0UsbUJBQW1CLGNBR2pCLElBQUksV0FDUCxDQUFDLFlBQVksQ0FBQyxtQkFDTix1QkFBdUIsQ0FBQyxNQUFNO3dHQUdmLGlCQUFpQjtzQkFBaEQsU0FBUzt1QkFBQyxtQkFBbUI7Z0JBQ0gsWUFBWTtzQkFBdEMsU0FBUzt1QkFBQyxjQUFjO2dCQUNOLElBQUk7c0JBQXRCLFNBQVM7dUJBQUMsTUFBTTtnQkFLUCxhQUFhO3NCQUF0QixNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIENvbXBvbmVudCxcbiAgRGVzdHJveVJlZixcbiAgRWxlbWVudFJlZixcbiAgRXZlbnRFbWl0dGVyLFxuICBPdXRwdXQsXG4gIFZpZXdDaGlsZCxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBmcm9tRXZlbnQgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyB0YWtlVW50aWxEZXN0cm95ZWQgfSBmcm9tICdAYW5ndWxhci9jb3JlL3J4anMtaW50ZXJvcCc7XG5cbi8qKlxuICogQ29tcG9uZW50IHRoYXQgY2FuIGJlIHVzZWQgdG8gYWRkIGEgZHJvcHpvbmUgaW50byB3aGljaCB5b3UgY2FuIGRyb3AgZmlsZXMuXG4gKiBUaGUgZHJvcHBlZCBmaWxlcyBhcmUgdGhlbiBlbWl0ZWQgdmlhIHRoZSBmaWxlc1VwbG9hZGVkLW91dHB1dCwgYWZ0ZXIgd2hpY2ggeW91IGNhbiBkbyB3aGF0IHlvdSB3YW50IHdpdGggdGhlbVxuICogRXhhbXBsZSB1c2U6XG4gKlxuICogPG91aS1maWxlLWRyb3B6b25lIChmaWxlc1VwbG9hZGVkKT1cIm9uRmlsZVVwbG9hZCgkZXZlbnQpXCI+PC9vdWktZmlsZS1kcm9wem9uZT5cbiAqL1xuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLWZpbGUtZHJvcHpvbmUnLFxuICB0ZW1wbGF0ZVVybDogJy4vZmlsZS1kcm9wem9uZS5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL2ZpbGUtZHJvcHpvbmUuY29tcG9uZW50LnNjc3MnXSxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW0NvbW1vbk1vZHVsZV0sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlGaWxlRHJvcHpvbmVDb21wb25lbnQgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0IHtcbiAgQFZpZXdDaGlsZCgnZHJvcHpvbmVDb250YWluZXInKSBkcm9wem9uZUNvbnRhaW5lcjogRWxlbWVudFJlZjtcbiAgQFZpZXdDaGlsZCgnaW1hZ2VEaXNwbGF5JykgaW1hZ2VEaXNwbGF5OiBFbGVtZW50UmVmO1xuICBAVmlld0NoaWxkKCdpY29uJykgaWNvbjogRWxlbWVudFJlZjtcblxuICAvKipcbiAgICogICBUaGUgZXZlbnQgdGhhdCdzIHRyaWdnZXJlZCBhZnRlciB1c2VyIGRyYWdzIGZpbGVzIGludG8gdGhlIGRyb3B6b25lXG4gICAqL1xuICBAT3V0cHV0KCkgZmlsZXNVcGxvYWRlZCA9IG5ldyBFdmVudEVtaXR0ZXI8RmlsZVtdPigpO1xuXG4gIHB1YmxpYyBpc0ltYWdlRGlzcGxheWVkID0gZmFsc2U7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSBlbGVtZW50UmVmOiBFbGVtZW50UmVmLFxuICAgIHByaXZhdGUgZGVzdHJveVJlZjogRGVzdHJveVJlZlxuICApIHt9XG5cbiAgcHVibGljIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICBmcm9tRXZlbnQodGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQsICdkcmFnb3ZlcicpXG4gICAgICAucGlwZSh0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSlcbiAgICAgIC5zdWJzY3JpYmUoKGV2ZW50OiBhbnkpID0+IHtcbiAgICAgICAgdGhpcy5kcm9wem9uZUNvbnRhaW5lci5uYXRpdmVFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ2hvdmVyZWQnKTtcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICB9KTtcblxuICAgIGZyb21FdmVudCh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ2RyYWdsZWF2ZScpXG4gICAgICAucGlwZSh0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSlcbiAgICAgIC5zdWJzY3JpYmUoKGV2ZW50OiBhbnkpID0+IHtcbiAgICAgICAgdGhpcy5kcm9wem9uZUNvbnRhaW5lci5uYXRpdmVFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2hvdmVyZWQnKTtcbiAgICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICB9KTtcblxuICAgIGZyb21FdmVudCh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ2Ryb3AnKVxuICAgICAgLnBpcGUodGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZikpXG4gICAgICAuc3Vic2NyaWJlKChldmVudDogYW55KSA9PiB7XG4gICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICB0aGlzLmZpbGVzVXBsb2FkZWQuZW1pdChldmVudC5kYXRhVHJhbnNmZXIuZmlsZXMpO1xuICAgICAgfSk7XG5cbiAgICB0aGlzLmljb24ubmF0aXZlRWxlbWVudC5zdHlsZS5iYWNrZ3JvdW5kSW1hZ2UgPVxuICAgICAgXCJ1cmwoJ2Fzc2V0cy9pY29ucy9hdHRhY2htZW50cy5zdmcnKVwiO1xuICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwib3VpLWZpbGUtZHJvcHpvbmUtY29udGFpbmVyXCIgI2Ryb3B6b25lQ29udGFpbmVyPlxuICA8ZGl2XG4gICAgY2xhc3M9XCJhdHRhY2htZW50cy1pY29uXCJcbiAgICBbbmdDbGFzc109XCJ7IGhpZGU6IGlzSW1hZ2VEaXNwbGF5ZWQgfVwiXG4gICAgI2ljb25cbiAgPjwvZGl2PlxuICA8ZGl2XG4gICAgY2xhc3M9XCJpbWFnZS1kaXNwbGF5XCJcbiAgICBbbmdDbGFzc109XCJ7IHNob3c6IGlzSW1hZ2VEaXNwbGF5ZWQgfVwiXG4gICAgI2ltYWdlRGlzcGxheVxuICA+PC9kaXY+XG48L2Rpdj5cbiJdfQ==