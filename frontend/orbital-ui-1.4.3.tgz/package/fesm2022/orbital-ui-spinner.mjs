import * as i0 from '@angular/core';
import { Component, ViewChild, Input } from '@angular/core';

/**
 * Can be used to add loading spinners. Control whether or not the spinner is visible with the *ngIf directive.
 */
class OuiSpinnerComponent {
    svgElement;
    pathElement;
    spinnerContainer;
    /**
     *   Either a color defined in the COLORS-constant, or alternatively a css-variable
     */
    color = 'primary';
    /**
     *   The size of the spinner
     */
    size = '1.6rem';
    type = 'solid';
    constructor() { }
    ngAfterViewInit() {
        this.updateColor();
        this.updateSize();
    }
    updateColor() {
        let actualColor;
        const cssFillVariableColor = getComputedStyle(document.documentElement).getPropertyValue(`--${this.color}`);
        actualColor = cssFillVariableColor
            ? cssFillVariableColor
            : this.color;
        if (this.pathElement) {
            this.pathElement.nativeElement.style.stroke = actualColor;
        }
        if (this.svgElement) {
            this.svgElement.nativeElement.style.fill = actualColor;
        }
    }
    updateSize() {
        if (this.svgElement) {
            this.svgElement.nativeElement.style.width = this.size;
            this.svgElement.nativeElement.style.height = this.size;
        }
        if (this.pathElement) {
            this.pathElement.nativeElement.style.width = this.size;
            this.pathElement.nativeElement.style.height = this.size;
        }
        if (this.spinnerContainer) {
            this.spinnerContainer.nativeElement.style.width = this.size;
            this.spinnerContainer.nativeElement.style.height = this.size;
        }
    }
    ngOnChanges(changes) {
        if ('color' in changes) {
            this.color = changes['color'].currentValue;
            this.updateColor();
        }
        if ('size' in changes) {
            this.size = changes['size'].currentValue;
            this.updateSize();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiSpinnerComponent, isStandalone: true, selector: "oui-spinner", inputs: { color: "color", size: "size", type: "type" }, viewQueries: [{ propertyName: "svgElement", first: true, predicate: ["svgElement"], descendants: true }, { propertyName: "pathElement", first: true, predicate: ["pathElement"], descendants: true }, { propertyName: "spinnerContainer", first: true, predicate: ["spinnerContainer"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"oui-spinner-container\" #spinnerContainer>\n  @if (type === 'solid') {\n    <svg\n      #svgElement\n      xmlns=\"http://www.w3.org/2000/svg\"\n      xmlns:xlink=\"http://www.w3.org/1999/xlink\"\n      style=\"margin: auto; shape-rendering: auto\"\n      viewBox=\"0 0 100 100\"\n      preserveAspectRatio=\"xMidYMid\"\n      >\n      <circle\n        #pathElement\n        cx=\"50\"\n        cy=\"50\"\n        fill=\"none\"\n        stroke=\"#e15b64\"\n        stroke-width=\"6\"\n        r=\"40\"\n        stroke-dasharray=\"188.49555921538757 64.83185307179586\"\n        >\n        <animateTransform\n          attributeName=\"transform\"\n          type=\"rotate\"\n          repeatCount=\"indefinite\"\n          dur=\"1s\"\n          values=\"0 50 50;360 50 50\"\n          keyTimes=\"0;1\"\n        ></animateTransform>\n      </circle>\n    </svg>\n  }\n\n  @if (type === 'stroke') {\n    <svg\n      #svgElement\n      xmlns=\"http://www.w3.org/2000/svg\"\n      xmlns:xlink=\"http://www.w3.org/1999/xlink\"\n      style=\"shape-rendering: auto\"\n      viewBox=\"0 0 100 100\"\n      preserveAspectRatio=\"xMidYMid\"\n      >\n      <path #pathElement d=\"M10 50A40 40 0 0 0 90 50A40 42 0 0 1 10 50\">\n        <animateTransform\n          attributeName=\"transform\"\n          type=\"rotate\"\n          dur=\"1s\"\n          repeatCount=\"indefinite\"\n          keyTimes=\"0;1\"\n          values=\"0 50 51;360 50 51\"\n        ></animateTransform>\n      </path>\n    </svg>\n  }\n</div>\n", styles: [":host{z-index:1;display:flex;align-items:center;justify-content:center}:host .oui-spinner-container{display:flex;justify-content:center;align-items:center}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-spinner', standalone: true, imports: [], template: "<div class=\"oui-spinner-container\" #spinnerContainer>\n  @if (type === 'solid') {\n    <svg\n      #svgElement\n      xmlns=\"http://www.w3.org/2000/svg\"\n      xmlns:xlink=\"http://www.w3.org/1999/xlink\"\n      style=\"margin: auto; shape-rendering: auto\"\n      viewBox=\"0 0 100 100\"\n      preserveAspectRatio=\"xMidYMid\"\n      >\n      <circle\n        #pathElement\n        cx=\"50\"\n        cy=\"50\"\n        fill=\"none\"\n        stroke=\"#e15b64\"\n        stroke-width=\"6\"\n        r=\"40\"\n        stroke-dasharray=\"188.49555921538757 64.83185307179586\"\n        >\n        <animateTransform\n          attributeName=\"transform\"\n          type=\"rotate\"\n          repeatCount=\"indefinite\"\n          dur=\"1s\"\n          values=\"0 50 50;360 50 50\"\n          keyTimes=\"0;1\"\n        ></animateTransform>\n      </circle>\n    </svg>\n  }\n\n  @if (type === 'stroke') {\n    <svg\n      #svgElement\n      xmlns=\"http://www.w3.org/2000/svg\"\n      xmlns:xlink=\"http://www.w3.org/1999/xlink\"\n      style=\"shape-rendering: auto\"\n      viewBox=\"0 0 100 100\"\n      preserveAspectRatio=\"xMidYMid\"\n      >\n      <path #pathElement d=\"M10 50A40 40 0 0 0 90 50A40 42 0 0 1 10 50\">\n        <animateTransform\n          attributeName=\"transform\"\n          type=\"rotate\"\n          dur=\"1s\"\n          repeatCount=\"indefinite\"\n          keyTimes=\"0;1\"\n          values=\"0 50 51;360 50 51\"\n        ></animateTransform>\n      </path>\n    </svg>\n  }\n</div>\n", styles: [":host{z-index:1;display:flex;align-items:center;justify-content:center}:host .oui-spinner-container{display:flex;justify-content:center;align-items:center}\n"] }]
        }], ctorParameters: () => [], propDecorators: { svgElement: [{
                type: ViewChild,
                args: ['svgElement', { static: false }]
            }], pathElement: [{
                type: ViewChild,
                args: ['pathElement', { static: false }]
            }], spinnerContainer: [{
                type: ViewChild,
                args: ['spinnerContainer', { static: false }]
            }], color: [{
                type: Input
            }], size: [{
                type: Input
            }], type: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiSpinnerComponent };
//# sourceMappingURL=orbital-ui-spinner.mjs.map
