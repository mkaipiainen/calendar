export * from './editable-text-display.component';
//# sourceMappingURL=public-api.d.ts.map