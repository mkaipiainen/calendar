import { IconLayer } from '@deck.gl/layers/typed';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { BindCommonDeckOptions } from '../deck/bind-default-deck-options';
import * as i0 from "@angular/core";
export class DeckIconLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new IconLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            getIcon: this.options.getIcon,
            iconAtlas: this.options.iconAtlas,
            iconMapping: this.options.iconMapping,
            getPosition: this.options.getPosition,
            pickable: this.options.pickable ?? true,
            sizeScale: this.options.sizeScale ?? 1,
            getSize: this.options.getSize ? this.options.getSize : 1,
            getPixelOffset: this.options.getPixelOffset
                ? this.options.getPixelOffset
                : () => [0, 0],
            onDrag: this.options.onDrag ? this.options.onDrag : () => { },
            onDragStart: this.options.onDragStart
                ? this.options.onDragStart
                : () => { },
            onDragEnd: this.options.onDragEnd ? this.options.onDragEnd : () => { },
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckIconLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckIconLayer, isStandalone: true, selector: "oui-deck-icon-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckIconLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-icon-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay1pY29uLWxheWVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9tYXBib3gvaWNvbi1sYXllci9kZWNrLWljb24tbGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBR2xELE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM3RCxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQzs7QUFTMUUsTUFBTSxPQUFPLGFBQWMsU0FBUSxhQUFzQztJQUNwQyxPQUFPLENBQXdCO0lBQ2xFO1FBQ0UsS0FBSyxFQUFFLENBQUM7SUFDVixDQUFDO0lBRU0sUUFBUTtRQUNiLE9BQU8sSUFBSSxTQUFTLENBQUM7WUFDbkIsR0FBRyxxQkFBcUIsQ0FBQyxJQUFJLENBQUM7WUFDOUIsSUFBSSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSTtZQUN2QixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPO1lBQzdCLFNBQVMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVM7WUFDakMsV0FBVyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVztZQUNyQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXO1lBQ3JDLFFBQVEsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsSUFBSSxJQUFJO1lBQ3ZDLFNBQVMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsSUFBSSxDQUFDO1lBQ3RDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDeEQsY0FBYyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYztnQkFDekMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYztnQkFDN0IsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNoQixNQUFNLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRSxDQUFDO1lBQzVELFdBQVcsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVc7Z0JBQ25DLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVc7Z0JBQzFCLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRSxDQUFDO1lBQ1osU0FBUyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUUsQ0FBQztTQUN0RSxDQUFDLENBQUM7SUFDTCxDQUFDO3VHQTFCVSxhQUFhOzJGQUFiLGFBQWEsc0lBTGQsRUFBRTs7MkZBS0QsYUFBYTtrQkFQekIsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUscUJBQXFCO29CQUMvQixRQUFRLEVBQUUsRUFBRTtvQkFDWixVQUFVLEVBQUUsSUFBSTtvQkFDaEIsT0FBTyxFQUFFLEVBQUU7b0JBQ1gsZUFBZSxFQUFFLHVCQUF1QixDQUFDLE1BQU07aUJBQ2hEO3dEQUVvQyxPQUFPO3NCQUF6QyxLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEljb25MYXllciB9IGZyb20gJ0BkZWNrLmdsL2xheWVycy90eXBlZCc7XG5pbXBvcnQgeyBJQ29tbW9uRGVja0xheWVyT3B0aW9ucywgSURlY2tJY29uTGF5ZXJPcHRpb25zIH0gZnJvbSAnLi4vdHlwaW5ncyc7XG5cbmltcG9ydCB7IENoYW5nZURldGVjdGlvblN0cmF0ZWd5LCBDb21wb25lbnQsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBCYXNlRGVja0xheWVyIH0gZnJvbSAnLi4vYmFzZS1kZWNrLWxheWVyLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBCaW5kQ29tbW9uRGVja09wdGlvbnMgfSBmcm9tICcuLi9kZWNrL2JpbmQtZGVmYXVsdC1kZWNrLW9wdGlvbnMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdvdWktZGVjay1pY29uLWxheWVyJyxcbiAgdGVtcGxhdGU6ICcnLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIERlY2tJY29uTGF5ZXIgZXh0ZW5kcyBCYXNlRGVja0xheWVyPElDb21tb25EZWNrTGF5ZXJPcHRpb25zPiB7XG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pIGRlY2xhcmUgb3B0aW9uczogSURlY2tJY29uTGF5ZXJPcHRpb25zO1xuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpO1xuICB9XG5cbiAgcHVibGljIGdldExheWVyKCkge1xuICAgIHJldHVybiBuZXcgSWNvbkxheWVyKHtcbiAgICAgIC4uLkJpbmRDb21tb25EZWNrT3B0aW9ucyh0aGlzKSxcbiAgICAgIGRhdGE6IHRoaXMub3B0aW9ucy5kYXRhLFxuICAgICAgZ2V0SWNvbjogdGhpcy5vcHRpb25zLmdldEljb24sXG4gICAgICBpY29uQXRsYXM6IHRoaXMub3B0aW9ucy5pY29uQXRsYXMsXG4gICAgICBpY29uTWFwcGluZzogdGhpcy5vcHRpb25zLmljb25NYXBwaW5nLFxuICAgICAgZ2V0UG9zaXRpb246IHRoaXMub3B0aW9ucy5nZXRQb3NpdGlvbixcbiAgICAgIHBpY2thYmxlOiB0aGlzLm9wdGlvbnMucGlja2FibGUgPz8gdHJ1ZSxcbiAgICAgIHNpemVTY2FsZTogdGhpcy5vcHRpb25zLnNpemVTY2FsZSA/PyAxLFxuICAgICAgZ2V0U2l6ZTogdGhpcy5vcHRpb25zLmdldFNpemUgPyB0aGlzLm9wdGlvbnMuZ2V0U2l6ZSA6IDEsXG4gICAgICBnZXRQaXhlbE9mZnNldDogdGhpcy5vcHRpb25zLmdldFBpeGVsT2Zmc2V0XG4gICAgICAgID8gdGhpcy5vcHRpb25zLmdldFBpeGVsT2Zmc2V0XG4gICAgICAgIDogKCkgPT4gWzAsIDBdLFxuICAgICAgb25EcmFnOiB0aGlzLm9wdGlvbnMub25EcmFnID8gdGhpcy5vcHRpb25zLm9uRHJhZyA6ICgpID0+IHt9LFxuICAgICAgb25EcmFnU3RhcnQ6IHRoaXMub3B0aW9ucy5vbkRyYWdTdGFydFxuICAgICAgICA/IHRoaXMub3B0aW9ucy5vbkRyYWdTdGFydFxuICAgICAgICA6ICgpID0+IHt9LFxuICAgICAgb25EcmFnRW5kOiB0aGlzLm9wdGlvbnMub25EcmFnRW5kID8gdGhpcy5vcHRpb25zLm9uRHJhZ0VuZCA6ICgpID0+IHt9LFxuICAgIH0pO1xuICB9XG59XG4iXX0=