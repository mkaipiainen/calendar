import { TileLayer } from '@deck.gl/geo-layers/typed';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { ICommonDeckLayerOptions, IDeckTileLayerOptions } from '../typings';
import * as i0 from "@angular/core";
export declare class DeckTileLayer extends BaseDeckLayer<ICommonDeckLayerOptions> {
    options: IDeckTileLayerOptions;
    constructor();
    getLayer(): TileLayer<any, {
        data: string | string[];
        minZoom: number;
        maxZoom: number;
        tileSize: number;
        renderSubLayers: (props: any) => any;
        getTileData: (tile: any) => Promise<any> | null;
        id: string;
        autoHighlight: boolean;
        transitions: {
            [x: string]: number | {
                duration: number;
                easing: any;
            };
        };
        highlightColor: import("orbital-ui/core").RGBA | ((d: any) => import("orbital-ui/core").RGBA);
        isEnabled: boolean;
        _dataDiff: (oldData: any, newData: any) => [{
            startRow: number;
            endRow: number;
        }];
        onClick: (object: any, event: any) => void;
        onHover: (event: any) => boolean;
        updateTriggers: any;
        dataComparator: (<LayerDataT = import("@deck.gl/core/typed").LayerData<unknown>>(newData: LayerDataT, oldData?: LayerDataT | undefined) => boolean) | null;
        getCursor: (data: {
            isHovering: boolean;
            isDragging: boolean;
        }) => string;
        order: number;
        loadOptions: any;
        visible: boolean;
        opacity: number;
        extensions: any[];
        pickable: boolean;
        getDashArray: [number, number];
        dashJustified: boolean;
        dashGapPickable: boolean;
        getOffset: number | (() => number);
        clipBounds: [number, number, number, number];
        maskId: string;
        maskByInstance: boolean;
        maskInverted: boolean;
        operation: "mask";
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeckTileLayer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeckTileLayer, "oui-deck-tile-layer", never, { "options": { "alias": "options"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=deck-tile-layer.d.ts.map