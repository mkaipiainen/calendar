import { computed, DestroyRef, Directive, ElementRef, inject, input, Input, Renderer2, } from '@angular/core';
import { OuiDefaultTooltipComponent } from './default-tooltip.component';
import { debounce, merge } from 'lodash-es';
import { OuiPopupService } from 'orbital-ui/popup';
import * as i0 from "@angular/core";
export class OuiTooltipDirective {
    elementRef = inject(ElementRef);
    renderer = inject(Renderer2);
    popupService = inject(OuiPopupService);
    destroyRef = inject(DestroyRef);
    component;
    inputs;
    isTooltipDisabled = input(false);
    tooltip = input('');
    tooltipOptions = input();
    combinedOptions = computed(() => {
        return merge({
            mode: 'hover',
            popupOptions: {
                placement: 'top',
                modifiers: [
                    {
                        name: 'arrow',
                        options: {
                            color: 'var(--color-primary)',
                            padding: 10,
                        },
                    },
                    {
                        name: 'offset',
                        options: {
                            offset: [0, 10],
                        },
                    },
                ],
            },
        }, {
            ...this.tooltipOptions(),
        });
    });
    popup;
    isHoveringOnPopup = false;
    isHoveringOnOrigin = false;
    handleDebouncedMouseLeave = debounce(this.handleMouseLeave, 100);
    constructor() { }
    ngAfterViewInit() {
        this.destroyRef.onDestroy(() => {
            this.destroyTooltip();
        });
        if (this.combinedOptions().mode === 'hover') {
            this.renderer.listen(this.elementRef.nativeElement, 'mouseenter', () => {
                this.isHoveringOnOrigin = true;
                this.createTooltip();
            });
            this.renderer.listen(this.elementRef.nativeElement, 'mouseleave', () => {
                this.isHoveringOnOrigin = false;
                this.handleDebouncedMouseLeave();
            });
        }
        else if (this.combinedOptions().mode === 'click') {
            this.renderer.listen(this.elementRef.nativeElement, 'mouseenter', () => {
                this.isHoveringOnOrigin = true;
            });
            this.renderer.listen(this.elementRef.nativeElement, 'click', () => {
                this.createTooltip();
            });
            this.renderer.listen(this.elementRef.nativeElement, 'mouseleave', () => {
                this.isHoveringOnOrigin = false;
                this.handleDebouncedMouseLeave();
            });
        }
    }
    createTooltip() {
        if (this.popup || this.isTooltipDisabled()) {
            return;
        }
        if (this.component) {
            this.popup = this.popupService.openPopup(this.component, this.inputs, this.combinedOptions().popupOptions, this.elementRef.nativeElement);
        }
        else {
            this.popup = this.popupService.openPopup(OuiDefaultTooltipComponent, {
                content: this.tooltip(),
            }, this.combinedOptions().popupOptions, this.elementRef.nativeElement);
        }
        this.renderer.listen(this.popup.popupElement, 'mouseenter', () => {
            this.isHoveringOnPopup = true;
        });
        this.renderer.listen(this.popup.popupElement, 'mouseleave', () => {
            this.isHoveringOnPopup = false;
            this.handleDebouncedMouseLeave();
        });
    }
    handleMouseLeave() {
        if (!this.isHoveringOnOrigin && !this.isHoveringOnPopup) {
            this.destroyTooltip();
        }
    }
    destroyTooltip() {
        if (this.popup) {
            this.popupService.dispose(this.popup.id);
            this.popup = undefined;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTooltipDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "17.3.1", type: OuiTooltipDirective, isStandalone: true, selector: "[ouiTooltip]", inputs: { component: { classPropertyName: "component", publicName: "component", isSignal: false, isRequired: false, transformFunction: null }, inputs: { classPropertyName: "inputs", publicName: "inputs", isSignal: false, isRequired: false, transformFunction: null }, isTooltipDisabled: { classPropertyName: "isTooltipDisabled", publicName: "isTooltipDisabled", isSignal: true, isRequired: false, transformFunction: null }, tooltip: { classPropertyName: "tooltip", publicName: "tooltip", isSignal: true, isRequired: false, transformFunction: null }, tooltipOptions: { classPropertyName: "tooltipOptions", publicName: "tooltipOptions", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTooltipDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ouiTooltip]',
                    standalone: true,
                }]
        }], ctorParameters: () => [], propDecorators: { component: [{
                type: Input
            }], inputs: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidG9vbHRpcC5kaXJlY3RpdmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3Rvb2x0aXAvdG9vbHRpcC5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUVMLFFBQVEsRUFDUixVQUFVLEVBQ1YsU0FBUyxFQUNULFVBQVUsRUFDVixNQUFNLEVBQ04sS0FBSyxFQUNMLEtBQUssRUFDTCxTQUFTLEdBQ1YsTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxFQUFFLDBCQUEwQixFQUFFLE1BQU0sNkJBQTZCLENBQUM7QUFDekUsT0FBTyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFDNUMsT0FBTyxFQUF5QixlQUFlLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQzs7QUFrQjFFLE1BQU0sT0FBTyxtQkFBbUI7SUFDdEIsVUFBVSxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNoQyxRQUFRLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQzdCLFlBQVksR0FBRyxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDdkMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUUvQixTQUFTLENBQXFCO0lBQzlCLE1BQU0sQ0FFYjtJQUVLLGlCQUFpQixHQUFHLEtBQUssQ0FBVSxLQUFLLENBQUMsQ0FBQztJQUMxQyxPQUFPLEdBQUcsS0FBSyxDQUFTLEVBQUUsQ0FBQyxDQUFDO0lBQzVCLGNBQWMsR0FBRyxLQUFLLEVBQXFCLENBQUM7SUFDNUMsZUFBZSxHQUFHLFFBQVEsQ0FBQyxHQUFHLEVBQUU7UUFDckMsT0FBTyxLQUFLLENBQ1Y7WUFDRSxJQUFJLEVBQUUsT0FBTztZQUNiLFlBQVksRUFBRTtnQkFDWixTQUFTLEVBQUUsS0FBSztnQkFDaEIsU0FBUyxFQUFFO29CQUNUO3dCQUNFLElBQUksRUFBRSxPQUFPO3dCQUNiLE9BQU8sRUFBRTs0QkFDUCxLQUFLLEVBQUUsc0JBQXNCOzRCQUM3QixPQUFPLEVBQUUsRUFBRTt5QkFDWjtxQkFDRjtvQkFDRDt3QkFDRSxJQUFJLEVBQUUsUUFBUTt3QkFDZCxPQUFPLEVBQUU7NEJBQ1AsTUFBTSxFQUFFLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQzt5QkFDaEI7cUJBQ0Y7aUJBQ0Y7YUFDRjtTQUNGLEVBQ0Q7WUFDRSxHQUFHLElBQUksQ0FBQyxjQUFjLEVBQUU7U0FDekIsQ0FDRixDQUFDO0lBQ0osQ0FBQyxDQUFDLENBQUM7SUFFSyxLQUFLLENBQXFCO0lBQzFCLGlCQUFpQixHQUFHLEtBQUssQ0FBQztJQUMxQixrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFDM0IseUJBQXlCLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUV6RSxnQkFBZSxDQUFDO0lBRVQsZUFBZTtRQUNwQixJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7WUFDN0IsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3hCLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRSxDQUFDO1lBQzVDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLFlBQVksRUFBRSxHQUFHLEVBQUU7Z0JBQ3JFLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUM7Z0JBQy9CLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUN2QixDQUFDLENBQUMsQ0FBQztZQUVILElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLFlBQVksRUFBRSxHQUFHLEVBQUU7Z0JBQ3JFLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxLQUFLLENBQUM7Z0JBQ2hDLElBQUksQ0FBQyx5QkFBeUIsRUFBRSxDQUFDO1lBQ25DLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQzthQUFNLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUUsQ0FBQztZQUNuRCxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxZQUFZLEVBQUUsR0FBRyxFQUFFO2dCQUNyRSxJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO1lBQ2pDLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsT0FBTyxFQUFFLEdBQUcsRUFBRTtnQkFDaEUsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3ZCLENBQUMsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsWUFBWSxFQUFFLEdBQUcsRUFBRTtnQkFDckUsSUFBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztnQkFDaEMsSUFBSSxDQUFDLHlCQUF5QixFQUFFLENBQUM7WUFDbkMsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDO0lBQ0gsQ0FBQztJQUVNLGFBQWE7UUFDbEIsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxFQUFFLENBQUM7WUFDM0MsT0FBTztRQUNULENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNuQixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUN0QyxJQUFJLENBQUMsU0FBUyxFQUNkLElBQUksQ0FBQyxNQUFNLEVBQ1gsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLFlBQVksRUFDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQzlCLENBQUM7UUFDSixDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQ3RDLDBCQUEwQixFQUMxQjtnQkFDRSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sRUFBRTthQUN4QixFQUNELElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxZQUFZLEVBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUM5QixDQUFDO1FBQ0osQ0FBQztRQUNELElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFLFlBQVksRUFBRSxHQUFHLEVBQUU7WUFDL0QsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQztRQUNoQyxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxFQUFFLFlBQVksRUFBRSxHQUFHLEVBQUU7WUFDL0QsSUFBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQztZQUMvQixJQUFJLENBQUMseUJBQXlCLEVBQUUsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxnQkFBZ0I7UUFDckIsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1lBQ3hELElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN4QixDQUFDO0lBQ0gsQ0FBQztJQUVNLGNBQWM7UUFDbkIsSUFBSSxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDZixJQUFJLENBQUMsWUFBWSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ3pDLElBQUksQ0FBQyxLQUFLLEdBQUcsU0FBUyxDQUFDO1FBQ3pCLENBQUM7SUFDSCxDQUFDO3VHQTFIVSxtQkFBbUI7MkZBQW5CLG1CQUFtQjs7MkZBQW5CLG1CQUFtQjtrQkFKL0IsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsY0FBYztvQkFDeEIsVUFBVSxFQUFFLElBQUk7aUJBQ2pCO3dEQU9VLFNBQVM7c0JBQWpCLEtBQUs7Z0JBQ0csTUFBTTtzQkFBZCxLQUFLIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgY29tcHV0ZWQsXG4gIERlc3Ryb3lSZWYsXG4gIERpcmVjdGl2ZSxcbiAgRWxlbWVudFJlZixcbiAgaW5qZWN0LFxuICBpbnB1dCxcbiAgSW5wdXQsXG4gIFJlbmRlcmVyMixcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb21wb25lbnRUeXBlIH0gZnJvbSAnQGFuZ3VsYXIvY2RrL292ZXJsYXknO1xuaW1wb3J0IHsgT3VpRGVmYXVsdFRvb2x0aXBDb21wb25lbnQgfSBmcm9tICcuL2RlZmF1bHQtdG9vbHRpcC5jb21wb25lbnQnO1xuaW1wb3J0IHsgZGVib3VuY2UsIG1lcmdlIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IElQb3B1cCwgSVBvcHVwT3B0aW9ucywgT3VpUG9wdXBTZXJ2aWNlIH0gZnJvbSAnb3JiaXRhbC11aS9wb3B1cCc7XG5cbmV4cG9ydCB0eXBlIE91aVRvb2x0aXBPcHRpb25zID0ge1xuICBtb2RlPzogJ2hvdmVyJyB8ICdjbGljaycgfCAnbWFudWFsJztcbiAgcG9wdXBPcHRpb25zPzogSVBvcHVwT3B0aW9ucztcbiAgaXNEaXNhYmxlZD86IGJvb2xlYW47XG59O1xuXG50eXBlIE91aVRvb2x0aXBDb21iaW5lZE9wdGlvbnMgPSB7XG4gIG1vZGU6ICdob3ZlcicgfCAnY2xpY2snIHwgJ21hbnVhbCc7XG4gIHBvcHVwT3B0aW9uczogSVBvcHVwT3B0aW9ucztcbiAgaXNEaXNhYmxlZDogYm9vbGVhbjtcbn07XG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ1tvdWlUb29sdGlwXScsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG59KVxuZXhwb3J0IGNsYXNzIE91aVRvb2x0aXBEaXJlY3RpdmUgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0IHtcbiAgcHJpdmF0ZSBlbGVtZW50UmVmID0gaW5qZWN0KEVsZW1lbnRSZWYpO1xuICBwcml2YXRlIHJlbmRlcmVyID0gaW5qZWN0KFJlbmRlcmVyMik7XG4gIHByaXZhdGUgcG9wdXBTZXJ2aWNlID0gaW5qZWN0KE91aVBvcHVwU2VydmljZSk7XG4gIHByaXZhdGUgZGVzdHJveVJlZiA9IGluamVjdChEZXN0cm95UmVmKTtcblxuICBASW5wdXQoKSBjb21wb25lbnQ6IENvbXBvbmVudFR5cGU8YW55PjtcbiAgQElucHV0KCkgaW5wdXRzOiB7XG4gICAgW3g6IHN0cmluZ106IGFueTtcbiAgfTtcblxuICBwdWJsaWMgaXNUb29sdGlwRGlzYWJsZWQgPSBpbnB1dDxib29sZWFuPihmYWxzZSk7XG4gIHB1YmxpYyB0b29sdGlwID0gaW5wdXQ8c3RyaW5nPignJyk7XG4gIHB1YmxpYyB0b29sdGlwT3B0aW9ucyA9IGlucHV0PE91aVRvb2x0aXBPcHRpb25zPigpO1xuICBwdWJsaWMgY29tYmluZWRPcHRpb25zID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIHJldHVybiBtZXJnZShcbiAgICAgIHtcbiAgICAgICAgbW9kZTogJ2hvdmVyJyxcbiAgICAgICAgcG9wdXBPcHRpb25zOiB7XG4gICAgICAgICAgcGxhY2VtZW50OiAndG9wJyxcbiAgICAgICAgICBtb2RpZmllcnM6IFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ2Fycm93JyxcbiAgICAgICAgICAgICAgb3B0aW9uczoge1xuICAgICAgICAgICAgICAgIGNvbG9yOiAndmFyKC0tY29sb3ItcHJpbWFyeSknLFxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDEwLFxuICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgbmFtZTogJ29mZnNldCcsXG4gICAgICAgICAgICAgIG9wdGlvbnM6IHtcbiAgICAgICAgICAgICAgICBvZmZzZXQ6IFswLCAxMF0sXG4gICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAge1xuICAgICAgICAuLi50aGlzLnRvb2x0aXBPcHRpb25zKCksXG4gICAgICB9XG4gICAgKTtcbiAgfSk7XG5cbiAgcHJpdmF0ZSBwb3B1cDogSVBvcHVwIHwgdW5kZWZpbmVkO1xuICBwcml2YXRlIGlzSG92ZXJpbmdPblBvcHVwID0gZmFsc2U7XG4gIHByaXZhdGUgaXNIb3ZlcmluZ09uT3JpZ2luID0gZmFsc2U7XG4gIHByaXZhdGUgaGFuZGxlRGVib3VuY2VkTW91c2VMZWF2ZSA9IGRlYm91bmNlKHRoaXMuaGFuZGxlTW91c2VMZWF2ZSwgMTAwKTtcblxuICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgcHVibGljIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICB0aGlzLmRlc3Ryb3lSZWYub25EZXN0cm95KCgpID0+IHtcbiAgICAgIHRoaXMuZGVzdHJveVRvb2x0aXAoKTtcbiAgICB9KTtcbiAgICBpZiAodGhpcy5jb21iaW5lZE9wdGlvbnMoKS5tb2RlID09PSAnaG92ZXInKSB7XG4gICAgICB0aGlzLnJlbmRlcmVyLmxpc3Rlbih0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ21vdXNlZW50ZXInLCAoKSA9PiB7XG4gICAgICAgIHRoaXMuaXNIb3ZlcmluZ09uT3JpZ2luID0gdHJ1ZTtcbiAgICAgICAgdGhpcy5jcmVhdGVUb29sdGlwKCk7XG4gICAgICB9KTtcblxuICAgICAgdGhpcy5yZW5kZXJlci5saXN0ZW4odGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQsICdtb3VzZWxlYXZlJywgKCkgPT4ge1xuICAgICAgICB0aGlzLmlzSG92ZXJpbmdPbk9yaWdpbiA9IGZhbHNlO1xuICAgICAgICB0aGlzLmhhbmRsZURlYm91bmNlZE1vdXNlTGVhdmUoKTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAodGhpcy5jb21iaW5lZE9wdGlvbnMoKS5tb2RlID09PSAnY2xpY2snKSB7XG4gICAgICB0aGlzLnJlbmRlcmVyLmxpc3Rlbih0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ21vdXNlZW50ZXInLCAoKSA9PiB7XG4gICAgICAgIHRoaXMuaXNIb3ZlcmluZ09uT3JpZ2luID0gdHJ1ZTtcbiAgICAgIH0pO1xuXG4gICAgICB0aGlzLnJlbmRlcmVyLmxpc3Rlbih0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgICB0aGlzLmNyZWF0ZVRvb2x0aXAoKTtcbiAgICAgIH0pO1xuXG4gICAgICB0aGlzLnJlbmRlcmVyLmxpc3Rlbih0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ21vdXNlbGVhdmUnLCAoKSA9PiB7XG4gICAgICAgIHRoaXMuaXNIb3ZlcmluZ09uT3JpZ2luID0gZmFsc2U7XG4gICAgICAgIHRoaXMuaGFuZGxlRGVib3VuY2VkTW91c2VMZWF2ZSgpO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIGNyZWF0ZVRvb2x0aXAoKSB7XG4gICAgaWYgKHRoaXMucG9wdXAgfHwgdGhpcy5pc1Rvb2x0aXBEaXNhYmxlZCgpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmICh0aGlzLmNvbXBvbmVudCkge1xuICAgICAgdGhpcy5wb3B1cCA9IHRoaXMucG9wdXBTZXJ2aWNlLm9wZW5Qb3B1cChcbiAgICAgICAgdGhpcy5jb21wb25lbnQsXG4gICAgICAgIHRoaXMuaW5wdXRzLFxuICAgICAgICB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLnBvcHVwT3B0aW9ucyxcbiAgICAgICAgdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnRcbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMucG9wdXAgPSB0aGlzLnBvcHVwU2VydmljZS5vcGVuUG9wdXAoXG4gICAgICAgIE91aURlZmF1bHRUb29sdGlwQ29tcG9uZW50LFxuICAgICAgICB7XG4gICAgICAgICAgY29udGVudDogdGhpcy50b29sdGlwKCksXG4gICAgICAgIH0sXG4gICAgICAgIHRoaXMuY29tYmluZWRPcHRpb25zKCkucG9wdXBPcHRpb25zLFxuICAgICAgICB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudFxuICAgICAgKTtcbiAgICB9XG4gICAgdGhpcy5yZW5kZXJlci5saXN0ZW4odGhpcy5wb3B1cC5wb3B1cEVsZW1lbnQsICdtb3VzZWVudGVyJywgKCkgPT4ge1xuICAgICAgdGhpcy5pc0hvdmVyaW5nT25Qb3B1cCA9IHRydWU7XG4gICAgfSk7XG5cbiAgICB0aGlzLnJlbmRlcmVyLmxpc3Rlbih0aGlzLnBvcHVwLnBvcHVwRWxlbWVudCwgJ21vdXNlbGVhdmUnLCAoKSA9PiB7XG4gICAgICB0aGlzLmlzSG92ZXJpbmdPblBvcHVwID0gZmFsc2U7XG4gICAgICB0aGlzLmhhbmRsZURlYm91bmNlZE1vdXNlTGVhdmUoKTtcbiAgICB9KTtcbiAgfVxuXG4gIHB1YmxpYyBoYW5kbGVNb3VzZUxlYXZlKCkge1xuICAgIGlmICghdGhpcy5pc0hvdmVyaW5nT25PcmlnaW4gJiYgIXRoaXMuaXNIb3ZlcmluZ09uUG9wdXApIHtcbiAgICAgIHRoaXMuZGVzdHJveVRvb2x0aXAoKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgZGVzdHJveVRvb2x0aXAoKSB7XG4gICAgaWYgKHRoaXMucG9wdXApIHtcbiAgICAgIHRoaXMucG9wdXBTZXJ2aWNlLmRpc3Bvc2UodGhpcy5wb3B1cC5pZCk7XG4gICAgICB0aGlzLnBvcHVwID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgfVxufVxuIl19