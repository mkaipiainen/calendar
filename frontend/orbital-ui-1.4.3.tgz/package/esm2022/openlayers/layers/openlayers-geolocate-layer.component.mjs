import { ChangeDetectionStrategy, Component, computed, input, signal, } from '@angular/core';
import { OpenlayersBaseLayerComponent } from './openlayers-base-layer.component';
import Geolocation from 'ol/Geolocation.js';
import { Feature } from 'ol';
import { Fill, Stroke, Style } from 'ol/style';
import CircleStyle from 'ol/style/Circle';
import { Point } from 'ol/geom';
import VectorSource from 'ol/source/Vector';
import VectorLayer from 'ol/layer/Vector';
import { DEFAULT_COMMON_OPTIONS } from '../constants';
import * as i0 from "@angular/core";
export class OpenlayersGeolocateLayerComponent extends OpenlayersBaseLayerComponent {
    options = input.required();
    combinedOptions = computed(() => {
        return {
            ...DEFAULT_COMMON_OPTIONS,
            ...this.options(),
        };
    });
    geolocation = signal(undefined);
    positionFeature = new Feature();
    accuracyFeature = new Feature();
    source = signal(new VectorSource({
        features: [this.accuracyFeature, this.positionFeature],
    }));
    layer = signal(new VectorLayer({
        source: this.source(),
    }));
    geolocationListeners = {
        'change:accuracyGeometry': this.onAccuracyOrGeometryChange.bind(this),
        'change:position': this.onPositionChange.bind(this),
    };
    constructor() {
        super();
    }
    updateLayer() { }
    onAdd() {
        const olMap = this.map().state.map();
        if (olMap) {
            this.layer().setMap(olMap);
            this.geolocation.set(new Geolocation({
                trackingOptions: {
                    enableHighAccuracy: true,
                },
                projection: olMap.getView().getProjection(),
            }));
            const geolocation = this.geolocation();
            if (geolocation) {
                geolocation.setTracking(true);
            }
            Object.keys(this.geolocationListeners).forEach(key => {
                const listener = this.geolocationListeners[key];
                if (geolocation) {
                    geolocation.on(key, listener);
                }
            });
        }
        else {
            throw new Error('Attempted to initialise layer - map not initialized');
        }
    }
    onRemove() {
        const geolocation = this.geolocation();
        if (geolocation) {
            Object.keys(this.geolocationListeners).forEach(key => {
                const listener = this.geolocationListeners[key];
                if (geolocation) {
                    geolocation.un(key, listener);
                }
            });
        }
    }
    onDestroy(openlayers) {
        const geolocation = this.geolocation();
        if (geolocation) {
            Object.keys(this.geolocationListeners).forEach(key => {
                const listener = this.geolocationListeners[key];
                if (geolocation) {
                    geolocation.un(key, listener);
                }
            });
        }
    }
    ngAfterViewInit() {
        this.map().updateLayer(this, this.onAdd.bind(this), this.onRemove.bind(this));
        this.positionFeature.setStyle(new Style({
            image: new CircleStyle({
                radius: 6,
                fill: new Fill({
                    color: '#3399CC',
                }),
                stroke: new Stroke({
                    color: '#fff',
                    width: 2,
                }),
            }),
        }));
    }
    onAccuracyOrGeometryChange(evt) {
        console.log('Accuracy or geometry change');
        const geolocation = this.geolocation();
        if (geolocation) {
            this.accuracyFeature.setGeometry(geolocation.getAccuracyGeometry() ?? undefined);
        }
        else {
            throw new Error('Attempted to update accuracy or geometry - geolocation not initialized');
        }
    }
    onPositionChange() {
        console.log('Changed position');
        const geolocation = this.geolocation();
        if (geolocation) {
            const coordinates = geolocation.getPosition();
            this.positionFeature.setGeometry(coordinates ? new Point(coordinates) : undefined);
        }
        else {
            throw new Error('Attempted to update position - geolocation not initialized');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersGeolocateLayerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "17.3.1", type: OpenlayersGeolocateLayerComponent, isStandalone: true, selector: "oui-openlayers-geolocate-layer", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, providers: [
            {
                provide: OpenlayersBaseLayerComponent,
                useExisting: OpenlayersGeolocateLayerComponent,
            },
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersGeolocateLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-openlayers-geolocate-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [
                        {
                            provide: OpenlayersBaseLayerComponent,
                            useExisting: OpenlayersGeolocateLayerComponent,
                        },
                    ],
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BlbmxheWVycy1nZW9sb2NhdGUtbGF5ZXIuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9vcGVubGF5ZXJzL2xheWVycy9vcGVubGF5ZXJzLWdlb2xvY2F0ZS1sYXllci5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUVMLHVCQUF1QixFQUN2QixTQUFTLEVBQ1QsUUFBUSxFQUNSLEtBQUssRUFDTCxNQUFNLEdBQ1AsTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxFQUFFLDRCQUE0QixFQUFFLE1BQU0sbUNBQW1DLENBQUM7QUFDakYsT0FBTyxXQUFXLE1BQU0sbUJBQW1CLENBQUM7QUFDNUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLElBQUksQ0FBQztBQUM3QixPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxVQUFVLENBQUM7QUFDL0MsT0FBTyxXQUFXLE1BQU0saUJBQWlCLENBQUM7QUFDMUMsT0FBTyxFQUFZLEtBQUssRUFBRSxNQUFNLFNBQVMsQ0FBQztBQUMxQyxPQUFPLFlBQVksTUFBTSxrQkFBa0IsQ0FBQztBQUM1QyxPQUFPLFdBQVcsTUFBTSxpQkFBaUIsQ0FBQztBQUcxQyxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSxjQUFjLENBQUM7O0FBZXRELE1BQU0sT0FBTyxpQ0FDWCxTQUFRLDRCQUFpQztJQUdsQyxPQUFPLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBc0MsQ0FBQztJQUMvRCxlQUFlLEdBQUcsUUFBUSxDQUFDLEdBQUcsRUFBRTtRQUNyQyxPQUFPO1lBQ0wsR0FBRyxzQkFBc0I7WUFDekIsR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFO1NBQ2xCLENBQUM7SUFDSixDQUFDLENBQUMsQ0FBQztJQUNLLFdBQVcsR0FBRyxNQUFNLENBQTBCLFNBQVMsQ0FBQyxDQUFDO0lBQ3pELGVBQWUsR0FBRyxJQUFJLE9BQU8sRUFBRSxDQUFDO0lBQ2hDLGVBQWUsR0FBRyxJQUFJLE9BQU8sRUFBRSxDQUFDO0lBQ2pDLE1BQU0sR0FBRyxNQUFNLENBQ3BCLElBQUksWUFBWSxDQUFDO1FBQ2YsUUFBUSxFQUFFLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDO0tBQ3ZELENBQUMsQ0FDSCxDQUFDO0lBQ0ssS0FBSyxHQUFHLE1BQU0sQ0FDbkIsSUFBSSxXQUFXLENBQUM7UUFDZCxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRTtLQUN0QixDQUFDLENBQ0gsQ0FBQztJQUNNLG9CQUFvQixHQUV4QjtRQUNGLHlCQUF5QixFQUFFLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQ3JFLGlCQUFpQixFQUFFLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0tBQ3BELENBQUM7SUFFRjtRQUNFLEtBQUssRUFBRSxDQUFDO0lBQ1YsQ0FBQztJQUVNLFdBQVcsS0FBSSxDQUFDO0lBRVAsS0FBSztRQUNuQixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ3JDLElBQUksS0FBSyxFQUFFLENBQUM7WUFDVixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzNCLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUNsQixJQUFJLFdBQVcsQ0FBQztnQkFDZCxlQUFlLEVBQUU7b0JBQ2Ysa0JBQWtCLEVBQUUsSUFBSTtpQkFDekI7Z0JBQ0QsVUFBVSxFQUFFLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxhQUFhLEVBQUU7YUFDNUMsQ0FBQyxDQUNILENBQUM7WUFFRixNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDdkMsSUFBSSxXQUFXLEVBQUUsQ0FBQztnQkFDaEIsV0FBVyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUNoQyxDQUFDO1lBQ0QsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ25ELE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDaEQsSUFBSSxXQUFXLEVBQUUsQ0FBQztvQkFDaEIsV0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFVLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBQ3ZDLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxJQUFJLEtBQUssQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO1FBQ3pFLENBQUM7SUFDSCxDQUFDO0lBRWUsUUFBUTtRQUN0QixNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDdkMsSUFBSSxXQUFXLEVBQUUsQ0FBQztZQUNoQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtnQkFDbkQsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUNoRCxJQUFJLFdBQVcsRUFBRSxDQUFDO29CQUNoQixXQUFXLENBQUMsRUFBRSxDQUFDLEdBQVUsRUFBRSxRQUFRLENBQUMsQ0FBQztnQkFDdkMsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztJQUNILENBQUM7SUFFZSxTQUFTLENBQUMsVUFBK0I7UUFDdkQsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3ZDLElBQUksV0FBVyxFQUFFLENBQUM7WUFDaEIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsb0JBQW9CLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ25ELE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDaEQsSUFBSSxXQUFXLEVBQUUsQ0FBQztvQkFDaEIsV0FBVyxDQUFDLEVBQUUsQ0FBQyxHQUFVLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBQ3ZDLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUM7SUFDSCxDQUFDO0lBRU0sZUFBZTtRQUNwQixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsV0FBVyxDQUNwQixJQUFJLEVBQ0osSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQ3JCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUN6QixDQUFDO1FBQ0YsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQzNCLElBQUksS0FBSyxDQUFDO1lBQ1IsS0FBSyxFQUFFLElBQUksV0FBVyxDQUFDO2dCQUNyQixNQUFNLEVBQUUsQ0FBQztnQkFDVCxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUM7b0JBQ2IsS0FBSyxFQUFFLFNBQVM7aUJBQ2pCLENBQUM7Z0JBQ0YsTUFBTSxFQUFFLElBQUksTUFBTSxDQUFDO29CQUNqQixLQUFLLEVBQUUsTUFBTTtvQkFDYixLQUFLLEVBQUUsQ0FBQztpQkFDVCxDQUFDO2FBQ0gsQ0FBQztTQUNILENBQUMsQ0FDSCxDQUFDO0lBQ0osQ0FBQztJQUVPLDBCQUEwQixDQUFDLEdBQVE7UUFDekMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1FBQzNDLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN2QyxJQUFJLFdBQVcsRUFBRSxDQUFDO1lBQ2hCLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUM5QixXQUFXLENBQUMsbUJBQW1CLEVBQUUsSUFBSSxTQUFTLENBQy9DLENBQUM7UUFDSixDQUFDO2FBQU0sQ0FBQztZQUNOLE1BQU0sSUFBSSxLQUFLLENBQ2Isd0VBQXdFLENBQ3pFLENBQUM7UUFDSixDQUFDO0lBQ0gsQ0FBQztJQUVPLGdCQUFnQjtRQUN0QixPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUM7UUFDaEMsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ3ZDLElBQUksV0FBVyxFQUFFLENBQUM7WUFDaEIsTUFBTSxXQUFXLEdBQUcsV0FBVyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzlDLElBQUksQ0FBQyxlQUFlLENBQUMsV0FBVyxDQUM5QixXQUFXLENBQUMsQ0FBQyxDQUFDLElBQUksS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQ2pELENBQUM7UUFDSixDQUFDO2FBQU0sQ0FBQztZQUNOLE1BQU0sSUFBSSxLQUFLLENBQ2IsNERBQTRELENBQzdELENBQUM7UUFDSixDQUFDO0lBQ0gsQ0FBQzt1R0ExSVUsaUNBQWlDOzJGQUFqQyxpQ0FBaUMsc05BUGpDO1lBQ1Q7Z0JBQ0UsT0FBTyxFQUFFLDRCQUE0QjtnQkFDckMsV0FBVyxFQUFFLGlDQUFpQzthQUMvQztTQUNGLGlEQVRTLEVBQUU7OzJGQVdELGlDQUFpQztrQkFiN0MsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsZ0NBQWdDO29CQUMxQyxRQUFRLEVBQUUsRUFBRTtvQkFDWixVQUFVLEVBQUUsSUFBSTtvQkFDaEIsT0FBTyxFQUFFLEVBQUU7b0JBQ1gsZUFBZSxFQUFFLHVCQUF1QixDQUFDLE1BQU07b0JBQy9DLFNBQVMsRUFBRTt3QkFDVDs0QkFDRSxPQUFPLEVBQUUsNEJBQTRCOzRCQUNyQyxXQUFXLG1DQUFtQzt5QkFDL0M7cUJBQ0Y7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcbiAgQ29tcG9uZW50LFxuICBjb21wdXRlZCxcbiAgaW5wdXQsXG4gIHNpZ25hbCxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IE9wZW5sYXllcnNCYXNlTGF5ZXJDb21wb25lbnQgfSBmcm9tICcuL29wZW5sYXllcnMtYmFzZS1sYXllci5jb21wb25lbnQnO1xuaW1wb3J0IEdlb2xvY2F0aW9uIGZyb20gJ29sL0dlb2xvY2F0aW9uLmpzJztcbmltcG9ydCB7IEZlYXR1cmUgfSBmcm9tICdvbCc7XG5pbXBvcnQgeyBGaWxsLCBTdHJva2UsIFN0eWxlIH0gZnJvbSAnb2wvc3R5bGUnO1xuaW1wb3J0IENpcmNsZVN0eWxlIGZyb20gJ29sL3N0eWxlL0NpcmNsZSc7XG5pbXBvcnQgeyBHZW9tZXRyeSwgUG9pbnQgfSBmcm9tICdvbC9nZW9tJztcbmltcG9ydCBWZWN0b3JTb3VyY2UgZnJvbSAnb2wvc291cmNlL1ZlY3Rvcic7XG5pbXBvcnQgVmVjdG9yTGF5ZXIgZnJvbSAnb2wvbGF5ZXIvVmVjdG9yJztcbmltcG9ydCB7IE91aU9wZW5sYXllcnNHZW9sb2NhdGVMYXllck9wdGlvbnMgfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQgeyBPcGVubGF5ZXJzQ29tcG9uZW50IH0gZnJvbSAnLi4vb3BlbmxheWVycy5jb21wb25lbnQnO1xuaW1wb3J0IHsgREVGQVVMVF9DT01NT05fT1BUSU9OUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1vcGVubGF5ZXJzLWdlb2xvY2F0ZS1sYXllcicsXG4gIHRlbXBsYXRlOiAnJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW10sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxuICBwcm92aWRlcnM6IFtcbiAgICB7XG4gICAgICBwcm92aWRlOiBPcGVubGF5ZXJzQmFzZUxheWVyQ29tcG9uZW50LFxuICAgICAgdXNlRXhpc3Rpbmc6IE9wZW5sYXllcnNHZW9sb2NhdGVMYXllckNvbXBvbmVudCxcbiAgICB9LFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBPcGVubGF5ZXJzR2VvbG9jYXRlTGF5ZXJDb21wb25lbnRcbiAgZXh0ZW5kcyBPcGVubGF5ZXJzQmFzZUxheWVyQ29tcG9uZW50PGFueT5cbiAgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0XG57XG4gIHB1YmxpYyBvcHRpb25zID0gaW5wdXQucmVxdWlyZWQ8T3VpT3BlbmxheWVyc0dlb2xvY2F0ZUxheWVyT3B0aW9ucz4oKTtcbiAgcHVibGljIGNvbWJpbmVkT3B0aW9ucyA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICByZXR1cm4ge1xuICAgICAgLi4uREVGQVVMVF9DT01NT05fT1BUSU9OUyxcbiAgICAgIC4uLnRoaXMub3B0aW9ucygpLFxuICAgIH07XG4gIH0pO1xuICBwcml2YXRlIGdlb2xvY2F0aW9uID0gc2lnbmFsPEdlb2xvY2F0aW9uIHwgdW5kZWZpbmVkPih1bmRlZmluZWQpO1xuICBwcml2YXRlIHBvc2l0aW9uRmVhdHVyZSA9IG5ldyBGZWF0dXJlKCk7XG4gIHByaXZhdGUgYWNjdXJhY3lGZWF0dXJlID0gbmV3IEZlYXR1cmUoKTtcbiAgcHVibGljIHNvdXJjZSA9IHNpZ25hbChcbiAgICBuZXcgVmVjdG9yU291cmNlKHtcbiAgICAgIGZlYXR1cmVzOiBbdGhpcy5hY2N1cmFjeUZlYXR1cmUsIHRoaXMucG9zaXRpb25GZWF0dXJlXSxcbiAgICB9KVxuICApO1xuICBwdWJsaWMgbGF5ZXIgPSBzaWduYWw8VmVjdG9yTGF5ZXI8VmVjdG9yU291cmNlPj4oXG4gICAgbmV3IFZlY3RvckxheWVyKHtcbiAgICAgIHNvdXJjZTogdGhpcy5zb3VyY2UoKSxcbiAgICB9KVxuICApO1xuICBwcml2YXRlIGdlb2xvY2F0aW9uTGlzdGVuZXJzOiB7XG4gICAgW3g6IHN0cmluZ106IChldmVudDogYW55KSA9PiB2b2lkO1xuICB9ID0ge1xuICAgICdjaGFuZ2U6YWNjdXJhY3lHZW9tZXRyeSc6IHRoaXMub25BY2N1cmFjeU9yR2VvbWV0cnlDaGFuZ2UuYmluZCh0aGlzKSxcbiAgICAnY2hhbmdlOnBvc2l0aW9uJzogdGhpcy5vblBvc2l0aW9uQ2hhbmdlLmJpbmQodGhpcyksXG4gIH07XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHB1YmxpYyB1cGRhdGVMYXllcigpIHt9XG5cbiAgcHVibGljIG92ZXJyaWRlIG9uQWRkKCkge1xuICAgIGNvbnN0IG9sTWFwID0gdGhpcy5tYXAoKS5zdGF0ZS5tYXAoKTtcbiAgICBpZiAob2xNYXApIHtcbiAgICAgIHRoaXMubGF5ZXIoKS5zZXRNYXAob2xNYXApO1xuICAgICAgdGhpcy5nZW9sb2NhdGlvbi5zZXQoXG4gICAgICAgIG5ldyBHZW9sb2NhdGlvbih7XG4gICAgICAgICAgdHJhY2tpbmdPcHRpb25zOiB7XG4gICAgICAgICAgICBlbmFibGVIaWdoQWNjdXJhY3k6IHRydWUsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBwcm9qZWN0aW9uOiBvbE1hcC5nZXRWaWV3KCkuZ2V0UHJvamVjdGlvbigpLFxuICAgICAgICB9KVxuICAgICAgKTtcblxuICAgICAgY29uc3QgZ2VvbG9jYXRpb24gPSB0aGlzLmdlb2xvY2F0aW9uKCk7XG4gICAgICBpZiAoZ2VvbG9jYXRpb24pIHtcbiAgICAgICAgZ2VvbG9jYXRpb24uc2V0VHJhY2tpbmcodHJ1ZSk7XG4gICAgICB9XG4gICAgICBPYmplY3Qua2V5cyh0aGlzLmdlb2xvY2F0aW9uTGlzdGVuZXJzKS5mb3JFYWNoKGtleSA9PiB7XG4gICAgICAgIGNvbnN0IGxpc3RlbmVyID0gdGhpcy5nZW9sb2NhdGlvbkxpc3RlbmVyc1trZXldO1xuICAgICAgICBpZiAoZ2VvbG9jYXRpb24pIHtcbiAgICAgICAgICBnZW9sb2NhdGlvbi5vbihrZXkgYXMgYW55LCBsaXN0ZW5lcik7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoJ0F0dGVtcHRlZCB0byBpbml0aWFsaXNlIGxheWVyIC0gbWFwIG5vdCBpbml0aWFsaXplZCcpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBvdmVycmlkZSBvblJlbW92ZSgpIHtcbiAgICBjb25zdCBnZW9sb2NhdGlvbiA9IHRoaXMuZ2VvbG9jYXRpb24oKTtcbiAgICBpZiAoZ2VvbG9jYXRpb24pIHtcbiAgICAgIE9iamVjdC5rZXlzKHRoaXMuZ2VvbG9jYXRpb25MaXN0ZW5lcnMpLmZvckVhY2goa2V5ID0+IHtcbiAgICAgICAgY29uc3QgbGlzdGVuZXIgPSB0aGlzLmdlb2xvY2F0aW9uTGlzdGVuZXJzW2tleV07XG4gICAgICAgIGlmIChnZW9sb2NhdGlvbikge1xuICAgICAgICAgIGdlb2xvY2F0aW9uLnVuKGtleSBhcyBhbnksIGxpc3RlbmVyKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG92ZXJyaWRlIG9uRGVzdHJveShvcGVubGF5ZXJzOiBPcGVubGF5ZXJzQ29tcG9uZW50KSB7XG4gICAgY29uc3QgZ2VvbG9jYXRpb24gPSB0aGlzLmdlb2xvY2F0aW9uKCk7XG4gICAgaWYgKGdlb2xvY2F0aW9uKSB7XG4gICAgICBPYmplY3Qua2V5cyh0aGlzLmdlb2xvY2F0aW9uTGlzdGVuZXJzKS5mb3JFYWNoKGtleSA9PiB7XG4gICAgICAgIGNvbnN0IGxpc3RlbmVyID0gdGhpcy5nZW9sb2NhdGlvbkxpc3RlbmVyc1trZXldO1xuICAgICAgICBpZiAoZ2VvbG9jYXRpb24pIHtcbiAgICAgICAgICBnZW9sb2NhdGlvbi51bihrZXkgYXMgYW55LCBsaXN0ZW5lcik7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgdGhpcy5tYXAoKS51cGRhdGVMYXllcihcbiAgICAgIHRoaXMsXG4gICAgICB0aGlzLm9uQWRkLmJpbmQodGhpcyksXG4gICAgICB0aGlzLm9uUmVtb3ZlLmJpbmQodGhpcylcbiAgICApO1xuICAgIHRoaXMucG9zaXRpb25GZWF0dXJlLnNldFN0eWxlKFxuICAgICAgbmV3IFN0eWxlKHtcbiAgICAgICAgaW1hZ2U6IG5ldyBDaXJjbGVTdHlsZSh7XG4gICAgICAgICAgcmFkaXVzOiA2LFxuICAgICAgICAgIGZpbGw6IG5ldyBGaWxsKHtcbiAgICAgICAgICAgIGNvbG9yOiAnIzMzOTlDQycsXG4gICAgICAgICAgfSksXG4gICAgICAgICAgc3Ryb2tlOiBuZXcgU3Ryb2tlKHtcbiAgICAgICAgICAgIGNvbG9yOiAnI2ZmZicsXG4gICAgICAgICAgICB3aWR0aDogMixcbiAgICAgICAgICB9KSxcbiAgICAgICAgfSksXG4gICAgICB9KVxuICAgICk7XG4gIH1cblxuICBwcml2YXRlIG9uQWNjdXJhY3lPckdlb21ldHJ5Q2hhbmdlKGV2dDogYW55KSB7XG4gICAgY29uc29sZS5sb2coJ0FjY3VyYWN5IG9yIGdlb21ldHJ5IGNoYW5nZScpO1xuICAgIGNvbnN0IGdlb2xvY2F0aW9uID0gdGhpcy5nZW9sb2NhdGlvbigpO1xuICAgIGlmIChnZW9sb2NhdGlvbikge1xuICAgICAgdGhpcy5hY2N1cmFjeUZlYXR1cmUuc2V0R2VvbWV0cnkoXG4gICAgICAgIGdlb2xvY2F0aW9uLmdldEFjY3VyYWN5R2VvbWV0cnkoKSA/PyB1bmRlZmluZWRcbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgJ0F0dGVtcHRlZCB0byB1cGRhdGUgYWNjdXJhY3kgb3IgZ2VvbWV0cnkgLSBnZW9sb2NhdGlvbiBub3QgaW5pdGlhbGl6ZWQnXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgb25Qb3NpdGlvbkNoYW5nZSgpIHtcbiAgICBjb25zb2xlLmxvZygnQ2hhbmdlZCBwb3NpdGlvbicpO1xuICAgIGNvbnN0IGdlb2xvY2F0aW9uID0gdGhpcy5nZW9sb2NhdGlvbigpO1xuICAgIGlmIChnZW9sb2NhdGlvbikge1xuICAgICAgY29uc3QgY29vcmRpbmF0ZXMgPSBnZW9sb2NhdGlvbi5nZXRQb3NpdGlvbigpO1xuICAgICAgdGhpcy5wb3NpdGlvbkZlYXR1cmUuc2V0R2VvbWV0cnkoXG4gICAgICAgIGNvb3JkaW5hdGVzID8gbmV3IFBvaW50KGNvb3JkaW5hdGVzKSA6IHVuZGVmaW5lZFxuICAgICAgKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAnQXR0ZW1wdGVkIHRvIHVwZGF0ZSBwb3NpdGlvbiAtIGdlb2xvY2F0aW9uIG5vdCBpbml0aWFsaXplZCdcbiAgICAgICk7XG4gICAgfVxuICB9XG59XG4iXX0=