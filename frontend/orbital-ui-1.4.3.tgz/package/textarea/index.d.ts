/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/textarea" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-textarea.d.ts.map