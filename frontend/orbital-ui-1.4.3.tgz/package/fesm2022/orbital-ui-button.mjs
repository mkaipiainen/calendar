import * as i0 from '@angular/core';
import { EventEmitter, Component, ChangeDetectionStrategy, Inject, ViewChild, Input, Output } from '@angular/core';
import { OuiIconComponent } from 'orbital-ui/icon';
import * as i1 from '@angular/common';
import { DOCUMENT, CommonModule } from '@angular/common';
import { OuiSpinnerComponent } from 'orbital-ui/spinner';
import { OuiRippleDirective } from 'orbital-ui/ripple';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

/**
 * A component that can be used to add simple buttons. The buttons are configurable by passing in a variant. You can also
 * add an icon to the button, and to show a loading-spinner in case some asynchronous operation is in progress and you want to show it.
 *
 * Example use:
 *
 * <oui-button variant="primary" (onClick)="onButtonClick($event)">Click me!</oui-button>
 *
 */
class OuiButtonComponent {
    renderer;
    document;
    destroyRef;
    cdr;
    button;
    set options(options) {
        const spinnerOptions = options?.spinnerOptions ?? this.getSpinnerOptions(options);
        this.#combinedOptions = {
            ...this.#defaultOptions,
            ...{ spinnerOptions: spinnerOptions },
            ...options,
        };
        if (this.isLoadingSubscription) {
            this.isLoadingSubscription.unsubscribe();
        }
        this.subscribeToDisabledObservable();
    }
    get options() {
        return this.#combinedOptions;
    }
    /**
     *   Event emitted on buttons click. Usually you want to tie a function to this event.
     */
    // eslint-disable-next-line @angular-eslint/no-output-on-prefix
    onClick = new EventEmitter();
    innerContainerRef;
    #defaultOptions = {
        variant: 'primary',
        disabled: false,
        isLoading: false,
        isLoading$: undefined,
        submitOnEnter: false,
        type: 'button',
        spinnerOptions: {
            size: '15px',
            color: 'color-primary',
        },
    };
    #combinedOptions = {
        variant: 'primary',
        disabled: false,
        isLoading: false,
        isLoading$: undefined,
        type: 'submit',
        submitOnEnter: false,
        spinnerOptions: {
            size: '15px',
            color: 'color-primary',
        },
    };
    isLoadingSubscription;
    isInitialized = false;
    unlistener;
    constructor(renderer, document, destroyRef, cdr) {
        this.renderer = renderer;
        this.document = document;
        this.destroyRef = destroyRef;
        this.cdr = cdr;
    }
    ngAfterViewInit() {
        if (this.options.submitOnEnter) {
            this.unlistener = this.renderer.listen(this.document, 'keyup', (event) => {
                if (event.key === 'Enter') {
                    this.emitClick(event);
                }
            });
        }
        setTimeout(() => {
            this.isInitialized = true;
            this.cdr.detectChanges();
        }, 300);
    }
    onEnterClick(event) {
        if (event.key === 'Enter') {
            this.emitClick(event);
        }
    }
    emitClick(event) {
        if (this.options.isLoading$) {
            this.options.isLoading = true;
            this.cdr.detectChanges();
        }
        this.onClick.emit(event);
    }
    ngOnDestroy() {
        if (this.options.submitOnEnter) {
            this.unlistener();
        }
    }
    subscribeToDisabledObservable() {
        if (this.options.isLoading$) {
            this.isLoadingSubscription = this.options.isLoading$
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe(() => {
                this.options.isLoading = false;
                this.cdr.detectChanges();
            });
        }
    }
    getSpinnerOptions(options) {
        const variant = options.variant ?? 'primary';
        return {
            color: `color-${variant}-text`,
            size: '15px',
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiButtonComponent, deps: [{ token: i0.Renderer2 }, { token: DOCUMENT }, { token: i0.DestroyRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiButtonComponent, isStandalone: true, selector: "oui-button", inputs: { options: "options" }, outputs: { onClick: "onClick" }, viewQueries: [{ propertyName: "button", first: true, predicate: ["button"], descendants: true }, { propertyName: "innerContainerRef", first: true, predicate: ["innerContainer"], descendants: true }], ngImport: i0, template: "<button\n  #button\n  [type]=\"options.type\"\n  class=\"oui-button {{options.variant}} {{isInitialized ? 'initialized' : ''}}\"\n  [ngClass]=\"{ disabled: options.isLoading || options.disabled }\"\n  (click)=\"emitClick($event)\"\n  ouiRipple\n  >\n  <div class=\"oui-button-inner-container\" #innerContainer>\n    @if (!options.isLoading) {\n      <ng-content></ng-content>\n    }\n    @if (options.isLoading) {\n      <oui-spinner [size]=\"options.spinnerOptions.size\" [color]=\"options.spinnerOptions.color\"></oui-spinner>\n    }\n  </div>\n</button>\n", styles: [":host{position:relative;display:flex;flex:1 0 auto;height:3.5rem}:host button{background:none;color:inherit;border:none;padding:0;font:inherit;cursor:pointer;outline:inherit}:host *{transition:none}:host .oui-button{position:relative;display:flex;justify-content:center;align-items:center;flex:1;border-width:var(--oui-button-border-width);border-style:var(--oui-button-border-style);border-color:var(--oui-button-border-color);border-radius:var(--border-radius-default);background-color:var(--oui-button-background-color);box-shadow:var(--oui-button-box-shadow);color:var(--oui-button-text-color);cursor:pointer}:host .oui-button:hover{background-color:var(--oui-button-background-color-hover)}:host .oui-button .oui-button-inner-container{flex:1 0 auto;width:100%;padding:4px 12px;display:flex;justify-content:center;align-items:center}:host .oui-button.disabled{opacity:.7;pointer-events:none;cursor:default}:host .oui-button.initialized{transition:background-color .3s}:host .oui-button.initialized *{transition:background-color .3s}:host .oui-button.secondary{background-color:var(--color-secondary);color:var(--color-secondary-text);border:1px solid var(--color-secondary-dark)}:host .oui-button.secondary:hover{background-color:var(--color-secondary-hover)}:host .oui-button.text{background-color:transparent;border-color:transparent;box-shadow:none;color:var(--oui-button-text-color)}:host .oui-button.text:hover{background-color:#0000000d}:host .oui-button.dark{background-color:var(--color-dark);color:var(--text-light);border:1px solid var(--color-dark);display:flex}:host .oui-button.dark:hover{background-color:var(--color-dark-hover)}:host .oui-button.custom{background-color:var(--oui-button-background-color);color:var(--oui-button-text-color);border:var(--oui-button-border-width) var(--oui-button-border-style) var(--oui-button-border-color);display:flex}:host .oui-button.custom:hover{background-color:var(--oui-button-background-color-hover)}:host .oui-button.light{background-color:var(--color-light);color:var(--text-dark);border:1px solid var(--text-dark);display:flex}:host .oui-button.light:hover{background-color:var(--color-light-hover)}:host .oui-button.success{background-color:var(--color-success);color:var(--color-success-text);border:1px solid var(--color-success);display:flex}:host .oui-button.success:hover{background-color:var(--color-success-hover)}:host .oui-button.warning{background-color:var(--color-warning);color:var(--color-warning-text);border:1px solid var(--color-warning);display:flex}:host .oui-button.warning:hover{background-color:var(--color-warning-hover)}:host .oui-button.info{background-color:var(--color-info);color:var(--color-info-text);border:1px solid var(--color-info);display:flex}:host .oui-button.info:hover{background-color:var(--color-info-hover)}:host .oui-button.error{background-color:var(--color-danger);color:var(--color-danger-text);border:1px solid var(--color-danger);display:flex}:host .oui-button.error:hover{background-color:var(--color-danger-hover)}:host .oui-button.muted{background-color:var(--color-muted);color:var(--color-muted-text);border:1px solid var(--color-muted);display:flex}:host .oui-button.muted:hover{background-color:var(--color-muted-hover)}:host .oui-button.primary{background-color:var(--color-primary);border:1px solid var(--color-primary);color:var(--color-primary-text);display:flex}:host .oui-button.primary:hover{background-color:var(--color-primary-hover);border-color:var(--color-primary-hover)}\n"], dependencies: [{ kind: "component", type: OuiSpinnerComponent, selector: "oui-spinner", inputs: ["color", "size", "type"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: OuiRippleDirective, selector: "[ouiRipple]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-button', standalone: true, imports: [
                        OuiSpinnerComponent,
                        OuiIconComponent,
                        CommonModule,
                        OuiRippleDirective,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<button\n  #button\n  [type]=\"options.type\"\n  class=\"oui-button {{options.variant}} {{isInitialized ? 'initialized' : ''}}\"\n  [ngClass]=\"{ disabled: options.isLoading || options.disabled }\"\n  (click)=\"emitClick($event)\"\n  ouiRipple\n  >\n  <div class=\"oui-button-inner-container\" #innerContainer>\n    @if (!options.isLoading) {\n      <ng-content></ng-content>\n    }\n    @if (options.isLoading) {\n      <oui-spinner [size]=\"options.spinnerOptions.size\" [color]=\"options.spinnerOptions.color\"></oui-spinner>\n    }\n  </div>\n</button>\n", styles: [":host{position:relative;display:flex;flex:1 0 auto;height:3.5rem}:host button{background:none;color:inherit;border:none;padding:0;font:inherit;cursor:pointer;outline:inherit}:host *{transition:none}:host .oui-button{position:relative;display:flex;justify-content:center;align-items:center;flex:1;border-width:var(--oui-button-border-width);border-style:var(--oui-button-border-style);border-color:var(--oui-button-border-color);border-radius:var(--border-radius-default);background-color:var(--oui-button-background-color);box-shadow:var(--oui-button-box-shadow);color:var(--oui-button-text-color);cursor:pointer}:host .oui-button:hover{background-color:var(--oui-button-background-color-hover)}:host .oui-button .oui-button-inner-container{flex:1 0 auto;width:100%;padding:4px 12px;display:flex;justify-content:center;align-items:center}:host .oui-button.disabled{opacity:.7;pointer-events:none;cursor:default}:host .oui-button.initialized{transition:background-color .3s}:host .oui-button.initialized *{transition:background-color .3s}:host .oui-button.secondary{background-color:var(--color-secondary);color:var(--color-secondary-text);border:1px solid var(--color-secondary-dark)}:host .oui-button.secondary:hover{background-color:var(--color-secondary-hover)}:host .oui-button.text{background-color:transparent;border-color:transparent;box-shadow:none;color:var(--oui-button-text-color)}:host .oui-button.text:hover{background-color:#0000000d}:host .oui-button.dark{background-color:var(--color-dark);color:var(--text-light);border:1px solid var(--color-dark);display:flex}:host .oui-button.dark:hover{background-color:var(--color-dark-hover)}:host .oui-button.custom{background-color:var(--oui-button-background-color);color:var(--oui-button-text-color);border:var(--oui-button-border-width) var(--oui-button-border-style) var(--oui-button-border-color);display:flex}:host .oui-button.custom:hover{background-color:var(--oui-button-background-color-hover)}:host .oui-button.light{background-color:var(--color-light);color:var(--text-dark);border:1px solid var(--text-dark);display:flex}:host .oui-button.light:hover{background-color:var(--color-light-hover)}:host .oui-button.success{background-color:var(--color-success);color:var(--color-success-text);border:1px solid var(--color-success);display:flex}:host .oui-button.success:hover{background-color:var(--color-success-hover)}:host .oui-button.warning{background-color:var(--color-warning);color:var(--color-warning-text);border:1px solid var(--color-warning);display:flex}:host .oui-button.warning:hover{background-color:var(--color-warning-hover)}:host .oui-button.info{background-color:var(--color-info);color:var(--color-info-text);border:1px solid var(--color-info);display:flex}:host .oui-button.info:hover{background-color:var(--color-info-hover)}:host .oui-button.error{background-color:var(--color-danger);color:var(--color-danger-text);border:1px solid var(--color-danger);display:flex}:host .oui-button.error:hover{background-color:var(--color-danger-hover)}:host .oui-button.muted{background-color:var(--color-muted);color:var(--color-muted-text);border:1px solid var(--color-muted);display:flex}:host .oui-button.muted:hover{background-color:var(--color-muted-hover)}:host .oui-button.primary{background-color:var(--color-primary);border:1px solid var(--color-primary);color:var(--color-primary-text);display:flex}:host .oui-button.primary:hover{background-color:var(--color-primary-hover);border-color:var(--color-primary-hover)}\n"] }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.DestroyRef }, { type: i0.ChangeDetectorRef }], propDecorators: { button: [{
                type: ViewChild,
                args: ['button']
            }], options: [{
                type: Input
            }], 
        // eslint-disable-next-line @angular-eslint/no-output-on-prefix
        onClick: [{
                type: Output
            }], innerContainerRef: [{
                type: ViewChild,
                args: ['innerContainer']
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiButtonComponent };
//# sourceMappingURL=orbital-ui-button.mjs.map
