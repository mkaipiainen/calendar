import { NgZone } from '@angular/core';
import { RequestQueueService } from 'orbital-ui/core';
import { OuiOpenlayersTileLayerOptions, OuiOpenlayersTileServiceOptions } from './types';
import * as i0 from "@angular/core";
/**
 * Service to handle fetching of raster-layers for the map.
 * Caches tiles in memory to prevent unnecessary requests.
 * Handles canceling of requests in case of the layer getting removed from the map, or the map being destroyed, and so on.
 * Also handles attaching the access token to the requests.
 */
export declare class OpenlayersTileLayerService {
    private requestQueueService;
    private zone;
    constructor(requestQueueService: RequestQueueService, zone: NgZone);
    /**
     * Returns a Deck.GL tileLayer-configuration for a map. This should work out of the gate by just giving the function
     * a unique ID (IMPORTANT), and the desired opticalImage-object. The function will then handle the rest.
     * @param id
     * @param data
     * @param options
     * @param layerOptions
     */
    getTileLayer<T>(options: OuiOpenlayersTileServiceOptions): OuiOpenlayersTileLayerOptions;
    private defaultUrlBuilder;
    private responseToObjectUrl;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpenlayersTileLayerService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OpenlayersTileLayerService>;
}
//# sourceMappingURL=openlayers-tile-layer.service.d.ts.map