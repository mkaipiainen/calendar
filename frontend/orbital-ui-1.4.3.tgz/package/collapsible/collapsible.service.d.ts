import { OuiCollapsibleContentComponent } from './collapsible-content/collapsible-content.component';
import { OuiCollapsibleToggleComponent } from './collapsible-toggle/collapsible-toggle.component';
import * as i0 from "@angular/core";
export interface ICollapsibleToggled {
    group: string;
    isOpen: boolean;
}
/**
 * Service used to control oui-collapsible-content and oui-collapsible-toggle.
 * All collapsibles are stored in this service, and you can programmatically toggle any group to be open or closed from here.
 * Contains a collapsibleToggled$ observable that you can subscribe to in order to be notified when a collapsible group is toggled
 */
export declare class OuiCollapsibleService {
    private collapsibleToggledSubject;
    private refreshCollapsibleContentHeightSubject;
    collapsibleToggled$: import("rxjs").Observable<ICollapsibleToggled>;
    refreshCollapsibleContentHeight$: import("rxjs").Observable<string>;
    private collapsibles;
    constructor();
    registerToggle(group: string, toggle: OuiCollapsibleToggleComponent): void;
    refreshCollapsibleContentHeight(group: string): void;
    registerContent(group: string, content: OuiCollapsibleContentComponent): void;
    deregisterCollapsible(group: string): void;
    toggle(group: string, isOpen?: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiCollapsibleService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiCollapsibleService>;
}
//# sourceMappingURL=collapsible.service.d.ts.map