import { OuiTabsComponent } from './tabs.component';
import { OuiTabComponent } from './tab.component';
import * as i0 from "@angular/core";
export declare class OuiTabsService {
    private tabSelectedSubject;
    tabSelected$: import("rxjs").Observable<OuiTabComponent>;
    tabs: {
        [id: string]: OuiTabsComponent;
    };
    constructor();
    registerTabs(tabs: OuiTabsComponent): void;
    selectTab(givenTab: OuiTabComponent | string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiTabsService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiTabsService>;
}
//# sourceMappingURL=tabs.service.d.ts.map