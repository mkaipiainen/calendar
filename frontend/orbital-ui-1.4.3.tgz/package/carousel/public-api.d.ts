export * from './carousel.component';
//# sourceMappingURL=public-api.d.ts.map