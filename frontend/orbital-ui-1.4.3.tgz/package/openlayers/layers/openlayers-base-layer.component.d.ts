import { DestroyRef, InputSignal, Signal, WritableSignal } from '@angular/core';
import { Feature as OlFeature } from 'ol';
import { OpenlayersComponent } from '../openlayers.component';
import { OuiOpenLayersCommonOptions } from '../types';
import * as i0 from "@angular/core";
export declare abstract class OpenlayersBaseLayerComponent<T extends OuiOpenLayersCommonOptions> {
    protected destroyRef: DestroyRef;
    abstract options: InputSignal<T> | undefined;
    abstract combinedOptions: Signal<T> | undefined;
    map: InputSignal<OpenlayersComponent>;
    isHovered: WritableSignal<boolean>;
    abstract layer: WritableSignal<any>;
    abstract source: WritableSignal<any>;
    private optionsChangedSubject;
    constructor();
    /**
     * This method is called whenever options of a layer are updated
     * Should update the source of the layer based on the new options
     * Updating on the side of the map is handled automatically
     * @param newOptions
     */
    abstract updateLayer(newOptions: T): void;
    /**
     * This method is called when the layer is added to the map
     * Override in child-classes if necessary
     * @param map
     * @protected
     */
    protected onAdd(map: OpenlayersComponent): void;
    /**
     * This method is called when the layer is removed from the map
     * Override in child-classes if necessary
     * @param map
     * @protected
     */
    protected onRemove(map: OpenlayersComponent): void;
    onHover(feature: OlFeature): void;
    onUnHover(feature: OlFeature): void;
    onClick(feature: OlFeature): void;
    onDestroy(openlayers: OpenlayersComponent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpenlayersBaseLayerComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpenlayersBaseLayerComponent<any>, "openlayers-base-layer", never, { "map": { "alias": "map"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=openlayers-base-layer.component.d.ts.map