import * as i0 from '@angular/core';
import { Injectable, Pipe, inject, ChangeDetectorRef, input, model, EventEmitter, computed, signal, effect, Component, ChangeDetectionStrategy, Inject, Input, Output, ViewChild, HostListener } from '@angular/core';
import { fromEvent, Subject, takeUntil } from 'rxjs';
import { createPopper } from '@popperjs/core';
import * as i2 from '@angular/common';
import { DOCUMENT, CommonModule } from '@angular/common';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { OuiIconComponent } from 'orbital-ui/icon';
import { OuiButtonComponent } from 'orbital-ui/button';
import { GUID } from 'orbital-ui/helpers';
import { merge, isPlainObject, xorBy } from 'lodash-es';
import { OuiInputComponent } from 'orbital-ui/input';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AutofocusDirective } from 'orbital-ui/autofocus';

/**
 * Service that keeps tracks and manages select-components.
 * Has a public method closeAll() that can be used to close all open select-components
 */
class OuiSelectService {
    clickObservable;
    dropdowns = [];
    constructor() {
        this.clickObservable = fromEvent(document, 'click');
    }
    register(dropdown) {
        this.dropdowns.push(dropdown);
    }
    closeAll() {
        for (const dropdown of this.dropdowns) {
            if ('cancel' in dropdown) {
                dropdown.cancel();
            }
            else {
                dropdown.close();
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSelectService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSelectService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSelectService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/**
 * Pipe to output either a caret up or down depending on value
 */
class IsSelectItemActivePipe {
    transform(item, selectedItems, idKey) {
        const isArray = Array.isArray(selectedItems);
        if (item[idKey]) {
            if (isArray) {
                return selectedItems.find((selectedItem) => selectedItem[idKey] === item[idKey]);
            }
            else {
                return selectedItems === item;
            }
        }
        else {
            if (isArray) {
                return selectedItems.find((selectedItem) => selectedItem === item);
            }
            else {
                return selectedItems === item;
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsSelectItemActivePipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: IsSelectItemActivePipe, isStandalone: true, name: "isSelectItemActive" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsSelectItemActivePipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'isSelectItemActive',
                    standalone: true,
                }]
        }] });

/**
 * Pipe to output either a caret up or down depending on value
 */
class SelectItemLabelPipe {
    transform(item, labelKey) {
        return item[labelKey] ?? item;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: SelectItemLabelPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: SelectItemLabelPipe, isStandalone: true, name: "selectItemLabel" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: SelectItemLabelPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'selectItemLabel',
                    standalone: true,
                }]
        }] });

/**
 * Component that can be used to create select-dropdowns.You can either pass simple strings in an array as the options to choose from,
 * or alternatively pass in objects with an additionally defined label-key and id-key.
 *
 * Example use:
 * <oui-select [(model)]="selectedItem" [idKey]="'value'" [labelKey]="'name'" [options]="selectValues"></oui-select>
 */
class OuiSelectComponent {
    vcr;
    ouiSelectService;
    destroyRef;
    document;
    cdr = inject(ChangeDetectorRef);
    /**
     *   labelKey       - The key in each object that's used to display a text in the dropdown.
     *   idKey          - The key in each object that is used to define which item is selected. Essentially the key in each object which should be used to differentiate each itme from each other item.
     *   type:          - The type of the select. Can be either 'standard' or 'underlined'. Defaults to 'standard'
     */
    options = input();
    isOpen = model(false);
    /**
     *   The options the user can choose from in the dropdown. If given a list of strings, simply shows those strings, and binds
     *   the model to the selected string. If given an array of objects, also need to pass in a labelKey and and idKey -input
     *   (although they are by default 'label' and 'id').
     */
    items = input.required();
    disabled = false;
    /**
     *   The model that's bound to the selected item
     */
    model;
    /**
     *   A template that should be used for each item. If none is given, then uses a default. This can be used if you need
     *   heavily customized dropdown-items
     */
    template;
    /**
     *   Triggered when model changes
     */
    modelChange = new EventEmitter();
    /**
     *   Triggered when dropdown closes
     */
    closed = new EventEmitter();
    dropdownContent;
    origin;
    defaultOptions = {
        labelKey: 'label',
        idKey: 'id',
        isMultiple: false,
        search: {
            isEnabled: false,
            isFocusedOnOpen: false,
        },
        isSelectingWithKeyboardActive: false,
        type: 'standard',
        contentClass: '',
        getToggleLabel: (item) => {
            return item[this.combinedOptions().labelKey] ?? item;
        },
    };
    currentDropdown;
    closed$ = new Subject();
    combinedOptions = computed(() => {
        return merge({ ...this.defaultOptions }, { ...this.options() });
    });
    view;
    popperRef;
    isClosing = false;
    id = GUID();
    dropdownHeight = signal('0px');
    selectToggleLabel = signal('');
    searchValue = signal('');
    itemType = computed(() => {
        return this.items()?.[0]?.[this.combinedOptions().idKey]
            ? 'object'
            : 'simple';
    });
    candidateForSelectionIndex = signal(0);
    filteredItems = computed(() => {
        if (!this.combinedOptions().search?.isEnabled) {
            return [...this.items()];
        }
        return this.items().filter(item => {
            const label = this.combinedOptions().labelKey && isPlainObject(item)
                ? item[this.combinedOptions().labelKey]
                : item;
            return label.toLowerCase().includes(this.searchValue().toLowerCase());
        });
    });
    constructor(vcr, ouiSelectService, destroyRef, document) {
        this.vcr = vcr;
        this.ouiSelectService = ouiSelectService;
        this.destroyRef = destroyRef;
        this.document = document;
        effect(() => {
            const dropdownHeightFromOptions = this.combinedOptions().dropdownHeight;
            if (dropdownHeightFromOptions) {
                this.dropdownHeight.set(dropdownHeightFromOptions);
            }
            if (this.model) {
                this.updateToggleLabel();
            }
        }, {
            allowSignalWrites: true,
        });
    }
    ngAfterViewInit() {
        this.ouiSelectService.register(this);
        this.updateToggleLabel();
        setTimeout(() => {
            if (this.isOpen()) {
                this.open();
            }
        }, 100);
    }
    get label() {
        if (typeof this.model === 'string') {
            return this.model;
        }
        else if (this.combinedOptions().labelKey) {
            return this.model
                ? this.model[this.combinedOptions().labelKey]
                : 'Select...';
        }
        else {
            console.error('Could not get label for the item');
            return '';
        }
    }
    select(option) {
        if (this.combinedOptions().isMultiple) {
            const comparator = this.itemType() === 'simple'
                ? (item) => item
                : this.combinedOptions().idKey;
            this.model = xorBy(this.model, [option], comparator);
        }
        else {
            let isCurrentlySelected = false;
            if (this.itemType() === 'simple') {
                isCurrentlySelected = this.model === option;
            }
            else {
                isCurrentlySelected =
                    this.model?.[this.combinedOptions().idKey] ===
                        option[this.combinedOptions().idKey];
            }
            if (isCurrentlySelected) {
                this.model = undefined;
            }
            else {
                this.model = option;
            }
            this.close();
        }
        this.modelChange.emit(this.model);
        this.updateToggleLabel();
    }
    updateToggleLabel() {
        let label = '';
        if (this.combinedOptions().isMultiple) {
            label = this.model.map(this.combinedOptions().getToggleLabel).join(', ');
        }
        else {
            label = this.model
                ? this.combinedOptions().getToggleLabel(this.model)
                : '';
        }
        this.selectToggleLabel.set(label);
    }
    open() {
        this.isOpen.set(true);
        this.view = this.vcr.createEmbeddedView(this.dropdownContent);
        this.currentDropdown = this.view.rootNodes[0];
        this.document.body.appendChild(this.currentDropdown);
        this.currentDropdown.style.width = `${this.origin.nativeElement.offsetWidth}px`;
        this.currentDropdown.classList.add('open');
        if (this.combinedOptions().search?.isEnabled) {
            this.currentDropdown.classList.add('has-search');
        }
        if (this.combinedOptions().contentClass) {
            this.currentDropdown.classList.add(this.combinedOptions().contentClass);
        }
        this.popperRef = createPopper(this.origin.nativeElement, this.currentDropdown, {
            placement: 'bottom-start',
            modifiers: [
                {
                    name: 'preventOverflow',
                    options: {
                        altAxis: true,
                        padding: 5,
                    },
                },
            ],
        });
        const observer = new ResizeObserver(() => {
            this.popperRef.update();
        });
        observer.observe(this.currentDropdown);
        fromEvent(this.document.body, 'keydown')
            .pipe(takeUntilDestroyed(this.destroyRef), takeUntil(this.closed$))
            .subscribe((event) => {
            if (this.combinedOptions().isSelectingWithKeyboardActive &&
                event.key === 'Enter') {
                event.preventDefault();
                event.stopPropagation();
                this.select(this.filteredItems()[this.candidateForSelectionIndex()]);
                if (!this.combinedOptions().isMultiple) {
                    this.close();
                }
            }
            if (event.key === 'Escape') {
                this.close();
            }
            if (this.combinedOptions().isSelectingWithKeyboardActive &&
                (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
                event.stopPropagation();
                event.preventDefault();
                const itemLength = this.filteredItems()?.length;
                if (event.key === 'ArrowDown') {
                    const newIndex = this.candidateForSelectionIndex() + 1 >= itemLength
                        ? 0
                        : this.candidateForSelectionIndex() + 1;
                    this.candidateForSelectionIndex.set(newIndex);
                }
                else {
                    const newIndex = this.candidateForSelectionIndex() - 1 < 0
                        ? itemLength - 1
                        : this.candidateForSelectionIndex() - 1;
                    this.candidateForSelectionIndex.set(newIndex);
                }
            }
        });
        setTimeout(() => {
            if (this.currentDropdown && observer) {
                observer.unobserve(this.currentDropdown);
            }
        }, 1000);
        setTimeout(() => {
            this.cdr.detectChanges();
        });
    }
    toggle() {
        if (this.isClosing) {
            return;
        }
        if (this.isOpen()) {
            this.close();
        }
        else {
            this.open();
        }
    }
    close() {
        this.closed$.next(true);
        this.isClosing = true;
        this.closed.emit();
        if (this.currentDropdown) {
            this.currentDropdown.classList.remove('open');
        }
        setTimeout(() => {
            if (this.view) {
                this.view.destroy();
            }
            if (this.popperRef) {
                this.popperRef.destroy();
            }
            this.view = null;
            this.popperRef = null;
            this.currentDropdown = null;
            this.isClosing = false;
        }, 300);
        this.isOpen.set(false);
    }
    onClick(event, targetElement) {
        if (!targetElement || !this.origin) {
            return;
        }
        const originBbox = this.origin.nativeElement.getBoundingClientRect();
        const dropdownBbox = this.view?.rootNodes?.[0]?.getBoundingClientRect();
        if (!dropdownBbox || !originBbox) {
            return;
        }
        const clickedInsideOrigin = event.clientX >= originBbox.left &&
            event.clientX <= originBbox.right &&
            event.clientY >= originBbox.top &&
            event.clientY <= originBbox.bottom;
        const clickedInsideDropdown = event.clientX >= dropdownBbox.left &&
            event.clientX <= dropdownBbox.right &&
            event.clientY >= dropdownBbox.top &&
            event.clientY <= dropdownBbox.bottom;
        if (!clickedInsideOrigin && !clickedInsideDropdown) {
            this.close();
        }
    }
    ngOnChanges(changes) {
        if (changes['model'] && this.combinedOptions()) {
            this.updateToggleLabel();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSelectComponent, deps: [{ token: i0.ViewContainerRef }, { token: OuiSelectService }, { token: i0.DestroyRef }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiSelectComponent, isStandalone: true, selector: "oui-select", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, isOpen: { classPropertyName: "isOpen", publicName: "isOpen", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: false, isRequired: false, transformFunction: null }, model: { classPropertyName: "model", publicName: "model", isSignal: false, isRequired: false, transformFunction: null }, template: { classPropertyName: "template", publicName: "template", isSignal: false, isRequired: false, transformFunction: null } }, outputs: { isOpen: "isOpenChange", modelChange: "modelChange", closed: "closed" }, host: { listeners: { "document:click": "onClick($event,$event.target)" } }, viewQueries: [{ propertyName: "dropdownContent", first: true, predicate: ["dropdown"], descendants: true }, { propertyName: "origin", first: true, predicate: ["origin"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div\n  class=\"oui-select-container {{ combinedOptions().type }}\"\n  id=\"{{ id }}\"\n  [ngClass]=\"{ active: isOpen(), disabled: disabled }\"\n  >\n  <div class=\"oui-select-toggle\" (click)=\"toggle()\" #origin>\n    <span>{{ selectToggleLabel() }}</span>\n    <div class=\"oui-select-toggle-caret pointer-events-none\">\n      @if (!isOpen()) {\n        <oui-icon\n          icon=\"assets/icons/caret_down.svg\"\n        [options]=\"{\n          strokeColor: 'oui-select-toggle-text-color',\n          fillColor: 'oui-select-toggle-text-color'\n        }\"\n        ></oui-icon>\n      }\n      @if (isOpen()) {\n        <oui-icon\n          icon=\"assets/icons/caret_up.svg\"\n        [options]=\"{\n          strokeColor: 'oui-select-toggle-text-color',\n          fillColor: 'oui-select-toggle-text-color'\n        }\"\n        ></oui-icon>\n      }\n    </div>\n  </div>\n  <ng-template #dropdown>\n    <div class=\"oui-select-content-container\" id=\"{{ id }}\">\n      @if (combinedOptions().search?.isEnabled) {\n        <div class=\"oui-select-search\">\n          <oui-input\n            ouiAutofocus\n            [isAutofocusEnabled]=\"!!combinedOptions().search?.isFocusedOnOpen\"\n            #searchInput\n            [options]=\"{\n              variant: 'underlined',\n              endIcon: {\n                icon: 'assets/icons/search.svg',\n                options: {\n                  fillColor: 'oui-select-search-icon-color',\n                  strokeColor: 'oui-select-search-icon-color',\n                  size: '1.8rem'\n                }\n              }\n            }\"\n            [model]=\"searchValue()\"\n            (modelChange)=\"searchValue.set($event)\"\n          ></oui-input>\n        </div>\n      }\n\n  <div\n    class=\"content oui-scrollbar oui-scrollbar-auto\"\n    >\n    @if (!filteredItems().length) {\n      <div>No results found...</div>\n    }\n\n    @for(item of filteredItems(); track item) {\n      <div\n        (click)=\"select(item)\"\n      >\n        @if (!template) {\n          <div\n            class=\"oui-select-option-container\"\n            [ngClass]=\"{\n                active:\n                  item | isSelectItemActive: this.model : combinedOptions().idKey,\n                candidateForSelection:\n                  combinedOptions().isSelectingWithKeyboardActive && $index === candidateForSelectionIndex()\n              }\"\n          >\n            <div class=\"option-label\">\n              {{ item | selectItemLabel: combinedOptions().labelKey }}\n            </div>\n            @if (\n              item | isSelectItemActive: this.model : combinedOptions().idKey\n              ) {\n              <div\n                class=\"option-active-icon\"\n              >\n                <oui-icon\n                  icon=\"assets/icons/check.svg\"\n                  [options]=\"{\n                    fillColor: 'oui-select-content-text',\n                    strokeColor: 'oui-select-content-text',\n                    size: '18px'\n                  }\"\n                ></oui-icon>\n              </div>\n            }\n          </div>\n        }\n\n        <ng-template\n          *ngTemplateOutlet=\"template; context: { $implicit: item, item: item }\"\n        >\n        </ng-template>\n      </div>\n    }\n\n  </div>\n</div>\n</ng-template>\n</div>\n", styles: [":host{height:100%;width:100%;position:relative}:host .oui-select-container{display:flex;border-style:var(--oui-select-border-style);border-width:var(--oui-select-border-width);border-color:var(--oui-select-border-color);height:100%;width:100%}:host .oui-select-container.disabled{opacity:.4;pointer-events:none;cursor:default}:host .oui-select-container.underlined{border:none;border-bottom:var(--oui-select-border-width) var(--oui-select-border-style) var(--oui-select-border-color)}:host .oui-select-container.active{border-color:var(--oui-select-border-color-active);box-shadow:0 0 1px 1px #00000017}:host .oui-select-container .oui-select-toggle{background:var(--oui-select-toggle-background);color:var(--oui-select-toggle-text-color);width:100%;display:flex;justify-content:space-between;align-items:center;padding:2px 4px}:host .oui-select-container .oui-select-toggle:hover{cursor:pointer}:host .oui-select-container .oui-select-toggle .oui-select-toggle-caret{height:100%;display:flex;justify-content:center;align-items:center}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: ScrollingModule }, { kind: "pipe", type: IsSelectItemActivePipe, name: "isSelectItemActive" }, { kind: "pipe", type: SelectItemLabelPipe, name: "selectItemLabel" }, { kind: "component", type: OuiInputComponent, selector: "oui-input", inputs: ["model", "options"], outputs: ["modelChange", "hasErrorChange"] }, { kind: "directive", type: AutofocusDirective, selector: "[ouiAutofocus]", inputs: ["isAutofocusEnabled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-select', standalone: true, imports: [
                        OuiIconComponent,
                        OuiButtonComponent,
                        CommonModule,
                        ScrollingModule,
                        IsSelectItemActivePipe,
                        SelectItemLabelPipe,
                        OuiInputComponent,
                        AutofocusDirective,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"oui-select-container {{ combinedOptions().type }}\"\n  id=\"{{ id }}\"\n  [ngClass]=\"{ active: isOpen(), disabled: disabled }\"\n  >\n  <div class=\"oui-select-toggle\" (click)=\"toggle()\" #origin>\n    <span>{{ selectToggleLabel() }}</span>\n    <div class=\"oui-select-toggle-caret pointer-events-none\">\n      @if (!isOpen()) {\n        <oui-icon\n          icon=\"assets/icons/caret_down.svg\"\n        [options]=\"{\n          strokeColor: 'oui-select-toggle-text-color',\n          fillColor: 'oui-select-toggle-text-color'\n        }\"\n        ></oui-icon>\n      }\n      @if (isOpen()) {\n        <oui-icon\n          icon=\"assets/icons/caret_up.svg\"\n        [options]=\"{\n          strokeColor: 'oui-select-toggle-text-color',\n          fillColor: 'oui-select-toggle-text-color'\n        }\"\n        ></oui-icon>\n      }\n    </div>\n  </div>\n  <ng-template #dropdown>\n    <div class=\"oui-select-content-container\" id=\"{{ id }}\">\n      @if (combinedOptions().search?.isEnabled) {\n        <div class=\"oui-select-search\">\n          <oui-input\n            ouiAutofocus\n            [isAutofocusEnabled]=\"!!combinedOptions().search?.isFocusedOnOpen\"\n            #searchInput\n            [options]=\"{\n              variant: 'underlined',\n              endIcon: {\n                icon: 'assets/icons/search.svg',\n                options: {\n                  fillColor: 'oui-select-search-icon-color',\n                  strokeColor: 'oui-select-search-icon-color',\n                  size: '1.8rem'\n                }\n              }\n            }\"\n            [model]=\"searchValue()\"\n            (modelChange)=\"searchValue.set($event)\"\n          ></oui-input>\n        </div>\n      }\n\n  <div\n    class=\"content oui-scrollbar oui-scrollbar-auto\"\n    >\n    @if (!filteredItems().length) {\n      <div>No results found...</div>\n    }\n\n    @for(item of filteredItems(); track item) {\n      <div\n        (click)=\"select(item)\"\n      >\n        @if (!template) {\n          <div\n            class=\"oui-select-option-container\"\n            [ngClass]=\"{\n                active:\n                  item | isSelectItemActive: this.model : combinedOptions().idKey,\n                candidateForSelection:\n                  combinedOptions().isSelectingWithKeyboardActive && $index === candidateForSelectionIndex()\n              }\"\n          >\n            <div class=\"option-label\">\n              {{ item | selectItemLabel: combinedOptions().labelKey }}\n            </div>\n            @if (\n              item | isSelectItemActive: this.model : combinedOptions().idKey\n              ) {\n              <div\n                class=\"option-active-icon\"\n              >\n                <oui-icon\n                  icon=\"assets/icons/check.svg\"\n                  [options]=\"{\n                    fillColor: 'oui-select-content-text',\n                    strokeColor: 'oui-select-content-text',\n                    size: '18px'\n                  }\"\n                ></oui-icon>\n              </div>\n            }\n          </div>\n        }\n\n        <ng-template\n          *ngTemplateOutlet=\"template; context: { $implicit: item, item: item }\"\n        >\n        </ng-template>\n      </div>\n    }\n\n  </div>\n</div>\n</ng-template>\n</div>\n", styles: [":host{height:100%;width:100%;position:relative}:host .oui-select-container{display:flex;border-style:var(--oui-select-border-style);border-width:var(--oui-select-border-width);border-color:var(--oui-select-border-color);height:100%;width:100%}:host .oui-select-container.disabled{opacity:.4;pointer-events:none;cursor:default}:host .oui-select-container.underlined{border:none;border-bottom:var(--oui-select-border-width) var(--oui-select-border-style) var(--oui-select-border-color)}:host .oui-select-container.active{border-color:var(--oui-select-border-color-active);box-shadow:0 0 1px 1px #00000017}:host .oui-select-container .oui-select-toggle{background:var(--oui-select-toggle-background);color:var(--oui-select-toggle-text-color);width:100%;display:flex;justify-content:space-between;align-items:center;padding:2px 4px}:host .oui-select-container .oui-select-toggle:hover{cursor:pointer}:host .oui-select-container .oui-select-toggle .oui-select-toggle-caret{height:100%;display:flex;justify-content:center;align-items:center}\n"] }]
        }], ctorParameters: () => [{ type: i0.ViewContainerRef }, { type: OuiSelectService }, { type: i0.DestroyRef }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { disabled: [{
                type: Input
            }], model: [{
                type: Input
            }], template: [{
                type: Input
            }], modelChange: [{
                type: Output
            }], closed: [{
                type: Output
            }], dropdownContent: [{
                type: ViewChild,
                args: ['dropdown']
            }], origin: [{
                type: ViewChild,
                args: ['origin']
            }], onClick: [{
                type: HostListener,
                args: ['document:click', ['$event', '$event.target']]
            }] } });

/**
 * This component should be used to select from groups of multiple different types of entities.
 * For a simple multi-select, use the oui-select component with the options `isMultiple` set to true.
 */
class OuiMultiSelectComponent {
    vcr;
    zone;
    ouiSelectService;
    document;
    options = {};
    model;
    template;
    bindValueToKey = '';
    modelChange = new EventEmitter();
    closed = new EventEmitter();
    dropdownContent;
    origin;
    internalModel = {};
    view;
    popperRef;
    isOpen = false;
    id = GUID();
    results = {};
    originalResults = {};
    originalInternalModel = {};
    constructor(vcr, zone, ouiSelectService, document) {
        this.vcr = vcr;
        this.zone = zone;
        this.ouiSelectService = ouiSelectService;
        this.document = document;
    }
    ngAfterViewInit() {
        this.initializePicker();
        this.ouiSelectService.register(this);
    }
    initializePicker() {
        if (this.options.sections) {
            for (const section of this.options.sections) {
                if (this.model[section.id]?.length) {
                    this.results[section.id] = section.items.filter(item => this.model[section.id].includes(section.bindToKey ? item[section.bindToKey] : item));
                    this.internalModel[section.id] = section.items.filter(item => !this.model[section.id].includes(section.bindToKey ? item[section.bindToKey] : item));
                }
                else {
                    this.results[section.id] = [];
                    this.internalModel[section.id] = section.items;
                }
            }
            this.originalInternalModel = { ...this.internalModel };
            this.originalResults = { ...this.results };
        }
    }
    open() {
        if (!this.dropdownContent) {
            console.warn('Tried to open multi-select, but no content was found');
            return;
        }
        if (!this.origin) {
            console.warn('Tried to open multi-select, but no origin was found');
            return;
        }
        this.isOpen = true;
        this.view = this.vcr.createEmbeddedView(this.dropdownContent);
        const dropdown = this.view.rootNodes[0];
        this.document.body.appendChild(dropdown);
        dropdown.style.width = `${this.origin.nativeElement.offsetWidth}px`;
        this.zone.runOutsideAngular(() => {
            if (!this.origin) {
                return;
            }
            this.popperRef = createPopper(this.origin.nativeElement, dropdown, {});
        });
        for (const sectionId in this.results) {
            this.originalResults[sectionId] = [...this.results[sectionId]];
        }
        for (const sectionId in this.internalModel) {
            this.originalInternalModel[sectionId] = [
                ...this.internalModel[sectionId],
            ];
        }
    }
    toggle() {
        if (this.isOpen) {
            this.close();
        }
        else {
            this.open();
        }
    }
    close() {
        this.closed.emit();
        if (this.popperRef) {
            this.popperRef.destroy();
        }
        if (this.view) {
            this.view.destroy();
        }
        this.isOpen = false;
        this.view = null;
        this.popperRef = null;
    }
    selectItem(item, selectedSection) {
        const optionSection = this.options.sections?.find(section => selectedSection.id === section.id);
        const actualItem = optionSection?.items.find(i => i.id === item.id);
        if (!this.results[selectedSection.id]) {
            this.results[selectedSection.id] = [actualItem];
        }
        else {
            this.results[selectedSection.id].push(actualItem);
        }
        this.internalModel[selectedSection.id] = this.internalModel[selectedSection.id].filter((i) => i.id !== item.id);
    }
    removeItem(item, sectionId) {
        this.results[sectionId] = this.results[sectionId].filter(i => i.id !== item.id);
        this.internalModel[sectionId].push(item);
    }
    submit() {
        this.originalResults = { ...this.results };
        this.originalInternalModel = { ...this.internalModel };
        this.modelChange.emit(this.results);
        this.close();
    }
    cancel() {
        this.results = { ...this.originalResults };
        this.internalModel = { ...this.originalInternalModel };
        this.close();
    }
    getResultsForSection(section) {
        return this.results[section.id];
    }
    getItemsForSection(section) {
        return this.internalModel[section.id];
    }
    getSelectedItems() {
        const allItemLabels = [];
        for (const sectionId in this.results) {
            const sectionLabelKey = this.options.sections?.find(s => s.id === sectionId)?.labelKey;
            allItemLabels.push(...this.results[sectionId].map((i) => i[sectionLabelKey]));
        }
        return allItemLabels.length ? allItemLabels.join(', ') : '';
    }
    getSectionsWithItems() {
        if (!this.options.sections) {
            return [];
        }
        return this.options.sections.filter(s => this.internalModel[s.id]?.length > 0);
    }
    getSectionsWithResults() {
        if (!this.options.sections) {
            return [];
        }
        return this.options.sections.filter(s => this.results[s.id]?.length > 0);
    }
    ngOnChanges(changes) {
        if (changes['options']) {
            this.options = changes['options'].currentValue;
            setTimeout(() => {
                this.initializePicker();
            });
        }
    }
    onClick(event, targetElement) {
        if (!targetElement || !this.origin) {
            return;
        }
        const originBbox = this.origin.nativeElement.getBoundingClientRect();
        const dropdownBbox = this.view?.rootNodes?.[0]?.getBoundingClientRect();
        if (!dropdownBbox || !originBbox) {
            return;
        }
        const clickedInsideOrigin = event.clientX >= originBbox.left &&
            event.clientX <= originBbox.right &&
            event.clientY >= originBbox.top &&
            event.clientY <= originBbox.bottom;
        const clickedInsideDropdown = event.clientX >= dropdownBbox.left &&
            event.clientX <= dropdownBbox.right &&
            event.clientY >= dropdownBbox.top &&
            event.clientY <= dropdownBbox.bottom;
        if (!clickedInsideOrigin && !clickedInsideDropdown) {
            this.close();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMultiSelectComponent, deps: [{ token: i0.ViewContainerRef }, { token: i0.NgZone }, { token: OuiSelectService }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiMultiSelectComponent, isStandalone: true, selector: "oui-multi-select", inputs: { options: "options", model: "model", template: "template", bindValueToKey: "bindValueToKey" }, outputs: { modelChange: "modelChange", closed: "closed" }, host: { listeners: { "document:click": "onClick($event,$event.target)" } }, viewQueries: [{ propertyName: "dropdownContent", first: true, predicate: ["dropdown"], descendants: true }, { propertyName: "origin", first: true, predicate: ["origin"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"oui-multi-select-container\" id=\"{{ id }}\">\n  <div class=\"oui-multi-select-toggle\" (click)=\"toggle()\" #origin>\n    <div class=\"select-label-container\">\n      {{ getSelectedItems() }}\n    </div>\n\n    <div class=\"oui-multi-select-toggle-caret pointer-events-none\">\n      @if (!isOpen) {\n        <oui-icon\n          icon=\"assets/icons/caret_down.svg\"\n        [options]=\"{\n          strokeColor: 'oui-multi-select-toggle-text-color',\n          fillColor: 'oui-multi-select-toggle-text-color'\n        }\"\n        ></oui-icon>\n      }\n      @if (isOpen) {\n        <oui-icon\n          icon=\"assets/icons/caret_up.svg\"\n        [options]=\"{\n          strokeColor: 'oui-multi-select-toggle-text-color',\n          fillColor: 'oui-multi-select-toggle-text-color'\n        }\"\n        ></oui-icon>\n      }\n    </div>\n  </div>\n  <ng-template #dropdown>\n    <div class=\"oui-multi-select-dropdown\">\n      <div class=\"oui-multi-select-content-container\" id=\"{{ id }}\">\n        <div class=\"oui-multi-select-item-select-container\">\n          @for (section of getSectionsWithItems(); track section) {\n            <div\n              class=\"oui-multi-select-content-section\"\n              >\n              <div class=\"oui-multi-select-content-title-container\">\n                <div class=\"oui-multi-select-content-title\">\n                  {{ section.title }}\n                </div>\n              </div>\n              <div class=\"oui-multi-select-content-items\">\n                @for (item of getItemsForSection(section); track item) {\n                  <div\n                    class=\"oui-multi-select-content-item\"\n                    (click)=\"selectItem(item, section)\"\n                    >\n                    {{ item[section.labelKey] }}\n                  </div>\n                }\n              </div>\n            </div>\n          }\n        </div>\n        <div class=\"oui-multi-select-results-container\">\n          @for (section of getSectionsWithResults(); track section) {\n            <div\n              class=\"oui-multi-select-results-section\"\n              >\n              <div class=\"oui-multi-select-results-section-title-container\">\n                <div class=\"oui-multi-select-results-section-title\">\n                  {{ section.title }}\n                </div>\n              </div>\n              <div class=\"oui-multi-select-results-section-items\">\n                @for (item of getResultsForSection(section); track item) {\n                  <div\n                    class=\"oui-multi-select-results-section-item\"\n                    (click)=\"removeItem(item, section.id)\"\n                    >\n                    <div class=\"item-label\">\n                      {{ item[section.labelKey] }}\n                    </div>\n                    <div class=\"item-remove-icon\">\n                      <oui-icon\n                    [options]=\"{\n                      size: '12px',\n                      strokeColor: 'color-background-primary-text',\n                      fillColor: 'color-background-primary-text'\n                    }\"\n                        icon=\"assets/icons/close.svg\"\n                      ></oui-icon>\n                    </div>\n                  </div>\n                }\n              </div>\n            </div>\n          }\n        </div>\n      </div>\n      <div class=\"oui-multi-select-button-container\">\n        <div class=\"oui-multi-select-button-inner-wrapper\">\n          <oui-button (onClick)=\"cancel()\" variant=\"muted\">Cancel</oui-button>\n          <oui-button (onClick)=\"submit()\" variant=\"primary\">Submit</oui-button>\n        </div>\n      </div>\n    </div>\n  </ng-template>\n</div>\n", styles: [":host{height:100%;width:100%;position:relative}:host .oui-multi-select-container{display:flex;border-color:var(--oui-multi-select-toggle-border-color);border-style:var(--oui-multi-select-toggle-border-style);border-width:var(--oui-multi-select-toggle-border-width);height:100%;width:100%}:host .oui-multi-select-container .oui-multi-select-toggle{background:var(--oui-multi-select-toggle-background);color:var(--oui-multi-select-toggle-text-color);width:100%;display:flex;justify-content:space-between;align-items:center;position:relative}:host .oui-multi-select-container .oui-multi-select-toggle:hover{cursor:pointer}:host .oui-multi-select-container .oui-multi-select-toggle .select-label-container{max-width:90%;overflow-x:hidden;display:flex;align-items:center;flex:1 1 0;padding:2px 4px;white-space:nowrap}:host .oui-multi-select-container .oui-multi-select-toggle .oui-multi-select-toggle-caret{height:100%;display:flex;justify-content:center;align-items:center}\n"], dependencies: [{ kind: "component", type: OuiButtonComponent, selector: "oui-button", inputs: ["options"], outputs: ["onClick"] }, { kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "ngmodule", type: ScrollingModule }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMultiSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-multi-select', standalone: true, imports: [
                        OuiButtonComponent,
                        OuiIconComponent,
                        ScrollingModule
                    ], template: "<div class=\"oui-multi-select-container\" id=\"{{ id }}\">\n  <div class=\"oui-multi-select-toggle\" (click)=\"toggle()\" #origin>\n    <div class=\"select-label-container\">\n      {{ getSelectedItems() }}\n    </div>\n\n    <div class=\"oui-multi-select-toggle-caret pointer-events-none\">\n      @if (!isOpen) {\n        <oui-icon\n          icon=\"assets/icons/caret_down.svg\"\n        [options]=\"{\n          strokeColor: 'oui-multi-select-toggle-text-color',\n          fillColor: 'oui-multi-select-toggle-text-color'\n        }\"\n        ></oui-icon>\n      }\n      @if (isOpen) {\n        <oui-icon\n          icon=\"assets/icons/caret_up.svg\"\n        [options]=\"{\n          strokeColor: 'oui-multi-select-toggle-text-color',\n          fillColor: 'oui-multi-select-toggle-text-color'\n        }\"\n        ></oui-icon>\n      }\n    </div>\n  </div>\n  <ng-template #dropdown>\n    <div class=\"oui-multi-select-dropdown\">\n      <div class=\"oui-multi-select-content-container\" id=\"{{ id }}\">\n        <div class=\"oui-multi-select-item-select-container\">\n          @for (section of getSectionsWithItems(); track section) {\n            <div\n              class=\"oui-multi-select-content-section\"\n              >\n              <div class=\"oui-multi-select-content-title-container\">\n                <div class=\"oui-multi-select-content-title\">\n                  {{ section.title }}\n                </div>\n              </div>\n              <div class=\"oui-multi-select-content-items\">\n                @for (item of getItemsForSection(section); track item) {\n                  <div\n                    class=\"oui-multi-select-content-item\"\n                    (click)=\"selectItem(item, section)\"\n                    >\n                    {{ item[section.labelKey] }}\n                  </div>\n                }\n              </div>\n            </div>\n          }\n        </div>\n        <div class=\"oui-multi-select-results-container\">\n          @for (section of getSectionsWithResults(); track section) {\n            <div\n              class=\"oui-multi-select-results-section\"\n              >\n              <div class=\"oui-multi-select-results-section-title-container\">\n                <div class=\"oui-multi-select-results-section-title\">\n                  {{ section.title }}\n                </div>\n              </div>\n              <div class=\"oui-multi-select-results-section-items\">\n                @for (item of getResultsForSection(section); track item) {\n                  <div\n                    class=\"oui-multi-select-results-section-item\"\n                    (click)=\"removeItem(item, section.id)\"\n                    >\n                    <div class=\"item-label\">\n                      {{ item[section.labelKey] }}\n                    </div>\n                    <div class=\"item-remove-icon\">\n                      <oui-icon\n                    [options]=\"{\n                      size: '12px',\n                      strokeColor: 'color-background-primary-text',\n                      fillColor: 'color-background-primary-text'\n                    }\"\n                        icon=\"assets/icons/close.svg\"\n                      ></oui-icon>\n                    </div>\n                  </div>\n                }\n              </div>\n            </div>\n          }\n        </div>\n      </div>\n      <div class=\"oui-multi-select-button-container\">\n        <div class=\"oui-multi-select-button-inner-wrapper\">\n          <oui-button (onClick)=\"cancel()\" variant=\"muted\">Cancel</oui-button>\n          <oui-button (onClick)=\"submit()\" variant=\"primary\">Submit</oui-button>\n        </div>\n      </div>\n    </div>\n  </ng-template>\n</div>\n", styles: [":host{height:100%;width:100%;position:relative}:host .oui-multi-select-container{display:flex;border-color:var(--oui-multi-select-toggle-border-color);border-style:var(--oui-multi-select-toggle-border-style);border-width:var(--oui-multi-select-toggle-border-width);height:100%;width:100%}:host .oui-multi-select-container .oui-multi-select-toggle{background:var(--oui-multi-select-toggle-background);color:var(--oui-multi-select-toggle-text-color);width:100%;display:flex;justify-content:space-between;align-items:center;position:relative}:host .oui-multi-select-container .oui-multi-select-toggle:hover{cursor:pointer}:host .oui-multi-select-container .oui-multi-select-toggle .select-label-container{max-width:90%;overflow-x:hidden;display:flex;align-items:center;flex:1 1 0;padding:2px 4px;white-space:nowrap}:host .oui-multi-select-container .oui-multi-select-toggle .oui-multi-select-toggle-caret{height:100%;display:flex;justify-content:center;align-items:center}\n"] }]
        }], ctorParameters: () => [{ type: i0.ViewContainerRef }, { type: i0.NgZone }, { type: OuiSelectService }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { options: [{
                type: Input
            }], model: [{
                type: Input
            }], template: [{
                type: Input
            }], bindValueToKey: [{
                type: Input
            }], modelChange: [{
                type: Output
            }], closed: [{
                type: Output
            }], dropdownContent: [{
                type: ViewChild,
                args: ['dropdown']
            }], origin: [{
                type: ViewChild,
                args: ['origin']
            }], onClick: [{
                type: HostListener,
                args: ['document:click', ['$event', '$event.target']]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiMultiSelectComponent, OuiSelectComponent, OuiSelectService };
//# sourceMappingURL=orbital-ui-select.mjs.map
