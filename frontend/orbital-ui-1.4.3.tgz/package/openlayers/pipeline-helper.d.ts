import { Position } from '@turf/helpers';
import { OpenlayersComponent } from './openlayers.component';
export declare class PipelineHelper {
    private map;
    private state;
    private pipelineSubject;
    pipeline$: import("rxjs").Observable<{
        dpp: number;
        bounds: Position[];
    }>;
    constructor(map: OpenlayersComponent);
    startPipelineSubscription(): void;
    private getBoundingBoxDimensions;
}
//# sourceMappingURL=pipeline-helper.d.ts.map