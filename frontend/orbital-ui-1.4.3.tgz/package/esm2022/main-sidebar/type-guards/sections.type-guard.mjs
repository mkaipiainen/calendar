import { Pipe } from '@angular/core';
import { MAIN_SIDEBAR_SECTION_TYPES, } from '../main-sidebar.service';
import * as i0 from "@angular/core";
export class IsRouteSectionOptionsPipe {
    transform(value) {
        return (value.type === MAIN_SIDEBAR_SECTION_TYPES.ROUTE ||
            value.type === MAIN_SIDEBAR_SECTION_TYPES.SUBROUTE);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsRouteSectionOptionsPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: IsRouteSectionOptionsPipe, isStandalone: true, name: "isRouteSectionOptions" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsRouteSectionOptionsPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'isRouteSectionOptions',
                    standalone: true,
                }]
        }] });
export class IsActionSectionOptionsPipe {
    transform(value) {
        return value.type === MAIN_SIDEBAR_SECTION_TYPES.ACTION;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsActionSectionOptionsPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: IsActionSectionOptionsPipe, isStandalone: true, name: "isActionSectionOptions" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsActionSectionOptionsPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'isActionSectionOptions',
                    standalone: true,
                }]
        }] });
export class IsSubSectionOptionsPipe {
    transform(value) {
        return value.type === MAIN_SIDEBAR_SECTION_TYPES.SUBSECTION;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsSubSectionOptionsPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: IsSubSectionOptionsPipe, isStandalone: true, name: "isSubsectionOptions" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsSubSectionOptionsPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'isSubsectionOptions',
                    standalone: true,
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VjdGlvbnMudHlwZS1ndWFyZC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvbWFpbi1zaWRlYmFyL3R5cGUtZ3VhcmRzL3NlY3Rpb25zLnR5cGUtZ3VhcmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUNyQyxPQUFPLEVBQ0wsMEJBQTBCLEdBRTNCLE1BQU0seUJBQXlCLENBQUM7O0FBU2pDLE1BQU0sT0FBTyx5QkFBeUI7SUFDcEMsU0FBUyxDQUNQLEtBQW1DO1FBRW5DLE9BQU8sQ0FDTCxLQUFLLENBQUMsSUFBSSxLQUFLLDBCQUEwQixDQUFDLEtBQUs7WUFDL0MsS0FBSyxDQUFDLElBQUksS0FBSywwQkFBMEIsQ0FBQyxRQUFRLENBQ25ELENBQUM7SUFDSixDQUFDO3VHQVJVLHlCQUF5QjtxR0FBekIseUJBQXlCOzsyRkFBekIseUJBQXlCO2tCQUpyQyxJQUFJO21CQUFDO29CQUNKLElBQUksRUFBRSx1QkFBdUI7b0JBQzdCLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjs7QUFnQkQsTUFBTSxPQUFPLDBCQUEwQjtJQUNyQyxTQUFTLENBQ1AsS0FBbUM7UUFFbkMsT0FBTyxLQUFLLENBQUMsSUFBSSxLQUFLLDBCQUEwQixDQUFDLE1BQU0sQ0FBQztJQUMxRCxDQUFDO3VHQUxVLDBCQUEwQjtxR0FBMUIsMEJBQTBCOzsyRkFBMUIsMEJBQTBCO2tCQUp0QyxJQUFJO21CQUFDO29CQUNKLElBQUksRUFBRSx3QkFBd0I7b0JBQzlCLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjs7QUFhRCxNQUFNLE9BQU8sdUJBQXVCO0lBQ2xDLFNBQVMsQ0FDUCxLQUFtQztRQUVuQyxPQUFPLEtBQUssQ0FBQyxJQUFJLEtBQUssMEJBQTBCLENBQUMsVUFBVSxDQUFDO0lBQzlELENBQUM7dUdBTFUsdUJBQXVCO3FHQUF2Qix1QkFBdUI7OzJGQUF2Qix1QkFBdUI7a0JBSm5DLElBQUk7bUJBQUM7b0JBQ0osSUFBSSxFQUFFLHFCQUFxQjtvQkFDM0IsVUFBVSxFQUFFLElBQUk7aUJBQ2pCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGlwZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgTUFJTl9TSURFQkFSX1NFQ1RJT05fVFlQRVMsXG4gIE91aU1haW5TaWRlYmFyU2VjdGlvbk9wdGlvbnMsXG59IGZyb20gJy4uL21haW4tc2lkZWJhci5zZXJ2aWNlJztcbmltcG9ydCB7IE91aU1haW5TaWRlYmFyUm91dGVTZWN0aW9uT3B0aW9ucyB9IGZyb20gJy4uL21haW4tc2lkZWJhci1yb3V0ZS1zZWN0aW9uL21haW4tc2lkZWJhci1yb3V0ZS1zZWN0aW9uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBPdWlNYWluU2lkZWJhckFjdGlvblNlY3Rpb25PcHRpb25zIH0gZnJvbSAnLi4vbWFpbi1zaWRlYmFyLWFjdGlvbi1zZWN0aW9uL21haW4tc2lkZWJhci1hY3Rpb24tc2VjdGlvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgT3VpTWFpblNpZGViYXJTdWJzZWN0aW9uT3B0aW9ucyB9IGZyb20gJy4uL21haW4tc2lkZWJhci1zdWItc2VjdGlvbi9tYWluLXNpZGViYXItc3ViLXNlY3Rpb24uY29tcG9uZW50JztcblxuQFBpcGUoe1xuICBuYW1lOiAnaXNSb3V0ZVNlY3Rpb25PcHRpb25zJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbn0pXG5leHBvcnQgY2xhc3MgSXNSb3V0ZVNlY3Rpb25PcHRpb25zUGlwZSB7XG4gIHRyYW5zZm9ybShcbiAgICB2YWx1ZTogT3VpTWFpblNpZGViYXJTZWN0aW9uT3B0aW9uc1xuICApOiB2YWx1ZSBpcyBPdWlNYWluU2lkZWJhclJvdXRlU2VjdGlvbk9wdGlvbnMge1xuICAgIHJldHVybiAoXG4gICAgICB2YWx1ZS50eXBlID09PSBNQUlOX1NJREVCQVJfU0VDVElPTl9UWVBFUy5ST1VURSB8fFxuICAgICAgdmFsdWUudHlwZSA9PT0gTUFJTl9TSURFQkFSX1NFQ1RJT05fVFlQRVMuU1VCUk9VVEVcbiAgICApO1xuICB9XG59XG5cbkBQaXBlKHtcbiAgbmFtZTogJ2lzQWN0aW9uU2VjdGlvbk9wdGlvbnMnLFxuICBzdGFuZGFsb25lOiB0cnVlLFxufSlcbmV4cG9ydCBjbGFzcyBJc0FjdGlvblNlY3Rpb25PcHRpb25zUGlwZSB7XG4gIHRyYW5zZm9ybShcbiAgICB2YWx1ZTogT3VpTWFpblNpZGViYXJTZWN0aW9uT3B0aW9uc1xuICApOiB2YWx1ZSBpcyBPdWlNYWluU2lkZWJhckFjdGlvblNlY3Rpb25PcHRpb25zIHtcbiAgICByZXR1cm4gdmFsdWUudHlwZSA9PT0gTUFJTl9TSURFQkFSX1NFQ1RJT05fVFlQRVMuQUNUSU9OO1xuICB9XG59XG5cbkBQaXBlKHtcbiAgbmFtZTogJ2lzU3Vic2VjdGlvbk9wdGlvbnMnLFxuICBzdGFuZGFsb25lOiB0cnVlLFxufSlcbmV4cG9ydCBjbGFzcyBJc1N1YlNlY3Rpb25PcHRpb25zUGlwZSB7XG4gIHRyYW5zZm9ybShcbiAgICB2YWx1ZTogT3VpTWFpblNpZGViYXJTZWN0aW9uT3B0aW9uc1xuICApOiB2YWx1ZSBpcyBPdWlNYWluU2lkZWJhclN1YnNlY3Rpb25PcHRpb25zIHtcbiAgICByZXR1cm4gdmFsdWUudHlwZSA9PT0gTUFJTl9TSURFQkFSX1NFQ1RJT05fVFlQRVMuU1VCU0VDVElPTjtcbiAgfVxufVxuIl19