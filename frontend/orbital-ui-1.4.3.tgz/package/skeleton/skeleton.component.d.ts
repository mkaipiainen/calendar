import { OnChanges, OnInit, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
export interface ISkeletonSingleOptions {
    type: 'single';
    width?: string;
    height?: string;
    borderRadius?: string;
    backgroundImageOptions?: {
        backgroundImage: string;
        backgroundSize?: string;
        backgroundPosition?: string;
    };
}
export interface ISkeletonRow {
    height: string;
    margin: string;
}
export interface ISkeletonAutoRow {
    count: number;
    margin: string;
}
export interface ISkeletonAutoColumn {
    count: number;
    margin: string;
}
export interface ISkeletonColumn {
    width: string;
    margin: string;
}
export interface ISkeletonGridOptions {
    type: 'grid';
    rows: ISkeletonAutoRow | ISkeletonRow[];
    columns: ISkeletonAutoColumn | ISkeletonColumn[];
    borderRadius?: string;
    width?: string;
    height?: string;
}
export interface ISkeletonTableOptions {
    type: 'table';
    rows: {
        count: number;
        verticalSpacing: string;
        height: string;
    };
    columns: {
        count: number;
    };
    header?: {
        margin?: string;
        height?: string;
    };
    cells: {
        inset: string;
        horizontalSpacing: string;
    };
}
export type ISkeletonOptions = ISkeletonSingleOptions | ISkeletonGridOptions | ISkeletonTableOptions;
/**
 * This component streamlines creation of skeleton loading-sections. Has a few different modes you can choose from, although
 * right now the table-mode is probably the most useful one.
 *
 * Example use:
 *
 *  <oui-skeleton [options]="loadingSkeletonOptions" *ngIf="isLoading && loadingSkeletonOptions.rows.count">
 *  </oui-skeleton>
 *
 *  Where loadingSkeletonOptions are
 *
 *  public loadingSkeletonOptions: ISkeletonTableOptions = {
 *    type: 'table',
 *    rows: {
 *      count: 0,
 *      verticalSpacing: '10px',
 *      height: '25px',
 *    },
 *    columns: {
 *      count: 4,
 *    },
 *    cells: {
 *      inset: '4px',
 *      horizontalSpacing: '4px',
 *    },
 *    header: {
 *      margin: '14px',
 *      height: '30px',
 *    }
 *  }
 */
export declare class OuiSkeletonComponent implements OnInit, OnChanges {
    /**
     *   The options that define the skeleton. Currently suggested to use only the table-mode until further modes have been implemented.
     */
    options: ISkeletonOptions;
    columns: ISkeletonColumn[];
    rows: ISkeletonRow[];
    constructor();
    private combineOptions;
    getRowStyle(row: ISkeletonRow): {
        height: string;
        margin: string;
    };
    getColumnStyle(column: ISkeletonColumn): {
        width: string;
        margin: string;
    };
    getTableRowStyle(type: 'head' | 'body'): {
        height: string;
        margin: string;
    };
    getTableCellStyle(): {
        [x: string]: string;
    };
    getTableInnerCellStyle(): {
        [x: string]: string;
    };
    getSingleStyle(): {
        [x: string]: string;
    };
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiSkeletonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiSkeletonComponent, "oui-skeleton", never, { "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=skeleton.component.d.ts.map