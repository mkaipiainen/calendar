import { Component, computed, EventEmitter, input, model, Output, ViewChild, } from '@angular/core';
import { debounce, isNil, merge, throttle } from 'lodash-es';
import { CommonModule } from '@angular/common';
import { OuiIconComponent } from 'orbital-ui/icon';
import { OuiDraggableDirective } from 'orbital-ui/draggable';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export class OuiSliderComponent {
    thumbFrom;
    thumbFromContainer;
    thumbFromDraggable;
    thumbTo;
    thumbToContainer;
    thumbToDraggable;
    sliderBar;
    /**
     * The model for 'smaller' value. Use this alone if you want just a single-thumb mode.
     */
    value = model.required();
    /**
     * The model for the 'larger' value. Can be only used together with value-input
     */
    valueTo = model();
    /**
     * The options of the slider.
     */
    options = input.required();
    combinedOptions = computed(() => {
        const minLabel = this.options().minLabel ?? this.options().min.toString();
        const maxLabel = this.options().maxLabel ?? this.options().max.toString();
        return merge({ ...this.defaultOptions }, { ...this.options(), ...{ minLabel, maxLabel } });
    });
    /**
     * The event that's triggered whenever value changes (even by a little bit)
     */
    /**
     * The event that's triggered whenever the value changed, but this event is debounced by 300ms.
     */
    debouncedvalueChange = new EventEmitter();
    /**
     * The event that's triggered whenever valueTo changes (even by a little bit)
     */
    /**
     * The event that's triggered whenever the valueTo changed, but this event is debounced by 300ms.
     */
    debouncedValueToChange = new EventEmitter();
    defaultOptions = {
        min: 0,
        max: 100,
        minLabel: '0',
        maxLabel: '100',
        alignment: 'horizontal',
    };
    resizeObserver;
    _debouncedValueToChange = debounce((value) => {
        this.debouncedValueToChange.emit(value);
    }, 300);
    _debouncedvalueChange = debounce((value) => {
        this.debouncedvalueChange.emit(value);
    }, 300);
    constructor() { }
    updateBarFill() {
        const valueTo = this.valueTo();
        const value = this.value();
        if (!isNil(valueTo)) {
            const fillElement = this.sliderBar?.nativeElement?.querySelector(`.slider-bar-section-fill`);
            if (!fillElement) {
                return;
            }
            const percentageFrom = ((value - this.combinedOptions().min) /
                (this.combinedOptions().max - this.combinedOptions().min)) *
                100;
            const percentageTo = ((valueTo - this.combinedOptions().min) /
                (this.combinedOptions().max - this.combinedOptions().min)) *
                100;
            fillElement.style.width = `calc(${percentageTo}% - ${percentageFrom}%)`;
            fillElement.style.left = `calc(${percentageFrom}%`;
        }
        else {
            const fillElement = this.sliderBar?.nativeElement?.querySelector(`.slider-bar-section-fill`);
            if (!fillElement) {
                return;
            }
            const percentageFrom = ((value - this.combinedOptions().min) /
                (this.combinedOptions().max - this.combinedOptions().min)) *
                100;
            fillElement.style.width = `calc(${percentageFrom}%)`;
        }
    }
    initValues() {
        const value = this.value();
        const valueTo = this.valueTo();
        if (value < this.combinedOptions().min) {
            this.value.set(this.combinedOptions().min);
        }
        else if (value > this.combinedOptions().max) {
            this.value.set(this.combinedOptions().max);
        }
        if (!isNil(valueTo)) {
            if (valueTo > this.combinedOptions().max) {
                this.valueTo.set(this.combinedOptions().max);
            }
            else if (valueTo < this.combinedOptions().min) {
                this.valueTo.set(this.combinedOptions().min);
            }
        }
    }
    setThumbPosition(type) {
        const thumbContainer = this.getThumbContainer(type);
        const value = this.getValue(type);
        if (isNil(value)) {
            return;
        }
        if (thumbContainer?.nativeElement && !isNil(value)) {
            const percentage = (value - this.combinedOptions().min) /
                (this.combinedOptions().max - this.combinedOptions().min);
            const left = percentage *
                this.sliderBar?.nativeElement?.getBoundingClientRect().width -
                this.getOffset(type);
            if (type === 'from') {
                this.thumbFromDraggable.updateTransform({
                    x: left,
                    y: 0,
                });
            }
            else if (this.thumbToDraggable) {
                this.thumbToDraggable.updateTransform({
                    x: left,
                    y: 0,
                });
            }
        }
    }
    getThumbContainer(type) {
        if (type === 'from') {
            return this.thumbFromContainer;
        }
        else {
            return this.thumbToContainer;
        }
    }
    getValue(type) {
        if (type === 'from') {
            return this.value();
        }
        else {
            return this.valueTo();
        }
    }
    onDragMove(type, data) {
        const eventData = data;
        const newValue = this.getPercentage(eventData.currentTranslate.x + this.getOffset(type)) *
            (this.combinedOptions().max - this.combinedOptions().min) +
            this.combinedOptions().min;
        if (type === 'from') {
            this.value.set(newValue);
        }
        else {
            this.valueTo.set(newValue);
        }
        if (type === 'from') {
            this._debouncedvalueChange(this.value());
        }
        else {
            this._debouncedValueToChange(this.valueTo());
        }
        this.updateBarFill();
    }
    getOffset(type) {
        if (type === 'from') {
            return (this.thumbFromContainer.nativeElement.getBoundingClientRect().width / 2);
        }
        else {
            return (this.thumbToContainer?.nativeElement?.getBoundingClientRect()?.width /
                2 ?? 0);
        }
    }
    constrainPosition(clientPosition, type) {
        if (!isNil(this.valueTo())) {
            clientPosition = this.constrainPositionRange(clientPosition, type);
        }
        return clientPosition;
    }
    /**
     * Prevents the thumbs from crossing over one another
     * @param position
     * @param type
     * @private
     */
    constrainPositionRange(position, type) {
        const leftThumb = this.thumbFromContainer;
        const rightThumb = this.thumbToContainer;
        const targetPosition = position;
        if (type === 'from') {
            const left = rightThumb.nativeElement.getBoundingClientRect().left -
                this.sliderBar.nativeElement.getBoundingClientRect().left;
            if (targetPosition.x > left) {
                targetPosition.x = left;
            }
        }
        else {
            const left = leftThumb.nativeElement.getBoundingClientRect().left -
                this.sliderBar.nativeElement.getBoundingClientRect().left +
                leftThumb.nativeElement.getBoundingClientRect().width;
            if (targetPosition.x < left) {
                targetPosition.x = left;
            }
        }
        return targetPosition;
    }
    getPercentage(targetLeft) {
        const percentage = targetLeft / this.sliderBar.nativeElement.getBoundingClientRect().width;
        return Math.max(0, Math.min(1, percentage));
    }
    ngAfterViewInit() {
        this.thumbFromDraggable.addDefaultBehavior();
        this.thumbFromDraggable.addContainerConstraint({
            container: this.sliderBar.nativeElement,
            anchor: 'center',
        });
        this.thumbFromDraggable.addAxisConstraint(this.combinedOptions().alignment === 'horizontal' ? 'x' : 'y');
        if (this.thumbToDraggable) {
            this.thumbToDraggable.addDefaultBehavior();
            this.thumbToDraggable.addContainerConstraint({
                container: this.sliderBar.nativeElement,
                anchor: 'center',
            });
            this.thumbToDraggable.addAxisConstraint(this.combinedOptions().alignment === 'horizontal' ? 'x' : 'y');
        }
        setTimeout(() => {
            this.initResizeObserver();
            this.initValues();
            this.setThumbPositions();
            this.updateBarFill();
        });
    }
    initResizeObserver() {
        const debouncedResize = throttle(() => {
            this.setThumbPositions();
        }, 50);
        this.resizeObserver = new ResizeObserver(() => {
            debouncedResize();
        });
        this.resizeObserver.observe(this.sliderBar?.nativeElement);
    }
    ngOnChanges(changes) {
        const changeKeys = Object.keys(changes);
        if (changeKeys.includes('options')) {
            this.initValues();
            this.setThumbPositions();
        }
        if (changeKeys.includes('value') || changeKeys.includes('valueTo')) {
            this.initValues();
            this.setThumbPositions();
        }
        setTimeout(() => {
            this.updateBarFill();
        });
    }
    setThumbPositions() {
        this.setThumbPosition('from');
        if (!isNil(this.valueTo())) {
            this.setThumbPosition('to');
        }
    }
    trackById(index, item) {
        return item['id'];
    }
    ngOnDestroy() {
        this.resizeObserver?.unobserve(this.sliderBar?.nativeElement);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSliderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiSliderComponent, isStandalone: true, selector: "oui-slider", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, valueTo: { classPropertyName: "valueTo", publicName: "valueTo", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { value: "valueChange", valueTo: "valueToChange", debouncedvalueChange: "debouncedvalueChange", debouncedValueToChange: "debouncedValueToChange" }, viewQueries: [{ propertyName: "thumbFrom", first: true, predicate: ["thumbFrom"], descendants: true }, { propertyName: "thumbFromContainer", first: true, predicate: ["thumbFromContainer"], descendants: true }, { propertyName: "thumbFromDraggable", first: true, predicate: ["thumbFromDraggable"], descendants: true }, { propertyName: "thumbTo", first: true, predicate: ["thumbTo"], descendants: true }, { propertyName: "thumbToContainer", first: true, predicate: ["thumbToContainer"], descendants: true }, { propertyName: "thumbToDraggable", first: true, predicate: ["thumbToDraggable"], descendants: true }, { propertyName: "sliderBar", first: true, predicate: ["sliderBar"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"slider-container {{ combinedOptions().alignment }}\">\n  <div class=\"slider-content-container\">\n    <div class=\"slider-bar-container\">\n      <div class=\"slider-bar\" #sliderBar>\n\n        <div class=\"slider-bar-section\">\n          <div class=\"slider-bar-section-fill\"></div>\n        </div>\n        <div\n          #thumbFromContainer\n          #thumbFromDraggable=\"OuiDraggableDirective\"\n          class=\"slider-thumb-container from\"\n          oui-draggable\n          (dragMove)=\"onDragMove('from', $event)\"\n          >\n          <div #thumbFrom class=\"thumb\">\n            @if (combinedOptions().thumbContentTemplate; as template) {\n              <ng-container *ngTemplateOutlet=\"template\"></ng-container>\n            }\n          </div>\n        </div>\n        @if (valueTo() !== undefined) {\n          <div\n            #thumbToContainer\n            #thumbToDraggable=\"OuiDraggableDirective\"\n            class=\"slider-thumb-container to\"\n            oui-draggable\n            (dragMove)=\"onDragMove('to', $event)\"\n            >\n            <div #thumbTo class=\"thumb\">\n              @if (combinedOptions().thumbToContentTemplate; as template) {\n                <ng-container *ngTemplateOutlet=\"template\"></ng-container>\n              }\n            </div>\n          </div>\n        }\n      </div>\n    </div>\n    @if (combinedOptions().minLabel !== undefined || combinedOptions().maxLabel !== undefined) {\n      <div\n        class=\"slider-labels-container\"\n        >\n        @if (combinedOptions().minLabel !== undefined) {\n          <div class=\"min-label\">\n            {{ combinedOptions().minLabel }}\n          </div>\n        }\n        @if (combinedOptions().maxLabel !== undefined) {\n          <div class=\"max-label\">\n            {{ combinedOptions().maxLabel }}\n          </div>\n        }\n      </div>\n    }\n  </div>\n</div>\n", styles: [":host{flex:1;height:100%;display:flex;align-items:center}:host .icon-between-ticks{position:absolute}:host .slider-container{height:100%;width:100%;position:relative}:host .slider-container .slider-content-container{height:100%;width:100%;position:relative;display:flex;flex-direction:column;justify-content:center;align-items:center}:host .slider-container .slider-content-container .slider-bar-container{width:100%;height:var(--oui-slider-bar-container-height);display:flex;align-items:center;position:relative}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container{min-height:14px;min-width:14px;display:flex;justify-content:center;align-items:center;position:absolute;z-index:2;height:var(--oui-slider-thumb-height);width:var(--oui-slider-thumb-width)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.dragging .thumb{box-shadow:var(--oui-slider-thumb-dragging-box-shadow)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.from .thumb{background-color:var(--oui-slider-thumb-color-primary);border:var(--oui-slider-thumb-primary-border)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.from .thumb:hover{background-color:var(--oui-slider-thumb-color-primary-hover)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.to .thumb{background-color:var(--oui-slider-thumb-color-secondary);border:var(--oui-slider-thumb-secondary-border)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.to .thumb:hover{background-color:var(--oui-slider-thumb-color-secondary-hover)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container .thumb{border-radius:var(--oui-slider-thumb-border-radius);height:var(--oui-slider-thumb-height);width:var(--oui-slider-thumb-width);min-width:var(--oui-slider-thumb-width);min-height:var(--oui-slider-thumb-height);transition:background-color .3s,box-shadow .3s;display:flex;justify-content:center;align-items:center;box-shadow:var(--oui-slider-thumb-box-shadow)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container .thumb:hover{cursor:pointer}:host .slider-container .slider-content-container .slider-bar-container .outer-bar{width:100%;position:absolute;height:4px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar{width:100%;height:var(--oui-slider-bar-height);display:flex;align-items:center;position:relative;border:1px solid transparent;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container{position:absolute;width:100%;height:100%;display:flex;align-items:center}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick{pointer-events:none;display:flex;position:absolute;top:calc(var(--oui-slider-tick-height) / 2);transform:translateY(-100%);flex-direction:column;width:var(--oui-slider-tick-width);align-self:flex-start}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick .tick-line-wrapper{grid-area:middle;display:flex;justify-items:center;align-items:center;flex:0 1 auto}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick .tick-line-wrapper .tick-line{width:var(--oui-slider-tick-width);height:var(--oui-slider-tick-height);background-color:var(--oui-slider-tick-background-color);border-radius:var(--oui-slider-tick-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section{flex:1;background:var(--oui-slider-bar-inactive);height:100%;position:relative;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-1{margin-left:1px;margin-right:1px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-2{margin-left:2px;margin-right:2px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-3{margin-left:3px;margin-right:3px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-4{margin-left:4px;margin-right:4px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-5{margin-left:5px;margin-right:5px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-6{margin-left:6px;margin-right:6px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-7{margin-left:7px;margin-right:7px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-8{margin-left:8px;margin-right:8px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section .slider-bar-section-fill{height:100%;width:0;background:var(--oui-slider-bar-active);pointer-events:none;position:absolute;left:0;top:0;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section .slider-bar-section-fill.full{background:var(--oui-slider-bar-active)}:host .slider-container .slider-content-container .slider-labels-container{width:100%;display:flex;justify-content:space-between;align-items:center;position:absolute;bottom:-2rem;color:var(--oui-slider-label-color);font-size:1.5rem}:host .slider-container .slider-content-container .slider-labels-container .min-label{transform:translate(-50%)}:host .slider-container .slider-content-container .slider-labels-container .max-label{transform:translate(50%)}\n"], dependencies: [{ kind: "directive", type: OuiDraggableDirective, selector: "[oui-draggable]", outputs: ["dragMove", "dragStart", "dragEnd"], exportAs: ["OuiDraggableDirective"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSliderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-slider', standalone: true, imports: [OuiDraggableDirective, CommonModule, OuiIconComponent], template: "<div class=\"slider-container {{ combinedOptions().alignment }}\">\n  <div class=\"slider-content-container\">\n    <div class=\"slider-bar-container\">\n      <div class=\"slider-bar\" #sliderBar>\n\n        <div class=\"slider-bar-section\">\n          <div class=\"slider-bar-section-fill\"></div>\n        </div>\n        <div\n          #thumbFromContainer\n          #thumbFromDraggable=\"OuiDraggableDirective\"\n          class=\"slider-thumb-container from\"\n          oui-draggable\n          (dragMove)=\"onDragMove('from', $event)\"\n          >\n          <div #thumbFrom class=\"thumb\">\n            @if (combinedOptions().thumbContentTemplate; as template) {\n              <ng-container *ngTemplateOutlet=\"template\"></ng-container>\n            }\n          </div>\n        </div>\n        @if (valueTo() !== undefined) {\n          <div\n            #thumbToContainer\n            #thumbToDraggable=\"OuiDraggableDirective\"\n            class=\"slider-thumb-container to\"\n            oui-draggable\n            (dragMove)=\"onDragMove('to', $event)\"\n            >\n            <div #thumbTo class=\"thumb\">\n              @if (combinedOptions().thumbToContentTemplate; as template) {\n                <ng-container *ngTemplateOutlet=\"template\"></ng-container>\n              }\n            </div>\n          </div>\n        }\n      </div>\n    </div>\n    @if (combinedOptions().minLabel !== undefined || combinedOptions().maxLabel !== undefined) {\n      <div\n        class=\"slider-labels-container\"\n        >\n        @if (combinedOptions().minLabel !== undefined) {\n          <div class=\"min-label\">\n            {{ combinedOptions().minLabel }}\n          </div>\n        }\n        @if (combinedOptions().maxLabel !== undefined) {\n          <div class=\"max-label\">\n            {{ combinedOptions().maxLabel }}\n          </div>\n        }\n      </div>\n    }\n  </div>\n</div>\n", styles: [":host{flex:1;height:100%;display:flex;align-items:center}:host .icon-between-ticks{position:absolute}:host .slider-container{height:100%;width:100%;position:relative}:host .slider-container .slider-content-container{height:100%;width:100%;position:relative;display:flex;flex-direction:column;justify-content:center;align-items:center}:host .slider-container .slider-content-container .slider-bar-container{width:100%;height:var(--oui-slider-bar-container-height);display:flex;align-items:center;position:relative}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container{min-height:14px;min-width:14px;display:flex;justify-content:center;align-items:center;position:absolute;z-index:2;height:var(--oui-slider-thumb-height);width:var(--oui-slider-thumb-width)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.dragging .thumb{box-shadow:var(--oui-slider-thumb-dragging-box-shadow)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.from .thumb{background-color:var(--oui-slider-thumb-color-primary);border:var(--oui-slider-thumb-primary-border)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.from .thumb:hover{background-color:var(--oui-slider-thumb-color-primary-hover)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.to .thumb{background-color:var(--oui-slider-thumb-color-secondary);border:var(--oui-slider-thumb-secondary-border)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.to .thumb:hover{background-color:var(--oui-slider-thumb-color-secondary-hover)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container .thumb{border-radius:var(--oui-slider-thumb-border-radius);height:var(--oui-slider-thumb-height);width:var(--oui-slider-thumb-width);min-width:var(--oui-slider-thumb-width);min-height:var(--oui-slider-thumb-height);transition:background-color .3s,box-shadow .3s;display:flex;justify-content:center;align-items:center;box-shadow:var(--oui-slider-thumb-box-shadow)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container .thumb:hover{cursor:pointer}:host .slider-container .slider-content-container .slider-bar-container .outer-bar{width:100%;position:absolute;height:4px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar{width:100%;height:var(--oui-slider-bar-height);display:flex;align-items:center;position:relative;border:1px solid transparent;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container{position:absolute;width:100%;height:100%;display:flex;align-items:center}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick{pointer-events:none;display:flex;position:absolute;top:calc(var(--oui-slider-tick-height) / 2);transform:translateY(-100%);flex-direction:column;width:var(--oui-slider-tick-width);align-self:flex-start}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick .tick-line-wrapper{grid-area:middle;display:flex;justify-items:center;align-items:center;flex:0 1 auto}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick .tick-line-wrapper .tick-line{width:var(--oui-slider-tick-width);height:var(--oui-slider-tick-height);background-color:var(--oui-slider-tick-background-color);border-radius:var(--oui-slider-tick-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section{flex:1;background:var(--oui-slider-bar-inactive);height:100%;position:relative;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-1{margin-left:1px;margin-right:1px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-2{margin-left:2px;margin-right:2px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-3{margin-left:3px;margin-right:3px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-4{margin-left:4px;margin-right:4px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-5{margin-left:5px;margin-right:5px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-6{margin-left:6px;margin-right:6px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-7{margin-left:7px;margin-right:7px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-8{margin-left:8px;margin-right:8px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section .slider-bar-section-fill{height:100%;width:0;background:var(--oui-slider-bar-active);pointer-events:none;position:absolute;left:0;top:0;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section .slider-bar-section-fill.full{background:var(--oui-slider-bar-active)}:host .slider-container .slider-content-container .slider-labels-container{width:100%;display:flex;justify-content:space-between;align-items:center;position:absolute;bottom:-2rem;color:var(--oui-slider-label-color);font-size:1.5rem}:host .slider-container .slider-content-container .slider-labels-container .min-label{transform:translate(-50%)}:host .slider-container .slider-content-container .slider-labels-container .max-label{transform:translate(50%)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { thumbFrom: [{
                type: ViewChild,
                args: ['thumbFrom']
            }], thumbFromContainer: [{
                type: ViewChild,
                args: ['thumbFromContainer']
            }], thumbFromDraggable: [{
                type: ViewChild,
                args: ['thumbFromDraggable']
            }], thumbTo: [{
                type: ViewChild,
                args: ['thumbTo']
            }], thumbToContainer: [{
                type: ViewChild,
                args: ['thumbToContainer']
            }], thumbToDraggable: [{
                type: ViewChild,
                args: ['thumbToDraggable']
            }], sliderBar: [{
                type: ViewChild,
                args: ['sliderBar']
            }], debouncedvalueChange: [{
                type: Output
            }], debouncedValueToChange: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2xpZGVyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvc2xpZGVyL3NsaWRlci9zbGlkZXIuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9zbGlkZXIvc2xpZGVyL3NsaWRlci5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBR0wsU0FBUyxFQUNULFFBQVEsRUFFUixZQUFZLEVBQ1osS0FBSyxFQUVMLEtBQUssRUFHTCxNQUFNLEVBR04sU0FBUyxHQUNWLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFDN0QsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ25ELE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLHNCQUFzQixDQUFDOzs7QUFzQzdELE1BQU0sT0FBTyxrQkFBa0I7SUFDTCxTQUFTLENBQWE7SUFDYixrQkFBa0IsQ0FBYTtJQUVoRSxrQkFBa0IsQ0FBd0I7SUFFcEIsT0FBTyxDQUF5QjtJQUN2QixnQkFBZ0IsQ0FBeUI7SUFDekMsZ0JBQWdCLENBRWpDO0lBQ1UsU0FBUyxDQUFhO0lBRTlDOztPQUVHO0lBQ0ksS0FBSyxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQU8sQ0FBQztJQUVyQzs7T0FFRztJQUNJLE9BQU8sR0FBRyxLQUFLLEVBQU8sQ0FBQztJQUU5Qjs7T0FFRztJQUVJLE9BQU8sR0FBRyxLQUFLLENBQUMsUUFBUSxFQUFxQixDQUFDO0lBRTlDLGVBQWUsR0FBRyxRQUFRLENBQUMsR0FBRyxFQUFFO1FBQ3JDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxRQUFRLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUMxRSxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxHQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDMUUsT0FBTyxLQUFLLENBQ1YsRUFBRSxHQUFHLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFDMUIsRUFBRSxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsRUFBRSxHQUFHLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxFQUFFLENBQ2pELENBQUM7SUFDSixDQUFDLENBQUMsQ0FBQztJQUVIOztPQUVHO0lBQ0g7O09BRUc7SUFDTyxvQkFBb0IsR0FBRyxJQUFJLFlBQVksRUFBTyxDQUFDO0lBRXpEOztPQUVHO0lBQ0g7O09BRUc7SUFDTyxzQkFBc0IsR0FBRyxJQUFJLFlBQVksRUFBTyxDQUFDO0lBRW5ELGNBQWMsR0FBOEI7UUFDbEQsR0FBRyxFQUFFLENBQUM7UUFDTixHQUFHLEVBQUUsR0FBRztRQUNSLFFBQVEsRUFBRSxHQUFHO1FBQ2IsUUFBUSxFQUFFLEtBQUs7UUFDZixTQUFTLEVBQUUsWUFBWTtLQUN4QixDQUFDO0lBQ00sY0FBYyxDQUE2QjtJQUMzQyx1QkFBdUIsR0FBRyxRQUFRLENBQUMsQ0FBQyxLQUFVLEVBQUUsRUFBRTtRQUN4RCxJQUFJLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNBLHFCQUFxQixHQUFHLFFBQVEsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFO1FBQ3RELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDeEMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBRVIsZ0JBQWUsQ0FBQztJQUVSLGFBQWE7UUFDbkIsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQy9CLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUMzQixJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7WUFDcEIsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxhQUFhLEVBQUUsYUFBYSxDQUM5RCwwQkFBMEIsQ0FDM0IsQ0FBQztZQUNGLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDakIsT0FBTztZQUNULENBQUM7WUFFRCxNQUFNLGNBQWMsR0FDbEIsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDO2dCQUNuQyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUM1RCxHQUFHLENBQUM7WUFDTixNQUFNLFlBQVksR0FDaEIsQ0FBQyxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDO2dCQUNyQyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUM1RCxHQUFHLENBQUM7WUFDTixXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxRQUFRLFlBQVksT0FBTyxjQUFjLElBQUksQ0FBQztZQUN4RSxXQUFXLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxRQUFRLGNBQWMsR0FBRyxDQUFDO1FBQ3JELENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxhQUFhLEVBQUUsYUFBYSxDQUM5RCwwQkFBMEIsQ0FDM0IsQ0FBQztZQUNGLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDakIsT0FBTztZQUNULENBQUM7WUFDRCxNQUFNLGNBQWMsR0FDbEIsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDO2dCQUNuQyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUM1RCxHQUFHLENBQUM7WUFDTixXQUFXLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxRQUFRLGNBQWMsSUFBSSxDQUFDO1FBQ3ZELENBQUM7SUFDSCxDQUFDO0lBRU8sVUFBVTtRQUNoQixNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDM0IsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQy9CLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUN2QyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDN0MsQ0FBQzthQUFNLElBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUM5QyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDN0MsQ0FBQztRQUNELElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztZQUNwQixJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUM7Z0JBQ3pDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUMvQyxDQUFDO2lCQUFNLElBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDaEQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQy9DLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVPLGdCQUFnQixDQUFDLElBQW1CO1FBQzFDLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNwRCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ2xDLElBQUksS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDakIsT0FBTztRQUNULENBQUM7UUFFRCxJQUFJLGNBQWMsRUFBRSxhQUFhLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNuRCxNQUFNLFVBQVUsR0FDZCxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxDQUFDO2dCQUNwQyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzVELE1BQU0sSUFBSSxHQUNSLFVBQVU7Z0JBQ1IsSUFBSSxDQUFDLFNBQVMsRUFBRSxhQUFhLEVBQUUscUJBQXFCLEVBQUUsQ0FBQyxLQUFLO2dCQUM5RCxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3ZCLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRSxDQUFDO2dCQUNwQixJQUFJLENBQUMsa0JBQWtCLENBQUMsZUFBZSxDQUFDO29CQUN0QyxDQUFDLEVBQUUsSUFBSTtvQkFDUCxDQUFDLEVBQUUsQ0FBQztpQkFDTCxDQUFDLENBQUM7WUFDTCxDQUFDO2lCQUFNLElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7Z0JBQ2pDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUM7b0JBQ3BDLENBQUMsRUFBRSxJQUFJO29CQUNQLENBQUMsRUFBRSxDQUFDO2lCQUNMLENBQUMsQ0FBQztZQUNMLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUNPLGlCQUFpQixDQUFDLElBQW1CO1FBQzNDLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRSxDQUFDO1lBQ3BCLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDO1FBQ2pDLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7UUFDL0IsQ0FBQztJQUNILENBQUM7SUFFTyxRQUFRLENBQUMsSUFBbUI7UUFDbEMsSUFBSSxJQUFJLEtBQUssTUFBTSxFQUFFLENBQUM7WUFDcEIsT0FBTyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDdEIsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUN4QixDQUFDO0lBQ0gsQ0FBQztJQUVNLFVBQVUsQ0FBQyxJQUFtQixFQUFFLElBQWtCO1FBQ3ZELE1BQU0sU0FBUyxHQUFHLElBQXlCLENBQUM7UUFDNUMsTUFBTSxRQUFRLEdBQ1osSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDckUsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsR0FBRyxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxHQUFHLENBQUM7WUFDM0QsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLEdBQUcsQ0FBQztRQUM3QixJQUFJLElBQUksS0FBSyxNQUFNLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMzQixDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzdCLENBQUM7UUFFRCxJQUFJLElBQUksS0FBSyxNQUFNLEVBQUUsQ0FBQztZQUNwQixJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUM7UUFDM0MsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsdUJBQXVCLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDL0MsQ0FBQztRQUNELElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUN2QixDQUFDO0lBRU8sU0FBUyxDQUFDLElBQW1CO1FBQ25DLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRSxDQUFDO1lBQ3BCLE9BQU8sQ0FDTCxJQUFJLENBQUMsa0JBQWtCLENBQUMsYUFBYSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FDeEUsQ0FBQztRQUNKLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxDQUNMLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhLEVBQUUscUJBQXFCLEVBQUUsRUFBRSxLQUFLO2dCQUNsRSxDQUFDLElBQUksQ0FBQyxDQUNULENBQUM7UUFDSixDQUFDO0lBQ0gsQ0FBQztJQUNNLGlCQUFpQixDQUFDLGNBQXNCLEVBQUUsSUFBbUI7UUFDbEUsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDO1lBQzNCLGNBQWMsR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsY0FBYyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3JFLENBQUM7UUFDRCxPQUFPLGNBQWMsQ0FBQztJQUN4QixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSyxzQkFBc0IsQ0FBQyxRQUFnQixFQUFFLElBQW1CO1FBQ2xFLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztRQUMxQyxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsZ0JBQThCLENBQUM7UUFDdkQsTUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDO1FBQ2hDLElBQUksSUFBSSxLQUFLLE1BQU0sRUFBRSxDQUFDO1lBQ3BCLE1BQU0sSUFBSSxHQUNSLFVBQVUsQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxJQUFJO2dCQUNyRCxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLElBQUksQ0FBQztZQUM1RCxJQUFJLGNBQWMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUM7Z0JBQzVCLGNBQWMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDO1lBQzFCLENBQUM7UUFDSCxDQUFDO2FBQU0sQ0FBQztZQUNOLE1BQU0sSUFBSSxHQUNSLFNBQVMsQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxJQUFJO2dCQUNwRCxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLElBQUk7Z0JBQ3pELFNBQVMsQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7WUFDeEQsSUFBSSxjQUFjLENBQUMsQ0FBQyxHQUFHLElBQUksRUFBRSxDQUFDO2dCQUM1QixjQUFjLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQztZQUMxQixDQUFDO1FBQ0gsQ0FBQztRQUNELE9BQU8sY0FBYyxDQUFDO0lBQ3hCLENBQUM7SUFFTyxhQUFhLENBQUMsVUFBa0I7UUFDdEMsTUFBTSxVQUFVLEdBQ2QsVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxDQUFDO1FBQzFFLE9BQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQztJQUM5QyxDQUFDO0lBRUQsZUFBZTtRQUNiLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQzdDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxzQkFBc0IsQ0FBQztZQUM3QyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhO1lBQ3ZDLE1BQU0sRUFBRSxRQUFRO1NBQ2pCLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxpQkFBaUIsQ0FDdkMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLFNBQVMsS0FBSyxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUM5RCxDQUFDO1FBQ0YsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUMxQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztZQUMzQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsc0JBQXNCLENBQUM7Z0JBQzNDLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWE7Z0JBQ3ZDLE1BQU0sRUFBRSxRQUFRO2FBQ2pCLENBQUMsQ0FBQztZQUNILElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxpQkFBaUIsQ0FDckMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLFNBQVMsS0FBSyxZQUFZLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUM5RCxDQUFDO1FBQ0osQ0FBQztRQUNELFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDZCxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztZQUMxQixJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDbEIsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3ZCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVPLGtCQUFrQjtRQUN4QixNQUFNLGVBQWUsR0FBRyxRQUFRLENBQUMsR0FBRyxFQUFFO1lBQ3BDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQzNCLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNQLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxjQUFjLENBQUMsR0FBRyxFQUFFO1lBQzVDLGVBQWUsRUFBRSxDQUFDO1FBQ3BCLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBRU0sV0FBVyxDQUFDLE9BQXNCO1FBQ3ZDLE1BQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDeEMsSUFBSSxVQUFVLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7WUFDbkMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2xCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQzNCLENBQUM7UUFDRCxJQUFJLFVBQVUsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksVUFBVSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO1lBQ25FLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNsQixJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUMzQixDQUFDO1FBQ0QsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN2QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTyxpQkFBaUI7UUFDdkIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzlCLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQztZQUMzQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDOUIsQ0FBQztJQUNILENBQUM7SUFFTSxTQUFTLENBQUMsS0FBYSxFQUFFLElBQVM7UUFDdkMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDcEIsQ0FBQztJQUVNLFdBQVc7UUFDaEIsSUFBSSxDQUFDLGNBQWMsRUFBRSxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxhQUFhLENBQUMsQ0FBQztJQUNoRSxDQUFDO3VHQXJUVSxrQkFBa0I7MkZBQWxCLGtCQUFrQixnekNDMUQvQix1NERBd0RBLDg2TERBWSxxQkFBcUIsK0lBQUUsWUFBWTs7MkZBRWxDLGtCQUFrQjtrQkFQOUIsU0FBUzsrQkFDRSxZQUFZLGNBR1YsSUFBSSxXQUNQLENBQUMscUJBQXFCLEVBQUUsWUFBWSxFQUFFLGdCQUFnQixDQUFDO3dEQUd4QyxTQUFTO3NCQUFoQyxTQUFTO3VCQUFDLFdBQVc7Z0JBQ1csa0JBQWtCO3NCQUFsRCxTQUFTO3VCQUFDLG9CQUFvQjtnQkFFL0Isa0JBQWtCO3NCQURqQixTQUFTO3VCQUFDLG9CQUFvQjtnQkFHVCxPQUFPO3NCQUE1QixTQUFTO3VCQUFDLFNBQVM7Z0JBQ1csZ0JBQWdCO3NCQUE5QyxTQUFTO3VCQUFDLGtCQUFrQjtnQkFDRSxnQkFBZ0I7c0JBQTlDLFNBQVM7dUJBQUMsa0JBQWtCO2dCQUdMLFNBQVM7c0JBQWhDLFNBQVM7dUJBQUMsV0FBVztnQkFpQ1osb0JBQW9CO3NCQUE3QixNQUFNO2dCQVFHLHNCQUFzQjtzQkFBL0IsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFmdGVyVmlld0luaXQsXG4gIENoYW5nZURldGVjdG9yUmVmLFxuICBDb21wb25lbnQsXG4gIGNvbXB1dGVkLFxuICBFbGVtZW50UmVmLFxuICBFdmVudEVtaXR0ZXIsXG4gIGlucHV0LFxuICBJbnB1dCxcbiAgbW9kZWwsXG4gIE9uQ2hhbmdlcyxcbiAgT25EZXN0cm95LFxuICBPdXRwdXQsXG4gIFNpbXBsZUNoYW5nZXMsXG4gIFRlbXBsYXRlUmVmLFxuICBWaWV3Q2hpbGQsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgZGVib3VuY2UsIGlzTmlsLCBtZXJnZSwgdGhyb3R0bGUgfSBmcm9tICdsb2Rhc2gtZXMnO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IE91aUljb25Db21wb25lbnQgfSBmcm9tICdvcmJpdGFsLXVpL2ljb24nO1xuaW1wb3J0IHsgT3VpRHJhZ2dhYmxlRGlyZWN0aXZlIH0gZnJvbSAnb3JiaXRhbC11aS9kcmFnZ2FibGUnO1xuaW1wb3J0IHsgSVBvaW50IH0gZnJvbSAnb3JiaXRhbC11aS9jb3JlJztcbmltcG9ydCB7IElPdWlEcmFnTW92ZSwgSU91aURyYWdNb3ZlRXZlbnQgfSBmcm9tICdvcmJpdGFsLXVpL2RyYWdnYWJsZSc7XG5cbi8qKlxuICogVGhlIG9wdGlvbnMgZm9yIHRoZSBzbGlkZXIuXG4gKlxuICogbWluOiB0aGUgbWluaW11bSB2YWx1ZSBvZiB0aGUgc2xpZGVyXG4gKiBtYXg6IHRoZSBtYXggdmFsdWUgb2YgdGhlIHNsaWRlclxuICogc2VjdGlvbnM6IERlZmluZSB0aGUgc2VjdGlvbnMgaW50byB3aGljaCB0aGUgc2xpZGVyLWJhciBpcyBzcGxpdC5cbiAqIG1pbkxhYmVsOiBEZWZpbmUgdGhlIGxhYmVsIHRoYXQgc2hvdWxkIGFwcGVhciBhdCB0aGUgbG93ZXN0IHZhbHVlIG9mIHRoZSBzbGlkZXIgKE1pZ2h0IG5vdCB3b3JrIGN1cnJlbnRseSlcbiAqIG1heExhYmVsOiBEZWZpbmUgdGhlIGxhYmVsIHRoYXQgc2hvdWxkIGFwcGVhciBhdCB0aGUgaGlnaGVzdCB2YWx1ZSBvZiB0aGUgc2xpZGVyIChNaWdodCBub3Qgd29yayBjdXJyZW50bHkpXG4gKiBhbGlnbm1lbnQ6IFdoZXRoZXIgc2xpZGVyIHNob3VsZCBiZSBob3Jpem9udGFsIG9yIHZlcnRpY2FsLiBDVVJSRU5UTFkgT05MWSBXT1JLUyBJTiBIT1JJWk9OVEFMIE1PREVcbiAqIGJhck1hcmdpbjogQWRkcyBhIG1hcmdpbiB0byB0aGUgYmFyXG4gKiBpY29uT3B0aW9uczogUG9zc2liaWxpdHkgdG8gYWRkIGljb25zIHRoYXQgYXJlIGluamVjdGVkIGluc2lkZSB0aGUgdGh1bWJzLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIElPdWlTbGlkZXJPcHRpb25zIGV4dGVuZHMgUGFydGlhbDxJT3VpU2xpZGVyQ29tYmluZWRPcHRpb25zPiB7XG4gIG1pbjogbnVtYmVyO1xuICBtYXg6IG51bWJlcjtcbn1cblxuaW50ZXJmYWNlIElPdWlTbGlkZXJDb21iaW5lZE9wdGlvbnMge1xuICBtaW46IG51bWJlcjtcbiAgbWF4OiBudW1iZXI7XG4gIG1pbkxhYmVsOiBzdHJpbmc7XG4gIG1heExhYmVsOiBzdHJpbmc7XG4gIGFsaWdubWVudDogJ2hvcml6b250YWwnIHwgJ3ZlcnRpY2FsJztcbiAgdGh1bWJDb250ZW50VGVtcGxhdGU/OiBUZW1wbGF0ZVJlZjxhbnk+O1xuICB0aHVtYlRvQ29udGVudFRlbXBsYXRlPzogVGVtcGxhdGVSZWY8YW55Pjtcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLXNsaWRlcicsXG4gIHRlbXBsYXRlVXJsOiAnLi9zbGlkZXIuY29tcG9uZW50Lmh0bWwnLFxuICBzdHlsZVVybHM6IFsnLi9zbGlkZXIuY29tcG9uZW50LnNjc3MnXSxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW091aURyYWdnYWJsZURpcmVjdGl2ZSwgQ29tbW9uTW9kdWxlLCBPdWlJY29uQ29tcG9uZW50XSxcbn0pXG5leHBvcnQgY2xhc3MgT3VpU2xpZGVyQ29tcG9uZW50IGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95LCBPbkNoYW5nZXMge1xuICBAVmlld0NoaWxkKCd0aHVtYkZyb20nKSB0aHVtYkZyb206IEVsZW1lbnRSZWY7XG4gIEBWaWV3Q2hpbGQoJ3RodW1iRnJvbUNvbnRhaW5lcicpIHRodW1iRnJvbUNvbnRhaW5lcjogRWxlbWVudFJlZjtcbiAgQFZpZXdDaGlsZCgndGh1bWJGcm9tRHJhZ2dhYmxlJylcbiAgdGh1bWJGcm9tRHJhZ2dhYmxlOiBPdWlEcmFnZ2FibGVEaXJlY3RpdmU7XG5cbiAgQFZpZXdDaGlsZCgndGh1bWJUbycpIHRodW1iVG86IEVsZW1lbnRSZWYgfCB1bmRlZmluZWQ7XG4gIEBWaWV3Q2hpbGQoJ3RodW1iVG9Db250YWluZXInKSB0aHVtYlRvQ29udGFpbmVyOiBFbGVtZW50UmVmIHwgdW5kZWZpbmVkO1xuICBAVmlld0NoaWxkKCd0aHVtYlRvRHJhZ2dhYmxlJykgdGh1bWJUb0RyYWdnYWJsZTpcbiAgICB8IE91aURyYWdnYWJsZURpcmVjdGl2ZVxuICAgIHwgdW5kZWZpbmVkO1xuICBAVmlld0NoaWxkKCdzbGlkZXJCYXInKSBzbGlkZXJCYXI6IEVsZW1lbnRSZWY7XG5cbiAgLyoqXG4gICAqIFRoZSBtb2RlbCBmb3IgJ3NtYWxsZXInIHZhbHVlLiBVc2UgdGhpcyBhbG9uZSBpZiB5b3Ugd2FudCBqdXN0IGEgc2luZ2xlLXRodW1iIG1vZGUuXG4gICAqL1xuICBwdWJsaWMgdmFsdWUgPSBtb2RlbC5yZXF1aXJlZDxhbnk+KCk7XG5cbiAgLyoqXG4gICAqIFRoZSBtb2RlbCBmb3IgdGhlICdsYXJnZXInIHZhbHVlLiBDYW4gYmUgb25seSB1c2VkIHRvZ2V0aGVyIHdpdGggdmFsdWUtaW5wdXRcbiAgICovXG4gIHB1YmxpYyB2YWx1ZVRvID0gbW9kZWw8YW55PigpO1xuXG4gIC8qKlxuICAgKiBUaGUgb3B0aW9ucyBvZiB0aGUgc2xpZGVyLlxuICAgKi9cblxuICBwdWJsaWMgb3B0aW9ucyA9IGlucHV0LnJlcXVpcmVkPElPdWlTbGlkZXJPcHRpb25zPigpO1xuXG4gIHB1YmxpYyBjb21iaW5lZE9wdGlvbnMgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgY29uc3QgbWluTGFiZWwgPSB0aGlzLm9wdGlvbnMoKS5taW5MYWJlbCA/PyB0aGlzLm9wdGlvbnMoKS5taW4udG9TdHJpbmcoKTtcbiAgICBjb25zdCBtYXhMYWJlbCA9IHRoaXMub3B0aW9ucygpLm1heExhYmVsID8/IHRoaXMub3B0aW9ucygpLm1heC50b1N0cmluZygpO1xuICAgIHJldHVybiBtZXJnZShcbiAgICAgIHsgLi4udGhpcy5kZWZhdWx0T3B0aW9ucyB9LFxuICAgICAgeyAuLi50aGlzLm9wdGlvbnMoKSwgLi4ueyBtaW5MYWJlbCwgbWF4TGFiZWwgfSB9XG4gICAgKTtcbiAgfSk7XG5cbiAgLyoqXG4gICAqIFRoZSBldmVudCB0aGF0J3MgdHJpZ2dlcmVkIHdoZW5ldmVyIHZhbHVlIGNoYW5nZXMgKGV2ZW4gYnkgYSBsaXR0bGUgYml0KVxuICAgKi9cbiAgLyoqXG4gICAqIFRoZSBldmVudCB0aGF0J3MgdHJpZ2dlcmVkIHdoZW5ldmVyIHRoZSB2YWx1ZSBjaGFuZ2VkLCBidXQgdGhpcyBldmVudCBpcyBkZWJvdW5jZWQgYnkgMzAwbXMuXG4gICAqL1xuICBAT3V0cHV0KCkgZGVib3VuY2VkdmFsdWVDaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyPGFueT4oKTtcblxuICAvKipcbiAgICogVGhlIGV2ZW50IHRoYXQncyB0cmlnZ2VyZWQgd2hlbmV2ZXIgdmFsdWVUbyBjaGFuZ2VzIChldmVuIGJ5IGEgbGl0dGxlIGJpdClcbiAgICovXG4gIC8qKlxuICAgKiBUaGUgZXZlbnQgdGhhdCdzIHRyaWdnZXJlZCB3aGVuZXZlciB0aGUgdmFsdWVUbyBjaGFuZ2VkLCBidXQgdGhpcyBldmVudCBpcyBkZWJvdW5jZWQgYnkgMzAwbXMuXG4gICAqL1xuICBAT3V0cHV0KCkgZGVib3VuY2VkVmFsdWVUb0NoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8YW55PigpO1xuXG4gIHByaXZhdGUgZGVmYXVsdE9wdGlvbnM6IElPdWlTbGlkZXJDb21iaW5lZE9wdGlvbnMgPSB7XG4gICAgbWluOiAwLFxuICAgIG1heDogMTAwLFxuICAgIG1pbkxhYmVsOiAnMCcsXG4gICAgbWF4TGFiZWw6ICcxMDAnLFxuICAgIGFsaWdubWVudDogJ2hvcml6b250YWwnLFxuICB9O1xuICBwcml2YXRlIHJlc2l6ZU9ic2VydmVyOiBSZXNpemVPYnNlcnZlciB8IHVuZGVmaW5lZDtcbiAgcHJpdmF0ZSBfZGVib3VuY2VkVmFsdWVUb0NoYW5nZSA9IGRlYm91bmNlKCh2YWx1ZTogYW55KSA9PiB7XG4gICAgdGhpcy5kZWJvdW5jZWRWYWx1ZVRvQ2hhbmdlLmVtaXQodmFsdWUpO1xuICB9LCAzMDApO1xuICBwcml2YXRlIF9kZWJvdW5jZWR2YWx1ZUNoYW5nZSA9IGRlYm91bmNlKCh2YWx1ZTogYW55KSA9PiB7XG4gICAgdGhpcy5kZWJvdW5jZWR2YWx1ZUNoYW5nZS5lbWl0KHZhbHVlKTtcbiAgfSwgMzAwKTtcblxuICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgcHJpdmF0ZSB1cGRhdGVCYXJGaWxsKCkge1xuICAgIGNvbnN0IHZhbHVlVG8gPSB0aGlzLnZhbHVlVG8oKTtcbiAgICBjb25zdCB2YWx1ZSA9IHRoaXMudmFsdWUoKTtcbiAgICBpZiAoIWlzTmlsKHZhbHVlVG8pKSB7XG4gICAgICBjb25zdCBmaWxsRWxlbWVudCA9IHRoaXMuc2xpZGVyQmFyPy5uYXRpdmVFbGVtZW50Py5xdWVyeVNlbGVjdG9yKFxuICAgICAgICBgLnNsaWRlci1iYXItc2VjdGlvbi1maWxsYFxuICAgICAgKTtcbiAgICAgIGlmICghZmlsbEVsZW1lbnQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBwZXJjZW50YWdlRnJvbSA9XG4gICAgICAgICgodmFsdWUgLSB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLm1pbikgL1xuICAgICAgICAgICh0aGlzLmNvbWJpbmVkT3B0aW9ucygpLm1heCAtIHRoaXMuY29tYmluZWRPcHRpb25zKCkubWluKSkgKlxuICAgICAgICAxMDA7XG4gICAgICBjb25zdCBwZXJjZW50YWdlVG8gPVxuICAgICAgICAoKHZhbHVlVG8gLSB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLm1pbikgL1xuICAgICAgICAgICh0aGlzLmNvbWJpbmVkT3B0aW9ucygpLm1heCAtIHRoaXMuY29tYmluZWRPcHRpb25zKCkubWluKSkgKlxuICAgICAgICAxMDA7XG4gICAgICBmaWxsRWxlbWVudC5zdHlsZS53aWR0aCA9IGBjYWxjKCR7cGVyY2VudGFnZVRvfSUgLSAke3BlcmNlbnRhZ2VGcm9tfSUpYDtcbiAgICAgIGZpbGxFbGVtZW50LnN0eWxlLmxlZnQgPSBgY2FsYygke3BlcmNlbnRhZ2VGcm9tfSVgO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBmaWxsRWxlbWVudCA9IHRoaXMuc2xpZGVyQmFyPy5uYXRpdmVFbGVtZW50Py5xdWVyeVNlbGVjdG9yKFxuICAgICAgICBgLnNsaWRlci1iYXItc2VjdGlvbi1maWxsYFxuICAgICAgKTtcbiAgICAgIGlmICghZmlsbEVsZW1lbnQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgcGVyY2VudGFnZUZyb20gPVxuICAgICAgICAoKHZhbHVlIC0gdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5taW4pIC9cbiAgICAgICAgICAodGhpcy5jb21iaW5lZE9wdGlvbnMoKS5tYXggLSB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLm1pbikpICpcbiAgICAgICAgMTAwO1xuICAgICAgZmlsbEVsZW1lbnQuc3R5bGUud2lkdGggPSBgY2FsYygke3BlcmNlbnRhZ2VGcm9tfSUpYDtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGluaXRWYWx1ZXMoKSB7XG4gICAgY29uc3QgdmFsdWUgPSB0aGlzLnZhbHVlKCk7XG4gICAgY29uc3QgdmFsdWVUbyA9IHRoaXMudmFsdWVUbygpO1xuICAgIGlmICh2YWx1ZSA8IHRoaXMuY29tYmluZWRPcHRpb25zKCkubWluKSB7XG4gICAgICB0aGlzLnZhbHVlLnNldCh0aGlzLmNvbWJpbmVkT3B0aW9ucygpLm1pbik7XG4gICAgfSBlbHNlIGlmICh2YWx1ZSA+IHRoaXMuY29tYmluZWRPcHRpb25zKCkubWF4KSB7XG4gICAgICB0aGlzLnZhbHVlLnNldCh0aGlzLmNvbWJpbmVkT3B0aW9ucygpLm1heCk7XG4gICAgfVxuICAgIGlmICghaXNOaWwodmFsdWVUbykpIHtcbiAgICAgIGlmICh2YWx1ZVRvID4gdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5tYXgpIHtcbiAgICAgICAgdGhpcy52YWx1ZVRvLnNldCh0aGlzLmNvbWJpbmVkT3B0aW9ucygpLm1heCk7XG4gICAgICB9IGVsc2UgaWYgKHZhbHVlVG8gPCB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLm1pbikge1xuICAgICAgICB0aGlzLnZhbHVlVG8uc2V0KHRoaXMuY29tYmluZWRPcHRpb25zKCkubWluKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHNldFRodW1iUG9zaXRpb24odHlwZTogJ2Zyb20nIHwgJ3RvJykge1xuICAgIGNvbnN0IHRodW1iQ29udGFpbmVyID0gdGhpcy5nZXRUaHVtYkNvbnRhaW5lcih0eXBlKTtcbiAgICBjb25zdCB2YWx1ZSA9IHRoaXMuZ2V0VmFsdWUodHlwZSk7XG4gICAgaWYgKGlzTmlsKHZhbHVlKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmICh0aHVtYkNvbnRhaW5lcj8ubmF0aXZlRWxlbWVudCAmJiAhaXNOaWwodmFsdWUpKSB7XG4gICAgICBjb25zdCBwZXJjZW50YWdlID1cbiAgICAgICAgKHZhbHVlIC0gdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5taW4pIC9cbiAgICAgICAgKHRoaXMuY29tYmluZWRPcHRpb25zKCkubWF4IC0gdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5taW4pO1xuICAgICAgY29uc3QgbGVmdCA9XG4gICAgICAgIHBlcmNlbnRhZ2UgKlxuICAgICAgICAgIHRoaXMuc2xpZGVyQmFyPy5uYXRpdmVFbGVtZW50Py5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCAtXG4gICAgICAgIHRoaXMuZ2V0T2Zmc2V0KHR5cGUpO1xuICAgICAgaWYgKHR5cGUgPT09ICdmcm9tJykge1xuICAgICAgICB0aGlzLnRodW1iRnJvbURyYWdnYWJsZS51cGRhdGVUcmFuc2Zvcm0oe1xuICAgICAgICAgIHg6IGxlZnQsXG4gICAgICAgICAgeTogMCxcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2UgaWYgKHRoaXMudGh1bWJUb0RyYWdnYWJsZSkge1xuICAgICAgICB0aGlzLnRodW1iVG9EcmFnZ2FibGUudXBkYXRlVHJhbnNmb3JtKHtcbiAgICAgICAgICB4OiBsZWZ0LFxuICAgICAgICAgIHk6IDAsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBwcml2YXRlIGdldFRodW1iQ29udGFpbmVyKHR5cGU6ICdmcm9tJyB8ICd0bycpIHtcbiAgICBpZiAodHlwZSA9PT0gJ2Zyb20nKSB7XG4gICAgICByZXR1cm4gdGhpcy50aHVtYkZyb21Db250YWluZXI7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiB0aGlzLnRodW1iVG9Db250YWluZXI7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBnZXRWYWx1ZSh0eXBlOiAnZnJvbScgfCAndG8nKSB7XG4gICAgaWYgKHR5cGUgPT09ICdmcm9tJykge1xuICAgICAgcmV0dXJuIHRoaXMudmFsdWUoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHRoaXMudmFsdWVUbygpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBvbkRyYWdNb3ZlKHR5cGU6ICdmcm9tJyB8ICd0bycsIGRhdGE6IElPdWlEcmFnTW92ZSkge1xuICAgIGNvbnN0IGV2ZW50RGF0YSA9IGRhdGEgYXMgSU91aURyYWdNb3ZlRXZlbnQ7XG4gICAgY29uc3QgbmV3VmFsdWUgPVxuICAgICAgdGhpcy5nZXRQZXJjZW50YWdlKGV2ZW50RGF0YS5jdXJyZW50VHJhbnNsYXRlLnggKyB0aGlzLmdldE9mZnNldCh0eXBlKSkgKlxuICAgICAgICAodGhpcy5jb21iaW5lZE9wdGlvbnMoKS5tYXggLSB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLm1pbikgK1xuICAgICAgdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5taW47XG4gICAgaWYgKHR5cGUgPT09ICdmcm9tJykge1xuICAgICAgdGhpcy52YWx1ZS5zZXQobmV3VmFsdWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnZhbHVlVG8uc2V0KG5ld1ZhbHVlKTtcbiAgICB9XG5cbiAgICBpZiAodHlwZSA9PT0gJ2Zyb20nKSB7XG4gICAgICB0aGlzLl9kZWJvdW5jZWR2YWx1ZUNoYW5nZSh0aGlzLnZhbHVlKCkpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9kZWJvdW5jZWRWYWx1ZVRvQ2hhbmdlKHRoaXMudmFsdWVUbygpKTtcbiAgICB9XG4gICAgdGhpcy51cGRhdGVCYXJGaWxsKCk7XG4gIH1cblxuICBwcml2YXRlIGdldE9mZnNldCh0eXBlOiAnZnJvbScgfCAndG8nKSB7XG4gICAgaWYgKHR5cGUgPT09ICdmcm9tJykge1xuICAgICAgcmV0dXJuIChcbiAgICAgICAgdGhpcy50aHVtYkZyb21Db250YWluZXIubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCAvIDJcbiAgICAgICk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIHRoaXMudGh1bWJUb0NvbnRhaW5lcj8ubmF0aXZlRWxlbWVudD8uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk/LndpZHRoIC9cbiAgICAgICAgICAyID8/IDBcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIHB1YmxpYyBjb25zdHJhaW5Qb3NpdGlvbihjbGllbnRQb3NpdGlvbjogSVBvaW50LCB0eXBlOiAnZnJvbScgfCAndG8nKSB7XG4gICAgaWYgKCFpc05pbCh0aGlzLnZhbHVlVG8oKSkpIHtcbiAgICAgIGNsaWVudFBvc2l0aW9uID0gdGhpcy5jb25zdHJhaW5Qb3NpdGlvblJhbmdlKGNsaWVudFBvc2l0aW9uLCB0eXBlKTtcbiAgICB9XG4gICAgcmV0dXJuIGNsaWVudFBvc2l0aW9uO1xuICB9XG5cbiAgLyoqXG4gICAqIFByZXZlbnRzIHRoZSB0aHVtYnMgZnJvbSBjcm9zc2luZyBvdmVyIG9uZSBhbm90aGVyXG4gICAqIEBwYXJhbSBwb3NpdGlvblxuICAgKiBAcGFyYW0gdHlwZVxuICAgKiBAcHJpdmF0ZVxuICAgKi9cbiAgcHJpdmF0ZSBjb25zdHJhaW5Qb3NpdGlvblJhbmdlKHBvc2l0aW9uOiBJUG9pbnQsIHR5cGU6ICdmcm9tJyB8ICd0bycpIHtcbiAgICBjb25zdCBsZWZ0VGh1bWIgPSB0aGlzLnRodW1iRnJvbUNvbnRhaW5lcjtcbiAgICBjb25zdCByaWdodFRodW1iID0gdGhpcy50aHVtYlRvQ29udGFpbmVyIGFzIEVsZW1lbnRSZWY7XG4gICAgY29uc3QgdGFyZ2V0UG9zaXRpb24gPSBwb3NpdGlvbjtcbiAgICBpZiAodHlwZSA9PT0gJ2Zyb20nKSB7XG4gICAgICBjb25zdCBsZWZ0ID1cbiAgICAgICAgcmlnaHRUaHVtYi5uYXRpdmVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmxlZnQgLVxuICAgICAgICB0aGlzLnNsaWRlckJhci5uYXRpdmVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmxlZnQ7XG4gICAgICBpZiAodGFyZ2V0UG9zaXRpb24ueCA+IGxlZnQpIHtcbiAgICAgICAgdGFyZ2V0UG9zaXRpb24ueCA9IGxlZnQ7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGxlZnQgPVxuICAgICAgICBsZWZ0VGh1bWIubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5sZWZ0IC1cbiAgICAgICAgdGhpcy5zbGlkZXJCYXIubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5sZWZ0ICtcbiAgICAgICAgbGVmdFRodW1iLm5hdGl2ZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGg7XG4gICAgICBpZiAodGFyZ2V0UG9zaXRpb24ueCA8IGxlZnQpIHtcbiAgICAgICAgdGFyZ2V0UG9zaXRpb24ueCA9IGxlZnQ7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiB0YXJnZXRQb3NpdGlvbjtcbiAgfVxuXG4gIHByaXZhdGUgZ2V0UGVyY2VudGFnZSh0YXJnZXRMZWZ0OiBudW1iZXIpIHtcbiAgICBjb25zdCBwZXJjZW50YWdlID1cbiAgICAgIHRhcmdldExlZnQgLyB0aGlzLnNsaWRlckJhci5uYXRpdmVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoO1xuICAgIHJldHVybiBNYXRoLm1heCgwLCBNYXRoLm1pbigxLCBwZXJjZW50YWdlKSk7XG4gIH1cblxuICBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgdGhpcy50aHVtYkZyb21EcmFnZ2FibGUuYWRkRGVmYXVsdEJlaGF2aW9yKCk7XG4gICAgdGhpcy50aHVtYkZyb21EcmFnZ2FibGUuYWRkQ29udGFpbmVyQ29uc3RyYWludCh7XG4gICAgICBjb250YWluZXI6IHRoaXMuc2xpZGVyQmFyLm5hdGl2ZUVsZW1lbnQsXG4gICAgICBhbmNob3I6ICdjZW50ZXInLFxuICAgIH0pO1xuXG4gICAgdGhpcy50aHVtYkZyb21EcmFnZ2FibGUuYWRkQXhpc0NvbnN0cmFpbnQoXG4gICAgICB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmFsaWdubWVudCA9PT0gJ2hvcml6b250YWwnID8gJ3gnIDogJ3knXG4gICAgKTtcbiAgICBpZiAodGhpcy50aHVtYlRvRHJhZ2dhYmxlKSB7XG4gICAgICB0aGlzLnRodW1iVG9EcmFnZ2FibGUuYWRkRGVmYXVsdEJlaGF2aW9yKCk7XG4gICAgICB0aGlzLnRodW1iVG9EcmFnZ2FibGUuYWRkQ29udGFpbmVyQ29uc3RyYWludCh7XG4gICAgICAgIGNvbnRhaW5lcjogdGhpcy5zbGlkZXJCYXIubmF0aXZlRWxlbWVudCxcbiAgICAgICAgYW5jaG9yOiAnY2VudGVyJyxcbiAgICAgIH0pO1xuICAgICAgdGhpcy50aHVtYlRvRHJhZ2dhYmxlLmFkZEF4aXNDb25zdHJhaW50KFxuICAgICAgICB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmFsaWdubWVudCA9PT0gJ2hvcml6b250YWwnID8gJ3gnIDogJ3knXG4gICAgICApO1xuICAgIH1cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRoaXMuaW5pdFJlc2l6ZU9ic2VydmVyKCk7XG4gICAgICB0aGlzLmluaXRWYWx1ZXMoKTtcbiAgICAgIHRoaXMuc2V0VGh1bWJQb3NpdGlvbnMoKTtcbiAgICAgIHRoaXMudXBkYXRlQmFyRmlsbCgpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBpbml0UmVzaXplT2JzZXJ2ZXIoKSB7XG4gICAgY29uc3QgZGVib3VuY2VkUmVzaXplID0gdGhyb3R0bGUoKCkgPT4ge1xuICAgICAgdGhpcy5zZXRUaHVtYlBvc2l0aW9ucygpO1xuICAgIH0sIDUwKTtcbiAgICB0aGlzLnJlc2l6ZU9ic2VydmVyID0gbmV3IFJlc2l6ZU9ic2VydmVyKCgpID0+IHtcbiAgICAgIGRlYm91bmNlZFJlc2l6ZSgpO1xuICAgIH0pO1xuXG4gICAgdGhpcy5yZXNpemVPYnNlcnZlci5vYnNlcnZlKHRoaXMuc2xpZGVyQmFyPy5uYXRpdmVFbGVtZW50KTtcbiAgfVxuXG4gIHB1YmxpYyBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XG4gICAgY29uc3QgY2hhbmdlS2V5cyA9IE9iamVjdC5rZXlzKGNoYW5nZXMpO1xuICAgIGlmIChjaGFuZ2VLZXlzLmluY2x1ZGVzKCdvcHRpb25zJykpIHtcbiAgICAgIHRoaXMuaW5pdFZhbHVlcygpO1xuICAgICAgdGhpcy5zZXRUaHVtYlBvc2l0aW9ucygpO1xuICAgIH1cbiAgICBpZiAoY2hhbmdlS2V5cy5pbmNsdWRlcygndmFsdWUnKSB8fCBjaGFuZ2VLZXlzLmluY2x1ZGVzKCd2YWx1ZVRvJykpIHtcbiAgICAgIHRoaXMuaW5pdFZhbHVlcygpO1xuICAgICAgdGhpcy5zZXRUaHVtYlBvc2l0aW9ucygpO1xuICAgIH1cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRoaXMudXBkYXRlQmFyRmlsbCgpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBzZXRUaHVtYlBvc2l0aW9ucygpIHtcbiAgICB0aGlzLnNldFRodW1iUG9zaXRpb24oJ2Zyb20nKTtcbiAgICBpZiAoIWlzTmlsKHRoaXMudmFsdWVUbygpKSkge1xuICAgICAgdGhpcy5zZXRUaHVtYlBvc2l0aW9uKCd0bycpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyB0cmFja0J5SWQoaW5kZXg6IG51bWJlciwgaXRlbTogYW55KSB7XG4gICAgcmV0dXJuIGl0ZW1bJ2lkJ107XG4gIH1cblxuICBwdWJsaWMgbmdPbkRlc3Ryb3koKSB7XG4gICAgdGhpcy5yZXNpemVPYnNlcnZlcj8udW5vYnNlcnZlKHRoaXMuc2xpZGVyQmFyPy5uYXRpdmVFbGVtZW50KTtcbiAgfVxufVxuIiwiPGRpdiBjbGFzcz1cInNsaWRlci1jb250YWluZXIge3sgY29tYmluZWRPcHRpb25zKCkuYWxpZ25tZW50IH19XCI+XG4gIDxkaXYgY2xhc3M9XCJzbGlkZXItY29udGVudC1jb250YWluZXJcIj5cbiAgICA8ZGl2IGNsYXNzPVwic2xpZGVyLWJhci1jb250YWluZXJcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJzbGlkZXItYmFyXCIgI3NsaWRlckJhcj5cblxuICAgICAgICA8ZGl2IGNsYXNzPVwic2xpZGVyLWJhci1zZWN0aW9uXCI+XG4gICAgICAgICAgPGRpdiBjbGFzcz1cInNsaWRlci1iYXItc2VjdGlvbi1maWxsXCI+PC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgI3RodW1iRnJvbUNvbnRhaW5lclxuICAgICAgICAgICN0aHVtYkZyb21EcmFnZ2FibGU9XCJPdWlEcmFnZ2FibGVEaXJlY3RpdmVcIlxuICAgICAgICAgIGNsYXNzPVwic2xpZGVyLXRodW1iLWNvbnRhaW5lciBmcm9tXCJcbiAgICAgICAgICBvdWktZHJhZ2dhYmxlXG4gICAgICAgICAgKGRyYWdNb3ZlKT1cIm9uRHJhZ01vdmUoJ2Zyb20nLCAkZXZlbnQpXCJcbiAgICAgICAgICA+XG4gICAgICAgICAgPGRpdiAjdGh1bWJGcm9tIGNsYXNzPVwidGh1bWJcIj5cbiAgICAgICAgICAgIEBpZiAoY29tYmluZWRPcHRpb25zKCkudGh1bWJDb250ZW50VGVtcGxhdGU7IGFzIHRlbXBsYXRlKSB7XG4gICAgICAgICAgICAgIDxuZy1jb250YWluZXIgKm5nVGVtcGxhdGVPdXRsZXQ9XCJ0ZW1wbGF0ZVwiPjwvbmctY29udGFpbmVyPlxuICAgICAgICAgICAgfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgQGlmICh2YWx1ZVRvKCkgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICN0aHVtYlRvQ29udGFpbmVyXG4gICAgICAgICAgICAjdGh1bWJUb0RyYWdnYWJsZT1cIk91aURyYWdnYWJsZURpcmVjdGl2ZVwiXG4gICAgICAgICAgICBjbGFzcz1cInNsaWRlci10aHVtYi1jb250YWluZXIgdG9cIlxuICAgICAgICAgICAgb3VpLWRyYWdnYWJsZVxuICAgICAgICAgICAgKGRyYWdNb3ZlKT1cIm9uRHJhZ01vdmUoJ3RvJywgJGV2ZW50KVwiXG4gICAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2ICN0aHVtYlRvIGNsYXNzPVwidGh1bWJcIj5cbiAgICAgICAgICAgICAgQGlmIChjb21iaW5lZE9wdGlvbnMoKS50aHVtYlRvQ29udGVudFRlbXBsYXRlOyBhcyB0ZW1wbGF0ZSkge1xuICAgICAgICAgICAgICAgIDxuZy1jb250YWluZXIgKm5nVGVtcGxhdGVPdXRsZXQ9XCJ0ZW1wbGF0ZVwiPjwvbmctY29udGFpbmVyPlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICAgQGlmIChjb21iaW5lZE9wdGlvbnMoKS5taW5MYWJlbCAhPT0gdW5kZWZpbmVkIHx8IGNvbWJpbmVkT3B0aW9ucygpLm1heExhYmVsICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3M9XCJzbGlkZXItbGFiZWxzLWNvbnRhaW5lclwiXG4gICAgICAgID5cbiAgICAgICAgQGlmIChjb21iaW5lZE9wdGlvbnMoKS5taW5MYWJlbCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgPGRpdiBjbGFzcz1cIm1pbi1sYWJlbFwiPlxuICAgICAgICAgICAge3sgY29tYmluZWRPcHRpb25zKCkubWluTGFiZWwgfX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgICAgICBAaWYgKGNvbWJpbmVkT3B0aW9ucygpLm1heExhYmVsICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICA8ZGl2IGNsYXNzPVwibWF4LWxhYmVsXCI+XG4gICAgICAgICAgICB7eyBjb21iaW5lZE9wdGlvbnMoKS5tYXhMYWJlbCB9fVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICA8L2Rpdj5cbiAgICB9XG4gIDwvZGl2PlxuPC9kaXY+XG4iXX0=