import { Directive, input } from '@angular/core';
import * as i0 from "@angular/core";
export class AutofocusDirective {
    host;
    isAutofocusEnabled = input(true);
    constructor(host) {
        this.host = host;
    }
    ngOnInit() {
        if (!this.isAutofocusEnabled()) {
            return;
        }
        let elem = this.host.nativeElement;
        if (elem.tagName === 'INPUT' ||
            elem.tagName === 'TEXTAREA' ||
            elem.tagName === 'BUTTON' ||
            elem.hasAttribute('tabindex')) {
            elem.focus();
        }
        else {
            let nestedElem = elem.querySelector('input,textarea,button,[tabindex]');
            if (nestedElem) {
                nestedElem.focus();
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: AutofocusDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "17.3.1", type: AutofocusDirective, isStandalone: true, selector: "[ouiAutofocus]", inputs: { isAutofocusEnabled: { classPropertyName: "isAutofocusEnabled", publicName: "isAutofocusEnabled", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: AutofocusDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ouiAutofocus]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0b2ZvY3VzLmRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvYXV0b2ZvY3VzL2F1dG9mb2N1cy5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBYyxLQUFLLEVBQVUsTUFBTSxlQUFlLENBQUM7O0FBTXJFLE1BQU0sT0FBTyxrQkFBa0I7SUFFVDtJQURiLGtCQUFrQixHQUFHLEtBQUssQ0FBVSxJQUFJLENBQUMsQ0FBQztJQUNqRCxZQUFvQixJQUFnQjtRQUFoQixTQUFJLEdBQUosSUFBSSxDQUFZO0lBQUcsQ0FBQztJQUN4QyxRQUFRO1FBQ04sSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxFQUFFLENBQUM7WUFDL0IsT0FBTztRQUNULENBQUM7UUFDRCxJQUFJLElBQUksR0FBZ0IsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUM7UUFFaEQsSUFDRSxJQUFJLENBQUMsT0FBTyxLQUFLLE9BQU87WUFDeEIsSUFBSSxDQUFDLE9BQU8sS0FBSyxVQUFVO1lBQzNCLElBQUksQ0FBQyxPQUFPLEtBQUssUUFBUTtZQUN6QixJQUFJLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxFQUM3QixDQUFDO1lBQ0QsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2YsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGtDQUFrQyxDQUFDLENBQUM7WUFFeEUsSUFBSSxVQUFVLEVBQUUsQ0FBQztnQkFDZCxVQUErQixDQUFDLEtBQUssRUFBRSxDQUFDO1lBQzNDLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQzt1R0F2QlUsa0JBQWtCOzJGQUFsQixrQkFBa0I7OzJGQUFsQixrQkFBa0I7a0JBSjlCLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLGdCQUFnQjtvQkFDMUIsVUFBVSxFQUFFLElBQUk7aUJBQ2pCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlyZWN0aXZlLCBFbGVtZW50UmVmLCBpbnB1dCwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ1tvdWlBdXRvZm9jdXNdJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbn0pXG5leHBvcnQgY2xhc3MgQXV0b2ZvY3VzRGlyZWN0aXZlIGltcGxlbWVudHMgT25Jbml0IHtcbiAgcHVibGljIGlzQXV0b2ZvY3VzRW5hYmxlZCA9IGlucHV0PGJvb2xlYW4+KHRydWUpO1xuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGhvc3Q6IEVsZW1lbnRSZWYpIHt9XG4gIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIGlmICghdGhpcy5pc0F1dG9mb2N1c0VuYWJsZWQoKSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBsZXQgZWxlbTogSFRNTEVsZW1lbnQgPSB0aGlzLmhvc3QubmF0aXZlRWxlbWVudDtcblxuICAgIGlmIChcbiAgICAgIGVsZW0udGFnTmFtZSA9PT0gJ0lOUFVUJyB8fFxuICAgICAgZWxlbS50YWdOYW1lID09PSAnVEVYVEFSRUEnIHx8XG4gICAgICBlbGVtLnRhZ05hbWUgPT09ICdCVVRUT04nIHx8XG4gICAgICBlbGVtLmhhc0F0dHJpYnV0ZSgndGFiaW5kZXgnKVxuICAgICkge1xuICAgICAgZWxlbS5mb2N1cygpO1xuICAgIH0gZWxzZSB7XG4gICAgICBsZXQgbmVzdGVkRWxlbSA9IGVsZW0ucXVlcnlTZWxlY3RvcignaW5wdXQsdGV4dGFyZWEsYnV0dG9uLFt0YWJpbmRleF0nKTtcblxuICAgICAgaWYgKG5lc3RlZEVsZW0pIHtcbiAgICAgICAgKG5lc3RlZEVsZW0gYXMgSFRNTElucHV0RWxlbWVudCkuZm9jdXMoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdfQ==