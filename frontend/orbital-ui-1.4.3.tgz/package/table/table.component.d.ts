import { ElementRef, OnChanges, SimpleChanges } from '@angular/core';
import { TableService } from './table.service';
import { IOuiTableColumn, IOuiTableOptions } from './types';
import { ResizeResult } from 'ngxtension/resize';
import * as i0 from "@angular/core";
export declare class OuiTableComponent implements OnChanges {
    tableService: TableService;
    outerColumnWrapper: ElementRef<any>;
    innerColumnWrapper: ElementRef<any>;
    componentWrapper: ElementRef<any>;
    items: any[];
    set columns(newColumns: IOuiTableColumn[]);
    get columns(): IOuiTableColumn[];
    set options(newOptions: IOuiTableOptions);
    get options(): IOuiTableOptions;
    columnsSignal: import("@angular/core").WritableSignal<IOuiTableColumn[]>;
    private defaultOptions;
    optionsSignal: import("@angular/core").WritableSignal<IOuiTableOptions>;
    combinedOptions: import("@angular/core").Signal<{
        itemHeight: number;
        hasVirtualScroll: boolean;
        onItemClick?: ((item: any, clickEvent: Event) => void) | undefined;
        trackBy: string;
    }>;
    constructor(tableService: TableService);
    onResize(result: ResizeResult): void;
    private onItemsChanged;
    private onOptionsChanged;
    private onColumnsChanged;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiTableComponent, "oui-table", never, { "items": { "alias": "items"; "required": true; }; "columns": { "alias": "columns"; "required": true; }; "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=table.component.d.ts.map