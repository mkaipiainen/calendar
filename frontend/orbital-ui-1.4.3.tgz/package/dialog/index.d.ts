/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/dialog" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-dialog.d.ts.map