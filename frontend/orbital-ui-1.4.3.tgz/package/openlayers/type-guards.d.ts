import { OuiOpenlayersTileLayerOptions, OuiOpenlayersTileLayerWmtsOptions } from './types';
export declare function IsWmtsLayerOptions(options: OuiOpenlayersTileLayerOptions): options is OuiOpenlayersTileLayerWmtsOptions;
//# sourceMappingURL=type-guards.d.ts.map