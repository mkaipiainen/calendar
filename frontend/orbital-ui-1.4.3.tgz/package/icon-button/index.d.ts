/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/icon-button" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-icon-button.d.ts.map