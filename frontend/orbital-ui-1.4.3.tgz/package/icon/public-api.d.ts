export * from './icon.component';
//# sourceMappingURL=public-api.d.ts.map