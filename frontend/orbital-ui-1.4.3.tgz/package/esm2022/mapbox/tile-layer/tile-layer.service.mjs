import { Injectable } from '@angular/core';
import { ImageLoader } from '@loaders.gl/images';
import { load } from '@loaders.gl/core';
import { of, take } from 'rxjs';
import { IsWmtsImageBrokerImage, } from 'orbital-ui/core';
import * as i0 from "@angular/core";
import * as i1 from "orbital-ui/core";
/**
 * Service to handle fetching of raster-layers for the map.
 * Caches tiles in memory to prevent unnecessary requests.
 * Handles canceling of requests in case of the layer getting removed from the map, or the map being destroyed, and so on.
 * Also handles attaching the access token to the requests.
 */
export class TileLayerService {
    requestQueueService;
    zone;
    cachedTiles = {};
    constructor(requestQueueService, zone) {
        this.requestQueueService = requestQueueService;
        this.zone = zone;
        setInterval(() => {
            this.clearCache();
        }, 60000 * 10);
    }
    /**
     * Returns a Deck.GL tileLayer-configuration for a map. This should work out of the gate by just giving the function
     * a unique ID (IMPORTANT), and the desired opticalImage-object. The function will then handle the rest.
     * @param id
     * @param data
     * @param options
     * @param layerOptions
     */
    getTileLayer(options, layerOptions = {}) {
        const defaultOptions = {
            isWebMercator: false,
            useCache: true,
            isWmts: false,
        };
        const combinedOptions = {
            ...defaultOptions,
            ...options,
        };
        const sourceUrls = (options.data ?? []).map(singleData => {
            if (typeof singleData === 'string') {
                return singleData;
            }
            else {
                const url = options.buildUrl
                    ? options.buildUrl(singleData, options)
                    : this.defaultUrlBuilder(singleData, options);
                return url;
            }
        });
        return {
            id: options.id,
            data: sourceUrls,
            isEnabled: !!sourceUrls.length,
            visible: !!sourceUrls.length,
            getTileData: (tile) => {
                return this.responseToObjectUrl(tile, combinedOptions);
            },
            ...layerOptions,
        };
    }
    defaultUrlBuilder(image, options) {
        let url = '';
        const origin = options.origin;
        // TODO: FIX WMTS
        if (IsWmtsImageBrokerImage(image)) {
            // const parsedWmtsUrl = image.wmts_data.url.replace('/wmts', '');
            // url = `${origin}/https://tiles1.geoserve.eu/Pleiades-NEO/tileserver/20230402_105346_PNEO-03_1_45_30cm_RD_8bit_RGB_Rijswijk/{z}/{x}/{y}`;
            url = `${origin}/https://tiles1.geoserve.eu/Pleiades-NEO/20231017_110049_PNEO-03_1_1_30cm_RD_8bit_RGB_DeLier/{z}/{x}/{y}`;
        }
        else {
            url = `${origin}/${image?.wms_data.image_url}&REQUEST=GetMap&SERVICE=${image?.service_type}&LAYERS=${image?.wms_data.wms_layer_name}&FORMAT=image/png&TRANSPARENT=TRUE&SRS=EPSG:3857&CRS=EPSG:4326&WIDTH=256&HEIGHT=256&VERSION=1.3.0&STYLES=`;
        }
        return url;
    }
    responseToObjectUrl(tile, options) {
        return new Promise((resolve, reject) => {
            if (options.useCache && !this.cachedTiles[options.id]) {
                this.cachedTiles[options.id] = {};
            }
            (options.accessToken$ ?? of('test')).pipe(take(1)).subscribe(token => {
                let finalUrl = tile.url;
                if (!options.isWmts) {
                    let bbox = [
                        tile.bbox.south,
                        tile.bbox.west,
                        tile.bbox.north,
                        tile.bbox.east,
                    ].join(',');
                    if (options.isWebMercator) {
                        const xySouthWest = this.latLonToMercator(tile.bbox.west, tile.bbox.south);
                        const xyNorthEast = this.latLonToMercator(tile.bbox.east, tile.bbox.north);
                        bbox = [
                            xySouthWest.x,
                            xySouthWest.y,
                            xyNorthEast.x,
                            xyNorthEast.y,
                        ].join(',');
                    }
                    finalUrl = `${tile.url}&BBOX=${bbox}`;
                }
                if (this.cachedTiles[options.id][finalUrl]) {
                    resolve(this.cachedTiles[options.id][finalUrl]);
                }
                else {
                    let headers = {};
                    if (token !== 'test') {
                        const authHeader = `Bearer ${token}`;
                        headers = {
                            Authorization: authHeader,
                        };
                    }
                    const promise = fetch(finalUrl, {
                        signal: tile.signal,
                        headers: headers,
                    });
                    this.zone.runOutsideAngular(() => {
                        const imagePromise = this.requestQueueService.addToQueue(promise, tile.signal, options.refreshedAccessToken$);
                        imagePromise
                            .catch(error => {
                            reject(error);
                        })
                            .then(async (response) => {
                            if (!response) {
                                reject(response);
                            }
                            try {
                                const image = await load(response, ImageLoader, {});
                                if (this.cachedTiles[options.id]) {
                                    this.cachedTiles[options.id][finalUrl] = image;
                                }
                                resolve(image);
                                return image;
                            }
                            catch (e) {
                                reject(e);
                            }
                        }, reject);
                    });
                }
            });
        });
    }
    latLonToMercator(lon, lat) {
        const rMajor = 6378137; //Equatorial Radius, WGS84
        const shift = Math.PI * rMajor;
        const x = (lon * shift) / 180;
        let y = Math.log(Math.tan(((90 + lat) * Math.PI) / 360)) / (Math.PI / 180);
        y = (y * shift) / 180;
        return {
            x,
            y,
        };
    }
    clearCache(id) {
        if (id) {
            delete this.cachedTiles[id];
        }
        else {
            this.cachedTiles = {};
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: TileLayerService, deps: [{ token: i1.RequestQueueService }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: TileLayerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: TileLayerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.RequestQueueService }, { type: i0.NgZone }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGlsZS1sYXllci5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9tYXBib3gvdGlsZS1sYXllci90aWxlLWxheWVyLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBVSxNQUFNLGVBQWUsQ0FBQztBQUNuRCxPQUFPLEVBQUUsV0FBVyxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDakQsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLGtCQUFrQixDQUFDO0FBRXhDLE9BQU8sRUFBYyxFQUFFLEVBQUUsSUFBSSxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQzVDLE9BQU8sRUFHTCxzQkFBc0IsR0FFdkIsTUFBTSxpQkFBaUIsQ0FBQzs7O0FBd0N6Qjs7Ozs7R0FLRztBQUlILE1BQU0sT0FBTyxnQkFBZ0I7SUFHakI7SUFDQTtJQUhGLFdBQVcsR0FBMkIsRUFBRSxDQUFDO0lBQ2pELFlBQ1UsbUJBQXdDLEVBQ3hDLElBQVk7UUFEWix3QkFBbUIsR0FBbkIsbUJBQW1CLENBQXFCO1FBQ3hDLFNBQUksR0FBSixJQUFJLENBQVE7UUFFcEIsV0FBVyxDQUFDLEdBQUcsRUFBRTtZQUNmLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNwQixDQUFDLEVBQUUsS0FBSyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0lBQ2pCLENBQUM7SUFFRDs7Ozs7OztPQU9HO0lBQ0ksWUFBWSxDQUNqQixPQUE2QixFQUM3QixlQUErQyxFQUFFO1FBRWpELE1BQU0sY0FBYyxHQUFHO1lBQ3JCLGFBQWEsRUFBRSxLQUFLO1lBQ3BCLFFBQVEsRUFBRSxJQUFJO1lBQ2QsTUFBTSxFQUFFLEtBQUs7U0FDZCxDQUFDO1FBQ0YsTUFBTSxlQUFlLEdBQXlCO1lBQzVDLEdBQUcsY0FBYztZQUNqQixHQUFHLE9BQU87U0FDWCxDQUFDO1FBQ0YsTUFBTSxVQUFVLEdBQUcsQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsRUFBRTtZQUN2RCxJQUFJLE9BQU8sVUFBVSxLQUFLLFFBQVEsRUFBRSxDQUFDO2dCQUNuQyxPQUFPLFVBQVUsQ0FBQztZQUNwQixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sTUFBTSxHQUFHLEdBQUcsT0FBTyxDQUFDLFFBQVE7b0JBQzFCLENBQUMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFVBQVUsRUFBRSxPQUFPLENBQUM7b0JBQ3ZDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsVUFBVSxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUNoRCxPQUFPLEdBQUcsQ0FBQztZQUNiLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUNILE9BQU87WUFDTCxFQUFFLEVBQUUsT0FBTyxDQUFDLEVBQUU7WUFDZCxJQUFJLEVBQUUsVUFBVTtZQUNoQixTQUFTLEVBQUUsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxNQUFNO1lBQzlCLE9BQU8sRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU07WUFDNUIsV0FBVyxFQUFFLENBQUMsSUFBd0IsRUFBRSxFQUFFO2dCQUN4QyxPQUFPLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLEVBQUUsZUFBZSxDQUFDLENBQUM7WUFDekQsQ0FBQztZQUNELEdBQUcsWUFBWTtTQUNoQixDQUFDO0lBQ0osQ0FBQztJQUVPLGlCQUFpQixDQUN2QixLQUE4QixFQUM5QixPQUE2QjtRQUU3QixJQUFJLEdBQUcsR0FBRyxFQUFFLENBQUM7UUFDYixNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO1FBQzlCLGlCQUFpQjtRQUNqQixJQUFJLHNCQUFzQixDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDbEMsa0VBQWtFO1lBQ2xFLDJJQUEySTtZQUMzSSxHQUFHLEdBQUcsR0FBRyxNQUFNLDBHQUEwRyxDQUFDO1FBQzVILENBQUM7YUFBTSxDQUFDO1lBQ04sR0FBRyxHQUFHLEdBQUcsTUFBTSxJQUFJLEtBQUssRUFBRSxRQUFRLENBQUMsU0FBUywyQkFBMkIsS0FBSyxFQUFFLFlBQVksV0FBVyxLQUFLLEVBQUUsUUFBUSxDQUFDLGNBQWMsMkdBQTJHLENBQUM7UUFDalAsQ0FBQztRQUNELE9BQU8sR0FBRyxDQUFDO0lBQ2IsQ0FBQztJQUVPLG1CQUFtQixDQUFDLElBQVMsRUFBRSxPQUE2QjtRQUNsRSxPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JDLElBQUksT0FBTyxDQUFDLFFBQVEsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7Z0JBQ3RELElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNwQyxDQUFDO1lBQ0QsQ0FBQyxPQUFPLENBQUMsWUFBWSxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLEVBQUU7Z0JBQ25FLElBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUM7Z0JBRXhCLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBQ3BCLElBQUksSUFBSSxHQUFHO3dCQUNULElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSzt3QkFDZixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUk7d0JBQ2QsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLO3dCQUNmLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSTtxQkFDZixDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDWixJQUFJLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQzt3QkFDMUIsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUN2QyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFDZCxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FDaEIsQ0FBQzt3QkFDRixNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQ3ZDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUNkLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUNoQixDQUFDO3dCQUNGLElBQUksR0FBRzs0QkFDTCxXQUFXLENBQUMsQ0FBQzs0QkFDYixXQUFXLENBQUMsQ0FBQzs0QkFDYixXQUFXLENBQUMsQ0FBQzs0QkFDYixXQUFXLENBQUMsQ0FBQzt5QkFDZCxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDZCxDQUFDO29CQUNELFFBQVEsR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLFNBQVMsSUFBSSxFQUFFLENBQUM7Z0JBQ3hDLENBQUM7Z0JBRUQsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDO29CQUMzQyxPQUFPLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztnQkFDbEQsQ0FBQztxQkFBTSxDQUFDO29CQUNOLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztvQkFDakIsSUFBSSxLQUFLLEtBQUssTUFBTSxFQUFFLENBQUM7d0JBQ3JCLE1BQU0sVUFBVSxHQUFHLFVBQVUsS0FBSyxFQUFFLENBQUM7d0JBQ3JDLE9BQU8sR0FBRzs0QkFDUixhQUFhLEVBQUUsVUFBVTt5QkFDMUIsQ0FBQztvQkFDSixDQUFDO29CQUNELE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQUU7d0JBQzlCLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTt3QkFDbkIsT0FBTyxFQUFFLE9BQU87cUJBQ2pCLENBQUMsQ0FBQztvQkFDSCxJQUFJLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsRUFBRTt3QkFDL0IsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFVBQVUsQ0FDdEQsT0FBTyxFQUNQLElBQUksQ0FBQyxNQUFNLEVBQ1gsT0FBTyxDQUFDLHFCQUFxQixDQUM5QixDQUFDO3dCQUNGLFlBQVk7NkJBQ1QsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFOzRCQUNiLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDaEIsQ0FBQyxDQUFDOzZCQUNELElBQUksQ0FBQyxLQUFLLEVBQUUsUUFBYSxFQUFFLEVBQUU7NEJBQzVCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQ0FDZCxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7NEJBQ25CLENBQUM7NEJBQ0QsSUFBSSxDQUFDO2dDQUNILE1BQU0sS0FBSyxHQUFHLE1BQU0sSUFBSSxDQUFDLFFBQVEsRUFBRSxXQUFXLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0NBQ3BELElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQztvQ0FDakMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsS0FBSyxDQUFDO2dDQUNqRCxDQUFDO2dDQUNELE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztnQ0FDZixPQUFPLEtBQUssQ0FBQzs0QkFDZixDQUFDOzRCQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7Z0NBQ1gsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDOzRCQUNaLENBQUM7d0JBQ0gsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO29CQUNmLENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVPLGdCQUFnQixDQUFDLEdBQVcsRUFBRSxHQUFXO1FBQy9DLE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxDQUFDLDBCQUEwQjtRQUNsRCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsRUFBRSxHQUFHLE1BQU0sQ0FBQztRQUMvQixNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxLQUFLLENBQUMsR0FBRyxHQUFHLENBQUM7UUFDOUIsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLEdBQUcsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxHQUFHLEdBQUcsQ0FBQyxDQUFDO1FBQzNFLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsR0FBRyxHQUFHLENBQUM7UUFFdEIsT0FBTztZQUNMLENBQUM7WUFDRCxDQUFDO1NBQ0YsQ0FBQztJQUNKLENBQUM7SUFFTSxVQUFVLENBQUMsRUFBVztRQUMzQixJQUFJLEVBQUUsRUFBRSxDQUFDO1lBQ1AsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQzlCLENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUM7UUFDeEIsQ0FBQztJQUNILENBQUM7dUdBektVLGdCQUFnQjsyR0FBaEIsZ0JBQWdCLGNBRmYsTUFBTTs7MkZBRVAsZ0JBQWdCO2tCQUg1QixVQUFVO21CQUFDO29CQUNWLFVBQVUsRUFBRSxNQUFNO2lCQUNuQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUsIE5nWm9uZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSW1hZ2VMb2FkZXIgfSBmcm9tICdAbG9hZGVycy5nbC9pbWFnZXMnO1xuaW1wb3J0IHsgbG9hZCB9IGZyb20gJ0Bsb2FkZXJzLmdsL2NvcmUnO1xuaW1wb3J0IHsgSURlY2tUaWxlTGF5ZXJPcHRpb25zLCBJRGVja1RpbGVMYXllclRpbGUgfSBmcm9tICcuLi90eXBpbmdzJztcbmltcG9ydCB7IE9ic2VydmFibGUsIG9mLCB0YWtlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQge1xuICBJc1MySW1hZ2UsXG4gIElzV21zSW1hZ2VCcm9rZXJJbWFnZSxcbiAgSXNXbXRzSW1hZ2VCcm9rZXJJbWFnZSxcbiAgUmVxdWVzdFF1ZXVlU2VydmljZSxcbn0gZnJvbSAnb3JiaXRhbC11aS9jb3JlJztcbmltcG9ydCB7IEltYWdlQnJva2VyT3B0aWNhbEltYWdlIH0gZnJvbSAnb3JiaXRhbC11aS9jb3JlJztcblxuZXhwb3J0IHR5cGUgSUdldFRpbGVMYXllck9wdGlvbnMgPVxuICB8IElHZXRUaWxlTGF5ZXJPcHRpY2FsSW1hZ2VPcHRpb25zXG4gIHwgSUdldFRpbGVMYXllckN1c3RvbURhdGFPcHRpb25zO1xuXG5leHBvcnQgaW50ZXJmYWNlIElHZXRDb21tb25UaWxlTGF5ZXJPcHRpb25zIHtcbiAgaWQ6IHN0cmluZztcbiAgaXNXZWJNZXJjYXRvcj86IGJvb2xlYW47XG4gIHVzZUNhY2hlPzogYm9vbGVhbjtcbiAgYWNjZXNzVG9rZW4kPzogT2JzZXJ2YWJsZTxzdHJpbmc+O1xuICByZWZyZXNoZWRBY2Nlc3NUb2tlbiQ/OiBPYnNlcnZhYmxlPHN0cmluZz47XG4gIGlzV210cz86IGJvb2xlYW47XG4gIG9yaWdpbjogc3RyaW5nO1xufVxuZXhwb3J0IGludGVyZmFjZSBJR2V0VGlsZUxheWVyT3B0aWNhbEltYWdlT3B0aW9uc1xuICBleHRlbmRzIElHZXRDb21tb25UaWxlTGF5ZXJPcHRpb25zIHtcbiAgYnVpbGRVcmw/OiAoXG4gICAgdXJsOiBJbWFnZUJyb2tlck9wdGljYWxJbWFnZSxcbiAgICBvcHRpb25zOiBJR2V0VGlsZUxheWVyT3B0aW9uc1xuICApID0+IHN0cmluZztcbiAgZGF0YTogSW1hZ2VCcm9rZXJPcHRpY2FsSW1hZ2VbXSB8IHN0cmluZ1tdO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElHZXRUaWxlTGF5ZXJDdXN0b21EYXRhT3B0aW9uc1xuICBleHRlbmRzIElHZXRDb21tb25UaWxlTGF5ZXJPcHRpb25zIHtcbiAgaWQ6IHN0cmluZztcbiAgaXNXZWJNZXJjYXRvcj86IGJvb2xlYW47XG4gIHVzZUNhY2hlPzogYm9vbGVhbjtcbiAgZGF0YTogRXhjbHVkZTxhbnksIEltYWdlQnJva2VyT3B0aWNhbEltYWdlPltdO1xuICBidWlsZFVybDogKFxuICAgIHVybDogRXhjbHVkZTxhbnksIEltYWdlQnJva2VyT3B0aWNhbEltYWdlPixcbiAgICBvcHRpb25zOiBJR2V0VGlsZUxheWVyT3B0aW9uc1xuICApID0+IHN0cmluZztcbiAgb3JpZ2luOiBzdHJpbmc7XG4gIGFjY2Vzc1Rva2VuJDogT2JzZXJ2YWJsZTxzdHJpbmc+O1xuICByZWZyZXNoZWRBY2Nlc3NUb2tlbiQ6IE9ic2VydmFibGU8c3RyaW5nPjtcbn1cblxuLyoqXG4gKiBTZXJ2aWNlIHRvIGhhbmRsZSBmZXRjaGluZyBvZiByYXN0ZXItbGF5ZXJzIGZvciB0aGUgbWFwLlxuICogQ2FjaGVzIHRpbGVzIGluIG1lbW9yeSB0byBwcmV2ZW50IHVubmVjZXNzYXJ5IHJlcXVlc3RzLlxuICogSGFuZGxlcyBjYW5jZWxpbmcgb2YgcmVxdWVzdHMgaW4gY2FzZSBvZiB0aGUgbGF5ZXIgZ2V0dGluZyByZW1vdmVkIGZyb20gdGhlIG1hcCwgb3IgdGhlIG1hcCBiZWluZyBkZXN0cm95ZWQsIGFuZCBzbyBvbi5cbiAqIEFsc28gaGFuZGxlcyBhdHRhY2hpbmcgdGhlIGFjY2VzcyB0b2tlbiB0byB0aGUgcmVxdWVzdHMuXG4gKi9cbkBJbmplY3RhYmxlKHtcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxufSlcbmV4cG9ydCBjbGFzcyBUaWxlTGF5ZXJTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBjYWNoZWRUaWxlczogeyBba2V5OiBzdHJpbmddOiBhbnkgfSA9IHt9O1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJlcXVlc3RRdWV1ZVNlcnZpY2U6IFJlcXVlc3RRdWV1ZVNlcnZpY2UsXG4gICAgcHJpdmF0ZSB6b25lOiBOZ1pvbmVcbiAgKSB7XG4gICAgc2V0SW50ZXJ2YWwoKCkgPT4ge1xuICAgICAgdGhpcy5jbGVhckNhY2hlKCk7XG4gICAgfSwgNjAwMDAgKiAxMCk7XG4gIH1cblxuICAvKipcbiAgICogUmV0dXJucyBhIERlY2suR0wgdGlsZUxheWVyLWNvbmZpZ3VyYXRpb24gZm9yIGEgbWFwLiBUaGlzIHNob3VsZCB3b3JrIG91dCBvZiB0aGUgZ2F0ZSBieSBqdXN0IGdpdmluZyB0aGUgZnVuY3Rpb25cbiAgICogYSB1bmlxdWUgSUQgKElNUE9SVEFOVCksIGFuZCB0aGUgZGVzaXJlZCBvcHRpY2FsSW1hZ2Utb2JqZWN0LiBUaGUgZnVuY3Rpb24gd2lsbCB0aGVuIGhhbmRsZSB0aGUgcmVzdC5cbiAgICogQHBhcmFtIGlkXG4gICAqIEBwYXJhbSBkYXRhXG4gICAqIEBwYXJhbSBvcHRpb25zXG4gICAqIEBwYXJhbSBsYXllck9wdGlvbnNcbiAgICovXG4gIHB1YmxpYyBnZXRUaWxlTGF5ZXIoXG4gICAgb3B0aW9uczogSUdldFRpbGVMYXllck9wdGlvbnMsXG4gICAgbGF5ZXJPcHRpb25zOiBQYXJ0aWFsPElEZWNrVGlsZUxheWVyT3B0aW9ucz4gPSB7fVxuICApOiBJRGVja1RpbGVMYXllck9wdGlvbnMge1xuICAgIGNvbnN0IGRlZmF1bHRPcHRpb25zID0ge1xuICAgICAgaXNXZWJNZXJjYXRvcjogZmFsc2UsXG4gICAgICB1c2VDYWNoZTogdHJ1ZSxcbiAgICAgIGlzV210czogZmFsc2UsXG4gICAgfTtcbiAgICBjb25zdCBjb21iaW5lZE9wdGlvbnM6IElHZXRUaWxlTGF5ZXJPcHRpb25zID0ge1xuICAgICAgLi4uZGVmYXVsdE9wdGlvbnMsXG4gICAgICAuLi5vcHRpb25zLFxuICAgIH07XG4gICAgY29uc3Qgc291cmNlVXJscyA9IChvcHRpb25zLmRhdGEgPz8gW10pLm1hcChzaW5nbGVEYXRhID0+IHtcbiAgICAgIGlmICh0eXBlb2Ygc2luZ2xlRGF0YSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgcmV0dXJuIHNpbmdsZURhdGE7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zdCB1cmwgPSBvcHRpb25zLmJ1aWxkVXJsXG4gICAgICAgICAgPyBvcHRpb25zLmJ1aWxkVXJsKHNpbmdsZURhdGEsIG9wdGlvbnMpXG4gICAgICAgICAgOiB0aGlzLmRlZmF1bHRVcmxCdWlsZGVyKHNpbmdsZURhdGEsIG9wdGlvbnMpO1xuICAgICAgICByZXR1cm4gdXJsO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiB7XG4gICAgICBpZDogb3B0aW9ucy5pZCxcbiAgICAgIGRhdGE6IHNvdXJjZVVybHMsXG4gICAgICBpc0VuYWJsZWQ6ICEhc291cmNlVXJscy5sZW5ndGgsXG4gICAgICB2aXNpYmxlOiAhIXNvdXJjZVVybHMubGVuZ3RoLFxuICAgICAgZ2V0VGlsZURhdGE6ICh0aWxlOiBJRGVja1RpbGVMYXllclRpbGUpID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMucmVzcG9uc2VUb09iamVjdFVybCh0aWxlLCBjb21iaW5lZE9wdGlvbnMpO1xuICAgICAgfSxcbiAgICAgIC4uLmxheWVyT3B0aW9ucyxcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSBkZWZhdWx0VXJsQnVpbGRlcihcbiAgICBpbWFnZTogSW1hZ2VCcm9rZXJPcHRpY2FsSW1hZ2UsXG4gICAgb3B0aW9uczogSUdldFRpbGVMYXllck9wdGlvbnNcbiAgKSB7XG4gICAgbGV0IHVybCA9ICcnO1xuICAgIGNvbnN0IG9yaWdpbiA9IG9wdGlvbnMub3JpZ2luO1xuICAgIC8vIFRPRE86IEZJWCBXTVRTXG4gICAgaWYgKElzV210c0ltYWdlQnJva2VySW1hZ2UoaW1hZ2UpKSB7XG4gICAgICAvLyBjb25zdCBwYXJzZWRXbXRzVXJsID0gaW1hZ2Uud210c19kYXRhLnVybC5yZXBsYWNlKCcvd210cycsICcnKTtcbiAgICAgIC8vIHVybCA9IGAke29yaWdpbn0vaHR0cHM6Ly90aWxlczEuZ2Vvc2VydmUuZXUvUGxlaWFkZXMtTkVPL3RpbGVzZXJ2ZXIvMjAyMzA0MDJfMTA1MzQ2X1BORU8tMDNfMV80NV8zMGNtX1JEXzhiaXRfUkdCX1JpanN3aWprL3t6fS97eH0ve3l9YDtcbiAgICAgIHVybCA9IGAke29yaWdpbn0vaHR0cHM6Ly90aWxlczEuZ2Vvc2VydmUuZXUvUGxlaWFkZXMtTkVPLzIwMjMxMDE3XzExMDA0OV9QTkVPLTAzXzFfMV8zMGNtX1JEXzhiaXRfUkdCX0RlTGllci97en0ve3h9L3t5fWA7XG4gICAgfSBlbHNlIHtcbiAgICAgIHVybCA9IGAke29yaWdpbn0vJHtpbWFnZT8ud21zX2RhdGEuaW1hZ2VfdXJsfSZSRVFVRVNUPUdldE1hcCZTRVJWSUNFPSR7aW1hZ2U/LnNlcnZpY2VfdHlwZX0mTEFZRVJTPSR7aW1hZ2U/Lndtc19kYXRhLndtc19sYXllcl9uYW1lfSZGT1JNQVQ9aW1hZ2UvcG5nJlRSQU5TUEFSRU5UPVRSVUUmU1JTPUVQU0c6Mzg1NyZDUlM9RVBTRzo0MzI2JldJRFRIPTI1NiZIRUlHSFQ9MjU2JlZFUlNJT049MS4zLjAmU1RZTEVTPWA7XG4gICAgfVxuICAgIHJldHVybiB1cmw7XG4gIH1cblxuICBwcml2YXRlIHJlc3BvbnNlVG9PYmplY3RVcmwodGlsZTogYW55LCBvcHRpb25zOiBJR2V0VGlsZUxheWVyT3B0aW9ucykge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBpZiAob3B0aW9ucy51c2VDYWNoZSAmJiAhdGhpcy5jYWNoZWRUaWxlc1tvcHRpb25zLmlkXSkge1xuICAgICAgICB0aGlzLmNhY2hlZFRpbGVzW29wdGlvbnMuaWRdID0ge307XG4gICAgICB9XG4gICAgICAob3B0aW9ucy5hY2Nlc3NUb2tlbiQgPz8gb2YoJ3Rlc3QnKSkucGlwZSh0YWtlKDEpKS5zdWJzY3JpYmUodG9rZW4gPT4ge1xuICAgICAgICBsZXQgZmluYWxVcmwgPSB0aWxlLnVybDtcblxuICAgICAgICBpZiAoIW9wdGlvbnMuaXNXbXRzKSB7XG4gICAgICAgICAgbGV0IGJib3ggPSBbXG4gICAgICAgICAgICB0aWxlLmJib3guc291dGgsXG4gICAgICAgICAgICB0aWxlLmJib3gud2VzdCxcbiAgICAgICAgICAgIHRpbGUuYmJveC5ub3J0aCxcbiAgICAgICAgICAgIHRpbGUuYmJveC5lYXN0LFxuICAgICAgICAgIF0uam9pbignLCcpO1xuICAgICAgICAgIGlmIChvcHRpb25zLmlzV2ViTWVyY2F0b3IpIHtcbiAgICAgICAgICAgIGNvbnN0IHh5U291dGhXZXN0ID0gdGhpcy5sYXRMb25Ub01lcmNhdG9yKFxuICAgICAgICAgICAgICB0aWxlLmJib3gud2VzdCxcbiAgICAgICAgICAgICAgdGlsZS5iYm94LnNvdXRoXG4gICAgICAgICAgICApO1xuICAgICAgICAgICAgY29uc3QgeHlOb3J0aEVhc3QgPSB0aGlzLmxhdExvblRvTWVyY2F0b3IoXG4gICAgICAgICAgICAgIHRpbGUuYmJveC5lYXN0LFxuICAgICAgICAgICAgICB0aWxlLmJib3gubm9ydGhcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgICBiYm94ID0gW1xuICAgICAgICAgICAgICB4eVNvdXRoV2VzdC54LFxuICAgICAgICAgICAgICB4eVNvdXRoV2VzdC55LFxuICAgICAgICAgICAgICB4eU5vcnRoRWFzdC54LFxuICAgICAgICAgICAgICB4eU5vcnRoRWFzdC55LFxuICAgICAgICAgICAgXS5qb2luKCcsJyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGZpbmFsVXJsID0gYCR7dGlsZS51cmx9JkJCT1g9JHtiYm94fWA7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAodGhpcy5jYWNoZWRUaWxlc1tvcHRpb25zLmlkXVtmaW5hbFVybF0pIHtcbiAgICAgICAgICByZXNvbHZlKHRoaXMuY2FjaGVkVGlsZXNbb3B0aW9ucy5pZF1bZmluYWxVcmxdKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBsZXQgaGVhZGVycyA9IHt9O1xuICAgICAgICAgIGlmICh0b2tlbiAhPT0gJ3Rlc3QnKSB7XG4gICAgICAgICAgICBjb25zdCBhdXRoSGVhZGVyID0gYEJlYXJlciAke3Rva2VufWA7XG4gICAgICAgICAgICBoZWFkZXJzID0ge1xuICAgICAgICAgICAgICBBdXRob3JpemF0aW9uOiBhdXRoSGVhZGVyLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgcHJvbWlzZSA9IGZldGNoKGZpbmFsVXJsLCB7XG4gICAgICAgICAgICBzaWduYWw6IHRpbGUuc2lnbmFsLFxuICAgICAgICAgICAgaGVhZGVyczogaGVhZGVycyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICB0aGlzLnpvbmUucnVuT3V0c2lkZUFuZ3VsYXIoKCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgaW1hZ2VQcm9taXNlID0gdGhpcy5yZXF1ZXN0UXVldWVTZXJ2aWNlLmFkZFRvUXVldWUoXG4gICAgICAgICAgICAgIHByb21pc2UsXG4gICAgICAgICAgICAgIHRpbGUuc2lnbmFsLFxuICAgICAgICAgICAgICBvcHRpb25zLnJlZnJlc2hlZEFjY2Vzc1Rva2VuJFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGltYWdlUHJvbWlzZVxuICAgICAgICAgICAgICAuY2F0Y2goZXJyb3IgPT4ge1xuICAgICAgICAgICAgICAgIHJlamVjdChlcnJvcik7XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC50aGVuKGFzeW5jIChyZXNwb25zZTogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFyZXNwb25zZSkge1xuICAgICAgICAgICAgICAgICAgcmVqZWN0KHJlc3BvbnNlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGltYWdlID0gYXdhaXQgbG9hZChyZXNwb25zZSwgSW1hZ2VMb2FkZXIsIHt9KTtcbiAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNhY2hlZFRpbGVzW29wdGlvbnMuaWRdKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuY2FjaGVkVGlsZXNbb3B0aW9ucy5pZF1bZmluYWxVcmxdID0gaW1hZ2U7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICByZXNvbHZlKGltYWdlKTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBpbWFnZTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgICByZWplY3QoZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9LCByZWplY3QpO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgbGF0TG9uVG9NZXJjYXRvcihsb246IG51bWJlciwgbGF0OiBudW1iZXIpIHtcbiAgICBjb25zdCByTWFqb3IgPSA2Mzc4MTM3OyAvL0VxdWF0b3JpYWwgUmFkaXVzLCBXR1M4NFxuICAgIGNvbnN0IHNoaWZ0ID0gTWF0aC5QSSAqIHJNYWpvcjtcbiAgICBjb25zdCB4ID0gKGxvbiAqIHNoaWZ0KSAvIDE4MDtcbiAgICBsZXQgeSA9IE1hdGgubG9nKE1hdGgudGFuKCgoOTAgKyBsYXQpICogTWF0aC5QSSkgLyAzNjApKSAvIChNYXRoLlBJIC8gMTgwKTtcbiAgICB5ID0gKHkgKiBzaGlmdCkgLyAxODA7XG5cbiAgICByZXR1cm4ge1xuICAgICAgeCxcbiAgICAgIHksXG4gICAgfTtcbiAgfVxuXG4gIHB1YmxpYyBjbGVhckNhY2hlKGlkPzogc3RyaW5nKSB7XG4gICAgaWYgKGlkKSB7XG4gICAgICBkZWxldGUgdGhpcy5jYWNoZWRUaWxlc1tpZF07XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuY2FjaGVkVGlsZXMgPSB7fTtcbiAgICB9XG4gIH1cbn1cbiJdfQ==