import { Pipe } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Pipe to output either a caret up or down depending on value
 */
export class CarouselNamePlacementPipe {
    transform(placement) {
        switch (placement) {
            case 'top-right':
                return 'top-0 right-0';
            case 'top-left':
                return 'top-0 left-0';
            case 'bottom-right':
                return 'bottom-0 right-0';
            case 'bottom-left':
                return 'bottom-0 left-0';
            default:
                return 'top-0 left-0';
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: CarouselNamePlacementPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: CarouselNamePlacementPipe, isStandalone: true, name: "carouselNamePlacement" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: CarouselNamePlacementPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'carouselNamePlacement',
                    standalone: true,
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmFtZS1wbGFjZW1lbnQucGlwZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvY2Fyb3VzZWwvbmFtZS1wbGFjZW1lbnQucGlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsSUFBSSxFQUFpQixNQUFNLGVBQWUsQ0FBQzs7QUFFcEQ7O0dBRUc7QUFLSCxNQUFNLE9BQU8seUJBQXlCO0lBQ3BDLFNBQVMsQ0FBQyxTQUFpQjtRQUN6QixRQUFRLFNBQVMsRUFBRSxDQUFDO1lBQ2xCLEtBQUssV0FBVztnQkFDZCxPQUFPLGVBQWUsQ0FBQztZQUN6QixLQUFLLFVBQVU7Z0JBQ2IsT0FBTyxjQUFjLENBQUM7WUFDeEIsS0FBSyxjQUFjO2dCQUNqQixPQUFPLGtCQUFrQixDQUFDO1lBQzVCLEtBQUssYUFBYTtnQkFDaEIsT0FBTyxpQkFBaUIsQ0FBQztZQUMzQjtnQkFDRSxPQUFPLGNBQWMsQ0FBQztRQUMxQixDQUFDO0lBQ0gsQ0FBQzt1R0FkVSx5QkFBeUI7cUdBQXpCLHlCQUF5Qjs7MkZBQXpCLHlCQUF5QjtrQkFKckMsSUFBSTttQkFBQztvQkFDSixJQUFJLEVBQUUsdUJBQXVCO29CQUM3QixVQUFVLEVBQUUsSUFBSTtpQkFDakIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQaXBlLCBQaXBlVHJhbnNmb3JtIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbi8qKlxuICogUGlwZSB0byBvdXRwdXQgZWl0aGVyIGEgY2FyZXQgdXAgb3IgZG93biBkZXBlbmRpbmcgb24gdmFsdWVcbiAqL1xuQFBpcGUoe1xuICBuYW1lOiAnY2Fyb3VzZWxOYW1lUGxhY2VtZW50JyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbn0pXG5leHBvcnQgY2xhc3MgQ2Fyb3VzZWxOYW1lUGxhY2VtZW50UGlwZSBpbXBsZW1lbnRzIFBpcGVUcmFuc2Zvcm0ge1xuICB0cmFuc2Zvcm0ocGxhY2VtZW50OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIHN3aXRjaCAocGxhY2VtZW50KSB7XG4gICAgICBjYXNlICd0b3AtcmlnaHQnOlxuICAgICAgICByZXR1cm4gJ3RvcC0wIHJpZ2h0LTAnO1xuICAgICAgY2FzZSAndG9wLWxlZnQnOlxuICAgICAgICByZXR1cm4gJ3RvcC0wIGxlZnQtMCc7XG4gICAgICBjYXNlICdib3R0b20tcmlnaHQnOlxuICAgICAgICByZXR1cm4gJ2JvdHRvbS0wIHJpZ2h0LTAnO1xuICAgICAgY2FzZSAnYm90dG9tLWxlZnQnOlxuICAgICAgICByZXR1cm4gJ2JvdHRvbS0wIGxlZnQtMCc7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICByZXR1cm4gJ3RvcC0wIGxlZnQtMCc7XG4gICAgfVxuICB9XG59XG4iXX0=