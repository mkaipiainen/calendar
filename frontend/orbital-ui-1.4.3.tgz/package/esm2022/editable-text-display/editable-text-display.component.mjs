import { ChangeDetectionStrategy, Component, EventEmitter, Inject, Input, Output, signal, ViewChild, } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { OuiInputComponent } from 'orbital-ui/input';
import { OuiIconButtonComponent } from 'orbital-ui/icon-button';
import * as i0 from "@angular/core";
/**
 * Component to enable having a text that's display normally, but that can be toggled to be editable
 * by clicking on a button. The edit can then be either canceled or accepted.
 *
 *   Example use:
 *
 *   <oui-editable-text-display [(model)]="myText"></oui-editable-text-display>
 */
export class OuiEditableTextDisplayComponent {
    document;
    placeholderElement;
    textInput;
    set options(options) {
        this.optionsSignal.set({
            ...this.defaultOptions,
            ...options
        });
    }
    ;
    /**
     * A placeholder to be shown if there's no text
     */
    placeholder;
    /**
     *   The text to be shown
     */
    model;
    /**
     *   Whether or not the text-field is currently being edited
     */
    isEditing = false;
    /**
     *  Whether or not the text-field should size to the content
     */
    sizeToContent = false;
    /**
     *   Event that's emitted when the text is edited
     */
    modelChange = new EventEmitter();
    textDisplay;
    originalModel;
    defaultOptions = {
        placeholder: '',
        sizeToContent: false,
        maxLength: undefined
    };
    optionsSignal = signal({
        ...this.defaultOptions
    });
    iconOptions = {
        strokeColor: 'oui-editable-text-display-edit-icon-color',
        fillColor: 'oui-editable-text-display-edit-icon-color',
        size: 'oui-editable-text-display-edit-icon-size',
    };
    fontSize = '1.6rem';
    constructor(document) {
        this.document = document;
    }
    onModelChange(model) {
        this.model = model;
    }
    submitEdit() {
        this.stopEditing();
        this.originalModel = this.model;
        this.modelChange.emit(this.model);
    }
    cancelEdit() {
        this.stopEditing();
        this.model = this.originalModel;
    }
    stopEditing() {
        this.isEditing = false;
        this.textDisplay.nativeElement.style.width = 'auto';
        this.textDisplay.nativeElement.style.minWidth = 'auto';
    }
    startEdit() {
        if (!this.optionsSignal().sizeToContent) {
            this.textDisplay.nativeElement.style.width =
                this.textDisplay.nativeElement.getBoundingClientRect().width + 'px';
        }
        else {
            this.textDisplay.nativeElement.style.minWidth =
                this.textDisplay.nativeElement.getBoundingClientRect().width + 'px';
        }
        this.isEditing = true;
        setTimeout(() => {
            this.textInput.inputElement.nativeElement.focus();
        });
    }
    ngAfterViewInit() {
        this.originalModel = this.model;
        this.fontSize = getComputedStyle(this.document.documentElement).getPropertyValue(`--oui-editable-text-display-font-size`);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiEditableTextDisplayComponent, deps: [{ token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiEditableTextDisplayComponent, isStandalone: true, selector: "oui-editable-text-display", inputs: { options: "options", placeholder: "placeholder", model: "model", isEditing: "isEditing", sizeToContent: "sizeToContent" }, outputs: { modelChange: "modelChange" }, viewQueries: [{ propertyName: "placeholderElement", first: true, predicate: ["placeholderElement"], descendants: true }, { propertyName: "textInput", first: true, predicate: ["textInput"], descendants: true }, { propertyName: "textDisplay", first: true, predicate: ["textDisplay"], descendants: true }], ngImport: i0, template: "<div class=\"editable-text-display-container\">\n  <div class=\"text\" #textDisplay>\n    @if (!isEditing && !model && optionsSignal().placeholder) {\n      <span\n        (click)=\"startEdit()\"\n        #placeholderElement\n        class=\"text-display placeholder\"\n        >{{ optionsSignal().placeholder }}</span\n        >\n      }\n      @if (!isEditing) {\n        <span (click)=\"startEdit()\" class=\"text-display\">{{\n          model\n        }}</span>\n      }\n      @if (isEditing) {\n        <oui-input\n          #textInput\n      [options]=\"{\n        fontSize: fontSize,\n        variant: 'underlined',\n        sizeToContent: optionsSignal().sizeToContent,\n        noPadding: true,\n      }\"\n          [model]=\"model\"\n          (modelChange)=\"onModelChange($event)\"\n        ></oui-input>\n      }\n    </div>\n    <div class=\"actions\">\n      @if (!isEditing) {\n        <oui-icon-button\n          [options]=\"iconOptions\"\n          (onClick)=\"startEdit()\"\n          icon=\"assets/icons/edit.svg\"\n        ></oui-icon-button>\n      }\n      @if (isEditing) {\n        <oui-icon-button\n      [options]=\"{\n        strokeColor: 'color-success',\n        fillColor: 'color-success',\n        size: iconOptions.size,\n        height: iconOptions.height,\n        width: iconOptions.width\n      }\"\n          color=\"transparent\"\n          (onClick)=\"submitEdit()\"\n          icon=\"assets/icons/check.svg\"\n        ></oui-icon-button>\n      }\n      @if (isEditing) {\n        <oui-icon-button\n      [options]=\"{\n        strokeColor: 'color-danger',\n        fillColor: 'color-danger',\n        size: iconOptions.size,\n        height: iconOptions.height,\n        width: iconOptions.width\n      }\"\n          color=\"transparent\"\n          (onClick)=\"cancelEdit()\"\n          icon=\"assets/icons/close.svg\"\n        ></oui-icon-button>\n      }\n    </div>\n  </div>\n", styles: [":host{min-height:3rem;--oui-input-underline-color: var(--oui-editable-text-display-underline-color);--oui-icon-button-background-color: var( --oui-editable-text-display-edit-icon-background );--oui-icon-button-background-color-hover: var( --oui-editable-text-display-edit-icon-background-hover )}:host .editable-text-display-container{display:flex;align-items:center}:host .editable-text-display-container .text-display{color:var(--oui-editable-text-display-text-color)}:host .editable-text-display-container .text{min-height:3rem;font-size:var(--font-size-body-regular);min-width:1rem;width:100%;margin-right:1rem;display:flex;color:var(--oui-editable-text-display-text-color);align-items:center}:host .editable-text-display-container .text:hover{cursor:pointer}:host .editable-text-display-container .text oui-input{min-height:3rem;height:100%;width:100%}:host .editable-text-display-container .text .text-display{font-size:var(--oui-editable-text-display-font-size);color:var(--oui-editable-text-display-text-color);align-items:center;display:flex;margin-right:1rem}:host .editable-text-display-container .text .text-display.placeholder{color:var(--oui-editable-text-display-placeholder-color)}:host .editable-text-display-container .actions{display:flex;align-items:center;justify-content:center;height:100%}\n"], dependencies: [{ kind: "component", type: OuiInputComponent, selector: "oui-input", inputs: ["model", "options"], outputs: ["modelChange", "hasErrorChange"] }, { kind: "component", type: OuiIconButtonComponent, selector: "oui-icon-button", inputs: ["icon", "isLoading", "options"], outputs: ["onClick"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiEditableTextDisplayComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-editable-text-display', standalone: true, imports: [OuiInputComponent, OuiIconButtonComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"editable-text-display-container\">\n  <div class=\"text\" #textDisplay>\n    @if (!isEditing && !model && optionsSignal().placeholder) {\n      <span\n        (click)=\"startEdit()\"\n        #placeholderElement\n        class=\"text-display placeholder\"\n        >{{ optionsSignal().placeholder }}</span\n        >\n      }\n      @if (!isEditing) {\n        <span (click)=\"startEdit()\" class=\"text-display\">{{\n          model\n        }}</span>\n      }\n      @if (isEditing) {\n        <oui-input\n          #textInput\n      [options]=\"{\n        fontSize: fontSize,\n        variant: 'underlined',\n        sizeToContent: optionsSignal().sizeToContent,\n        noPadding: true,\n      }\"\n          [model]=\"model\"\n          (modelChange)=\"onModelChange($event)\"\n        ></oui-input>\n      }\n    </div>\n    <div class=\"actions\">\n      @if (!isEditing) {\n        <oui-icon-button\n          [options]=\"iconOptions\"\n          (onClick)=\"startEdit()\"\n          icon=\"assets/icons/edit.svg\"\n        ></oui-icon-button>\n      }\n      @if (isEditing) {\n        <oui-icon-button\n      [options]=\"{\n        strokeColor: 'color-success',\n        fillColor: 'color-success',\n        size: iconOptions.size,\n        height: iconOptions.height,\n        width: iconOptions.width\n      }\"\n          color=\"transparent\"\n          (onClick)=\"submitEdit()\"\n          icon=\"assets/icons/check.svg\"\n        ></oui-icon-button>\n      }\n      @if (isEditing) {\n        <oui-icon-button\n      [options]=\"{\n        strokeColor: 'color-danger',\n        fillColor: 'color-danger',\n        size: iconOptions.size,\n        height: iconOptions.height,\n        width: iconOptions.width\n      }\"\n          color=\"transparent\"\n          (onClick)=\"cancelEdit()\"\n          icon=\"assets/icons/close.svg\"\n        ></oui-icon-button>\n      }\n    </div>\n  </div>\n", styles: [":host{min-height:3rem;--oui-input-underline-color: var(--oui-editable-text-display-underline-color);--oui-icon-button-background-color: var( --oui-editable-text-display-edit-icon-background );--oui-icon-button-background-color-hover: var( --oui-editable-text-display-edit-icon-background-hover )}:host .editable-text-display-container{display:flex;align-items:center}:host .editable-text-display-container .text-display{color:var(--oui-editable-text-display-text-color)}:host .editable-text-display-container .text{min-height:3rem;font-size:var(--font-size-body-regular);min-width:1rem;width:100%;margin-right:1rem;display:flex;color:var(--oui-editable-text-display-text-color);align-items:center}:host .editable-text-display-container .text:hover{cursor:pointer}:host .editable-text-display-container .text oui-input{min-height:3rem;height:100%;width:100%}:host .editable-text-display-container .text .text-display{font-size:var(--oui-editable-text-display-font-size);color:var(--oui-editable-text-display-text-color);align-items:center;display:flex;margin-right:1rem}:host .editable-text-display-container .text .text-display.placeholder{color:var(--oui-editable-text-display-placeholder-color)}:host .editable-text-display-container .actions{display:flex;align-items:center;justify-content:center;height:100%}\n"] }]
        }], ctorParameters: () => [{ type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { placeholderElement: [{
                type: ViewChild,
                args: ['placeholderElement']
            }], textInput: [{
                type: ViewChild,
                args: ['textInput']
            }], options: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], model: [{
                type: Input
            }], isEditing: [{
                type: Input
            }], sizeToContent: [{
                type: Input
            }], modelChange: [{
                type: Output
            }], textDisplay: [{
                type: ViewChild,
                args: ['textDisplay']
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZWRpdGFibGUtdGV4dC1kaXNwbGF5LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvZWRpdGFibGUtdGV4dC1kaXNwbGF5L2VkaXRhYmxlLXRleHQtZGlzcGxheS5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL2VkaXRhYmxlLXRleHQtZGlzcGxheS9lZGl0YWJsZS10ZXh0LWRpc3BsYXkuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUVMLHVCQUF1QixFQUN2QixTQUFTLEVBRVQsWUFBWSxFQUNaLE1BQU0sRUFDTixLQUFLLEVBQ0wsTUFBTSxFQUFFLE1BQU0sRUFDZCxTQUFTLEdBQ1YsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzNDLE9BQU8sRUFBbUIsaUJBQWlCLEVBQUMsTUFBTSxrQkFBa0IsQ0FBQztBQUNyRSxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQzs7QUFTaEU7Ozs7Ozs7R0FPRztBQVNILE1BQU0sT0FBTywrQkFBK0I7SUFzREo7SUFyREwsa0JBQWtCLENBQWE7SUFDeEMsU0FBUyxDQUFvQjtJQUVyRCxJQUFhLE9BQU8sQ0FBQyxPQUF1QztRQUMxRCxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQztZQUNyQixHQUFHLElBQUksQ0FBQyxjQUFjO1lBQ3RCLEdBQUcsT0FBTztTQUNYLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFBQSxDQUFDO0lBRUY7O09BRUc7SUFDTSxXQUFXLENBQVM7SUFFN0I7O09BRUc7SUFDTSxLQUFLLENBQVM7SUFFdkI7O09BRUc7SUFDTSxTQUFTLEdBQUcsS0FBSyxDQUFDO0lBRTNCOztPQUVHO0lBQ00sYUFBYSxHQUFHLEtBQUssQ0FBQztJQUUvQjs7T0FFRztJQUNPLFdBQVcsR0FBRyxJQUFJLFlBQVksRUFBVSxDQUFDO0lBRXpCLFdBQVcsQ0FBYTtJQUUxQyxhQUFhLENBQVM7SUFDdEIsY0FBYyxHQUFtQztRQUN2RCxXQUFXLEVBQUUsRUFBRTtRQUNmLGFBQWEsRUFBRSxLQUFLO1FBQ3BCLFNBQVMsRUFBRSxTQUFTO0tBQ3JCLENBQUE7SUFDTSxhQUFhLEdBQUcsTUFBTSxDQUFpQztRQUM1RCxHQUFHLElBQUksQ0FBQyxjQUFjO0tBQ3ZCLENBQUMsQ0FBQztJQUNJLFdBQVcsR0FBb0I7UUFDcEMsV0FBVyxFQUFFLDJDQUEyQztRQUN4RCxTQUFTLEVBQUUsMkNBQTJDO1FBQ3RELElBQUksRUFBRSwwQ0FBMEM7S0FDakQsQ0FBQztJQUNLLFFBQVEsR0FBRyxRQUFRLENBQUM7SUFFM0IsWUFBc0MsUUFBa0I7UUFBbEIsYUFBUSxHQUFSLFFBQVEsQ0FBVTtJQUFHLENBQUM7SUFFckQsYUFBYSxDQUFDLEtBQXNCO1FBQ3pDLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBZSxDQUFDO0lBQy9CLENBQUM7SUFFTSxVQUFVO1FBQ2YsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUNoQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVNLFVBQVU7UUFDZixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO0lBQ2xDLENBQUM7SUFFTSxXQUFXO1FBQ2hCLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO1FBQ3JCLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsTUFBTSxDQUFDO1FBQ3BELElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxRQUFRLEdBQUcsTUFBTSxDQUFDO0lBQzNELENBQUM7SUFFTSxTQUFTO1FBQ2QsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUN4QyxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsS0FBSztnQkFDeEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ3hFLENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLFFBQVE7Z0JBQzNDLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQztRQUN4RSxDQUFDO1FBQ0QsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFDdEIsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNwRCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxlQUFlO1FBQ3BCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUNoQyxJQUFJLENBQUMsUUFBUSxHQUFHLGdCQUFnQixDQUM5QixJQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FDOUIsQ0FBQyxnQkFBZ0IsQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDO0lBQzlELENBQUM7dUdBaEdVLCtCQUErQixrQkFzRHRCLFFBQVE7MkZBdERqQiwrQkFBK0Isa2pCQ3RDNUMsdzREQW1FQSw0MUNEaENZLGlCQUFpQixnSUFBRSxzQkFBc0I7OzJGQUd4QywrQkFBK0I7a0JBUjNDLFNBQVM7K0JBQ0UsMkJBQTJCLGNBR3pCLElBQUksV0FDUCxDQUFDLGlCQUFpQixFQUFFLHNCQUFzQixDQUFDLG1CQUNuQyx1QkFBdUIsQ0FBQyxNQUFNOzswQkF3RGxDLE1BQU07MkJBQUMsUUFBUTt5Q0FyREssa0JBQWtCO3NCQUFsRCxTQUFTO3VCQUFDLG9CQUFvQjtnQkFDUCxTQUFTO3NCQUFoQyxTQUFTO3VCQUFDLFdBQVc7Z0JBRVQsT0FBTztzQkFBbkIsS0FBSztnQkFVRyxXQUFXO3NCQUFuQixLQUFLO2dCQUtHLEtBQUs7c0JBQWIsS0FBSztnQkFLRyxTQUFTO3NCQUFqQixLQUFLO2dCQUtHLGFBQWE7c0JBQXJCLEtBQUs7Z0JBS0ksV0FBVztzQkFBcEIsTUFBTTtnQkFFbUIsV0FBVztzQkFBcEMsU0FBUzt1QkFBQyxhQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIENvbXBvbmVudCxcbiAgRWxlbWVudFJlZixcbiAgRXZlbnRFbWl0dGVyLFxuICBJbmplY3QsXG4gIElucHV0LFxuICBPdXRwdXQsIHNpZ25hbCxcbiAgVmlld0NoaWxkLFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IERPQ1VNRU5UIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7SU91aUlucHV0T3B0aW9ucywgT3VpSW5wdXRDb21wb25lbnR9IGZyb20gJ29yYml0YWwtdWkvaW5wdXQnO1xuaW1wb3J0IHsgT3VpSWNvbkJ1dHRvbkNvbXBvbmVudCB9IGZyb20gJ29yYml0YWwtdWkvaWNvbi1idXR0b24nO1xuaW1wb3J0IHsgSU91aUljb25PcHRpb25zIH0gZnJvbSAnb3JiaXRhbC11aS9pY29uJztcblxuXG5leHBvcnQgaW50ZXJmYWNlIElPdWlFZGl0YWJsZVRleHREaXNwbGF5T3B0aW9ucyB7XG4gIHBsYWNlaG9sZGVyPzogc3RyaW5nO1xuICBzaXplVG9Db250ZW50PzogYm9vbGVhbjtcbiAgbWF4TGVuZ3RoPzogbnVtYmVyO1xufVxuLyoqXG4gKiBDb21wb25lbnQgdG8gZW5hYmxlIGhhdmluZyBhIHRleHQgdGhhdCdzIGRpc3BsYXkgbm9ybWFsbHksIGJ1dCB0aGF0IGNhbiBiZSB0b2dnbGVkIHRvIGJlIGVkaXRhYmxlXG4gKiBieSBjbGlja2luZyBvbiBhIGJ1dHRvbi4gVGhlIGVkaXQgY2FuIHRoZW4gYmUgZWl0aGVyIGNhbmNlbGVkIG9yIGFjY2VwdGVkLlxuICpcbiAqICAgRXhhbXBsZSB1c2U6XG4gKlxuICogICA8b3VpLWVkaXRhYmxlLXRleHQtZGlzcGxheSBbKG1vZGVsKV09XCJteVRleHRcIj48L291aS1lZGl0YWJsZS10ZXh0LWRpc3BsYXk+XG4gKi9cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1lZGl0YWJsZS10ZXh0LWRpc3BsYXknLFxuICB0ZW1wbGF0ZVVybDogJy4vZWRpdGFibGUtdGV4dC1kaXNwbGF5LmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vZWRpdGFibGUtdGV4dC1kaXNwbGF5LmNvbXBvbmVudC5zY3NzJ10sXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtPdWlJbnB1dENvbXBvbmVudCwgT3VpSWNvbkJ1dHRvbkNvbXBvbmVudF0sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlFZGl0YWJsZVRleHREaXNwbGF5Q29tcG9uZW50IGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCB7XG4gIEBWaWV3Q2hpbGQoJ3BsYWNlaG9sZGVyRWxlbWVudCcpIHBsYWNlaG9sZGVyRWxlbWVudDogRWxlbWVudFJlZjtcbiAgQFZpZXdDaGlsZCgndGV4dElucHV0JykgdGV4dElucHV0OiBPdWlJbnB1dENvbXBvbmVudDtcblxuICBASW5wdXQoKSBzZXQgb3B0aW9ucyhvcHRpb25zOiBJT3VpRWRpdGFibGVUZXh0RGlzcGxheU9wdGlvbnMpIHtcbiAgICB0aGlzLm9wdGlvbnNTaWduYWwuc2V0KHtcbiAgICAgIC4uLnRoaXMuZGVmYXVsdE9wdGlvbnMsXG4gICAgICAuLi5vcHRpb25zXG4gICAgfSlcbiAgfTtcblxuICAvKipcbiAgICogQSBwbGFjZWhvbGRlciB0byBiZSBzaG93biBpZiB0aGVyZSdzIG5vIHRleHRcbiAgICovXG4gIEBJbnB1dCgpIHBsYWNlaG9sZGVyOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqICAgVGhlIHRleHQgdG8gYmUgc2hvd25cbiAgICovXG4gIEBJbnB1dCgpIG1vZGVsOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqICAgV2hldGhlciBvciBub3QgdGhlIHRleHQtZmllbGQgaXMgY3VycmVudGx5IGJlaW5nIGVkaXRlZFxuICAgKi9cbiAgQElucHV0KCkgaXNFZGl0aW5nID0gZmFsc2U7XG5cbiAgLyoqXG4gICAqICBXaGV0aGVyIG9yIG5vdCB0aGUgdGV4dC1maWVsZCBzaG91bGQgc2l6ZSB0byB0aGUgY29udGVudFxuICAgKi9cbiAgQElucHV0KCkgc2l6ZVRvQ29udGVudCA9IGZhbHNlO1xuXG4gIC8qKlxuICAgKiAgIEV2ZW50IHRoYXQncyBlbWl0dGVkIHdoZW4gdGhlIHRleHQgaXMgZWRpdGVkXG4gICAqL1xuICBAT3V0cHV0KCkgbW9kZWxDaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyPHN0cmluZz4oKTtcblxuICBAVmlld0NoaWxkKCd0ZXh0RGlzcGxheScpIHRleHREaXNwbGF5OiBFbGVtZW50UmVmO1xuXG4gIHByaXZhdGUgb3JpZ2luYWxNb2RlbDogc3RyaW5nO1xuICBwcml2YXRlIGRlZmF1bHRPcHRpb25zOiBJT3VpRWRpdGFibGVUZXh0RGlzcGxheU9wdGlvbnMgPSB7XG4gICAgcGxhY2Vob2xkZXI6ICcnLFxuICAgIHNpemVUb0NvbnRlbnQ6IGZhbHNlLFxuICAgIG1heExlbmd0aDogdW5kZWZpbmVkXG4gIH1cbiAgcHVibGljIG9wdGlvbnNTaWduYWwgPSBzaWduYWw8SU91aUVkaXRhYmxlVGV4dERpc3BsYXlPcHRpb25zPih7XG4gICAgLi4udGhpcy5kZWZhdWx0T3B0aW9uc1xuICB9KTtcbiAgcHVibGljIGljb25PcHRpb25zOiBJT3VpSWNvbk9wdGlvbnMgPSB7XG4gICAgc3Ryb2tlQ29sb3I6ICdvdWktZWRpdGFibGUtdGV4dC1kaXNwbGF5LWVkaXQtaWNvbi1jb2xvcicsXG4gICAgZmlsbENvbG9yOiAnb3VpLWVkaXRhYmxlLXRleHQtZGlzcGxheS1lZGl0LWljb24tY29sb3InLFxuICAgIHNpemU6ICdvdWktZWRpdGFibGUtdGV4dC1kaXNwbGF5LWVkaXQtaWNvbi1zaXplJyxcbiAgfTtcbiAgcHVibGljIGZvbnRTaXplID0gJzEuNnJlbSc7XG5cbiAgY29uc3RydWN0b3IoQEluamVjdChET0NVTUVOVCkgcHJpdmF0ZSBkb2N1bWVudDogRG9jdW1lbnQpIHt9XG5cbiAgcHVibGljIG9uTW9kZWxDaGFuZ2UobW9kZWw6IHN0cmluZyB8IG51bWJlcikge1xuICAgIHRoaXMubW9kZWwgPSBtb2RlbCBhcyBzdHJpbmc7XG4gIH1cblxuICBwdWJsaWMgc3VibWl0RWRpdCgpIHtcbiAgICB0aGlzLnN0b3BFZGl0aW5nKCk7XG4gICAgdGhpcy5vcmlnaW5hbE1vZGVsID0gdGhpcy5tb2RlbDtcbiAgICB0aGlzLm1vZGVsQ2hhbmdlLmVtaXQodGhpcy5tb2RlbCk7XG4gIH1cblxuICBwdWJsaWMgY2FuY2VsRWRpdCgpIHtcbiAgICB0aGlzLnN0b3BFZGl0aW5nKCk7XG4gICAgdGhpcy5tb2RlbCA9IHRoaXMub3JpZ2luYWxNb2RlbDtcbiAgfVxuXG4gIHB1YmxpYyBzdG9wRWRpdGluZygpIHtcbiAgICB0aGlzLmlzRWRpdGluZyA9IGZhbHNlO1xuICAgICAgdGhpcy50ZXh0RGlzcGxheS5uYXRpdmVFbGVtZW50LnN0eWxlLndpZHRoID0gJ2F1dG8nO1xuICAgICAgdGhpcy50ZXh0RGlzcGxheS5uYXRpdmVFbGVtZW50LnN0eWxlLm1pbldpZHRoID0gJ2F1dG8nO1xuICB9XG5cbiAgcHVibGljIHN0YXJ0RWRpdCgpIHtcbiAgICBpZiAoIXRoaXMub3B0aW9uc1NpZ25hbCgpLnNpemVUb0NvbnRlbnQpIHtcbiAgICAgIHRoaXMudGV4dERpc3BsYXkubmF0aXZlRWxlbWVudC5zdHlsZS53aWR0aCA9XG4gICAgICAgIHRoaXMudGV4dERpc3BsYXkubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCArICdweCc7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMudGV4dERpc3BsYXkubmF0aXZlRWxlbWVudC5zdHlsZS5taW5XaWR0aCA9XG4gICAgICAgIHRoaXMudGV4dERpc3BsYXkubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aCArICdweCc7XG4gICAgfVxuICAgIHRoaXMuaXNFZGl0aW5nID0gdHJ1ZTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRoaXMudGV4dElucHV0LmlucHV0RWxlbWVudC5uYXRpdmVFbGVtZW50LmZvY3VzKCk7XG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCkge1xuICAgIHRoaXMub3JpZ2luYWxNb2RlbCA9IHRoaXMubW9kZWw7XG4gICAgdGhpcy5mb250U2l6ZSA9IGdldENvbXB1dGVkU3R5bGUoXG4gICAgICB0aGlzLmRvY3VtZW50LmRvY3VtZW50RWxlbWVudFxuICAgICkuZ2V0UHJvcGVydHlWYWx1ZShgLS1vdWktZWRpdGFibGUtdGV4dC1kaXNwbGF5LWZvbnQtc2l6ZWApO1xuICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwiZWRpdGFibGUtdGV4dC1kaXNwbGF5LWNvbnRhaW5lclwiPlxuICA8ZGl2IGNsYXNzPVwidGV4dFwiICN0ZXh0RGlzcGxheT5cbiAgICBAaWYgKCFpc0VkaXRpbmcgJiYgIW1vZGVsICYmIG9wdGlvbnNTaWduYWwoKS5wbGFjZWhvbGRlcikge1xuICAgICAgPHNwYW5cbiAgICAgICAgKGNsaWNrKT1cInN0YXJ0RWRpdCgpXCJcbiAgICAgICAgI3BsYWNlaG9sZGVyRWxlbWVudFxuICAgICAgICBjbGFzcz1cInRleHQtZGlzcGxheSBwbGFjZWhvbGRlclwiXG4gICAgICAgID57eyBvcHRpb25zU2lnbmFsKCkucGxhY2Vob2xkZXIgfX08L3NwYW5cbiAgICAgICAgPlxuICAgICAgfVxuICAgICAgQGlmICghaXNFZGl0aW5nKSB7XG4gICAgICAgIDxzcGFuIChjbGljayk9XCJzdGFydEVkaXQoKVwiIGNsYXNzPVwidGV4dC1kaXNwbGF5XCI+e3tcbiAgICAgICAgICBtb2RlbFxuICAgICAgICB9fTwvc3Bhbj5cbiAgICAgIH1cbiAgICAgIEBpZiAoaXNFZGl0aW5nKSB7XG4gICAgICAgIDxvdWktaW5wdXRcbiAgICAgICAgICAjdGV4dElucHV0XG4gICAgICBbb3B0aW9uc109XCJ7XG4gICAgICAgIGZvbnRTaXplOiBmb250U2l6ZSxcbiAgICAgICAgdmFyaWFudDogJ3VuZGVybGluZWQnLFxuICAgICAgICBzaXplVG9Db250ZW50OiBvcHRpb25zU2lnbmFsKCkuc2l6ZVRvQ29udGVudCxcbiAgICAgICAgbm9QYWRkaW5nOiB0cnVlLFxuICAgICAgfVwiXG4gICAgICAgICAgW21vZGVsXT1cIm1vZGVsXCJcbiAgICAgICAgICAobW9kZWxDaGFuZ2UpPVwib25Nb2RlbENoYW5nZSgkZXZlbnQpXCJcbiAgICAgICAgPjwvb3VpLWlucHV0PlxuICAgICAgfVxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJhY3Rpb25zXCI+XG4gICAgICBAaWYgKCFpc0VkaXRpbmcpIHtcbiAgICAgICAgPG91aS1pY29uLWJ1dHRvblxuICAgICAgICAgIFtvcHRpb25zXT1cImljb25PcHRpb25zXCJcbiAgICAgICAgICAob25DbGljayk9XCJzdGFydEVkaXQoKVwiXG4gICAgICAgICAgaWNvbj1cImFzc2V0cy9pY29ucy9lZGl0LnN2Z1wiXG4gICAgICAgID48L291aS1pY29uLWJ1dHRvbj5cbiAgICAgIH1cbiAgICAgIEBpZiAoaXNFZGl0aW5nKSB7XG4gICAgICAgIDxvdWktaWNvbi1idXR0b25cbiAgICAgIFtvcHRpb25zXT1cIntcbiAgICAgICAgc3Ryb2tlQ29sb3I6ICdjb2xvci1zdWNjZXNzJyxcbiAgICAgICAgZmlsbENvbG9yOiAnY29sb3Itc3VjY2VzcycsXG4gICAgICAgIHNpemU6IGljb25PcHRpb25zLnNpemUsXG4gICAgICAgIGhlaWdodDogaWNvbk9wdGlvbnMuaGVpZ2h0LFxuICAgICAgICB3aWR0aDogaWNvbk9wdGlvbnMud2lkdGhcbiAgICAgIH1cIlxuICAgICAgICAgIGNvbG9yPVwidHJhbnNwYXJlbnRcIlxuICAgICAgICAgIChvbkNsaWNrKT1cInN1Ym1pdEVkaXQoKVwiXG4gICAgICAgICAgaWNvbj1cImFzc2V0cy9pY29ucy9jaGVjay5zdmdcIlxuICAgICAgICA+PC9vdWktaWNvbi1idXR0b24+XG4gICAgICB9XG4gICAgICBAaWYgKGlzRWRpdGluZykge1xuICAgICAgICA8b3VpLWljb24tYnV0dG9uXG4gICAgICBbb3B0aW9uc109XCJ7XG4gICAgICAgIHN0cm9rZUNvbG9yOiAnY29sb3ItZGFuZ2VyJyxcbiAgICAgICAgZmlsbENvbG9yOiAnY29sb3ItZGFuZ2VyJyxcbiAgICAgICAgc2l6ZTogaWNvbk9wdGlvbnMuc2l6ZSxcbiAgICAgICAgaGVpZ2h0OiBpY29uT3B0aW9ucy5oZWlnaHQsXG4gICAgICAgIHdpZHRoOiBpY29uT3B0aW9ucy53aWR0aFxuICAgICAgfVwiXG4gICAgICAgICAgY29sb3I9XCJ0cmFuc3BhcmVudFwiXG4gICAgICAgICAgKG9uQ2xpY2spPVwiY2FuY2VsRWRpdCgpXCJcbiAgICAgICAgICBpY29uPVwiYXNzZXRzL2ljb25zL2Nsb3NlLnN2Z1wiXG4gICAgICAgID48L291aS1pY29uLWJ1dHRvbj5cbiAgICAgIH1cbiAgICA8L2Rpdj5cbiAgPC9kaXY+XG4iXX0=