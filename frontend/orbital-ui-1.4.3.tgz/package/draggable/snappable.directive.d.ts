import { AfterViewInit, ElementRef, OnDestroy } from '@angular/core';
import { OuiDraggableService } from './draggable.service';
import * as i0 from "@angular/core";
export declare class OuiSnappableDirective implements AfterViewInit, OnDestroy {
    private draggableService;
    private elementRef;
    ouiSnappable: string;
    constructor(draggableService: OuiDraggableService, elementRef: ElementRef);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiSnappableDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OuiSnappableDirective, "[ouiSnappable]", never, { "ouiSnappable": { "alias": "ouiSnappable"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=snappable.directive.d.ts.map