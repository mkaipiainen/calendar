import { OuiMainSidebarSectionOptions } from '../main-sidebar.service';
import { OuiMainSidebarRouteSectionOptions } from '../main-sidebar-route-section/main-sidebar-route-section.component';
import { OuiMainSidebarActionSectionOptions } from '../main-sidebar-action-section/main-sidebar-action-section.component';
import { OuiMainSidebarSubsectionOptions } from '../main-sidebar-sub-section/main-sidebar-sub-section.component';
import * as i0 from "@angular/core";
export declare class IsRouteSectionOptionsPipe {
    transform(value: OuiMainSidebarSectionOptions): value is OuiMainSidebarRouteSectionOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<IsRouteSectionOptionsPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<IsRouteSectionOptionsPipe, "isRouteSectionOptions", true>;
}
export declare class IsActionSectionOptionsPipe {
    transform(value: OuiMainSidebarSectionOptions): value is OuiMainSidebarActionSectionOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<IsActionSectionOptionsPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<IsActionSectionOptionsPipe, "isActionSectionOptions", true>;
}
export declare class IsSubSectionOptionsPipe {
    transform(value: OuiMainSidebarSectionOptions): value is OuiMainSidebarSubsectionOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<IsSubSectionOptionsPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<IsSubSectionOptionsPipe, "isSubsectionOptions", true>;
}
//# sourceMappingURL=sections.type-guard.d.ts.map