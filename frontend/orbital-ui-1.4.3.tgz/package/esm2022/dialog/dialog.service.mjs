import { Inject, Injectable, } from '@angular/core';
import { fromEvent, Subject } from 'rxjs';
import { NavigationStart } from '@angular/router';
import { DOCUMENT } from '@angular/common';
import { GUID } from 'orbital-ui/helpers';
import { ComponentCreator } from 'orbital-ui/helpers';
import * as i0 from "@angular/core";
import * as i1 from "@angular/router";
/**
 * This service can be used to open dialogs. You can pass in a custom dialog, which will be inserted
 * into the DOM and opened. You can call dialogService.submitDialog or dialogService.cancelDialog to easily close or open the dialog.
 * Alternatively, you can pass the option closeOnEscape to automatically close the dialog when the escape key is pressed.
 *
 * When creating new components, the workflow is as follows:
 *  - Create a component extended from OuiDialogComponent
 *  - Open the component using the openDialog() method
 *  - The openDialog returns an observable you can subscribe to in order to get the result of the dialog
 *
 *
 * Example:
 *
 * ouiDialogService.openDialog(StConfirmDialogComponent, {title: 'This is an example title'}, {closeOnEscape: true}).subscribe((result) => {
 *   if(result.confirm) {
 *     // User confirmed the dialog, do something
 *   } else {
 *     // User canceled the dialog, do something else
 *   }
 * });
 */
export class OuiDialogService {
    router;
    zone;
    appRef;
    injector;
    rendererFactory;
    document;
    overlay;
    wrapper;
    openDialogs = {};
    renderer;
    constructor(router, zone, appRef, injector, rendererFactory, document) {
        this.router = router;
        this.zone = zone;
        this.appRef = appRef;
        this.injector = injector;
        this.rendererFactory = rendererFactory;
        this.document = document;
        this.renderer = rendererFactory.createRenderer(null, null);
        this.wrapper = this.renderer.createElement('div');
        this.overlay = this.renderer.createElement('div');
        this.renderer.addClass(this.wrapper, 'oui-dialog-wrapper');
        this.renderer.addClass(this.wrapper, 'hide');
        this.renderer.addClass(this.overlay, 'oui-dialog-overlay');
        this.renderer.appendChild(this.wrapper, this.overlay);
        this.renderer.appendChild(this.document.body, this.wrapper);
        fromEvent(this.overlay, 'click').subscribe((event) => {
            for (let dialog of Object.values(this.openDialogs)) {
                if (dialog.options.closeOnOutsideClick) {
                    this.cancelDialog(dialog.id, {});
                }
            }
        });
        this.router.events.subscribe(val => {
            if (val instanceof NavigationStart) {
                this.destroyDialogs();
            }
        });
        fromEvent(this.document, 'keyup').subscribe((event) => {
            if (event.key === 'Escape') {
                this.onEscapePress();
            }
        });
    }
    onEscapePress() {
        for (const id in this.openDialogs) {
            if (this.openDialogs[id].options.closeOnEscape) {
                this.cancelDialog(id, {});
            }
        }
    }
    destroyDialogs() {
        for (const id in this.openDialogs) {
            this.doDispose(id);
        }
    }
    /**
     * Opens a dialog with the given content and options. The content can be any component, which will be inserted into the DOM.
     * @param content The component to be used for the dialog
     * @param inputs A javascript object of inputs to be passed to the component
     * @param options Options for the dialog. See IDialogOptions for more information.
     */
    openDialog(content, inputs, options = {}) {
        const id = options.id ?? GUID();
        const subject = new Subject();
        const dialog = this.renderer.createElement('div');
        dialog.id = id;
        this.renderer.addClass(dialog, 'oui-dialog');
        if (options.classList?.length) {
            for (const className of options.classList) {
                this.renderer.addClass(dialog, className);
            }
        }
        const createComponentOptions = {
            component: content,
            parentElement: dialog,
            appRef: this.appRef,
            createComponentOptions: {
                environmentInjector: this.injector,
            },
            inputs: inputs,
        };
        const componentRef = ComponentCreator.createComponent(createComponentOptions);
        this.renderer.appendChild(this.wrapper, dialog);
        this.openDialogs[id] = {
            dialogElement: dialog,
            componentRef: componentRef,
            id: id,
            options: options,
            subject,
        };
        componentRef.instance.id = id;
        setTimeout(() => {
            this.renderer.removeClass(this.wrapper, 'hide');
            this.renderer.addClass(dialog, 'open');
            setTimeout(() => {
                this.renderer.addClass(this.wrapper, 'open');
                this.renderer.addClass(dialog, 'open');
            }, 50);
        });
        return subject.asObservable();
    }
    submitDialog(id, data) {
        if (this.openDialogs[id]) {
            this.openDialogs[id].subject.next({
                confirm: true,
                data: data ?? {},
            });
            this.dispose(id);
        }
    }
    cancelDialog(id, data) {
        if (this.openDialogs[id]) {
            this.openDialogs[id].subject.next({
                confirm: false,
                data: data ?? {},
            });
            this.dispose(id);
        }
    }
    dispose(id) {
        if (this.openDialogs?.[id]) {
            this.doDispose(id);
        }
    }
    doDispose(id) {
        this.renderer.removeClass(this.openDialogs[id].dialogElement, 'open');
        const componentRef = this.openDialogs[id].componentRef;
        this.openDialogs[id].subject.complete();
        delete this.openDialogs[id];
        if (Object.keys(this.openDialogs).length === 0) {
            this.renderer.removeClass(this.wrapper, 'open');
            setTimeout(() => {
                this.renderer.addClass(this.wrapper, 'hide');
            }, 300);
        }
        setTimeout(() => {
            componentRef.destroy();
            this.appRef.detachView(componentRef.hostView);
        }, 300);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDialogService, deps: [{ token: i1.Router }, { token: i0.NgZone }, { token: i0.ApplicationRef }, { token: i0.EnvironmentInjector }, { token: i0.RendererFactory2 }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDialogService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDialogService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.Router }, { type: i0.NgZone }, { type: i0.ApplicationRef }, { type: i0.EnvironmentInjector }, { type: i0.RendererFactory2 }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGlhbG9nLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL2RpYWxvZy9kaWFsb2cuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBR0wsTUFBTSxFQUNOLFVBQVUsR0FJWCxNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsU0FBUyxFQUFjLE9BQU8sRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUN0RCxPQUFPLEVBQUUsZUFBZSxFQUFVLE1BQU0saUJBQWlCLENBQUM7QUFFMUQsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBRTNDLE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUMxQyxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQzs7O0FBc0J0RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FvQkc7QUFLSCxNQUFNLE9BQU8sZ0JBQWdCO0lBU2pCO0lBQ0E7SUFDQTtJQUNBO0lBQ0E7SUFDa0I7SUFicEIsT0FBTyxDQUFjO0lBQ3JCLE9BQU8sQ0FBYztJQUNyQixXQUFXLEdBRWYsRUFBRSxDQUFDO0lBQ0MsUUFBUSxDQUFZO0lBRTVCLFlBQ1UsTUFBYyxFQUNkLElBQVksRUFDWixNQUFzQixFQUN0QixRQUE2QixFQUM3QixlQUFpQyxFQUNmLFFBQWtCO1FBTHBDLFdBQU0sR0FBTixNQUFNLENBQVE7UUFDZCxTQUFJLEdBQUosSUFBSSxDQUFRO1FBQ1osV0FBTSxHQUFOLE1BQU0sQ0FBZ0I7UUFDdEIsYUFBUSxHQUFSLFFBQVEsQ0FBcUI7UUFDN0Isb0JBQWUsR0FBZixlQUFlLENBQWtCO1FBQ2YsYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUU1QyxJQUFJLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNsRCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLG9CQUFvQixDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLG9CQUFvQixDQUFDLENBQUM7UUFDM0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRTVELFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQVksRUFBRSxFQUFFO1lBQzFELEtBQUssSUFBSSxNQUFNLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztnQkFDbkQsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLG1CQUFtQixFQUFFLENBQUM7b0JBQ3ZDLElBQUksQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNqQyxJQUFJLEdBQUcsWUFBWSxlQUFlLEVBQUUsQ0FBQztnQkFDbkMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3hCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQ3pELElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxRQUFRLEVBQUUsQ0FBQztnQkFDM0IsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3ZCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxhQUFhO1FBQ2xCLEtBQUssTUFBTSxFQUFFLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ2xDLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQy9DLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1lBQzVCLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVNLGNBQWM7UUFDbkIsS0FBSyxNQUFNLEVBQUUsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDbEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNyQixDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7OztPQUtHO0lBQ0ksVUFBVSxDQUNmLE9BQXlCLEVBQ3pCLE1BQWdDLEVBQ2hDLFVBQTBCLEVBQUU7UUFFNUIsTUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFDLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUNoQyxNQUFNLE9BQU8sR0FBRyxJQUFJLE9BQU8sRUFBa0IsQ0FBQztRQUU5QyxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNsRCxNQUFNLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQztRQUNmLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxZQUFZLENBQUMsQ0FBQztRQUM3QyxJQUFJLE9BQU8sQ0FBQyxTQUFTLEVBQUUsTUFBTSxFQUFFLENBQUM7WUFDOUIsS0FBSyxNQUFNLFNBQVMsSUFBSSxPQUFPLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQzFDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsQ0FBQztZQUM1QyxDQUFDO1FBQ0gsQ0FBQztRQUNELE1BQU0sc0JBQXNCLEdBQUc7WUFDN0IsU0FBUyxFQUFFLE9BQU87WUFDbEIsYUFBYSxFQUFFLE1BQU07WUFDckIsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ25CLHNCQUFzQixFQUFFO2dCQUN0QixtQkFBbUIsRUFBRSxJQUFJLENBQUMsUUFBUTthQUNuQztZQUNELE1BQU0sRUFBRSxNQUFNO1NBQ2YsQ0FBQztRQUNGLE1BQU0sWUFBWSxHQUFHLGdCQUFnQixDQUFDLGVBQWUsQ0FDbkQsc0JBQXNCLENBQ3ZCLENBQUM7UUFDRixJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ2hELElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLEdBQUc7WUFDckIsYUFBYSxFQUFFLE1BQU07WUFDckIsWUFBWSxFQUFFLFlBQVk7WUFDMUIsRUFBRSxFQUFFLEVBQUU7WUFDTixPQUFPLEVBQUUsT0FBTztZQUNoQixPQUFPO1NBQ1IsQ0FBQztRQUNGLFlBQVksQ0FBQyxRQUFRLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQztRQUM5QixVQUFVLENBQUMsR0FBRyxFQUFFO1lBQ2QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztZQUNoRCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDdkMsVUFBVSxDQUFDLEdBQUcsRUFBRTtnQkFDZCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUM3QyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDekMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ1QsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPLE9BQU8sQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUNoQyxDQUFDO0lBRU0sWUFBWSxDQUFDLEVBQVUsRUFBRSxJQUFTO1FBQ3ZDLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztnQkFDaEMsT0FBTyxFQUFFLElBQUk7Z0JBQ2IsSUFBSSxFQUFFLElBQUksSUFBSSxFQUFFO2FBQ2pCLENBQUMsQ0FBQztZQUNILElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDbkIsQ0FBQztJQUNILENBQUM7SUFFTSxZQUFZLENBQUMsRUFBVSxFQUFFLElBQVM7UUFDdkMsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO2dCQUNoQyxPQUFPLEVBQUUsS0FBSztnQkFDZCxJQUFJLEVBQUUsSUFBSSxJQUFJLEVBQUU7YUFDakIsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNuQixDQUFDO0lBQ0gsQ0FBQztJQUVNLE9BQU8sQ0FBQyxFQUFVO1FBQ3ZCLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7WUFDM0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNyQixDQUFDO0lBQ0gsQ0FBQztJQUVPLFNBQVMsQ0FBQyxFQUFVO1FBQzFCLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3RFLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDO1FBQ3ZELElBQUksQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3hDLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUM1QixJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUMvQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBQ2hELFVBQVUsQ0FBQyxHQUFHLEVBQUU7Z0JBQ2QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQztZQUMvQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDVixDQUFDO1FBQ0QsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNkLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUN2QixJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDaEQsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ1YsQ0FBQzt1R0EzSlUsZ0JBQWdCLCtKQWNqQixRQUFROzJHQWRQLGdCQUFnQixjQUZmLE1BQU07OzJGQUVQLGdCQUFnQjtrQkFINUIsVUFBVTttQkFBQztvQkFDVixVQUFVLEVBQUUsTUFBTTtpQkFDbkI7OzBCQWVJLE1BQU07MkJBQUMsUUFBUSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFwcGxpY2F0aW9uUmVmLFxuICBFbnZpcm9ubWVudEluamVjdG9yLFxuICBJbmplY3QsXG4gIEluamVjdGFibGUsXG4gIE5nWm9uZSxcbiAgUmVuZGVyZXIyLFxuICBSZW5kZXJlckZhY3RvcnkyLFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGZyb21FdmVudCwgT2JzZXJ2YWJsZSwgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgTmF2aWdhdGlvblN0YXJ0LCBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgQ29tcG9uZW50VHlwZSB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9vdmVybGF5JztcbmltcG9ydCB7IERPQ1VNRU5UIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IE91aURpYWxvZ0NvbXBvbmVudCB9IGZyb20gJy4vZGlhbG9nLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBHVUlEIH0gZnJvbSAnb3JiaXRhbC11aS9oZWxwZXJzJztcbmltcG9ydCB7IENvbXBvbmVudENyZWF0b3IgfSBmcm9tICdvcmJpdGFsLXVpL2hlbHBlcnMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIElEaWFsb2dPcHRpb25zIHtcbiAgaWQ/OiBzdHJpbmc7XG4gIGNsb3NlT25Fc2NhcGU/OiBib29sZWFuO1xuICBjbGFzc0xpc3Q/OiBzdHJpbmdbXTtcbiAgY2xvc2VPbk91dHNpZGVDbGljaz86IGJvb2xlYW47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSURpYWxvZyB7XG4gIGRpYWxvZ0VsZW1lbnQ6IEhUTUxFbGVtZW50O1xuICBjb21wb25lbnRSZWY6IGFueTtcbiAgaWQ6IHN0cmluZztcbiAgc3ViamVjdDogU3ViamVjdDxJRGlhbG9nU3ViamVjdD47XG4gIG9wdGlvbnM6IElEaWFsb2dPcHRpb25zO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElEaWFsb2dTdWJqZWN0IHtcbiAgY29uZmlybTogYm9vbGVhbjtcbiAgZGF0YTogYW55O1xufVxuXG4vKipcbiAqIFRoaXMgc2VydmljZSBjYW4gYmUgdXNlZCB0byBvcGVuIGRpYWxvZ3MuIFlvdSBjYW4gcGFzcyBpbiBhIGN1c3RvbSBkaWFsb2csIHdoaWNoIHdpbGwgYmUgaW5zZXJ0ZWRcbiAqIGludG8gdGhlIERPTSBhbmQgb3BlbmVkLiBZb3UgY2FuIGNhbGwgZGlhbG9nU2VydmljZS5zdWJtaXREaWFsb2cgb3IgZGlhbG9nU2VydmljZS5jYW5jZWxEaWFsb2cgdG8gZWFzaWx5IGNsb3NlIG9yIG9wZW4gdGhlIGRpYWxvZy5cbiAqIEFsdGVybmF0aXZlbHksIHlvdSBjYW4gcGFzcyB0aGUgb3B0aW9uIGNsb3NlT25Fc2NhcGUgdG8gYXV0b21hdGljYWxseSBjbG9zZSB0aGUgZGlhbG9nIHdoZW4gdGhlIGVzY2FwZSBrZXkgaXMgcHJlc3NlZC5cbiAqXG4gKiBXaGVuIGNyZWF0aW5nIG5ldyBjb21wb25lbnRzLCB0aGUgd29ya2Zsb3cgaXMgYXMgZm9sbG93czpcbiAqICAtIENyZWF0ZSBhIGNvbXBvbmVudCBleHRlbmRlZCBmcm9tIE91aURpYWxvZ0NvbXBvbmVudFxuICogIC0gT3BlbiB0aGUgY29tcG9uZW50IHVzaW5nIHRoZSBvcGVuRGlhbG9nKCkgbWV0aG9kXG4gKiAgLSBUaGUgb3BlbkRpYWxvZyByZXR1cm5zIGFuIG9ic2VydmFibGUgeW91IGNhbiBzdWJzY3JpYmUgdG8gaW4gb3JkZXIgdG8gZ2V0IHRoZSByZXN1bHQgb2YgdGhlIGRpYWxvZ1xuICpcbiAqXG4gKiBFeGFtcGxlOlxuICpcbiAqIG91aURpYWxvZ1NlcnZpY2Uub3BlbkRpYWxvZyhTdENvbmZpcm1EaWFsb2dDb21wb25lbnQsIHt0aXRsZTogJ1RoaXMgaXMgYW4gZXhhbXBsZSB0aXRsZSd9LCB7Y2xvc2VPbkVzY2FwZTogdHJ1ZX0pLnN1YnNjcmliZSgocmVzdWx0KSA9PiB7XG4gKiAgIGlmKHJlc3VsdC5jb25maXJtKSB7XG4gKiAgICAgLy8gVXNlciBjb25maXJtZWQgdGhlIGRpYWxvZywgZG8gc29tZXRoaW5nXG4gKiAgIH0gZWxzZSB7XG4gKiAgICAgLy8gVXNlciBjYW5jZWxlZCB0aGUgZGlhbG9nLCBkbyBzb21ldGhpbmcgZWxzZVxuICogICB9XG4gKiB9KTtcbiAqL1xuXG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290Jyxcbn0pXG5leHBvcnQgY2xhc3MgT3VpRGlhbG9nU2VydmljZSB7XG4gIHByaXZhdGUgb3ZlcmxheTogSFRNTEVsZW1lbnQ7XG4gIHByaXZhdGUgd3JhcHBlcjogSFRNTEVsZW1lbnQ7XG4gIHByaXZhdGUgb3BlbkRpYWxvZ3M6IHtcbiAgICBbeDogc3RyaW5nXTogSURpYWxvZztcbiAgfSA9IHt9O1xuICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjI7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSByb3V0ZXI6IFJvdXRlcixcbiAgICBwcml2YXRlIHpvbmU6IE5nWm9uZSxcbiAgICBwcml2YXRlIGFwcFJlZjogQXBwbGljYXRpb25SZWYsXG4gICAgcHJpdmF0ZSBpbmplY3RvcjogRW52aXJvbm1lbnRJbmplY3RvcixcbiAgICBwcml2YXRlIHJlbmRlcmVyRmFjdG9yeTogUmVuZGVyZXJGYWN0b3J5MixcbiAgICBASW5qZWN0KERPQ1VNRU5UKSBwcml2YXRlIGRvY3VtZW50OiBEb2N1bWVudFxuICApIHtcbiAgICB0aGlzLnJlbmRlcmVyID0gcmVuZGVyZXJGYWN0b3J5LmNyZWF0ZVJlbmRlcmVyKG51bGwsIG51bGwpO1xuICAgIHRoaXMud3JhcHBlciA9IHRoaXMucmVuZGVyZXIuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgdGhpcy5vdmVybGF5ID0gdGhpcy5yZW5kZXJlci5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICB0aGlzLnJlbmRlcmVyLmFkZENsYXNzKHRoaXMud3JhcHBlciwgJ291aS1kaWFsb2ctd3JhcHBlcicpO1xuICAgIHRoaXMucmVuZGVyZXIuYWRkQ2xhc3ModGhpcy53cmFwcGVyLCAnaGlkZScpO1xuICAgIHRoaXMucmVuZGVyZXIuYWRkQ2xhc3ModGhpcy5vdmVybGF5LCAnb3VpLWRpYWxvZy1vdmVybGF5Jyk7XG4gICAgdGhpcy5yZW5kZXJlci5hcHBlbmRDaGlsZCh0aGlzLndyYXBwZXIsIHRoaXMub3ZlcmxheSk7XG4gICAgdGhpcy5yZW5kZXJlci5hcHBlbmRDaGlsZCh0aGlzLmRvY3VtZW50LmJvZHksIHRoaXMud3JhcHBlcik7XG5cbiAgICBmcm9tRXZlbnQodGhpcy5vdmVybGF5LCAnY2xpY2snKS5zdWJzY3JpYmUoKGV2ZW50OiBFdmVudCkgPT4ge1xuICAgICAgZm9yIChsZXQgZGlhbG9nIG9mIE9iamVjdC52YWx1ZXModGhpcy5vcGVuRGlhbG9ncykpIHtcbiAgICAgICAgaWYgKGRpYWxvZy5vcHRpb25zLmNsb3NlT25PdXRzaWRlQ2xpY2spIHtcbiAgICAgICAgICB0aGlzLmNhbmNlbERpYWxvZyhkaWFsb2cuaWQsIHt9KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuXG4gICAgdGhpcy5yb3V0ZXIuZXZlbnRzLnN1YnNjcmliZSh2YWwgPT4ge1xuICAgICAgaWYgKHZhbCBpbnN0YW5jZW9mIE5hdmlnYXRpb25TdGFydCkge1xuICAgICAgICB0aGlzLmRlc3Ryb3lEaWFsb2dzKCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBmcm9tRXZlbnQodGhpcy5kb2N1bWVudCwgJ2tleXVwJykuc3Vic2NyaWJlKChldmVudDogYW55KSA9PiB7XG4gICAgICBpZiAoZXZlbnQua2V5ID09PSAnRXNjYXBlJykge1xuICAgICAgICB0aGlzLm9uRXNjYXBlUHJlc3MoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIHB1YmxpYyBvbkVzY2FwZVByZXNzKCkge1xuICAgIGZvciAoY29uc3QgaWQgaW4gdGhpcy5vcGVuRGlhbG9ncykge1xuICAgICAgaWYgKHRoaXMub3BlbkRpYWxvZ3NbaWRdLm9wdGlvbnMuY2xvc2VPbkVzY2FwZSkge1xuICAgICAgICB0aGlzLmNhbmNlbERpYWxvZyhpZCwge30pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBkZXN0cm95RGlhbG9ncygpIHtcbiAgICBmb3IgKGNvbnN0IGlkIGluIHRoaXMub3BlbkRpYWxvZ3MpIHtcbiAgICAgIHRoaXMuZG9EaXNwb3NlKGlkKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogT3BlbnMgYSBkaWFsb2cgd2l0aCB0aGUgZ2l2ZW4gY29udGVudCBhbmQgb3B0aW9ucy4gVGhlIGNvbnRlbnQgY2FuIGJlIGFueSBjb21wb25lbnQsIHdoaWNoIHdpbGwgYmUgaW5zZXJ0ZWQgaW50byB0aGUgRE9NLlxuICAgKiBAcGFyYW0gY29udGVudCBUaGUgY29tcG9uZW50IHRvIGJlIHVzZWQgZm9yIHRoZSBkaWFsb2dcbiAgICogQHBhcmFtIGlucHV0cyBBIGphdmFzY3JpcHQgb2JqZWN0IG9mIGlucHV0cyB0byBiZSBwYXNzZWQgdG8gdGhlIGNvbXBvbmVudFxuICAgKiBAcGFyYW0gb3B0aW9ucyBPcHRpb25zIGZvciB0aGUgZGlhbG9nLiBTZWUgSURpYWxvZ09wdGlvbnMgZm9yIG1vcmUgaW5mb3JtYXRpb24uXG4gICAqL1xuICBwdWJsaWMgb3BlbkRpYWxvZzxUIGV4dGVuZHMgT3VpRGlhbG9nQ29tcG9uZW50PihcbiAgICBjb250ZW50OiBDb21wb25lbnRUeXBlPFQ+LFxuICAgIGlucHV0czogeyBbeDogc3RyaW5nXTogdW5rbm93biB9LFxuICAgIG9wdGlvbnM6IElEaWFsb2dPcHRpb25zID0ge31cbiAgKTogT2JzZXJ2YWJsZTxJRGlhbG9nU3ViamVjdD4ge1xuICAgIGNvbnN0IGlkID0gb3B0aW9ucy5pZCA/PyBHVUlEKCk7XG4gICAgY29uc3Qgc3ViamVjdCA9IG5ldyBTdWJqZWN0PElEaWFsb2dTdWJqZWN0PigpO1xuXG4gICAgY29uc3QgZGlhbG9nID0gdGhpcy5yZW5kZXJlci5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBkaWFsb2cuaWQgPSBpZDtcbiAgICB0aGlzLnJlbmRlcmVyLmFkZENsYXNzKGRpYWxvZywgJ291aS1kaWFsb2cnKTtcbiAgICBpZiAob3B0aW9ucy5jbGFzc0xpc3Q/Lmxlbmd0aCkge1xuICAgICAgZm9yIChjb25zdCBjbGFzc05hbWUgb2Ygb3B0aW9ucy5jbGFzc0xpc3QpIHtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5hZGRDbGFzcyhkaWFsb2csIGNsYXNzTmFtZSk7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGNyZWF0ZUNvbXBvbmVudE9wdGlvbnMgPSB7XG4gICAgICBjb21wb25lbnQ6IGNvbnRlbnQsXG4gICAgICBwYXJlbnRFbGVtZW50OiBkaWFsb2csXG4gICAgICBhcHBSZWY6IHRoaXMuYXBwUmVmLFxuICAgICAgY3JlYXRlQ29tcG9uZW50T3B0aW9uczoge1xuICAgICAgICBlbnZpcm9ubWVudEluamVjdG9yOiB0aGlzLmluamVjdG9yLFxuICAgICAgfSxcbiAgICAgIGlucHV0czogaW5wdXRzLFxuICAgIH07XG4gICAgY29uc3QgY29tcG9uZW50UmVmID0gQ29tcG9uZW50Q3JlYXRvci5jcmVhdGVDb21wb25lbnQoXG4gICAgICBjcmVhdGVDb21wb25lbnRPcHRpb25zXG4gICAgKTtcbiAgICB0aGlzLnJlbmRlcmVyLmFwcGVuZENoaWxkKHRoaXMud3JhcHBlciwgZGlhbG9nKTtcbiAgICB0aGlzLm9wZW5EaWFsb2dzW2lkXSA9IHtcbiAgICAgIGRpYWxvZ0VsZW1lbnQ6IGRpYWxvZyxcbiAgICAgIGNvbXBvbmVudFJlZjogY29tcG9uZW50UmVmLFxuICAgICAgaWQ6IGlkLFxuICAgICAgb3B0aW9uczogb3B0aW9ucyxcbiAgICAgIHN1YmplY3QsXG4gICAgfTtcbiAgICBjb21wb25lbnRSZWYuaW5zdGFuY2UuaWQgPSBpZDtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRoaXMucmVuZGVyZXIucmVtb3ZlQ2xhc3ModGhpcy53cmFwcGVyLCAnaGlkZScpO1xuICAgICAgdGhpcy5yZW5kZXJlci5hZGRDbGFzcyhkaWFsb2csICdvcGVuJyk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5hZGRDbGFzcyh0aGlzLndyYXBwZXIsICdvcGVuJyk7XG4gICAgICAgIHRoaXMucmVuZGVyZXIuYWRkQ2xhc3MoZGlhbG9nLCAnb3BlbicpO1xuICAgICAgfSwgNTApO1xuICAgIH0pO1xuICAgIHJldHVybiBzdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuICB9XG5cbiAgcHVibGljIHN1Ym1pdERpYWxvZyhpZDogc3RyaW5nLCBkYXRhOiBhbnkpIHtcbiAgICBpZiAodGhpcy5vcGVuRGlhbG9nc1tpZF0pIHtcbiAgICAgIHRoaXMub3BlbkRpYWxvZ3NbaWRdLnN1YmplY3QubmV4dCh7XG4gICAgICAgIGNvbmZpcm06IHRydWUsXG4gICAgICAgIGRhdGE6IGRhdGEgPz8ge30sXG4gICAgICB9KTtcbiAgICAgIHRoaXMuZGlzcG9zZShpZCk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIGNhbmNlbERpYWxvZyhpZDogc3RyaW5nLCBkYXRhOiBhbnkpIHtcbiAgICBpZiAodGhpcy5vcGVuRGlhbG9nc1tpZF0pIHtcbiAgICAgIHRoaXMub3BlbkRpYWxvZ3NbaWRdLnN1YmplY3QubmV4dCh7XG4gICAgICAgIGNvbmZpcm06IGZhbHNlLFxuICAgICAgICBkYXRhOiBkYXRhID8/IHt9LFxuICAgICAgfSk7XG4gICAgICB0aGlzLmRpc3Bvc2UoaWQpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBkaXNwb3NlKGlkOiBzdHJpbmcpIHtcbiAgICBpZiAodGhpcy5vcGVuRGlhbG9ncz8uW2lkXSkge1xuICAgICAgdGhpcy5kb0Rpc3Bvc2UoaWQpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZG9EaXNwb3NlKGlkOiBzdHJpbmcpIHtcbiAgICB0aGlzLnJlbmRlcmVyLnJlbW92ZUNsYXNzKHRoaXMub3BlbkRpYWxvZ3NbaWRdLmRpYWxvZ0VsZW1lbnQsICdvcGVuJyk7XG4gICAgY29uc3QgY29tcG9uZW50UmVmID0gdGhpcy5vcGVuRGlhbG9nc1tpZF0uY29tcG9uZW50UmVmO1xuICAgIHRoaXMub3BlbkRpYWxvZ3NbaWRdLnN1YmplY3QuY29tcGxldGUoKTtcbiAgICBkZWxldGUgdGhpcy5vcGVuRGlhbG9nc1tpZF07XG4gICAgaWYgKE9iamVjdC5rZXlzKHRoaXMub3BlbkRpYWxvZ3MpLmxlbmd0aCA9PT0gMCkge1xuICAgICAgdGhpcy5yZW5kZXJlci5yZW1vdmVDbGFzcyh0aGlzLndyYXBwZXIsICdvcGVuJyk7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5hZGRDbGFzcyh0aGlzLndyYXBwZXIsICdoaWRlJyk7XG4gICAgICB9LCAzMDApO1xuICAgIH1cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGNvbXBvbmVudFJlZi5kZXN0cm95KCk7XG4gICAgICB0aGlzLmFwcFJlZi5kZXRhY2hWaWV3KGNvbXBvbmVudFJlZi5ob3N0Vmlldyk7XG4gICAgfSwgMzAwKTtcbiAgfVxufVxuIl19