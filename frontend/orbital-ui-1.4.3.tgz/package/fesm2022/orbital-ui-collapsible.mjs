import * as i0 from '@angular/core';
import { Injectable, EventEmitter, Component, ChangeDetectionStrategy, Input, ViewChild, Output } from '@angular/core';
import { ReplaySubject, Subject, filter } from 'rxjs';
import { isNil } from 'lodash-es';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NgClass } from '@angular/common';
import * as i2 from '@angular/cdk/observers';
import { ObserversModule } from '@angular/cdk/observers';

/**
 * Service used to control oui-collapsible-content and oui-collapsible-toggle.
 * All collapsibles are stored in this service, and you can programmatically toggle any group to be open or closed from here.
 * Contains a collapsibleToggled$ observable that you can subscribe to in order to be notified when a collapsible group is toggled
 */
class OuiCollapsibleService {
    collapsibleToggledSubject = new ReplaySubject(1);
    refreshCollapsibleContentHeightSubject = new Subject();
    collapsibleToggled$ = this.collapsibleToggledSubject.asObservable();
    refreshCollapsibleContentHeight$ = this.refreshCollapsibleContentHeightSubject.asObservable();
    collapsibles = {};
    constructor() { }
    registerToggle(group, toggle) {
        if (!this.collapsibles[group]) {
            this.collapsibles[group] = {
                content: null,
                toggle: toggle,
                isOpen: toggle.isOpen,
            };
        }
        else {
            this.collapsibles[group].toggle = toggle;
            this.collapsibles[group].isOpen = toggle.isOpen;
        }
    }
    refreshCollapsibleContentHeight(group) {
        if (this.collapsibles[group]) {
            this.refreshCollapsibleContentHeightSubject.next(group);
        }
    }
    registerContent(group, content) {
        if (!this.collapsibles[group]) {
            this.collapsibles[group] = {
                content: content,
                toggle: null,
                isOpen: false,
            };
        }
        else {
            this.collapsibles[group].content = content;
        }
    }
    deregisterCollapsible(group) {
        if (this.collapsibles[group]) {
            delete this.collapsibles[group];
        }
    }
    toggle(group, isOpen) {
        if (this.collapsibles[group]) {
            const newIsOpen = isNil(isOpen)
                ? !this.collapsibles[group].isOpen
                : isOpen;
            this.collapsibles[group].isOpen = newIsOpen;
            this.collapsibleToggledSubject.next({
                group,
                isOpen: newIsOpen,
            });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCollapsibleService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCollapsibleService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCollapsibleService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/**
 * A component part of a group of components that can be used to create collapsible content-blocks.
 * This component is used to toggle the content of the collapsible block. Use this in conjunction with oui-collapsible-content.
 *
 * @Input() group: string -               The group of the collapsible component. This needs to match the toggle that you want to use to
 *                                        toggle the content.
 * @Input() isOpen: boolean -             You can use this input to control whether or not the collapsible content should be open
 *                                        For example if you want it to be initially toggled open, then you can pass true to this input
 * @Input() disableClickToggle: boolean - This can be used to disable toggling the collapsible content by clicking on the toggle
 *                                        In this case, it can only be toggled programmatically.
 *
 * @Output() isOpenChange: boolean - Emitted when the toggle is opened/closed
 * Example usage:
 *
 * <oui-collapsible-toggle [isOpen]="isFirstGroupOpen" group="first-group"></oui-collapsible-toggle>
 * <oui-collapsible-content group=first-group">
 *   <div class="content">You can put any content here that you desire</div>
 * </oui-collapsible-content>
 */
class OuiCollapsibleToggleComponent {
    ouiCollapsibleService;
    destroyRef;
    group;
    isOpen = false;
    disableClickToggle = false;
    toggleContainer;
    toggle;
    isOpenChange = new EventEmitter();
    isInitialOpenSet = false;
    constructor(ouiCollapsibleService, destroyRef) {
        this.ouiCollapsibleService = ouiCollapsibleService;
        this.destroyRef = destroyRef;
    }
    ngAfterViewInit() {
        this.ouiCollapsibleService.registerToggle(this.group, this);
        this.ouiCollapsibleService.collapsibleToggled$
            .pipe(filter((data) => {
            return data.group === this.group;
        }), takeUntilDestroyed(this.destroyRef))
            .subscribe((data) => {
            this.isOpen = data.isOpen;
            if (this.isInitialOpenSet) {
                this.isOpenChange.emit(this.isOpen);
            }
        });
        if (this.isOpen) {
            this.ouiCollapsibleService.toggle(this.group, true);
        }
        this.isInitialOpenSet = true;
    }
    onClick() {
        if (!this.disableClickToggle) {
            this.doToggle();
        }
    }
    doToggle() {
        this.ouiCollapsibleService.toggle(this.group);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCollapsibleToggleComponent, deps: [{ token: OuiCollapsibleService }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiCollapsibleToggleComponent, isStandalone: true, selector: "oui-collapsible-toggle", inputs: { group: "group", isOpen: "isOpen", disableClickToggle: "disableClickToggle" }, outputs: { isOpenChange: "isOpenChange" }, viewQueries: [{ propertyName: "toggleContainer", first: true, predicate: ["toggleContainer"], descendants: true }, { propertyName: "toggle", first: true, predicate: ["toggle"], descendants: true }], ngImport: i0, template: "<div\n  class=\"oui-collapsible-toggle-container\"\n  #toggleContainer\n  (click)=\"onClick()\"\n>\n  <ng-content #toggle></ng-content>\n</div>\n", styles: [":host{width:100%;position:relative}:host .oui-collapsible-toggle-container{width:100%}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCollapsibleToggleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-collapsible-toggle', standalone: true, imports: [], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"oui-collapsible-toggle-container\"\n  #toggleContainer\n  (click)=\"onClick()\"\n>\n  <ng-content #toggle></ng-content>\n</div>\n", styles: [":host{width:100%;position:relative}:host .oui-collapsible-toggle-container{width:100%}\n"] }]
        }], ctorParameters: () => [{ type: OuiCollapsibleService }, { type: i0.DestroyRef }], propDecorators: { group: [{
                type: Input
            }], isOpen: [{
                type: Input
            }], disableClickToggle: [{
                type: Input
            }], toggleContainer: [{
                type: ViewChild,
                args: ['toggleContainer']
            }], toggle: [{
                type: ViewChild,
                args: ['toggle']
            }], isOpenChange: [{
                type: Output
            }] } });

/**
 * A component part of a group of components that can be used to create collapsible content-blocks.
 * This component is used to contain the content of the collapsible block. Use this in conjunction with oui-collapsible-toggle.
 * Example usage:
 *
 * <oui-collapsible-toggle group="first-group"></oui-collapsible-toggle>
 * <oui-collapsible-content group=first-group">
 *   <div class="content">You can put any content here that you desire</div>
 * </oui-collapsible-content>
 */
class OuiCollapsibleContentComponent {
    ouiCollapsibleService;
    cdr;
    destroyRef;
    /**
     * the group of the collapsible component. This needs to match the toggle that you want to use to
     * toggle the content.
     */
    group;
    isOpen = false;
    isOpeningFinished = false;
    isInitialHeightSet = false;
    contentContainer;
    constructor(ouiCollapsibleService, cdr, destroyRef) {
        this.ouiCollapsibleService = ouiCollapsibleService;
        this.cdr = cdr;
        this.destroyRef = destroyRef;
    }
    onContentChange() {
        if (this.isInitialHeightSet) {
            return;
        }
        this.doCalculateContent();
    }
    doCalculateContent() {
        const child = this.contentContainer.nativeElement.children[0];
        if (child) {
            if (this.isOpen) {
                this.contentContainer.nativeElement.style.height =
                    child.offsetHeight + 'px';
            }
            this.isInitialHeightSet = true;
        }
    }
    ngAfterViewInit() {
        this.ouiCollapsibleService.registerContent(this.group, this);
        this.destroyRef.onDestroy(() => {
            this.ouiCollapsibleService.deregisterCollapsible(this.group);
        });
        this.ouiCollapsibleService.refreshCollapsibleContentHeight$
            .pipe(filter((group) => {
            return group === this.group;
        }), takeUntilDestroyed(this.destroyRef))
            .subscribe((group) => {
            this.doCalculateContent();
        });
        this.ouiCollapsibleService.collapsibleToggled$
            .pipe(filter((data) => {
            return data.group === this.group;
        }), takeUntilDestroyed(this.destroyRef))
            .subscribe((data) => {
            this.isOpen = data.isOpen;
            if (this.isOpen) {
                const child = this.contentContainer.nativeElement.children[0];
                if (child) {
                    this.contentContainer.nativeElement.style.height =
                        child.offsetHeight + 'px';
                }
                setTimeout(() => {
                    this.isOpeningFinished = true;
                    this.cdr.detectChanges();
                }, 300);
            }
            else {
                this.isOpeningFinished = false;
                this.contentContainer.nativeElement.style.height = 0;
            }
            this.cdr.detectChanges();
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCollapsibleContentComponent, deps: [{ token: OuiCollapsibleService }, { token: i0.ChangeDetectorRef }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiCollapsibleContentComponent, isStandalone: true, selector: "oui-collapsible-content", inputs: { group: "group" }, viewQueries: [{ propertyName: "contentContainer", first: true, predicate: ["contentContainer"], descendants: true }], ngImport: i0, template: "<div\n  class=\"oui-collapsible-content-container oui-scrollbar oui-scrollbar-auto\"\n  [ngClass]=\"{ 'is-open': isOpen, 'opening-finished': isOpeningFinished }\"\n  #contentContainer\n  (cdkObserveContent)=\"onContentChange()\"\n>\n  <ng-content></ng-content>\n</div>\n", styles: [":host{height:100%;width:100%;position:relative;display:flex}:host .oui-collapsible-content-container{opacity:0;pointer-events:none;height:0;width:100%;overflow:hidden;transition:height .3s,opacity .3s;overflow:hidden!important}:host .oui-collapsible-content-container.is-open{display:block;pointer-events:all;opacity:1}:host .oui-collapsible-content-container.opening-finished{overflow:auto}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: ObserversModule }, { kind: "directive", type: i2.CdkObserveContent, selector: "[cdkObserveContent]", inputs: ["cdkObserveContentDisabled", "debounce"], outputs: ["cdkObserveContent"], exportAs: ["cdkObserveContent"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCollapsibleContentComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-collapsible-content', standalone: true, imports: [NgClass, ObserversModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"oui-collapsible-content-container oui-scrollbar oui-scrollbar-auto\"\n  [ngClass]=\"{ 'is-open': isOpen, 'opening-finished': isOpeningFinished }\"\n  #contentContainer\n  (cdkObserveContent)=\"onContentChange()\"\n>\n  <ng-content></ng-content>\n</div>\n", styles: [":host{height:100%;width:100%;position:relative;display:flex}:host .oui-collapsible-content-container{opacity:0;pointer-events:none;height:0;width:100%;overflow:hidden;transition:height .3s,opacity .3s;overflow:hidden!important}:host .oui-collapsible-content-container.is-open{display:block;pointer-events:all;opacity:1}:host .oui-collapsible-content-container.opening-finished{overflow:auto}\n"] }]
        }], ctorParameters: () => [{ type: OuiCollapsibleService }, { type: i0.ChangeDetectorRef }, { type: i0.DestroyRef }], propDecorators: { group: [{
                type: Input
            }], contentContainer: [{
                type: ViewChild,
                args: ['contentContainer']
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiCollapsibleContentComponent, OuiCollapsibleService, OuiCollapsibleToggleComponent };
//# sourceMappingURL=orbital-ui-collapsible.mjs.map
