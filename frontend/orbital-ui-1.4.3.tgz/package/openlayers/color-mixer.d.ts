import { RGBA } from 'orbital-ui/core';
export declare function mixRgbaColors(colorA: RGBA, colorB: RGBA): RGBA;
//# sourceMappingURL=color-mixer.d.ts.map