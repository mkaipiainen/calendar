import * as i0 from '@angular/core';
import { EventEmitter, Component, ChangeDetectionStrategy, Input, Output } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { isEqual } from 'lodash-es';

/**
 * Component to add radio-buttons.
 *
 *   example use:
 *
 *   <oui-radio group="radioButtons"[(model)]="radioModel" value="First value">The label for first radio-button</oui-radio>
 *   <oui-radio group="radioButtons" [(model)]="radioModel" value="Second value">The label for second radio-button</oui-radio>
 *
 */
class OuiRadioComponent {
    cdr;
    /**
     *   Group that the radio-button belongs to.
     */
    group;
    /**
     *   The model attached to the input field value-changes
     */
    model;
    /**
     *   The value of the radio-button. When radio-button is selected, the attached model gets this value
     */
    value;
    /**
     *   The event emitted when model changes
     */
    modelChange = new EventEmitter();
    /**
     *  The property of the model to compare with the value
     */
    compareBy;
    isChecked = false;
    constructor(cdr) {
        this.cdr = cdr;
    }
    ngAfterViewInit() {
        if (this.model && this.value) {
            this.doCheckIsChecked();
        }
    }
    doCheckIsChecked() {
        this.isChecked = this.isSelected();
        this.cdr.detectChanges();
    }
    isSelected() {
        if (this.compareBy) {
            return this.model[this.compareBy] === this.value[this.compareBy];
        }
        else {
            return isEqual(this.model, this.value);
        }
    }
    setModel() {
        this.model = this.value;
        this.isChecked = true;
        this.modelChange.emit(this.model);
        this.cdr.detectChanges();
    }
    ngOnChanges(changes) {
        if (changes['model'] || changes['value']) {
            this.model = changes['model'].currentValue;
            this.doCheckIsChecked();
        }
        if (changes['value']) {
            this.value = changes['value'].currentValue;
            this.doCheckIsChecked();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiRadioComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiRadioComponent, isStandalone: true, selector: "oui-radio", inputs: { group: "group", model: "model", value: "value", compareBy: "compareBy" }, outputs: { modelChange: "modelChange" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"oui-radio-container\" (click)=\"setModel()\">\n  <div class=\"oui-radio-inner-container\">\n    <input\n      type=\"radio\"\n      name=\"{{ group }}\"\n      value=\"{{ value }}\"\n      [ngModel]=\"model\"\n      />\n    <span class=\"oui-radio-circle\">\n      @if (isChecked) {\n        <span class=\"oui-radio-check\"></span>\n      }\n    </span>\n  </div>\n  <div class=\"oui-radio-label-container\">\n    <ng-content></ng-content>\n  </div>\n</div>\n", styles: [":host{cursor:pointer;min-width:50px;min-height:20px;display:flex;align-items:center}:host input[type=radio]{-webkit-appearance:none;appearance:none;opacity:0;position:absolute}:host .oui-radio-container{display:flex;align-items:center;flex-wrap:nowrap;flex:1}:host .oui-radio-container .oui-radio-inner-container{display:flex;align-items:center;flex-wrap:nowrap;margin-right:var(--oui-radio-label-distance)}:host .oui-radio-container .oui-radio-inner-container .oui-radio-circle{width:var(--oui-radio-size);height:var(--oui-radio-size);border-radius:50%;border:1px solid var(--oui-radio-border-color);background-color:#fff;display:flex;justify-content:center;align-items:center;transition:border-color .3s;flex:0 0 auto;margin-right:5px}:host .oui-radio-container .oui-radio-inner-container .oui-radio-circle .oui-radio-check{border-radius:50%;width:10px;height:10px;background-color:var(--oui-radio-check-color)}:host .oui-radio-container .oui-radio-label-container{flex:1;display:inline-block;position:relative;color:var(--oui-radio-text-color);font-size:var(--oui-radio-label-font-size)}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.RadioControlValueAccessor, selector: "input[type=radio][formControlName],input[type=radio][formControl],input[type=radio][ngModel]", inputs: ["name", "formControlName", "value"] }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiRadioComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-radio', standalone: true, imports: [FormsModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"oui-radio-container\" (click)=\"setModel()\">\n  <div class=\"oui-radio-inner-container\">\n    <input\n      type=\"radio\"\n      name=\"{{ group }}\"\n      value=\"{{ value }}\"\n      [ngModel]=\"model\"\n      />\n    <span class=\"oui-radio-circle\">\n      @if (isChecked) {\n        <span class=\"oui-radio-check\"></span>\n      }\n    </span>\n  </div>\n  <div class=\"oui-radio-label-container\">\n    <ng-content></ng-content>\n  </div>\n</div>\n", styles: [":host{cursor:pointer;min-width:50px;min-height:20px;display:flex;align-items:center}:host input[type=radio]{-webkit-appearance:none;appearance:none;opacity:0;position:absolute}:host .oui-radio-container{display:flex;align-items:center;flex-wrap:nowrap;flex:1}:host .oui-radio-container .oui-radio-inner-container{display:flex;align-items:center;flex-wrap:nowrap;margin-right:var(--oui-radio-label-distance)}:host .oui-radio-container .oui-radio-inner-container .oui-radio-circle{width:var(--oui-radio-size);height:var(--oui-radio-size);border-radius:50%;border:1px solid var(--oui-radio-border-color);background-color:#fff;display:flex;justify-content:center;align-items:center;transition:border-color .3s;flex:0 0 auto;margin-right:5px}:host .oui-radio-container .oui-radio-inner-container .oui-radio-circle .oui-radio-check{border-radius:50%;width:10px;height:10px;background-color:var(--oui-radio-check-color)}:host .oui-radio-container .oui-radio-label-container{flex:1;display:inline-block;position:relative;color:var(--oui-radio-text-color);font-size:var(--oui-radio-label-font-size)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { group: [{
                type: Input
            }], model: [{
                type: Input
            }], value: [{
                type: Input
            }], modelChange: [{
                type: Output
            }], compareBy: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiRadioComponent };
//# sourceMappingURL=orbital-ui-radio.mjs.map
