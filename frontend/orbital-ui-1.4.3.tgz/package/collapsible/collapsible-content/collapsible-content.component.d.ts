import { AfterViewInit, ChangeDetectorRef, DestroyRef, ElementRef } from '@angular/core';
import { OuiCollapsibleService } from '../collapsible.service';
import * as i0 from "@angular/core";
/**
 * A component part of a group of components that can be used to create collapsible content-blocks.
 * This component is used to contain the content of the collapsible block. Use this in conjunction with oui-collapsible-toggle.
 * Example usage:
 *
 * <oui-collapsible-toggle group="first-group"></oui-collapsible-toggle>
 * <oui-collapsible-content group=first-group">
 *   <div class="content">You can put any content here that you desire</div>
 * </oui-collapsible-content>
 */
export declare class OuiCollapsibleContentComponent implements AfterViewInit {
    private ouiCollapsibleService;
    private cdr;
    private destroyRef;
    /**
     * the group of the collapsible component. This needs to match the toggle that you want to use to
     * toggle the content.
     */
    group: string;
    isOpen: boolean;
    isOpeningFinished: boolean;
    private isInitialHeightSet;
    contentContainer: ElementRef;
    constructor(ouiCollapsibleService: OuiCollapsibleService, cdr: ChangeDetectorRef, destroyRef: DestroyRef);
    onContentChange(): void;
    private doCalculateContent;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiCollapsibleContentComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiCollapsibleContentComponent, "oui-collapsible-content", never, { "group": { "alias": "group"; "required": false; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=collapsible-content.component.d.ts.map