import { PathLayer } from '@deck.gl/layers/typed';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { BindCommonDeckOptions } from '../deck/bind-default-deck-options';
import * as i0 from "@angular/core";
export class DeckPathLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new PathLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            getWidth: this.options.getWidth ? this.options.getWidth : () => 1,
            widthMinPixels: this.options.widthMinPixels ?? 1,
            widthMaxPixels: this.options.widthMaxPixels ?? 9999,
            getColor: this.options.getColor,
            getPath: this.options.getPath,
            widthUnits: this.options.widthUnits ?? 'pixels',
            jointRounded: this.options.jointRounded ?? false,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckPathLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckPathLayer, isStandalone: true, selector: "oui-deck-path-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckPathLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-path-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay1wYXRoLWxheWVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9tYXBib3gvcGF0aC1sYXllci9kZWNrLXBhdGgtbGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBRWxELE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM3RCxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQzs7QUFTMUUsTUFBTSxPQUFPLGFBQWMsU0FBUSxhQUFzQztJQUNwQyxPQUFPLENBQXdCO0lBRWxFO1FBQ0UsS0FBSyxFQUFFLENBQUM7SUFDVixDQUFDO0lBRU0sUUFBUTtRQUNiLE9BQU8sSUFBSSxTQUFTLENBQUM7WUFDbkIsR0FBRyxxQkFBcUIsQ0FBQyxJQUFJLENBQUM7WUFDOUIsSUFBSSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSTtZQUN2QixRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO1lBQ2pFLGNBQWMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsSUFBSSxDQUFDO1lBQ2hELGNBQWMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsSUFBSSxJQUFJO1lBQ25ELFFBQVEsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVE7WUFDL0IsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTztZQUM3QixVQUFVLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLElBQUksUUFBUTtZQUMvQyxZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLElBQUksS0FBSztTQUNqRCxDQUFDLENBQUM7SUFDTCxDQUFDO3VHQW5CVSxhQUFhOzJGQUFiLGFBQWEsc0lBTGQsRUFBRTs7MkZBS0QsYUFBYTtrQkFQekIsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUscUJBQXFCO29CQUMvQixRQUFRLEVBQUUsRUFBRTtvQkFDWixVQUFVLEVBQUUsSUFBSTtvQkFDaEIsT0FBTyxFQUFFLEVBQUU7b0JBQ1gsZUFBZSxFQUFFLHVCQUF1QixDQUFDLE1BQU07aUJBQ2hEO3dEQUVvQyxPQUFPO3NCQUF6QyxLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBhdGhMYXllciB9IGZyb20gJ0BkZWNrLmdsL2xheWVycy90eXBlZCc7XG5pbXBvcnQgeyBJQ29tbW9uRGVja0xheWVyT3B0aW9ucywgSURlY2tQYXRoTGF5ZXJPcHRpb25zIH0gZnJvbSAnLi4vdHlwaW5ncyc7XG5pbXBvcnQgeyBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSwgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURlY2tMYXllciB9IGZyb20gJy4uL2Jhc2UtZGVjay1sYXllci5jb21wb25lbnQnO1xuaW1wb3J0IHsgQmluZENvbW1vbkRlY2tPcHRpb25zIH0gZnJvbSAnLi4vZGVjay9iaW5kLWRlZmF1bHQtZGVjay1vcHRpb25zJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLWRlY2stcGF0aC1sYXllcicsXG4gIHRlbXBsYXRlOiAnJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW10sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBEZWNrUGF0aExheWVyIGV4dGVuZHMgQmFzZURlY2tMYXllcjxJQ29tbW9uRGVja0xheWVyT3B0aW9ucz4ge1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KSBkZWNsYXJlIG9wdGlvbnM6IElEZWNrUGF0aExheWVyT3B0aW9ucztcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpO1xuICB9XG5cbiAgcHVibGljIGdldExheWVyKCkge1xuICAgIHJldHVybiBuZXcgUGF0aExheWVyKHtcbiAgICAgIC4uLkJpbmRDb21tb25EZWNrT3B0aW9ucyh0aGlzKSxcbiAgICAgIGRhdGE6IHRoaXMub3B0aW9ucy5kYXRhLFxuICAgICAgZ2V0V2lkdGg6IHRoaXMub3B0aW9ucy5nZXRXaWR0aCA/IHRoaXMub3B0aW9ucy5nZXRXaWR0aCA6ICgpID0+IDEsXG4gICAgICB3aWR0aE1pblBpeGVsczogdGhpcy5vcHRpb25zLndpZHRoTWluUGl4ZWxzID8/IDEsXG4gICAgICB3aWR0aE1heFBpeGVsczogdGhpcy5vcHRpb25zLndpZHRoTWF4UGl4ZWxzID8/IDk5OTksXG4gICAgICBnZXRDb2xvcjogdGhpcy5vcHRpb25zLmdldENvbG9yLFxuICAgICAgZ2V0UGF0aDogdGhpcy5vcHRpb25zLmdldFBhdGgsXG4gICAgICB3aWR0aFVuaXRzOiB0aGlzLm9wdGlvbnMud2lkdGhVbml0cyA/PyAncGl4ZWxzJyxcbiAgICAgIGpvaW50Um91bmRlZDogdGhpcy5vcHRpb25zLmpvaW50Um91bmRlZCA/PyBmYWxzZSxcbiAgICB9KTtcbiAgfVxufVxuIl19