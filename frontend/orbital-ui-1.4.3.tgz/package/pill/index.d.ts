/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/pill" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-pill.d.ts.map