import { ChangeDetectionStrategy, Component, computed, input, signal, } from '@angular/core';
import { OpenlayersBaseLayerComponent } from './openlayers-base-layer.component';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import { GeoJSON } from 'ol/format';
import { Icon, Style } from 'ol/style';
import { DEFAULT_COMMON_OPTIONS } from '../constants';
import * as i0 from "@angular/core";
export class OpenlayersIconLayerComponent extends OpenlayersBaseLayerComponent {
    options = input.required();
    combinedOptions = computed(() => {
        return {
            ...DEFAULT_COMMON_OPTIONS,
            ...{
                anchor: {
                    x: 0.5,
                    y: 0.5,
                },
                anchorUnits: {
                    x: 'fraction',
                    y: 'fraction',
                },
            },
            ...this.options(),
        };
    });
    source = signal(new VectorSource());
    layer = signal(new VectorLayer({
        source: this.source(),
        style: feature => {
            return this.getStyleForFeature(feature);
        },
    }));
    constructor() {
        super();
    }
    getStyleForFeature(feature) {
        const options = this.combinedOptions();
        return new Style({
            image: new Icon({
                anchor: [options.anchor.x, options.anchor.y],
                anchorXUnits: options.anchorUnits.x,
                anchorYUnits: options.anchorUnits.y,
                src: options.getIcon(feature),
                scale: 1,
            }),
        });
    }
    onHover(feature) {
        super.onHover(feature);
    }
    onUnHover(feature) {
        super.onUnHover(feature);
    }
    updateLayer() {
        const dataWithLayer = {
            type: 'FeatureCollection',
            features: this.combinedOptions().data.map((datum) => {
                return {
                    type: 'Feature',
                    geometry: {
                        type: 'Point',
                        coordinates: this.combinedOptions().getPosition(datum),
                    },
                    properties: {
                        ...(datum ?? {}),
                        layer: this,
                    },
                };
            }),
        };
        this.layer().setZIndex(this.combinedOptions().order ?? 0);
        this.source().clear(true);
        this.source().addFeatures(new GeoJSON().readFeatures(dataWithLayer, {
            featureProjection: 'EPSG:3857', // Ensure the projection matches your map's projection
        }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersIconLayerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "17.3.1", type: OpenlayersIconLayerComponent, isStandalone: true, selector: "oui-openlayers-icon-layer", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, providers: [
            {
                provide: OpenlayersBaseLayerComponent,
                useExisting: OpenlayersIconLayerComponent,
            },
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersIconLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-openlayers-icon-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [
                        {
                            provide: OpenlayersBaseLayerComponent,
                            useExisting: OpenlayersIconLayerComponent,
                        },
                    ],
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BlbmxheWVycy1pY29uLWxheWVyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvb3BlbmxheWVycy9sYXllcnMvb3BlbmxheWVycy1pY29uLWxheWVyLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBRUwsdUJBQXVCLEVBQ3ZCLFNBQVMsRUFDVCxRQUFRLEVBQ1IsS0FBSyxFQUNMLE1BQU0sR0FDUCxNQUFNLGVBQWUsQ0FBQztBQUd2QixPQUFPLEVBQUUsNEJBQTRCLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQztBQUNqRixPQUFPLFdBQVcsTUFBTSxpQkFBaUIsQ0FBQztBQUMxQyxPQUFPLFlBQVksTUFBTSxrQkFBa0IsQ0FBQztBQUM1QyxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sV0FBVyxDQUFDO0FBQ3BDLE9BQU8sRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLE1BQU0sVUFBVSxDQUFDO0FBTXZDLE9BQU8sRUFBRSxzQkFBc0IsRUFBRSxNQUFNLGNBQWMsQ0FBQzs7QUFjdEQsTUFBTSxPQUFPLDRCQUE2QixTQUFRLDRCQUEyRDtJQUMzRixPQUFPLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBaUMsQ0FBQztJQUNuRSxlQUFlLEdBQUcsUUFBUSxDQUFDLEdBQUcsRUFBRTtRQUNyQyxPQUFPO1lBQ0wsR0FBRyxzQkFBc0I7WUFDekIsR0FBRztnQkFDRCxNQUFNLEVBQUU7b0JBQ04sQ0FBQyxFQUFFLEdBQUc7b0JBQ04sQ0FBQyxFQUFFLEdBQUc7aUJBQ1A7Z0JBQ0QsV0FBVyxFQUFFO29CQUNYLENBQUMsRUFBRSxVQUFVO29CQUNiLENBQUMsRUFBRSxVQUFVO2lCQUNkO2FBQ0Y7WUFDRCxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUU7U0FDdUIsQ0FBQztJQUM3QyxDQUFDLENBQUMsQ0FBQztJQUVJLE1BQU0sR0FBRyxNQUFNLENBQWUsSUFBSSxZQUFZLEVBQUUsQ0FBQyxDQUFDO0lBQ2xELEtBQUssR0FBRyxNQUFNLENBQ25CLElBQUksV0FBVyxDQUFDO1FBQ2QsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUU7UUFDckIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxFQUFFO1lBQ2YsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDMUMsQ0FBQztLQUNGLENBQUMsQ0FDSCxDQUFDO0lBRUY7UUFDRSxLQUFLLEVBQUUsQ0FBQztJQUNWLENBQUM7SUFFTyxrQkFBa0IsQ0FBQyxPQUFvQjtRQUM3QyxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDdkMsT0FBTyxJQUFJLEtBQUssQ0FBQztZQUNmLEtBQUssRUFBRSxJQUFJLElBQUksQ0FBQztnQkFDZCxNQUFNLEVBQUUsQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztnQkFDNUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDbkMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFDbkMsR0FBRyxFQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO2dCQUM3QixLQUFLLEVBQUUsQ0FBQzthQUNULENBQUM7U0FDSCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRWUsT0FBTyxDQUFDLE9BQWtCO1FBQ3hDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDekIsQ0FBQztJQUVlLFNBQVMsQ0FBQyxPQUFrQjtRQUMxQyxLQUFLLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQzNCLENBQUM7SUFFTSxXQUFXO1FBQ2hCLE1BQU0sYUFBYSxHQUFHO1lBQ3BCLElBQUksRUFBRSxtQkFBbUI7WUFDekIsUUFBUSxFQUFFLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBVSxFQUFFLEVBQUU7Z0JBQ3ZELE9BQU87b0JBQ0wsSUFBSSxFQUFFLFNBQVM7b0JBQ2YsUUFBUSxFQUFFO3dCQUNSLElBQUksRUFBRSxPQUFPO3dCQUNiLFdBQVcsRUFBRSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQztxQkFDdkQ7b0JBQ0QsVUFBVSxFQUFFO3dCQUNWLEdBQUcsQ0FBQyxLQUFLLElBQUksRUFBRSxDQUFDO3dCQUNoQixLQUFLLEVBQUUsSUFBSTtxQkFDWjtpQkFDRixDQUFDO1lBQ0osQ0FBQyxDQUFDO1NBQ2tCLENBQUM7UUFDdkIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzFELElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDMUIsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLFdBQVcsQ0FDdkIsSUFBSSxPQUFPLEVBQUUsQ0FBQyxZQUFZLENBQUMsYUFBYSxFQUFFO1lBQ3hDLGlCQUFpQixFQUFFLFdBQVcsRUFBRSxzREFBc0Q7U0FDdkYsQ0FBUSxDQUNWLENBQUM7SUFDSixDQUFDO3VHQTlFVSw0QkFBNEI7MkZBQTVCLDRCQUE0QixpTkFQNUI7WUFDVDtnQkFDRSxPQUFPLEVBQUUsNEJBQTRCO2dCQUNyQyxXQUFXLEVBQUUsNEJBQTRCO2FBQzFDO1NBQ0YsaURBVFMsRUFBRTs7MkZBV0QsNEJBQTRCO2tCQWJ4QyxTQUFTO21CQUFDO29CQUNULFFBQVEsRUFBRSwyQkFBMkI7b0JBQ3JDLFFBQVEsRUFBRSxFQUFFO29CQUNaLFVBQVUsRUFBRSxJQUFJO29CQUNoQixPQUFPLEVBQUUsRUFBRTtvQkFDWCxlQUFlLEVBQUUsdUJBQXVCLENBQUMsTUFBTTtvQkFDL0MsU0FBUyxFQUFFO3dCQUNUOzRCQUNFLE9BQU8sRUFBRSw0QkFBNEI7NEJBQ3JDLFdBQVcsOEJBQThCO3lCQUMxQztxQkFDRjtpQkFDRiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFmdGVyVmlld0luaXQsXG4gIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LFxuICBDb21wb25lbnQsXG4gIGNvbXB1dGVkLFxuICBpbnB1dCxcbiAgc2lnbmFsLFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZlYXR1cmVDb2xsZWN0aW9uIH0gZnJvbSAnQHR1cmYvaGVscGVycyc7XG5pbXBvcnQgeyBGZWF0dXJlIGFzIE9sRmVhdHVyZSB9IGZyb20gJ29sJztcbmltcG9ydCB7IE9wZW5sYXllcnNCYXNlTGF5ZXJDb21wb25lbnQgfSBmcm9tICcuL29wZW5sYXllcnMtYmFzZS1sYXllci5jb21wb25lbnQnO1xuaW1wb3J0IFZlY3RvckxheWVyIGZyb20gJ29sL2xheWVyL1ZlY3Rvcic7XG5pbXBvcnQgVmVjdG9yU291cmNlIGZyb20gJ29sL3NvdXJjZS9WZWN0b3InO1xuaW1wb3J0IHsgR2VvSlNPTiB9IGZyb20gJ29sL2Zvcm1hdCc7XG5pbXBvcnQgeyBJY29uLCBTdHlsZSB9IGZyb20gJ29sL3N0eWxlJztcbmltcG9ydCB7IEZlYXR1cmVMaWtlIH0gZnJvbSAnb2wvRmVhdHVyZSc7XG5pbXBvcnQge1xuICBPdWlPcGVuTGF5ZXJzQ29tYmluZWRJY29uTGF5ZXJPcHRpb25zLFxuICBPdWlPcGVuTGF5ZXJzSWNvbkxheWVyT3B0aW9ucyxcbn0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgREVGQVVMVF9DT01NT05fT1BUSU9OUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdvdWktb3BlbmxheWVycy1pY29uLWxheWVyJyxcbiAgdGVtcGxhdGU6ICcnLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG4gIHByb3ZpZGVyczogW1xuICAgIHtcbiAgICAgIHByb3ZpZGU6IE9wZW5sYXllcnNCYXNlTGF5ZXJDb21wb25lbnQsXG4gICAgICB1c2VFeGlzdGluZzogT3BlbmxheWVyc0ljb25MYXllckNvbXBvbmVudCxcbiAgICB9LFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBPcGVubGF5ZXJzSWNvbkxheWVyQ29tcG9uZW50IGV4dGVuZHMgT3BlbmxheWVyc0Jhc2VMYXllckNvbXBvbmVudDxPdWlPcGVuTGF5ZXJzSWNvbkxheWVyT3B0aW9ucz4ge1xuICBwdWJsaWMgb3ZlcnJpZGUgb3B0aW9ucyA9IGlucHV0LnJlcXVpcmVkPE91aU9wZW5MYXllcnNJY29uTGF5ZXJPcHRpb25zPigpO1xuICBwdWJsaWMgY29tYmluZWRPcHRpb25zID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5ERUZBVUxUX0NPTU1PTl9PUFRJT05TLFxuICAgICAgLi4ue1xuICAgICAgICBhbmNob3I6IHtcbiAgICAgICAgICB4OiAwLjUsXG4gICAgICAgICAgeTogMC41LFxuICAgICAgICB9LFxuICAgICAgICBhbmNob3JVbml0czoge1xuICAgICAgICAgIHg6ICdmcmFjdGlvbicsXG4gICAgICAgICAgeTogJ2ZyYWN0aW9uJyxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICAuLi50aGlzLm9wdGlvbnMoKSxcbiAgICB9IGFzIE91aU9wZW5MYXllcnNDb21iaW5lZEljb25MYXllck9wdGlvbnM7XG4gIH0pO1xuXG4gIHB1YmxpYyBzb3VyY2UgPSBzaWduYWw8VmVjdG9yU291cmNlPihuZXcgVmVjdG9yU291cmNlKCkpO1xuICBwdWJsaWMgbGF5ZXIgPSBzaWduYWw8VmVjdG9yTGF5ZXI8VmVjdG9yU291cmNlPj4oXG4gICAgbmV3IFZlY3RvckxheWVyKHtcbiAgICAgIHNvdXJjZTogdGhpcy5zb3VyY2UoKSxcbiAgICAgIHN0eWxlOiBmZWF0dXJlID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0U3R5bGVGb3JGZWF0dXJlKGZlYXR1cmUpO1xuICAgICAgfSxcbiAgICB9KVxuICApO1xuXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKCk7XG4gIH1cblxuICBwcml2YXRlIGdldFN0eWxlRm9yRmVhdHVyZShmZWF0dXJlOiBGZWF0dXJlTGlrZSkge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB0aGlzLmNvbWJpbmVkT3B0aW9ucygpO1xuICAgIHJldHVybiBuZXcgU3R5bGUoe1xuICAgICAgaW1hZ2U6IG5ldyBJY29uKHtcbiAgICAgICAgYW5jaG9yOiBbb3B0aW9ucy5hbmNob3IueCwgb3B0aW9ucy5hbmNob3IueV0sXG4gICAgICAgIGFuY2hvclhVbml0czogb3B0aW9ucy5hbmNob3JVbml0cy54LFxuICAgICAgICBhbmNob3JZVW5pdHM6IG9wdGlvbnMuYW5jaG9yVW5pdHMueSxcbiAgICAgICAgc3JjOiBvcHRpb25zLmdldEljb24oZmVhdHVyZSksXG4gICAgICAgIHNjYWxlOiAxLFxuICAgICAgfSksXG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgb3ZlcnJpZGUgb25Ib3ZlcihmZWF0dXJlOiBPbEZlYXR1cmUpIHtcbiAgICBzdXBlci5vbkhvdmVyKGZlYXR1cmUpO1xuICB9XG5cbiAgcHVibGljIG92ZXJyaWRlIG9uVW5Ib3ZlcihmZWF0dXJlOiBPbEZlYXR1cmUpIHtcbiAgICBzdXBlci5vblVuSG92ZXIoZmVhdHVyZSk7XG4gIH1cblxuICBwdWJsaWMgdXBkYXRlTGF5ZXIoKSB7XG4gICAgY29uc3QgZGF0YVdpdGhMYXllciA9IHtcbiAgICAgIHR5cGU6ICdGZWF0dXJlQ29sbGVjdGlvbicsXG4gICAgICBmZWF0dXJlczogdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5kYXRhLm1hcCgoZGF0dW06IGFueSkgPT4ge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHR5cGU6ICdGZWF0dXJlJyxcbiAgICAgICAgICBnZW9tZXRyeToge1xuICAgICAgICAgICAgdHlwZTogJ1BvaW50JyxcbiAgICAgICAgICAgIGNvb3JkaW5hdGVzOiB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmdldFBvc2l0aW9uKGRhdHVtKSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgICAgIC4uLihkYXR1bSA/PyB7fSksXG4gICAgICAgICAgICBsYXllcjogdGhpcyxcbiAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgICAgfSksXG4gICAgfSBhcyBGZWF0dXJlQ29sbGVjdGlvbjtcbiAgICB0aGlzLmxheWVyKCkuc2V0WkluZGV4KHRoaXMuY29tYmluZWRPcHRpb25zKCkub3JkZXIgPz8gMCk7XG4gICAgdGhpcy5zb3VyY2UoKS5jbGVhcih0cnVlKTtcbiAgICB0aGlzLnNvdXJjZSgpLmFkZEZlYXR1cmVzKFxuICAgICAgbmV3IEdlb0pTT04oKS5yZWFkRmVhdHVyZXMoZGF0YVdpdGhMYXllciwge1xuICAgICAgICBmZWF0dXJlUHJvamVjdGlvbjogJ0VQU0c6Mzg1NycsIC8vIEVuc3VyZSB0aGUgcHJvamVjdGlvbiBtYXRjaGVzIHlvdXIgbWFwJ3MgcHJvamVjdGlvblxuICAgICAgfSkgYXMgYW55XG4gICAgKTtcbiAgfVxufVxuIl19