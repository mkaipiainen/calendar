import { Feature as OlFeature } from 'ol';
import { OpenlayersBaseLayerComponent } from './openlayers-base-layer.component';
import { OuiOpenlayersTileLayerOptions } from '../types';
import TileLayer from 'ol/layer/Tile';
import { TileWMS, WMTS } from 'ol/source';
import * as i0 from "@angular/core";
export declare class OpenlayersTileLayerComponent extends OpenlayersBaseLayerComponent<OuiOpenlayersTileLayerOptions> {
    options: import("@angular/core").InputSignal<OuiOpenlayersTileLayerOptions>;
    olLayer: import("@angular/core").WritableSignal<TileLayer<WMTS | TileWMS> | undefined>;
    combinedOptions: import("@angular/core").Signal<OuiOpenlayersTileLayerOptions>;
    sourceWMS: import("@angular/core").WritableSignal<TileWMS | undefined>;
    sourceWMTS: import("@angular/core").WritableSignal<WMTS | undefined>;
    activeSource: import("@angular/core").Signal<{
        id: string;
        source: TileWMS;
    } | {
        id: string;
        source: WMTS;
    } | undefined>;
    source: import("@angular/core").WritableSignal<WMTS | TileWMS | undefined>;
    layer: import("@angular/core").WritableSignal<TileLayer<WMTS | TileWMS>>;
    constructor();
    onHover(feature: OlFeature): void;
    onUnHover(feature: OlFeature): void;
    onAdd(): void;
    updateLayer(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpenlayersTileLayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpenlayersTileLayerComponent, "oui-openlayers-tile-layer", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=openlayers-tile-layer.component.d.ts.map