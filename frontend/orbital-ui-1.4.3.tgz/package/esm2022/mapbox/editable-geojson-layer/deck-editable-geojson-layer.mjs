import { EditableGeoJsonLayer } from '@nebula.gl/layers';
import { ModifyMode } from '@nebula.gl/edit-modes';
import { ViewMode } from '@nebula.gl/edit-modes';
import { DrawPolygonMode } from '@nebula.gl/edit-modes';
import { MeasureDistanceMode } from '@nebula.gl/edit-modes';
import { DrawRectangleMode } from '@nebula.gl/edit-modes';
import { DrawPointMode } from '@nebula.gl/edit-modes';
import { DrawLineStringMode } from '@nebula.gl/edit-modes';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BindCommonDeckOptions } from '../deck/bind-default-deck-options';
import * as i0 from "@angular/core";
export const EDITABLE_GEOJSON_LAYER_MODES = {
    MODIFY: ModifyMode,
    VIEW: ViewMode,
    DRAW: DrawPolygonMode,
    MEASURE_DISTANCE: MeasureDistanceMode,
    DRAW_RECTANGLE: DrawRectangleMode,
    DRAW_POINT: DrawPointMode,
    DRAW_LINESTRING: DrawLineStringMode,
};
export class DeckEditableGeoJsonlayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        // @ts-ignore
        return new EditableGeoJsonLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            selectedFeatureIndexes: this.options.selectedFeatureIndexes ?? [],
            mode: this.options.mode,
            // Styles
            modeConfig: this.options.modeConfig ?? {},
            filled: this.options.filled ?? true,
            editHandlePointStrokeWidth: this.options.editHandlePointStrokeWidth ?? 2,
            getEditHandlePointColor: this.options.getEditHandlePointColor ?? [
                255, 0, 0, 255,
            ],
            getEditHandlePointOutlineColor: this.options
                .getEditHandlePointOutlineColor ?? [255, 255, 255, 255],
            pointRadiusMinPixels: this.options.pointRadiusMinPixels ?? 2,
            getEditHandlePointRadius: this.options.getEditHandlePointRadius ?? 8,
            pointRadiusScale: this.options.pointRadiusScale ?? 1,
            getFillColor: this.options.getFillColor
                ? this.options.getFillColor
                : [200, 0, 80, 180],
            getTentativeFillColor: this.options.getTentativeFillColor
                ? this.options.getTentativeFillColor
                : [200, 0, 80, 180],
            autoHighlight: this.options.autoHighlight ?? false,
            onEdit: this.options.onEdit ? this.options.onEdit : () => { },
            pickingRadius: this.options.pickingRadius ?? 10,
            _subLayerProps: this.options._subLayerProps ?? {},
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckEditableGeoJsonlayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckEditableGeoJsonlayer, isStandalone: true, selector: "oui-deck-editable-geojson-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckEditableGeoJsonlayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-editable-geojson-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay1lZGl0YWJsZS1nZW9qc29uLWxheWVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9tYXBib3gvZWRpdGFibGUtZ2VvanNvbi1sYXllci9kZWNrLWVkaXRhYmxlLWdlb2pzb24tbGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLG9CQUFvQixFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFLekQsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ25ELE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQztBQUNqRCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDeEQsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDNUQsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDMUQsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ3RELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQzNELE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM3RCxPQUFPLEVBQUUsdUJBQXVCLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMxRSxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQzs7QUFFMUUsTUFBTSxDQUFDLE1BQU0sNEJBQTRCLEdBQUc7SUFDMUMsTUFBTSxFQUFFLFVBQVU7SUFDbEIsSUFBSSxFQUFFLFFBQVE7SUFDZCxJQUFJLEVBQUUsZUFBZTtJQUNyQixnQkFBZ0IsRUFBRSxtQkFBbUI7SUFDckMsY0FBYyxFQUFFLGlCQUFpQjtJQUNqQyxVQUFVLEVBQUUsYUFBYTtJQUN6QixlQUFlLEVBQUUsa0JBQWtCO0NBQ3BDLENBQUM7QUFTRixNQUFNLE9BQU8sd0JBQXlCLFNBQVEsYUFBc0M7SUFDL0MsT0FBTyxDQUFtQztJQUM3RTtRQUNFLEtBQUssRUFBRSxDQUFDO0lBQ1YsQ0FBQztJQUVNLFFBQVE7UUFDYixhQUFhO1FBQ2IsT0FBTyxJQUFJLG9CQUFvQixDQUFDO1lBQzlCLEdBQUcscUJBQXFCLENBQUMsSUFBSSxDQUFDO1lBQzlCLElBQUksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQVc7WUFDOUIsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsSUFBSSxFQUFFO1lBQ2pFLElBQUksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUk7WUFDdkIsU0FBUztZQUNULFVBQVUsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsSUFBSSxFQUFFO1lBQ3pDLE1BQU0sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sSUFBSSxJQUFJO1lBQ25DLDBCQUEwQixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsMEJBQTBCLElBQUksQ0FBQztZQUN4RSx1QkFBdUIsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLHVCQUF1QixJQUFJO2dCQUMvRCxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsRUFBRSxHQUFHO2FBQ2Y7WUFDRCw4QkFBOEIsRUFBRSxJQUFJLENBQUMsT0FBTztpQkFDekMsOEJBQThCLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUM7WUFDekQsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0IsSUFBSSxDQUFDO1lBQzVELHdCQUF3QixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsd0JBQXdCLElBQUksQ0FBQztZQUNwRSxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixJQUFJLENBQUM7WUFDcEQsWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWTtnQkFDckMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWTtnQkFDM0IsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsR0FBRyxDQUFDO1lBQ3JCLHFCQUFxQixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMscUJBQXFCO2dCQUN2RCxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxxQkFBcUI7Z0JBQ3BDLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLEdBQUcsQ0FBQztZQUNyQixhQUFhLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLElBQUksS0FBSztZQUNsRCxNQUFNLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRSxDQUFDO1lBQzVELGFBQWEsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsSUFBSSxFQUFFO1lBQy9DLGNBQWMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsSUFBSSxFQUFFO1NBQ2xELENBQUMsQ0FBQztJQUNMLENBQUM7dUdBcENVLHdCQUF3QjsyRkFBeEIsd0JBQXdCLGtKQUx6QixFQUFFOzsyRkFLRCx3QkFBd0I7a0JBUHBDLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLGlDQUFpQztvQkFDM0MsUUFBUSxFQUFFLEVBQUU7b0JBQ1osVUFBVSxFQUFFLElBQUk7b0JBQ2hCLE9BQU8sRUFBRSxFQUFFO29CQUNYLGVBQWUsRUFBRSx1QkFBdUIsQ0FBQyxNQUFNO2lCQUNoRDt3REFFb0MsT0FBTztzQkFBekMsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFZGl0YWJsZUdlb0pzb25MYXllciB9IGZyb20gJ0BuZWJ1bGEuZ2wvbGF5ZXJzJztcbmltcG9ydCB7XG4gIElDb21tb25EZWNrTGF5ZXJPcHRpb25zLFxuICBJRGVja0VkaXRhYmxlR2VvSnNvbkxheWVyT3B0aW9ucyxcbn0gZnJvbSAnLi4vdHlwaW5ncyc7XG5pbXBvcnQgeyBNb2RpZnlNb2RlIH0gZnJvbSAnQG5lYnVsYS5nbC9lZGl0LW1vZGVzJztcbmltcG9ydCB7IFZpZXdNb2RlIH0gZnJvbSAnQG5lYnVsYS5nbC9lZGl0LW1vZGVzJztcbmltcG9ydCB7IERyYXdQb2x5Z29uTW9kZSB9IGZyb20gJ0BuZWJ1bGEuZ2wvZWRpdC1tb2Rlcyc7XG5pbXBvcnQgeyBNZWFzdXJlRGlzdGFuY2VNb2RlIH0gZnJvbSAnQG5lYnVsYS5nbC9lZGl0LW1vZGVzJztcbmltcG9ydCB7IERyYXdSZWN0YW5nbGVNb2RlIH0gZnJvbSAnQG5lYnVsYS5nbC9lZGl0LW1vZGVzJztcbmltcG9ydCB7IERyYXdQb2ludE1vZGUgfSBmcm9tICdAbmVidWxhLmdsL2VkaXQtbW9kZXMnO1xuaW1wb3J0IHsgRHJhd0xpbmVTdHJpbmdNb2RlIH0gZnJvbSAnQG5lYnVsYS5nbC9lZGl0LW1vZGVzJztcbmltcG9ydCB7IEJhc2VEZWNrTGF5ZXIgfSBmcm9tICcuLi9iYXNlLWRlY2stbGF5ZXIuY29tcG9uZW50JztcbmltcG9ydCB7IENoYW5nZURldGVjdGlvblN0cmF0ZWd5LCBDb21wb25lbnQsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBCaW5kQ29tbW9uRGVja09wdGlvbnMgfSBmcm9tICcuLi9kZWNrL2JpbmQtZGVmYXVsdC1kZWNrLW9wdGlvbnMnO1xuXG5leHBvcnQgY29uc3QgRURJVEFCTEVfR0VPSlNPTl9MQVlFUl9NT0RFUyA9IHtcbiAgTU9ESUZZOiBNb2RpZnlNb2RlLFxuICBWSUVXOiBWaWV3TW9kZSxcbiAgRFJBVzogRHJhd1BvbHlnb25Nb2RlLFxuICBNRUFTVVJFX0RJU1RBTkNFOiBNZWFzdXJlRGlzdGFuY2VNb2RlLFxuICBEUkFXX1JFQ1RBTkdMRTogRHJhd1JlY3RhbmdsZU1vZGUsXG4gIERSQVdfUE9JTlQ6IERyYXdQb2ludE1vZGUsXG4gIERSQVdfTElORVNUUklORzogRHJhd0xpbmVTdHJpbmdNb2RlLFxufTtcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLWRlY2stZWRpdGFibGUtZ2VvanNvbi1sYXllcicsXG4gIHRlbXBsYXRlOiAnJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW10sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBEZWNrRWRpdGFibGVHZW9Kc29ubGF5ZXIgZXh0ZW5kcyBCYXNlRGVja0xheWVyPElDb21tb25EZWNrTGF5ZXJPcHRpb25zPiB7XG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pIGRlY2xhcmUgb3B0aW9uczogSURlY2tFZGl0YWJsZUdlb0pzb25MYXllck9wdGlvbnM7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKCk7XG4gIH1cblxuICBwdWJsaWMgZ2V0TGF5ZXIoKSB7XG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHJldHVybiBuZXcgRWRpdGFibGVHZW9Kc29uTGF5ZXIoe1xuICAgICAgLi4uQmluZENvbW1vbkRlY2tPcHRpb25zKHRoaXMpLFxuICAgICAgZGF0YTogdGhpcy5vcHRpb25zLmRhdGEgYXMgYW55LFxuICAgICAgc2VsZWN0ZWRGZWF0dXJlSW5kZXhlczogdGhpcy5vcHRpb25zLnNlbGVjdGVkRmVhdHVyZUluZGV4ZXMgPz8gW10sXG4gICAgICBtb2RlOiB0aGlzLm9wdGlvbnMubW9kZSxcbiAgICAgIC8vIFN0eWxlc1xuICAgICAgbW9kZUNvbmZpZzogdGhpcy5vcHRpb25zLm1vZGVDb25maWcgPz8ge30sXG4gICAgICBmaWxsZWQ6IHRoaXMub3B0aW9ucy5maWxsZWQgPz8gdHJ1ZSxcbiAgICAgIGVkaXRIYW5kbGVQb2ludFN0cm9rZVdpZHRoOiB0aGlzLm9wdGlvbnMuZWRpdEhhbmRsZVBvaW50U3Ryb2tlV2lkdGggPz8gMixcbiAgICAgIGdldEVkaXRIYW5kbGVQb2ludENvbG9yOiB0aGlzLm9wdGlvbnMuZ2V0RWRpdEhhbmRsZVBvaW50Q29sb3IgPz8gW1xuICAgICAgICAyNTUsIDAsIDAsIDI1NSxcbiAgICAgIF0sXG4gICAgICBnZXRFZGl0SGFuZGxlUG9pbnRPdXRsaW5lQ29sb3I6IHRoaXMub3B0aW9uc1xuICAgICAgICAuZ2V0RWRpdEhhbmRsZVBvaW50T3V0bGluZUNvbG9yID8/IFsyNTUsIDI1NSwgMjU1LCAyNTVdLFxuICAgICAgcG9pbnRSYWRpdXNNaW5QaXhlbHM6IHRoaXMub3B0aW9ucy5wb2ludFJhZGl1c01pblBpeGVscyA/PyAyLFxuICAgICAgZ2V0RWRpdEhhbmRsZVBvaW50UmFkaXVzOiB0aGlzLm9wdGlvbnMuZ2V0RWRpdEhhbmRsZVBvaW50UmFkaXVzID8/IDgsXG4gICAgICBwb2ludFJhZGl1c1NjYWxlOiB0aGlzLm9wdGlvbnMucG9pbnRSYWRpdXNTY2FsZSA/PyAxLFxuICAgICAgZ2V0RmlsbENvbG9yOiB0aGlzLm9wdGlvbnMuZ2V0RmlsbENvbG9yXG4gICAgICAgID8gdGhpcy5vcHRpb25zLmdldEZpbGxDb2xvclxuICAgICAgICA6IFsyMDAsIDAsIDgwLCAxODBdLFxuICAgICAgZ2V0VGVudGF0aXZlRmlsbENvbG9yOiB0aGlzLm9wdGlvbnMuZ2V0VGVudGF0aXZlRmlsbENvbG9yXG4gICAgICAgID8gdGhpcy5vcHRpb25zLmdldFRlbnRhdGl2ZUZpbGxDb2xvclxuICAgICAgICA6IFsyMDAsIDAsIDgwLCAxODBdLFxuICAgICAgYXV0b0hpZ2hsaWdodDogdGhpcy5vcHRpb25zLmF1dG9IaWdobGlnaHQgPz8gZmFsc2UsXG4gICAgICBvbkVkaXQ6IHRoaXMub3B0aW9ucy5vbkVkaXQgPyB0aGlzLm9wdGlvbnMub25FZGl0IDogKCkgPT4ge30sXG4gICAgICBwaWNraW5nUmFkaXVzOiB0aGlzLm9wdGlvbnMucGlja2luZ1JhZGl1cyA/PyAxMCxcbiAgICAgIF9zdWJMYXllclByb3BzOiB0aGlzLm9wdGlvbnMuX3N1YkxheWVyUHJvcHMgPz8ge30sXG4gICAgfSk7XG4gIH1cbn1cbiJdfQ==