export * from './spinner.component';
//# sourceMappingURL=public-api.d.ts.map