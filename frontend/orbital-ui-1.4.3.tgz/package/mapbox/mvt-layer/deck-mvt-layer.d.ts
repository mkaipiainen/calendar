import { MVTLayer } from '@deck.gl/geo-layers/typed';
import { ICommonDeckLayerOptions, IDeckMvtLayerOptions } from '../typings';
import { BaseDeckLayer } from '../base-deck-layer.component';
import * as i0 from "@angular/core";
export declare class DeckMvtLayer extends BaseDeckLayer<ICommonDeckLayerOptions> {
    options: IDeckMvtLayerOptions & ICommonDeckLayerOptions;
    constructor();
    getLayer(): MVTLayer<{
        onDataLoad: any;
        data: string;
        getLineColor: import("orbital-ui/core").RGBA | ((d: any) => [number, number, number, number]);
        getFillColor: import("orbital-ui/core").RGBA | ((d: any) => [number, number, number, number]);
        minZoom: number;
        maxZoom: number;
        renderSubLayers: (props: any) => any;
        uniqueIdProperty: string;
        highlightedFeatureId: string | null;
        binary: boolean;
        loaders: any[];
        lineWidthMinPixels: number | ((d: any) => number);
        getLineWidth: number | ((d: any) => number);
        id: string;
        autoHighlight: boolean;
        transitions: {
            [x: string]: number | {
                duration: number;
                easing: any;
            };
        };
        highlightColor: import("orbital-ui/core").RGBA | ((d: any) => import("orbital-ui/core").RGBA);
        isEnabled: boolean;
        _dataDiff: (oldData: any, newData: any) => [{
            startRow: number;
            endRow: number;
        }];
        onClick: (object: any, event: any) => void;
        onHover: (event: any) => boolean;
        updateTriggers: any;
        dataComparator: (<LayerDataT = import("@deck.gl/core/typed").LayerData<unknown>>(newData: LayerDataT, oldData?: LayerDataT | undefined) => boolean) | null;
        getCursor: (data: {
            isHovering: boolean;
            isDragging: boolean;
        }) => string;
        order: number;
        loadOptions: any;
        visible: boolean;
        opacity: number;
        extensions: any[];
        pickable: boolean;
        getDashArray: [number, number];
        dashJustified: boolean;
        dashGapPickable: boolean;
        getOffset: number | (() => number);
        clipBounds: [number, number, number, number];
        maskId: string;
        maskByInstance: boolean;
        maskInverted: boolean;
        operation: "mask";
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeckMvtLayer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeckMvtLayer, "oui-deck-mvt-layer", never, { "options": { "alias": "options"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=deck-mvt-layer.d.ts.map