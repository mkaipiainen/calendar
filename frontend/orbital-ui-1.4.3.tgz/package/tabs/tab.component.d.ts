import { AfterViewInit, ChangeDetectorRef, DestroyRef, ElementRef, TemplateRef } from '@angular/core';
import { OuiTabsService } from './tabs.service';
import { OuiTabOptions } from './tabs.component';
import { Router } from '@angular/router';
import * as i0 from "@angular/core";
export declare class OuiTabComponent implements AfterViewInit {
    private tabService;
    elementRef: ElementRef;
    private cdr;
    private destroyRef;
    private router;
    titleTemplate: TemplateRef<any>;
    tabContentTemplate: TemplateRef<any>;
    title: string;
    tabTitleTemplate: TemplateRef<any>;
    parentId: string;
    id: string;
    disabled: boolean;
    isActive: boolean;
    options: OuiTabOptions | null;
    constructor(tabService: OuiTabsService, elementRef: ElementRef, cdr: ChangeDetectorRef, destroyRef: DestroyRef, router: Router);
    ngAfterViewInit(): void;
    setOptions(options: OuiTabOptions): void;
    selectTab(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiTabComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiTabComponent, "oui-tab", never, { "title": { "alias": "title"; "required": false; }; "tabTitleTemplate": { "alias": "tabTitleTemplate"; "required": false; }; "parentId": { "alias": "parentId"; "required": false; }; "id": { "alias": "id"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, {}, never, ["*"], true, never>;
}
//# sourceMappingURL=tab.component.d.ts.map