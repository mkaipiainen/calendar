import * as i0 from '@angular/core';
import { EventEmitter, Component, ChangeDetectionStrategy, Input, Output } from '@angular/core';
import { OuiIconComponent } from 'orbital-ui/icon';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { OuiSpinnerComponent } from 'orbital-ui/spinner';
import { OuiRippleDirective } from 'orbital-ui/ripple';
import { merge } from 'lodash-es';

/**
 * Creates a clickable icon, with a little hover effect to signal clickability.
 *
 *  example use:
 *
 *  <oui-icon-button color="primary" icon="assets/icons/my-example-icon.svg" [options]="{fillColor: 'color-white'}" (onClick)="onIconClick($event)"></oui-icon-button>
 */
class OuiIconButtonComponent {
    cdr;
    /**
     *   The path to the icon
     */
    icon = '';
    /**
     *   if set to true, icon is replaced with a loading spinner
     */
    isLoading = false;
    /**
     *   The options of the icon
     */
    set options(newOptions) {
        this.combinedOptions = merge({ ...this.defaultOptions }, { ...newOptions });
    }
    get options() {
        return this.combinedOptions;
    }
    /**
     *   Emitted when icon is clicked. Usually you want to tie a function to this.
     */
    onClick = new EventEmitter();
    defaultOptions = {
        fillColor: 'color-primary-icons',
        strokeColor: 'color-primary-icons',
        size: '24px',
    };
    combinedOptions = {
        ...this.defaultOptions,
    };
    spinnerColor = '';
    spinnerSize = '';
    constructor(cdr) {
        this.cdr = cdr;
    }
    ngAfterViewInit() {
        if (Array.isArray(this.options.fillColor)) {
            this.spinnerColor = `rgba(${this.options.fillColor[0]}, ${this.options.fillColor[1]}, ${this.options.fillColor[2]}, ${this.options.fillColor.length > 3
                ? this.options.fillColor[3] / 255
                : '1'})`;
        }
        else {
            this.spinnerColor = this.options.fillColor || 'color-primary-text';
        }
        this.spinnerSize = this.options.size ?? '1.6rem';
        this.cdr.detectChanges();
    }
    emitClick(event) {
        this.onClick.emit(event);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiIconButtonComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiIconButtonComponent, isStandalone: true, selector: "oui-icon-button", inputs: { icon: "icon", isLoading: "isLoading", options: "options" }, outputs: { onClick: "onClick" }, ngImport: i0, template: "<div\n  class=\"oui-icon-button-container\"\n  (click)=\"emitClick($event)\"\n  [ngClass]=\"{ disabled: isLoading }\"\n  ouiRipple\n  >\n  @if (!isLoading) {\n    <oui-icon [options]=\"options\" [icon]=\"icon\"></oui-icon>\n  }\n  @if (isLoading) {\n    <oui-spinner\n      type=\"solid\"\n      [color]=\"spinnerColor\"\n      [size]=\"spinnerSize\"\n    ></oui-spinner>\n  }\n</div>\n", styles: [":host{height:100%;width:100%;display:flex;justify-content:center;align-items:center}:host .oui-icon-button-container{border-width:var(--oui-icon-button-border-width);border-style:var(--oui-icon-button-border-style);border-color:var(--oui-icon-button-border-color);border-radius:var(--oui-icon-button-border-radius);background-color:var(--oui-icon-button-background-color);transition:background-color .3s;display:flex;justify-content:center;align-items:center;padding:var(--oui-icon-button-padding);flex:1;box-sizing:border-box;height:100%;width:100%}:host .oui-icon-button-container oui-spinner{width:100%;height:100%}:host .oui-icon-button-container.disabled{pointer-events:none;opacity:.7}:host .oui-icon-button-container:hover{background-color:var(--oui-icon-button-background-color-hover);cursor:pointer}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "component", type: OuiSpinnerComponent, selector: "oui-spinner", inputs: ["color", "size", "type"] }, { kind: "directive", type: OuiRippleDirective, selector: "[ouiRipple]" }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiIconButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-icon-button', standalone: true, imports: [
                        OuiIconComponent,
                        OuiSpinnerComponent,
                        OuiRippleDirective,
                        CommonModule,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"oui-icon-button-container\"\n  (click)=\"emitClick($event)\"\n  [ngClass]=\"{ disabled: isLoading }\"\n  ouiRipple\n  >\n  @if (!isLoading) {\n    <oui-icon [options]=\"options\" [icon]=\"icon\"></oui-icon>\n  }\n  @if (isLoading) {\n    <oui-spinner\n      type=\"solid\"\n      [color]=\"spinnerColor\"\n      [size]=\"spinnerSize\"\n    ></oui-spinner>\n  }\n</div>\n", styles: [":host{height:100%;width:100%;display:flex;justify-content:center;align-items:center}:host .oui-icon-button-container{border-width:var(--oui-icon-button-border-width);border-style:var(--oui-icon-button-border-style);border-color:var(--oui-icon-button-border-color);border-radius:var(--oui-icon-button-border-radius);background-color:var(--oui-icon-button-background-color);transition:background-color .3s;display:flex;justify-content:center;align-items:center;padding:var(--oui-icon-button-padding);flex:1;box-sizing:border-box;height:100%;width:100%}:host .oui-icon-button-container oui-spinner{width:100%;height:100%}:host .oui-icon-button-container.disabled{pointer-events:none;opacity:.7}:host .oui-icon-button-container:hover{background-color:var(--oui-icon-button-background-color-hover);cursor:pointer}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { icon: [{
                type: Input
            }], isLoading: [{
                type: Input
            }], options: [{
                type: Input
            }], onClick: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiIconButtonComponent };
//# sourceMappingURL=orbital-ui-icon-button.mjs.map
