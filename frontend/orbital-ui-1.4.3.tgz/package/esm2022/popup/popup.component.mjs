import { Component, inject } from '@angular/core';
import { OuiPopupService } from './popup.service';
import * as i0 from "@angular/core";
/**
 * This component should not be used directly, but instead extended in each popup component.
 * Popups can be opened with ouiPopupService.
 */
export class OuiPopupComponent {
    ouiPopupService = inject(OuiPopupService);
    popup;
    constructor() { }
    close() {
        this.ouiPopupService.dispose(this.popup.id);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiPopupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiPopupComponent, isStandalone: true, selector: "oui-popup", ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiPopupComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-popup',
                    template: '',
                    standalone: true,
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9wdXAuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9wb3B1cC9wb3B1cC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDbEQsT0FBTyxFQUFVLGVBQWUsRUFBRSxNQUFNLGlCQUFpQixDQUFDOztBQUUxRDs7O0dBR0c7QUFNSCxNQUFNLE9BQU8saUJBQWlCO0lBQ2xCLGVBQWUsR0FBRyxNQUFNLENBQUMsZUFBZSxDQUFDLENBQUM7SUFDN0MsS0FBSyxDQUFTO0lBRXJCLGdCQUFlLENBQUM7SUFFVCxLQUFLO1FBQ1YsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUM5QyxDQUFDO3VHQVJVLGlCQUFpQjsyRkFBakIsaUJBQWlCLHFFQUhsQixFQUFFOzsyRkFHRCxpQkFBaUI7a0JBTDdCLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLFdBQVc7b0JBQ3JCLFFBQVEsRUFBRSxFQUFFO29CQUNaLFVBQVUsRUFBRSxJQUFJO2lCQUNqQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgaW5qZWN0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJUG9wdXAsIE91aVBvcHVwU2VydmljZSB9IGZyb20gJy4vcG9wdXAuc2VydmljZSc7XG5cbi8qKlxuICogVGhpcyBjb21wb25lbnQgc2hvdWxkIG5vdCBiZSB1c2VkIGRpcmVjdGx5LCBidXQgaW5zdGVhZCBleHRlbmRlZCBpbiBlYWNoIHBvcHVwIGNvbXBvbmVudC5cbiAqIFBvcHVwcyBjYW4gYmUgb3BlbmVkIHdpdGggb3VpUG9wdXBTZXJ2aWNlLlxuICovXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdvdWktcG9wdXAnLFxuICB0ZW1wbGF0ZTogJycsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG59KVxuZXhwb3J0IGNsYXNzIE91aVBvcHVwQ29tcG9uZW50IHtcbiAgcHJvdGVjdGVkIG91aVBvcHVwU2VydmljZSA9IGluamVjdChPdWlQb3B1cFNlcnZpY2UpO1xuICBwdWJsaWMgcG9wdXA6IElQb3B1cDtcblxuICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgcHVibGljIGNsb3NlKCkge1xuICAgIHRoaXMub3VpUG9wdXBTZXJ2aWNlLmRpc3Bvc2UodGhpcy5wb3B1cC5pZCk7XG4gIH1cbn1cbiJdfQ==