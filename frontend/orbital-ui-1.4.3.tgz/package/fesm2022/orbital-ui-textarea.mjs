import * as i0 from '@angular/core';
import { EventEmitter, signal, computed, Component, ChangeDetectionStrategy, ViewChild, Input, Output } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { OuiIconComponent } from 'orbital-ui/icon';
import { merge } from 'lodash-es';

/**
 * Component to add input-fields.
 *
 *   Example use:
 *   <oui-textarea [(model)]="model"></oui-input>
 */
class OuiTextareaComponent {
    cdr;
    renderer;
    elementRef;
    textarea;
    autosizeWrapper;
    /**
     *   The model that's bound to the input field
     */
    model;
    /**
     * Options of the input-field. See IOuiInputOptions for more information
     */
    set options(newOptions) {
        this.optionsSignal.set(merge({ ...this.defaultOptions }, { ...newOptions }));
        if (this.resizeListener) {
            this.resizeListener();
            this.resizeListener = undefined;
        }
        if (newOptions.autoSizeOptions?.isEnabled) {
            this.initResizeListener();
        }
    }
    get options() {
        return this.optionsSignal();
    }
    /**
     *   The event emitted when input field changes.
     */
    modelChange = new EventEmitter();
    /**
     *   The event emitted when the hasError-field changes
     */
    hasErrorChange = new EventEmitter();
    defaultOptions = {
        placeholder: '',
        label: '',
        disabled: false,
        disableResize: false,
        hasError: false,
        autoSizeOptions: {
            isEnabled: false,
            maxHeight: undefined,
            minHeight: undefined,
        },
    };
    resizeListener;
    isFocused = signal(false);
    isInitialized = signal(false);
    optionsSignal = signal(this.defaultOptions);
    className = computed(() => {
        return `oui-textarea ${this.optionsSignal().hasError ? 'has-error' : ''} ${this.isInitialized() ? 'initialized' : ''} ${this.optionsSignal().disableResize ? 'disable-resize' : ''}`;
    });
    constructor(cdr, renderer, elementRef) {
        this.cdr = cdr;
        this.renderer = renderer;
        this.elementRef = elementRef;
    }
    onModelChange() {
        this.modelChange.emit(this.model);
    }
    updateHeight() {
        if (this.options.autoSizeOptions?.isEnabled && this.textarea) {
            this.textarea.nativeElement.style.height = '1px';
            this.textarea.nativeElement.style.height =
                25 + this.textarea.nativeElement.scrollHeight + 'px';
        }
    }
    initResizeListener() {
        if (this.textarea?.nativeElement) {
            this.textarea.nativeElement.setAttribute('style', 'height:' +
                this.textarea.nativeElement.scrollHeight +
                'px;overflow-y:hidden;');
            this.resizeListener = this.renderer.listen(this.textarea.nativeElement, 'input', this.onInput.bind(this));
        }
    }
    onInput() {
        this.textarea.nativeElement.style.height = 0;
        this.textarea.nativeElement.style.height =
            this.textarea.nativeElement.scrollHeight + 'px';
    }
    ngAfterViewInit() {
        this.isFocused.set(!!this.model);
        if (this.isFocused()) {
            this.renderer.addClass(this.elementRef.nativeElement, 'focused');
        }
        this.cdr.detectChanges();
        if (this.options.autoSizeOptions?.isEnabled && this.autosizeWrapper) {
            this.initResizeListener();
            if (this.options.autoSizeOptions.maxHeight) {
                this.autosizeWrapper.nativeElement.style.maxHeight =
                    this.options.autoSizeOptions.maxHeight;
            }
            if (this.options.autoSizeOptions.minHeight) {
                this.autosizeWrapper.nativeElement.style.minHeight =
                    this.options.autoSizeOptions.minHeight;
            }
        }
        setTimeout(() => {
            this.updateHeight();
            this.isInitialized.set(true);
        }, 400);
    }
    setFocus(value) {
        if (!this.model && !value) {
            this.isFocused.set(false);
            this.modelChange.emit(this.model);
            this.renderer.removeClass(this.elementRef.nativeElement, 'focused');
        }
        else if (value) {
            this.isFocused.set(true);
            this.setError(false);
            this.renderer.addClass(this.elementRef.nativeElement, 'focused');
        }
        this.cdr.detectChanges();
    }
    setError(value) {
        this.options.hasError = value;
        this.hasErrorChange.emit(value);
        this.cdr.detectChanges();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTextareaComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i0.Renderer2 }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiTextareaComponent, isStandalone: true, selector: "oui-textarea", inputs: { model: "model", options: "options" }, outputs: { modelChange: "modelChange", hasErrorChange: "hasErrorChange" }, viewQueries: [{ propertyName: "textarea", first: true, predicate: ["textarea"], descendants: true }, { propertyName: "autosizeWrapper", first: true, predicate: ["autosizeWrapper"], descendants: true }], ngImport: i0, template: "<div class=\"{{ className() }}\" (click)=\"setFocus(true)\">\n  @if (optionsSignal().label) {\n    <div class=\"oui-textarea-label\">\n      {{ optionsSignal().label }}\n    </div>\n  }\n  <div class=\"textarea-wrapper\">\n    @if (!optionsSignal().autoSizeOptions?.isEnabled) {\n      <textarea\n        class=\"textarea\"\n        [placeholder]=\"optionsSignal().placeholder ?? ''\"\n        (focus)=\"setFocus(true)\"\n        (blur)=\"setFocus(false)\"\n        #textarea\n        [disabled]=\"optionsSignal().disabled ?? false\"\n        [(ngModel)]=\"model\"\n        (input)=\"onModelChange()\"\n      ></textarea>\n    }\n    @if (optionsSignal().autoSizeOptions?.isEnabled) {\n      <div\n        #autosizeWrapper class=\"grow-wrap oui-scrollbar oui-scrollbar-auto\">\n        <textarea\n          class=\"textarea\"\n          [placeholder]=\"optionsSignal().placeholder ?? ''\"\n          (focus)=\"setFocus(true)\"\n          (blur)=\"setFocus(false)\"\n          #textarea\n          [disabled]=\"optionsSignal().disabled ?? false\"\n          [(ngModel)]=\"model\"\n          (input)=\"onModelChange()\"\n        ></textarea>\n      </div>\n    }\n  </div>\n</div>\n", styles: [":host{flex:1;display:block;border-radius:var(--border-radius-default);border-color:var(--oui-textarea-border-color);border-width:var(--oui-textarea-border-width);border-style:var(--oui-textarea-border-style);overflow:hidden}:host.focused{border-color:var(--oui-textarea-border-active-color)}:host.focused .oui-textarea .oui-textarea-label{top:-1.5rem;left:0rem;font-size:9px;color:var(--oui-textarea-text-color-focused)}:host .oui-textarea{position:relative;display:flex;height:100%;transition:none;background-color:var(--oui-textarea-background-color)}:host .oui-textarea.disable-resize textarea{resize:none}:host .oui-textarea .grow-wrap{display:grid;width:100%}:host .oui-textarea .grow-wrap:after{content:attr(data-replicated-value) \" \";white-space:pre-wrap;visibility:hidden}:host .oui-textarea .grow-wrap>textarea{resize:none;overflow:hidden}:host .oui-textarea .grow-wrap>textarea,:host .oui-textarea .grow-wrap:after{padding:.5rem;font:inherit;grid-area:1/1/2/2}:host .oui-textarea .textarea{width:100%;max-width:100%;background-color:transparent}:host .oui-textarea .textarea-wrapper .end-icon{margin-right:1rem}:host .oui-textarea *{transition:none}:host .oui-textarea.initialized{transition:background-color .3s}:host .oui-textarea.initialized *{transition:background-color .3s}:host .oui-textarea .oui-textarea-label{position:absolute;top:0;left:.5rem;color:var(--oui-textarea-text-color);transition:top .2s,left .2s,color .3s,font-size .2s;font-size:11px;pointer-events:none;font-family:var(--font-primary);z-index:1}:host .oui-textarea .textarea-wrapper{display:flex;align-items:center;position:relative;flex:1;overflow:hidden}:host .oui-textarea .textarea-wrapper .grow-wrap textarea{padding:0}:host .oui-textarea .textarea-wrapper textarea{outline:none;border:none;flex:1;height:100%;font-family:var(--font-primary);font-size:13px;padding:1rem;color:var(--oui-textarea-text-color)}:host .oui-textarea .textarea-wrapper textarea.no-padding{padding:0}:host .oui-textarea .textarea-wrapper textarea.autosize{position:absolute;width:100%}:host .oui-textarea.has-error{outline:1px solid var(--color-danger)}:host .oui-textarea.has-error .oui-textarea-label{color:var(--color-danger)}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTextareaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-textarea', standalone: true, imports: [FormsModule, OuiIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"{{ className() }}\" (click)=\"setFocus(true)\">\n  @if (optionsSignal().label) {\n    <div class=\"oui-textarea-label\">\n      {{ optionsSignal().label }}\n    </div>\n  }\n  <div class=\"textarea-wrapper\">\n    @if (!optionsSignal().autoSizeOptions?.isEnabled) {\n      <textarea\n        class=\"textarea\"\n        [placeholder]=\"optionsSignal().placeholder ?? ''\"\n        (focus)=\"setFocus(true)\"\n        (blur)=\"setFocus(false)\"\n        #textarea\n        [disabled]=\"optionsSignal().disabled ?? false\"\n        [(ngModel)]=\"model\"\n        (input)=\"onModelChange()\"\n      ></textarea>\n    }\n    @if (optionsSignal().autoSizeOptions?.isEnabled) {\n      <div\n        #autosizeWrapper class=\"grow-wrap oui-scrollbar oui-scrollbar-auto\">\n        <textarea\n          class=\"textarea\"\n          [placeholder]=\"optionsSignal().placeholder ?? ''\"\n          (focus)=\"setFocus(true)\"\n          (blur)=\"setFocus(false)\"\n          #textarea\n          [disabled]=\"optionsSignal().disabled ?? false\"\n          [(ngModel)]=\"model\"\n          (input)=\"onModelChange()\"\n        ></textarea>\n      </div>\n    }\n  </div>\n</div>\n", styles: [":host{flex:1;display:block;border-radius:var(--border-radius-default);border-color:var(--oui-textarea-border-color);border-width:var(--oui-textarea-border-width);border-style:var(--oui-textarea-border-style);overflow:hidden}:host.focused{border-color:var(--oui-textarea-border-active-color)}:host.focused .oui-textarea .oui-textarea-label{top:-1.5rem;left:0rem;font-size:9px;color:var(--oui-textarea-text-color-focused)}:host .oui-textarea{position:relative;display:flex;height:100%;transition:none;background-color:var(--oui-textarea-background-color)}:host .oui-textarea.disable-resize textarea{resize:none}:host .oui-textarea .grow-wrap{display:grid;width:100%}:host .oui-textarea .grow-wrap:after{content:attr(data-replicated-value) \" \";white-space:pre-wrap;visibility:hidden}:host .oui-textarea .grow-wrap>textarea{resize:none;overflow:hidden}:host .oui-textarea .grow-wrap>textarea,:host .oui-textarea .grow-wrap:after{padding:.5rem;font:inherit;grid-area:1/1/2/2}:host .oui-textarea .textarea{width:100%;max-width:100%;background-color:transparent}:host .oui-textarea .textarea-wrapper .end-icon{margin-right:1rem}:host .oui-textarea *{transition:none}:host .oui-textarea.initialized{transition:background-color .3s}:host .oui-textarea.initialized *{transition:background-color .3s}:host .oui-textarea .oui-textarea-label{position:absolute;top:0;left:.5rem;color:var(--oui-textarea-text-color);transition:top .2s,left .2s,color .3s,font-size .2s;font-size:11px;pointer-events:none;font-family:var(--font-primary);z-index:1}:host .oui-textarea .textarea-wrapper{display:flex;align-items:center;position:relative;flex:1;overflow:hidden}:host .oui-textarea .textarea-wrapper .grow-wrap textarea{padding:0}:host .oui-textarea .textarea-wrapper textarea{outline:none;border:none;flex:1;height:100%;font-family:var(--font-primary);font-size:13px;padding:1rem;color:var(--oui-textarea-text-color)}:host .oui-textarea .textarea-wrapper textarea.no-padding{padding:0}:host .oui-textarea .textarea-wrapper textarea.autosize{position:absolute;width:100%}:host .oui-textarea.has-error{outline:1px solid var(--color-danger)}:host .oui-textarea.has-error .oui-textarea-label{color:var(--color-danger)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i0.Renderer2 }, { type: i0.ElementRef }], propDecorators: { textarea: [{
                type: ViewChild,
                args: ['textarea']
            }], autosizeWrapper: [{
                type: ViewChild,
                args: ['autosizeWrapper']
            }], model: [{
                type: Input
            }], options: [{
                type: Input
            }], modelChange: [{
                type: Output
            }], hasErrorChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiTextareaComponent };
//# sourceMappingURL=orbital-ui-textarea.mjs.map
