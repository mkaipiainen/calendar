import { MVTLayer } from '@deck.gl/geo-layers/typed';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { BindCommonDeckOptions } from '../deck/bind-default-deck-options';
import * as i0 from "@angular/core";
export class DeckMvtLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new MVTLayer({
            ...BindCommonDeckOptions(this),
            onDataLoad: this.options.onDataLoad,
            data: this.options.data,
            getLineColor: this.options.getLineColor,
            getFillColor: this.options.getFillColor,
            minZoom: this.options.minZoom,
            maxZoom: this.options.maxZoom,
            renderSubLayers: this.options.renderSubLayers,
            uniqueIdProperty: this.options.uniqueIdProperty,
            highlightedFeatureId: this.options.highlightedFeatureId,
            binary: this.options.binary,
            loaders: this.options.loaders,
            lineWidthMinPixels: this.options.lineWidthMinPixels,
            getLineWidth: this.options.getLineWidth,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckMvtLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckMvtLayer, isStandalone: true, selector: "oui-deck-mvt-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckMvtLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-mvt-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay1tdnQtbGF5ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL21hcGJveC9tdnQtbGF5ZXIvZGVjay1tdnQtbGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFFBQVEsRUFBaUIsTUFBTSwyQkFBMkIsQ0FBQztBQUVwRSxPQUFPLEVBQUUsdUJBQXVCLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMxRSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sOEJBQThCLENBQUM7QUFDN0QsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sbUNBQW1DLENBQUM7O0FBUzFFLE1BQU0sT0FBTyxZQUFhLFNBQVEsYUFBc0M7SUFDbkMsT0FBTyxDQUNoQjtJQUMxQjtRQUNFLEtBQUssRUFBRSxDQUFDO0lBQ1YsQ0FBQztJQUVNLFFBQVE7UUFDYixPQUFPLElBQUksUUFBUSxDQUFDO1lBQ2xCLEdBQUcscUJBQXFCLENBQUMsSUFBSSxDQUFDO1lBQzlCLFVBQVUsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVU7WUFDbkMsSUFBSSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSTtZQUN2QixZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZO1lBQ3ZDLFlBQVksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVk7WUFDdkMsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTztZQUM3QixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPO1lBQzdCLGVBQWUsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWU7WUFDN0MsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0I7WUFDL0Msb0JBQW9CLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxvQkFBb0I7WUFDdkQsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTTtZQUMzQixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPO1lBQzdCLGtCQUFrQixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsa0JBQWtCO1lBQ25ELFlBQVksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVk7U0FDeEMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQzt1R0F4QlUsWUFBWTsyRkFBWixZQUFZLHFJQUxiLEVBQUU7OzJGQUtELFlBQVk7a0JBUHhCLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLG9CQUFvQjtvQkFDOUIsUUFBUSxFQUFFLEVBQUU7b0JBQ1osVUFBVSxFQUFFLElBQUk7b0JBQ2hCLE9BQU8sRUFBRSxFQUFFO29CQUNYLGVBQWUsRUFBRSx1QkFBdUIsQ0FBQyxNQUFNO2lCQUNoRDt3REFFb0MsT0FBTztzQkFBekMsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNVlRMYXllciwgTVZUTGF5ZXJQcm9wcyB9IGZyb20gJ0BkZWNrLmdsL2dlby1sYXllcnMvdHlwZWQnO1xuaW1wb3J0IHsgSUNvbW1vbkRlY2tMYXllck9wdGlvbnMsIElEZWNrTXZ0TGF5ZXJPcHRpb25zIH0gZnJvbSAnLi4vdHlwaW5ncyc7XG5pbXBvcnQgeyBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSwgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURlY2tMYXllciB9IGZyb20gJy4uL2Jhc2UtZGVjay1sYXllci5jb21wb25lbnQnO1xuaW1wb3J0IHsgQmluZENvbW1vbkRlY2tPcHRpb25zIH0gZnJvbSAnLi4vZGVjay9iaW5kLWRlZmF1bHQtZGVjay1vcHRpb25zJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLWRlY2stbXZ0LWxheWVyJyxcbiAgdGVtcGxhdGU6ICcnLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIERlY2tNdnRMYXllciBleHRlbmRzIEJhc2VEZWNrTGF5ZXI8SUNvbW1vbkRlY2tMYXllck9wdGlvbnM+IHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSkgZGVjbGFyZSBvcHRpb25zOiBJRGVja012dExheWVyT3B0aW9ucyAmXG4gICAgSUNvbW1vbkRlY2tMYXllck9wdGlvbnM7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKCk7XG4gIH1cblxuICBwdWJsaWMgZ2V0TGF5ZXIoKSB7XG4gICAgcmV0dXJuIG5ldyBNVlRMYXllcih7XG4gICAgICAuLi5CaW5kQ29tbW9uRGVja09wdGlvbnModGhpcyksXG4gICAgICBvbkRhdGFMb2FkOiB0aGlzLm9wdGlvbnMub25EYXRhTG9hZCxcbiAgICAgIGRhdGE6IHRoaXMub3B0aW9ucy5kYXRhLFxuICAgICAgZ2V0TGluZUNvbG9yOiB0aGlzLm9wdGlvbnMuZ2V0TGluZUNvbG9yLFxuICAgICAgZ2V0RmlsbENvbG9yOiB0aGlzLm9wdGlvbnMuZ2V0RmlsbENvbG9yLFxuICAgICAgbWluWm9vbTogdGhpcy5vcHRpb25zLm1pblpvb20sXG4gICAgICBtYXhab29tOiB0aGlzLm9wdGlvbnMubWF4Wm9vbSxcbiAgICAgIHJlbmRlclN1YkxheWVyczogdGhpcy5vcHRpb25zLnJlbmRlclN1YkxheWVycyxcbiAgICAgIHVuaXF1ZUlkUHJvcGVydHk6IHRoaXMub3B0aW9ucy51bmlxdWVJZFByb3BlcnR5LFxuICAgICAgaGlnaGxpZ2h0ZWRGZWF0dXJlSWQ6IHRoaXMub3B0aW9ucy5oaWdobGlnaHRlZEZlYXR1cmVJZCxcbiAgICAgIGJpbmFyeTogdGhpcy5vcHRpb25zLmJpbmFyeSxcbiAgICAgIGxvYWRlcnM6IHRoaXMub3B0aW9ucy5sb2FkZXJzLFxuICAgICAgbGluZVdpZHRoTWluUGl4ZWxzOiB0aGlzLm9wdGlvbnMubGluZVdpZHRoTWluUGl4ZWxzLFxuICAgICAgZ2V0TGluZVdpZHRoOiB0aGlzLm9wdGlvbnMuZ2V0TGluZVdpZHRoLFxuICAgIH0pO1xuICB9XG59XG4iXX0=