import { AfterViewInit, DestroyRef, ElementRef, ViewContainerRef } from '@angular/core';
import { MAIN_SIDEBAR_SECTION_TYPES, OuiMainSidebarService } from '../main-sidebar.service';
import { IOuiIconOptions } from 'orbital-ui/icon';
import * as i0 from "@angular/core";
export type OuiMainSidebarActionSectionOptions = {
    icon: string;
    iconOptions?: IOuiIconOptions;
    id: string;
    type: typeof MAIN_SIDEBAR_SECTION_TYPES.ACTION;
    onClick: () => void;
    label: string;
    isActive?: boolean;
};
/**
 * Action-section for the main sidebar. Not used manually, only instantiated dynamically by the oui-main-sidebar-service
 * Options can be passed via the addActionSection-method of the oui-main-sidebar-service.
 *
 * @Input() options: IOuiMainSidebarActionSectionOptions
 */
export declare class OuiMainSidebarActionSectionComponent implements AfterViewInit {
    private ouiMainSidebarService;
    private destroyRef;
    subSubSection: ElementRef;
    componentContainerVCR: ViewContainerRef;
    options: import("@angular/core").InputSignal<OuiMainSidebarActionSectionOptions>;
    isOpen: import("@angular/core").WritableSignal<boolean>;
    constructor(ouiMainSidebarService: OuiMainSidebarService, destroyRef: DestroyRef);
    onClick(): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiMainSidebarActionSectionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiMainSidebarActionSectionComponent, "oui-main-sidebar-action-section", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=main-sidebar-action-section.component.d.ts.map