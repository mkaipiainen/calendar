import { Observable } from 'rxjs';
import { OuiMultiSelectComponent } from './multi-select/multi-select.component';
import { OuiSelectComponent } from './select-component/select.component';
import * as i0 from "@angular/core";
/**
 * Service that keeps tracks and manages select-components.
 * Has a public method closeAll() that can be used to close all open select-components
 */
export declare class OuiSelectService {
    clickObservable: Observable<PointerEvent>;
    dropdowns: (OuiSelectComponent | OuiMultiSelectComponent)[];
    constructor();
    register(dropdown: OuiSelectComponent | OuiMultiSelectComponent): void;
    closeAll(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiSelectService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiSelectService>;
}
//# sourceMappingURL=select.service.d.ts.map