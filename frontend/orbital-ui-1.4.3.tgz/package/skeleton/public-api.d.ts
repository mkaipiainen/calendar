export * from './skeleton.component';
//# sourceMappingURL=public-api.d.ts.map