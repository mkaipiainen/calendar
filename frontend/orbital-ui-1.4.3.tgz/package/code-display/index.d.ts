/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/code-display" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-code-display.d.ts.map