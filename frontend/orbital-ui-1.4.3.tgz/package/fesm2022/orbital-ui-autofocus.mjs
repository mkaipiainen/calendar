import * as i0 from '@angular/core';
import { input, Directive } from '@angular/core';

class AutofocusDirective {
    host;
    isAutofocusEnabled = input(true);
    constructor(host) {
        this.host = host;
    }
    ngOnInit() {
        if (!this.isAutofocusEnabled()) {
            return;
        }
        let elem = this.host.nativeElement;
        if (elem.tagName === 'INPUT' ||
            elem.tagName === 'TEXTAREA' ||
            elem.tagName === 'BUTTON' ||
            elem.hasAttribute('tabindex')) {
            elem.focus();
        }
        else {
            let nestedElem = elem.querySelector('input,textarea,button,[tabindex]');
            if (nestedElem) {
                nestedElem.focus();
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: AutofocusDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "17.3.1", type: AutofocusDirective, isStandalone: true, selector: "[ouiAutofocus]", inputs: { isAutofocusEnabled: { classPropertyName: "isAutofocusEnabled", publicName: "isAutofocusEnabled", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: AutofocusDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ouiAutofocus]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }] });

/**
 * Generated bundle index. Do not edit.
 */

export { AutofocusDirective };
//# sourceMappingURL=orbital-ui-autofocus.mjs.map
