import { Pipe } from '@angular/core';
import { getMonth } from 'date-fns';
import * as i0 from "@angular/core";
export class MonthShortLabelPipe {
    transform(value, translations) {
        if (!value) {
            return '';
        }
        const month = getMonth(value);
        return translations.months[month].substring(0, 3);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: MonthShortLabelPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: MonthShortLabelPipe, isStandalone: true, name: "monthShortLabel" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: MonthShortLabelPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'monthShortLabel',
                    standalone: true,
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9udGgtc2hvcnQtbGFiZWwucGlwZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvZGF0ZS1waWNrZXIvZGF0ZS1yYW5nZS1waWNrZXIvbW9udGgtc2hvcnQtbGFiZWwucGlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsSUFBSSxFQUFpQixNQUFNLGVBQWUsQ0FBQztBQUNwRCxPQUFPLEVBQVUsUUFBUSxFQUFFLE1BQU0sVUFBVSxDQUFDOztBQU81QyxNQUFNLE9BQU8sbUJBQW1CO0lBQzlCLFNBQVMsQ0FDUCxLQUF1QixFQUN2QixZQUFvQztRQUVwQyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDWCxPQUFPLEVBQUUsQ0FBQztRQUNaLENBQUM7UUFDRCxNQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDOUIsT0FBTyxZQUFZLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFDcEQsQ0FBQzt1R0FWVSxtQkFBbUI7cUdBQW5CLG1CQUFtQjs7MkZBQW5CLG1CQUFtQjtrQkFKL0IsSUFBSTttQkFBQztvQkFDSixJQUFJLEVBQUUsaUJBQWlCO29CQUN2QixVQUFVLEVBQUUsSUFBSTtpQkFDakIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQaXBlLCBQaXBlVHJhbnNmb3JtIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBmb3JtYXQsIGdldE1vbnRoIH0gZnJvbSAnZGF0ZS1mbnMnO1xuaW1wb3J0IHsgSURhdGVMYWJlbFRyYW5zbGF0aW9ucyB9IGZyb20gJy4uL2RhdGUtcGlja2VyL2RhdGUtcGlja2VyLmNvbXBvbmVudCc7XG5cbkBQaXBlKHtcbiAgbmFtZTogJ21vbnRoU2hvcnRMYWJlbCcsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG59KVxuZXhwb3J0IGNsYXNzIE1vbnRoU2hvcnRMYWJlbFBpcGUgaW1wbGVtZW50cyBQaXBlVHJhbnNmb3JtIHtcbiAgdHJhbnNmb3JtKFxuICAgIHZhbHVlOiBEYXRlIHwgdW5kZWZpbmVkLFxuICAgIHRyYW5zbGF0aW9uczogSURhdGVMYWJlbFRyYW5zbGF0aW9uc1xuICApOiBzdHJpbmcge1xuICAgIGlmICghdmFsdWUpIHtcbiAgICAgIHJldHVybiAnJztcbiAgICB9XG4gICAgY29uc3QgbW9udGggPSBnZXRNb250aCh2YWx1ZSk7XG4gICAgcmV0dXJuIHRyYW5zbGF0aW9ucy5tb250aHNbbW9udGhdLnN1YnN0cmluZygwLCAzKTtcbiAgfVxufVxuIl19