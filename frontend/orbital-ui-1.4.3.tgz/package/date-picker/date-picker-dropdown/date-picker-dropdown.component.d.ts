import { ChangeDetectorRef, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { OuiDropdownComponent } from 'orbital-ui/dropdown';
import { IOuiDatePickerOptions } from '../date-picker/date-picker.component';
import * as i0 from "@angular/core";
export interface IOuiDatePickerDropdownOptions {
    datePickerOptions: IOuiDatePickerOptions;
    dropdownOptions?: {
        className?: string;
    };
}
/**
 * Component that adds a dropdown with an oui-datepicker inside it
 *
 */
export declare class OuiDatePickerDropdownComponent implements OnChanges {
    private cdr;
    /**
     *   The date selected in the datepicker
     */
    date: import("@angular/core").ModelSignal<Date | undefined>;
    /**
     *   The options to be passed to the datepicker
     */
    options: IOuiDatePickerDropdownOptions;
    /**
     *   The event emitted when the date in the datepicker changes
     */
    dateChange: EventEmitter<Date | undefined>;
    dropdown: OuiDropdownComponent;
    isOpen: boolean;
    translations: {
        months: string[];
        days: string[];
    };
    constructor(cdr: ChangeDetectorRef);
    onDateChange(date: Date | undefined): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiDatePickerDropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiDatePickerDropdownComponent, "oui-date-picker-dropdown", never, { "date": { "alias": "date"; "required": true; "isSignal": true; }; "options": { "alias": "options"; "required": false; }; }, { "date": "dateChange"; "dateChange": "dateChange"; }, never, never, true, never>;
}
//# sourceMappingURL=date-picker-dropdown.component.d.ts.map