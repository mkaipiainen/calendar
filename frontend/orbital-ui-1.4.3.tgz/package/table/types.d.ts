import { TemplateRef } from '@angular/core';
export interface IScrollTop {
    value: number;
    stringValue: string;
}
export interface IOuiTableData {
    columns: IOuiTableColumn[];
    items: any[];
}
export interface IOuiTableOptions {
    itemHeight?: number;
    hasVirtualScroll?: boolean;
    onItemClick?: (item: any, clickEvent: Event) => void;
    trackBy?: string;
}
export interface IOuiTableCombinedOptions {
    itemHeight: number;
    hasVirtualScroll: boolean;
    onItemClick?: (item: any, clickEvent: Event) => void;
    trackBy: string;
}
export interface IOuiTableInternalItem {
    index: number;
    item: any;
}
export interface ISortOrder {
    column: IOuiTableColumn;
    direction: 'ASC' | 'DESC';
}
export interface IOuiTableColumn {
    id: string;
    label: string;
    valueKey: string;
    isSortable?: boolean;
    flex?: string;
    sortFunction?: (a: IOuiTableInternalItem, b: IOuiTableInternalItem, sortOrder: ISortOrder) => number;
    overflow?: 'auto' | 'hidden' | 'scroll' | 'visible';
    textOverflow?: 'ellipsis' | 'clip';
    cellTemplate?: TemplateRef<any>;
    headerCellTemplate?: TemplateRef<any>;
}
//# sourceMappingURL=types.d.ts.map