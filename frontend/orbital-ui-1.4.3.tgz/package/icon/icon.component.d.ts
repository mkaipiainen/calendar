import { AfterViewInit, DestroyRef, ElementRef, Renderer2, Signal } from '@angular/core';
import { OuiThemeService } from 'orbital-ui/themes';
import * as i0 from "@angular/core";
export interface IOuiIconOptions {
    size?: string;
    width?: string;
    height?: string;
    fillColor?: string | number[];
    strokeColor?: string | number[];
    disableTransform?: boolean;
    preserveAspectRatio?: string;
    viewBox?: string;
    disableColorChange?: boolean;
    margin?: string;
}
/**
 * Component to be used to display icons. Streamlines use of especially svg-icons, but can also display images like pngs.
 * Created because configuration of svg-icons is cumbersome, and this component acts as an abstraction that does a lot of
 * the hard work automatically.
 *
 * Under the hood uses a method to 'unpack' a given svg-image, and inlines it directly into the DOM. This is done
 * to enable coloring the SVG on the fly.
 *
 *
 *  Example use:
 *
 *  <oui-icon icon="assets/icons/my-svg.svg" [options]={fillColor: 'color-white', strokeColor: 'color-white', viewBox: '0 0 48 48'}></oui-icon>
 */
export declare class OuiIconComponent implements AfterViewInit {
    #private;
    private ouiThemeService;
    private renderer;
    elementRef: ElementRef;
    private document;
    private destroyRef;
    iconContainerElement: any;
    /**
     *   The path to the icon to be used
     */
    set icon(newIcon: string);
    get icon(): string;
    iconElement: HTMLElement;
    /**
     *   The options that are to be used with the icons. Important options are:
     *     fillColor: string - the fillColor of the svg. Can be a hex-color, or a css-variable
     *     strokeColor: string - the strokeColor of the svg. Can be a hex-color or a css-variable
     *     viewBox: string - Controls the viewbox of the svg. This is usually taken by default from the svg-image.
     *                       Sometimes SVGs don't have the viewbox proprety by default, in which case you might need to provide it yourself.
     *                       In these cases, you can usually look at the dimensions of the image and match the viewBox with that. For example,
     *                       if an image is 40 pixels wide and 30 pixels high, you can pass the following viewBox: '0 0 40 30'.
     *
     *     size: string - The size of the icon, for example '20px' or '2rem'. A quick way to pass a single proprety instead of height and width separately.
     *     height: string - The same as size, except only for height
     *     width: string - The same as size, except only for width
     *     disableTransform: boolean - If set to true, svg-injecting is disabled. This should be set to true for example for png-icons.
     *     disableColorChange: boolean - If set to true, color of the SVG isn't altered. This should be set to true if SVG already contains colors.
     *     preserveAspectRatio: string - alters the preserveAspectRatio-proprety of the svg. Rarely used.
     *     margin: string - way to pass a margin to be used for the icon if needed
     */
    set options(newOptions: IOuiIconOptions);
    get options(): IOuiIconOptions;
    private defaultOptions;
    optionsSignal: import("@angular/core").WritableSignal<IOuiIconOptions>;
    iconSignal: import("@angular/core").WritableSignal<string>;
    combinedOptions: Signal<IOuiIconOptions>;
    fallbackSize: string;
    constructor(ouiThemeService: OuiThemeService, renderer: Renderer2, elementRef: ElementRef, document: Document, destroyRef: DestroyRef);
    ngAfterViewInit(): void;
    private setElementSize;
    private doSvgInjection;
    private setUsedColors;
    private colorSvgAndContents;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiIconComponent, "oui-icon", never, { "icon": { "alias": "icon"; "required": true; }; "options": { "alias": "options"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=icon.component.d.ts.map