import { AfterViewInit, DestroyRef, ElementRef, EventEmitter } from '@angular/core';
import { OuiCollapsibleService } from '../collapsible.service';
import * as i0 from "@angular/core";
/**
 * A component part of a group of components that can be used to create collapsible content-blocks.
 * This component is used to toggle the content of the collapsible block. Use this in conjunction with oui-collapsible-content.
 *
 * @Input() group: string -               The group of the collapsible component. This needs to match the toggle that you want to use to
 *                                        toggle the content.
 * @Input() isOpen: boolean -             You can use this input to control whether or not the collapsible content should be open
 *                                        For example if you want it to be initially toggled open, then you can pass true to this input
 * @Input() disableClickToggle: boolean - This can be used to disable toggling the collapsible content by clicking on the toggle
 *                                        In this case, it can only be toggled programmatically.
 *
 * @Output() isOpenChange: boolean - Emitted when the toggle is opened/closed
 * Example usage:
 *
 * <oui-collapsible-toggle [isOpen]="isFirstGroupOpen" group="first-group"></oui-collapsible-toggle>
 * <oui-collapsible-content group=first-group">
 *   <div class="content">You can put any content here that you desire</div>
 * </oui-collapsible-content>
 */
export declare class OuiCollapsibleToggleComponent implements AfterViewInit {
    private ouiCollapsibleService;
    private destroyRef;
    group: string;
    isOpen: boolean;
    disableClickToggle: boolean;
    toggleContainer: ElementRef;
    toggle: ElementRef;
    isOpenChange: EventEmitter<boolean>;
    private isInitialOpenSet;
    constructor(ouiCollapsibleService: OuiCollapsibleService, destroyRef: DestroyRef);
    ngAfterViewInit(): void;
    onClick(): void;
    doToggle(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiCollapsibleToggleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiCollapsibleToggleComponent, "oui-collapsible-toggle", never, { "group": { "alias": "group"; "required": false; }; "isOpen": { "alias": "isOpen"; "required": false; }; "disableClickToggle": { "alias": "disableClickToggle"; "required": false; }; }, { "isOpenChange": "isOpenChange"; }, never, ["*"], true, never>;
}
//# sourceMappingURL=collapsible-toggle.component.d.ts.map