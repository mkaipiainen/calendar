import { BitmapLayer } from '@deck.gl/layers/typed';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { BindCommonDeckOptions } from '../deck/bind-default-deck-options';
import * as i0 from "@angular/core";
export class DeckBitmapLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new BitmapLayer({
            ...BindCommonDeckOptions(this),
            image: this.options.image,
            bounds: this.options.bounds,
            loadOptions: this.options.loadOptions,
            textureParameters: this.options.textureParameters,
        }, {
            data: this.options.data,
            image: this.options.image,
            bounds: this.options.bounds,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckBitmapLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckBitmapLayer, isStandalone: true, selector: "oui-deck-bitmap-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckBitmapLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-bitmap-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay1iaXRtYXAtbGF5ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL21hcGJveC9iaXRtYXAtbGF5ZXIvZGVjay1iaXRtYXAtbGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFdBQVcsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBQ3BELE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUU3RCxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQzs7QUFRMUUsTUFBTSxPQUFPLGVBQWdCLFNBQVEsYUFBc0M7SUFDdEMsT0FBTyxDQUEwQjtJQUNwRTtRQUNFLEtBQUssRUFBRSxDQUFDO0lBQ1YsQ0FBQztJQUVNLFFBQVE7UUFDYixPQUFPLElBQUksV0FBVyxDQUNwQjtZQUNFLEdBQUcscUJBQXFCLENBQUMsSUFBSSxDQUFDO1lBQzlCLEtBQUssRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUs7WUFDekIsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTTtZQUMzQixXQUFXLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXO1lBQ3JDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsaUJBQWlCO1NBQ2xELEVBQ0Q7WUFDRSxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ3ZCLEtBQUssRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUs7WUFDekIsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTTtTQUM1QixDQUNGLENBQUM7SUFDSixDQUFDO3VHQXJCVSxlQUFlOzJGQUFmLGVBQWUsd0lBTGhCLEVBQUU7OzJGQUtELGVBQWU7a0JBUDNCLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLHVCQUF1QjtvQkFDakMsUUFBUSxFQUFFLEVBQUU7b0JBQ1osVUFBVSxFQUFFLElBQUk7b0JBQ2hCLE9BQU8sRUFBRSxFQUFFO29CQUNYLGVBQWUsRUFBRSx1QkFBdUIsQ0FBQyxNQUFNO2lCQUNoRDt3REFFb0MsT0FBTztzQkFBekMsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBCaXRtYXBMYXllciB9IGZyb20gJ0BkZWNrLmdsL2xheWVycy90eXBlZCc7XG5pbXBvcnQgeyBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSwgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURlY2tMYXllciB9IGZyb20gJy4uL2Jhc2UtZGVjay1sYXllci5jb21wb25lbnQnO1xuaW1wb3J0IHsgSUNvbW1vbkRlY2tMYXllck9wdGlvbnMsIElEZWNrQml0bWFwTGF5ZXJPcHRpb25zIH0gZnJvbSAnLi4vdHlwaW5ncyc7XG5pbXBvcnQgeyBCaW5kQ29tbW9uRGVja09wdGlvbnMgfSBmcm9tICcuLi9kZWNrL2JpbmQtZGVmYXVsdC1kZWNrLW9wdGlvbnMnO1xuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLWRlY2stYml0bWFwLWxheWVyJyxcbiAgdGVtcGxhdGU6ICcnLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIERlY2tCaXRtYXBMYXllciBleHRlbmRzIEJhc2VEZWNrTGF5ZXI8SUNvbW1vbkRlY2tMYXllck9wdGlvbnM+IHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSkgZGVjbGFyZSBvcHRpb25zOiBJRGVja0JpdG1hcExheWVyT3B0aW9ucztcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHB1YmxpYyBnZXRMYXllcigpIHtcbiAgICByZXR1cm4gbmV3IEJpdG1hcExheWVyKFxuICAgICAge1xuICAgICAgICAuLi5CaW5kQ29tbW9uRGVja09wdGlvbnModGhpcyksXG4gICAgICAgIGltYWdlOiB0aGlzLm9wdGlvbnMuaW1hZ2UsXG4gICAgICAgIGJvdW5kczogdGhpcy5vcHRpb25zLmJvdW5kcyxcbiAgICAgICAgbG9hZE9wdGlvbnM6IHRoaXMub3B0aW9ucy5sb2FkT3B0aW9ucyxcbiAgICAgICAgdGV4dHVyZVBhcmFtZXRlcnM6IHRoaXMub3B0aW9ucy50ZXh0dXJlUGFyYW1ldGVycyxcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGRhdGE6IHRoaXMub3B0aW9ucy5kYXRhLFxuICAgICAgICBpbWFnZTogdGhpcy5vcHRpb25zLmltYWdlLFxuICAgICAgICBib3VuZHM6IHRoaXMub3B0aW9ucy5ib3VuZHMsXG4gICAgICB9XG4gICAgKTtcbiAgfVxufVxuIl19