export * from './pill.component';
//# sourceMappingURL=public-api.d.ts.map