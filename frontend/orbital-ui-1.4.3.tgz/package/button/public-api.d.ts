export * from './button.component';
//# sourceMappingURL=public-api.d.ts.map