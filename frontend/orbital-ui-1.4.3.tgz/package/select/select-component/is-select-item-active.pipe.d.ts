import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Pipe to output either a caret up or down depending on value
 */
export declare class IsSelectItemActivePipe implements PipeTransform {
    transform(item: any, selectedItems: any, idKey: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<IsSelectItemActivePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<IsSelectItemActivePipe, "isSelectItemActive", true>;
}
//# sourceMappingURL=is-select-item-active.pipe.d.ts.map