import * as i0 from "@angular/core";
/**
 * Service to streamline access to localStorage a bit, especially with JSON-objects.
 * When using this service, you don't need to manually stringify and parse javascript-objects, but it's handled automatically.
 */
export declare class OuiLocalStorageService {
    constructor();
    setItem(key: string, value: any): void;
    getItem(key: string): any;
    removeItem(key: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiLocalStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiLocalStorageService>;
}
//# sourceMappingURL=local-storage.service.d.ts.map