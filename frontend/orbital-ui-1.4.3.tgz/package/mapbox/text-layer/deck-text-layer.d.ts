import { ICommonDeckLayerOptions, IDeckTextLayerOptions } from '../typings';
import { BaseDeckLayer } from '../base-deck-layer.component';
import * as i0 from "@angular/core";
export declare class DeckTextLayer extends BaseDeckLayer<ICommonDeckLayerOptions> {
    name: string;
    options: IDeckTextLayerOptions;
    constructor();
    getLayer(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeckTextLayer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeckTextLayer, "oui-deck-text-layer", never, { "options": { "alias": "options"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=deck-text-layer.d.ts.map