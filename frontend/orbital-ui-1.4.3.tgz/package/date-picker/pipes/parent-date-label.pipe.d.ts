import { PipeTransform } from '@angular/core';
import { IDateLabelTranslations } from '../date-picker/date-picker.component';
import * as i0 from "@angular/core";
export declare class ParentDateLabelPipe implements PipeTransform {
    transform(value: number | Date | null, mode: string, translations: IDateLabelTranslations): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ParentDateLabelPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<ParentDateLabelPipe, "parentDateLabel", true>;
}
//# sourceMappingURL=parent-date-label.pipe.d.ts.map