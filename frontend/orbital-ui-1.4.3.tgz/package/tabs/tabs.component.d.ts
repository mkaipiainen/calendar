import { AfterViewInit, DestroyRef, ElementRef, QueryList } from '@angular/core';
import { OuiTabComponent } from './tab.component';
import { OuiTabsService } from './tabs.service';
import * as i0 from "@angular/core";
export type OuiTabOptions = {
    variant: 'underlined' | 'bordered';
    mode?: 'standard' | 'only-tabs';
};
export declare class OuiTabsComponent implements AfterViewInit {
    private tabService;
    private elementRef;
    private destroyRef;
    tabs: QueryList<OuiTabComponent>;
    underline: ElementRef;
    id: string;
    options: import("@angular/core").InputSignal<OuiTabOptions | undefined>;
    private defaultOptions;
    combinedOptions: import("@angular/core").Signal<{
        variant: "underlined" | "bordered";
        mode?: "standard" | "only-tabs" | undefined;
    } & OuiTabOptions>;
    selectedTab: import("@angular/core").WritableSignal<OuiTabComponent | undefined>;
    constructor(tabService: OuiTabsService, elementRef: ElementRef, destroyRef: DestroyRef);
    ngAfterViewInit(): void;
    private setChildParentIds;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiTabsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiTabsComponent, "oui-tabs", never, { "id": { "alias": "id"; "required": false; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; }, {}, ["tabs"], ["*"], true, never>;
}
//# sourceMappingURL=tabs.component.d.ts.map