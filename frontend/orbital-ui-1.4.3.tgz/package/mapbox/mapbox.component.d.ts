import { AfterViewInit, ApplicationRef, ChangeDetectorRef, DestroyRef, ElementRef, EventEmitter, NgZone, OnDestroy, Renderer2, TemplateRef, ViewContainerRef } from '@angular/core';
import * as MapboxGl from 'mapbox-gl';
import { LngLat, PointLike } from 'mapbox-gl';
import { IFlyToOptions, IMouseUpDown, IMapboxViewStateChange, IOuiMapboxCombinedOptions, IOuiMapboxOptions } from './typings';
import { OuiDeckComponent } from './deck/deck.component';
import { Position } from '@turf/helpers';
import * as i0 from "@angular/core";
export declare class OuiMapboxComponent implements AfterViewInit, OnDestroy {
    private zone;
    destroyRef: DestroyRef;
    elementRef: ElementRef;
    private cdr;
    private renderer;
    private vcr;
    private appRef;
    mapRef: ElementRef;
    overlay: ElementRef;
    mapContainer: ElementRef;
    actions: ElementRef;
    gammaMask: ElementRef;
    attributions: import("@angular/core").InputSignal<TemplateRef<any>[]>;
    deck: OuiDeckComponent;
    set gamma(newGamma: number);
    get gamma(): number;
    set options(newOptions: IOuiMapboxOptions | undefined);
    get options(): IOuiMapboxCombinedOptions | undefined;
    onLoad: EventEmitter<OuiMapboxComponent>;
    private defaultOptions;
    private currentMapboxLayers;
    private isDestroyedSubject;
    private isDestroyed;
    private isLoaded;
    private pipelineHelper;
    private isEmittingPipelines;
    private isInitialised;
    private resizeObserver;
    private onLoadSubject;
    private dragStartSubject;
    private longClickSubject;
    private mouseUpSubject;
    private mouseDownSubject;
    private viewStateChangeSubject;
    private boundsSubject;
    private eventHandlers;
    private previousMapboxViewState;
    private pipelineDataSubject;
    private _gamma;
    private navigationControl;
    combinedOptions: import("@angular/core").Signal<({
        bounds?: undefined;
    } & {
        antialias: boolean;
        attributionControl: boolean;
        bearing: number;
        dragPan: boolean;
        dragRotate: boolean;
        doubleClickZoom: boolean;
        maxBounds?: MapboxGl.LngLatBoundsLike | undefined;
        maxZoom: number;
        minZoom: number;
        maxPitch: number;
        style: string;
        accessToken: string;
        disableResizeTracking?: boolean | undefined;
        isHiddenOnInitialLoad?: boolean | undefined;
        isPipelineDataEmitted?: boolean | undefined;
        longClickDelay?: number | undefined;
        projection: MapboxGl.Projection;
        navigationControl?: "top-left" | "top-right" | "bottom-right" | "bottom-left" | undefined;
    } & {
        center: [number, number];
        zoom: number;
    }) | ({
        center?: undefined;
        zoom?: undefined;
    } & {
        antialias: boolean;
        attributionControl: boolean;
        bearing: number;
        dragPan: boolean;
        dragRotate: boolean;
        doubleClickZoom: boolean;
        maxBounds?: MapboxGl.LngLatBoundsLike | undefined;
        maxZoom: number;
        minZoom: number;
        maxPitch: number;
        style: string;
        accessToken: string;
        disableResizeTracking?: boolean | undefined;
        isHiddenOnInitialLoad?: boolean | undefined;
        isPipelineDataEmitted?: boolean | undefined;
        longClickDelay?: number | undefined;
        projection: MapboxGl.Projection;
        navigationControl?: "top-left" | "top-right" | "bottom-right" | "bottom-left" | undefined;
    } & {
        bounds: MapboxGl.LngLatBoundsLike;
    })>;
    optionsSignal: import("@angular/core").WritableSignal<({
        bounds?: undefined;
    } & Partial<{
        antialias: boolean;
        attributionControl: boolean;
        bearing: number;
        dragPan: boolean;
        dragRotate: boolean;
        doubleClickZoom: boolean;
        maxBounds?: MapboxGl.LngLatBoundsLike | undefined;
        maxZoom: number;
        minZoom: number;
        maxPitch: number;
        style: string;
        accessToken: string;
        disableResizeTracking?: boolean | undefined;
        isHiddenOnInitialLoad?: boolean | undefined;
        isPipelineDataEmitted?: boolean | undefined;
        longClickDelay?: number | undefined;
        projection: MapboxGl.Projection;
        navigationControl?: "top-left" | "top-right" | "bottom-right" | "bottom-left" | undefined;
    } & {
        center: [number, number];
        zoom: number;
    }> & {
        center: [number, number];
        zoom: number;
    }) | ({
        center?: undefined;
        zoom?: undefined;
    } & Partial<{
        antialias: boolean;
        attributionControl: boolean;
        bearing: number;
        dragPan: boolean;
        dragRotate: boolean;
        doubleClickZoom: boolean;
        maxBounds?: MapboxGl.LngLatBoundsLike | undefined;
        maxZoom: number;
        minZoom: number;
        maxPitch: number;
        style: string;
        accessToken: string;
        disableResizeTracking?: boolean | undefined;
        isHiddenOnInitialLoad?: boolean | undefined;
        isPipelineDataEmitted?: boolean | undefined;
        longClickDelay?: number | undefined;
        projection: MapboxGl.Projection;
        navigationControl?: "top-left" | "top-right" | "bottom-right" | "bottom-left" | undefined;
    } & {
        bounds: MapboxGl.LngLatBoundsLike;
    }> & {
        bounds: MapboxGl.LngLatBoundsLike;
    }) | undefined>;
    container: import("@angular/core").WritableSignal<HTMLElement | undefined>;
    id: string;
    onLoad$: import("rxjs").Observable<OuiMapboxComponent>;
    map: MapboxGl.Map | undefined;
    isDestroyed$: import("rxjs").Observable<boolean>;
    viewStateChange$: import("rxjs").Observable<IMapboxViewStateChange>;
    bounds$: import("rxjs").Observable<MapboxGl.LngLatBounds>;
    auditedViewStateChange$: import("rxjs").Observable<IMapboxViewStateChange>;
    auditedBounds$: import("rxjs").Observable<MapboxGl.LngLatBounds>;
    pipelineData$: import("rxjs").Observable<{
        dpp: number;
        bounds: Position[];
    }>;
    dragStart$: import("rxjs").Observable<{
        latitude: number;
        longitude: number;
    }>;
    longClick$: import("rxjs").Observable<IMouseUpDown>;
    mouseUp$: import("rxjs").Observable<IMouseUpDown>;
    mouseDown$: import("rxjs").Observable<IMouseUpDown>;
    isLoading: import("@angular/core").WritableSignal<boolean>;
    gammaFilterUrl: string;
    constructor(zone: NgZone, destroyRef: DestroyRef, elementRef: ElementRef, cdr: ChangeDetectorRef, renderer: Renderer2, vcr: ViewContainerRef, appRef: ApplicationRef);
    ngAfterViewInit(): void;
    doShow(): void;
    private initNavigationControl;
    private attemptInitialisation;
    private initialiseComponent;
    getDeckProps(): Required<import("@deck.gl/core/typed").DeckProps> | undefined;
    setDeckProps(props: any): void;
    private initMap;
    private onMapMouseUp;
    private onMapMouseDown;
    onMapLoad(): void;
    onMapDragStart(event: any): void;
    private initEmittingPipelines;
    projectLngLatToXy(lngLat: [number, number]): {
        x: number;
        y: number;
    };
    projectXyToLngLat(point: PointLike): LngLat;
    private onMapMove;
    private emitInitialViewState;
    flyTo(options: IFlyToOptions): void;
    private repositionMap;
    toggleDragPan(isEnabled: boolean): void;
    ngOnDestroy(): void;
    cleanup(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiMapboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiMapboxComponent, "oui-mapbox", never, { "attributions": { "alias": "attributions"; "required": false; "isSignal": true; }; "deck": { "alias": "deck"; "required": false; }; "gamma": { "alias": "gamma"; "required": false; }; "options": { "alias": "options"; "required": true; }; }, { "onLoad": "onLoad"; }, never, ["*"], true, never>;
}
//# sourceMappingURL=mapbox.component.d.ts.map