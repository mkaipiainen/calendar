import { ChangeDetectionStrategy, Component, EventEmitter, HostListener, Inject, Input, Output, ViewChild, } from '@angular/core';
import { createPopper } from '@popperjs/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { OuiRippleDirective } from 'orbital-ui/ripple';
import * as i0 from "@angular/core";
import * as i1 from "./dropdown.service";
import * as i2 from "@angular/common";
// TODO: Extract content and toggle into their own directives
/**
 * Component used to create dropdowns. Used by passing a content and toggle template-references.
 * @Input() disableCloseOnWindowResize: boolean
 *   If set to true, dropdown doesn't close when window is resized. Normally all dropdowns close when window is resized.
 * @Input() content: TemplateRef<any>
 *   A templateRef that will be used to inject the content into the dropdown.
 * @Input toggle: TemplateRef<any>
 *   A templateRef that will be used to inject the toggle into the DOM
 * @Input() isOpen: boolean
 *   Input to control whether or not the dropdown is open
 * @Output() isOpenChange: EventEmitter<boolean>
 *   Output that triggers whenever the dropdown either opens or is closed
 *
 *
 *   Example use:
 *
 *   <oui-dropdown [toggle]="toggle" [content]="content">
 *     <ng-template #toggle>
 *       <div>This element will be used as the toggle</div>
 *     </ng-template>
 *     <ng-template #content>
 *       <div class="dropdown-content-wrapper">
 *         <div class="dropdown-item">Item1</div>
 *         <div class="dropdown-item">Item2</div>
 *         <div class="dropdown-item">Item3</div>
 *       </div>
 *   </oui-dropdown
 */
export class OuiDropdownComponent {
    vcr;
    zone;
    dropdownService;
    document;
    disableCloseOnWindowResize = false;
    content;
    toggle;
    isOpen = false;
    disabled = false;
    origin;
    wrapper;
    isOpenChange = new EventEmitter();
    dropdownView;
    popperRef;
    constructor(vcr, zone, dropdownService, document) {
        this.vcr = vcr;
        this.zone = zone;
        this.dropdownService = dropdownService;
        this.document = document;
    }
    ngAfterViewInit() {
        this.dropdownService.register(this);
    }
    doToggleDropdown() {
        if (this.disabled) {
            return;
        }
        if (!this.isOpen) {
            this.open();
        }
        else {
            this.close();
        }
    }
    open() {
        if (this.isOpen || this.popperRef || this.dropdownView) {
            return;
        }
        this.isOpen = true;
        this.isOpenChange.emit(this.isOpen);
        this.dropdownView = this.vcr.createEmbeddedView(this.content);
        const dropdown = this.dropdownView.rootNodes[0];
        dropdown.classList.add('oui-dropdown');
        this.document.body.appendChild(dropdown);
        dropdown.style.minWidth =
            this.origin.nativeElement.getBoundingClientRect().width + 'px';
        this.zone.runOutsideAngular(() => {
            this.popperRef = createPopper(this.origin.nativeElement, dropdown, {
                placement: 'bottom-start',
                modifiers: [
                    {
                        name: 'preventOverflow',
                        options: {
                            altAxis: true,
                            padding: 5,
                        },
                    },
                ],
            });
        });
        setTimeout(() => {
            dropdown.classList.add('open');
        });
        // Sometimes when content of the dropdown is built dynamically
        // popper doesn't properly flip the dropdown
        // so we need to make popper do it manually while dropdown is opening
        const observer = new ResizeObserver(() => {
            this.popperRef?.update();
        });
        observer.observe(dropdown);
        setTimeout(() => {
            observer.unobserve(dropdown);
        }, 1000);
    }
    onClick(event, targetElement) {
        if (!targetElement || !this.origin) {
            return;
        }
        const originBbox = this.origin.nativeElement.getBoundingClientRect();
        const dropdownBbox = this.dropdownView?.rootNodes?.[0]?.getBoundingClientRect();
        if (!dropdownBbox || !originBbox) {
            return;
        }
        const clickedInsideOrigin = event.clientX >= originBbox.left &&
            event.clientX <= originBbox.right &&
            event.clientY >= originBbox.top &&
            event.clientY <= originBbox.bottom;
        const clickedInsideDropdown = event.clientX >= dropdownBbox.left &&
            event.clientX <= dropdownBbox.right &&
            event.clientY >= dropdownBbox.top &&
            event.clientY <= dropdownBbox.bottom;
        if (!clickedInsideOrigin && !clickedInsideDropdown) {
            this.close();
        }
    }
    onResize() {
        if (!this.disableCloseOnWindowResize) {
            this.close();
        }
    }
    close(timeout = 200) {
        if (this.dropdownView) {
            this.dropdownView?.rootNodes?.[0]?.classList?.add('hide');
            this.dropdownView?.rootNodes?.[0]?.classList?.remove('open');
        }
        setTimeout(() => {
            if (this.popperRef) {
                this.popperRef.destroy();
            }
            if (this.dropdownView) {
                this.dropdownView.destroy();
            }
            this.isOpen = false;
            this.dropdownView = null;
            this.popperRef = null;
            this.isOpenChange.emit(this.isOpen);
        }, timeout);
    }
    ngOnChanges(changes) {
        if ('isOpen' in changes) {
            if (changes['isOpen'].currentValue) {
                this.open();
            }
            else {
                this.close();
            }
        }
    }
    ngOnDestroy() {
        this.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDropdownComponent, deps: [{ token: i0.ViewContainerRef }, { token: i0.NgZone }, { token: i1.OuiDropdownService }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiDropdownComponent, isStandalone: true, selector: "oui-dropdown", inputs: { disableCloseOnWindowResize: "disableCloseOnWindowResize", content: "content", toggle: "toggle", isOpen: "isOpen", disabled: "disabled" }, outputs: { isOpenChange: "isOpenChange" }, host: { listeners: { "document:click": "onClick($event,$event.target)", "window:resize": "onResize($event)" } }, viewQueries: [{ propertyName: "origin", first: true, predicate: ["origin"], descendants: true }, { propertyName: "wrapper", first: true, predicate: ["wrapper"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div\n  [ngClass]=\"{ disabled: disabled }\"\n  ouiRipple\n  class=\"oui-dropdown-container\"\n  #origin\n  (click)=\"doToggleDropdown()\"\n>\n  <ng-container *ngTemplateOutlet=\"toggle\"></ng-container>\n</div>\n", styles: [":host{width:100%;height:100%;position:relative;z-index:1;display:flex;flex:1}:host .oui-dropdown-fill{transition:opacity .5s;background:var(--dropdown-background-color);opacity:1;height:10px;position:absolute;bottom:0}:host .oui-dropdown-fill.hide{opacity:0}:host .oui-dropdown-container{display:flex;flex:1 0 auto;flex-direction:column;border-radius:var(--border-radius-default);width:100%}:host .oui-dropdown-container.disabled{pointer-events:none;opacity:.8}:host .oui-dropdown-container:hover{cursor:pointer}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: OuiRippleDirective, selector: "[ouiRipple]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDropdownComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-dropdown', standalone: true, imports: [CommonModule, OuiRippleDirective], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  [ngClass]=\"{ disabled: disabled }\"\n  ouiRipple\n  class=\"oui-dropdown-container\"\n  #origin\n  (click)=\"doToggleDropdown()\"\n>\n  <ng-container *ngTemplateOutlet=\"toggle\"></ng-container>\n</div>\n", styles: [":host{width:100%;height:100%;position:relative;z-index:1;display:flex;flex:1}:host .oui-dropdown-fill{transition:opacity .5s;background:var(--dropdown-background-color);opacity:1;height:10px;position:absolute;bottom:0}:host .oui-dropdown-fill.hide{opacity:0}:host .oui-dropdown-container{display:flex;flex:1 0 auto;flex-direction:column;border-radius:var(--border-radius-default);width:100%}:host .oui-dropdown-container.disabled{pointer-events:none;opacity:.8}:host .oui-dropdown-container:hover{cursor:pointer}\n"] }]
        }], ctorParameters: () => [{ type: i0.ViewContainerRef }, { type: i0.NgZone }, { type: i1.OuiDropdownService }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { disableCloseOnWindowResize: [{
                type: Input
            }], content: [{
                type: Input
            }], toggle: [{
                type: Input
            }], isOpen: [{
                type: Input
            }], disabled: [{
                type: Input
            }], origin: [{
                type: ViewChild,
                args: ['origin']
            }], wrapper: [{
                type: ViewChild,
                args: ['wrapper']
            }], isOpenChange: [{
                type: Output
            }], onClick: [{
                type: HostListener,
                args: ['document:click', ['$event', '$event.target']]
            }], onResize: [{
                type: HostListener,
                args: ['window:resize', ['$event']]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHJvcGRvd24uY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9kcm9wZG93bi9kcm9wZG93bi5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL2Ryb3Bkb3duL2Ryb3Bkb3duLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFFTCx1QkFBdUIsRUFDdkIsU0FBUyxFQUdULFlBQVksRUFDWixZQUFZLEVBQ1osTUFBTSxFQUNOLEtBQUssRUFHTCxNQUFNLEVBR04sU0FBUyxHQUVWLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUU5QyxPQUFPLEVBQUUsWUFBWSxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3pELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLG1CQUFtQixDQUFDOzs7O0FBRXZELDZEQUE2RDtBQUM3RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBMkJHO0FBU0gsTUFBTSxPQUFPLG9CQUFvQjtJQTRCckI7SUFDQTtJQUNBO0lBQ2tCO0lBN0I1QiwwQkFBMEIsR0FBRyxLQUFLLENBQUM7SUFHNUIsT0FBTyxDQUFtQjtJQUcxQixNQUFNLENBQW1CO0lBR2hDLE1BQU0sR0FBRyxLQUFLLENBQUM7SUFFTixRQUFRLEdBQUcsS0FBSyxDQUFDO0lBR25CLE1BQU0sQ0FBYTtJQUduQixPQUFPLENBQWE7SUFHM0IsWUFBWSxHQUFHLElBQUksWUFBWSxFQUFXLENBQUM7SUFFbkMsWUFBWSxDQUE4QjtJQUMxQyxTQUFTLENBQU07SUFFdkIsWUFDVSxHQUFxQixFQUNyQixJQUFZLEVBQ1osZUFBbUMsRUFDakIsUUFBa0I7UUFIcEMsUUFBRyxHQUFILEdBQUcsQ0FBa0I7UUFDckIsU0FBSSxHQUFKLElBQUksQ0FBUTtRQUNaLG9CQUFlLEdBQWYsZUFBZSxDQUFvQjtRQUNqQixhQUFRLEdBQVIsUUFBUSxDQUFVO0lBQzNDLENBQUM7SUFFRyxlQUFlO1FBQ3BCLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFTSxnQkFBZ0I7UUFDckIsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDbEIsT0FBTztRQUNULENBQUM7UUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2pCLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNkLENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2YsQ0FBQztJQUNILENBQUM7SUFFTSxJQUFJO1FBQ1QsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3ZELE9BQU87UUFDVCxDQUFDO1FBQ0QsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUM7UUFDbkIsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3BDLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDOUQsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEQsUUFBUSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDdkMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3pDLFFBQVEsQ0FBQyxLQUFLLENBQUMsUUFBUTtZQUNyQixJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUM7UUFFakUsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLEVBQUU7WUFDL0IsSUFBSSxDQUFDLFNBQVMsR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsUUFBUSxFQUFFO2dCQUNqRSxTQUFTLEVBQUUsY0FBYztnQkFDekIsU0FBUyxFQUFFO29CQUNUO3dCQUNFLElBQUksRUFBRSxpQkFBaUI7d0JBQ3ZCLE9BQU8sRUFBRTs0QkFDUCxPQUFPLEVBQUUsSUFBSTs0QkFDYixPQUFPLEVBQUUsQ0FBQzt5QkFDWDtxQkFDRjtpQkFDRjthQUNGLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO1FBRUgsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNkLFFBQVEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pDLENBQUMsQ0FBQyxDQUFDO1FBRUgsOERBQThEO1FBQzlELDRDQUE0QztRQUM1QyxxRUFBcUU7UUFDckUsTUFBTSxRQUFRLEdBQUcsSUFBSSxjQUFjLENBQUMsR0FBRyxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxTQUFTLEVBQUUsTUFBTSxFQUFFLENBQUM7UUFDM0IsQ0FBQyxDQUFDLENBQUM7UUFDSCxRQUFRLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBRTNCLFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDZCxRQUFRLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQy9CLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNYLENBQUM7SUFHTSxPQUFPLENBQUMsS0FBaUIsRUFBRSxhQUEwQjtRQUMxRCxJQUFJLENBQUMsYUFBYSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ25DLE9BQU87UUFDVCxDQUFDO1FBQ0QsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUNyRSxNQUFNLFlBQVksR0FDaEIsSUFBSSxDQUFDLFlBQVksRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxxQkFBcUIsRUFBRSxDQUFDO1FBQzdELElBQUksQ0FBQyxZQUFZLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNqQyxPQUFPO1FBQ1QsQ0FBQztRQUVELE1BQU0sbUJBQW1CLEdBQ3ZCLEtBQUssQ0FBQyxPQUFPLElBQUksVUFBVSxDQUFDLElBQUk7WUFDaEMsS0FBSyxDQUFDLE9BQU8sSUFBSSxVQUFVLENBQUMsS0FBSztZQUNqQyxLQUFLLENBQUMsT0FBTyxJQUFJLFVBQVUsQ0FBQyxHQUFHO1lBQy9CLEtBQUssQ0FBQyxPQUFPLElBQUksVUFBVSxDQUFDLE1BQU0sQ0FBQztRQUNyQyxNQUFNLHFCQUFxQixHQUN6QixLQUFLLENBQUMsT0FBTyxJQUFJLFlBQVksQ0FBQyxJQUFJO1lBQ2xDLEtBQUssQ0FBQyxPQUFPLElBQUksWUFBWSxDQUFDLEtBQUs7WUFDbkMsS0FBSyxDQUFDLE9BQU8sSUFBSSxZQUFZLENBQUMsR0FBRztZQUNqQyxLQUFLLENBQUMsT0FBTyxJQUFJLFlBQVksQ0FBQyxNQUFNLENBQUM7UUFFdkMsSUFBSSxDQUFDLG1CQUFtQixJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztZQUNuRCxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDZixDQUFDO0lBQ0gsQ0FBQztJQUdELFFBQVE7UUFDTixJQUFJLENBQUMsSUFBSSxDQUFDLDBCQUEwQixFQUFFLENBQUM7WUFDckMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2YsQ0FBQztJQUNILENBQUM7SUFFTSxLQUFLLENBQUMsT0FBTyxHQUFHLEdBQUc7UUFDeEIsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDdEIsSUFBSSxDQUFDLFlBQVksRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxTQUFTLEVBQUUsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQzFELElBQUksQ0FBQyxZQUFZLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsU0FBUyxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUMvRCxDQUFDO1FBQ0QsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO2dCQUNuQixJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQzNCLENBQUM7WUFDRCxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDdEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUM5QixDQUFDO1lBQ0QsSUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUM7WUFDcEIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7WUFDekIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7WUFDdEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3RDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUNkLENBQUM7SUFFTSxXQUFXLENBQUMsT0FBc0I7UUFDdkMsSUFBSSxRQUFRLElBQUksT0FBTyxFQUFFLENBQUM7WUFDeEIsSUFBSSxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ25DLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNkLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDZixDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFTSxXQUFXO1FBQ2hCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUNmLENBQUM7dUdBaEtVLG9CQUFvQiwwR0ErQnJCLFFBQVE7MkZBL0JQLG9CQUFvQixva0JDNURqQyx1TkFTQSwyakJEZ0RZLFlBQVksb1NBQUUsa0JBQWtCOzsyRkFHL0Isb0JBQW9CO2tCQVJoQyxTQUFTOytCQUNFLGNBQWMsY0FHWixJQUFJLFdBQ1AsQ0FBQyxZQUFZLEVBQUUsa0JBQWtCLENBQUMsbUJBQzFCLHVCQUF1QixDQUFDLE1BQU07OzBCQWlDNUMsTUFBTTsyQkFBQyxRQUFRO3lDQTdCbEIsMEJBQTBCO3NCQUR6QixLQUFLO2dCQUlDLE9BQU87c0JBRGIsS0FBSztnQkFJQyxNQUFNO3NCQURaLEtBQUs7Z0JBSU4sTUFBTTtzQkFETCxLQUFLO2dCQUdHLFFBQVE7c0JBQWhCLEtBQUs7Z0JBR0MsTUFBTTtzQkFEWixTQUFTO3VCQUFDLFFBQVE7Z0JBSVosT0FBTztzQkFEYixTQUFTO3VCQUFDLFNBQVM7Z0JBSXBCLFlBQVk7c0JBRFgsTUFBTTtnQkEwRUEsT0FBTztzQkFEYixZQUFZO3VCQUFDLGdCQUFnQixFQUFFLENBQUMsUUFBUSxFQUFFLGVBQWUsQ0FBQztnQkE2QjNELFFBQVE7c0JBRFAsWUFBWTt1QkFBQyxlQUFlLEVBQUUsQ0FBQyxRQUFRLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcbiAgQ29tcG9uZW50LFxuICBFbGVtZW50UmVmLFxuICBFbWJlZGRlZFZpZXdSZWYsXG4gIEV2ZW50RW1pdHRlcixcbiAgSG9zdExpc3RlbmVyLFxuICBJbmplY3QsXG4gIElucHV0LFxuICBOZ1pvbmUsXG4gIE9uQ2hhbmdlcywgT25EZXN0cm95LFxuICBPdXRwdXQsXG4gIFNpbXBsZUNoYW5nZXMsXG4gIFRlbXBsYXRlUmVmLFxuICBWaWV3Q2hpbGQsXG4gIFZpZXdDb250YWluZXJSZWYsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgY3JlYXRlUG9wcGVyIH0gZnJvbSAnQHBvcHBlcmpzL2NvcmUnO1xuaW1wb3J0IHsgT3VpRHJvcGRvd25TZXJ2aWNlIH0gZnJvbSAnLi9kcm9wZG93bi5zZXJ2aWNlJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSwgRE9DVU1FTlQgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgT3VpUmlwcGxlRGlyZWN0aXZlIH0gZnJvbSAnb3JiaXRhbC11aS9yaXBwbGUnO1xuXG4vLyBUT0RPOiBFeHRyYWN0IGNvbnRlbnQgYW5kIHRvZ2dsZSBpbnRvIHRoZWlyIG93biBkaXJlY3RpdmVzXG4vKipcbiAqIENvbXBvbmVudCB1c2VkIHRvIGNyZWF0ZSBkcm9wZG93bnMuIFVzZWQgYnkgcGFzc2luZyBhIGNvbnRlbnQgYW5kIHRvZ2dsZSB0ZW1wbGF0ZS1yZWZlcmVuY2VzLlxuICogQElucHV0KCkgZGlzYWJsZUNsb3NlT25XaW5kb3dSZXNpemU6IGJvb2xlYW5cbiAqICAgSWYgc2V0IHRvIHRydWUsIGRyb3Bkb3duIGRvZXNuJ3QgY2xvc2Ugd2hlbiB3aW5kb3cgaXMgcmVzaXplZC4gTm9ybWFsbHkgYWxsIGRyb3Bkb3ducyBjbG9zZSB3aGVuIHdpbmRvdyBpcyByZXNpemVkLlxuICogQElucHV0KCkgY29udGVudDogVGVtcGxhdGVSZWY8YW55PlxuICogICBBIHRlbXBsYXRlUmVmIHRoYXQgd2lsbCBiZSB1c2VkIHRvIGluamVjdCB0aGUgY29udGVudCBpbnRvIHRoZSBkcm9wZG93bi5cbiAqIEBJbnB1dCB0b2dnbGU6IFRlbXBsYXRlUmVmPGFueT5cbiAqICAgQSB0ZW1wbGF0ZVJlZiB0aGF0IHdpbGwgYmUgdXNlZCB0byBpbmplY3QgdGhlIHRvZ2dsZSBpbnRvIHRoZSBET01cbiAqIEBJbnB1dCgpIGlzT3BlbjogYm9vbGVhblxuICogICBJbnB1dCB0byBjb250cm9sIHdoZXRoZXIgb3Igbm90IHRoZSBkcm9wZG93biBpcyBvcGVuXG4gKiBAT3V0cHV0KCkgaXNPcGVuQ2hhbmdlOiBFdmVudEVtaXR0ZXI8Ym9vbGVhbj5cbiAqICAgT3V0cHV0IHRoYXQgdHJpZ2dlcnMgd2hlbmV2ZXIgdGhlIGRyb3Bkb3duIGVpdGhlciBvcGVucyBvciBpcyBjbG9zZWRcbiAqXG4gKlxuICogICBFeGFtcGxlIHVzZTpcbiAqXG4gKiAgIDxvdWktZHJvcGRvd24gW3RvZ2dsZV09XCJ0b2dnbGVcIiBbY29udGVudF09XCJjb250ZW50XCI+XG4gKiAgICAgPG5nLXRlbXBsYXRlICN0b2dnbGU+XG4gKiAgICAgICA8ZGl2PlRoaXMgZWxlbWVudCB3aWxsIGJlIHVzZWQgYXMgdGhlIHRvZ2dsZTwvZGl2PlxuICogICAgIDwvbmctdGVtcGxhdGU+XG4gKiAgICAgPG5nLXRlbXBsYXRlICNjb250ZW50PlxuICogICAgICAgPGRpdiBjbGFzcz1cImRyb3Bkb3duLWNvbnRlbnQtd3JhcHBlclwiPlxuICogICAgICAgICA8ZGl2IGNsYXNzPVwiZHJvcGRvd24taXRlbVwiPkl0ZW0xPC9kaXY+XG4gKiAgICAgICAgIDxkaXYgY2xhc3M9XCJkcm9wZG93bi1pdGVtXCI+SXRlbTI8L2Rpdj5cbiAqICAgICAgICAgPGRpdiBjbGFzcz1cImRyb3Bkb3duLWl0ZW1cIj5JdGVtMzwvZGl2PlxuICogICAgICAgPC9kaXY+XG4gKiAgIDwvb3VpLWRyb3Bkb3duXG4gKi9cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1kcm9wZG93bicsXG4gIHRlbXBsYXRlVXJsOiAnLi9kcm9wZG93bi5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL2Ryb3Bkb3duLmNvbXBvbmVudC5zY3NzJ10sXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtDb21tb25Nb2R1bGUsIE91aVJpcHBsZURpcmVjdGl2ZV0sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlEcm9wZG93bkNvbXBvbmVudCBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQsIE9uQ2hhbmdlcywgT25EZXN0cm95IHtcbiAgQElucHV0KClcbiAgZGlzYWJsZUNsb3NlT25XaW5kb3dSZXNpemUgPSBmYWxzZTtcblxuICBASW5wdXQoKVxuICBwdWJsaWMgY29udGVudDogVGVtcGxhdGVSZWY8YW55PjtcblxuICBASW5wdXQoKVxuICBwdWJsaWMgdG9nZ2xlOiBUZW1wbGF0ZVJlZjxhbnk+O1xuXG4gIEBJbnB1dCgpXG4gIGlzT3BlbiA9IGZhbHNlO1xuXG4gIEBJbnB1dCgpIGRpc2FibGVkID0gZmFsc2U7XG5cbiAgQFZpZXdDaGlsZCgnb3JpZ2luJylcbiAgcHVibGljIG9yaWdpbjogRWxlbWVudFJlZjtcblxuICBAVmlld0NoaWxkKCd3cmFwcGVyJylcbiAgcHVibGljIHdyYXBwZXI6IEVsZW1lbnRSZWY7XG5cbiAgQE91dHB1dCgpXG4gIGlzT3BlbkNoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8Ym9vbGVhbj4oKTtcblxuICBwcml2YXRlIGRyb3Bkb3duVmlldzogRW1iZWRkZWRWaWV3UmVmPGFueT4gfCBudWxsO1xuICBwcml2YXRlIHBvcHBlclJlZjogYW55O1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgdmNyOiBWaWV3Q29udGFpbmVyUmVmLFxuICAgIHByaXZhdGUgem9uZTogTmdab25lLFxuICAgIHByaXZhdGUgZHJvcGRvd25TZXJ2aWNlOiBPdWlEcm9wZG93blNlcnZpY2UsXG4gICAgQEluamVjdChET0NVTUVOVCkgcHJpdmF0ZSBkb2N1bWVudDogRG9jdW1lbnRcbiAgKSB7fVxuXG4gIHB1YmxpYyBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgdGhpcy5kcm9wZG93blNlcnZpY2UucmVnaXN0ZXIodGhpcyk7XG4gIH1cblxuICBwdWJsaWMgZG9Ub2dnbGVEcm9wZG93bigpIHtcbiAgICBpZiAodGhpcy5kaXNhYmxlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoIXRoaXMuaXNPcGVuKSB7XG4gICAgICB0aGlzLm9wZW4oKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5jbG9zZSgpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBvcGVuKCkge1xuICAgIGlmICh0aGlzLmlzT3BlbiB8fCB0aGlzLnBvcHBlclJlZiB8fCB0aGlzLmRyb3Bkb3duVmlldykge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLmlzT3BlbiA9IHRydWU7XG4gICAgdGhpcy5pc09wZW5DaGFuZ2UuZW1pdCh0aGlzLmlzT3Blbik7XG4gICAgdGhpcy5kcm9wZG93blZpZXcgPSB0aGlzLnZjci5jcmVhdGVFbWJlZGRlZFZpZXcodGhpcy5jb250ZW50KTtcbiAgICBjb25zdCBkcm9wZG93biA9IHRoaXMuZHJvcGRvd25WaWV3LnJvb3ROb2Rlc1swXTtcbiAgICBkcm9wZG93bi5jbGFzc0xpc3QuYWRkKCdvdWktZHJvcGRvd24nKTtcbiAgICB0aGlzLmRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZHJvcGRvd24pO1xuICAgIGRyb3Bkb3duLnN0eWxlLm1pbldpZHRoID1cbiAgICAgIHRoaXMub3JpZ2luLm5hdGl2ZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggKyAncHgnO1xuXG4gICAgdGhpcy56b25lLnJ1bk91dHNpZGVBbmd1bGFyKCgpID0+IHtcbiAgICAgIHRoaXMucG9wcGVyUmVmID0gY3JlYXRlUG9wcGVyKHRoaXMub3JpZ2luLm5hdGl2ZUVsZW1lbnQsIGRyb3Bkb3duLCB7XG4gICAgICAgIHBsYWNlbWVudDogJ2JvdHRvbS1zdGFydCcsXG4gICAgICAgIG1vZGlmaWVyczogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIG5hbWU6ICdwcmV2ZW50T3ZlcmZsb3cnLFxuICAgICAgICAgICAgb3B0aW9uczoge1xuICAgICAgICAgICAgICBhbHRBeGlzOiB0cnVlLFxuICAgICAgICAgICAgICBwYWRkaW5nOiA1LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGRyb3Bkb3duLmNsYXNzTGlzdC5hZGQoJ29wZW4nKTtcbiAgICB9KTtcblxuICAgIC8vIFNvbWV0aW1lcyB3aGVuIGNvbnRlbnQgb2YgdGhlIGRyb3Bkb3duIGlzIGJ1aWx0IGR5bmFtaWNhbGx5XG4gICAgLy8gcG9wcGVyIGRvZXNuJ3QgcHJvcGVybHkgZmxpcCB0aGUgZHJvcGRvd25cbiAgICAvLyBzbyB3ZSBuZWVkIHRvIG1ha2UgcG9wcGVyIGRvIGl0IG1hbnVhbGx5IHdoaWxlIGRyb3Bkb3duIGlzIG9wZW5pbmdcbiAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBSZXNpemVPYnNlcnZlcigoKSA9PiB7XG4gICAgICB0aGlzLnBvcHBlclJlZj8udXBkYXRlKCk7XG4gICAgfSk7XG4gICAgb2JzZXJ2ZXIub2JzZXJ2ZShkcm9wZG93bik7XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIG9ic2VydmVyLnVub2JzZXJ2ZShkcm9wZG93bik7XG4gICAgfSwgMTAwMCk7XG4gIH1cblxuICBASG9zdExpc3RlbmVyKCdkb2N1bWVudDpjbGljaycsIFsnJGV2ZW50JywgJyRldmVudC50YXJnZXQnXSlcbiAgcHVibGljIG9uQ2xpY2soZXZlbnQ6IE1vdXNlRXZlbnQsIHRhcmdldEVsZW1lbnQ6IEhUTUxFbGVtZW50KTogdm9pZCB7XG4gICAgaWYgKCF0YXJnZXRFbGVtZW50IHx8ICF0aGlzLm9yaWdpbikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBvcmlnaW5CYm94ID0gdGhpcy5vcmlnaW4ubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBjb25zdCBkcm9wZG93bkJib3ggPVxuICAgICAgdGhpcy5kcm9wZG93blZpZXc/LnJvb3ROb2Rlcz8uWzBdPy5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBpZiAoIWRyb3Bkb3duQmJveCB8fCAhb3JpZ2luQmJveCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IGNsaWNrZWRJbnNpZGVPcmlnaW4gPVxuICAgICAgZXZlbnQuY2xpZW50WCA+PSBvcmlnaW5CYm94LmxlZnQgJiZcbiAgICAgIGV2ZW50LmNsaWVudFggPD0gb3JpZ2luQmJveC5yaWdodCAmJlxuICAgICAgZXZlbnQuY2xpZW50WSA+PSBvcmlnaW5CYm94LnRvcCAmJlxuICAgICAgZXZlbnQuY2xpZW50WSA8PSBvcmlnaW5CYm94LmJvdHRvbTtcbiAgICBjb25zdCBjbGlja2VkSW5zaWRlRHJvcGRvd24gPVxuICAgICAgZXZlbnQuY2xpZW50WCA+PSBkcm9wZG93bkJib3gubGVmdCAmJlxuICAgICAgZXZlbnQuY2xpZW50WCA8PSBkcm9wZG93bkJib3gucmlnaHQgJiZcbiAgICAgIGV2ZW50LmNsaWVudFkgPj0gZHJvcGRvd25CYm94LnRvcCAmJlxuICAgICAgZXZlbnQuY2xpZW50WSA8PSBkcm9wZG93bkJib3guYm90dG9tO1xuXG4gICAgaWYgKCFjbGlja2VkSW5zaWRlT3JpZ2luICYmICFjbGlja2VkSW5zaWRlRHJvcGRvd24pIHtcbiAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICB9XG4gIH1cblxuICBASG9zdExpc3RlbmVyKCd3aW5kb3c6cmVzaXplJywgWyckZXZlbnQnXSlcbiAgb25SZXNpemUoKSB7XG4gICAgaWYgKCF0aGlzLmRpc2FibGVDbG9zZU9uV2luZG93UmVzaXplKSB7XG4gICAgICB0aGlzLmNsb3NlKCk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIGNsb3NlKHRpbWVvdXQgPSAyMDApIHtcbiAgICBpZiAodGhpcy5kcm9wZG93blZpZXcpIHtcbiAgICAgIHRoaXMuZHJvcGRvd25WaWV3Py5yb290Tm9kZXM/LlswXT8uY2xhc3NMaXN0Py5hZGQoJ2hpZGUnKTtcbiAgICAgIHRoaXMuZHJvcGRvd25WaWV3Py5yb290Tm9kZXM/LlswXT8uY2xhc3NMaXN0Py5yZW1vdmUoJ29wZW4nKTtcbiAgICB9XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBpZiAodGhpcy5wb3BwZXJSZWYpIHtcbiAgICAgICAgdGhpcy5wb3BwZXJSZWYuZGVzdHJveSgpO1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMuZHJvcGRvd25WaWV3KSB7XG4gICAgICAgIHRoaXMuZHJvcGRvd25WaWV3LmRlc3Ryb3koKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuaXNPcGVuID0gZmFsc2U7XG4gICAgICB0aGlzLmRyb3Bkb3duVmlldyA9IG51bGw7XG4gICAgICB0aGlzLnBvcHBlclJlZiA9IG51bGw7XG4gICAgICB0aGlzLmlzT3BlbkNoYW5nZS5lbWl0KHRoaXMuaXNPcGVuKTtcbiAgICB9LCB0aW1lb3V0KTtcbiAgfVxuXG4gIHB1YmxpYyBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XG4gICAgaWYgKCdpc09wZW4nIGluIGNoYW5nZXMpIHtcbiAgICAgIGlmIChjaGFuZ2VzWydpc09wZW4nXS5jdXJyZW50VmFsdWUpIHtcbiAgICAgICAgdGhpcy5vcGVuKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmNsb3NlKCk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG5nT25EZXN0cm95KCkge1xuICAgIHRoaXMuY2xvc2UoKTtcbiAgfVxufVxuIiwiPGRpdlxuICBbbmdDbGFzc109XCJ7IGRpc2FibGVkOiBkaXNhYmxlZCB9XCJcbiAgb3VpUmlwcGxlXG4gIGNsYXNzPVwib3VpLWRyb3Bkb3duLWNvbnRhaW5lclwiXG4gICNvcmlnaW5cbiAgKGNsaWNrKT1cImRvVG9nZ2xlRHJvcGRvd24oKVwiXG4+XG4gIDxuZy1jb250YWluZXIgKm5nVGVtcGxhdGVPdXRsZXQ9XCJ0b2dnbGVcIj48L25nLWNvbnRhaW5lcj5cbjwvZGl2PlxuIl19