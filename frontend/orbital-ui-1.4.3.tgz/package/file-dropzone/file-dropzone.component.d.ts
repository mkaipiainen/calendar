import { AfterViewInit, DestroyRef, ElementRef, EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Component that can be used to add a dropzone into which you can drop files.
 * The dropped files are then emited via the filesUploaded-output, after which you can do what you want with them
 * Example use:
 *
 * <oui-file-dropzone (filesUploaded)="onFileUpload($event)"></oui-file-dropzone>
 */
export declare class OuiFileDropzoneComponent implements AfterViewInit {
    private elementRef;
    private destroyRef;
    dropzoneContainer: ElementRef;
    imageDisplay: ElementRef;
    icon: ElementRef;
    /**
     *   The event that's triggered after user drags files into the dropzone
     */
    filesUploaded: EventEmitter<File[]>;
    isImageDisplayed: boolean;
    constructor(elementRef: ElementRef, destroyRef: DestroyRef);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiFileDropzoneComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiFileDropzoneComponent, "oui-file-dropzone", never, {}, { "filesUploaded": "filesUploaded"; }, never, never, true, never>;
}
//# sourceMappingURL=file-dropzone.component.d.ts.map