import { AfterViewInit, ElementRef, EventEmitter, NgZone, OnChanges, OnDestroy, SimpleChanges, TemplateRef, ViewContainerRef } from '@angular/core';
import { OuiDropdownService } from './dropdown.service';
import * as i0 from "@angular/core";
/**
 * Component used to create dropdowns. Used by passing a content and toggle template-references.
 * @Input() disableCloseOnWindowResize: boolean
 *   If set to true, dropdown doesn't close when window is resized. Normally all dropdowns close when window is resized.
 * @Input() content: TemplateRef<any>
 *   A templateRef that will be used to inject the content into the dropdown.
 * @Input toggle: TemplateRef<any>
 *   A templateRef that will be used to inject the toggle into the DOM
 * @Input() isOpen: boolean
 *   Input to control whether or not the dropdown is open
 * @Output() isOpenChange: EventEmitter<boolean>
 *   Output that triggers whenever the dropdown either opens or is closed
 *
 *
 *   Example use:
 *
 *   <oui-dropdown [toggle]="toggle" [content]="content">
 *     <ng-template #toggle>
 *       <div>This element will be used as the toggle</div>
 *     </ng-template>
 *     <ng-template #content>
 *       <div class="dropdown-content-wrapper">
 *         <div class="dropdown-item">Item1</div>
 *         <div class="dropdown-item">Item2</div>
 *         <div class="dropdown-item">Item3</div>
 *       </div>
 *   </oui-dropdown
 */
export declare class OuiDropdownComponent implements AfterViewInit, OnChanges, OnDestroy {
    private vcr;
    private zone;
    private dropdownService;
    private document;
    disableCloseOnWindowResize: boolean;
    content: TemplateRef<any>;
    toggle: TemplateRef<any>;
    isOpen: boolean;
    disabled: boolean;
    origin: ElementRef;
    wrapper: ElementRef;
    isOpenChange: EventEmitter<boolean>;
    private dropdownView;
    private popperRef;
    constructor(vcr: ViewContainerRef, zone: NgZone, dropdownService: OuiDropdownService, document: Document);
    ngAfterViewInit(): void;
    doToggleDropdown(): void;
    open(): void;
    onClick(event: MouseEvent, targetElement: HTMLElement): void;
    onResize(): void;
    close(timeout?: number): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiDropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiDropdownComponent, "oui-dropdown", never, { "disableCloseOnWindowResize": { "alias": "disableCloseOnWindowResize"; "required": false; }; "content": { "alias": "content"; "required": false; }; "toggle": { "alias": "toggle"; "required": false; }; "isOpen": { "alias": "isOpen"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "isOpenChange": "isOpenChange"; }, never, never, true, never>;
}
//# sourceMappingURL=dropdown.component.d.ts.map