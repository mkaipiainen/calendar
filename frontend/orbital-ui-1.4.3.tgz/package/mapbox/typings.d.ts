import { ViewStateChangeParameters } from '@deck.gl/core/typed/controllers/controller';
import { PathStyleExtension } from '@deck.gl/extensions/typed';
import { Accessor, Layer, View, Viewport, WebMercatorViewport } from '@deck.gl/core/typed';
import { RGBA } from 'orbital-ui/core';
import { LayerData } from '@deck.gl/core/typed/types/layer-props';
import { TransitionProps } from '@deck.gl/core/typed/controllers/transition-manager';
import { LngLatBoundsLike, Map, Projection } from 'mapbox-gl';
import { FeatureCollection, Position } from '@turf/helpers';
export type IMapboxEllipsisDriveLayerOptions = IMapboxEllipsisDriveRasterLayerOptions | IMapboxEllipsisDriveVectorLayerOptions;
export type IMapboxLayer = IMapboxEllipsisDriveLayer;
export interface MapboxBaseLayer {
    id: string;
    addTo: (map: Map) => void;
    removeFrom: (map: Map) => void;
}
export interface IPointFeatureCollection {
    type: 'FeatureCollection';
    features: IPointFeature[];
}
export interface IPointFeature {
    type: 'Feature';
    geometry: {
        type: 'Point';
        coordinates: number[];
    };
    properties: {
        [x: string]: any;
    };
}
export interface ILineFeatureCollection {
    type: 'FeatureCollection';
    features: ILineFeature[];
}
export interface ILineFeature {
    type: 'Feature';
    geometry: {
        type: 'LineString';
        coordinates: number[][];
    };
    properties: {
        [x: string]: any;
    };
}
export declare const SELECTION_TYPE: {
    NONE: null;
    RECTANGLE: string;
    POLYGON: string;
};
export declare const enum DECK_LAYER_TYPES {
    CLUSTER = "cluster",
    SCATTERPLOT = "scatterplot",
    POLYGON = "polygon",
    PATH = "path",
    ICON = "icon",
    EDITABLE_GEOJSON = "editable-geojson",
    SELECTION_LAYER = "selection",
    TILE = "tile",
    TEXT = "text",
    WMS = "wms",
    BITMAP = "bitmap",
    MVT = "mvt",
    MEASURE = "measure"
}
export type IDeckViewState = Record<string, any>;
export interface IDeckViewStateChange extends ViewStateChangeParameters {
    viewState: IDeckViewState;
    interactionState: {
        inTransition?: boolean;
        isDragging?: boolean;
        isPanning?: boolean;
        isRotating?: boolean;
        isZooming?: boolean;
    };
    oldViewState: IDeckViewState;
}
export interface IDeckTileLayerTile {
    index: {
        x: number;
        y: number;
        z: number;
        selected: boolean;
    };
    id: string;
    bbox: {
        west: number;
        north: number;
        east: number;
        south: number;
    };
    zoom: number;
    signal: AbortSignal;
    url: string;
}
export interface IMapboxEllipsisDriveRasterLayerOptions {
    id: string;
    type: 'raster';
    pathId: string;
    timestampId: string;
    layer: string;
    token: string;
}
export interface IMapboxEllipsisDriveVectorLayerOptions {
    id: string;
    type: 'vector';
    pathId: string;
    token: string;
}
export declare const enum MAPBOX_LAYER_TYPES {
    ELLIPSIS = "ellipsis"
}
export interface IMapboxEllipsisDriveLayer {
    type: MAPBOX_LAYER_TYPES.ELLIPSIS;
    options: IMapboxEllipsisDriveLayerOptions;
}
export interface IDeckPathStyleExtensionOptions {
    getDashArray: [number, number];
    dashJustified: boolean;
    dashGapPickable: boolean;
    getOffset: (() => number) | number;
    extensions: (PathStyleExtension | any)[];
}
export interface IDeckClipExtensionOptions {
    clipBounds: [number, number, number, number];
}
export interface IDeckMeasureLayerModeConfig {
    centerTooltipsOnLine?: boolean;
    turfOptions?: {
        units: 'kilometers' | 'miles';
    };
    formatTooltip?: (distance: number) => string;
    measurementCallback?: (distance: number) => void;
}
export interface IDeckMaskExtensionOptions {
    maskId: string;
    maskByInstance?: boolean;
    maskInverted?: boolean;
    operation: 'mask';
}
export interface ICommonDeckLayerOptions extends Partial<IDeckPathStyleExtensionOptions & IDeckClipExtensionOptions & IDeckMaskExtensionOptions> {
    id: string;
    autoHighlight?: boolean;
    transitions?: {
        [x: string]: number | {
            duration: number;
            easing: any;
        };
    };
    highlightColor?: ((d: any) => RGBA) | RGBA;
    isEnabled?: boolean;
    _dataDiff?: (oldData: any, newData: any) => [
        {
            startRow: number;
            endRow: number;
        }
    ];
    onClick?: (object: any, event: any) => void;
    onHover?: (event: any) => boolean;
    updateTriggers?: any;
    dataComparator?: (<LayerDataT = LayerData<unknown>>(newData: LayerDataT, oldData?: LayerDataT) => boolean) | null;
    getCursor?: (data: {
        isHovering: boolean;
        isDragging: boolean;
    }) => string;
    order?: number;
    loadOptions?: any;
    visible?: boolean;
    opacity?: number;
    extensions?: any[];
    pickable?: boolean;
}
export interface ISlimCommonDeckLayerOptions extends Omit<ICommonDeckLayerOptions, 'onClick'> {
}
export interface IDeckMeasureLayerOptions extends Omit<IDeckEditableGeoJsonLayerOptions, 'mode'> {
    modeConfig?: IDeckMeasureLayerModeConfig;
}
export interface IDeckMeasureLayerModeConfig {
    centerTooltipsOnLine?: boolean;
    turfOptions?: {
        units: 'kilometers' | 'miles';
    };
    formatTooltip?: (distance: number) => string;
    measurementCallback?: (distance: number) => void;
}
export interface IDeckTextLayerOptions extends ICommonDeckLayerOptions {
    data: any;
    characterSet?: string;
    getText: (d: any) => string;
    getPosition: (d: any) => [number, number];
    getColor?: RGBA | ((d: any) => RGBA);
    getSize?: number | ((d: any) => number);
    sizeScale?: number;
    getAngle?: number;
    getTextAnchor?: any;
    getAlignmentBaseline?: (string & Accessor<any, 'top' | 'center' | 'bottom'>) | undefined;
}
export interface IDeckTextLayer {
    type: DECK_LAYER_TYPES.TEXT;
    options: IDeckTextLayerOptions;
}
export interface IDeckBitmapLayerOptions extends ICommonDeckLayerOptions {
    data?: any;
    bounds: [number, number, number, number];
    loadOptions?: any;
    textureParameters?: any;
    image: any;
}
export interface IDeckMvtLayerOptions extends ICommonDeckLayerOptions {
    id: string;
    onDataLoad?: ((tilejson: any | null) => void) | any;
    data: string;
    getLineColor?: RGBA | ((d: any) => [number, number, number, number]);
    getFillColor?: RGBA | ((d: any) => [number, number, number, number]);
    minZoom?: number;
    maxZoom?: number;
    renderSubLayers?: (props: any) => any;
    uniqueIdProperty?: string;
    highlightedFeatureId?: string | null;
    binary?: boolean;
    loaders?: any[];
    lineWidthMinPixels?: ((d: any) => number) | number;
    getLineWidth?: ((d: any) => number) | number;
}
export interface IDeckBitmapLayer {
    type: DECK_LAYER_TYPES.BITMAP;
    options: IDeckBitmapLayerOptions;
}
export interface IDeckMvtLayer {
    type: DECK_LAYER_TYPES.MVT;
    options: IDeckMvtLayerOptions;
}
export interface IDeckScatterplotLayerOptions extends ICommonDeckLayerOptions {
    data: any;
    onHover?: (event: any) => boolean;
    opacity?: number;
    stroked?: boolean;
    filled?: boolean;
    radiusScale?: number;
    radiusMinPixels?: number;
    radiusMaxPixels?: number;
    lineWidthMinPixels?: number;
    lineWidthMaxPixels?: number;
    lineWidthUnits?: 'meters' | 'common' | 'pixels';
    getLineWidth?: (d: any) => number;
    getPosition: (d: any) => [number, number];
    getRadius: (d: any) => number;
    getFillColor: (d: any) => RGBA;
    getLineColor: (d: any) => RGBA;
}
export interface IDeckScatterplotLayer {
    type: DECK_LAYER_TYPES.SCATTERPLOT;
    options: IDeckScatterplotLayerOptions;
}
export type CursorState = {
    isHovering: boolean;
    isDragging: boolean;
};
export interface IDeckClusterClickInfo {
    color: Uint8Array;
    coordinate: [number, number];
    devicePixel: [number, number];
    index: number;
    layer: any;
    object: {
        type: 'Feature';
        id: number;
        properties: any;
        geometry: {
            type: 'Point';
            coordinates: [number, number];
        };
    };
    picked: boolean;
    pixel: [number, number];
    pixelRatio: number;
    sourceLayer: any;
    viewport: WebMercatorViewport;
    x: number;
    y: number;
}
export interface IDeckClusterLayerOptions extends ISlimCommonDeckLayerOptions {
    data: any;
    name?: string;
    onClick?: (object: IDeckClusterClickInfo, nextZoomLevel: number | null, event: any) => void;
    getClusterSize: ((cluster: any) => number) | number;
    shouldUpdateState?: (changeFlags: {
        dataChanged: boolean;
        extensionsChanged: boolean;
        propsChanged: boolean;
        propsOrDataChanged: boolean;
        somethingChanged: boolean;
        stateChanged: boolean;
        updateTriggersChanged: boolean;
        viewportChanged: boolean;
    }) => boolean;
    iconAtlas: string;
    iconMapping: string;
    sizeScale?: number;
    getPosition: (cluster: any) => number[];
    getIconName: ((cluster: any) => string) | string;
    clusterProps?: string[];
    onHover?: (event: any) => boolean;
    reduceProps?: (acc: Record<string, any>, singleItemProps: Record<string, any>) => void;
    mapProps?: (item: any) => any;
    textLayerProps?: IDeckClusterTextLayerOptions;
    getColor?: RGBA | ((d: any) => RGBA);
    mask?: boolean;
}
export interface IDeckClusterTextLayerOptions extends Partial<IDeckTextLayerOptions> {
    getText: (cluster: any) => string;
    getPosition: (cluster: any) => [number, number];
}
export interface IDeckClusterLayer {
    type: DECK_LAYER_TYPES.CLUSTER;
    options: IDeckClusterLayerOptions;
}
export interface IDeckEditableGeoJsonLayerOptions extends ICommonDeckLayerOptions {
    name?: string;
    data: FeatureCollection;
    selectedFeatureIndexes?: any;
    mode: any;
    filled?: boolean;
    pointRadiusMinPixels?: any;
    pointRadiusScale?: any;
    getFillColor?: ((data: any) => RGBA) | RGBA;
    pickable?: any;
    modeConfig?: {
        [x: string]: any;
    };
    getEditHandlePointColor?: ((data: any) => RGBA) | RGBA;
    getEditHandlePointOutlineColor?: ((data: any) => RGBA) | RGBA;
    autoHighlight?: any;
    onEdit?: any;
    pickingRadius?: number;
    getTentativeFillColor?: ((data: any) => RGBA) | RGBA;
    editHandlePointStrokeWidth: number;
    getEditHandlePointRadius?: ((d: any) => number) | number;
    _subLayerProps?: {
        [layerName: string]: {
            [propName: string]: any;
        };
    };
}
export interface IDeckEditableGeoJsonLayer {
    type: DECK_LAYER_TYPES.EDITABLE_GEOJSON;
    options: IDeckEditableGeoJsonLayerOptions;
}
export interface IDeckSelectionLayerOptions extends ICommonDeckLayerOptions {
    selectionType: (typeof SELECTION_TYPE)[keyof typeof SELECTION_TYPE];
    onSelect: (data: any) => void;
    getTentativeFillColor?: (() => RGBA) | RGBA;
    getTentativeLineColor?: (() => RGBA) | RGBA;
    getTentativeLineDashArray?: () => [number, number];
    lineWidthMinPixels?: number;
    layerIds?: string[];
}
export interface IDeckSelectionLayer {
    type: DECK_LAYER_TYPES.SELECTION_LAYER;
    options: IDeckSelectionLayerOptions;
}
export interface IMapboxViewStateChange {
    viewState: Record<string, any>;
    oldViewState?: Record<string, any>;
}
export interface IDeckTileLayerOptions extends ICommonDeckLayerOptions {
    name?: string;
    data?: string | string[];
    pickable?: boolean;
    onHover?: (event: any) => boolean;
    minZoom?: number;
    maxZoom?: number;
    tileSize?: number;
    getTileData?: (tile: any) => Promise<any> | null;
    renderSubLayers?: (props: any) => any;
}
export interface IDeckTileLayer {
    type: DECK_LAYER_TYPES.TILE;
    options: IDeckTileLayerOptions;
}
export interface IDeckIconLayerOptions extends ICommonDeckLayerOptions {
    name?: string;
    data: any[];
    pickable?: boolean;
    iconAtlas: string;
    iconMapping: any;
    getIcon: (d: any) => string;
    onHover?: (event: any) => boolean;
    sizeScale?: number;
    getPosition?: (d: any) => [number, number];
    getSize?: ((d: any) => number) | number;
    getPixelOffset?: any;
    onDrag?: (info: any) => void;
    onDragStart?: (info: any) => void;
    onDragEnd?: (info: any) => void;
}
export interface IDeckIconLayer {
    type: DECK_LAYER_TYPES.ICON;
    options: IDeckIconLayerOptions;
}
export interface IDeckGeoJsonLayerOptions extends ICommonDeckLayerOptions {
    data: FeatureCollection;
    pointType: 'circle' | 'icon' | 'text';
    lineWidthScale?: number;
    lineWidthMinPixels?: number;
    lineWidthMaxPixels?: number;
    lineWithUnits?: 'meters' | 'common' | 'pixels';
    getFillColor: ((d: any) => RGBA) | RGBA;
    getLineColor: ((d: any) => RGBA) | RGBA;
    getPointRadius?: ((d: any) => number) | number;
    getLineWidth?: ((d: any) => number) | number;
    getElevation?: ((d: any) => number) | number;
    extruded?: boolean;
}
export interface IDeckPolygonLayerOptions extends ICommonDeckLayerOptions {
    name?: string;
    data: any[];
    pickable?: boolean;
    onHover?: (event: any) => boolean;
    stroked?: boolean;
    filled?: boolean;
    wireframe?: boolean;
    lineWidthMinPixels: number;
    getPolygon: (x: any) => Position[] | Position[][];
    getElevation?: ((d: any) => number) | number;
    getFillColor: ((d: any) => RGBA) | RGBA;
    getLineColor: ((d: any) => RGBA) | RGBA;
    getLineWidth: ((d: any) => number) | number;
}
export interface IDeckPolygonLayer {
    type: DECK_LAYER_TYPES.POLYGON;
    options: IDeckPolygonLayerOptions;
}
export interface IDeckPathLayerOptions extends ICommonDeckLayerOptions {
    name?: string;
    data: any[];
    pickable?: boolean;
    widthScale?: number;
    widthMinPixels?: number;
    widthUnits?: 'meters' | 'common' | 'pixels';
    widthMaxPixels?: number;
    getPath: ((d: any) => any | number[][]) & any;
    getColor: ((d: any) => RGBA) | RGBA;
    getWidth: ((d: any) => number) | number;
    onHover?: (event: any) => boolean;
    jointRounded?: boolean;
}
export interface IDeckPathLayer {
    type: DECK_LAYER_TYPES.PATH;
    options: IDeckPathLayerOptions;
}
export interface IMapDeckMapView {
    repeat?: boolean;
    nearZMultiplier?: number;
    farZMultiplier?: number;
    projectionMatrix?: number[];
    fovy?: number;
    altitude?: number;
    ortographic?: boolean;
}
export interface IDeckGeolocateLayerOptions extends ICommonDeckLayerOptions {
    onHover?: (event: any) => boolean;
    opacity?: number;
    stroked?: boolean;
    filled?: boolean;
    radiusScale?: number;
    radiusMinPixels?: number | (((d: any) => number) & number) | undefined;
    radiusMaxPixels?: number | (((d: any) => number) & number) | undefined;
    lineWidthMinPixels?: number | (((d: any) => number) & number) | undefined;
    getLineWidth?: number | (((d: any) => number) & number) | undefined;
    getRadius?: number | (((d: any) => number) & number) | undefined;
    getFillColor?: (d: any) => RGBA;
    getLineColor?: (d: any) => RGBA;
}
export interface IDeckOptions {
    mapView?: IMapDeckMapView;
    layerFilter?: ({ layer, viewport, }: {
        layer: Layer;
        viewport: Viewport;
    }) => boolean;
    views?: View<TransitionProps, {}> | View<TransitionProps, {}>[] | null;
    getCursor?: (event: any) => string;
    onClick?: (info: any, event: any) => void;
    onDragStart?: (info: any, event: any) => void;
    onDrag?: (event: any) => void;
    onDragEnd?: (event: any) => void;
    doubleClickZoom?: boolean;
    onViewStateChange?: (viewState: ViewStateChangeParameters) => void;
    effects?: any[];
    updateTriggers?: any;
    eventListeners?: {
        [event: string]: {
            listener: (event: unknown) => void;
            options?: {
                capture?: boolean;
                once?: boolean;
                passive?: boolean;
                signal?: AbortSignal;
            };
        };
    };
    initialViewState: IDeckViewState;
    controller?: {
        [x: string]: any;
    } | boolean;
}
type Without<T, U> = {
    [P in Exclude<keyof T, keyof U>]?: never;
};
type XOR<T, U> = T | U extends object ? (Without<T, U> & U) | (Without<U, T> & T) : T | U;
export type IOuiMapboxOptions = XOR<IOuiMapboxBoundsOptions, IOuiMapboxCenterZoomOptions>;
export type OuiAttributionControlOptions = {
    alignment?: {
        top?: string;
        left?: string;
        right?: string;
        bottom?: string;
    };
};
type IOuiMapboxBoundsOptions = Partial<IOuiMapboxCombinedBoundsOptions> & {
    bounds: LngLatBoundsLike;
};
type IOuiMapboxCenterZoomOptions = Partial<IOuiMapboxCombinedCenterZoomOptions> & {
    center: [number, number];
    zoom: number;
};
type IOuiMapboxCombinedCommonOptions = {
    antialias: boolean;
    attributionControl: boolean;
    bearing: number;
    dragPan: boolean;
    dragRotate: boolean;
    doubleClickZoom: boolean;
    maxBounds?: LngLatBoundsLike;
    maxZoom: number;
    minZoom: number;
    maxPitch: number;
    style: string;
    accessToken: string;
    disableResizeTracking?: boolean;
    isHiddenOnInitialLoad?: boolean;
    isPipelineDataEmitted?: boolean;
    longClickDelay?: number;
    projection: Projection;
    navigationControl?: 'top-left' | 'top-right' | 'bottom-right' | 'bottom-left';
};
type IOuiMapboxCombinedBoundsOptions = IOuiMapboxCombinedCommonOptions & {
    bounds: LngLatBoundsLike;
};
type IOuiMapboxCombinedCenterZoomOptions = IOuiMapboxCombinedCommonOptions & {
    center: [number, number];
    zoom: number;
};
export type IOuiMapboxCombinedOptions = XOR<IOuiMapboxCombinedBoundsOptions, IOuiMapboxCombinedCenterZoomOptions>;
export interface IFlyToOptions {
    latitude: number;
    longitude: number;
    zoom: number;
    transitionDuration: number | 'auto';
    disableViewStateChangeEvent?: boolean;
    onTransitionEnd?: () => void;
}
export interface IDragStartEvent {
    latitude: number;
    longitude: number;
    zoom: number;
}
export interface IMouseUpDown {
    latitude: number;
    longitude: number;
    point: {
        x: number;
        y: number;
    };
    originalEvent: Event;
    type: 'mouseup' | 'mousedown';
}
export {};
//# sourceMappingURL=typings.d.ts.map