import { Directive, Input, } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "./mapsync.service";
import * as i2 from "../mapbox.component";
export class OuiMapSyncDirective {
    mapSyncService;
    map;
    /** simple directive that syncs the maps with the given group */
    mapSyncGroup;
    constructor(mapSyncService, map) {
        this.mapSyncService = mapSyncService;
        this.map = map;
    }
    ngOnInit() { }
    ngAfterViewInit() {
        const interval = setInterval(() => {
            if (this.map?.map) {
                this.mapSyncService.registerMap(this.map, this.mapSyncGroup);
                clearInterval(interval);
            }
        }, 500);
    }
    ngOnDestroy() {
        this.mapSyncService.deRegisterMap(this.map, this.mapSyncGroup);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMapSyncDirective, deps: [{ token: i1.OuiMapSyncService }, { token: i2.OuiMapboxComponent }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.1", type: OuiMapSyncDirective, isStandalone: true, selector: "[oui-map-sync]", inputs: { mapSyncGroup: "mapSyncGroup" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMapSyncDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[oui-map-sync]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i1.OuiMapSyncService }, { type: i2.OuiMapboxComponent }], propDecorators: { mapSyncGroup: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFwc3luYy5kaXJlY3RpdmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL21hcGJveC9tYXBzeW5jL21hcHN5bmMuZGlyZWN0aXZlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFFTCxTQUFTLEVBQ1QsS0FBSyxHQUdOLE1BQU0sZUFBZSxDQUFDOzs7O0FBUXZCLE1BQU0sT0FBTyxtQkFBbUI7SUFNcEI7SUFDQTtJQU5WLGdFQUFnRTtJQUVyQyxZQUFZLENBQVM7SUFFaEQsWUFDVSxjQUFpQyxFQUNqQyxHQUF1QjtRQUR2QixtQkFBYyxHQUFkLGNBQWMsQ0FBbUI7UUFDakMsUUFBRyxHQUFILEdBQUcsQ0FBb0I7SUFDOUIsQ0FBQztJQUVHLFFBQVEsS0FBSSxDQUFDO0lBRWIsZUFBZTtRQUNwQixNQUFNLFFBQVEsR0FBRyxXQUFXLENBQUMsR0FBRyxFQUFFO1lBQ2hDLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztnQkFDbEIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBQzdELGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUMxQixDQUFDO1FBQ0gsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ1YsQ0FBQztJQUVNLFdBQVc7UUFDaEIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDakUsQ0FBQzt1R0F2QlUsbUJBQW1COzJGQUFuQixtQkFBbUI7OzJGQUFuQixtQkFBbUI7a0JBSi9CLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLGdCQUFnQjtvQkFDMUIsVUFBVSxFQUFFLElBQUk7aUJBQ2pCO3VIQUk0QixZQUFZO3NCQUF0QyxLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFmdGVyVmlld0luaXQsXG4gIERpcmVjdGl2ZSxcbiAgSW5wdXQsXG4gIE9uRGVzdHJveSxcbiAgT25Jbml0LFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE91aU1hcFN5bmNTZXJ2aWNlIH0gZnJvbSAnLi9tYXBzeW5jLnNlcnZpY2UnO1xuaW1wb3J0IHsgT3VpTWFwYm94Q29tcG9uZW50IH0gZnJvbSAnLi4vbWFwYm94LmNvbXBvbmVudCc7XG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ1tvdWktbWFwLXN5bmNdJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbn0pXG5leHBvcnQgY2xhc3MgT3VpTWFwU3luY0RpcmVjdGl2ZSBpbXBsZW1lbnRzIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95IHtcbiAgLyoqIHNpbXBsZSBkaXJlY3RpdmUgdGhhdCBzeW5jcyB0aGUgbWFwcyB3aXRoIHRoZSBnaXZlbiBncm91cCAqL1xuXG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pIG1hcFN5bmNHcm91cDogc3RyaW5nO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgbWFwU3luY1NlcnZpY2U6IE91aU1hcFN5bmNTZXJ2aWNlLFxuICAgIHByaXZhdGUgbWFwOiBPdWlNYXBib3hDb21wb25lbnRcbiAgKSB7fVxuXG4gIHB1YmxpYyBuZ09uSW5pdCgpIHt9XG5cbiAgcHVibGljIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICBjb25zdCBpbnRlcnZhbCA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgIGlmICh0aGlzLm1hcD8ubWFwKSB7XG4gICAgICAgIHRoaXMubWFwU3luY1NlcnZpY2UucmVnaXN0ZXJNYXAodGhpcy5tYXAsIHRoaXMubWFwU3luY0dyb3VwKTtcbiAgICAgICAgY2xlYXJJbnRlcnZhbChpbnRlcnZhbCk7XG4gICAgICB9XG4gICAgfSwgNTAwKTtcbiAgfVxuXG4gIHB1YmxpYyBuZ09uRGVzdHJveSgpIHtcbiAgICB0aGlzLm1hcFN5bmNTZXJ2aWNlLmRlUmVnaXN0ZXJNYXAodGhpcy5tYXAsIHRoaXMubWFwU3luY0dyb3VwKTtcbiAgfVxufVxuIl19