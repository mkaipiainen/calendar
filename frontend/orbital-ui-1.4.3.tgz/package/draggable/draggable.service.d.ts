import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class OuiDraggableService {
    private snappables;
    private snappablesSubject;
    snappables$: import("rxjs").Observable<{
        [groupId: string]: Set<ElementRef<any>>;
    }>;
    constructor();
    addSnappable(elementRef: ElementRef, id: string): void;
    removeSnappable(elementRef: ElementRef, id: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiDraggableService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiDraggableService>;
}
//# sourceMappingURL=draggable.service.d.ts.map