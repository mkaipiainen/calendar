export * from './hover.directive';
//# sourceMappingURL=public-api.d.ts.map