export declare function IsTabletOrMobile(): boolean;
//# sourceMappingURL=is-tablet-or-mobile.d.ts.map