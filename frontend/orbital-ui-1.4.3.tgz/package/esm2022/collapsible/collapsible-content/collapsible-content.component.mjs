import { ChangeDetectionStrategy, Component, Input, ViewChild, } from '@angular/core';
import { filter } from 'rxjs';
import { NgClass } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { ObserversModule } from '@angular/cdk/observers';
import * as i0 from "@angular/core";
import * as i1 from "../collapsible.service";
import * as i2 from "@angular/cdk/observers";
/**
 * A component part of a group of components that can be used to create collapsible content-blocks.
 * This component is used to contain the content of the collapsible block. Use this in conjunction with oui-collapsible-toggle.
 * Example usage:
 *
 * <oui-collapsible-toggle group="first-group"></oui-collapsible-toggle>
 * <oui-collapsible-content group=first-group">
 *   <div class="content">You can put any content here that you desire</div>
 * </oui-collapsible-content>
 */
export class OuiCollapsibleContentComponent {
    ouiCollapsibleService;
    cdr;
    destroyRef;
    /**
     * the group of the collapsible component. This needs to match the toggle that you want to use to
     * toggle the content.
     */
    group;
    isOpen = false;
    isOpeningFinished = false;
    isInitialHeightSet = false;
    contentContainer;
    constructor(ouiCollapsibleService, cdr, destroyRef) {
        this.ouiCollapsibleService = ouiCollapsibleService;
        this.cdr = cdr;
        this.destroyRef = destroyRef;
    }
    onContentChange() {
        if (this.isInitialHeightSet) {
            return;
        }
        this.doCalculateContent();
    }
    doCalculateContent() {
        const child = this.contentContainer.nativeElement.children[0];
        if (child) {
            if (this.isOpen) {
                this.contentContainer.nativeElement.style.height =
                    child.offsetHeight + 'px';
            }
            this.isInitialHeightSet = true;
        }
    }
    ngAfterViewInit() {
        this.ouiCollapsibleService.registerContent(this.group, this);
        this.destroyRef.onDestroy(() => {
            this.ouiCollapsibleService.deregisterCollapsible(this.group);
        });
        this.ouiCollapsibleService.refreshCollapsibleContentHeight$
            .pipe(filter((group) => {
            return group === this.group;
        }), takeUntilDestroyed(this.destroyRef))
            .subscribe((group) => {
            this.doCalculateContent();
        });
        this.ouiCollapsibleService.collapsibleToggled$
            .pipe(filter((data) => {
            return data.group === this.group;
        }), takeUntilDestroyed(this.destroyRef))
            .subscribe((data) => {
            this.isOpen = data.isOpen;
            if (this.isOpen) {
                const child = this.contentContainer.nativeElement.children[0];
                if (child) {
                    this.contentContainer.nativeElement.style.height =
                        child.offsetHeight + 'px';
                }
                setTimeout(() => {
                    this.isOpeningFinished = true;
                    this.cdr.detectChanges();
                }, 300);
            }
            else {
                this.isOpeningFinished = false;
                this.contentContainer.nativeElement.style.height = 0;
            }
            this.cdr.detectChanges();
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCollapsibleContentComponent, deps: [{ token: i1.OuiCollapsibleService }, { token: i0.ChangeDetectorRef }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiCollapsibleContentComponent, isStandalone: true, selector: "oui-collapsible-content", inputs: { group: "group" }, viewQueries: [{ propertyName: "contentContainer", first: true, predicate: ["contentContainer"], descendants: true }], ngImport: i0, template: "<div\n  class=\"oui-collapsible-content-container oui-scrollbar oui-scrollbar-auto\"\n  [ngClass]=\"{ 'is-open': isOpen, 'opening-finished': isOpeningFinished }\"\n  #contentContainer\n  (cdkObserveContent)=\"onContentChange()\"\n>\n  <ng-content></ng-content>\n</div>\n", styles: [":host{height:100%;width:100%;position:relative;display:flex}:host .oui-collapsible-content-container{opacity:0;pointer-events:none;height:0;width:100%;overflow:hidden;transition:height .3s,opacity .3s;overflow:hidden!important}:host .oui-collapsible-content-container.is-open{display:block;pointer-events:all;opacity:1}:host .oui-collapsible-content-container.opening-finished{overflow:auto}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: ObserversModule }, { kind: "directive", type: i2.CdkObserveContent, selector: "[cdkObserveContent]", inputs: ["cdkObserveContentDisabled", "debounce"], outputs: ["cdkObserveContent"], exportAs: ["cdkObserveContent"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCollapsibleContentComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-collapsible-content', standalone: true, imports: [NgClass, ObserversModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"oui-collapsible-content-container oui-scrollbar oui-scrollbar-auto\"\n  [ngClass]=\"{ 'is-open': isOpen, 'opening-finished': isOpeningFinished }\"\n  #contentContainer\n  (cdkObserveContent)=\"onContentChange()\"\n>\n  <ng-content></ng-content>\n</div>\n", styles: [":host{height:100%;width:100%;position:relative;display:flex}:host .oui-collapsible-content-container{opacity:0;pointer-events:none;height:0;width:100%;overflow:hidden;transition:height .3s,opacity .3s;overflow:hidden!important}:host .oui-collapsible-content-container.is-open{display:block;pointer-events:all;opacity:1}:host .oui-collapsible-content-container.opening-finished{overflow:auto}\n"] }]
        }], ctorParameters: () => [{ type: i1.OuiCollapsibleService }, { type: i0.ChangeDetectorRef }, { type: i0.DestroyRef }], propDecorators: { group: [{
                type: Input
            }], contentContainer: [{
                type: ViewChild,
                args: ['contentContainer']
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29sbGFwc2libGUtY29udGVudC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL2NvbGxhcHNpYmxlL2NvbGxhcHNpYmxlLWNvbnRlbnQvY29sbGFwc2libGUtY29udGVudC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL2NvbGxhcHNpYmxlL2NvbGxhcHNpYmxlLWNvbnRlbnQvY29sbGFwc2libGUtY29udGVudC5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBRUwsdUJBQXVCLEVBRXZCLFNBQVMsRUFHVCxLQUFLLEVBQ0wsU0FBUyxHQUNWLE1BQU0sZUFBZSxDQUFDO0FBS3ZCLE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDOUIsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzFDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSx3QkFBd0IsQ0FBQzs7OztBQUV6RDs7Ozs7Ozs7O0dBU0c7QUFTSCxNQUFNLE9BQU8sOEJBQThCO0lBZS9CO0lBQ0E7SUFDQTtJQWhCVjs7O09BR0c7SUFDTSxLQUFLLENBQVM7SUFFaEIsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUNmLGlCQUFpQixHQUFHLEtBQUssQ0FBQztJQUV6QixrQkFBa0IsR0FBRyxLQUFLLENBQUM7SUFFSixnQkFBZ0IsQ0FBYTtJQUU1RCxZQUNVLHFCQUE0QyxFQUM1QyxHQUFzQixFQUN0QixVQUFzQjtRQUZ0QiwwQkFBcUIsR0FBckIscUJBQXFCLENBQXVCO1FBQzVDLFFBQUcsR0FBSCxHQUFHLENBQW1CO1FBQ3RCLGVBQVUsR0FBVixVQUFVLENBQVk7SUFDN0IsQ0FBQztJQUVHLGVBQWU7UUFDcEIsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztZQUM1QixPQUFPO1FBQ1QsQ0FBQztRQUNELElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO0lBQzVCLENBQUM7SUFFTyxrQkFBa0I7UUFDeEIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDOUQsSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUNWLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNoQixJQUFJLENBQUMsZ0JBQWdCLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxNQUFNO29CQUM5QyxLQUFLLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztZQUM5QixDQUFDO1lBQ0QsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQztRQUNqQyxDQUFDO0lBQ0gsQ0FBQztJQUVELGVBQWU7UUFDYixJQUFJLENBQUMscUJBQXFCLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDN0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFO1lBQzdCLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDL0QsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMscUJBQXFCLENBQUMsZ0NBQWdDO2FBQ3hELElBQUksQ0FDSCxNQUFNLENBQUMsQ0FBQyxLQUFhLEVBQUUsRUFBRTtZQUN2QixPQUFPLEtBQUssS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQzlCLENBQUMsQ0FBQyxFQUNGLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FDcEM7YUFDQSxTQUFTLENBQUMsQ0FBQyxLQUFhLEVBQUUsRUFBRTtZQUMzQixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUM1QixDQUFDLENBQUMsQ0FBQztRQUVMLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxtQkFBbUI7YUFDM0MsSUFBSSxDQUNILE1BQU0sQ0FBQyxDQUFDLElBQXlCLEVBQUUsRUFBRTtZQUNuQyxPQUFPLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQztRQUNuQyxDQUFDLENBQUMsRUFDRixrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQ3BDO2FBQ0EsU0FBUyxDQUFDLENBQUMsSUFBeUIsRUFBRSxFQUFFO1lBQ3ZDLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQztZQUMxQixJQUFJLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFDaEIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzlELElBQUksS0FBSyxFQUFFLENBQUM7b0JBQ1YsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsTUFBTTt3QkFDOUMsS0FBSyxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7Z0JBQzlCLENBQUM7Z0JBQ0QsVUFBVSxDQUFDLEdBQUcsRUFBRTtvQkFDZCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDO29CQUM5QixJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUMzQixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDVixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sSUFBSSxDQUFDLGlCQUFpQixHQUFHLEtBQUssQ0FBQztnQkFDL0IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUN2RCxDQUFDO1lBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUMzQixDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7dUdBL0VVLDhCQUE4QjsyRkFBOUIsOEJBQThCLHFPQ3JDM0MsZ1JBUUEsbWNEMEJZLE9BQU8sbUZBQUUsZUFBZTs7MkZBR3ZCLDhCQUE4QjtrQkFSMUMsU0FBUzsrQkFDRSx5QkFBeUIsY0FHdkIsSUFBSSxXQUNQLENBQUMsT0FBTyxFQUFFLGVBQWUsQ0FBQyxtQkFDbEIsdUJBQXVCLENBQUMsTUFBTTttSkFPdEMsS0FBSztzQkFBYixLQUFLO2dCQU95QixnQkFBZ0I7c0JBQTlDLFNBQVM7dUJBQUMsa0JBQWtCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIENoYW5nZURldGVjdG9yUmVmLFxuICBDb21wb25lbnQsXG4gIERlc3Ryb3lSZWYsXG4gIEVsZW1lbnRSZWYsXG4gIElucHV0LFxuICBWaWV3Q2hpbGQsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgT3VpQ29sbGFwc2libGVTZXJ2aWNlLFxuICBJQ29sbGFwc2libGVUb2dnbGVkLFxufSBmcm9tICcuLi9jb2xsYXBzaWJsZS5zZXJ2aWNlJztcbmltcG9ydCB7IGZpbHRlciB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgTmdDbGFzcyB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyB0YWtlVW50aWxEZXN0cm95ZWQgfSBmcm9tICdAYW5ndWxhci9jb3JlL3J4anMtaW50ZXJvcCc7XG5pbXBvcnQgeyBPYnNlcnZlcnNNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jZGsvb2JzZXJ2ZXJzJztcblxuLyoqXG4gKiBBIGNvbXBvbmVudCBwYXJ0IG9mIGEgZ3JvdXAgb2YgY29tcG9uZW50cyB0aGF0IGNhbiBiZSB1c2VkIHRvIGNyZWF0ZSBjb2xsYXBzaWJsZSBjb250ZW50LWJsb2Nrcy5cbiAqIFRoaXMgY29tcG9uZW50IGlzIHVzZWQgdG8gY29udGFpbiB0aGUgY29udGVudCBvZiB0aGUgY29sbGFwc2libGUgYmxvY2suIFVzZSB0aGlzIGluIGNvbmp1bmN0aW9uIHdpdGggb3VpLWNvbGxhcHNpYmxlLXRvZ2dsZS5cbiAqIEV4YW1wbGUgdXNhZ2U6XG4gKlxuICogPG91aS1jb2xsYXBzaWJsZS10b2dnbGUgZ3JvdXA9XCJmaXJzdC1ncm91cFwiPjwvb3VpLWNvbGxhcHNpYmxlLXRvZ2dsZT5cbiAqIDxvdWktY29sbGFwc2libGUtY29udGVudCBncm91cD1maXJzdC1ncm91cFwiPlxuICogICA8ZGl2IGNsYXNzPVwiY29udGVudFwiPllvdSBjYW4gcHV0IGFueSBjb250ZW50IGhlcmUgdGhhdCB5b3UgZGVzaXJlPC9kaXY+XG4gKiA8L291aS1jb2xsYXBzaWJsZS1jb250ZW50PlxuICovXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdvdWktY29sbGFwc2libGUtY29udGVudCcsXG4gIHRlbXBsYXRlVXJsOiAnLi9jb2xsYXBzaWJsZS1jb250ZW50LmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vY29sbGFwc2libGUtY29udGVudC5jb21wb25lbnQuc2NzcyddLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbTmdDbGFzcywgT2JzZXJ2ZXJzTW9kdWxlXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIE91aUNvbGxhcHNpYmxlQ29udGVudENvbXBvbmVudCBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQge1xuICAvKipcbiAgICogdGhlIGdyb3VwIG9mIHRoZSBjb2xsYXBzaWJsZSBjb21wb25lbnQuIFRoaXMgbmVlZHMgdG8gbWF0Y2ggdGhlIHRvZ2dsZSB0aGF0IHlvdSB3YW50IHRvIHVzZSB0b1xuICAgKiB0b2dnbGUgdGhlIGNvbnRlbnQuXG4gICAqL1xuICBASW5wdXQoKSBncm91cDogc3RyaW5nO1xuXG4gIHB1YmxpYyBpc09wZW4gPSBmYWxzZTtcbiAgcHVibGljIGlzT3BlbmluZ0ZpbmlzaGVkID0gZmFsc2U7XG5cbiAgcHJpdmF0ZSBpc0luaXRpYWxIZWlnaHRTZXQgPSBmYWxzZTtcblxuICBAVmlld0NoaWxkKCdjb250ZW50Q29udGFpbmVyJykgY29udGVudENvbnRhaW5lcjogRWxlbWVudFJlZjtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIG91aUNvbGxhcHNpYmxlU2VydmljZTogT3VpQ29sbGFwc2libGVTZXJ2aWNlLFxuICAgIHByaXZhdGUgY2RyOiBDaGFuZ2VEZXRlY3RvclJlZixcbiAgICBwcml2YXRlIGRlc3Ryb3lSZWY6IERlc3Ryb3lSZWZcbiAgKSB7fVxuXG4gIHB1YmxpYyBvbkNvbnRlbnRDaGFuZ2UoKSB7XG4gICAgaWYgKHRoaXMuaXNJbml0aWFsSGVpZ2h0U2V0KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMuZG9DYWxjdWxhdGVDb250ZW50KCk7XG4gIH1cblxuICBwcml2YXRlIGRvQ2FsY3VsYXRlQ29udGVudCgpIHtcbiAgICBjb25zdCBjaGlsZCA9IHRoaXMuY29udGVudENvbnRhaW5lci5uYXRpdmVFbGVtZW50LmNoaWxkcmVuWzBdO1xuICAgIGlmIChjaGlsZCkge1xuICAgICAgaWYgKHRoaXMuaXNPcGVuKSB7XG4gICAgICAgIHRoaXMuY29udGVudENvbnRhaW5lci5uYXRpdmVFbGVtZW50LnN0eWxlLmhlaWdodCA9XG4gICAgICAgICAgY2hpbGQub2Zmc2V0SGVpZ2h0ICsgJ3B4JztcbiAgICAgIH1cbiAgICAgIHRoaXMuaXNJbml0aWFsSGVpZ2h0U2V0ID0gdHJ1ZTtcbiAgICB9XG4gIH1cblxuICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XG4gICAgdGhpcy5vdWlDb2xsYXBzaWJsZVNlcnZpY2UucmVnaXN0ZXJDb250ZW50KHRoaXMuZ3JvdXAsIHRoaXMpO1xuICAgIHRoaXMuZGVzdHJveVJlZi5vbkRlc3Ryb3koKCkgPT4ge1xuICAgICAgdGhpcy5vdWlDb2xsYXBzaWJsZVNlcnZpY2UuZGVyZWdpc3RlckNvbGxhcHNpYmxlKHRoaXMuZ3JvdXApO1xuICAgIH0pO1xuICAgIHRoaXMub3VpQ29sbGFwc2libGVTZXJ2aWNlLnJlZnJlc2hDb2xsYXBzaWJsZUNvbnRlbnRIZWlnaHQkXG4gICAgICAucGlwZShcbiAgICAgICAgZmlsdGVyKChncm91cDogc3RyaW5nKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGdyb3VwID09PSB0aGlzLmdyb3VwO1xuICAgICAgICB9KSxcbiAgICAgICAgdGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZilcbiAgICAgIClcbiAgICAgIC5zdWJzY3JpYmUoKGdyb3VwOiBzdHJpbmcpID0+IHtcbiAgICAgICAgdGhpcy5kb0NhbGN1bGF0ZUNvbnRlbnQoKTtcbiAgICAgIH0pO1xuXG4gICAgdGhpcy5vdWlDb2xsYXBzaWJsZVNlcnZpY2UuY29sbGFwc2libGVUb2dnbGVkJFxuICAgICAgLnBpcGUoXG4gICAgICAgIGZpbHRlcigoZGF0YTogSUNvbGxhcHNpYmxlVG9nZ2xlZCkgPT4ge1xuICAgICAgICAgIHJldHVybiBkYXRhLmdyb3VwID09PSB0aGlzLmdyb3VwO1xuICAgICAgICB9KSxcbiAgICAgICAgdGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZilcbiAgICAgIClcbiAgICAgIC5zdWJzY3JpYmUoKGRhdGE6IElDb2xsYXBzaWJsZVRvZ2dsZWQpID0+IHtcbiAgICAgICAgdGhpcy5pc09wZW4gPSBkYXRhLmlzT3BlbjtcbiAgICAgICAgaWYgKHRoaXMuaXNPcGVuKSB7XG4gICAgICAgICAgY29uc3QgY2hpbGQgPSB0aGlzLmNvbnRlbnRDb250YWluZXIubmF0aXZlRWxlbWVudC5jaGlsZHJlblswXTtcbiAgICAgICAgICBpZiAoY2hpbGQpIHtcbiAgICAgICAgICAgIHRoaXMuY29udGVudENvbnRhaW5lci5uYXRpdmVFbGVtZW50LnN0eWxlLmhlaWdodCA9XG4gICAgICAgICAgICAgIGNoaWxkLm9mZnNldEhlaWdodCArICdweCc7XG4gICAgICAgICAgfVxuICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5pc09wZW5pbmdGaW5pc2hlZCA9IHRydWU7XG4gICAgICAgICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgICAgfSwgMzAwKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0aGlzLmlzT3BlbmluZ0ZpbmlzaGVkID0gZmFsc2U7XG4gICAgICAgICAgdGhpcy5jb250ZW50Q29udGFpbmVyLm5hdGl2ZUVsZW1lbnQuc3R5bGUuaGVpZ2h0ID0gMDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICB9KTtcbiAgfVxufVxuIiwiPGRpdlxuICBjbGFzcz1cIm91aS1jb2xsYXBzaWJsZS1jb250ZW50LWNvbnRhaW5lciBvdWktc2Nyb2xsYmFyIG91aS1zY3JvbGxiYXItYXV0b1wiXG4gIFtuZ0NsYXNzXT1cInsgJ2lzLW9wZW4nOiBpc09wZW4sICdvcGVuaW5nLWZpbmlzaGVkJzogaXNPcGVuaW5nRmluaXNoZWQgfVwiXG4gICNjb250ZW50Q29udGFpbmVyXG4gIChjZGtPYnNlcnZlQ29udGVudCk9XCJvbkNvbnRlbnRDaGFuZ2UoKVwiXG4+XG4gIDxuZy1jb250ZW50PjwvbmctY29udGVudD5cbjwvZGl2PlxuIl19