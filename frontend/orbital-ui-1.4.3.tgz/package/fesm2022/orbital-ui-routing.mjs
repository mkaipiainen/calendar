import * as i0 from '@angular/core';
import { inject, Injectable } from '@angular/core';
import { Router, NavigationStart, NavigationEnd } from '@angular/router';
import { Subject, ReplaySubject, buffer, debounceTime, map } from 'rxjs';
import { isEqual, merge } from 'lodash-es';

class OuiRoutingService {
    router = inject(Router);
    previousPath;
    routeHistory = [];
    navigationStartSubject = new Subject();
    queryParamsSubject = new ReplaySubject(1);
    bufferedNavigationSubject = new Subject();
    bufferedNavigationTrigger$ = this.bufferedNavigationSubject
        .asObservable()
        .pipe(buffer(this.bufferedNavigationSubject.asObservable().pipe(debounceTime(300))), map(navigationEvents => {
        return navigationEvents.reduce((acc, curr) => {
            if (isEqual(curr.commands, acc.commands)) {
                const mergedQueryParams = merge({
                    ...acc.extras.queryParams,
                    ...curr.extras.queryParams,
                });
                const mergedExtras = merge({ ...acc.extras }, { ...curr.extras }, { queryParams: mergedQueryParams });
                return merge({
                    ...acc,
                    ...{ commands: curr.commands, extras: mergedExtras },
                });
            }
            else {
                return curr;
            }
        }, { commands: [], extras: {} });
    }));
    routeHistorySubject = new Subject();
    navigationStart$ = this.navigationStartSubject.asObservable();
    routeHistory$ = this.routeHistorySubject.asObservable();
    queryParams$ = this.router.routerState.root.queryParams;
    constructor() {
        this.bufferedNavigationTrigger$.subscribe(({ commands, extras }) => {
            this.router.navigate(commands, extras ?? {});
        });
        this.router.events.subscribe(event => {
            if (event instanceof NavigationStart) {
                const currentPath = this.getUrlWithoutParams(event.url);
                this.navigationStartSubject.next({
                    currentUrl: currentPath,
                    previousUrl: this.previousPath,
                    event,
                });
            }
            else if (event instanceof NavigationEnd) {
                this.previousPath = this.getUrlWithoutParams(event.url);
                this.routeHistory = [...this.routeHistory, event.url];
                this.routeHistorySubject.next(this.routeHistory);
            }
        });
    }
    getUrlWithoutParams(url) {
        const urlTree = this.router.parseUrl(url);
        const primaryChildren = urlTree.root.children['primary'];
        return primaryChildren
            ? primaryChildren.segments.map(it => it.path).join('/')
            : urlTree.root.segments.map(it => it.path).join('/');
    }
    /**
     * Sometimes we want to navigate to the same route repeatedly and add different query params
     * (for example when initialising filters). This allows us to do that without triggering
     * navigation for each query param change (which can lead to navigationEnd never triggering in angular).
     * This method collects all the changed query params and merges them together, finally navigating to the
     * target route with all the query params (after 300 ms)
     * @param commands
     * @param extras
     */
    bufferedNavigate(commands, extras) {
        this.bufferedNavigationSubject.next({ commands, extras });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiRoutingService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiRoutingService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiRoutingService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiRoutingService };
//# sourceMappingURL=orbital-ui-routing.mjs.map
