import { AfterViewInit, ElementRef, EventEmitter, OnChanges, OnDestroy, SimpleChanges, TemplateRef } from '@angular/core';
import { OuiDraggableDirective } from 'orbital-ui/draggable';
import { IPoint } from 'orbital-ui/core';
import { IOuiDragMove } from 'orbital-ui/draggable';
import * as i0 from "@angular/core";
/**
 * The options for the slider.
 *
 * min: the minimum value of the slider
 * max: the max value of the slider
 * sections: Define the sections into which the slider-bar is split.
 * minLabel: Define the label that should appear at the lowest value of the slider (Might not work currently)
 * maxLabel: Define the label that should appear at the highest value of the slider (Might not work currently)
 * alignment: Whether slider should be horizontal or vertical. CURRENTLY ONLY WORKS IN HORIZONTAL MODE
 * barMargin: Adds a margin to the bar
 * iconOptions: Possibility to add icons that are injected inside the thumbs.
 */
export interface IOuiSliderOptions extends Partial<IOuiSliderCombinedOptions> {
    min: number;
    max: number;
}
interface IOuiSliderCombinedOptions {
    min: number;
    max: number;
    minLabel: string;
    maxLabel: string;
    alignment: 'horizontal' | 'vertical';
    thumbContentTemplate?: TemplateRef<any>;
    thumbToContentTemplate?: TemplateRef<any>;
}
export declare class OuiSliderComponent implements AfterViewInit, OnDestroy, OnChanges {
    thumbFrom: ElementRef;
    thumbFromContainer: ElementRef;
    thumbFromDraggable: OuiDraggableDirective;
    thumbTo: ElementRef | undefined;
    thumbToContainer: ElementRef | undefined;
    thumbToDraggable: OuiDraggableDirective | undefined;
    sliderBar: ElementRef;
    /**
     * The model for 'smaller' value. Use this alone if you want just a single-thumb mode.
     */
    value: import("@angular/core").ModelSignal<any>;
    /**
     * The model for the 'larger' value. Can be only used together with value-input
     */
    valueTo: import("@angular/core").ModelSignal<any>;
    /**
     * The options of the slider.
     */
    options: import("@angular/core").InputSignal<IOuiSliderOptions>;
    combinedOptions: import("@angular/core").Signal<{
        min: number;
        max: number;
        minLabel: string;
        maxLabel: string;
        alignment: "horizontal" | "vertical";
        thumbContentTemplate?: TemplateRef<any> | undefined;
        thumbToContentTemplate?: TemplateRef<any> | undefined;
    } & {
        minLabel: string;
        maxLabel: string;
        min: number;
        max: number;
        alignment?: "horizontal" | "vertical" | undefined;
        thumbContentTemplate?: TemplateRef<any> | undefined;
        thumbToContentTemplate?: TemplateRef<any> | undefined;
    }>;
    /**
     * The event that's triggered whenever value changes (even by a little bit)
     */
    /**
     * The event that's triggered whenever the value changed, but this event is debounced by 300ms.
     */
    debouncedvalueChange: EventEmitter<any>;
    /**
     * The event that's triggered whenever valueTo changes (even by a little bit)
     */
    /**
     * The event that's triggered whenever the valueTo changed, but this event is debounced by 300ms.
     */
    debouncedValueToChange: EventEmitter<any>;
    private defaultOptions;
    private resizeObserver;
    private _debouncedValueToChange;
    private _debouncedvalueChange;
    constructor();
    private updateBarFill;
    private initValues;
    private setThumbPosition;
    private getThumbContainer;
    private getValue;
    onDragMove(type: 'from' | 'to', data: IOuiDragMove): void;
    private getOffset;
    constrainPosition(clientPosition: IPoint, type: 'from' | 'to'): IPoint;
    /**
     * Prevents the thumbs from crossing over one another
     * @param position
     * @param type
     * @private
     */
    private constrainPositionRange;
    private getPercentage;
    ngAfterViewInit(): void;
    private initResizeObserver;
    ngOnChanges(changes: SimpleChanges): void;
    private setThumbPositions;
    trackById(index: number, item: any): any;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiSliderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiSliderComponent, "oui-slider", never, { "value": { "alias": "value"; "required": true; "isSignal": true; }; "valueTo": { "alias": "valueTo"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": true; "isSignal": true; }; }, { "value": "valueChange"; "valueTo": "valueToChange"; "debouncedvalueChange": "debouncedvalueChange"; "debouncedValueToChange": "debouncedValueToChange"; }, never, never, true, never>;
}
export {};
//# sourceMappingURL=slider.component.d.ts.map