import { Directive, } from '@angular/core';
import { fromEvent } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i0 from "@angular/core";
/**
 * Can be used to add a ripple-element on an element when clicking on them. No options needed.
 */
export class OuiRippleDirective {
    elementRef;
    renderer;
    destroyRef;
    constructor(elementRef, renderer, destroyRef) {
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.destroyRef = destroyRef;
    }
    ngAfterViewInit() {
        fromEvent(this.elementRef.nativeElement, 'click')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            const parentBbox = this.elementRef.nativeElement.getBoundingClientRect();
            const rippleContainer = this.renderer.createElement('div');
            this.renderer.addClass(rippleContainer, 'oui-ripple-container');
            this.renderer.setStyle(rippleContainer, 'width', `${parentBbox.width}px`);
            this.renderer.setStyle(rippleContainer, 'position', 'absolute');
            this.renderer.setStyle(rippleContainer, 'overflow', 'hidden');
            this.renderer.setStyle(rippleContainer, 'top', '0');
            this.renderer.setStyle(rippleContainer, 'left', '0');
            this.renderer.setStyle(rippleContainer, 'pointerEvents', 'none');
            this.renderer.setStyle(rippleContainer, 'height', `${parentBbox.height}px`);
            this.renderer.setStyle(rippleContainer, 'borderRadius', getComputedStyle(this.elementRef.nativeElement).borderRadius);
            const ripple = this.renderer.createElement('div');
            this.renderer.addClass(ripple, 'oui-ripple');
            this.renderer.setStyle(this.elementRef.nativeElement, 'position', 'relative');
            const squareEdge = Math.max(parentBbox.width, parentBbox.height);
            const left = event.clientX - parentBbox.left - squareEdge / 2;
            const top = event.clientY - parentBbox.top - squareEdge / 2;
            this.renderer.setStyle(ripple, 'left', `${left}px`);
            this.renderer.setStyle(ripple, 'top', `${top}px`);
            this.renderer.setStyle(ripple, 'width', `${squareEdge}px`);
            this.renderer.setStyle(ripple, 'height', `${squareEdge}px`);
            this.renderer.setStyle(ripple, 'position', 'absolute');
            this.renderer.setStyle(ripple, 'transform', 'scale(0)');
            this.renderer.setStyle(ripple, 'borderRadius', '100%');
            this.renderer.setStyle(ripple, 'background', 'radial-gradient(circle at 50% 50%, rgba(132, 144, 171, 1) 0%, rgba(255, 210, 210, 0) 80%)');
            this.renderer.setStyle(ripple, 'transition', 'transform 1s, opacity 0.8s');
            this.renderer.setStyle(ripple, 'zIndex', '9999');
            this.renderer.setStyle(ripple, 'opacity', '1');
            this.renderer.appendChild(this.elementRef.nativeElement, rippleContainer);
            this.renderer.appendChild(rippleContainer, ripple);
            setTimeout(() => {
                this.renderer.addClass(ripple, 'oui-ripple-active');
                this.renderer.setStyle(ripple, 'transform', 'scale(2)');
                this.renderer.setStyle(ripple, 'opacity', '0');
            });
            setTimeout(() => {
                this.renderer.removeChild(rippleContainer, ripple);
                this.renderer.removeChild(this.elementRef.nativeElement, rippleContainer);
            }, 1500);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiRippleDirective, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.1", type: OuiRippleDirective, isStandalone: true, selector: "[ouiRipple]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiRippleDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ouiRipple]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: i0.DestroyRef }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmlwcGxlLmRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvcmlwcGxlL3JpcHBsZS5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUdMLFNBQVMsR0FHVixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQ2pDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDOztBQUVoRTs7R0FFRztBQUtILE1BQU0sT0FBTyxrQkFBa0I7SUFFbkI7SUFDQTtJQUNBO0lBSFYsWUFDVSxVQUFzQixFQUN0QixRQUFtQixFQUNuQixVQUFzQjtRQUZ0QixlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQ3RCLGFBQVEsR0FBUixRQUFRLENBQVc7UUFDbkIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtJQUM3QixDQUFDO0lBRUcsZUFBZTtRQUNwQixTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDO2FBQzlDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDekMsU0FBUyxDQUFDLENBQUMsS0FBVSxFQUFFLEVBQUU7WUFDeEIsTUFBTSxVQUFVLEdBQ2QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQztZQUN4RCxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMzRCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxlQUFlLEVBQUUsc0JBQXNCLENBQUMsQ0FBQztZQUNoRSxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FDcEIsZUFBZSxFQUNmLE9BQU8sRUFDUCxHQUFHLFVBQVUsQ0FBQyxLQUFLLElBQUksQ0FDeEIsQ0FBQztZQUNGLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFDaEUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLFVBQVUsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUM5RCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxlQUFlLEVBQUUsS0FBSyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBQ3BELElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLGVBQWUsRUFBRSxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDckQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsZUFBZSxFQUFFLGVBQWUsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUNqRSxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FDcEIsZUFBZSxFQUNmLFFBQVEsRUFDUixHQUFHLFVBQVUsQ0FBQyxNQUFNLElBQUksQ0FDekIsQ0FBQztZQUNGLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUNwQixlQUFlLEVBQ2YsY0FBYyxFQUNkLGdCQUFnQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUMsWUFBWSxDQUM3RCxDQUFDO1lBRUYsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDbEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFDO1lBQzdDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUNwQixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFDN0IsVUFBVSxFQUNWLFVBQVUsQ0FDWCxDQUFDO1lBRUYsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNqRSxNQUFNLElBQUksR0FBRyxLQUFLLENBQUMsT0FBTyxHQUFHLFVBQVUsQ0FBQyxJQUFJLEdBQUcsVUFBVSxHQUFHLENBQUMsQ0FBQztZQUM5RCxNQUFNLEdBQUcsR0FBRyxLQUFLLENBQUMsT0FBTyxHQUFHLFVBQVUsQ0FBQyxHQUFHLEdBQUcsVUFBVSxHQUFHLENBQUMsQ0FBQztZQUM1RCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBSSxJQUFJLENBQUMsQ0FBQztZQUNwRCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsR0FBRyxJQUFJLENBQUMsQ0FBQztZQUNsRCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsT0FBTyxFQUFFLEdBQUcsVUFBVSxJQUFJLENBQUMsQ0FBQztZQUMzRCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsUUFBUSxFQUFFLEdBQUcsVUFBVSxJQUFJLENBQUMsQ0FBQztZQUM1RCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1lBQ3ZELElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFDeEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLGNBQWMsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUN2RCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FDcEIsTUFBTSxFQUNOLFlBQVksRUFDWiwyRkFBMkYsQ0FDNUYsQ0FBQztZQUNGLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUNwQixNQUFNLEVBQ04sWUFBWSxFQUNaLDRCQUE0QixDQUM3QixDQUFDO1lBQ0YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztZQUNqRCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1lBRS9DLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUN2QixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFDN0IsZUFBZSxDQUNoQixDQUFDO1lBQ0YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1lBRW5ELFVBQVUsQ0FBQyxHQUFHLEVBQUU7Z0JBQ2QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLG1CQUFtQixDQUFDLENBQUM7Z0JBQ3BELElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxXQUFXLEVBQUUsVUFBVSxDQUFDLENBQUM7Z0JBQ3hELElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUM7WUFDakQsQ0FBQyxDQUFDLENBQUM7WUFDSCxVQUFVLENBQUMsR0FBRyxFQUFFO2dCQUNkLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLGVBQWUsRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFDbkQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQ3ZCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUM3QixlQUFlLENBQ2hCLENBQUM7WUFDSixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDWCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7dUdBdEZVLGtCQUFrQjsyRkFBbEIsa0JBQWtCOzsyRkFBbEIsa0JBQWtCO2tCQUo5QixTQUFTO21CQUFDO29CQUNULFFBQVEsRUFBRSxhQUFhO29CQUN2QixVQUFVLEVBQUUsSUFBSTtpQkFDakIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBEZXN0cm95UmVmLFxuICBEaXJlY3RpdmUsXG4gIEVsZW1lbnRSZWYsXG4gIFJlbmRlcmVyMixcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBmcm9tRXZlbnQgfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IHRha2VVbnRpbERlc3Ryb3llZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUvcnhqcy1pbnRlcm9wJztcblxuLyoqXG4gKiBDYW4gYmUgdXNlZCB0byBhZGQgYSByaXBwbGUtZWxlbWVudCBvbiBhbiBlbGVtZW50IHdoZW4gY2xpY2tpbmcgb24gdGhlbS4gTm8gb3B0aW9ucyBuZWVkZWQuXG4gKi9cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ1tvdWlSaXBwbGVdJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbn0pXG5leHBvcnQgY2xhc3MgT3VpUmlwcGxlRGlyZWN0aXZlIGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgZWxlbWVudFJlZjogRWxlbWVudFJlZixcbiAgICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjIsXG4gICAgcHJpdmF0ZSBkZXN0cm95UmVmOiBEZXN0cm95UmVmXG4gICkge31cblxuICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCkge1xuICAgIGZyb21FdmVudCh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ2NsaWNrJylcbiAgICAgIC5waXBlKHRha2VVbnRpbERlc3Ryb3llZCh0aGlzLmRlc3Ryb3lSZWYpKVxuICAgICAgLnN1YnNjcmliZSgoZXZlbnQ6IGFueSkgPT4ge1xuICAgICAgICBjb25zdCBwYXJlbnRCYm94ID1cbiAgICAgICAgICB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgY29uc3QgcmlwcGxlQ29udGFpbmVyID0gdGhpcy5yZW5kZXJlci5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5hZGRDbGFzcyhyaXBwbGVDb250YWluZXIsICdvdWktcmlwcGxlLWNvbnRhaW5lcicpO1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKFxuICAgICAgICAgIHJpcHBsZUNvbnRhaW5lcixcbiAgICAgICAgICAnd2lkdGgnLFxuICAgICAgICAgIGAke3BhcmVudEJib3gud2lkdGh9cHhgXG4gICAgICAgICk7XG4gICAgICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUocmlwcGxlQ29udGFpbmVyLCAncG9zaXRpb24nLCAnYWJzb2x1dGUnKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShyaXBwbGVDb250YWluZXIsICdvdmVyZmxvdycsICdoaWRkZW4nKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShyaXBwbGVDb250YWluZXIsICd0b3AnLCAnMCcpO1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKHJpcHBsZUNvbnRhaW5lciwgJ2xlZnQnLCAnMCcpO1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKHJpcHBsZUNvbnRhaW5lciwgJ3BvaW50ZXJFdmVudHMnLCAnbm9uZScpO1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKFxuICAgICAgICAgIHJpcHBsZUNvbnRhaW5lcixcbiAgICAgICAgICAnaGVpZ2h0JyxcbiAgICAgICAgICBgJHtwYXJlbnRCYm94LmhlaWdodH1weGBcbiAgICAgICAgKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShcbiAgICAgICAgICByaXBwbGVDb250YWluZXIsXG4gICAgICAgICAgJ2JvcmRlclJhZGl1cycsXG4gICAgICAgICAgZ2V0Q29tcHV0ZWRTdHlsZSh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCkuYm9yZGVyUmFkaXVzXG4gICAgICAgICk7XG5cbiAgICAgICAgY29uc3QgcmlwcGxlID0gdGhpcy5yZW5kZXJlci5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5hZGRDbGFzcyhyaXBwbGUsICdvdWktcmlwcGxlJyk7XG4gICAgICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUoXG4gICAgICAgICAgdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQsXG4gICAgICAgICAgJ3Bvc2l0aW9uJyxcbiAgICAgICAgICAncmVsYXRpdmUnXG4gICAgICAgICk7XG5cbiAgICAgICAgY29uc3Qgc3F1YXJlRWRnZSA9IE1hdGgubWF4KHBhcmVudEJib3gud2lkdGgsIHBhcmVudEJib3guaGVpZ2h0KTtcbiAgICAgICAgY29uc3QgbGVmdCA9IGV2ZW50LmNsaWVudFggLSBwYXJlbnRCYm94LmxlZnQgLSBzcXVhcmVFZGdlIC8gMjtcbiAgICAgICAgY29uc3QgdG9wID0gZXZlbnQuY2xpZW50WSAtIHBhcmVudEJib3gudG9wIC0gc3F1YXJlRWRnZSAvIDI7XG4gICAgICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUocmlwcGxlLCAnbGVmdCcsIGAke2xlZnR9cHhgKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShyaXBwbGUsICd0b3AnLCBgJHt0b3B9cHhgKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShyaXBwbGUsICd3aWR0aCcsIGAke3NxdWFyZUVkZ2V9cHhgKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShyaXBwbGUsICdoZWlnaHQnLCBgJHtzcXVhcmVFZGdlfXB4YCk7XG4gICAgICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUocmlwcGxlLCAncG9zaXRpb24nLCAnYWJzb2x1dGUnKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShyaXBwbGUsICd0cmFuc2Zvcm0nLCAnc2NhbGUoMCknKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShyaXBwbGUsICdib3JkZXJSYWRpdXMnLCAnMTAwJScpO1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKFxuICAgICAgICAgIHJpcHBsZSxcbiAgICAgICAgICAnYmFja2dyb3VuZCcsXG4gICAgICAgICAgJ3JhZGlhbC1ncmFkaWVudChjaXJjbGUgYXQgNTAlIDUwJSwgcmdiYSgxMzIsIDE0NCwgMTcxLCAxKSAwJSwgcmdiYSgyNTUsIDIxMCwgMjEwLCAwKSA4MCUpJ1xuICAgICAgICApO1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKFxuICAgICAgICAgIHJpcHBsZSxcbiAgICAgICAgICAndHJhbnNpdGlvbicsXG4gICAgICAgICAgJ3RyYW5zZm9ybSAxcywgb3BhY2l0eSAwLjhzJ1xuICAgICAgICApO1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKHJpcHBsZSwgJ3pJbmRleCcsICc5OTk5Jyk7XG4gICAgICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUocmlwcGxlLCAnb3BhY2l0eScsICcxJyk7XG5cbiAgICAgICAgdGhpcy5yZW5kZXJlci5hcHBlbmRDaGlsZChcbiAgICAgICAgICB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCxcbiAgICAgICAgICByaXBwbGVDb250YWluZXJcbiAgICAgICAgKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5hcHBlbmRDaGlsZChyaXBwbGVDb250YWluZXIsIHJpcHBsZSk7XG5cbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgdGhpcy5yZW5kZXJlci5hZGRDbGFzcyhyaXBwbGUsICdvdWktcmlwcGxlLWFjdGl2ZScpO1xuICAgICAgICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUocmlwcGxlLCAndHJhbnNmb3JtJywgJ3NjYWxlKDIpJyk7XG4gICAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShyaXBwbGUsICdvcGFjaXR5JywgJzAnKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIHRoaXMucmVuZGVyZXIucmVtb3ZlQ2hpbGQocmlwcGxlQ29udGFpbmVyLCByaXBwbGUpO1xuICAgICAgICAgIHRoaXMucmVuZGVyZXIucmVtb3ZlQ2hpbGQoXG4gICAgICAgICAgICB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCxcbiAgICAgICAgICAgIHJpcHBsZUNvbnRhaW5lclxuICAgICAgICAgICk7XG4gICAgICAgIH0sIDE1MDApO1xuICAgICAgfSk7XG4gIH1cbn1cbiJdfQ==