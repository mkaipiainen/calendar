export * from './local-storage.service';
//# sourceMappingURL=public-api.d.ts.map