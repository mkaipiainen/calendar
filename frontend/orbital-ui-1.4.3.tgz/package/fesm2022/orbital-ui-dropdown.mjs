import * as i0 from '@angular/core';
import { Injectable, EventEmitter, Component, ChangeDetectionStrategy, Inject, Input, ViewChild, Output, HostListener } from '@angular/core';
import * as i1 from 'orbital-ui/routing';
import { createPopper } from '@popperjs/core';
import * as i2 from '@angular/common';
import { DOCUMENT, CommonModule } from '@angular/common';
import { OuiRippleDirective } from 'orbital-ui/ripple';

/**
 * Service used to control dropdowns in the application. Tracks all dropdowns, and has a public method to close all dropdowns.
 */
// TODO: Add a method to close a single dropdown
class OuiDropdownService {
    ouiRoutingService;
    dropdowns = [];
    constructor(ouiRoutingService) {
        this.ouiRoutingService = ouiRoutingService;
        this.ouiRoutingService.navigationStart$.subscribe(event => {
            if (event.previousUrl !== event.currentUrl) {
                this.closeAll();
            }
        });
    }
    register(dropdown) {
        this.dropdowns.push(dropdown);
    }
    closeAll() {
        for (const dropdown of this.dropdowns) {
            dropdown.close();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDropdownService, deps: [{ token: i1.OuiRoutingService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDropdownService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDropdownService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.OuiRoutingService }] });

// TODO: Extract content and toggle into their own directives
/**
 * Component used to create dropdowns. Used by passing a content and toggle template-references.
 * @Input() disableCloseOnWindowResize: boolean
 *   If set to true, dropdown doesn't close when window is resized. Normally all dropdowns close when window is resized.
 * @Input() content: TemplateRef<any>
 *   A templateRef that will be used to inject the content into the dropdown.
 * @Input toggle: TemplateRef<any>
 *   A templateRef that will be used to inject the toggle into the DOM
 * @Input() isOpen: boolean
 *   Input to control whether or not the dropdown is open
 * @Output() isOpenChange: EventEmitter<boolean>
 *   Output that triggers whenever the dropdown either opens or is closed
 *
 *
 *   Example use:
 *
 *   <oui-dropdown [toggle]="toggle" [content]="content">
 *     <ng-template #toggle>
 *       <div>This element will be used as the toggle</div>
 *     </ng-template>
 *     <ng-template #content>
 *       <div class="dropdown-content-wrapper">
 *         <div class="dropdown-item">Item1</div>
 *         <div class="dropdown-item">Item2</div>
 *         <div class="dropdown-item">Item3</div>
 *       </div>
 *   </oui-dropdown
 */
class OuiDropdownComponent {
    vcr;
    zone;
    dropdownService;
    document;
    disableCloseOnWindowResize = false;
    content;
    toggle;
    isOpen = false;
    disabled = false;
    origin;
    wrapper;
    isOpenChange = new EventEmitter();
    dropdownView;
    popperRef;
    constructor(vcr, zone, dropdownService, document) {
        this.vcr = vcr;
        this.zone = zone;
        this.dropdownService = dropdownService;
        this.document = document;
    }
    ngAfterViewInit() {
        this.dropdownService.register(this);
    }
    doToggleDropdown() {
        if (this.disabled) {
            return;
        }
        if (!this.isOpen) {
            this.open();
        }
        else {
            this.close();
        }
    }
    open() {
        if (this.isOpen || this.popperRef || this.dropdownView) {
            return;
        }
        this.isOpen = true;
        this.isOpenChange.emit(this.isOpen);
        this.dropdownView = this.vcr.createEmbeddedView(this.content);
        const dropdown = this.dropdownView.rootNodes[0];
        dropdown.classList.add('oui-dropdown');
        this.document.body.appendChild(dropdown);
        dropdown.style.minWidth =
            this.origin.nativeElement.getBoundingClientRect().width + 'px';
        this.zone.runOutsideAngular(() => {
            this.popperRef = createPopper(this.origin.nativeElement, dropdown, {
                placement: 'bottom-start',
                modifiers: [
                    {
                        name: 'preventOverflow',
                        options: {
                            altAxis: true,
                            padding: 5,
                        },
                    },
                ],
            });
        });
        setTimeout(() => {
            dropdown.classList.add('open');
        });
        // Sometimes when content of the dropdown is built dynamically
        // popper doesn't properly flip the dropdown
        // so we need to make popper do it manually while dropdown is opening
        const observer = new ResizeObserver(() => {
            this.popperRef?.update();
        });
        observer.observe(dropdown);
        setTimeout(() => {
            observer.unobserve(dropdown);
        }, 1000);
    }
    onClick(event, targetElement) {
        if (!targetElement || !this.origin) {
            return;
        }
        const originBbox = this.origin.nativeElement.getBoundingClientRect();
        const dropdownBbox = this.dropdownView?.rootNodes?.[0]?.getBoundingClientRect();
        if (!dropdownBbox || !originBbox) {
            return;
        }
        const clickedInsideOrigin = event.clientX >= originBbox.left &&
            event.clientX <= originBbox.right &&
            event.clientY >= originBbox.top &&
            event.clientY <= originBbox.bottom;
        const clickedInsideDropdown = event.clientX >= dropdownBbox.left &&
            event.clientX <= dropdownBbox.right &&
            event.clientY >= dropdownBbox.top &&
            event.clientY <= dropdownBbox.bottom;
        if (!clickedInsideOrigin && !clickedInsideDropdown) {
            this.close();
        }
    }
    onResize() {
        if (!this.disableCloseOnWindowResize) {
            this.close();
        }
    }
    close(timeout = 200) {
        if (this.dropdownView) {
            this.dropdownView?.rootNodes?.[0]?.classList?.add('hide');
            this.dropdownView?.rootNodes?.[0]?.classList?.remove('open');
        }
        setTimeout(() => {
            if (this.popperRef) {
                this.popperRef.destroy();
            }
            if (this.dropdownView) {
                this.dropdownView.destroy();
            }
            this.isOpen = false;
            this.dropdownView = null;
            this.popperRef = null;
            this.isOpenChange.emit(this.isOpen);
        }, timeout);
    }
    ngOnChanges(changes) {
        if ('isOpen' in changes) {
            if (changes['isOpen'].currentValue) {
                this.open();
            }
            else {
                this.close();
            }
        }
    }
    ngOnDestroy() {
        this.close();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDropdownComponent, deps: [{ token: i0.ViewContainerRef }, { token: i0.NgZone }, { token: OuiDropdownService }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiDropdownComponent, isStandalone: true, selector: "oui-dropdown", inputs: { disableCloseOnWindowResize: "disableCloseOnWindowResize", content: "content", toggle: "toggle", isOpen: "isOpen", disabled: "disabled" }, outputs: { isOpenChange: "isOpenChange" }, host: { listeners: { "document:click": "onClick($event,$event.target)", "window:resize": "onResize($event)" } }, viewQueries: [{ propertyName: "origin", first: true, predicate: ["origin"], descendants: true }, { propertyName: "wrapper", first: true, predicate: ["wrapper"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div\n  [ngClass]=\"{ disabled: disabled }\"\n  ouiRipple\n  class=\"oui-dropdown-container\"\n  #origin\n  (click)=\"doToggleDropdown()\"\n>\n  <ng-container *ngTemplateOutlet=\"toggle\"></ng-container>\n</div>\n", styles: [":host{width:100%;height:100%;position:relative;z-index:1;display:flex;flex:1}:host .oui-dropdown-fill{transition:opacity .5s;background:var(--dropdown-background-color);opacity:1;height:10px;position:absolute;bottom:0}:host .oui-dropdown-fill.hide{opacity:0}:host .oui-dropdown-container{display:flex;flex:1 0 auto;flex-direction:column;border-radius:var(--border-radius-default);width:100%}:host .oui-dropdown-container.disabled{pointer-events:none;opacity:.8}:host .oui-dropdown-container:hover{cursor:pointer}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: OuiRippleDirective, selector: "[ouiRipple]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDropdownComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-dropdown', standalone: true, imports: [CommonModule, OuiRippleDirective], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  [ngClass]=\"{ disabled: disabled }\"\n  ouiRipple\n  class=\"oui-dropdown-container\"\n  #origin\n  (click)=\"doToggleDropdown()\"\n>\n  <ng-container *ngTemplateOutlet=\"toggle\"></ng-container>\n</div>\n", styles: [":host{width:100%;height:100%;position:relative;z-index:1;display:flex;flex:1}:host .oui-dropdown-fill{transition:opacity .5s;background:var(--dropdown-background-color);opacity:1;height:10px;position:absolute;bottom:0}:host .oui-dropdown-fill.hide{opacity:0}:host .oui-dropdown-container{display:flex;flex:1 0 auto;flex-direction:column;border-radius:var(--border-radius-default);width:100%}:host .oui-dropdown-container.disabled{pointer-events:none;opacity:.8}:host .oui-dropdown-container:hover{cursor:pointer}\n"] }]
        }], ctorParameters: () => [{ type: i0.ViewContainerRef }, { type: i0.NgZone }, { type: OuiDropdownService }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { disableCloseOnWindowResize: [{
                type: Input
            }], content: [{
                type: Input
            }], toggle: [{
                type: Input
            }], isOpen: [{
                type: Input
            }], disabled: [{
                type: Input
            }], origin: [{
                type: ViewChild,
                args: ['origin']
            }], wrapper: [{
                type: ViewChild,
                args: ['wrapper']
            }], isOpenChange: [{
                type: Output
            }], onClick: [{
                type: HostListener,
                args: ['document:click', ['$event', '$event.target']]
            }], onResize: [{
                type: HostListener,
                args: ['window:resize', ['$event']]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiDropdownComponent, OuiDropdownService };
//# sourceMappingURL=orbital-ui-dropdown.mjs.map
