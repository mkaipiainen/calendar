import { IPoint } from 'orbital-ui/core';
import { OuiDraggableDirective } from './draggable.directive';
export declare function GetTransformDelta(startPosition: IPoint, mousePosition: IPoint): {
    x: number;
    y: number;
};
export declare function getDistanceBetweenPointAndElement(point: IPoint, element: HTMLElement | undefined): number;
export declare function GetTranslateXY(element: HTMLElement): {
    x: number;
    y: number;
};
export declare function GetElementViewportLocation(element: HTMLElement): {
    x: number;
    y: number;
};
export declare function GetTranslatedBbox(draggable: OuiDraggableDirective, delta: IPoint): DOMRect;
export declare function GetBboxMovedToXy(rect: DOMRect, targetXy: IPoint): {
    left: number;
    right: number;
    top: number;
    bottom: number;
    width: number;
    height: number;
    x: number;
    y: number;
    toJSON: () => void;
};
export declare function CopyBbox(bbox: DOMRect): {
    x: number;
    y: number;
    width: number;
    height: number;
    left: number;
    right: number;
    top: number;
    bottom: number;
    toJSON: () => any;
};
export declare function GetBboxCenteredToAnotherBbox(bboxToMove: DOMRect, bboxToCenterOn: DOMRect): {
    left: number;
    right: number;
    top: number;
    bottom: number;
    width: number;
    height: number;
    x: number;
    y: number;
    toJSON: () => void;
};
export declare function GetXyBetweenBboxes(bbox1: DOMRect, bbox2: DOMRect): {
    x: number;
    y: number;
};
export declare function GetViewportPointFromEvent(event: MouseEvent | TouchEvent): IPoint;
export declare function GetTransformRequiredToMoveElement(element: HTMLElement, targetPoint: IPoint): IPoint;
//# sourceMappingURL=helpers.d.ts.map