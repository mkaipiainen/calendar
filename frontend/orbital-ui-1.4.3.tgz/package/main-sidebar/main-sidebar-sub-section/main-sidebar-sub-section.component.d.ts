import { AfterViewInit, DestroyRef } from '@angular/core';
import { MAIN_SIDEBAR_SECTION_TYPES, OuiMainSidebarService } from '../main-sidebar.service';
import { ComponentType } from '@angular/cdk/overlay';
import { IOuiIconOptions } from 'orbital-ui/icon';
import * as i0 from "@angular/core";
export type OuiMainSidebarSubsectionOptions = {
    icon: string;
    iconOptions?: IOuiIconOptions;
    id: string;
    type: typeof MAIN_SIDEBAR_SECTION_TYPES.SUBSECTION;
    component: ComponentType<any>;
    label?: string;
    isActive?: () => boolean;
    inputs: {
        [key: string]: any;
    };
};
export declare class OuiMainSidebarSubSectionComponent implements AfterViewInit {
    private ouiMainSidebarService;
    private destroyRef;
    isSidebarOpen: import("@angular/core").WritableSignal<boolean>;
    isOpen: import("@angular/core").WritableSignal<boolean>;
    options: import("@angular/core").InputSignal<OuiMainSidebarSubsectionOptions>;
    constructor(ouiMainSidebarService: OuiMainSidebarService, destroyRef: DestroyRef);
    onClick(): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiMainSidebarSubSectionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiMainSidebarSubSectionComponent, "oui-main-sidebar-sub-section", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=main-sidebar-sub-section.component.d.ts.map