import { ScatterplotLayer } from '@deck.gl/layers/typed';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { take } from 'rxjs';
import { CompositeLayer } from '@deck.gl/core/typed';
import { OuiIconComponent } from 'orbital-ui/icon';
import { OuiRippleDirective } from 'orbital-ui/ripple';
import * as i0 from "@angular/core";
export class DeckGeolocateLayer extends BaseDeckLayer {
    options;
    isGeolocateStarted = false;
    location = [0, 0];
    accuracy = {
        position: [0, 0],
        radius: 0,
    };
    heading = null;
    pingState = {
        isInProgress: false,
        isDone: false,
    };
    interval;
    constructor() {
        super();
    }
    onGeolocateEvent(data) {
        this.location = [data.coords.longitude, data.coords.latitude];
        this.accuracy.position = [data.coords.longitude, data.coords.latitude];
        this.accuracy.radius = data.coords.accuracy;
        this.deck.refreshLayer(this);
    }
    locateUser() {
        this.deck.map.flyTo({
            latitude: this.location[1],
            longitude: this.location[0],
            zoom: 15,
            transitionDuration: 'auto',
        });
    }
    getLayer() {
        if (!this.isGeolocateStarted) {
            this.isGeolocateStarted = true;
            if (!this.interval) {
                this.interval = setInterval(() => {
                    this.pingState = {
                        isInProgress: true,
                        isDone: false,
                    };
                    this.deck.refreshLayer(this);
                    setTimeout(() => {
                        this.pingState = {
                            isInProgress: false,
                            isDone: true,
                        };
                        this.deck.refreshLayer(this);
                        setTimeout(() => {
                            this.pingState = {
                                isInProgress: false,
                                isDone: false,
                            };
                            this.deck.refreshLayer(this);
                        }, 1000);
                    }, 1000);
                }, 3000);
            }
            this.deck.onLoad$
                .pipe(takeUntilDestroyed(this.destroyRef), take(1))
                .subscribe(() => {
                if (navigator.geolocation) {
                    navigator.geolocation.watchPosition(this.onGeolocateEvent.bind(this));
                }
            });
        }
        return new GeolocateLayer({
            options: this.options,
            location: this.location,
            accuracy: this.accuracy,
            heading: this.heading,
            pingState: this.pingState,
        });
    }
    ngOnDestroy() {
        if (this.interval) {
            clearInterval(this.interval);
        }
        super.ngOnDestroy();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckGeolocateLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckGeolocateLayer, isStandalone: true, selector: "oui-deck-geolocate-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '<div class="geolocate" ouiRipple (click)="locateUser()"><oui-icon icon="assets/icons/location.svg" [options]="{fillColor: \'oui-mapbox-geolocate-color\', strokeColor: \'oui-mapbox-geolocate-color\', size: \'18px\'}"></oui-icon></div>', isInline: true, styles: [":host{position:absolute;top:1rem;right:1rem}:host .geolocate{height:var(--oui-mapbox-geolocate-height);width:var(--oui-mapbox-geolocate-width);display:flex;justify-content:center;align-items:center;background-color:var(--oui-mapbox-geolocate-background);border-radius:var(--border-radius-default);padding:.5rem;transition:background-color .3s;box-shadow:var(--box-shadow-bottom)}:host .geolocate:hover{cursor:pointer;background-color:var(--oui-mapbox-geolocate-background-hover)}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "directive", type: OuiRippleDirective, selector: "[ouiRipple]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckGeolocateLayer, decorators: [{
            type: Component,
            args: [{ selector: 'oui-deck-geolocate-layer', template: '<div class="geolocate" ouiRipple (click)="locateUser()"><oui-icon icon="assets/icons/location.svg" [options]="{fillColor: \'oui-mapbox-geolocate-color\', strokeColor: \'oui-mapbox-geolocate-color\', size: \'18px\'}"></oui-icon></div>', standalone: true, imports: [OuiIconComponent, OuiRippleDirective], changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{position:absolute;top:1rem;right:1rem}:host .geolocate{height:var(--oui-mapbox-geolocate-height);width:var(--oui-mapbox-geolocate-width);display:flex;justify-content:center;align-items:center;background-color:var(--oui-mapbox-geolocate-background);border-radius:var(--border-radius-default);padding:.5rem;transition:background-color .3s;box-shadow:var(--box-shadow-bottom)}:host .geolocate:hover{cursor:pointer;background-color:var(--oui-mapbox-geolocate-background-hover)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
// TODO: Implement heading
class GeolocateLayer extends CompositeLayer {
    options;
    location = [0, 0];
    accuracy = {
        position: [0, 0],
        radius: 0,
    };
    heading = 0;
    pingState = {
        isInProgress: false,
        isDone: false,
    };
    constructor(props) {
        super(props);
        this.options = props.options;
        this.accuracy = props.accuracy;
        this.location = props.location;
        this.heading = props.heading;
        this.pingState = props.pingState;
    }
    shouldUpdateState({ changeFlags }) {
        return changeFlags.propsChanged || changeFlags.dataChanged;
    }
    // override updateState({ props, oldProps, changeFlags }: any) {
    //   return true;
    // }
    renderLayers() {
        const layers = [
            new ScatterplotLayer(this.getSubLayerProps({
                data: [this.accuracy],
                id: 'accuracy',
                radiusUnits: 'meters',
                getPosition: (d) => {
                    return d.position;
                },
                stroked: false,
                filled: true,
                getFillColor: this.options.getFillColor ?? [29, 161, 242, 125],
                getRadius: (d) => {
                    return d.radius;
                },
            })),
            new ScatterplotLayer(this.getSubLayerProps({
                data: [this.location],
                transitions: {
                    getFillColor: 1000,
                    getRadius: 1000,
                },
                id: 'ping',
                getRadius: this.pingState.isDone
                    ? 0
                    : this.pingState.isInProgress
                        ? 30
                        : 0,
                getFillColor: () => {
                    if (this.pingState.isDone || this.pingState.isInProgress) {
                        return [29, 161, 242, 0];
                    }
                    else {
                        return [26, 122, 200, 255];
                    }
                },
                filled: true,
                stroked: false,
                getPosition: (d) => d,
                radiusUnits: 'pixels',
                updateTriggers: {
                    getFillColor: this.pingState,
                    getRadius: this.pingState,
                },
            })),
            new ScatterplotLayer(this.getSubLayerProps({
                data: [this.location],
                id: 'location',
                radiusUnits: 'pixels',
                getPosition: (d) => d,
                stroked: this.options.stroked ?? true,
                filled: this.options.filled ?? true,
                getRadius: this.options.getRadius ?? 7,
                getFillColor: this.options.getFillColor ?? [29, 161, 242, 255],
                getLineColor: this.options.getLineColor ?? [255, 255, 255, 255],
                getLineWidth: this.options.getLineWidth ?? 2,
                lineWidthMinPixels: this.options.getLineWidth ?? 2,
            })),
        ];
        return layers;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay1nZW9sb2NhdGUtbGF5ZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL21hcGJveC9nZW9sb2NhdGUtbGF5ZXIvZGVjay1nZW9sb2NhdGUtbGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFNekQsT0FBTyxFQUFFLHVCQUF1QixFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDMUUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzdELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDNUIsT0FBTyxFQUFFLGNBQWMsRUFBcUIsTUFBTSxxQkFBcUIsQ0FBQztBQUN4RSxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUNuRCxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQzs7QUE0QnZELE1BQU0sT0FBTyxrQkFBbUIsU0FBUSxhQUFzQztJQUN6QyxPQUFPLENBQTZCO0lBQy9ELGtCQUFrQixHQUFHLEtBQUssQ0FBQztJQUMzQixRQUFRLEdBQWMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7SUFFN0IsUUFBUSxHQUFjO1FBQzVCLFFBQVEsRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDaEIsTUFBTSxFQUFFLENBQUM7S0FDVixDQUFDO0lBRU0sT0FBTyxHQUFrQixJQUFJLENBQUM7SUFDOUIsU0FBUyxHQUFlO1FBQzlCLFlBQVksRUFBRSxLQUFLO1FBQ25CLE1BQU0sRUFBRSxLQUFLO0tBQ2QsQ0FBQztJQUNNLFFBQVEsQ0FBTTtJQUV0QjtRQUNFLEtBQUssRUFBRSxDQUFDO0lBQ1YsQ0FBQztJQUVPLGdCQUFnQixDQUFDLElBQVM7UUFDaEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDOUQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ3ZFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQzVDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQy9CLENBQUM7SUFFTSxVQUFVO1FBQ2YsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO1lBQ2xCLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUMxQixTQUFTLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7WUFDM0IsSUFBSSxFQUFFLEVBQUU7WUFDUixrQkFBa0IsRUFBRSxNQUFNO1NBQzNCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxRQUFRO1FBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1lBQzdCLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxJQUFJLENBQUM7WUFDL0IsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztnQkFDbkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxXQUFXLENBQUMsR0FBRyxFQUFFO29CQUMvQixJQUFJLENBQUMsU0FBUyxHQUFHO3dCQUNmLFlBQVksRUFBRSxJQUFJO3dCQUNsQixNQUFNLEVBQUUsS0FBSztxQkFDZCxDQUFDO29CQUNGLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO29CQUM3QixVQUFVLENBQUMsR0FBRyxFQUFFO3dCQUNkLElBQUksQ0FBQyxTQUFTLEdBQUc7NEJBQ2YsWUFBWSxFQUFFLEtBQUs7NEJBQ25CLE1BQU0sRUFBRSxJQUFJO3lCQUNiLENBQUM7d0JBQ0YsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7d0JBRTdCLFVBQVUsQ0FBQyxHQUFHLEVBQUU7NEJBQ2QsSUFBSSxDQUFDLFNBQVMsR0FBRztnQ0FDZixZQUFZLEVBQUUsS0FBSztnQ0FDbkIsTUFBTSxFQUFFLEtBQUs7NkJBQ2QsQ0FBQzs0QkFDRixJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsQ0FBQzt3QkFDL0IsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDO29CQUNYLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztnQkFDWCxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDWCxDQUFDO1lBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPO2lCQUNkLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNsRCxTQUFTLENBQUMsR0FBRyxFQUFFO2dCQUNkLElBQUksU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDO29CQUMxQixTQUFTLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FDakMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FDakMsQ0FBQztnQkFDSixDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDO1FBQ0QsT0FBTyxJQUFJLGNBQWMsQ0FBQztZQUN4QixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87WUFDckIsUUFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO1lBQ3ZCLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtZQUN2QixPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU87WUFDckIsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO1NBQzFCLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFZSxXQUFXO1FBQ3pCLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ2xCLGFBQWEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDL0IsQ0FBQztRQUNELEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQztJQUN0QixDQUFDO3VHQXhGVSxrQkFBa0I7MkZBQWxCLGtCQUFrQiwySUFOM0IsMk9BQTJPLDJpQkFHbk8sZ0JBQWdCLGtGQUFFLGtCQUFrQjs7MkZBR25DLGtCQUFrQjtrQkFUOUIsU0FBUzsrQkFDRSwwQkFBMEIsWUFFbEMsMk9BQTJPLGNBQ2pPLElBQUksV0FFUCxDQUFDLGdCQUFnQixFQUFFLGtCQUFrQixDQUFDLG1CQUM5Qix1QkFBdUIsQ0FBQyxNQUFNO3dEQUdaLE9BQU87c0JBQXpDLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFOztBQXlGM0IsMEJBQTBCO0FBQzFCLE1BQU0sY0FBZSxTQUFRLGNBQW1CO0lBQ3RDLE9BQU8sQ0FBNkI7SUFDcEMsUUFBUSxHQUFjLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzdCLFFBQVEsR0FBYztRQUM1QixRQUFRLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ2hCLE1BQU0sRUFBRSxDQUFDO0tBQ1YsQ0FBQztJQUNNLE9BQU8sR0FBa0IsQ0FBQyxDQUFDO0lBQzNCLFNBQVMsR0FBZTtRQUM5QixZQUFZLEVBQUUsS0FBSztRQUNuQixNQUFNLEVBQUUsS0FBSztLQUNkLENBQUM7SUFDRixZQUFZLEtBQTZCO1FBQ3ZDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNiLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUM3QixJQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUM7UUFDL0IsSUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDO1FBQy9CLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUM3QixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxTQUFTLENBQUM7SUFDbkMsQ0FBQztJQUVRLGlCQUFpQixDQUFDLEVBQUUsV0FBVyxFQUFPO1FBQzdDLE9BQU8sV0FBVyxDQUFDLFlBQVksSUFBSSxXQUFXLENBQUMsV0FBVyxDQUFDO0lBQzdELENBQUM7SUFFRCxnRUFBZ0U7SUFDaEUsaUJBQWlCO0lBQ2pCLElBQUk7SUFFSyxZQUFZO1FBQ25CLE1BQU0sTUFBTSxHQUFVO1lBQ3BCLElBQUksZ0JBQWdCLENBQ2xCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDcEIsSUFBSSxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztnQkFDckIsRUFBRSxFQUFFLFVBQVU7Z0JBQ2QsV0FBVyxFQUFFLFFBQVE7Z0JBQ3JCLFdBQVcsRUFBRSxDQUFDLENBQVksRUFBRSxFQUFFO29CQUM1QixPQUFPLENBQUMsQ0FBQyxRQUFRLENBQUM7Z0JBQ3BCLENBQUM7Z0JBQ0QsT0FBTyxFQUFFLEtBQUs7Z0JBQ2QsTUFBTSxFQUFFLElBQUk7Z0JBQ1osWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxJQUFJLENBQUMsRUFBRSxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDO2dCQUM5RCxTQUFTLEVBQUUsQ0FBQyxDQUFZLEVBQUUsRUFBRTtvQkFDMUIsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDO2dCQUNsQixDQUFDO2FBQ0YsQ0FBQyxDQUNIO1lBQ0QsSUFBSSxnQkFBZ0IsQ0FDbEIsSUFBSSxDQUFDLGdCQUFnQixDQUFDO2dCQUNwQixJQUFJLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO2dCQUNyQixXQUFXLEVBQUU7b0JBQ1gsWUFBWSxFQUFFLElBQUk7b0JBQ2xCLFNBQVMsRUFBRSxJQUFJO2lCQUNoQjtnQkFDRCxFQUFFLEVBQUUsTUFBTTtnQkFDVixTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNO29CQUM5QixDQUFDLENBQUMsQ0FBQztvQkFDSCxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZO3dCQUM3QixDQUFDLENBQUMsRUFBRTt3QkFDSixDQUFDLENBQUMsQ0FBQztnQkFDTCxZQUFZLEVBQUUsR0FBRyxFQUFFO29CQUNqQixJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxJQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLENBQUM7d0JBQ3pELE9BQU8sQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztvQkFDM0IsQ0FBQzt5QkFBTSxDQUFDO3dCQUNOLE9BQU8sQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztvQkFDN0IsQ0FBQztnQkFDSCxDQUFDO2dCQUNELE1BQU0sRUFBRSxJQUFJO2dCQUNaLE9BQU8sRUFBRSxLQUFLO2dCQUNkLFdBQVcsRUFBRSxDQUFDLENBQVksRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDaEMsV0FBVyxFQUFFLFFBQVE7Z0JBQ3JCLGNBQWMsRUFBRTtvQkFDZCxZQUFZLEVBQUUsSUFBSSxDQUFDLFNBQVM7b0JBQzVCLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztpQkFDMUI7YUFDRixDQUFDLENBQ0g7WUFDRCxJQUFJLGdCQUFnQixDQUNsQixJQUFJLENBQUMsZ0JBQWdCLENBQUM7Z0JBQ3BCLElBQUksRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQ3JCLEVBQUUsRUFBRSxVQUFVO2dCQUNkLFdBQVcsRUFBRSxRQUFRO2dCQUNyQixXQUFXLEVBQUUsQ0FBQyxDQUFZLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQ2hDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sSUFBSSxJQUFJO2dCQUNyQyxNQUFNLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLElBQUksSUFBSTtnQkFDbkMsU0FBUyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxJQUFJLENBQUM7Z0JBQ3RDLFlBQVksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksSUFBSSxDQUFDLEVBQUUsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBQztnQkFDOUQsWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFDO2dCQUMvRCxZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLElBQUksQ0FBQztnQkFDNUMsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLElBQUksQ0FBQzthQUNuRCxDQUFDLENBQ0g7U0FDRixDQUFDO1FBRUYsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQztDQUNGIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgU2NhdHRlcnBsb3RMYXllciB9IGZyb20gJ0BkZWNrLmdsL2xheWVycy90eXBlZCc7XG5pbXBvcnQge1xuICBJQ29tbW9uRGVja0xheWVyT3B0aW9ucyxcbiAgSURlY2tHZW9sb2NhdGVMYXllck9wdGlvbnMsXG59IGZyb20gJy4uL3R5cGluZ3MnO1xuXG5pbXBvcnQgeyBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSwgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURlY2tMYXllciB9IGZyb20gJy4uL2Jhc2UtZGVjay1sYXllci5jb21wb25lbnQnO1xuaW1wb3J0IHsgdGFrZVVudGlsRGVzdHJveWVkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZS9yeGpzLWludGVyb3AnO1xuaW1wb3J0IHsgdGFrZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgQ29tcG9zaXRlTGF5ZXIsIExheWVyLCBMYXllcnNMaXN0IH0gZnJvbSAnQGRlY2suZ2wvY29yZS90eXBlZCc7XG5pbXBvcnQgeyBPdWlJY29uQ29tcG9uZW50IH0gZnJvbSAnb3JiaXRhbC11aS9pY29uJztcbmltcG9ydCB7IE91aVJpcHBsZURpcmVjdGl2ZSB9IGZyb20gJ29yYml0YWwtdWkvcmlwcGxlJztcblxudHlwZSBJTG9jYXRpb24gPSBbbnVtYmVyLCBudW1iZXJdO1xudHlwZSBJQWNjdXJhY3kgPSB7XG4gIHBvc2l0aW9uOiBbbnVtYmVyLCBudW1iZXJdO1xuICByYWRpdXM6IG51bWJlcjtcbn07XG50eXBlIElQaW5nU3RhdGUgPSB7XG4gIGlzSW5Qcm9ncmVzczogYm9vbGVhbjtcbiAgaXNEb25lOiBib29sZWFuO1xufTtcblxudHlwZSBJR2VvbG9jYXRlTGF5ZXJPcHRpb25zID0ge1xuICBvcHRpb25zOiBJRGVja0dlb2xvY2F0ZUxheWVyT3B0aW9ucztcbiAgbG9jYXRpb246IElMb2NhdGlvbjtcbiAgYWNjdXJhY3k6IElBY2N1cmFjeTtcbiAgcGluZ1N0YXRlOiBJUGluZ1N0YXRlO1xuICBoZWFkaW5nOiBudW1iZXIgfCBudWxsO1xufTtcbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1kZWNrLWdlb2xvY2F0ZS1sYXllcicsXG4gIHRlbXBsYXRlOlxuICAgICc8ZGl2IGNsYXNzPVwiZ2VvbG9jYXRlXCIgb3VpUmlwcGxlIChjbGljayk9XCJsb2NhdGVVc2VyKClcIj48b3VpLWljb24gaWNvbj1cImFzc2V0cy9pY29ucy9sb2NhdGlvbi5zdmdcIiBbb3B0aW9uc109XCJ7ZmlsbENvbG9yOiBcXCdvdWktbWFwYm94LWdlb2xvY2F0ZS1jb2xvclxcJywgc3Ryb2tlQ29sb3I6IFxcJ291aS1tYXBib3gtZ2VvbG9jYXRlLWNvbG9yXFwnLCBzaXplOiBcXCcxOHB4XFwnfVwiPjwvb3VpLWljb24+PC9kaXY+JyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgc3R5bGVVcmxzOiBbJy4vZGVjay1nZW9sb2NhdGUtbGF5ZXIuc2NzcyddLFxuICBpbXBvcnRzOiBbT3VpSWNvbkNvbXBvbmVudCwgT3VpUmlwcGxlRGlyZWN0aXZlXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIERlY2tHZW9sb2NhdGVMYXllciBleHRlbmRzIEJhc2VEZWNrTGF5ZXI8SUNvbW1vbkRlY2tMYXllck9wdGlvbnM+IHtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSkgZGVjbGFyZSBvcHRpb25zOiBJRGVja0dlb2xvY2F0ZUxheWVyT3B0aW9ucztcbiAgcHJpdmF0ZSBpc0dlb2xvY2F0ZVN0YXJ0ZWQgPSBmYWxzZTtcbiAgcHJpdmF0ZSBsb2NhdGlvbjogSUxvY2F0aW9uID0gWzAsIDBdO1xuXG4gIHByaXZhdGUgYWNjdXJhY3k6IElBY2N1cmFjeSA9IHtcbiAgICBwb3NpdGlvbjogWzAsIDBdLFxuICAgIHJhZGl1czogMCxcbiAgfTtcblxuICBwcml2YXRlIGhlYWRpbmc6IG51bWJlciB8IG51bGwgPSBudWxsO1xuICBwcml2YXRlIHBpbmdTdGF0ZTogSVBpbmdTdGF0ZSA9IHtcbiAgICBpc0luUHJvZ3Jlc3M6IGZhbHNlLFxuICAgIGlzRG9uZTogZmFsc2UsXG4gIH07XG4gIHByaXZhdGUgaW50ZXJ2YWw6IGFueTtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBzdXBlcigpO1xuICB9XG5cbiAgcHJpdmF0ZSBvbkdlb2xvY2F0ZUV2ZW50KGRhdGE6IGFueSkge1xuICAgIHRoaXMubG9jYXRpb24gPSBbZGF0YS5jb29yZHMubG9uZ2l0dWRlLCBkYXRhLmNvb3Jkcy5sYXRpdHVkZV07XG4gICAgdGhpcy5hY2N1cmFjeS5wb3NpdGlvbiA9IFtkYXRhLmNvb3Jkcy5sb25naXR1ZGUsIGRhdGEuY29vcmRzLmxhdGl0dWRlXTtcbiAgICB0aGlzLmFjY3VyYWN5LnJhZGl1cyA9IGRhdGEuY29vcmRzLmFjY3VyYWN5O1xuICAgIHRoaXMuZGVjay5yZWZyZXNoTGF5ZXIodGhpcyk7XG4gIH1cblxuICBwdWJsaWMgbG9jYXRlVXNlcigpIHtcbiAgICB0aGlzLmRlY2subWFwLmZseVRvKHtcbiAgICAgIGxhdGl0dWRlOiB0aGlzLmxvY2F0aW9uWzFdLFxuICAgICAgbG9uZ2l0dWRlOiB0aGlzLmxvY2F0aW9uWzBdLFxuICAgICAgem9vbTogMTUsXG4gICAgICB0cmFuc2l0aW9uRHVyYXRpb246ICdhdXRvJyxcbiAgICB9KTtcbiAgfVxuXG4gIHB1YmxpYyBnZXRMYXllcigpIHtcbiAgICBpZiAoIXRoaXMuaXNHZW9sb2NhdGVTdGFydGVkKSB7XG4gICAgICB0aGlzLmlzR2VvbG9jYXRlU3RhcnRlZCA9IHRydWU7XG4gICAgICBpZiAoIXRoaXMuaW50ZXJ2YWwpIHtcbiAgICAgICAgdGhpcy5pbnRlcnZhbCA9IHNldEludGVydmFsKCgpID0+IHtcbiAgICAgICAgICB0aGlzLnBpbmdTdGF0ZSA9IHtcbiAgICAgICAgICAgIGlzSW5Qcm9ncmVzczogdHJ1ZSxcbiAgICAgICAgICAgIGlzRG9uZTogZmFsc2UsXG4gICAgICAgICAgfTtcbiAgICAgICAgICB0aGlzLmRlY2sucmVmcmVzaExheWVyKHRoaXMpO1xuICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5waW5nU3RhdGUgPSB7XG4gICAgICAgICAgICAgIGlzSW5Qcm9ncmVzczogZmFsc2UsXG4gICAgICAgICAgICAgIGlzRG9uZTogdHJ1ZSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB0aGlzLmRlY2sucmVmcmVzaExheWVyKHRoaXMpO1xuXG4gICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgICAgdGhpcy5waW5nU3RhdGUgPSB7XG4gICAgICAgICAgICAgICAgaXNJblByb2dyZXNzOiBmYWxzZSxcbiAgICAgICAgICAgICAgICBpc0RvbmU6IGZhbHNlLFxuICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICB0aGlzLmRlY2sucmVmcmVzaExheWVyKHRoaXMpO1xuICAgICAgICAgICAgfSwgMTAwMCk7XG4gICAgICAgICAgfSwgMTAwMCk7XG4gICAgICAgIH0sIDMwMDApO1xuICAgICAgfVxuICAgICAgdGhpcy5kZWNrLm9uTG9hZCRcbiAgICAgICAgLnBpcGUodGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZiksIHRha2UoMSkpXG4gICAgICAgIC5zdWJzY3JpYmUoKCkgPT4ge1xuICAgICAgICAgIGlmIChuYXZpZ2F0b3IuZ2VvbG9jYXRpb24pIHtcbiAgICAgICAgICAgIG5hdmlnYXRvci5nZW9sb2NhdGlvbi53YXRjaFBvc2l0aW9uKFxuICAgICAgICAgICAgICB0aGlzLm9uR2VvbG9jYXRlRXZlbnQuYmluZCh0aGlzKVxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IEdlb2xvY2F0ZUxheWVyKHtcbiAgICAgIG9wdGlvbnM6IHRoaXMub3B0aW9ucyxcbiAgICAgIGxvY2F0aW9uOiB0aGlzLmxvY2F0aW9uLFxuICAgICAgYWNjdXJhY3k6IHRoaXMuYWNjdXJhY3ksXG4gICAgICBoZWFkaW5nOiB0aGlzLmhlYWRpbmcsXG4gICAgICBwaW5nU3RhdGU6IHRoaXMucGluZ1N0YXRlLFxuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIG92ZXJyaWRlIG5nT25EZXN0cm95KCkge1xuICAgIGlmICh0aGlzLmludGVydmFsKSB7XG4gICAgICBjbGVhckludGVydmFsKHRoaXMuaW50ZXJ2YWwpO1xuICAgIH1cbiAgICBzdXBlci5uZ09uRGVzdHJveSgpO1xuICB9XG59XG4vLyBUT0RPOiBJbXBsZW1lbnQgaGVhZGluZ1xuY2xhc3MgR2VvbG9jYXRlTGF5ZXIgZXh0ZW5kcyBDb21wb3NpdGVMYXllcjxhbnk+IHtcbiAgcHJpdmF0ZSBvcHRpb25zOiBJRGVja0dlb2xvY2F0ZUxheWVyT3B0aW9ucztcbiAgcHJpdmF0ZSBsb2NhdGlvbjogSUxvY2F0aW9uID0gWzAsIDBdO1xuICBwcml2YXRlIGFjY3VyYWN5OiBJQWNjdXJhY3kgPSB7XG4gICAgcG9zaXRpb246IFswLCAwXSxcbiAgICByYWRpdXM6IDAsXG4gIH07XG4gIHByaXZhdGUgaGVhZGluZzogbnVtYmVyIHwgbnVsbCA9IDA7XG4gIHByaXZhdGUgcGluZ1N0YXRlOiBJUGluZ1N0YXRlID0ge1xuICAgIGlzSW5Qcm9ncmVzczogZmFsc2UsXG4gICAgaXNEb25lOiBmYWxzZSxcbiAgfTtcbiAgY29uc3RydWN0b3IocHJvcHM6IElHZW9sb2NhdGVMYXllck9wdGlvbnMpIHtcbiAgICBzdXBlcihwcm9wcyk7XG4gICAgdGhpcy5vcHRpb25zID0gcHJvcHMub3B0aW9ucztcbiAgICB0aGlzLmFjY3VyYWN5ID0gcHJvcHMuYWNjdXJhY3k7XG4gICAgdGhpcy5sb2NhdGlvbiA9IHByb3BzLmxvY2F0aW9uO1xuICAgIHRoaXMuaGVhZGluZyA9IHByb3BzLmhlYWRpbmc7XG4gICAgdGhpcy5waW5nU3RhdGUgPSBwcm9wcy5waW5nU3RhdGU7XG4gIH1cblxuICBvdmVycmlkZSBzaG91bGRVcGRhdGVTdGF0ZSh7IGNoYW5nZUZsYWdzIH06IGFueSkge1xuICAgIHJldHVybiBjaGFuZ2VGbGFncy5wcm9wc0NoYW5nZWQgfHwgY2hhbmdlRmxhZ3MuZGF0YUNoYW5nZWQ7XG4gIH1cblxuICAvLyBvdmVycmlkZSB1cGRhdGVTdGF0ZSh7IHByb3BzLCBvbGRQcm9wcywgY2hhbmdlRmxhZ3MgfTogYW55KSB7XG4gIC8vICAgcmV0dXJuIHRydWU7XG4gIC8vIH1cblxuICBvdmVycmlkZSByZW5kZXJMYXllcnMoKTogTGF5ZXIgfCBMYXllcnNMaXN0IHwgbnVsbCB7XG4gICAgY29uc3QgbGF5ZXJzOiBhbnlbXSA9IFtcbiAgICAgIG5ldyBTY2F0dGVycGxvdExheWVyKFxuICAgICAgICB0aGlzLmdldFN1YkxheWVyUHJvcHMoe1xuICAgICAgICAgIGRhdGE6IFt0aGlzLmFjY3VyYWN5XSxcbiAgICAgICAgICBpZDogJ2FjY3VyYWN5JyxcbiAgICAgICAgICByYWRpdXNVbml0czogJ21ldGVycycsXG4gICAgICAgICAgZ2V0UG9zaXRpb246IChkOiBJQWNjdXJhY3kpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBkLnBvc2l0aW9uO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgc3Ryb2tlZDogZmFsc2UsXG4gICAgICAgICAgZmlsbGVkOiB0cnVlLFxuICAgICAgICAgIGdldEZpbGxDb2xvcjogdGhpcy5vcHRpb25zLmdldEZpbGxDb2xvciA/PyBbMjksIDE2MSwgMjQyLCAxMjVdLFxuICAgICAgICAgIGdldFJhZGl1czogKGQ6IElBY2N1cmFjeSkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIGQucmFkaXVzO1xuICAgICAgICAgIH0sXG4gICAgICAgIH0pXG4gICAgICApLFxuICAgICAgbmV3IFNjYXR0ZXJwbG90TGF5ZXIoXG4gICAgICAgIHRoaXMuZ2V0U3ViTGF5ZXJQcm9wcyh7XG4gICAgICAgICAgZGF0YTogW3RoaXMubG9jYXRpb25dLFxuICAgICAgICAgIHRyYW5zaXRpb25zOiB7XG4gICAgICAgICAgICBnZXRGaWxsQ29sb3I6IDEwMDAsXG4gICAgICAgICAgICBnZXRSYWRpdXM6IDEwMDAsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBpZDogJ3BpbmcnLFxuICAgICAgICAgIGdldFJhZGl1czogdGhpcy5waW5nU3RhdGUuaXNEb25lXG4gICAgICAgICAgICA/IDBcbiAgICAgICAgICAgIDogdGhpcy5waW5nU3RhdGUuaXNJblByb2dyZXNzXG4gICAgICAgICAgICA/IDMwXG4gICAgICAgICAgICA6IDAsXG4gICAgICAgICAgZ2V0RmlsbENvbG9yOiAoKSA9PiB7XG4gICAgICAgICAgICBpZiAodGhpcy5waW5nU3RhdGUuaXNEb25lIHx8IHRoaXMucGluZ1N0YXRlLmlzSW5Qcm9ncmVzcykge1xuICAgICAgICAgICAgICByZXR1cm4gWzI5LCAxNjEsIDI0MiwgMF07XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICByZXR1cm4gWzI2LCAxMjIsIDIwMCwgMjU1XTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIGZpbGxlZDogdHJ1ZSxcbiAgICAgICAgICBzdHJva2VkOiBmYWxzZSxcbiAgICAgICAgICBnZXRQb3NpdGlvbjogKGQ6IElMb2NhdGlvbikgPT4gZCxcbiAgICAgICAgICByYWRpdXNVbml0czogJ3BpeGVscycsXG4gICAgICAgICAgdXBkYXRlVHJpZ2dlcnM6IHtcbiAgICAgICAgICAgIGdldEZpbGxDb2xvcjogdGhpcy5waW5nU3RhdGUsXG4gICAgICAgICAgICBnZXRSYWRpdXM6IHRoaXMucGluZ1N0YXRlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pXG4gICAgICApLFxuICAgICAgbmV3IFNjYXR0ZXJwbG90TGF5ZXIoXG4gICAgICAgIHRoaXMuZ2V0U3ViTGF5ZXJQcm9wcyh7XG4gICAgICAgICAgZGF0YTogW3RoaXMubG9jYXRpb25dLFxuICAgICAgICAgIGlkOiAnbG9jYXRpb24nLFxuICAgICAgICAgIHJhZGl1c1VuaXRzOiAncGl4ZWxzJyxcbiAgICAgICAgICBnZXRQb3NpdGlvbjogKGQ6IElMb2NhdGlvbikgPT4gZCxcbiAgICAgICAgICBzdHJva2VkOiB0aGlzLm9wdGlvbnMuc3Ryb2tlZCA/PyB0cnVlLFxuICAgICAgICAgIGZpbGxlZDogdGhpcy5vcHRpb25zLmZpbGxlZCA/PyB0cnVlLFxuICAgICAgICAgIGdldFJhZGl1czogdGhpcy5vcHRpb25zLmdldFJhZGl1cyA/PyA3LFxuICAgICAgICAgIGdldEZpbGxDb2xvcjogdGhpcy5vcHRpb25zLmdldEZpbGxDb2xvciA/PyBbMjksIDE2MSwgMjQyLCAyNTVdLFxuICAgICAgICAgIGdldExpbmVDb2xvcjogdGhpcy5vcHRpb25zLmdldExpbmVDb2xvciA/PyBbMjU1LCAyNTUsIDI1NSwgMjU1XSxcbiAgICAgICAgICBnZXRMaW5lV2lkdGg6IHRoaXMub3B0aW9ucy5nZXRMaW5lV2lkdGggPz8gMixcbiAgICAgICAgICBsaW5lV2lkdGhNaW5QaXhlbHM6IHRoaXMub3B0aW9ucy5nZXRMaW5lV2lkdGggPz8gMixcbiAgICAgICAgfSlcbiAgICAgICksXG4gICAgXTtcblxuICAgIHJldHVybiBsYXllcnM7XG4gIH1cbn1cbiJdfQ==