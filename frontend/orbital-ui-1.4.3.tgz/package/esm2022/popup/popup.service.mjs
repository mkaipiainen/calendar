import { Inject, Injectable, } from '@angular/core';
import { NavigationStart } from '@angular/router';
import { createPopper, } from '@popperjs/core';
import { isNil } from 'lodash-es';
import { fromEvent, Subject } from 'rxjs';
import { DOCUMENT } from '@angular/common';
import { GUID } from 'orbital-ui/helpers';
import { ComponentCreator } from 'orbital-ui/helpers';
import * as i0 from "@angular/core";
import * as i1 from "@angular/router";
// Create JDOC to describe this service
/**
 * Service to open popups. Uses popper.js under the hood.
 * You can create popups by passing any custom component together with options to the openPopup() method.
 *
 * The options object can contain the following properties:
 *
 * modifiers: Array of modifiers to be passed to popper.js. Optional and generally only necessary for edge-cases. See https://popper.js.org/docs/v2/modifiers/ for more info.
 * placement: Placement of the popup. Optional and defaults to 'bottom'. See https://popper.js.org/docs/v2/constructors/#placement for more info.
 * strategy: Positioning strategy. Optional and defaults to 'absolute'. Rarely needed. See https://popper.js.org/docs/v2/constructors/#strategy for more info.
 * onFirstUpdate: Callback to be called when the popup is first positioned. Optional. See https://popper.js.org/docs/v2/constructors/#onfirstupdate for more info.
 * id: Id of the popup. Optional. If not provided, a random id will be generated.
 * closeOnEscape: Whether the popup should be closed when the escape key is pressed.
 *
 * The last parameter takes an origin, which the popup will be positioned on. This can be either a DOM element or a virtual element.
 * A virtual element is an object with a getBoundingClientRect() method that returns a DOMRect object.
 * See https://popper.js.org/docs/v2/virtual-elements/ for more info.
 * If no origin is provided, the popup will be positioned on the document body.
 *
 * An arrow can be created automatically by passing in the arrow modifier. See https://popper.js.org/docs/v2/modifiers/arrow/ for more info.
 *
 * Some default modifiers are applied to each popup:
 * - PreventOverflow: prevents the popup from overflowing outside of the window. See https://popper.js.org/docs/v2/modifiers/prevent-overflow/ for more info.
 *
 *
 * An example usecase for a simple popup with an arrow, popup placed to the top left and closeOnEscape enabled.
 * The example popup uses a component called MyPopupComponent which has an input called myInput with a value 'myValue'.
 *
 * const popupOptions: IPopupOptions = {
 *    modifiers: [{
 *      name: 'arrow',
 *        options: {
 *          color: 'var(--color-background)',
 *        }
 *      }
 *    ],
 *    placement: 'top-start',
 *    closeOnEscape: true,
 *  }
 *
 *  this.popupService.openPopup(MyPopupComponent, {myInput: 'myValue'}, popupOptions);
 *
 */
export class OuiPopupService {
    router;
    zone;
    appRef;
    injector;
    rendererFactory;
    document;
    openPopups = {};
    popupOpenSubject = new Subject();
    popupClosedSubject = new Subject();
    popupOpen$ = this.popupOpenSubject.asObservable();
    popupClosed$ = this.popupClosedSubject.asObservable();
    renderer;
    constructor(router, zone, appRef, injector, rendererFactory, document) {
        this.router = router;
        this.zone = zone;
        this.appRef = appRef;
        this.injector = injector;
        this.rendererFactory = rendererFactory;
        this.document = document;
        this.renderer = rendererFactory.createRenderer(null, null);
        this.router.events.subscribe(val => {
            if (val instanceof NavigationStart) {
                this.destroyPopups();
            }
        });
        fromEvent(document, 'keyup').subscribe((event) => {
            if (event.key === 'Escape') {
                this.onEscapePress();
            }
        });
        fromEvent(document.body, 'click').subscribe((event) => {
            this.onDocumentClick(event);
        });
    }
    onEscapePress() {
        for (const id in this.openPopups) {
            if (this.openPopups[id].options.closeOnEscape) {
                this.dispose(id);
            }
        }
    }
    onDocumentClick(event) {
        for (const id in this.openPopups) {
            if (this.openPopups[id].options.closeOnOutsideClick &&
                this.openPopups[id].isInitialised &&
                !this.openPopups[id].popupElement.contains(event.target)) {
                this.dispose(id);
            }
        }
    }
    destroyPopups() {
        for (const id in this.openPopups) {
            this.doDispose(id);
        }
    }
    openPopup(content, inputs, options = {}, origin) {
        const id = options.id ?? GUID();
        const popup = this.renderer.createElement('div');
        popup.id = id;
        this.renderer.addClass(popup, 'oui-popup');
        const createComponentOptions = {
            component: content,
            parentElement: popup,
            appRef: this.appRef,
            createComponentOptions: {
                environmentInjector: this.injector,
            },
            inputs: inputs,
        };
        const componentRef = ComponentCreator.createComponent(createComponentOptions);
        this.renderer.appendChild(this.document.body, popup);
        const arrowModifierIndex = options?.modifiers?.findIndex(modifier => modifier.name === 'arrow');
        if (!isNil(arrowModifierIndex) && arrowModifierIndex > -1) {
            const arrow = this.renderer.createElement('div');
            arrow.id = 'arrow';
            this.renderer.appendChild(popup, arrow);
            if (options.modifiers) {
                options.modifiers[arrowModifierIndex].options.element = arrow;
                this.renderer.setStyle(arrow, 'backgroundColor', options.modifiers[arrowModifierIndex].options.color);
                this.renderer.setStyle(arrow, 'color', options.modifiers[arrowModifierIndex].options.color);
                this.renderer.setAttribute(arrow, 'data-popper-arrow', '');
            }
        }
        const defaultModifiers = [
            {
                name: 'preventOverflow',
                options: {
                    altAxis: true,
                    padding: 5,
                },
            },
        ];
        const combinedModifiers = [
            ...defaultModifiers,
            ...(options.modifiers || []),
        ];
        options.modifiers = combinedModifiers;
        this.zone.runOutsideAngular(() => {
            const popperRef = createPopper(origin ?? this.document.body, popup, options);
            this.openPopups[id] = {
                popperRef,
                componentRef,
                popupElement: popup,
                id: id,
                options: options,
                isInitialised: false,
            };
            componentRef.instance.popup = this.openPopups[id];
        });
        this.popupOpenSubject.next(this.openPopups[id]);
        setTimeout(() => {
            if (this.openPopups[id]) {
                this.openPopups[id].isInitialised = true;
            }
        }, 300);
        setTimeout(() => {
            this.renderer.setStyle(popup, 'opacity', '1');
        }, 0);
        return this.openPopups[id];
    }
    dispose(id) {
        if (this.openPopups?.[id]) {
            this.doDispose(id);
        }
    }
    // TODO: Might cause memory-leaks, ensure it doesn't
    doDispose(id) {
        this.renderer.setStyle(this.openPopups[id].popupElement, 'opacity', '0');
        const popperRef = this.openPopups[id].popperRef;
        const componentRef = this.openPopups[id].componentRef;
        const popupElement = this.openPopups[id].popupElement;
        this.popupClosedSubject.next(this.openPopups[id]);
        delete this.openPopups[id];
        setTimeout(() => {
            popperRef.destroy();
            componentRef.destroy();
            this.renderer.removeChild(this.document.body, popupElement);
            this.appRef.detachView(componentRef.hostView);
        }, 300);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiPopupService, deps: [{ token: i1.Router }, { token: i0.NgZone }, { token: i0.ApplicationRef }, { token: i0.EnvironmentInjector }, { token: i0.RendererFactory2 }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiPopupService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiPopupService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.Router }, { type: i0.NgZone }, { type: i0.ApplicationRef }, { type: i0.EnvironmentInjector }, { type: i0.RendererFactory2 }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9wdXAuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvcG9wdXAvcG9wdXAuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBR0wsTUFBTSxFQUNOLFVBQVUsR0FJWCxNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsZUFBZSxFQUFVLE1BQU0saUJBQWlCLENBQUM7QUFDMUQsT0FBTyxFQUNMLFlBQVksR0FJYixNQUFNLGdCQUFnQixDQUFDO0FBRXhCLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFDbEMsT0FBTyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFFMUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBRTNDLE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUMxQyxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQzs7O0FBcUJ0RCx1Q0FBdUM7QUFDdkM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBeUNHO0FBSUgsTUFBTSxPQUFPLGVBQWU7SUFhaEI7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNrQjtJQWpCcEIsVUFBVSxHQUVkLEVBQUUsQ0FBQztJQUVDLGdCQUFnQixHQUFHLElBQUksT0FBTyxFQUFVLENBQUM7SUFDekMsa0JBQWtCLEdBQUcsSUFBSSxPQUFPLEVBQVUsQ0FBQztJQUU1QyxVQUFVLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ2xELFlBQVksR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxFQUFFLENBQUM7SUFFckQsUUFBUSxDQUFZO0lBQzVCLFlBQ1UsTUFBYyxFQUNkLElBQVksRUFDWixNQUFzQixFQUN0QixRQUE2QixFQUM3QixlQUFpQyxFQUNmLFFBQWtCO1FBTHBDLFdBQU0sR0FBTixNQUFNLENBQVE7UUFDZCxTQUFJLEdBQUosSUFBSSxDQUFRO1FBQ1osV0FBTSxHQUFOLE1BQU0sQ0FBZ0I7UUFDdEIsYUFBUSxHQUFSLFFBQVEsQ0FBcUI7UUFDN0Isb0JBQWUsR0FBZixlQUFlLENBQWtCO1FBQ2YsYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUU1QyxJQUFJLENBQUMsUUFBUSxHQUFHLGVBQWUsQ0FBQyxjQUFjLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBRTNELElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRTtZQUNqQyxJQUFJLEdBQUcsWUFBWSxlQUFlLEVBQUUsQ0FBQztnQkFDbkMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3ZCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILFNBQVMsQ0FBQyxRQUFRLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBVSxFQUFFLEVBQUU7WUFDcEQsSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLFFBQVEsRUFBRSxDQUFDO2dCQUMzQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDdkIsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO1FBRUgsU0FBUyxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsS0FBVSxFQUFFLEVBQUU7WUFDekQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUM5QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxhQUFhO1FBQ2xCLEtBQUssTUFBTSxFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2pDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQzlDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDbkIsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRU8sZUFBZSxDQUFDLEtBQVU7UUFDaEMsS0FBSyxNQUFNLEVBQUUsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDakMsSUFDRSxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxtQkFBbUI7Z0JBQy9DLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUMsYUFBYTtnQkFDakMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUN4RCxDQUFDO2dCQUNELElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDbkIsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRU0sYUFBYTtRQUNsQixLQUFLLE1BQU0sRUFBRSxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNqQyxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3JCLENBQUM7SUFDSCxDQUFDO0lBRU0sU0FBUyxDQUNkLE9BQXlCLEVBQ3pCLE1BQWdDLEVBQ2hDLFVBQXlCLEVBQUUsRUFDM0IsTUFBcUM7UUFFckMsTUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFDLEVBQUUsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUNoQyxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNqRCxLQUFLLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQztRQUNkLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxXQUFXLENBQUMsQ0FBQztRQUMzQyxNQUFNLHNCQUFzQixHQUFHO1lBQzdCLFNBQVMsRUFBRSxPQUFPO1lBQ2xCLGFBQWEsRUFBRSxLQUFLO1lBQ3BCLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtZQUNuQixzQkFBc0IsRUFBRTtnQkFDdEIsbUJBQW1CLEVBQUUsSUFBSSxDQUFDLFFBQVE7YUFDbkM7WUFDRCxNQUFNLEVBQUUsTUFBTTtTQUNmLENBQUM7UUFDRixNQUFNLFlBQVksR0FBRyxnQkFBZ0IsQ0FBQyxlQUFlLENBQ25ELHNCQUFzQixDQUN2QixDQUFDO1FBQ0YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDckQsTUFBTSxrQkFBa0IsR0FBRyxPQUFPLEVBQUUsU0FBUyxFQUFFLFNBQVMsQ0FDdEQsUUFBUSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxLQUFLLE9BQU8sQ0FDdEMsQ0FBQztRQUNGLElBQUksQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUMsSUFBSSxrQkFBa0IsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQzFELE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ2pELEtBQUssQ0FBQyxFQUFFLEdBQUcsT0FBTyxDQUFDO1lBQ25CLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN4QyxJQUFJLE9BQU8sQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDdEIsT0FBTyxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO2dCQUM5RCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FDcEIsS0FBSyxFQUNMLGlCQUFpQixFQUNqQixPQUFPLENBQUMsU0FBUyxDQUFDLGtCQUFrQixDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FDcEQsQ0FBQztnQkFDRixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FDcEIsS0FBSyxFQUNMLE9BQU8sRUFDUCxPQUFPLENBQUMsU0FBUyxDQUFDLGtCQUFrQixDQUFDLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FDcEQsQ0FBQztnQkFDRixJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxLQUFLLEVBQUUsbUJBQW1CLEVBQUUsRUFBRSxDQUFDLENBQUM7WUFDN0QsQ0FBQztRQUNILENBQUM7UUFFRCxNQUFNLGdCQUFnQixHQUFHO1lBQ3ZCO2dCQUNFLElBQUksRUFBRSxpQkFBaUI7Z0JBQ3ZCLE9BQU8sRUFBRTtvQkFDUCxPQUFPLEVBQUUsSUFBSTtvQkFDYixPQUFPLEVBQUUsQ0FBQztpQkFDWDthQUNGO1NBQ0YsQ0FBQztRQUNGLE1BQU0saUJBQWlCLEdBQUc7WUFDeEIsR0FBRyxnQkFBZ0I7WUFDbkIsR0FBRyxDQUFDLE9BQU8sQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDO1NBQzdCLENBQUM7UUFDRixPQUFPLENBQUMsU0FBUyxHQUFHLGlCQUFpQixDQUFDO1FBQ3RDLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxFQUFFO1lBQy9CLE1BQU0sU0FBUyxHQUFHLFlBQVksQ0FDNUIsTUFBTSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUM1QixLQUFLLEVBQ0wsT0FBTyxDQUNSLENBQUM7WUFDRixJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxHQUFHO2dCQUNwQixTQUFTO2dCQUNULFlBQVk7Z0JBQ1osWUFBWSxFQUFFLEtBQUs7Z0JBQ25CLEVBQUUsRUFBRSxFQUFFO2dCQUNOLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixhQUFhLEVBQUUsS0FBSzthQUNyQixDQUFDO1lBQ0YsWUFBWSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNwRCxDQUFDLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQ2hELFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDZCxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQztnQkFDeEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1lBQzNDLENBQUM7UUFDSCxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDUixVQUFVLENBQUMsR0FBRyxFQUFFO1lBQ2QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNoRCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDTixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDN0IsQ0FBQztJQUVNLE9BQU8sQ0FBQyxFQUFVO1FBQ3ZCLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7WUFDMUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNyQixDQUFDO0lBQ0gsQ0FBQztJQUVELG9EQUFvRDtJQUM1QyxTQUFTLENBQUMsRUFBVTtRQUMxQixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLFlBQVksRUFBRSxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDekUsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxTQUFTLENBQUM7UUFDaEQsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUM7UUFDdEQsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUM7UUFDdEQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDbEQsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQzNCLFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDZCxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDcEIsWUFBWSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFDO1lBQzVELElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUNoRCxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDVixDQUFDO3VHQTdLVSxlQUFlLCtKQWtCaEIsUUFBUTsyR0FsQlAsZUFBZSxjQUZkLE1BQU07OzJGQUVQLGVBQWU7a0JBSDNCLFVBQVU7bUJBQUM7b0JBQ1YsVUFBVSxFQUFFLE1BQU07aUJBQ25COzswQkFtQkksTUFBTTsyQkFBQyxRQUFRIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXBwbGljYXRpb25SZWYsXG4gIEVudmlyb25tZW50SW5qZWN0b3IsXG4gIEluamVjdCxcbiAgSW5qZWN0YWJsZSxcbiAgTmdab25lLFxuICBSZW5kZXJlcjIsXG4gIFJlbmRlcmVyRmFjdG9yeTIsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTmF2aWdhdGlvblN0YXJ0LCBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHtcbiAgY3JlYXRlUG9wcGVyLFxuICBQb3NpdGlvbmluZ1N0cmF0ZWd5LFxuICBTdGF0ZSxcbiAgVmlydHVhbEVsZW1lbnQsXG59IGZyb20gJ0Bwb3BwZXJqcy9jb3JlJztcbmltcG9ydCB7IFBsYWNlbWVudCB9IGZyb20gJ0Bwb3BwZXJqcy9jb3JlJztcbmltcG9ydCB7IGlzTmlsIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IGZyb21FdmVudCwgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgQ29tcG9uZW50VHlwZSB9IGZyb20gJ0Bhbmd1bGFyL2Nkay9vdmVybGF5JztcbmltcG9ydCB7IERPQ1VNRU5UIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IE91aVBvcHVwQ29tcG9uZW50IH0gZnJvbSAnLi9wb3B1cC5jb21wb25lbnQnO1xuaW1wb3J0IHsgR1VJRCB9IGZyb20gJ29yYml0YWwtdWkvaGVscGVycyc7XG5pbXBvcnQgeyBDb21wb25lbnRDcmVhdG9yIH0gZnJvbSAnb3JiaXRhbC11aS9oZWxwZXJzJztcblxuZXhwb3J0IGludGVyZmFjZSBJUG9wdXBPcHRpb25zIHtcbiAgbW9kaWZpZXJzPzogeyBuYW1lOiBzdHJpbmc7IG9wdGlvbnM6IGFueSB9W107XG4gIHBsYWNlbWVudD86IFBsYWNlbWVudDtcbiAgc3RyYXRlZ3k/OiBQb3NpdGlvbmluZ1N0cmF0ZWd5O1xuICBvbkZpcnN0VXBkYXRlPzogKGFyZzA6IFBhcnRpYWw8U3RhdGU+KSA9PiB2b2lkO1xuICBpZD86IHN0cmluZztcbiAgY2xvc2VPbkVzY2FwZT86IGJvb2xlYW47XG4gIGNsb3NlT25PdXRzaWRlQ2xpY2s/OiBib29sZWFuO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElQb3B1cCB7XG4gIHBvcHBlclJlZjogYW55O1xuICBwb3B1cEVsZW1lbnQ6IEhUTUxFbGVtZW50O1xuICBjb21wb25lbnRSZWY6IGFueTtcbiAgaWQ6IHN0cmluZztcbiAgb3B0aW9uczogSVBvcHVwT3B0aW9ucztcbiAgaXNJbml0aWFsaXNlZDogYm9vbGVhbjtcbn1cblxuLy8gQ3JlYXRlIEpET0MgdG8gZGVzY3JpYmUgdGhpcyBzZXJ2aWNlXG4vKipcbiAqIFNlcnZpY2UgdG8gb3BlbiBwb3B1cHMuIFVzZXMgcG9wcGVyLmpzIHVuZGVyIHRoZSBob29kLlxuICogWW91IGNhbiBjcmVhdGUgcG9wdXBzIGJ5IHBhc3NpbmcgYW55IGN1c3RvbSBjb21wb25lbnQgdG9nZXRoZXIgd2l0aCBvcHRpb25zIHRvIHRoZSBvcGVuUG9wdXAoKSBtZXRob2QuXG4gKlxuICogVGhlIG9wdGlvbnMgb2JqZWN0IGNhbiBjb250YWluIHRoZSBmb2xsb3dpbmcgcHJvcGVydGllczpcbiAqXG4gKiBtb2RpZmllcnM6IEFycmF5IG9mIG1vZGlmaWVycyB0byBiZSBwYXNzZWQgdG8gcG9wcGVyLmpzLiBPcHRpb25hbCBhbmQgZ2VuZXJhbGx5IG9ubHkgbmVjZXNzYXJ5IGZvciBlZGdlLWNhc2VzLiBTZWUgaHR0cHM6Ly9wb3BwZXIuanMub3JnL2RvY3MvdjIvbW9kaWZpZXJzLyBmb3IgbW9yZSBpbmZvLlxuICogcGxhY2VtZW50OiBQbGFjZW1lbnQgb2YgdGhlIHBvcHVwLiBPcHRpb25hbCBhbmQgZGVmYXVsdHMgdG8gJ2JvdHRvbScuIFNlZSBodHRwczovL3BvcHBlci5qcy5vcmcvZG9jcy92Mi9jb25zdHJ1Y3RvcnMvI3BsYWNlbWVudCBmb3IgbW9yZSBpbmZvLlxuICogc3RyYXRlZ3k6IFBvc2l0aW9uaW5nIHN0cmF0ZWd5LiBPcHRpb25hbCBhbmQgZGVmYXVsdHMgdG8gJ2Fic29sdXRlJy4gUmFyZWx5IG5lZWRlZC4gU2VlIGh0dHBzOi8vcG9wcGVyLmpzLm9yZy9kb2NzL3YyL2NvbnN0cnVjdG9ycy8jc3RyYXRlZ3kgZm9yIG1vcmUgaW5mby5cbiAqIG9uRmlyc3RVcGRhdGU6IENhbGxiYWNrIHRvIGJlIGNhbGxlZCB3aGVuIHRoZSBwb3B1cCBpcyBmaXJzdCBwb3NpdGlvbmVkLiBPcHRpb25hbC4gU2VlIGh0dHBzOi8vcG9wcGVyLmpzLm9yZy9kb2NzL3YyL2NvbnN0cnVjdG9ycy8jb25maXJzdHVwZGF0ZSBmb3IgbW9yZSBpbmZvLlxuICogaWQ6IElkIG9mIHRoZSBwb3B1cC4gT3B0aW9uYWwuIElmIG5vdCBwcm92aWRlZCwgYSByYW5kb20gaWQgd2lsbCBiZSBnZW5lcmF0ZWQuXG4gKiBjbG9zZU9uRXNjYXBlOiBXaGV0aGVyIHRoZSBwb3B1cCBzaG91bGQgYmUgY2xvc2VkIHdoZW4gdGhlIGVzY2FwZSBrZXkgaXMgcHJlc3NlZC5cbiAqXG4gKiBUaGUgbGFzdCBwYXJhbWV0ZXIgdGFrZXMgYW4gb3JpZ2luLCB3aGljaCB0aGUgcG9wdXAgd2lsbCBiZSBwb3NpdGlvbmVkIG9uLiBUaGlzIGNhbiBiZSBlaXRoZXIgYSBET00gZWxlbWVudCBvciBhIHZpcnR1YWwgZWxlbWVudC5cbiAqIEEgdmlydHVhbCBlbGVtZW50IGlzIGFuIG9iamVjdCB3aXRoIGEgZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkgbWV0aG9kIHRoYXQgcmV0dXJucyBhIERPTVJlY3Qgb2JqZWN0LlxuICogU2VlIGh0dHBzOi8vcG9wcGVyLmpzLm9yZy9kb2NzL3YyL3ZpcnR1YWwtZWxlbWVudHMvIGZvciBtb3JlIGluZm8uXG4gKiBJZiBubyBvcmlnaW4gaXMgcHJvdmlkZWQsIHRoZSBwb3B1cCB3aWxsIGJlIHBvc2l0aW9uZWQgb24gdGhlIGRvY3VtZW50IGJvZHkuXG4gKlxuICogQW4gYXJyb3cgY2FuIGJlIGNyZWF0ZWQgYXV0b21hdGljYWxseSBieSBwYXNzaW5nIGluIHRoZSBhcnJvdyBtb2RpZmllci4gU2VlIGh0dHBzOi8vcG9wcGVyLmpzLm9yZy9kb2NzL3YyL21vZGlmaWVycy9hcnJvdy8gZm9yIG1vcmUgaW5mby5cbiAqXG4gKiBTb21lIGRlZmF1bHQgbW9kaWZpZXJzIGFyZSBhcHBsaWVkIHRvIGVhY2ggcG9wdXA6XG4gKiAtIFByZXZlbnRPdmVyZmxvdzogcHJldmVudHMgdGhlIHBvcHVwIGZyb20gb3ZlcmZsb3dpbmcgb3V0c2lkZSBvZiB0aGUgd2luZG93LiBTZWUgaHR0cHM6Ly9wb3BwZXIuanMub3JnL2RvY3MvdjIvbW9kaWZpZXJzL3ByZXZlbnQtb3ZlcmZsb3cvIGZvciBtb3JlIGluZm8uXG4gKlxuICpcbiAqIEFuIGV4YW1wbGUgdXNlY2FzZSBmb3IgYSBzaW1wbGUgcG9wdXAgd2l0aCBhbiBhcnJvdywgcG9wdXAgcGxhY2VkIHRvIHRoZSB0b3AgbGVmdCBhbmQgY2xvc2VPbkVzY2FwZSBlbmFibGVkLlxuICogVGhlIGV4YW1wbGUgcG9wdXAgdXNlcyBhIGNvbXBvbmVudCBjYWxsZWQgTXlQb3B1cENvbXBvbmVudCB3aGljaCBoYXMgYW4gaW5wdXQgY2FsbGVkIG15SW5wdXQgd2l0aCBhIHZhbHVlICdteVZhbHVlJy5cbiAqXG4gKiBjb25zdCBwb3B1cE9wdGlvbnM6IElQb3B1cE9wdGlvbnMgPSB7XG4gKiAgICBtb2RpZmllcnM6IFt7XG4gKiAgICAgIG5hbWU6ICdhcnJvdycsXG4gKiAgICAgICAgb3B0aW9uczoge1xuICogICAgICAgICAgY29sb3I6ICd2YXIoLS1jb2xvci1iYWNrZ3JvdW5kKScsXG4gKiAgICAgICAgfVxuICogICAgICB9XG4gKiAgICBdLFxuICogICAgcGxhY2VtZW50OiAndG9wLXN0YXJ0JyxcbiAqICAgIGNsb3NlT25Fc2NhcGU6IHRydWUsXG4gKiAgfVxuICpcbiAqICB0aGlzLnBvcHVwU2VydmljZS5vcGVuUG9wdXAoTXlQb3B1cENvbXBvbmVudCwge215SW5wdXQ6ICdteVZhbHVlJ30sIHBvcHVwT3B0aW9ucyk7XG4gKlxuICovXG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290Jyxcbn0pXG5leHBvcnQgY2xhc3MgT3VpUG9wdXBTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBvcGVuUG9wdXBzOiB7XG4gICAgW3g6IHN0cmluZ106IElQb3B1cDtcbiAgfSA9IHt9O1xuXG4gIHByaXZhdGUgcG9wdXBPcGVuU3ViamVjdCA9IG5ldyBTdWJqZWN0PElQb3B1cD4oKTtcbiAgcHJpdmF0ZSBwb3B1cENsb3NlZFN1YmplY3QgPSBuZXcgU3ViamVjdDxJUG9wdXA+KCk7XG5cbiAgcHVibGljIHBvcHVwT3BlbiQgPSB0aGlzLnBvcHVwT3BlblN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XG4gIHB1YmxpYyBwb3B1cENsb3NlZCQgPSB0aGlzLnBvcHVwQ2xvc2VkU3ViamVjdC5hc09ic2VydmFibGUoKTtcblxuICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjI7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgcm91dGVyOiBSb3V0ZXIsXG4gICAgcHJpdmF0ZSB6b25lOiBOZ1pvbmUsXG4gICAgcHJpdmF0ZSBhcHBSZWY6IEFwcGxpY2F0aW9uUmVmLFxuICAgIHByaXZhdGUgaW5qZWN0b3I6IEVudmlyb25tZW50SW5qZWN0b3IsXG4gICAgcHJpdmF0ZSByZW5kZXJlckZhY3Rvcnk6IFJlbmRlcmVyRmFjdG9yeTIsXG4gICAgQEluamVjdChET0NVTUVOVCkgcHJpdmF0ZSBkb2N1bWVudDogRG9jdW1lbnRcbiAgKSB7XG4gICAgdGhpcy5yZW5kZXJlciA9IHJlbmRlcmVyRmFjdG9yeS5jcmVhdGVSZW5kZXJlcihudWxsLCBudWxsKTtcblxuICAgIHRoaXMucm91dGVyLmV2ZW50cy5zdWJzY3JpYmUodmFsID0+IHtcbiAgICAgIGlmICh2YWwgaW5zdGFuY2VvZiBOYXZpZ2F0aW9uU3RhcnQpIHtcbiAgICAgICAgdGhpcy5kZXN0cm95UG9wdXBzKCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBmcm9tRXZlbnQoZG9jdW1lbnQsICdrZXl1cCcpLnN1YnNjcmliZSgoZXZlbnQ6IGFueSkgPT4ge1xuICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ0VzY2FwZScpIHtcbiAgICAgICAgdGhpcy5vbkVzY2FwZVByZXNzKCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBmcm9tRXZlbnQoZG9jdW1lbnQuYm9keSwgJ2NsaWNrJykuc3Vic2NyaWJlKChldmVudDogYW55KSA9PiB7XG4gICAgICB0aGlzLm9uRG9jdW1lbnRDbGljayhldmVudCk7XG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgb25Fc2NhcGVQcmVzcygpIHtcbiAgICBmb3IgKGNvbnN0IGlkIGluIHRoaXMub3BlblBvcHVwcykge1xuICAgICAgaWYgKHRoaXMub3BlblBvcHVwc1tpZF0ub3B0aW9ucy5jbG9zZU9uRXNjYXBlKSB7XG4gICAgICAgIHRoaXMuZGlzcG9zZShpZCk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBvbkRvY3VtZW50Q2xpY2soZXZlbnQ6IGFueSkge1xuICAgIGZvciAoY29uc3QgaWQgaW4gdGhpcy5vcGVuUG9wdXBzKSB7XG4gICAgICBpZiAoXG4gICAgICAgIHRoaXMub3BlblBvcHVwc1tpZF0ub3B0aW9ucy5jbG9zZU9uT3V0c2lkZUNsaWNrICYmXG4gICAgICAgIHRoaXMub3BlblBvcHVwc1tpZF0uaXNJbml0aWFsaXNlZCAmJlxuICAgICAgICAhdGhpcy5vcGVuUG9wdXBzW2lkXS5wb3B1cEVsZW1lbnQuY29udGFpbnMoZXZlbnQudGFyZ2V0KVxuICAgICAgKSB7XG4gICAgICAgIHRoaXMuZGlzcG9zZShpZCk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcHVibGljIGRlc3Ryb3lQb3B1cHMoKSB7XG4gICAgZm9yIChjb25zdCBpZCBpbiB0aGlzLm9wZW5Qb3B1cHMpIHtcbiAgICAgIHRoaXMuZG9EaXNwb3NlKGlkKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgb3BlblBvcHVwPFQgZXh0ZW5kcyBPdWlQb3B1cENvbXBvbmVudD4oXG4gICAgY29udGVudDogQ29tcG9uZW50VHlwZTxUPixcbiAgICBpbnB1dHM6IHsgW3g6IHN0cmluZ106IHVua25vd24gfSxcbiAgICBvcHRpb25zOiBJUG9wdXBPcHRpb25zID0ge30sXG4gICAgb3JpZ2luPzogSFRNTEVsZW1lbnQgfCBWaXJ0dWFsRWxlbWVudFxuICApOiBJUG9wdXAge1xuICAgIGNvbnN0IGlkID0gb3B0aW9ucy5pZCA/PyBHVUlEKCk7XG4gICAgY29uc3QgcG9wdXAgPSB0aGlzLnJlbmRlcmVyLmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHBvcHVwLmlkID0gaWQ7XG4gICAgdGhpcy5yZW5kZXJlci5hZGRDbGFzcyhwb3B1cCwgJ291aS1wb3B1cCcpO1xuICAgIGNvbnN0IGNyZWF0ZUNvbXBvbmVudE9wdGlvbnMgPSB7XG4gICAgICBjb21wb25lbnQ6IGNvbnRlbnQsXG4gICAgICBwYXJlbnRFbGVtZW50OiBwb3B1cCxcbiAgICAgIGFwcFJlZjogdGhpcy5hcHBSZWYsXG4gICAgICBjcmVhdGVDb21wb25lbnRPcHRpb25zOiB7XG4gICAgICAgIGVudmlyb25tZW50SW5qZWN0b3I6IHRoaXMuaW5qZWN0b3IsXG4gICAgICB9LFxuICAgICAgaW5wdXRzOiBpbnB1dHMsXG4gICAgfTtcbiAgICBjb25zdCBjb21wb25lbnRSZWYgPSBDb21wb25lbnRDcmVhdG9yLmNyZWF0ZUNvbXBvbmVudChcbiAgICAgIGNyZWF0ZUNvbXBvbmVudE9wdGlvbnNcbiAgICApO1xuICAgIHRoaXMucmVuZGVyZXIuYXBwZW5kQ2hpbGQodGhpcy5kb2N1bWVudC5ib2R5LCBwb3B1cCk7XG4gICAgY29uc3QgYXJyb3dNb2RpZmllckluZGV4ID0gb3B0aW9ucz8ubW9kaWZpZXJzPy5maW5kSW5kZXgoXG4gICAgICBtb2RpZmllciA9PiBtb2RpZmllci5uYW1lID09PSAnYXJyb3cnXG4gICAgKTtcbiAgICBpZiAoIWlzTmlsKGFycm93TW9kaWZpZXJJbmRleCkgJiYgYXJyb3dNb2RpZmllckluZGV4ID4gLTEpIHtcbiAgICAgIGNvbnN0IGFycm93ID0gdGhpcy5yZW5kZXJlci5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgIGFycm93LmlkID0gJ2Fycm93JztcbiAgICAgIHRoaXMucmVuZGVyZXIuYXBwZW5kQ2hpbGQocG9wdXAsIGFycm93KTtcbiAgICAgIGlmIChvcHRpb25zLm1vZGlmaWVycykge1xuICAgICAgICBvcHRpb25zLm1vZGlmaWVyc1thcnJvd01vZGlmaWVySW5kZXhdLm9wdGlvbnMuZWxlbWVudCA9IGFycm93O1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKFxuICAgICAgICAgIGFycm93LFxuICAgICAgICAgICdiYWNrZ3JvdW5kQ29sb3InLFxuICAgICAgICAgIG9wdGlvbnMubW9kaWZpZXJzW2Fycm93TW9kaWZpZXJJbmRleF0ub3B0aW9ucy5jb2xvclxuICAgICAgICApO1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKFxuICAgICAgICAgIGFycm93LFxuICAgICAgICAgICdjb2xvcicsXG4gICAgICAgICAgb3B0aW9ucy5tb2RpZmllcnNbYXJyb3dNb2RpZmllckluZGV4XS5vcHRpb25zLmNvbG9yXG4gICAgICAgICk7XG4gICAgICAgIHRoaXMucmVuZGVyZXIuc2V0QXR0cmlidXRlKGFycm93LCAnZGF0YS1wb3BwZXItYXJyb3cnLCAnJyk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgZGVmYXVsdE1vZGlmaWVycyA9IFtcbiAgICAgIHtcbiAgICAgICAgbmFtZTogJ3ByZXZlbnRPdmVyZmxvdycsXG4gICAgICAgIG9wdGlvbnM6IHtcbiAgICAgICAgICBhbHRBeGlzOiB0cnVlLFxuICAgICAgICAgIHBhZGRpbmc6IDUsXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIF07XG4gICAgY29uc3QgY29tYmluZWRNb2RpZmllcnMgPSBbXG4gICAgICAuLi5kZWZhdWx0TW9kaWZpZXJzLFxuICAgICAgLi4uKG9wdGlvbnMubW9kaWZpZXJzIHx8IFtdKSxcbiAgICBdO1xuICAgIG9wdGlvbnMubW9kaWZpZXJzID0gY29tYmluZWRNb2RpZmllcnM7XG4gICAgdGhpcy56b25lLnJ1bk91dHNpZGVBbmd1bGFyKCgpID0+IHtcbiAgICAgIGNvbnN0IHBvcHBlclJlZiA9IGNyZWF0ZVBvcHBlcihcbiAgICAgICAgb3JpZ2luID8/IHRoaXMuZG9jdW1lbnQuYm9keSxcbiAgICAgICAgcG9wdXAsXG4gICAgICAgIG9wdGlvbnNcbiAgICAgICk7XG4gICAgICB0aGlzLm9wZW5Qb3B1cHNbaWRdID0ge1xuICAgICAgICBwb3BwZXJSZWYsXG4gICAgICAgIGNvbXBvbmVudFJlZixcbiAgICAgICAgcG9wdXBFbGVtZW50OiBwb3B1cCxcbiAgICAgICAgaWQ6IGlkLFxuICAgICAgICBvcHRpb25zOiBvcHRpb25zLFxuICAgICAgICBpc0luaXRpYWxpc2VkOiBmYWxzZSxcbiAgICAgIH07XG4gICAgICBjb21wb25lbnRSZWYuaW5zdGFuY2UucG9wdXAgPSB0aGlzLm9wZW5Qb3B1cHNbaWRdO1xuICAgIH0pO1xuICAgIHRoaXMucG9wdXBPcGVuU3ViamVjdC5uZXh0KHRoaXMub3BlblBvcHVwc1tpZF0pO1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgaWYgKHRoaXMub3BlblBvcHVwc1tpZF0pIHtcbiAgICAgICAgdGhpcy5vcGVuUG9wdXBzW2lkXS5pc0luaXRpYWxpc2VkID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9LCAzMDApO1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShwb3B1cCwgJ29wYWNpdHknLCAnMScpO1xuICAgIH0sIDApO1xuICAgIHJldHVybiB0aGlzLm9wZW5Qb3B1cHNbaWRdO1xuICB9XG5cbiAgcHVibGljIGRpc3Bvc2UoaWQ6IHN0cmluZykge1xuICAgIGlmICh0aGlzLm9wZW5Qb3B1cHM/LltpZF0pIHtcbiAgICAgIHRoaXMuZG9EaXNwb3NlKGlkKTtcbiAgICB9XG4gIH1cblxuICAvLyBUT0RPOiBNaWdodCBjYXVzZSBtZW1vcnktbGVha3MsIGVuc3VyZSBpdCBkb2Vzbid0XG4gIHByaXZhdGUgZG9EaXNwb3NlKGlkOiBzdHJpbmcpIHtcbiAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKHRoaXMub3BlblBvcHVwc1tpZF0ucG9wdXBFbGVtZW50LCAnb3BhY2l0eScsICcwJyk7XG4gICAgY29uc3QgcG9wcGVyUmVmID0gdGhpcy5vcGVuUG9wdXBzW2lkXS5wb3BwZXJSZWY7XG4gICAgY29uc3QgY29tcG9uZW50UmVmID0gdGhpcy5vcGVuUG9wdXBzW2lkXS5jb21wb25lbnRSZWY7XG4gICAgY29uc3QgcG9wdXBFbGVtZW50ID0gdGhpcy5vcGVuUG9wdXBzW2lkXS5wb3B1cEVsZW1lbnQ7XG4gICAgdGhpcy5wb3B1cENsb3NlZFN1YmplY3QubmV4dCh0aGlzLm9wZW5Qb3B1cHNbaWRdKTtcbiAgICBkZWxldGUgdGhpcy5vcGVuUG9wdXBzW2lkXTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHBvcHBlclJlZi5kZXN0cm95KCk7XG4gICAgICBjb21wb25lbnRSZWYuZGVzdHJveSgpO1xuICAgICAgdGhpcy5yZW5kZXJlci5yZW1vdmVDaGlsZCh0aGlzLmRvY3VtZW50LmJvZHksIHBvcHVwRWxlbWVudCk7XG4gICAgICB0aGlzLmFwcFJlZi5kZXRhY2hWaWV3KGNvbXBvbmVudFJlZi5ob3N0Vmlldyk7XG4gICAgfSwgMzAwKTtcbiAgfVxufVxuIl19