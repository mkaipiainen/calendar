import { ChangeDetectionStrategy, Component, DestroyRef, effect, inject, input, signal, } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { debounceTime, Subject } from 'rxjs';
import * as i0 from "@angular/core";
export class OpenlayersBaseLayerComponent {
    destroyRef = inject(DestroyRef);
    map = input.required();
    isHovered = signal(false);
    optionsChangedSubject = new Subject();
    constructor() {
        effect(() => {
            const options = this.options ? this.options() : undefined;
            if (options) {
                this.optionsChangedSubject.next(options);
            }
        });
        this.optionsChangedSubject
            .pipe(takeUntilDestroyed(this.destroyRef), debounceTime(300))
            .subscribe((newValue) => {
            this.updateLayer(newValue);
            this.map().updateLayer(this, this.onAdd.bind(this), this.onRemove.bind(this));
        });
    }
    /**
     * This method is called when the layer is added to the map
     * Override in child-classes if necessary
     * @param map
     * @protected
     */
    onAdd(map) {
        return;
    }
    /**
     * This method is called when the layer is removed from the map
     * Override in child-classes if necessary
     * @param map
     * @protected
     */
    onRemove(map) {
        return;
    }
    onHover(feature) {
        const options = this.options ? this.options() : undefined;
        if (options?.onHover) {
            options.onHover(feature);
        }
    }
    onUnHover(feature) {
        this.isHovered.set(false);
    }
    onClick(feature) {
        const options = this.options ? this.options() : undefined;
        if (options?.onClick) {
            options.onClick(feature);
        }
    }
    onDestroy(openlayers) {
        return;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersBaseLayerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "17.3.1", type: OpenlayersBaseLayerComponent, isStandalone: true, selector: "openlayers-base-layer", inputs: { map: { classPropertyName: "map", publicName: "map", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersBaseLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'openlayers-base-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BlbmxheWVycy1iYXNlLWxheWVyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvb3BlbmxheWVycy9sYXllcnMvb3BlbmxheWVycy1iYXNlLWxheWVyLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBRUwsdUJBQXVCLEVBQ3ZCLFNBQVMsRUFDVCxVQUFVLEVBQ1YsTUFBTSxFQUVOLE1BQU0sRUFDTixLQUFLLEVBSUwsTUFBTSxHQUVQLE1BQU0sZUFBZSxDQUFDO0FBS3ZCLE9BQU8sRUFBRSxrQkFBa0IsRUFBZ0IsTUFBTSw0QkFBNEIsQ0FBQztBQUM5RSxPQUFPLEVBQUUsWUFBWSxFQUFZLE9BQU8sRUFBRSxNQUFNLE1BQU0sQ0FBQzs7QUFhdkQsTUFBTSxPQUFnQiw0QkFBNEI7SUFHdEMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUduQyxHQUFHLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBdUIsQ0FBQztJQUU1QyxTQUFTLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBR3pCLHFCQUFxQixHQUFHLElBQUksT0FBTyxFQUFLLENBQUM7SUFFakQ7UUFDRSxNQUFNLENBQUMsR0FBRyxFQUFFO1lBQ1YsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7WUFDMUQsSUFBSSxPQUFPLEVBQUUsQ0FBQztnQkFDWixJQUFJLENBQUMscUJBQXFCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzNDLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxxQkFBcUI7YUFDdkIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUM7YUFDNUQsU0FBUyxDQUFDLENBQUMsUUFBVyxFQUFFLEVBQUU7WUFDekIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUMzQixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsV0FBVyxDQUNwQixJQUFXLEVBQ1gsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQ3JCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUN6QixDQUFDO1FBQ0osQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBVUQ7Ozs7O09BS0c7SUFDTyxLQUFLLENBQUMsR0FBd0I7UUFDdEMsT0FBTztJQUNULENBQUM7SUFFRDs7Ozs7T0FLRztJQUNPLFFBQVEsQ0FBQyxHQUF3QjtRQUN6QyxPQUFPO0lBQ1QsQ0FBQztJQUVNLE9BQU8sQ0FBQyxPQUFrQjtRQUMvQixNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQztRQUMxRCxJQUFJLE9BQU8sRUFBRSxPQUFPLEVBQUUsQ0FBQztZQUNyQixPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzNCLENBQUM7SUFDSCxDQUFDO0lBRU0sU0FBUyxDQUFDLE9BQWtCO1FBQ2pDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUFFTSxPQUFPLENBQUMsT0FBa0I7UUFDL0IsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUM7UUFDMUQsSUFBSSxPQUFPLEVBQUUsT0FBTyxFQUFFLENBQUM7WUFDckIsT0FBTyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMzQixDQUFDO0lBQ0gsQ0FBQztJQUVNLFNBQVMsQ0FBQyxVQUErQjtRQUM5QyxPQUFPO0lBQ1QsQ0FBQzt1R0FqRm1CLDRCQUE0QjsyRkFBNUIsNEJBQTRCLDhNQUx0QyxFQUFFOzsyRkFLUSw0QkFBNEI7a0JBUGpELFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLHVCQUF1QjtvQkFDakMsUUFBUSxFQUFFLEVBQUU7b0JBQ1osVUFBVSxFQUFFLElBQUk7b0JBQ2hCLE9BQU8sRUFBRSxFQUFFO29CQUNYLGVBQWUsRUFBRSx1QkFBdUIsQ0FBQyxNQUFNO2lCQUNoRCIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFmdGVyVmlld0luaXQsXG4gIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LFxuICBDb21wb25lbnQsXG4gIERlc3Ryb3lSZWYsXG4gIGVmZmVjdCxcbiAgRXZlbnRFbWl0dGVyLFxuICBpbmplY3QsXG4gIGlucHV0LFxuICBJbnB1dFNpZ25hbCxcbiAgT3V0cHV0LFxuICBTaWduYWwsXG4gIHNpZ25hbCxcbiAgV3JpdGFibGVTaWduYWwsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRmVhdHVyZSB9IGZyb20gJ0B0dXJmL2hlbHBlcnMnO1xuaW1wb3J0IHsgRmVhdHVyZSBhcyBPbEZlYXR1cmUgfSBmcm9tICdvbCc7XG5pbXBvcnQgeyBPcGVubGF5ZXJzQ29tcG9uZW50IH0gZnJvbSAnLi4vb3BlbmxheWVycy5jb21wb25lbnQnO1xuaW1wb3J0IHsgZGVib3VuY2UgfSBmcm9tICdsb2Rhc2gtZXMnO1xuaW1wb3J0IHsgdGFrZVVudGlsRGVzdHJveWVkLCB0b09ic2VydmFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlL3J4anMtaW50ZXJvcCc7XG5pbXBvcnQgeyBkZWJvdW5jZVRpbWUsIHBhaXJ3aXNlLCBTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5pbXBvcnQge1xuICBPdWlPcGVuTGF5ZXJzQ29tbW9uT3B0aW9ucyxcbiAgT3VpT3BlbmxheWVyc1RpbGVMYXllck9wdGlvbnMsXG59IGZyb20gJy4uL3R5cGVzJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3BlbmxheWVycy1iYXNlLWxheWVyJyxcbiAgdGVtcGxhdGU6ICcnLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIE9wZW5sYXllcnNCYXNlTGF5ZXJDb21wb25lbnQ8XG4gIFQgZXh0ZW5kcyBPdWlPcGVuTGF5ZXJzQ29tbW9uT3B0aW9ucyxcbj4ge1xuICBwcm90ZWN0ZWQgZGVzdHJveVJlZiA9IGluamVjdChEZXN0cm95UmVmKTtcbiAgcHVibGljIGFic3RyYWN0IG9wdGlvbnM6IElucHV0U2lnbmFsPFQ+IHwgdW5kZWZpbmVkO1xuICBwdWJsaWMgYWJzdHJhY3QgY29tYmluZWRPcHRpb25zOiBTaWduYWw8VD4gfCB1bmRlZmluZWQ7XG4gIHB1YmxpYyBtYXAgPSBpbnB1dC5yZXF1aXJlZDxPcGVubGF5ZXJzQ29tcG9uZW50PigpO1xuXG4gIHB1YmxpYyBpc0hvdmVyZWQgPSBzaWduYWwoZmFsc2UpO1xuICBwdWJsaWMgYWJzdHJhY3QgbGF5ZXI6IFdyaXRhYmxlU2lnbmFsPGFueT47XG4gIHB1YmxpYyBhYnN0cmFjdCBzb3VyY2U6IFdyaXRhYmxlU2lnbmFsPGFueT47XG4gIHByaXZhdGUgb3B0aW9uc0NoYW5nZWRTdWJqZWN0ID0gbmV3IFN1YmplY3Q8VD4oKTtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICBlZmZlY3QoKCkgPT4ge1xuICAgICAgY29uc3Qgb3B0aW9ucyA9IHRoaXMub3B0aW9ucyA/IHRoaXMub3B0aW9ucygpIDogdW5kZWZpbmVkO1xuICAgICAgaWYgKG9wdGlvbnMpIHtcbiAgICAgICAgdGhpcy5vcHRpb25zQ2hhbmdlZFN1YmplY3QubmV4dChvcHRpb25zKTtcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIHRoaXMub3B0aW9uc0NoYW5nZWRTdWJqZWN0XG4gICAgICAucGlwZSh0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSwgZGVib3VuY2VUaW1lKDMwMCkpXG4gICAgICAuc3Vic2NyaWJlKChuZXdWYWx1ZTogVCkgPT4ge1xuICAgICAgICB0aGlzLnVwZGF0ZUxheWVyKG5ld1ZhbHVlKTtcbiAgICAgICAgdGhpcy5tYXAoKS51cGRhdGVMYXllcihcbiAgICAgICAgICB0aGlzIGFzIGFueSxcbiAgICAgICAgICB0aGlzLm9uQWRkLmJpbmQodGhpcyksXG4gICAgICAgICAgdGhpcy5vblJlbW92ZS5iaW5kKHRoaXMpXG4gICAgICAgICk7XG4gICAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIG1ldGhvZCBpcyBjYWxsZWQgd2hlbmV2ZXIgb3B0aW9ucyBvZiBhIGxheWVyIGFyZSB1cGRhdGVkXG4gICAqIFNob3VsZCB1cGRhdGUgdGhlIHNvdXJjZSBvZiB0aGUgbGF5ZXIgYmFzZWQgb24gdGhlIG5ldyBvcHRpb25zXG4gICAqIFVwZGF0aW5nIG9uIHRoZSBzaWRlIG9mIHRoZSBtYXAgaXMgaGFuZGxlZCBhdXRvbWF0aWNhbGx5XG4gICAqIEBwYXJhbSBuZXdPcHRpb25zXG4gICAqL1xuICBwdWJsaWMgYWJzdHJhY3QgdXBkYXRlTGF5ZXIobmV3T3B0aW9uczogVCk6IHZvaWQ7XG5cbiAgLyoqXG4gICAqIFRoaXMgbWV0aG9kIGlzIGNhbGxlZCB3aGVuIHRoZSBsYXllciBpcyBhZGRlZCB0byB0aGUgbWFwXG4gICAqIE92ZXJyaWRlIGluIGNoaWxkLWNsYXNzZXMgaWYgbmVjZXNzYXJ5XG4gICAqIEBwYXJhbSBtYXBcbiAgICogQHByb3RlY3RlZFxuICAgKi9cbiAgcHJvdGVjdGVkIG9uQWRkKG1hcDogT3BlbmxheWVyc0NvbXBvbmVudCk6IHZvaWQge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGlzIG1ldGhvZCBpcyBjYWxsZWQgd2hlbiB0aGUgbGF5ZXIgaXMgcmVtb3ZlZCBmcm9tIHRoZSBtYXBcbiAgICogT3ZlcnJpZGUgaW4gY2hpbGQtY2xhc3NlcyBpZiBuZWNlc3NhcnlcbiAgICogQHBhcmFtIG1hcFxuICAgKiBAcHJvdGVjdGVkXG4gICAqL1xuICBwcm90ZWN0ZWQgb25SZW1vdmUobWFwOiBPcGVubGF5ZXJzQ29tcG9uZW50KTogdm9pZCB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgcHVibGljIG9uSG92ZXIoZmVhdHVyZTogT2xGZWF0dXJlKSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHRoaXMub3B0aW9ucyA/IHRoaXMub3B0aW9ucygpIDogdW5kZWZpbmVkO1xuICAgIGlmIChvcHRpb25zPy5vbkhvdmVyKSB7XG4gICAgICBvcHRpb25zLm9uSG92ZXIoZmVhdHVyZSk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG9uVW5Ib3ZlcihmZWF0dXJlOiBPbEZlYXR1cmUpIHtcbiAgICB0aGlzLmlzSG92ZXJlZC5zZXQoZmFsc2UpO1xuICB9XG5cbiAgcHVibGljIG9uQ2xpY2soZmVhdHVyZTogT2xGZWF0dXJlKSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHRoaXMub3B0aW9ucyA/IHRoaXMub3B0aW9ucygpIDogdW5kZWZpbmVkO1xuICAgIGlmIChvcHRpb25zPy5vbkNsaWNrKSB7XG4gICAgICBvcHRpb25zLm9uQ2xpY2soZmVhdHVyZSk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG9uRGVzdHJveShvcGVubGF5ZXJzOiBPcGVubGF5ZXJzQ29tcG9uZW50KSB7XG4gICAgcmV0dXJuO1xuICB9XG59XG4iXX0=