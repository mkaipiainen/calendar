import { AfterViewInit, ChangeDetectorRef, DestroyRef, ElementRef, QueryList } from '@angular/core';
import { TableService } from '../table.service';
import { IOuiTableColumn } from '../types';
import * as i0 from "@angular/core";
export declare class OuiTableHeadComponent implements AfterViewInit {
    private destroyRef;
    private cdr;
    tableService: TableService;
    columnRefs: QueryList<ElementRef>;
    sortRank: number | undefined;
    columns: import("@angular/core").WritableSignal<IOuiTableColumn[]>;
    sortOrder: import("@angular/core").WritableSignal<{
        [columnId: string]: {
            rank: number;
            direction: 'ASC' | 'DESC';
        };
    }>;
    constructor(destroyRef: DestroyRef, cdr: ChangeDetectorRef);
    ngAfterViewInit(): void;
    private initColumnWidths;
    trackById(index: number, column: IOuiTableColumn): string;
    toggleSort(column: IOuiTableColumn): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiTableHeadComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiTableHeadComponent, "oui-table-head", never, { "tableService": { "alias": "tableService"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=oui-table-head.component.d.ts.map