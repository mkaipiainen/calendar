import { Pipe } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Pipe to check if a value is null or undefined
 * @param value value to check
 */
export class InputClassPipe {
    transform(model, variant, isInitialized, isActive) {
        const isActiveCombined = !!model || isActive;
        return `oui-input ${variant} ${isActiveCombined ? 'focused' : ''} ${isInitialized ? 'initialized' : ''}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: InputClassPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: InputClassPipe, isStandalone: true, name: "inputClass" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: InputClassPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'inputClass',
                    standalone: true,
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5wdXQtY2xhc3MucGlwZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvaW5wdXQvaW5wdXQtY2xhc3MucGlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsSUFBSSxFQUFpQixNQUFNLGVBQWUsQ0FBQzs7QUFFcEQ7OztHQUdHO0FBS0gsTUFBTSxPQUFPLGNBQWM7SUFDekIsU0FBUyxDQUNQLEtBQVUsRUFDVixPQUFlLEVBQ2YsYUFBc0IsRUFDdEIsUUFBaUI7UUFFakIsTUFBTSxnQkFBZ0IsR0FBRyxDQUFDLENBQUMsS0FBSyxJQUFJLFFBQVEsQ0FBQztRQUM3QyxPQUFPLGFBQWEsT0FBTyxJQUFJLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFDOUQsYUFBYSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEVBQ2xDLEVBQUUsQ0FBQztJQUNMLENBQUM7dUdBWFUsY0FBYztxR0FBZCxjQUFjOzsyRkFBZCxjQUFjO2tCQUoxQixJQUFJO21CQUFDO29CQUNKLElBQUksRUFBRSxZQUFZO29CQUNsQixVQUFVLEVBQUUsSUFBSTtpQkFDakIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQaXBlLCBQaXBlVHJhbnNmb3JtIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbi8qKlxuICogUGlwZSB0byBjaGVjayBpZiBhIHZhbHVlIGlzIG51bGwgb3IgdW5kZWZpbmVkXG4gKiBAcGFyYW0gdmFsdWUgdmFsdWUgdG8gY2hlY2tcbiAqL1xuQFBpcGUoe1xuICBuYW1lOiAnaW5wdXRDbGFzcycsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG59KVxuZXhwb3J0IGNsYXNzIElucHV0Q2xhc3NQaXBlIGltcGxlbWVudHMgUGlwZVRyYW5zZm9ybSB7XG4gIHRyYW5zZm9ybShcbiAgICBtb2RlbDogYW55LFxuICAgIHZhcmlhbnQ6IHN0cmluZyxcbiAgICBpc0luaXRpYWxpemVkOiBib29sZWFuLFxuICAgIGlzQWN0aXZlOiBib29sZWFuXG4gICk6IHN0cmluZyB7XG4gICAgY29uc3QgaXNBY3RpdmVDb21iaW5lZCA9ICEhbW9kZWwgfHwgaXNBY3RpdmU7XG4gICAgcmV0dXJuIGBvdWktaW5wdXQgJHt2YXJpYW50fSAke2lzQWN0aXZlQ29tYmluZWQgPyAnZm9jdXNlZCcgOiAnJ30gJHtcbiAgICAgIGlzSW5pdGlhbGl6ZWQgPyAnaW5pdGlhbGl6ZWQnIDogJydcbiAgICB9YDtcbiAgfVxufVxuIl19