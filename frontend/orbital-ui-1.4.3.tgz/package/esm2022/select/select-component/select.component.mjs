import { ChangeDetectionStrategy, ChangeDetectorRef, Component, computed, effect, EventEmitter, HostListener, inject, Inject, input, Input, model, Output, signal, ViewChild, } from '@angular/core';
import { createPopper } from '@popperjs/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { OuiIconComponent } from 'orbital-ui/icon';
import { OuiButtonComponent } from 'orbital-ui/button';
import { GUID } from 'orbital-ui/helpers';
import { isPlainObject, merge, xorBy } from 'lodash-es';
import { IsSelectItemActivePipe } from './is-select-item-active.pipe';
import { SelectItemLabelPipe } from './select-item-label.pipe';
import { OuiInputComponent } from 'orbital-ui/input';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { AutofocusDirective } from 'orbital-ui/autofocus';
import { fromEvent, Subject, takeUntil } from 'rxjs';
import * as i0 from "@angular/core";
import * as i1 from "../select.service";
import * as i2 from "@angular/common";
/**
 * Component that can be used to create select-dropdowns.You can either pass simple strings in an array as the options to choose from,
 * or alternatively pass in objects with an additionally defined label-key and id-key.
 *
 * Example use:
 * <oui-select [(model)]="selectedItem" [idKey]="'value'" [labelKey]="'name'" [options]="selectValues"></oui-select>
 */
export class OuiSelectComponent {
    vcr;
    ouiSelectService;
    destroyRef;
    document;
    cdr = inject(ChangeDetectorRef);
    /**
     *   labelKey       - The key in each object that's used to display a text in the dropdown.
     *   idKey          - The key in each object that is used to define which item is selected. Essentially the key in each object which should be used to differentiate each itme from each other item.
     *   type:          - The type of the select. Can be either 'standard' or 'underlined'. Defaults to 'standard'
     */
    options = input();
    isOpen = model(false);
    /**
     *   The options the user can choose from in the dropdown. If given a list of strings, simply shows those strings, and binds
     *   the model to the selected string. If given an array of objects, also need to pass in a labelKey and and idKey -input
     *   (although they are by default 'label' and 'id').
     */
    items = input.required();
    disabled = false;
    /**
     *   The model that's bound to the selected item
     */
    model;
    /**
     *   A template that should be used for each item. If none is given, then uses a default. This can be used if you need
     *   heavily customized dropdown-items
     */
    template;
    /**
     *   Triggered when model changes
     */
    modelChange = new EventEmitter();
    /**
     *   Triggered when dropdown closes
     */
    closed = new EventEmitter();
    dropdownContent;
    origin;
    defaultOptions = {
        labelKey: 'label',
        idKey: 'id',
        isMultiple: false,
        search: {
            isEnabled: false,
            isFocusedOnOpen: false,
        },
        isSelectingWithKeyboardActive: false,
        type: 'standard',
        contentClass: '',
        getToggleLabel: (item) => {
            return item[this.combinedOptions().labelKey] ?? item;
        },
    };
    currentDropdown;
    closed$ = new Subject();
    combinedOptions = computed(() => {
        return merge({ ...this.defaultOptions }, { ...this.options() });
    });
    view;
    popperRef;
    isClosing = false;
    id = GUID();
    dropdownHeight = signal('0px');
    selectToggleLabel = signal('');
    searchValue = signal('');
    itemType = computed(() => {
        return this.items()?.[0]?.[this.combinedOptions().idKey]
            ? 'object'
            : 'simple';
    });
    candidateForSelectionIndex = signal(0);
    filteredItems = computed(() => {
        if (!this.combinedOptions().search?.isEnabled) {
            return [...this.items()];
        }
        return this.items().filter(item => {
            const label = this.combinedOptions().labelKey && isPlainObject(item)
                ? item[this.combinedOptions().labelKey]
                : item;
            return label.toLowerCase().includes(this.searchValue().toLowerCase());
        });
    });
    constructor(vcr, ouiSelectService, destroyRef, document) {
        this.vcr = vcr;
        this.ouiSelectService = ouiSelectService;
        this.destroyRef = destroyRef;
        this.document = document;
        effect(() => {
            const dropdownHeightFromOptions = this.combinedOptions().dropdownHeight;
            if (dropdownHeightFromOptions) {
                this.dropdownHeight.set(dropdownHeightFromOptions);
            }
            if (this.model) {
                this.updateToggleLabel();
            }
        }, {
            allowSignalWrites: true,
        });
    }
    ngAfterViewInit() {
        this.ouiSelectService.register(this);
        this.updateToggleLabel();
        setTimeout(() => {
            if (this.isOpen()) {
                this.open();
            }
        }, 100);
    }
    get label() {
        if (typeof this.model === 'string') {
            return this.model;
        }
        else if (this.combinedOptions().labelKey) {
            return this.model
                ? this.model[this.combinedOptions().labelKey]
                : 'Select...';
        }
        else {
            console.error('Could not get label for the item');
            return '';
        }
    }
    select(option) {
        if (this.combinedOptions().isMultiple) {
            const comparator = this.itemType() === 'simple'
                ? (item) => item
                : this.combinedOptions().idKey;
            this.model = xorBy(this.model, [option], comparator);
        }
        else {
            let isCurrentlySelected = false;
            if (this.itemType() === 'simple') {
                isCurrentlySelected = this.model === option;
            }
            else {
                isCurrentlySelected =
                    this.model?.[this.combinedOptions().idKey] ===
                        option[this.combinedOptions().idKey];
            }
            if (isCurrentlySelected) {
                this.model = undefined;
            }
            else {
                this.model = option;
            }
            this.close();
        }
        this.modelChange.emit(this.model);
        this.updateToggleLabel();
    }
    updateToggleLabel() {
        let label = '';
        if (this.combinedOptions().isMultiple) {
            label = this.model.map(this.combinedOptions().getToggleLabel).join(', ');
        }
        else {
            label = this.model
                ? this.combinedOptions().getToggleLabel(this.model)
                : '';
        }
        this.selectToggleLabel.set(label);
    }
    open() {
        this.isOpen.set(true);
        this.view = this.vcr.createEmbeddedView(this.dropdownContent);
        this.currentDropdown = this.view.rootNodes[0];
        this.document.body.appendChild(this.currentDropdown);
        this.currentDropdown.style.width = `${this.origin.nativeElement.offsetWidth}px`;
        this.currentDropdown.classList.add('open');
        if (this.combinedOptions().search?.isEnabled) {
            this.currentDropdown.classList.add('has-search');
        }
        if (this.combinedOptions().contentClass) {
            this.currentDropdown.classList.add(this.combinedOptions().contentClass);
        }
        this.popperRef = createPopper(this.origin.nativeElement, this.currentDropdown, {
            placement: 'bottom-start',
            modifiers: [
                {
                    name: 'preventOverflow',
                    options: {
                        altAxis: true,
                        padding: 5,
                    },
                },
            ],
        });
        const observer = new ResizeObserver(() => {
            this.popperRef.update();
        });
        observer.observe(this.currentDropdown);
        fromEvent(this.document.body, 'keydown')
            .pipe(takeUntilDestroyed(this.destroyRef), takeUntil(this.closed$))
            .subscribe((event) => {
            if (this.combinedOptions().isSelectingWithKeyboardActive &&
                event.key === 'Enter') {
                event.preventDefault();
                event.stopPropagation();
                this.select(this.filteredItems()[this.candidateForSelectionIndex()]);
                if (!this.combinedOptions().isMultiple) {
                    this.close();
                }
            }
            if (event.key === 'Escape') {
                this.close();
            }
            if (this.combinedOptions().isSelectingWithKeyboardActive &&
                (event.key === 'ArrowDown' || event.key === 'ArrowUp')) {
                event.stopPropagation();
                event.preventDefault();
                const itemLength = this.filteredItems()?.length;
                if (event.key === 'ArrowDown') {
                    const newIndex = this.candidateForSelectionIndex() + 1 >= itemLength
                        ? 0
                        : this.candidateForSelectionIndex() + 1;
                    this.candidateForSelectionIndex.set(newIndex);
                }
                else {
                    const newIndex = this.candidateForSelectionIndex() - 1 < 0
                        ? itemLength - 1
                        : this.candidateForSelectionIndex() - 1;
                    this.candidateForSelectionIndex.set(newIndex);
                }
            }
        });
        setTimeout(() => {
            if (this.currentDropdown && observer) {
                observer.unobserve(this.currentDropdown);
            }
        }, 1000);
        setTimeout(() => {
            this.cdr.detectChanges();
        });
    }
    toggle() {
        if (this.isClosing) {
            return;
        }
        if (this.isOpen()) {
            this.close();
        }
        else {
            this.open();
        }
    }
    close() {
        this.closed$.next(true);
        this.isClosing = true;
        this.closed.emit();
        if (this.currentDropdown) {
            this.currentDropdown.classList.remove('open');
        }
        setTimeout(() => {
            if (this.view) {
                this.view.destroy();
            }
            if (this.popperRef) {
                this.popperRef.destroy();
            }
            this.view = null;
            this.popperRef = null;
            this.currentDropdown = null;
            this.isClosing = false;
        }, 300);
        this.isOpen.set(false);
    }
    onClick(event, targetElement) {
        if (!targetElement || !this.origin) {
            return;
        }
        const originBbox = this.origin.nativeElement.getBoundingClientRect();
        const dropdownBbox = this.view?.rootNodes?.[0]?.getBoundingClientRect();
        if (!dropdownBbox || !originBbox) {
            return;
        }
        const clickedInsideOrigin = event.clientX >= originBbox.left &&
            event.clientX <= originBbox.right &&
            event.clientY >= originBbox.top &&
            event.clientY <= originBbox.bottom;
        const clickedInsideDropdown = event.clientX >= dropdownBbox.left &&
            event.clientX <= dropdownBbox.right &&
            event.clientY >= dropdownBbox.top &&
            event.clientY <= dropdownBbox.bottom;
        if (!clickedInsideOrigin && !clickedInsideDropdown) {
            this.close();
        }
    }
    ngOnChanges(changes) {
        if (changes['model'] && this.combinedOptions()) {
            this.updateToggleLabel();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSelectComponent, deps: [{ token: i0.ViewContainerRef }, { token: i1.OuiSelectService }, { token: i0.DestroyRef }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiSelectComponent, isStandalone: true, selector: "oui-select", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null }, isOpen: { classPropertyName: "isOpen", publicName: "isOpen", isSignal: true, isRequired: false, transformFunction: null }, items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: true, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: false, isRequired: false, transformFunction: null }, model: { classPropertyName: "model", publicName: "model", isSignal: false, isRequired: false, transformFunction: null }, template: { classPropertyName: "template", publicName: "template", isSignal: false, isRequired: false, transformFunction: null } }, outputs: { isOpen: "isOpenChange", modelChange: "modelChange", closed: "closed" }, host: { listeners: { "document:click": "onClick($event,$event.target)" } }, viewQueries: [{ propertyName: "dropdownContent", first: true, predicate: ["dropdown"], descendants: true }, { propertyName: "origin", first: true, predicate: ["origin"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div\n  class=\"oui-select-container {{ combinedOptions().type }}\"\n  id=\"{{ id }}\"\n  [ngClass]=\"{ active: isOpen(), disabled: disabled }\"\n  >\n  <div class=\"oui-select-toggle\" (click)=\"toggle()\" #origin>\n    <span>{{ selectToggleLabel() }}</span>\n    <div class=\"oui-select-toggle-caret pointer-events-none\">\n      @if (!isOpen()) {\n        <oui-icon\n          icon=\"assets/icons/caret_down.svg\"\n        [options]=\"{\n          strokeColor: 'oui-select-toggle-text-color',\n          fillColor: 'oui-select-toggle-text-color'\n        }\"\n        ></oui-icon>\n      }\n      @if (isOpen()) {\n        <oui-icon\n          icon=\"assets/icons/caret_up.svg\"\n        [options]=\"{\n          strokeColor: 'oui-select-toggle-text-color',\n          fillColor: 'oui-select-toggle-text-color'\n        }\"\n        ></oui-icon>\n      }\n    </div>\n  </div>\n  <ng-template #dropdown>\n    <div class=\"oui-select-content-container\" id=\"{{ id }}\">\n      @if (combinedOptions().search?.isEnabled) {\n        <div class=\"oui-select-search\">\n          <oui-input\n            ouiAutofocus\n            [isAutofocusEnabled]=\"!!combinedOptions().search?.isFocusedOnOpen\"\n            #searchInput\n            [options]=\"{\n              variant: 'underlined',\n              endIcon: {\n                icon: 'assets/icons/search.svg',\n                options: {\n                  fillColor: 'oui-select-search-icon-color',\n                  strokeColor: 'oui-select-search-icon-color',\n                  size: '1.8rem'\n                }\n              }\n            }\"\n            [model]=\"searchValue()\"\n            (modelChange)=\"searchValue.set($event)\"\n          ></oui-input>\n        </div>\n      }\n\n  <div\n    class=\"content oui-scrollbar oui-scrollbar-auto\"\n    >\n    @if (!filteredItems().length) {\n      <div>No results found...</div>\n    }\n\n    @for(item of filteredItems(); track item) {\n      <div\n        (click)=\"select(item)\"\n      >\n        @if (!template) {\n          <div\n            class=\"oui-select-option-container\"\n            [ngClass]=\"{\n                active:\n                  item | isSelectItemActive: this.model : combinedOptions().idKey,\n                candidateForSelection:\n                  combinedOptions().isSelectingWithKeyboardActive && $index === candidateForSelectionIndex()\n              }\"\n          >\n            <div class=\"option-label\">\n              {{ item | selectItemLabel: combinedOptions().labelKey }}\n            </div>\n            @if (\n              item | isSelectItemActive: this.model : combinedOptions().idKey\n              ) {\n              <div\n                class=\"option-active-icon\"\n              >\n                <oui-icon\n                  icon=\"assets/icons/check.svg\"\n                  [options]=\"{\n                    fillColor: 'oui-select-content-text',\n                    strokeColor: 'oui-select-content-text',\n                    size: '18px'\n                  }\"\n                ></oui-icon>\n              </div>\n            }\n          </div>\n        }\n\n        <ng-template\n          *ngTemplateOutlet=\"template; context: { $implicit: item, item: item }\"\n        >\n        </ng-template>\n      </div>\n    }\n\n  </div>\n</div>\n</ng-template>\n</div>\n", styles: [":host{height:100%;width:100%;position:relative}:host .oui-select-container{display:flex;border-style:var(--oui-select-border-style);border-width:var(--oui-select-border-width);border-color:var(--oui-select-border-color);height:100%;width:100%}:host .oui-select-container.disabled{opacity:.4;pointer-events:none;cursor:default}:host .oui-select-container.underlined{border:none;border-bottom:var(--oui-select-border-width) var(--oui-select-border-style) var(--oui-select-border-color)}:host .oui-select-container.active{border-color:var(--oui-select-border-color-active);box-shadow:0 0 1px 1px #00000017}:host .oui-select-container .oui-select-toggle{background:var(--oui-select-toggle-background);color:var(--oui-select-toggle-text-color);width:100%;display:flex;justify-content:space-between;align-items:center;padding:2px 4px}:host .oui-select-container .oui-select-toggle:hover{cursor:pointer}:host .oui-select-container .oui-select-toggle .oui-select-toggle-caret{height:100%;display:flex;justify-content:center;align-items:center}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: ScrollingModule }, { kind: "pipe", type: IsSelectItemActivePipe, name: "isSelectItemActive" }, { kind: "pipe", type: SelectItemLabelPipe, name: "selectItemLabel" }, { kind: "component", type: OuiInputComponent, selector: "oui-input", inputs: ["model", "options"], outputs: ["modelChange", "hasErrorChange"] }, { kind: "directive", type: AutofocusDirective, selector: "[ouiAutofocus]", inputs: ["isAutofocusEnabled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-select', standalone: true, imports: [
                        OuiIconComponent,
                        OuiButtonComponent,
                        CommonModule,
                        ScrollingModule,
                        IsSelectItemActivePipe,
                        SelectItemLabelPipe,
                        OuiInputComponent,
                        AutofocusDirective,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"oui-select-container {{ combinedOptions().type }}\"\n  id=\"{{ id }}\"\n  [ngClass]=\"{ active: isOpen(), disabled: disabled }\"\n  >\n  <div class=\"oui-select-toggle\" (click)=\"toggle()\" #origin>\n    <span>{{ selectToggleLabel() }}</span>\n    <div class=\"oui-select-toggle-caret pointer-events-none\">\n      @if (!isOpen()) {\n        <oui-icon\n          icon=\"assets/icons/caret_down.svg\"\n        [options]=\"{\n          strokeColor: 'oui-select-toggle-text-color',\n          fillColor: 'oui-select-toggle-text-color'\n        }\"\n        ></oui-icon>\n      }\n      @if (isOpen()) {\n        <oui-icon\n          icon=\"assets/icons/caret_up.svg\"\n        [options]=\"{\n          strokeColor: 'oui-select-toggle-text-color',\n          fillColor: 'oui-select-toggle-text-color'\n        }\"\n        ></oui-icon>\n      }\n    </div>\n  </div>\n  <ng-template #dropdown>\n    <div class=\"oui-select-content-container\" id=\"{{ id }}\">\n      @if (combinedOptions().search?.isEnabled) {\n        <div class=\"oui-select-search\">\n          <oui-input\n            ouiAutofocus\n            [isAutofocusEnabled]=\"!!combinedOptions().search?.isFocusedOnOpen\"\n            #searchInput\n            [options]=\"{\n              variant: 'underlined',\n              endIcon: {\n                icon: 'assets/icons/search.svg',\n                options: {\n                  fillColor: 'oui-select-search-icon-color',\n                  strokeColor: 'oui-select-search-icon-color',\n                  size: '1.8rem'\n                }\n              }\n            }\"\n            [model]=\"searchValue()\"\n            (modelChange)=\"searchValue.set($event)\"\n          ></oui-input>\n        </div>\n      }\n\n  <div\n    class=\"content oui-scrollbar oui-scrollbar-auto\"\n    >\n    @if (!filteredItems().length) {\n      <div>No results found...</div>\n    }\n\n    @for(item of filteredItems(); track item) {\n      <div\n        (click)=\"select(item)\"\n      >\n        @if (!template) {\n          <div\n            class=\"oui-select-option-container\"\n            [ngClass]=\"{\n                active:\n                  item | isSelectItemActive: this.model : combinedOptions().idKey,\n                candidateForSelection:\n                  combinedOptions().isSelectingWithKeyboardActive && $index === candidateForSelectionIndex()\n              }\"\n          >\n            <div class=\"option-label\">\n              {{ item | selectItemLabel: combinedOptions().labelKey }}\n            </div>\n            @if (\n              item | isSelectItemActive: this.model : combinedOptions().idKey\n              ) {\n              <div\n                class=\"option-active-icon\"\n              >\n                <oui-icon\n                  icon=\"assets/icons/check.svg\"\n                  [options]=\"{\n                    fillColor: 'oui-select-content-text',\n                    strokeColor: 'oui-select-content-text',\n                    size: '18px'\n                  }\"\n                ></oui-icon>\n              </div>\n            }\n          </div>\n        }\n\n        <ng-template\n          *ngTemplateOutlet=\"template; context: { $implicit: item, item: item }\"\n        >\n        </ng-template>\n      </div>\n    }\n\n  </div>\n</div>\n</ng-template>\n</div>\n", styles: [":host{height:100%;width:100%;position:relative}:host .oui-select-container{display:flex;border-style:var(--oui-select-border-style);border-width:var(--oui-select-border-width);border-color:var(--oui-select-border-color);height:100%;width:100%}:host .oui-select-container.disabled{opacity:.4;pointer-events:none;cursor:default}:host .oui-select-container.underlined{border:none;border-bottom:var(--oui-select-border-width) var(--oui-select-border-style) var(--oui-select-border-color)}:host .oui-select-container.active{border-color:var(--oui-select-border-color-active);box-shadow:0 0 1px 1px #00000017}:host .oui-select-container .oui-select-toggle{background:var(--oui-select-toggle-background);color:var(--oui-select-toggle-text-color);width:100%;display:flex;justify-content:space-between;align-items:center;padding:2px 4px}:host .oui-select-container .oui-select-toggle:hover{cursor:pointer}:host .oui-select-container .oui-select-toggle .oui-select-toggle-caret{height:100%;display:flex;justify-content:center;align-items:center}\n"] }]
        }], ctorParameters: () => [{ type: i0.ViewContainerRef }, { type: i1.OuiSelectService }, { type: i0.DestroyRef }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { disabled: [{
                type: Input
            }], model: [{
                type: Input
            }], template: [{
                type: Input
            }], modelChange: [{
                type: Output
            }], closed: [{
                type: Output
            }], dropdownContent: [{
                type: ViewChild,
                args: ['dropdown']
            }], origin: [{
                type: ViewChild,
                args: ['origin']
            }], onClick: [{
                type: HostListener,
                args: ['document:click', ['$event', '$event.target']]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VsZWN0LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvc2VsZWN0L3NlbGVjdC1jb21wb25lbnQvc2VsZWN0LmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvc2VsZWN0L3NlbGVjdC1jb21wb25lbnQvc2VsZWN0LmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFFTCx1QkFBdUIsRUFDdkIsaUJBQWlCLEVBQ2pCLFNBQVMsRUFDVCxRQUFRLEVBRVIsTUFBTSxFQUVOLFlBQVksRUFDWixZQUFZLEVBQ1osTUFBTSxFQUNOLE1BQU0sRUFDTixLQUFLLEVBQ0wsS0FBSyxFQUNMLEtBQUssRUFHTCxNQUFNLEVBRU4sTUFBTSxFQUdOLFNBQVMsR0FJVixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFFOUMsT0FBTyxFQUFFLFlBQVksRUFBRSxRQUFRLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUN6RCxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFDekQsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDbkQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFDdkQsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQzFDLE9BQU8sRUFBRSxhQUFhLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxNQUFNLFdBQVcsQ0FBQztBQUN4RCxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUN0RSxPQUFPLEVBQUUsbUJBQW1CLEVBQUUsTUFBTSwwQkFBMEIsQ0FBQztBQUMvRCxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQztBQUNyRCxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUNoRSxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUMxRCxPQUFPLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxNQUFNLENBQUM7Ozs7QUFnQ3JEOzs7Ozs7R0FNRztBQWtCSCxNQUFNLE9BQU8sa0JBQWtCO0lBK0ZuQjtJQUNBO0lBQ0E7SUFDa0I7SUFqR3BCLEdBQUcsR0FBRyxNQUFNLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUN4Qzs7OztPQUlHO0lBQ0ksT0FBTyxHQUFHLEtBQUssRUFBb0IsQ0FBQztJQUVwQyxNQUFNLEdBQUcsS0FBSyxDQUFVLEtBQUssQ0FBQyxDQUFDO0lBRXRDOzs7O09BSUc7SUFFSSxLQUFLLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBUyxDQUFDO0lBRTlCLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFFMUI7O09BRUc7SUFDTSxLQUFLLENBQU07SUFFcEI7OztPQUdHO0lBQ00sUUFBUSxDQUEwQjtJQUUzQzs7T0FFRztJQUNPLFdBQVcsR0FBRyxJQUFJLFlBQVksRUFBRSxDQUFDO0lBRTNDOztPQUVHO0lBQ08sTUFBTSxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7SUFFZixlQUFlLENBQW1CO0lBQ3BDLE1BQU0sQ0FBYTtJQUVoQyxjQUFjLEdBQTZCO1FBQ2pELFFBQVEsRUFBRSxPQUFPO1FBQ2pCLEtBQUssRUFBRSxJQUFJO1FBQ1gsVUFBVSxFQUFFLEtBQUs7UUFDakIsTUFBTSxFQUFFO1lBQ04sU0FBUyxFQUFFLEtBQUs7WUFDaEIsZUFBZSxFQUFFLEtBQUs7U0FDdkI7UUFDRCw2QkFBNkIsRUFBRSxLQUFLO1FBQ3BDLElBQUksRUFBRSxVQUFVO1FBQ2hCLFlBQVksRUFBRSxFQUFFO1FBQ2hCLGNBQWMsRUFBRSxDQUFDLElBQVMsRUFBRSxFQUFFO1lBQzVCLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxRQUFRLENBQUMsSUFBSSxJQUFJLENBQUM7UUFDdkQsQ0FBQztLQUNGLENBQUM7SUFFTSxlQUFlLENBQU07SUFDckIsT0FBTyxHQUFHLElBQUksT0FBTyxFQUFXLENBQUM7SUFFbEMsZUFBZSxHQUFHLFFBQVEsQ0FBQyxHQUFHLEVBQUU7UUFDckMsT0FBTyxLQUFLLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQyxjQUFjLEVBQUUsRUFBRSxFQUFFLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQztJQUNsRSxDQUFDLENBQUMsQ0FBQztJQUNJLElBQUksQ0FBTTtJQUNWLFNBQVMsQ0FBTTtJQUNmLFNBQVMsR0FBRyxLQUFLLENBQUM7SUFDbEIsRUFBRSxHQUFHLElBQUksRUFBRSxDQUFDO0lBQ1osY0FBYyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMvQixpQkFBaUIsR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDL0IsV0FBVyxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUN6QixRQUFRLEdBQUcsUUFBUSxDQUFDLEdBQUcsRUFBRTtRQUM5QixPQUFPLElBQUksQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLEtBQUssQ0FBQztZQUN0RCxDQUFDLENBQUMsUUFBUTtZQUNWLENBQUMsQ0FBQyxRQUFRLENBQUM7SUFDZixDQUFDLENBQUMsQ0FBQztJQUVJLDBCQUEwQixHQUFHLE1BQU0sQ0FBUyxDQUFDLENBQUMsQ0FBQztJQUMvQyxhQUFhLEdBQUcsUUFBUSxDQUFDLEdBQUcsRUFBRTtRQUNuQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsQ0FBQztZQUM5QyxPQUFPLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQztRQUMzQixDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2hDLE1BQU0sS0FBSyxHQUNULElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxRQUFRLElBQUksYUFBYSxDQUFDLElBQUksQ0FBQztnQkFDcEQsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsUUFBUSxDQUFDO2dCQUN2QyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBQ1gsT0FBTyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBQ3hFLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQyxDQUFDLENBQUM7SUFFSCxZQUNVLEdBQXFCLEVBQ3JCLGdCQUFrQyxFQUNsQyxVQUFzQixFQUNKLFFBQWtCO1FBSHBDLFFBQUcsR0FBSCxHQUFHLENBQWtCO1FBQ3JCLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBa0I7UUFDbEMsZUFBVSxHQUFWLFVBQVUsQ0FBWTtRQUNKLGFBQVEsR0FBUixRQUFRLENBQVU7UUFFNUMsTUFBTSxDQUNKLEdBQUcsRUFBRTtZQUNILE1BQU0seUJBQXlCLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLGNBQWMsQ0FBQztZQUN4RSxJQUFJLHlCQUF5QixFQUFFLENBQUM7Z0JBQzlCLElBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDLENBQUM7WUFDckQsQ0FBQztZQUNELElBQUksSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUNmLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1lBQzNCLENBQUM7UUFDSCxDQUFDLEVBQ0Q7WUFDRSxpQkFBaUIsRUFBRSxJQUFJO1NBQ3hCLENBQ0YsQ0FBQztJQUNKLENBQUM7SUFDTSxlQUFlO1FBQ3BCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDckMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFFekIsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUM7Z0JBQ2xCLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUNkLENBQUM7UUFDSCxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDVixDQUFDO0lBRUQsSUFBSSxLQUFLO1FBQ1AsSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDbkMsT0FBTyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3BCLENBQUM7YUFBTSxJQUFJLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUMzQyxPQUFPLElBQUksQ0FBQyxLQUFLO2dCQUNmLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxRQUFRLENBQUM7Z0JBQzdDLENBQUMsQ0FBQyxXQUFXLENBQUM7UUFDbEIsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLENBQUMsS0FBSyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7WUFDbEQsT0FBTyxFQUFFLENBQUM7UUFDWixDQUFDO0lBQ0gsQ0FBQztJQUVNLE1BQU0sQ0FBQyxNQUFXO1FBQ3ZCLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ3RDLE1BQU0sVUFBVSxHQUNkLElBQUksQ0FBQyxRQUFRLEVBQUUsS0FBSyxRQUFRO2dCQUMxQixDQUFDLENBQUMsQ0FBQyxJQUFTLEVBQUUsRUFBRSxDQUFDLElBQUk7Z0JBQ3JCLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsS0FBSyxDQUFDO1lBQ25DLElBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQyxNQUFNLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztRQUN2RCxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksbUJBQW1CLEdBQUcsS0FBSyxDQUFDO1lBQ2hDLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRSxLQUFLLFFBQVEsRUFBRSxDQUFDO2dCQUNqQyxtQkFBbUIsR0FBRyxJQUFJLENBQUMsS0FBSyxLQUFLLE1BQU0sQ0FBQztZQUM5QyxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sbUJBQW1CO29CQUNqQixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLEtBQUssQ0FBQzt3QkFDMUMsTUFBTSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN6QyxDQUFDO1lBQ0QsSUFBSSxtQkFBbUIsRUFBRSxDQUFDO2dCQUN4QixJQUFJLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQztZQUN6QixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sSUFBSSxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUM7WUFDdEIsQ0FBQztZQUNELElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNmLENBQUM7UUFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbEMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVPLGlCQUFpQjtRQUN2QixJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7UUFDZixJQUFJLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUN0QyxLQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMzRSxDQUFDO2FBQU0sQ0FBQztZQUNOLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSztnQkFDaEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztnQkFDbkQsQ0FBQyxDQUFDLEVBQUUsQ0FBQztRQUNULENBQUM7UUFDRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFFTSxJQUFJO1FBQ1QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdEIsSUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUM5RCxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRTlDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDckQsSUFBSSxDQUFDLGVBQWUsQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsV0FBVyxJQUFJLENBQUM7UUFDaEYsSUFBSSxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzNDLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsQ0FBQztZQUM3QyxJQUFJLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDbkQsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDMUUsQ0FBQztRQUNELElBQUksQ0FBQyxTQUFTLEdBQUcsWUFBWSxDQUMzQixJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFDekIsSUFBSSxDQUFDLGVBQWUsRUFDcEI7WUFDRSxTQUFTLEVBQUUsY0FBYztZQUN6QixTQUFTLEVBQUU7Z0JBQ1Q7b0JBQ0UsSUFBSSxFQUFFLGlCQUFpQjtvQkFDdkIsT0FBTyxFQUFFO3dCQUNQLE9BQU8sRUFBRSxJQUFJO3dCQUNiLE9BQU8sRUFBRSxDQUFDO3FCQUNYO2lCQUNGO2FBQ0Y7U0FDRixDQUNGLENBQUM7UUFFRixNQUFNLFFBQVEsR0FBRyxJQUFJLGNBQWMsQ0FBQyxHQUFHLEVBQUU7WUFDdkMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUMxQixDQUFDLENBQUMsQ0FBQztRQUNILFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBRXZDLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxTQUFTLENBQUM7YUFDckMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ2xFLFNBQVMsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQ3hCLElBQ0UsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLDZCQUE2QjtnQkFDcEQsS0FBSyxDQUFDLEdBQUcsS0FBSyxPQUFPLEVBQ3JCLENBQUM7Z0JBQ0QsS0FBSyxDQUFDLGNBQWMsRUFBRSxDQUFDO2dCQUN2QixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7Z0JBQ3hCLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLElBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDLENBQUMsQ0FBQztnQkFDckUsSUFBSSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxVQUFVLEVBQUUsQ0FBQztvQkFDdkMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO2dCQUNmLENBQUM7WUFDSCxDQUFDO1lBQ0QsSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLFFBQVEsRUFBRSxDQUFDO2dCQUMzQixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDZixDQUFDO1lBQ0QsSUFDRSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsNkJBQTZCO2dCQUNwRCxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssV0FBVyxJQUFJLEtBQUssQ0FBQyxHQUFHLEtBQUssU0FBUyxDQUFDLEVBQ3RELENBQUM7Z0JBQ0QsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO2dCQUN4QixLQUFLLENBQUMsY0FBYyxFQUFFLENBQUM7Z0JBQ3ZCLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsRUFBRSxNQUFNLENBQUM7Z0JBRWhELElBQUksS0FBSyxDQUFDLEdBQUcsS0FBSyxXQUFXLEVBQUUsQ0FBQztvQkFDOUIsTUFBTSxRQUFRLEdBQ1osSUFBSSxDQUFDLDBCQUEwQixFQUFFLEdBQUcsQ0FBQyxJQUFJLFVBQVU7d0JBQ2pELENBQUMsQ0FBQyxDQUFDO3dCQUNILENBQUMsQ0FBQyxJQUFJLENBQUMsMEJBQTBCLEVBQUUsR0FBRyxDQUFDLENBQUM7b0JBQzVDLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ2hELENBQUM7cUJBQU0sQ0FBQztvQkFDTixNQUFNLFFBQVEsR0FDWixJQUFJLENBQUMsMEJBQTBCLEVBQUUsR0FBRyxDQUFDLEdBQUcsQ0FBQzt3QkFDdkMsQ0FBQyxDQUFDLFVBQVUsR0FBRyxDQUFDO3dCQUNoQixDQUFDLENBQUMsSUFBSSxDQUFDLDBCQUEwQixFQUFFLEdBQUcsQ0FBQyxDQUFDO29CQUM1QyxJQUFJLENBQUMsMEJBQTBCLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUNoRCxDQUFDO1lBQ0gsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO1FBRUwsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksSUFBSSxDQUFDLGVBQWUsSUFBSSxRQUFRLEVBQUUsQ0FBQztnQkFDckMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7WUFDM0MsQ0FBQztRQUNILENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNULFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDZCxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLE1BQU07UUFDWCxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNuQixPQUFPO1FBQ1QsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRSxFQUFFLENBQUM7WUFDbEIsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2YsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDZCxDQUFDO0lBQ0gsQ0FBQztJQUVNLEtBQUs7UUFDVixJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztRQUN0QixJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO1FBRW5CLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3pCLElBQUksQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNoRCxDQUFDO1FBRUQsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNkLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDdEIsQ0FBQztZQUNELElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO2dCQUNuQixJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQzNCLENBQUM7WUFDRCxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztZQUNqQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztZQUN0QixJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksQ0FBQztZQUM1QixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN6QixDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDUixJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN6QixDQUFDO0lBR00sT0FBTyxDQUFDLEtBQWlCLEVBQUUsYUFBMEI7UUFDMUQsSUFBSSxDQUFDLGFBQWEsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNuQyxPQUFPO1FBQ1QsQ0FBQztRQUNELE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDckUsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxxQkFBcUIsRUFBRSxDQUFDO1FBQ3hFLElBQUksQ0FBQyxZQUFZLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNqQyxPQUFPO1FBQ1QsQ0FBQztRQUVELE1BQU0sbUJBQW1CLEdBQ3ZCLEtBQUssQ0FBQyxPQUFPLElBQUksVUFBVSxDQUFDLElBQUk7WUFDaEMsS0FBSyxDQUFDLE9BQU8sSUFBSSxVQUFVLENBQUMsS0FBSztZQUNqQyxLQUFLLENBQUMsT0FBTyxJQUFJLFVBQVUsQ0FBQyxHQUFHO1lBQy9CLEtBQUssQ0FBQyxPQUFPLElBQUksVUFBVSxDQUFDLE1BQU0sQ0FBQztRQUNyQyxNQUFNLHFCQUFxQixHQUN6QixLQUFLLENBQUMsT0FBTyxJQUFJLFlBQVksQ0FBQyxJQUFJO1lBQ2xDLEtBQUssQ0FBQyxPQUFPLElBQUksWUFBWSxDQUFDLEtBQUs7WUFDbkMsS0FBSyxDQUFDLE9BQU8sSUFBSSxZQUFZLENBQUMsR0FBRztZQUNqQyxLQUFLLENBQUMsT0FBTyxJQUFJLFlBQVksQ0FBQyxNQUFNLENBQUM7UUFFdkMsSUFBSSxDQUFDLG1CQUFtQixJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztZQUNuRCxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDZixDQUFDO0lBQ0gsQ0FBQztJQUVNLFdBQVcsQ0FBQyxPQUFzQjtRQUN2QyxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLEVBQUUsQ0FBQztZQUMvQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUMzQixDQUFDO0lBQ0gsQ0FBQzt1R0EzVVUsa0JBQWtCLDRHQWtHbkIsUUFBUTsyRkFsR1Asa0JBQWtCLG1yQ0NqRy9CLHV4R0EyR0EsdWtDRHJCSSxnQkFBZ0IsaUZBRWhCLFlBQVksbVNBQ1osZUFBZSwwQkFDZixzQkFBc0Isc0RBQ3RCLG1CQUFtQix3REFDbkIsaUJBQWlCLGdJQUNqQixrQkFBa0I7OzJGQUlULGtCQUFrQjtrQkFqQjlCLFNBQVM7K0JBQ0UsWUFBWSxjQUdWLElBQUksV0FDUDt3QkFDUCxnQkFBZ0I7d0JBQ2hCLGtCQUFrQjt3QkFDbEIsWUFBWTt3QkFDWixlQUFlO3dCQUNmLHNCQUFzQjt3QkFDdEIsbUJBQW1CO3dCQUNuQixpQkFBaUI7d0JBQ2pCLGtCQUFrQjtxQkFDbkIsbUJBQ2dCLHVCQUF1QixDQUFDLE1BQU07OzBCQW9HNUMsTUFBTTsyQkFBQyxRQUFRO3lDQS9FVCxRQUFRO3NCQUFoQixLQUFLO2dCQUtHLEtBQUs7c0JBQWIsS0FBSztnQkFNRyxRQUFRO3NCQUFoQixLQUFLO2dCQUtJLFdBQVc7c0JBQXBCLE1BQU07Z0JBS0csTUFBTTtzQkFBZixNQUFNO2dCQUVnQixlQUFlO3NCQUFyQyxTQUFTO3VCQUFDLFVBQVU7Z0JBQ0EsTUFBTTtzQkFBMUIsU0FBUzt1QkFBQyxRQUFRO2dCQWtRWixPQUFPO3NCQURiLFlBQVk7dUJBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxRQUFRLEVBQUUsZUFBZSxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIENoYW5nZURldGVjdG9yUmVmLFxuICBDb21wb25lbnQsXG4gIGNvbXB1dGVkLFxuICBEZXN0cm95UmVmLFxuICBlZmZlY3QsXG4gIEVsZW1lbnRSZWYsXG4gIEV2ZW50RW1pdHRlcixcbiAgSG9zdExpc3RlbmVyLFxuICBpbmplY3QsXG4gIEluamVjdCxcbiAgaW5wdXQsXG4gIElucHV0LFxuICBtb2RlbCxcbiAgTmdab25lLFxuICBPbkNoYW5nZXMsXG4gIE91dHB1dCxcbiAgUXVlcnlMaXN0LFxuICBzaWduYWwsXG4gIFNpbXBsZUNoYW5nZXMsXG4gIFRlbXBsYXRlUmVmLFxuICBWaWV3Q2hpbGQsXG4gIFZpZXdDaGlsZHJlbixcbiAgVmlld0NvbnRhaW5lclJlZixcbiAgV3JpdGFibGVTaWduYWwsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgY3JlYXRlUG9wcGVyIH0gZnJvbSAnQHBvcHBlcmpzL2NvcmUnO1xuaW1wb3J0IHsgT3VpU2VsZWN0U2VydmljZSB9IGZyb20gJy4uL3NlbGVjdC5zZXJ2aWNlJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSwgRE9DVU1FTlQgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgU2Nyb2xsaW5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY2RrL3Njcm9sbGluZyc7XG5pbXBvcnQgeyBPdWlJY29uQ29tcG9uZW50IH0gZnJvbSAnb3JiaXRhbC11aS9pY29uJztcbmltcG9ydCB7IE91aUJ1dHRvbkNvbXBvbmVudCB9IGZyb20gJ29yYml0YWwtdWkvYnV0dG9uJztcbmltcG9ydCB7IEdVSUQgfSBmcm9tICdvcmJpdGFsLXVpL2hlbHBlcnMnO1xuaW1wb3J0IHsgaXNQbGFpbk9iamVjdCwgbWVyZ2UsIHhvckJ5IH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IElzU2VsZWN0SXRlbUFjdGl2ZVBpcGUgfSBmcm9tICcuL2lzLXNlbGVjdC1pdGVtLWFjdGl2ZS5waXBlJztcbmltcG9ydCB7IFNlbGVjdEl0ZW1MYWJlbFBpcGUgfSBmcm9tICcuL3NlbGVjdC1pdGVtLWxhYmVsLnBpcGUnO1xuaW1wb3J0IHsgT3VpSW5wdXRDb21wb25lbnQgfSBmcm9tICdvcmJpdGFsLXVpL2lucHV0JztcbmltcG9ydCB7IHRha2VVbnRpbERlc3Ryb3llZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUvcnhqcy1pbnRlcm9wJztcbmltcG9ydCB7IEF1dG9mb2N1c0RpcmVjdGl2ZSB9IGZyb20gJ29yYml0YWwtdWkvYXV0b2ZvY3VzJztcbmltcG9ydCB7IGZyb21FdmVudCwgU3ViamVjdCwgdGFrZVVudGlsIH0gZnJvbSAncnhqcyc7XG5cbmV4cG9ydCB0eXBlIE91aVNlbGVjdE9wdGlvbnMgPSB7XG4gIGxhYmVsS2V5Pzogc3RyaW5nO1xuICBpZEtleT86IHN0cmluZztcbiAgdHlwZT86ICdzdGFuZGFyZCcgfCAndW5kZXJsaW5lZCc7XG4gIGlzTXVsdGlwbGU/OiBib29sZWFuO1xuICBzZWFyY2g/OiB7XG4gICAgaXNFbmFibGVkOiBib29sZWFuO1xuICAgIGlzRm9jdXNlZE9uT3Blbj86IGJvb2xlYW47XG4gIH07XG4gIGNvbnRlbnRDbGFzcz86IHN0cmluZztcbiAgZ2V0VG9nZ2xlTGFiZWw/OiAoaXRlbTogYW55KSA9PiBzdHJpbmc7XG4gIGRyb3Bkb3duSGVpZ2h0Pzogc3RyaW5nO1xuICBpc1NlbGVjdGluZ1dpdGhLZXlib2FyZEFjdGl2ZT86IGJvb2xlYW47XG59O1xuXG50eXBlIE91aVNlbGVjdENvbWJpbmVkT3B0aW9ucyA9IHtcbiAgbGFiZWxLZXk6IHN0cmluZztcbiAgaWRLZXk6IHN0cmluZztcbiAgdHlwZT86ICdzdGFuZGFyZCcgfCAndW5kZXJsaW5lZCc7XG4gIGlzTXVsdGlwbGU6IGJvb2xlYW47XG4gIHNlYXJjaD86IHtcbiAgICBpc0VuYWJsZWQ6IGJvb2xlYW47XG4gICAgaXNGb2N1c2VkT25PcGVuPzogYm9vbGVhbjtcbiAgfTtcbiAgaXNTZWxlY3RpbmdXaXRoS2V5Ym9hcmRBY3RpdmU6IGJvb2xlYW47XG4gIGNvbnRlbnRDbGFzczogc3RyaW5nO1xuICBnZXRUb2dnbGVMYWJlbDogKGl0ZW06IGFueSkgPT4gc3RyaW5nO1xuICBkcm9wZG93bkhlaWdodD86IHN0cmluZztcbn07XG5cbi8qKlxuICogQ29tcG9uZW50IHRoYXQgY2FuIGJlIHVzZWQgdG8gY3JlYXRlIHNlbGVjdC1kcm9wZG93bnMuWW91IGNhbiBlaXRoZXIgcGFzcyBzaW1wbGUgc3RyaW5ncyBpbiBhbiBhcnJheSBhcyB0aGUgb3B0aW9ucyB0byBjaG9vc2UgZnJvbSxcbiAqIG9yIGFsdGVybmF0aXZlbHkgcGFzcyBpbiBvYmplY3RzIHdpdGggYW4gYWRkaXRpb25hbGx5IGRlZmluZWQgbGFiZWwta2V5IGFuZCBpZC1rZXkuXG4gKlxuICogRXhhbXBsZSB1c2U6XG4gKiA8b3VpLXNlbGVjdCBbKG1vZGVsKV09XCJzZWxlY3RlZEl0ZW1cIiBbaWRLZXldPVwiJ3ZhbHVlJ1wiIFtsYWJlbEtleV09XCInbmFtZSdcIiBbb3B0aW9uc109XCJzZWxlY3RWYWx1ZXNcIj48L291aS1zZWxlY3Q+XG4gKi9cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1zZWxlY3QnLFxuICB0ZW1wbGF0ZVVybDogJy4vc2VsZWN0LmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vc2VsZWN0LmNvbXBvbmVudC5zY3NzJ10sXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtcbiAgICBPdWlJY29uQ29tcG9uZW50LFxuICAgIE91aUJ1dHRvbkNvbXBvbmVudCxcbiAgICBDb21tb25Nb2R1bGUsXG4gICAgU2Nyb2xsaW5nTW9kdWxlLFxuICAgIElzU2VsZWN0SXRlbUFjdGl2ZVBpcGUsXG4gICAgU2VsZWN0SXRlbUxhYmVsUGlwZSxcbiAgICBPdWlJbnB1dENvbXBvbmVudCxcbiAgICBBdXRvZm9jdXNEaXJlY3RpdmUsXG4gIF0sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlTZWxlY3RDb21wb25lbnQgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0LCBPbkNoYW5nZXMge1xuICBwcml2YXRlIGNkciA9IGluamVjdChDaGFuZ2VEZXRlY3RvclJlZik7XG4gIC8qKlxuICAgKiAgIGxhYmVsS2V5ICAgICAgIC0gVGhlIGtleSBpbiBlYWNoIG9iamVjdCB0aGF0J3MgdXNlZCB0byBkaXNwbGF5IGEgdGV4dCBpbiB0aGUgZHJvcGRvd24uXG4gICAqICAgaWRLZXkgICAgICAgICAgLSBUaGUga2V5IGluIGVhY2ggb2JqZWN0IHRoYXQgaXMgdXNlZCB0byBkZWZpbmUgd2hpY2ggaXRlbSBpcyBzZWxlY3RlZC4gRXNzZW50aWFsbHkgdGhlIGtleSBpbiBlYWNoIG9iamVjdCB3aGljaCBzaG91bGQgYmUgdXNlZCB0byBkaWZmZXJlbnRpYXRlIGVhY2ggaXRtZSBmcm9tIGVhY2ggb3RoZXIgaXRlbS5cbiAgICogICB0eXBlOiAgICAgICAgICAtIFRoZSB0eXBlIG9mIHRoZSBzZWxlY3QuIENhbiBiZSBlaXRoZXIgJ3N0YW5kYXJkJyBvciAndW5kZXJsaW5lZCcuIERlZmF1bHRzIHRvICdzdGFuZGFyZCdcbiAgICovXG4gIHB1YmxpYyBvcHRpb25zID0gaW5wdXQ8T3VpU2VsZWN0T3B0aW9ucz4oKTtcblxuICBwdWJsaWMgaXNPcGVuID0gbW9kZWw8Ym9vbGVhbj4oZmFsc2UpO1xuXG4gIC8qKlxuICAgKiAgIFRoZSBvcHRpb25zIHRoZSB1c2VyIGNhbiBjaG9vc2UgZnJvbSBpbiB0aGUgZHJvcGRvd24uIElmIGdpdmVuIGEgbGlzdCBvZiBzdHJpbmdzLCBzaW1wbHkgc2hvd3MgdGhvc2Ugc3RyaW5ncywgYW5kIGJpbmRzXG4gICAqICAgdGhlIG1vZGVsIHRvIHRoZSBzZWxlY3RlZCBzdHJpbmcuIElmIGdpdmVuIGFuIGFycmF5IG9mIG9iamVjdHMsIGFsc28gbmVlZCB0byBwYXNzIGluIGEgbGFiZWxLZXkgYW5kIGFuZCBpZEtleSAtaW5wdXRcbiAgICogICAoYWx0aG91Z2ggdGhleSBhcmUgYnkgZGVmYXVsdCAnbGFiZWwnIGFuZCAnaWQnKS5cbiAgICovXG5cbiAgcHVibGljIGl0ZW1zID0gaW5wdXQucmVxdWlyZWQ8YW55W10+KCk7XG5cbiAgQElucHV0KCkgZGlzYWJsZWQgPSBmYWxzZTtcblxuICAvKipcbiAgICogICBUaGUgbW9kZWwgdGhhdCdzIGJvdW5kIHRvIHRoZSBzZWxlY3RlZCBpdGVtXG4gICAqL1xuICBASW5wdXQoKSBtb2RlbDogYW55O1xuXG4gIC8qKlxuICAgKiAgIEEgdGVtcGxhdGUgdGhhdCBzaG91bGQgYmUgdXNlZCBmb3IgZWFjaCBpdGVtLiBJZiBub25lIGlzIGdpdmVuLCB0aGVuIHVzZXMgYSBkZWZhdWx0LiBUaGlzIGNhbiBiZSB1c2VkIGlmIHlvdSBuZWVkXG4gICAqICAgaGVhdmlseSBjdXN0b21pemVkIGRyb3Bkb3duLWl0ZW1zXG4gICAqL1xuICBASW5wdXQoKSB0ZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PiB8IG51bGw7XG5cbiAgLyoqXG4gICAqICAgVHJpZ2dlcmVkIHdoZW4gbW9kZWwgY2hhbmdlc1xuICAgKi9cbiAgQE91dHB1dCgpIG1vZGVsQ2hhbmdlID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuXG4gIC8qKlxuICAgKiAgIFRyaWdnZXJlZCB3aGVuIGRyb3Bkb3duIGNsb3Nlc1xuICAgKi9cbiAgQE91dHB1dCgpIGNsb3NlZCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICBAVmlld0NoaWxkKCdkcm9wZG93bicpIGRyb3Bkb3duQ29udGVudDogVGVtcGxhdGVSZWY8YW55PjtcbiAgQFZpZXdDaGlsZCgnb3JpZ2luJykgb3JpZ2luOiBFbGVtZW50UmVmO1xuXG4gIHByaXZhdGUgZGVmYXVsdE9wdGlvbnM6IE91aVNlbGVjdENvbWJpbmVkT3B0aW9ucyA9IHtcbiAgICBsYWJlbEtleTogJ2xhYmVsJyxcbiAgICBpZEtleTogJ2lkJyxcbiAgICBpc011bHRpcGxlOiBmYWxzZSxcbiAgICBzZWFyY2g6IHtcbiAgICAgIGlzRW5hYmxlZDogZmFsc2UsXG4gICAgICBpc0ZvY3VzZWRPbk9wZW46IGZhbHNlLFxuICAgIH0sXG4gICAgaXNTZWxlY3RpbmdXaXRoS2V5Ym9hcmRBY3RpdmU6IGZhbHNlLFxuICAgIHR5cGU6ICdzdGFuZGFyZCcsXG4gICAgY29udGVudENsYXNzOiAnJyxcbiAgICBnZXRUb2dnbGVMYWJlbDogKGl0ZW06IGFueSkgPT4ge1xuICAgICAgcmV0dXJuIGl0ZW1bdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5sYWJlbEtleV0gPz8gaXRlbTtcbiAgICB9LFxuICB9O1xuXG4gIHByaXZhdGUgY3VycmVudERyb3Bkb3duOiBhbnk7XG4gIHByaXZhdGUgY2xvc2VkJCA9IG5ldyBTdWJqZWN0PGJvb2xlYW4+KCk7XG5cbiAgcHVibGljIGNvbWJpbmVkT3B0aW9ucyA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICByZXR1cm4gbWVyZ2UoeyAuLi50aGlzLmRlZmF1bHRPcHRpb25zIH0sIHsgLi4udGhpcy5vcHRpb25zKCkgfSk7XG4gIH0pO1xuICBwdWJsaWMgdmlldzogYW55O1xuICBwdWJsaWMgcG9wcGVyUmVmOiBhbnk7XG4gIHB1YmxpYyBpc0Nsb3NpbmcgPSBmYWxzZTtcbiAgcHVibGljIGlkID0gR1VJRCgpO1xuICBwdWJsaWMgZHJvcGRvd25IZWlnaHQgPSBzaWduYWwoJzBweCcpO1xuICBwdWJsaWMgc2VsZWN0VG9nZ2xlTGFiZWwgPSBzaWduYWwoJycpO1xuICBwdWJsaWMgc2VhcmNoVmFsdWUgPSBzaWduYWwoJycpO1xuICBwdWJsaWMgaXRlbVR5cGUgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgcmV0dXJuIHRoaXMuaXRlbXMoKT8uWzBdPy5bdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5pZEtleV1cbiAgICAgID8gJ29iamVjdCdcbiAgICAgIDogJ3NpbXBsZSc7XG4gIH0pO1xuXG4gIHB1YmxpYyBjYW5kaWRhdGVGb3JTZWxlY3Rpb25JbmRleCA9IHNpZ25hbDxudW1iZXI+KDApO1xuICBwdWJsaWMgZmlsdGVyZWRJdGVtcyA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICBpZiAoIXRoaXMuY29tYmluZWRPcHRpb25zKCkuc2VhcmNoPy5pc0VuYWJsZWQpIHtcbiAgICAgIHJldHVybiBbLi4udGhpcy5pdGVtcygpXTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuaXRlbXMoKS5maWx0ZXIoaXRlbSA9PiB7XG4gICAgICBjb25zdCBsYWJlbCA9XG4gICAgICAgIHRoaXMuY29tYmluZWRPcHRpb25zKCkubGFiZWxLZXkgJiYgaXNQbGFpbk9iamVjdChpdGVtKVxuICAgICAgICAgID8gaXRlbVt0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmxhYmVsS2V5XVxuICAgICAgICAgIDogaXRlbTtcbiAgICAgIHJldHVybiBsYWJlbC50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHRoaXMuc2VhcmNoVmFsdWUoKS50b0xvd2VyQ2FzZSgpKTtcbiAgICB9KTtcbiAgfSk7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSB2Y3I6IFZpZXdDb250YWluZXJSZWYsXG4gICAgcHJpdmF0ZSBvdWlTZWxlY3RTZXJ2aWNlOiBPdWlTZWxlY3RTZXJ2aWNlLFxuICAgIHByaXZhdGUgZGVzdHJveVJlZjogRGVzdHJveVJlZixcbiAgICBASW5qZWN0KERPQ1VNRU5UKSBwcml2YXRlIGRvY3VtZW50OiBEb2N1bWVudFxuICApIHtcbiAgICBlZmZlY3QoXG4gICAgICAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGRyb3Bkb3duSGVpZ2h0RnJvbU9wdGlvbnMgPSB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmRyb3Bkb3duSGVpZ2h0O1xuICAgICAgICBpZiAoZHJvcGRvd25IZWlnaHRGcm9tT3B0aW9ucykge1xuICAgICAgICAgIHRoaXMuZHJvcGRvd25IZWlnaHQuc2V0KGRyb3Bkb3duSGVpZ2h0RnJvbU9wdGlvbnMpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLm1vZGVsKSB7XG4gICAgICAgICAgdGhpcy51cGRhdGVUb2dnbGVMYWJlbCgpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAge1xuICAgICAgICBhbGxvd1NpZ25hbFdyaXRlczogdHJ1ZSxcbiAgICAgIH1cbiAgICApO1xuICB9XG4gIHB1YmxpYyBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgdGhpcy5vdWlTZWxlY3RTZXJ2aWNlLnJlZ2lzdGVyKHRoaXMpO1xuICAgIHRoaXMudXBkYXRlVG9nZ2xlTGFiZWwoKTtcblxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgaWYgKHRoaXMuaXNPcGVuKCkpIHtcbiAgICAgICAgdGhpcy5vcGVuKCk7XG4gICAgICB9XG4gICAgfSwgMTAwKTtcbiAgfVxuXG4gIGdldCBsYWJlbCgpIHtcbiAgICBpZiAodHlwZW9mIHRoaXMubW9kZWwgPT09ICdzdHJpbmcnKSB7XG4gICAgICByZXR1cm4gdGhpcy5tb2RlbDtcbiAgICB9IGVsc2UgaWYgKHRoaXMuY29tYmluZWRPcHRpb25zKCkubGFiZWxLZXkpIHtcbiAgICAgIHJldHVybiB0aGlzLm1vZGVsXG4gICAgICAgID8gdGhpcy5tb2RlbFt0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmxhYmVsS2V5XVxuICAgICAgICA6ICdTZWxlY3QuLi4nO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdDb3VsZCBub3QgZ2V0IGxhYmVsIGZvciB0aGUgaXRlbScpO1xuICAgICAgcmV0dXJuICcnO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBzZWxlY3Qob3B0aW9uOiBhbnkpIHtcbiAgICBpZiAodGhpcy5jb21iaW5lZE9wdGlvbnMoKS5pc011bHRpcGxlKSB7XG4gICAgICBjb25zdCBjb21wYXJhdG9yID1cbiAgICAgICAgdGhpcy5pdGVtVHlwZSgpID09PSAnc2ltcGxlJ1xuICAgICAgICAgID8gKGl0ZW06IGFueSkgPT4gaXRlbVxuICAgICAgICAgIDogdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5pZEtleTtcbiAgICAgIHRoaXMubW9kZWwgPSB4b3JCeSh0aGlzLm1vZGVsLCBbb3B0aW9uXSwgY29tcGFyYXRvcik7XG4gICAgfSBlbHNlIHtcbiAgICAgIGxldCBpc0N1cnJlbnRseVNlbGVjdGVkID0gZmFsc2U7XG4gICAgICBpZiAodGhpcy5pdGVtVHlwZSgpID09PSAnc2ltcGxlJykge1xuICAgICAgICBpc0N1cnJlbnRseVNlbGVjdGVkID0gdGhpcy5tb2RlbCA9PT0gb3B0aW9uO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaXNDdXJyZW50bHlTZWxlY3RlZCA9XG4gICAgICAgICAgdGhpcy5tb2RlbD8uW3RoaXMuY29tYmluZWRPcHRpb25zKCkuaWRLZXldID09PVxuICAgICAgICAgIG9wdGlvblt0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmlkS2V5XTtcbiAgICAgIH1cbiAgICAgIGlmIChpc0N1cnJlbnRseVNlbGVjdGVkKSB7XG4gICAgICAgIHRoaXMubW9kZWwgPSB1bmRlZmluZWQ7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLm1vZGVsID0gb3B0aW9uO1xuICAgICAgfVxuICAgICAgdGhpcy5jbG9zZSgpO1xuICAgIH1cbiAgICB0aGlzLm1vZGVsQ2hhbmdlLmVtaXQodGhpcy5tb2RlbCk7XG4gICAgdGhpcy51cGRhdGVUb2dnbGVMYWJlbCgpO1xuICB9XG5cbiAgcHJpdmF0ZSB1cGRhdGVUb2dnbGVMYWJlbCgpIHtcbiAgICBsZXQgbGFiZWwgPSAnJztcbiAgICBpZiAodGhpcy5jb21iaW5lZE9wdGlvbnMoKS5pc011bHRpcGxlKSB7XG4gICAgICBsYWJlbCA9IHRoaXMubW9kZWwubWFwKHRoaXMuY29tYmluZWRPcHRpb25zKCkuZ2V0VG9nZ2xlTGFiZWwpLmpvaW4oJywgJyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGxhYmVsID0gdGhpcy5tb2RlbFxuICAgICAgICA/IHRoaXMuY29tYmluZWRPcHRpb25zKCkuZ2V0VG9nZ2xlTGFiZWwodGhpcy5tb2RlbClcbiAgICAgICAgOiAnJztcbiAgICB9XG4gICAgdGhpcy5zZWxlY3RUb2dnbGVMYWJlbC5zZXQobGFiZWwpO1xuICB9XG5cbiAgcHVibGljIG9wZW4oKSB7XG4gICAgdGhpcy5pc09wZW4uc2V0KHRydWUpO1xuICAgIHRoaXMudmlldyA9IHRoaXMudmNyLmNyZWF0ZUVtYmVkZGVkVmlldyh0aGlzLmRyb3Bkb3duQ29udGVudCk7XG4gICAgdGhpcy5jdXJyZW50RHJvcGRvd24gPSB0aGlzLnZpZXcucm9vdE5vZGVzWzBdO1xuXG4gICAgdGhpcy5kb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKHRoaXMuY3VycmVudERyb3Bkb3duKTtcbiAgICB0aGlzLmN1cnJlbnREcm9wZG93bi5zdHlsZS53aWR0aCA9IGAke3RoaXMub3JpZ2luLm5hdGl2ZUVsZW1lbnQub2Zmc2V0V2lkdGh9cHhgO1xuICAgIHRoaXMuY3VycmVudERyb3Bkb3duLmNsYXNzTGlzdC5hZGQoJ29wZW4nKTtcbiAgICBpZiAodGhpcy5jb21iaW5lZE9wdGlvbnMoKS5zZWFyY2g/LmlzRW5hYmxlZCkge1xuICAgICAgdGhpcy5jdXJyZW50RHJvcGRvd24uY2xhc3NMaXN0LmFkZCgnaGFzLXNlYXJjaCcpO1xuICAgIH1cbiAgICBpZiAodGhpcy5jb21iaW5lZE9wdGlvbnMoKS5jb250ZW50Q2xhc3MpIHtcbiAgICAgIHRoaXMuY3VycmVudERyb3Bkb3duLmNsYXNzTGlzdC5hZGQodGhpcy5jb21iaW5lZE9wdGlvbnMoKS5jb250ZW50Q2xhc3MpO1xuICAgIH1cbiAgICB0aGlzLnBvcHBlclJlZiA9IGNyZWF0ZVBvcHBlcihcbiAgICAgIHRoaXMub3JpZ2luLm5hdGl2ZUVsZW1lbnQsXG4gICAgICB0aGlzLmN1cnJlbnREcm9wZG93bixcbiAgICAgIHtcbiAgICAgICAgcGxhY2VtZW50OiAnYm90dG9tLXN0YXJ0JyxcbiAgICAgICAgbW9kaWZpZXJzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgbmFtZTogJ3ByZXZlbnRPdmVyZmxvdycsXG4gICAgICAgICAgICBvcHRpb25zOiB7XG4gICAgICAgICAgICAgIGFsdEF4aXM6IHRydWUsXG4gICAgICAgICAgICAgIHBhZGRpbmc6IDUsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIF0sXG4gICAgICB9XG4gICAgKTtcblxuICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IFJlc2l6ZU9ic2VydmVyKCgpID0+IHtcbiAgICAgIHRoaXMucG9wcGVyUmVmLnVwZGF0ZSgpO1xuICAgIH0pO1xuICAgIG9ic2VydmVyLm9ic2VydmUodGhpcy5jdXJyZW50RHJvcGRvd24pO1xuXG4gICAgZnJvbUV2ZW50KHRoaXMuZG9jdW1lbnQuYm9keSwgJ2tleWRvd24nKVxuICAgICAgLnBpcGUodGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZiksIHRha2VVbnRpbCh0aGlzLmNsb3NlZCQpKVxuICAgICAgLnN1YnNjcmliZSgoZXZlbnQ6IGFueSkgPT4ge1xuICAgICAgICBpZiAoXG4gICAgICAgICAgdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5pc1NlbGVjdGluZ1dpdGhLZXlib2FyZEFjdGl2ZSAmJlxuICAgICAgICAgIGV2ZW50LmtleSA9PT0gJ0VudGVyJ1xuICAgICAgICApIHtcbiAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgIHRoaXMuc2VsZWN0KHRoaXMuZmlsdGVyZWRJdGVtcygpW3RoaXMuY2FuZGlkYXRlRm9yU2VsZWN0aW9uSW5kZXgoKV0pO1xuICAgICAgICAgIGlmICghdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5pc011bHRpcGxlKSB7XG4gICAgICAgICAgICB0aGlzLmNsb3NlKCk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChldmVudC5rZXkgPT09ICdFc2NhcGUnKSB7XG4gICAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChcbiAgICAgICAgICB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmlzU2VsZWN0aW5nV2l0aEtleWJvYXJkQWN0aXZlICYmXG4gICAgICAgICAgKGV2ZW50LmtleSA9PT0gJ0Fycm93RG93bicgfHwgZXZlbnQua2V5ID09PSAnQXJyb3dVcCcpXG4gICAgICAgICkge1xuICAgICAgICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICAgICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgICAgY29uc3QgaXRlbUxlbmd0aCA9IHRoaXMuZmlsdGVyZWRJdGVtcygpPy5sZW5ndGg7XG5cbiAgICAgICAgICBpZiAoZXZlbnQua2V5ID09PSAnQXJyb3dEb3duJykge1xuICAgICAgICAgICAgY29uc3QgbmV3SW5kZXggPVxuICAgICAgICAgICAgICB0aGlzLmNhbmRpZGF0ZUZvclNlbGVjdGlvbkluZGV4KCkgKyAxID49IGl0ZW1MZW5ndGhcbiAgICAgICAgICAgICAgICA/IDBcbiAgICAgICAgICAgICAgICA6IHRoaXMuY2FuZGlkYXRlRm9yU2VsZWN0aW9uSW5kZXgoKSArIDE7XG4gICAgICAgICAgICB0aGlzLmNhbmRpZGF0ZUZvclNlbGVjdGlvbkluZGV4LnNldChuZXdJbmRleCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIGNvbnN0IG5ld0luZGV4ID1cbiAgICAgICAgICAgICAgdGhpcy5jYW5kaWRhdGVGb3JTZWxlY3Rpb25JbmRleCgpIC0gMSA8IDBcbiAgICAgICAgICAgICAgICA/IGl0ZW1MZW5ndGggLSAxXG4gICAgICAgICAgICAgICAgOiB0aGlzLmNhbmRpZGF0ZUZvclNlbGVjdGlvbkluZGV4KCkgLSAxO1xuICAgICAgICAgICAgdGhpcy5jYW5kaWRhdGVGb3JTZWxlY3Rpb25JbmRleC5zZXQobmV3SW5kZXgpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGlmICh0aGlzLmN1cnJlbnREcm9wZG93biAmJiBvYnNlcnZlcikge1xuICAgICAgICBvYnNlcnZlci51bm9ic2VydmUodGhpcy5jdXJyZW50RHJvcGRvd24pO1xuICAgICAgfVxuICAgIH0sIDEwMDApO1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIHRvZ2dsZSgpIHtcbiAgICBpZiAodGhpcy5pc0Nsb3NpbmcpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHRoaXMuaXNPcGVuKCkpIHtcbiAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5vcGVuKCk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIGNsb3NlKCkge1xuICAgIHRoaXMuY2xvc2VkJC5uZXh0KHRydWUpO1xuICAgIHRoaXMuaXNDbG9zaW5nID0gdHJ1ZTtcbiAgICB0aGlzLmNsb3NlZC5lbWl0KCk7XG5cbiAgICBpZiAodGhpcy5jdXJyZW50RHJvcGRvd24pIHtcbiAgICAgIHRoaXMuY3VycmVudERyb3Bkb3duLmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTtcbiAgICB9XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGlmICh0aGlzLnZpZXcpIHtcbiAgICAgICAgdGhpcy52aWV3LmRlc3Ryb3koKTtcbiAgICAgIH1cbiAgICAgIGlmICh0aGlzLnBvcHBlclJlZikge1xuICAgICAgICB0aGlzLnBvcHBlclJlZi5kZXN0cm95KCk7XG4gICAgICB9XG4gICAgICB0aGlzLnZpZXcgPSBudWxsO1xuICAgICAgdGhpcy5wb3BwZXJSZWYgPSBudWxsO1xuICAgICAgdGhpcy5jdXJyZW50RHJvcGRvd24gPSBudWxsO1xuICAgICAgdGhpcy5pc0Nsb3NpbmcgPSBmYWxzZTtcbiAgICB9LCAzMDApO1xuICAgIHRoaXMuaXNPcGVuLnNldChmYWxzZSk7XG4gIH1cblxuICBASG9zdExpc3RlbmVyKCdkb2N1bWVudDpjbGljaycsIFsnJGV2ZW50JywgJyRldmVudC50YXJnZXQnXSlcbiAgcHVibGljIG9uQ2xpY2soZXZlbnQ6IE1vdXNlRXZlbnQsIHRhcmdldEVsZW1lbnQ6IEhUTUxFbGVtZW50KTogdm9pZCB7XG4gICAgaWYgKCF0YXJnZXRFbGVtZW50IHx8ICF0aGlzLm9yaWdpbikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBvcmlnaW5CYm94ID0gdGhpcy5vcmlnaW4ubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBjb25zdCBkcm9wZG93bkJib3ggPSB0aGlzLnZpZXc/LnJvb3ROb2Rlcz8uWzBdPy5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICBpZiAoIWRyb3Bkb3duQmJveCB8fCAhb3JpZ2luQmJveCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGNvbnN0IGNsaWNrZWRJbnNpZGVPcmlnaW4gPVxuICAgICAgZXZlbnQuY2xpZW50WCA+PSBvcmlnaW5CYm94LmxlZnQgJiZcbiAgICAgIGV2ZW50LmNsaWVudFggPD0gb3JpZ2luQmJveC5yaWdodCAmJlxuICAgICAgZXZlbnQuY2xpZW50WSA+PSBvcmlnaW5CYm94LnRvcCAmJlxuICAgICAgZXZlbnQuY2xpZW50WSA8PSBvcmlnaW5CYm94LmJvdHRvbTtcbiAgICBjb25zdCBjbGlja2VkSW5zaWRlRHJvcGRvd24gPVxuICAgICAgZXZlbnQuY2xpZW50WCA+PSBkcm9wZG93bkJib3gubGVmdCAmJlxuICAgICAgZXZlbnQuY2xpZW50WCA8PSBkcm9wZG93bkJib3gucmlnaHQgJiZcbiAgICAgIGV2ZW50LmNsaWVudFkgPj0gZHJvcGRvd25CYm94LnRvcCAmJlxuICAgICAgZXZlbnQuY2xpZW50WSA8PSBkcm9wZG93bkJib3guYm90dG9tO1xuXG4gICAgaWYgKCFjbGlja2VkSW5zaWRlT3JpZ2luICYmICFjbGlja2VkSW5zaWRlRHJvcGRvd24pIHtcbiAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgIGlmIChjaGFuZ2VzWydtb2RlbCddICYmIHRoaXMuY29tYmluZWRPcHRpb25zKCkpIHtcbiAgICAgIHRoaXMudXBkYXRlVG9nZ2xlTGFiZWwoKTtcbiAgICB9XG4gIH1cbn1cbiIsIjxkaXZcbiAgY2xhc3M9XCJvdWktc2VsZWN0LWNvbnRhaW5lciB7eyBjb21iaW5lZE9wdGlvbnMoKS50eXBlIH19XCJcbiAgaWQ9XCJ7eyBpZCB9fVwiXG4gIFtuZ0NsYXNzXT1cInsgYWN0aXZlOiBpc09wZW4oKSwgZGlzYWJsZWQ6IGRpc2FibGVkIH1cIlxuICA+XG4gIDxkaXYgY2xhc3M9XCJvdWktc2VsZWN0LXRvZ2dsZVwiIChjbGljayk9XCJ0b2dnbGUoKVwiICNvcmlnaW4+XG4gICAgPHNwYW4+e3sgc2VsZWN0VG9nZ2xlTGFiZWwoKSB9fTwvc3Bhbj5cbiAgICA8ZGl2IGNsYXNzPVwib3VpLXNlbGVjdC10b2dnbGUtY2FyZXQgcG9pbnRlci1ldmVudHMtbm9uZVwiPlxuICAgICAgQGlmICghaXNPcGVuKCkpIHtcbiAgICAgICAgPG91aS1pY29uXG4gICAgICAgICAgaWNvbj1cImFzc2V0cy9pY29ucy9jYXJldF9kb3duLnN2Z1wiXG4gICAgICAgIFtvcHRpb25zXT1cIntcbiAgICAgICAgICBzdHJva2VDb2xvcjogJ291aS1zZWxlY3QtdG9nZ2xlLXRleHQtY29sb3InLFxuICAgICAgICAgIGZpbGxDb2xvcjogJ291aS1zZWxlY3QtdG9nZ2xlLXRleHQtY29sb3InXG4gICAgICAgIH1cIlxuICAgICAgICA+PC9vdWktaWNvbj5cbiAgICAgIH1cbiAgICAgIEBpZiAoaXNPcGVuKCkpIHtcbiAgICAgICAgPG91aS1pY29uXG4gICAgICAgICAgaWNvbj1cImFzc2V0cy9pY29ucy9jYXJldF91cC5zdmdcIlxuICAgICAgICBbb3B0aW9uc109XCJ7XG4gICAgICAgICAgc3Ryb2tlQ29sb3I6ICdvdWktc2VsZWN0LXRvZ2dsZS10ZXh0LWNvbG9yJyxcbiAgICAgICAgICBmaWxsQ29sb3I6ICdvdWktc2VsZWN0LXRvZ2dsZS10ZXh0LWNvbG9yJ1xuICAgICAgICB9XCJcbiAgICAgICAgPjwvb3VpLWljb24+XG4gICAgICB9XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuICA8bmctdGVtcGxhdGUgI2Ryb3Bkb3duPlxuICAgIDxkaXYgY2xhc3M9XCJvdWktc2VsZWN0LWNvbnRlbnQtY29udGFpbmVyXCIgaWQ9XCJ7eyBpZCB9fVwiPlxuICAgICAgQGlmIChjb21iaW5lZE9wdGlvbnMoKS5zZWFyY2g/LmlzRW5hYmxlZCkge1xuICAgICAgICA8ZGl2IGNsYXNzPVwib3VpLXNlbGVjdC1zZWFyY2hcIj5cbiAgICAgICAgICA8b3VpLWlucHV0XG4gICAgICAgICAgICBvdWlBdXRvZm9jdXNcbiAgICAgICAgICAgIFtpc0F1dG9mb2N1c0VuYWJsZWRdPVwiISFjb21iaW5lZE9wdGlvbnMoKS5zZWFyY2g/LmlzRm9jdXNlZE9uT3BlblwiXG4gICAgICAgICAgICAjc2VhcmNoSW5wdXRcbiAgICAgICAgICAgIFtvcHRpb25zXT1cIntcbiAgICAgICAgICAgICAgdmFyaWFudDogJ3VuZGVybGluZWQnLFxuICAgICAgICAgICAgICBlbmRJY29uOiB7XG4gICAgICAgICAgICAgICAgaWNvbjogJ2Fzc2V0cy9pY29ucy9zZWFyY2guc3ZnJyxcbiAgICAgICAgICAgICAgICBvcHRpb25zOiB7XG4gICAgICAgICAgICAgICAgICBmaWxsQ29sb3I6ICdvdWktc2VsZWN0LXNlYXJjaC1pY29uLWNvbG9yJyxcbiAgICAgICAgICAgICAgICAgIHN0cm9rZUNvbG9yOiAnb3VpLXNlbGVjdC1zZWFyY2gtaWNvbi1jb2xvcicsXG4gICAgICAgICAgICAgICAgICBzaXplOiAnMS44cmVtJ1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVwiXG4gICAgICAgICAgICBbbW9kZWxdPVwic2VhcmNoVmFsdWUoKVwiXG4gICAgICAgICAgICAobW9kZWxDaGFuZ2UpPVwic2VhcmNoVmFsdWUuc2V0KCRldmVudClcIlxuICAgICAgICAgID48L291aS1pbnB1dD5cbiAgICAgICAgPC9kaXY+XG4gICAgICB9XG5cbiAgPGRpdlxuICAgIGNsYXNzPVwiY29udGVudCBvdWktc2Nyb2xsYmFyIG91aS1zY3JvbGxiYXItYXV0b1wiXG4gICAgPlxuICAgIEBpZiAoIWZpbHRlcmVkSXRlbXMoKS5sZW5ndGgpIHtcbiAgICAgIDxkaXY+Tm8gcmVzdWx0cyBmb3VuZC4uLjwvZGl2PlxuICAgIH1cblxuICAgIEBmb3IoaXRlbSBvZiBmaWx0ZXJlZEl0ZW1zKCk7IHRyYWNrIGl0ZW0pIHtcbiAgICAgIDxkaXZcbiAgICAgICAgKGNsaWNrKT1cInNlbGVjdChpdGVtKVwiXG4gICAgICA+XG4gICAgICAgIEBpZiAoIXRlbXBsYXRlKSB7XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3M9XCJvdWktc2VsZWN0LW9wdGlvbi1jb250YWluZXJcIlxuICAgICAgICAgICAgW25nQ2xhc3NdPVwie1xuICAgICAgICAgICAgICAgIGFjdGl2ZTpcbiAgICAgICAgICAgICAgICAgIGl0ZW0gfCBpc1NlbGVjdEl0ZW1BY3RpdmU6IHRoaXMubW9kZWwgOiBjb21iaW5lZE9wdGlvbnMoKS5pZEtleSxcbiAgICAgICAgICAgICAgICBjYW5kaWRhdGVGb3JTZWxlY3Rpb246XG4gICAgICAgICAgICAgICAgICBjb21iaW5lZE9wdGlvbnMoKS5pc1NlbGVjdGluZ1dpdGhLZXlib2FyZEFjdGl2ZSAmJiAkaW5kZXggPT09IGNhbmRpZGF0ZUZvclNlbGVjdGlvbkluZGV4KClcbiAgICAgICAgICAgICAgfVwiXG4gICAgICAgICAgPlxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cIm9wdGlvbi1sYWJlbFwiPlxuICAgICAgICAgICAgICB7eyBpdGVtIHwgc2VsZWN0SXRlbUxhYmVsOiBjb21iaW5lZE9wdGlvbnMoKS5sYWJlbEtleSB9fVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICBAaWYgKFxuICAgICAgICAgICAgICBpdGVtIHwgaXNTZWxlY3RJdGVtQWN0aXZlOiB0aGlzLm1vZGVsIDogY29tYmluZWRPcHRpb25zKCkuaWRLZXlcbiAgICAgICAgICAgICAgKSB7XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBjbGFzcz1cIm9wdGlvbi1hY3RpdmUtaWNvblwiXG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8b3VpLWljb25cbiAgICAgICAgICAgICAgICAgIGljb249XCJhc3NldHMvaWNvbnMvY2hlY2suc3ZnXCJcbiAgICAgICAgICAgICAgICAgIFtvcHRpb25zXT1cIntcbiAgICAgICAgICAgICAgICAgICAgZmlsbENvbG9yOiAnb3VpLXNlbGVjdC1jb250ZW50LXRleHQnLFxuICAgICAgICAgICAgICAgICAgICBzdHJva2VDb2xvcjogJ291aS1zZWxlY3QtY29udGVudC10ZXh0JyxcbiAgICAgICAgICAgICAgICAgICAgc2l6ZTogJzE4cHgnXG4gICAgICAgICAgICAgICAgICB9XCJcbiAgICAgICAgICAgICAgICA+PC9vdWktaWNvbj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICB9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIH1cblxuICAgICAgICA8bmctdGVtcGxhdGVcbiAgICAgICAgICAqbmdUZW1wbGF0ZU91dGxldD1cInRlbXBsYXRlOyBjb250ZXh0OiB7ICRpbXBsaWNpdDogaXRlbSwgaXRlbTogaXRlbSB9XCJcbiAgICAgICAgPlxuICAgICAgICA8L25nLXRlbXBsYXRlPlxuICAgICAgPC9kaXY+XG4gICAgfVxuXG4gIDwvZGl2PlxuPC9kaXY+XG48L25nLXRlbXBsYXRlPlxuPC9kaXY+XG4iXX0=