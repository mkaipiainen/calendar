export * from './slider/slider.component';
export * from './tick-slider/tick-slider.component';
//# sourceMappingURL=public-api.d.ts.map