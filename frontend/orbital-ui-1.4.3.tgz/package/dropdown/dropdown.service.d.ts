import { OuiDropdownComponent } from './dropdown.component';
import { OuiRoutingService } from 'orbital-ui/routing';
import * as i0 from "@angular/core";
/**
 * Service used to control dropdowns in the application. Tracks all dropdowns, and has a public method to close all dropdowns.
 */
export declare class OuiDropdownService {
    private ouiRoutingService;
    dropdowns: OuiDropdownComponent[];
    constructor(ouiRoutingService: OuiRoutingService);
    register(dropdown: OuiDropdownComponent): void;
    closeAll(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiDropdownService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiDropdownService>;
}
//# sourceMappingURL=dropdown.service.d.ts.map