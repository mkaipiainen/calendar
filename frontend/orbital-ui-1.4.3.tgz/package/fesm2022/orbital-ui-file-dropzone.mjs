import * as i0 from '@angular/core';
import { EventEmitter, Component, ChangeDetectionStrategy, ViewChild, Output } from '@angular/core';
import { fromEvent } from 'rxjs';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

/**
 * Component that can be used to add a dropzone into which you can drop files.
 * The dropped files are then emited via the filesUploaded-output, after which you can do what you want with them
 * Example use:
 *
 * <oui-file-dropzone (filesUploaded)="onFileUpload($event)"></oui-file-dropzone>
 */
class OuiFileDropzoneComponent {
    elementRef;
    destroyRef;
    dropzoneContainer;
    imageDisplay;
    icon;
    /**
     *   The event that's triggered after user drags files into the dropzone
     */
    filesUploaded = new EventEmitter();
    isImageDisplayed = false;
    constructor(elementRef, destroyRef) {
        this.elementRef = elementRef;
        this.destroyRef = destroyRef;
    }
    ngAfterViewInit() {
        fromEvent(this.elementRef.nativeElement, 'dragover')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            this.dropzoneContainer.nativeElement.classList.add('hovered');
            event.stopPropagation();
            event.preventDefault();
        });
        fromEvent(this.elementRef.nativeElement, 'dragleave')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            this.dropzoneContainer.nativeElement.classList.remove('hovered');
            event.stopPropagation();
            event.preventDefault();
        });
        fromEvent(this.elementRef.nativeElement, 'drop')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            event.stopPropagation();
            event.preventDefault();
            this.filesUploaded.emit(event.dataTransfer.files);
        });
        this.icon.nativeElement.style.backgroundImage =
            "url('assets/icons/attachments.svg')";
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiFileDropzoneComponent, deps: [{ token: i0.ElementRef }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiFileDropzoneComponent, isStandalone: true, selector: "oui-file-dropzone", outputs: { filesUploaded: "filesUploaded" }, viewQueries: [{ propertyName: "dropzoneContainer", first: true, predicate: ["dropzoneContainer"], descendants: true }, { propertyName: "imageDisplay", first: true, predicate: ["imageDisplay"], descendants: true }, { propertyName: "icon", first: true, predicate: ["icon"], descendants: true }], ngImport: i0, template: "<div class=\"oui-file-dropzone-container\" #dropzoneContainer>\n  <div\n    class=\"attachments-icon\"\n    [ngClass]=\"{ hide: isImageDisplayed }\"\n    #icon\n  ></div>\n  <div\n    class=\"image-display\"\n    [ngClass]=\"{ show: isImageDisplayed }\"\n    #imageDisplay\n  ></div>\n</div>\n", styles: [":host{width:100%;height:100%;position:relative}:host .oui-file-dropzone-container{width:100%;height:100%;display:flex;justify-content:center;align-items:center}:host .oui-file-dropzone-container:hover{cursor:pointer}:host .oui-file-dropzone-container:hover .attachments-icon{filter:brightness(2)}:host .oui-file-dropzone-container.hovered .attachments-icon{filter:brightness(2)}:host .oui-file-dropzone-container .attachments-icon{background-size:contain;background-repeat:no-repeat;background-position:center;flex:1;height:100%;width:100%;opacity:1;position:relative}:host .oui-file-dropzone-container .attachments-icon.hide{opacity:0;position:absolute;pointer-events:none}:host .oui-file-dropzone-container .image-display{height:100%;width:100%;opacity:0;pointer-events:none;position:absolute}:host .oui-file-dropzone-container .image-display.show{opacity:1;pointer-events:all;position:relative}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiFileDropzoneComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-file-dropzone', standalone: true, imports: [CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"oui-file-dropzone-container\" #dropzoneContainer>\n  <div\n    class=\"attachments-icon\"\n    [ngClass]=\"{ hide: isImageDisplayed }\"\n    #icon\n  ></div>\n  <div\n    class=\"image-display\"\n    [ngClass]=\"{ show: isImageDisplayed }\"\n    #imageDisplay\n  ></div>\n</div>\n", styles: [":host{width:100%;height:100%;position:relative}:host .oui-file-dropzone-container{width:100%;height:100%;display:flex;justify-content:center;align-items:center}:host .oui-file-dropzone-container:hover{cursor:pointer}:host .oui-file-dropzone-container:hover .attachments-icon{filter:brightness(2)}:host .oui-file-dropzone-container.hovered .attachments-icon{filter:brightness(2)}:host .oui-file-dropzone-container .attachments-icon{background-size:contain;background-repeat:no-repeat;background-position:center;flex:1;height:100%;width:100%;opacity:1;position:relative}:host .oui-file-dropzone-container .attachments-icon.hide{opacity:0;position:absolute;pointer-events:none}:host .oui-file-dropzone-container .image-display{height:100%;width:100%;opacity:0;pointer-events:none;position:absolute}:host .oui-file-dropzone-container .image-display.show{opacity:1;pointer-events:all;position:relative}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.DestroyRef }], propDecorators: { dropzoneContainer: [{
                type: ViewChild,
                args: ['dropzoneContainer']
            }], imageDisplay: [{
                type: ViewChild,
                args: ['imageDisplay']
            }], icon: [{
                type: ViewChild,
                args: ['icon']
            }], filesUploaded: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiFileDropzoneComponent };
//# sourceMappingURL=orbital-ui-file-dropzone.mjs.map
