import { OuiMainSidebarRouteSectionOptions, OuiMainSidebarRouteSectionComponent } from './main-sidebar-route-section/main-sidebar-route-section.component';
import { OuiMainSidebarActionSectionOptions, OuiMainSidebarActionSectionComponent } from './main-sidebar-action-section/main-sidebar-action-section.component';
import { OuiMainSidebarSubsectionOptions, OuiMainSidebarSubSectionComponent } from './main-sidebar-sub-section/main-sidebar-sub-section.component';
import * as i0 from "@angular/core";
export type OuiMainSidebarSectionComponent = OuiMainSidebarSubSectionComponent | OuiMainSidebarRouteSectionComponent | OuiMainSidebarActionSectionComponent;
export type OuiMainSidebarSectionOptions = OuiMainSidebarActionSectionOptions | OuiMainSidebarSubsectionOptions | OuiMainSidebarRouteSectionOptions;
export declare const MAIN_SIDEBAR_SECTION_TYPES: {
    ROUTE: string;
    SUBROUTE: string;
    ACTION: string;
    SUBSECTION: string;
};
export type MainSidebarSectionType = (typeof MAIN_SIDEBAR_SECTION_TYPES)[keyof typeof MAIN_SIDEBAR_SECTION_TYPES];
export declare class OuiMainSidebarService {
    private isOpenSubject;
    private openSubSectionSubject;
    private sectionClosedSubject;
    private sectionActiveSubject;
    private extensionWidthSubject;
    private isOpen;
    activeSection: import("@angular/core").WritableSignal<OuiMainSidebarSubSectionComponent | OuiMainSidebarRouteSectionComponent | undefined>;
    isOpen$: import("rxjs").Observable<boolean>;
    openSubSection$: import("rxjs").Observable<OuiMainSidebarSubSectionComponent | undefined>;
    sectionClosed$: import("rxjs").Observable<OuiMainSidebarSectionComponent>;
    extensionWidth$: import("rxjs").Observable<{
        width: string;
        value: number;
    }>;
    sectionActive$: import("rxjs").Observable<{
        isActive: boolean;
        sectionId: string;
    }>;
    constructor();
    setExtensionWidth(width: string): void;
    closeExtension(): void;
    openSubSection(subsection: OuiMainSidebarSubSectionComponent | undefined): void;
    open(): void;
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiMainSidebarService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiMainSidebarService>;
}
//# sourceMappingURL=main-sidebar.service.d.ts.map