import { Pipe } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Pipe to output either a caret up or down depending on value
 */
export class SelectItemLabelPipe {
    transform(item, labelKey) {
        return item[labelKey] ?? item;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: SelectItemLabelPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: SelectItemLabelPipe, isStandalone: true, name: "selectItemLabel" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: SelectItemLabelPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'selectItemLabel',
                    standalone: true,
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VsZWN0LWl0ZW0tbGFiZWwucGlwZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvc2VsZWN0L3NlbGVjdC1jb21wb25lbnQvc2VsZWN0LWl0ZW0tbGFiZWwucGlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsSUFBSSxFQUFpQixNQUFNLGVBQWUsQ0FBQzs7QUFFcEQ7O0dBRUc7QUFLSCxNQUFNLE9BQU8sbUJBQW1CO0lBQzlCLFNBQVMsQ0FBQyxJQUFTLEVBQUUsUUFBZ0I7UUFDbkMsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDO0lBQ2hDLENBQUM7dUdBSFUsbUJBQW1CO3FHQUFuQixtQkFBbUI7OzJGQUFuQixtQkFBbUI7a0JBSi9CLElBQUk7bUJBQUM7b0JBQ0osSUFBSSxFQUFFLGlCQUFpQjtvQkFDdkIsVUFBVSxFQUFFLElBQUk7aUJBQ2pCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGlwZSwgUGlwZVRyYW5zZm9ybSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG4vKipcbiAqIFBpcGUgdG8gb3V0cHV0IGVpdGhlciBhIGNhcmV0IHVwIG9yIGRvd24gZGVwZW5kaW5nIG9uIHZhbHVlXG4gKi9cbkBQaXBlKHtcbiAgbmFtZTogJ3NlbGVjdEl0ZW1MYWJlbCcsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG59KVxuZXhwb3J0IGNsYXNzIFNlbGVjdEl0ZW1MYWJlbFBpcGUgaW1wbGVtZW50cyBQaXBlVHJhbnNmb3JtIHtcbiAgdHJhbnNmb3JtKGl0ZW06IGFueSwgbGFiZWxLZXk6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGl0ZW1bbGFiZWxLZXldID8/IGl0ZW07XG4gIH1cbn1cbiJdfQ==