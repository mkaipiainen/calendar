import { ChangeDetectionStrategy, Component, computed, EventEmitter, input, Input, Output, signal, ViewChild, } from '@angular/core';
import * as MapboxGl from 'mapbox-gl';
import { GUID } from 'orbital-ui/helpers';
import { auditTime, concatMap, delay, of, race, ReplaySubject, skip, Subject, take, } from 'rxjs';
import { PipelineHelper } from './pipelines/pipeline-helper';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { merge } from 'lodash-es';
import { FlyToInterpolator } from '@deck.gl/core/typed';
import { OuiIconComponent } from 'orbital-ui/icon';
import { OuiRippleDirective } from 'orbital-ui/ripple';
import { NgStyle } from '@angular/common';
import * as i0 from "@angular/core";
export class OuiMapboxComponent {
    zone;
    destroyRef;
    elementRef;
    cdr;
    renderer;
    vcr;
    appRef;
    mapRef;
    overlay;
    mapContainer;
    actions;
    gammaMask;
    attributions = input([]);
    deck;
    set gamma(newGamma) {
        this._gamma = newGamma;
        const filters = this.elementRef.nativeElement.querySelectorAll('.gammaElement');
        if (this._gamma === 0) {
            this.gamma = -0.001;
        }
        for (const filter of filters) {
            filter.setAttribute('amplitude', `${this._gamma}`);
            filter.setAttribute('exponent', `${1 / this._gamma}`);
            // filter.setAttribute('offset', `${(value - 1) / 5}`);
        }
        this.gammaFilterUrl = `url(#gamma-${this.id}) brightness(${this._gamma})`;
    }
    get gamma() {
        return this._gamma;
    }
    set options(newOptions) {
        if (!newOptions) {
            return;
        }
        this.optionsSignal.set(newOptions);
        if (!this.isInitialised()) {
            this.attemptInitialisation();
            this.initNavigationControl();
            if (this.combinedOptions()?.isPipelineDataEmitted &&
                !this.isEmittingPipelines) {
                this.initEmittingPipelines();
            }
            if (!this.deck || this.deck.isInterleaved) {
                this.repositionMap();
            }
        }
        else if (!this.deck || this.deck.isInterleaved) {
            this.repositionMap();
        }
    }
    get options() {
        return this.combinedOptions();
    }
    onLoad = new EventEmitter();
    defaultOptions = {
        maxPitch: 0,
        style: 'mapbox://styles/mapbox/streets-v12',
        disableResizeTracking: false,
        isPipelineDataEmitted: false,
        antialias: true,
        attributionControl: true,
        bearing: 0,
        dragPan: true,
        dragRotate: true,
        doubleClickZoom: false,
        maxBounds: [-180, -90, 180, 90],
        maxZoom: 20,
        minZoom: 1,
        isHiddenOnInitialLoad: false,
        accessToken: '',
        longClickDelay: 500,
        projection: {
            name: 'mercator',
            center: [4, 50],
            parallels: [90, 90],
        },
    };
    currentMapboxLayers = [];
    isDestroyedSubject = new ReplaySubject(1);
    isDestroyed = false;
    isLoaded = false;
    pipelineHelper;
    isEmittingPipelines = false;
    isInitialised = signal(false);
    resizeObserver;
    onLoadSubject = new ReplaySubject(1);
    dragStartSubject = new Subject();
    longClickSubject = new Subject();
    mouseUpSubject = new Subject();
    mouseDownSubject = new Subject();
    viewStateChangeSubject = new ReplaySubject(1);
    boundsSubject = new ReplaySubject(1);
    eventHandlers = {
        move: this.onMapMove.bind(this),
        dragstart: this.onMapDragStart.bind(this),
        load: this.onMapLoad.bind(this),
        mousedown: this.onMapMouseDown.bind(this),
        mouseup: this.onMapMouseUp.bind(this),
    };
    previousMapboxViewState = {};
    pipelineDataSubject = new ReplaySubject(1);
    _gamma = 1;
    navigationControl;
    combinedOptions = computed(() => {
        return merge({ ...this.defaultOptions, ...this.optionsSignal() });
    });
    optionsSignal = signal(undefined);
    container = signal(undefined);
    id = GUID();
    onLoad$ = this.onLoadSubject.asObservable();
    map;
    isDestroyed$ = this.isDestroyedSubject.asObservable();
    viewStateChange$ = this.viewStateChangeSubject.asObservable();
    bounds$ = this.boundsSubject.asObservable();
    auditedViewStateChange$ = this.viewStateChange$.pipe(auditTime(500));
    auditedBounds$ = this.bounds$.pipe(auditTime(500));
    pipelineData$ = this.pipelineDataSubject.asObservable();
    dragStart$ = this.dragStartSubject.asObservable();
    longClick$ = this.longClickSubject.asObservable();
    mouseUp$ = this.mouseUpSubject.asObservable();
    mouseDown$ = this.mouseDownSubject.asObservable();
    isLoading = signal(true);
    gammaFilterUrl = `url(#gamma-${this.id}) brightness(1)`;
    constructor(zone, destroyRef, elementRef, cdr, renderer, vcr, appRef) {
        this.zone = zone;
        this.destroyRef = destroyRef;
        this.elementRef = elementRef;
        this.cdr = cdr;
        this.renderer = renderer;
        this.vcr = vcr;
        this.appRef = appRef;
    }
    ngAfterViewInit() {
        this.attemptInitialisation();
        if (!this.combinedOptions()?.isHiddenOnInitialLoad && this.mapContainer) {
            this.doShow();
        }
        setTimeout(() => {
            const attributionControl = this.elementRef.nativeElement.querySelector('.mapboxgl-ctrl-attrib');
            for (let template of this.attributions()) {
                if (attributionControl) {
                    const view = template.createEmbeddedView({});
                    this.appRef.attachView(view);
                    for (let child of view.rootNodes) {
                        attributionControl.appendChild(child);
                    }
                }
            }
        });
    }
    doShow() {
        this.renderer.addClass(this.mapContainer.nativeElement, 'show');
        this.renderer.addClass(this.overlay.nativeElement, 'fade');
    }
    initNavigationControl() {
        if (this.combinedOptions()?.navigationControl && this.map) {
            if (!this.navigationControl) {
                this.navigationControl = new MapboxGl.NavigationControl();
                this.map.addControl(this.navigationControl, this.combinedOptions().navigationControl);
            }
        }
    }
    attemptInitialisation() {
        if (!this.combinedOptions()?.accessToken) {
            return;
        }
        if (this.elementRef && this.mapRef && !this.isInitialised()) {
            this.initialiseComponent();
            this.isInitialised.set(true);
        }
    }
    initialiseComponent() {
        this.initMap();
        if (!this.combinedOptions()?.disableResizeTracking &&
            !this.resizeObserver) {
            this.resizeObserver = new ResizeObserver(() => {
                this.map?.resize();
            });
            this.resizeObserver.observe(this.elementRef.nativeElement);
        }
    }
    getDeckProps() {
        return this.deck.getProps();
    }
    setDeckProps(props) {
        if (this.deck.deck()) {
            this.deck.deck()?.setProps(props);
        }
        const overlay = this.deck.deckOverlay();
        if (overlay) {
            overlay.setProps(props);
            // this.deck.deckOverlay()?.setProps(props);
        }
    }
    initMap() {
        this.zone.runOutsideAngular(() => {
            const options = this.combinedOptions();
            if (!options) {
                return;
            }
            const mapOptions = {
                container: this.mapRef.nativeElement,
                // Choose from Mapbox's core styles, or make your own style with Mapbox Studio
                style: options?.style ?? 'mapbox://styles/mapbox/standard',
                accessToken: options?.accessToken,
                antialias: options.antialias,
                trackResize: true,
                doubleClickZoom: false,
                maxZoom: options.maxZoom,
                maxPitch: options.maxPitch,
                minZoom: options.minZoom,
                dragPan: options.dragPan,
                dragRotate: options.dragRotate,
                attributionControl: options.attributionControl,
                bearing: options.bearing,
                projection: {
                    name: options.projection.name,
                    center: options.center,
                    parallels: options.projection.parallels,
                },
            };
            if (options.bounds) {
                mapOptions.bounds = options.bounds;
            }
            else {
                mapOptions.center = options.center;
                mapOptions.zoom = options.zoom;
            }
            this.map = new MapboxGl.Map(mapOptions);
            this.container.set(this.mapRef.nativeElement);
            this.initNavigationControl();
            this.map.on('idle', this.eventHandlers.load);
        });
    }
    onMapMouseUp(event) {
        const eventData = {
            latitude: event.lngLat.lng,
            longitude: event.lngLat.lat,
            point: event.point,
            originalEvent: event.originalEvent,
            type: 'mouseup',
        };
        this.mouseUpSubject.next(eventData);
    }
    onMapMouseDown(event) {
        const eventData = {
            latitude: event.lngLat.lng,
            longitude: event.lngLat.lat,
            point: event.point,
            originalEvent: event.originalEvent,
            type: 'mousedown',
        };
        this.mouseDownSubject.next(eventData);
        race([
            this.mouseUp$,
            this.viewStateChange$.pipe(skip(1)),
            of(event).pipe(delay(this.combinedOptions()?.longClickDelay ?? 500)),
        ])
            .pipe(take(1), takeUntilDestroyed(this.destroyRef))
            .subscribe(data => {
            if ('type' in data &&
                (data.type === 'mousedown' || data.type === 'touchstart')) {
                this.longClickSubject.next({
                    latitude: event.lngLat.lat,
                    longitude: event.lngLat.lng,
                    point: event.point,
                    type: 'mousedown',
                    originalEvent: event.originalEvent,
                });
            }
        });
    }
    onMapLoad() {
        if (this.isDestroyed || !this.map || this.isLoaded) {
            return;
        }
        this.map.off('idle', this.eventHandlers.load);
        this.isLoaded = true;
        this.onLoad.emit(this);
        this.onLoadSubject.next(this);
        if (!this.combinedOptions()?.isHiddenOnInitialLoad && this.mapContainer) {
            this.doShow();
        }
        if (this.deck && !this.deck.isInterleaved) {
            this.deck.dragStart$
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe((data) => {
                this.dragStartSubject.next({
                    latitude: data.info.coordinate[1],
                    longitude: data.info.coordinate[0],
                });
            });
            this.deck.mousedown$
                .pipe(concatMap(data => {
                return race([
                    this.deck.mouseup$,
                    this.viewStateChange$.pipe(skip(1), take(1)),
                    of(data).pipe(delay(this.combinedOptions()?.longClickDelay ?? 500)),
                ]).pipe(take(1), takeUntilDestroyed(this.destroyRef));
            }))
                .subscribe(data => {
                if ('type' in data && data.type === 'mousedown') {
                    this.longClickSubject.next(data);
                }
            });
            this.deck.viewStateChange$
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe(viewState => {
                this.map.jumpTo({
                    center: [
                        viewState.viewState.longitude,
                        viewState.viewState.latitude,
                    ],
                    zoom: viewState.viewState.zoom,
                    bearing: viewState.viewState.bearing ?? 0,
                    pitch: viewState.viewState.pitch ?? 0,
                });
                this.viewStateChangeSubject.next(viewState);
            });
            this.deck.bounds$
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe(bounds => {
                this.boundsSubject.next(bounds);
            });
            this.deck.onLoad$
                .pipe(takeUntilDestroyed(this.destroyRef), take(1))
                .subscribe(() => {
                this.isLoading.set(false);
                this.emitInitialViewState();
            });
        }
        else {
            this.isLoading.set(false);
            this.emitInitialViewState();
            this.map.on('move', this.eventHandlers['move']);
            this.map.on('mousedown', this.eventHandlers.mousedown);
            this.map.on('touchstart', this.eventHandlers.mousedown);
            this.map.on('mouseup', this.eventHandlers.mouseup);
            this.map.on('touchend', this.eventHandlers.mouseup);
            this.map.on('dragstart', this.eventHandlers.dragstart);
            // this.onMapMove();
        }
        // Only for fetching pipelines
        if (this.combinedOptions()?.isPipelineDataEmitted &&
            !this.isEmittingPipelines) {
            this.initEmittingPipelines();
        }
    }
    onMapDragStart(event) {
        const center = this.map?.getCenter();
        this.dragStartSubject.next({
            latitude: center?.lat ?? 0,
            longitude: center?.lng ?? 0,
        });
    }
    initEmittingPipelines() {
        this.isEmittingPipelines = true;
        this.pipelineHelper = new PipelineHelper(this);
        this.pipelineHelper.pipeline$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(data => {
            this.pipelineDataSubject.next(data);
        });
    }
    projectLngLatToXy(lngLat) {
        if (!this.map) {
            throw new Error('Map is not initialized');
        }
        return this.map.project(lngLat);
    }
    projectXyToLngLat(point) {
        if (!this.map) {
            throw new Error('Map is not initialized');
        }
        return this.map.unproject(point);
    }
    onMapMove() {
        if (!this.map) {
            return;
        }
        const center = this.map.getCenter();
        const zoom = this.map.getZoom();
        const bounds = this.map.getBounds();
        const canvas = this.map.getCanvas();
        const newViewState = {
            latitude: center.lat,
            longitude: center.lng,
            zoom,
            width: canvas.width,
            height: canvas.height,
        };
        this.viewStateChangeSubject.next({
            oldViewState: this.previousMapboxViewState,
            viewState: newViewState,
        });
        this.previousMapboxViewState = newViewState;
        this.boundsSubject.next(this.map.getBounds());
    }
    emitInitialViewState() {
        if (this.map && (!this.deck || this.deck.isInterleaved)) {
            this.viewStateChangeSubject.next({
                oldViewState: {
                    latitude: this.map.getCenter().lat,
                    longitude: this.map.getCenter().lng,
                    zoom: this.map.getZoom(),
                    width: this.map.getCanvas().width,
                    height: this.map.getCanvas().height,
                },
                viewState: {
                    latitude: this.map.getCenter().lat,
                    longitude: this.map.getCenter().lng,
                    zoom: this.map.getZoom(),
                    width: this.map.getCanvas().width,
                    height: this.map.getCanvas().height,
                },
            });
        }
        if (this.map) {
            this.boundsSubject.next(this.map.getBounds());
        }
    }
    flyTo(options) {
        if (this.deck && !this.deck.isInterleaved) {
            const oldViewState = {
                ...this.deck.deck().props.initialViewState,
            };
            const newViewState = {
                ...oldViewState,
                latitude: options.latitude,
                longitude: options.longitude,
                zoom: options.zoom,
            };
            this.deck.deck().setProps({
                initialViewState: {
                    ...newViewState,
                    transitionDuration: options.transitionDuration,
                    transitionInterpolator: new FlyToInterpolator(),
                },
            });
            if (options.transitionDuration === 0) {
                this.deck.deck().props.onViewStateChange({
                    oldViewState,
                    viewState: newViewState,
                    interactionState: {},
                    viewId: 'default-map-view',
                });
            }
        }
        else if (this.map) {
            const flyToOptions = {
                center: [options.longitude, options.latitude],
                essential: true,
                zoom: options.zoom,
            };
            if (options.transitionDuration !== 'auto') {
                flyToOptions.duration = options.transitionDuration;
            }
            this.map.flyTo(flyToOptions);
        }
    }
    repositionMap() {
        const options = this.combinedOptions();
        if (this.map && options) {
            if ('bounds' in options && options.bounds) {
                this.map.fitBounds(options.bounds, {
                    animate: false
                });
            }
            else {
                this.map.jumpTo({
                    center: options.center,
                    zoom: options.zoom,
                });
            }
            this.onMapMove();
        }
    }
    toggleDragPan(isEnabled) {
        if (this.map) {
            if (isEnabled) {
                this.map.dragPan.enable();
            }
            else {
                this.map.dragPan.disable();
            }
        }
    }
    ngOnDestroy() {
        this.cleanup();
    }
    cleanup() {
        this.isDestroyed = true;
        this.isDestroyedSubject.next(true);
        this.isDestroyedSubject.complete();
        this.pipelineDataSubject.complete();
        this.onLoadSubject.complete();
        this.viewStateChangeSubject.complete();
        this.boundsSubject.complete();
        for (let key in this.eventHandlers) {
            if (this.map) {
                this.map.off(key, this.eventHandlers[key]);
            }
        }
        if (this.deck) {
            this.deck.finalize();
        }
        if (this.resizeObserver) {
            this.resizeObserver.unobserve(this.elementRef.nativeElement);
            this.resizeObserver.disconnect();
        }
        if (this.map) {
            try {
                this.map.remove();
            }
            catch (e) {
                console.log(e);
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMapboxComponent, deps: [{ token: i0.NgZone }, { token: i0.DestroyRef }, { token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i0.Renderer2 }, { token: i0.ViewContainerRef }, { token: i0.ApplicationRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "17.3.1", type: OuiMapboxComponent, isStandalone: true, selector: "oui-mapbox", inputs: { attributions: { classPropertyName: "attributions", publicName: "attributions", isSignal: true, isRequired: false, transformFunction: null }, deck: { classPropertyName: "deck", publicName: "deck", isSignal: false, isRequired: false, transformFunction: null }, gamma: { classPropertyName: "gamma", publicName: "gamma", isSignal: false, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: false, isRequired: true, transformFunction: null } }, outputs: { onLoad: "onLoad" }, viewQueries: [{ propertyName: "mapRef", first: true, predicate: ["map"], descendants: true }, { propertyName: "overlay", first: true, predicate: ["overlay"], descendants: true }, { propertyName: "mapContainer", first: true, predicate: ["mapContainer"], descendants: true }, { propertyName: "actions", first: true, predicate: ["actions"], descendants: true }, { propertyName: "gammaMask", first: true, predicate: ["gammaFilter"], descendants: true }], ngImport: i0, template: "<div class=\"map-overlay\" #overlay>\n\n</div>\n<div class=\"mapbox-container\" #mapContainer>\n  <div id=\"map\" [ngStyle]=\"{filter: gammaFilterUrl}\" #map></div>\n  <ng-content></ng-content>\n  <div class=\"actions\" #actions>\n\n  </div>\n\n  <svg class=\"gamma-mask-svg\">\n    <filter id=\"gamma-{{id}}\" primitiveUnits=\"objectBoundingBox\" width=\"100%\" height=\"100%\" x=\"0\" y=\"0\">\n      <feComponentTransfer result=\"ADJUSTED\" x=\"0%\" width=\"100%\" height=\"100%\" y=\"0%\">\n        <feFuncR\n            class=\"gammaElement\"\n            type=\"gamma\"\n            amplitude=\"1\"\n            exponent=\"1\"\n            offset=\"0\"\n        />\n        <feFuncG\n            class=\"gammaElement\"\n            type=\"gamma\"\n            amplitude=\"1\"\n            exponent=\"1\"\n            offset=\"0\"\n        />\n        <feFuncB\n            class=\"gammaElement\"\n            type=\"gamma\"\n            amplitude=\"1\"\n            exponent=\"1\"\n            offset=\"0\"\n        />\n      </feComponentTransfer>\n\n<!--      <feComposite in2=\"SourceGraphic\" in=\"ADJUSTED\" operator=\"over\" result=\"COMPOSITE\">-->\n\n<!--      </feComposite>-->\n    </filter>\n  </svg>\n</div>\n", styles: [":host{flex:1;display:flex;position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:all;box-shadow:var(--oui-mapbox-side-by-side-map-box-shadow);border-radius:var(--oui-mapbox-side-by-side-map-border-radius);border-width:var(--oui-mapbox-side-by-side-map-border-width);border-style:var(--oui-mapbox-side-by-side-map-border-style);border-color:var(--oui-mapbox-side-by-side-map-border-color);overflow:hidden}:host .map-overlay{position:absolute;top:0;left:0;height:100%;width:100%;background-color:var(--oui-mapbox-loading-overlay-color);opacity:1;transition:opacity .5s}:host .map-overlay.fade{opacity:0;pointer-events:none}:host .mapbox-container{position:relative;top:0;right:0;width:100%;height:100%;opacity:0;transition:opacity .5s}:host .mapbox-container.show{opacity:1}:host .mapbox-container .deck-canvas.disabled{display:none}:host .mapbox-container .actions{position:absolute;right:2rem;top:2rem;display:flex;flex-direction:column;left:auto;height:auto;width:3rem;z-index:1;pointer-events:none}:host .mapbox-container .actions .action{margin-bottom:1rem;width:3rem;height:3rem;border-radius:4px;background-color:var(--oui-mapbox-geolocate-background);display:flex;justify-content:center;align-items:center;box-shadow:0 0 5px #0000004d;pointer-events:all}:host .mapbox-container .actions .action:hover{background-color:var(--oui-mapbox-geolocate-background-hover);cursor:pointer}:host .mapbox-container canvas{position:absolute}:host .mapbox-container *{top:0;left:0;width:100%;height:100%}\n"], dependencies: [{ kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMapboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-mapbox', standalone: true, imports: [OuiIconComponent, OuiRippleDirective, NgStyle], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"map-overlay\" #overlay>\n\n</div>\n<div class=\"mapbox-container\" #mapContainer>\n  <div id=\"map\" [ngStyle]=\"{filter: gammaFilterUrl}\" #map></div>\n  <ng-content></ng-content>\n  <div class=\"actions\" #actions>\n\n  </div>\n\n  <svg class=\"gamma-mask-svg\">\n    <filter id=\"gamma-{{id}}\" primitiveUnits=\"objectBoundingBox\" width=\"100%\" height=\"100%\" x=\"0\" y=\"0\">\n      <feComponentTransfer result=\"ADJUSTED\" x=\"0%\" width=\"100%\" height=\"100%\" y=\"0%\">\n        <feFuncR\n            class=\"gammaElement\"\n            type=\"gamma\"\n            amplitude=\"1\"\n            exponent=\"1\"\n            offset=\"0\"\n        />\n        <feFuncG\n            class=\"gammaElement\"\n            type=\"gamma\"\n            amplitude=\"1\"\n            exponent=\"1\"\n            offset=\"0\"\n        />\n        <feFuncB\n            class=\"gammaElement\"\n            type=\"gamma\"\n            amplitude=\"1\"\n            exponent=\"1\"\n            offset=\"0\"\n        />\n      </feComponentTransfer>\n\n<!--      <feComposite in2=\"SourceGraphic\" in=\"ADJUSTED\" operator=\"over\" result=\"COMPOSITE\">-->\n\n<!--      </feComposite>-->\n    </filter>\n  </svg>\n</div>\n", styles: [":host{flex:1;display:flex;position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:all;box-shadow:var(--oui-mapbox-side-by-side-map-box-shadow);border-radius:var(--oui-mapbox-side-by-side-map-border-radius);border-width:var(--oui-mapbox-side-by-side-map-border-width);border-style:var(--oui-mapbox-side-by-side-map-border-style);border-color:var(--oui-mapbox-side-by-side-map-border-color);overflow:hidden}:host .map-overlay{position:absolute;top:0;left:0;height:100%;width:100%;background-color:var(--oui-mapbox-loading-overlay-color);opacity:1;transition:opacity .5s}:host .map-overlay.fade{opacity:0;pointer-events:none}:host .mapbox-container{position:relative;top:0;right:0;width:100%;height:100%;opacity:0;transition:opacity .5s}:host .mapbox-container.show{opacity:1}:host .mapbox-container .deck-canvas.disabled{display:none}:host .mapbox-container .actions{position:absolute;right:2rem;top:2rem;display:flex;flex-direction:column;left:auto;height:auto;width:3rem;z-index:1;pointer-events:none}:host .mapbox-container .actions .action{margin-bottom:1rem;width:3rem;height:3rem;border-radius:4px;background-color:var(--oui-mapbox-geolocate-background);display:flex;justify-content:center;align-items:center;box-shadow:0 0 5px #0000004d;pointer-events:all}:host .mapbox-container .actions .action:hover{background-color:var(--oui-mapbox-geolocate-background-hover);cursor:pointer}:host .mapbox-container canvas{position:absolute}:host .mapbox-container *{top:0;left:0;width:100%;height:100%}\n"] }]
        }], ctorParameters: () => [{ type: i0.NgZone }, { type: i0.DestroyRef }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i0.Renderer2 }, { type: i0.ViewContainerRef }, { type: i0.ApplicationRef }], propDecorators: { mapRef: [{
                type: ViewChild,
                args: ['map']
            }], overlay: [{
                type: ViewChild,
                args: ['overlay']
            }], mapContainer: [{
                type: ViewChild,
                args: ['mapContainer']
            }], actions: [{
                type: ViewChild,
                args: ['actions']
            }], gammaMask: [{
                type: ViewChild,
                args: ['gammaFilter']
            }], deck: [{
                type: Input
            }], gamma: [{
                type: Input
            }], options: [{
                type: Input,
                args: [{ required: true }]
            }], onLoad: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFwYm94LmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvbWFwYm94L21hcGJveC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL21hcGJveC9tYXBib3guY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUdMLHVCQUF1QixFQUV2QixTQUFTLEVBQ1QsUUFBUSxFQUdSLFlBQVksRUFDWixLQUFLLEVBQ0wsS0FBSyxFQUdMLE1BQU0sRUFFTixNQUFNLEVBRU4sU0FBUyxHQUVWLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sS0FBSyxRQUFRLE1BQU0sV0FBVyxDQUFDO0FBRXRDLE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUMxQyxPQUFPLEVBQ0wsU0FBUyxFQUNULFNBQVMsRUFDVCxLQUFLLEVBQ0wsRUFBRSxFQUNGLElBQUksRUFDSixhQUFhLEVBQ2IsSUFBSSxFQUNKLE9BQU8sRUFDUCxJQUFJLEdBQ0wsTUFBTSxNQUFNLENBQUM7QUFDZCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sNkJBQTZCLENBQUM7QUFDN0QsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFVaEUsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLFdBQVcsQ0FBQztBQUNsQyxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQztBQUV4RCxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUNuRCxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUN2RCxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0saUJBQWlCLENBQUM7O0FBVTFDLE1BQU0sT0FBTyxrQkFBa0I7SUF5SW5CO0lBQ0Q7SUFDQTtJQUNDO0lBQ0E7SUFDQTtJQUNBO0lBOUlRLE1BQU0sQ0FBYTtJQUNmLE9BQU8sQ0FBYTtJQUNmLFlBQVksQ0FBYTtJQUM5QixPQUFPLENBQWE7SUFDaEIsU0FBUyxDQUFhO0lBRXpDLFlBQVksR0FBRyxLQUFLLENBQXFCLEVBQUUsQ0FBQyxDQUFDO0lBRTNDLElBQUksQ0FBbUI7SUFDaEMsSUFBYSxLQUFLLENBQUMsUUFBZ0I7UUFDakMsSUFBSSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUM7UUFDdkIsTUFBTSxPQUFPLEdBQ1gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDbEUsSUFBSSxJQUFJLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ3RCLElBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQyxLQUFLLENBQUM7UUFDdEIsQ0FBQztRQUNELEtBQUssTUFBTSxNQUFNLElBQUksT0FBTyxFQUFFLENBQUM7WUFDN0IsTUFBTSxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUUsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUNuRCxNQUFNLENBQUMsWUFBWSxDQUFDLFVBQVUsRUFBRSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztZQUN0RCx1REFBdUQ7UUFDekQsQ0FBQztRQUNELElBQUksQ0FBQyxjQUFjLEdBQUcsY0FBYyxJQUFJLENBQUMsRUFBRSxnQkFBZ0IsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDO0lBQzVFLENBQUM7SUFFRCxJQUFJLEtBQUs7UUFDUCxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUM7SUFDckIsQ0FBQztJQUNELElBQStCLE9BQU8sQ0FDcEMsVUFBeUM7UUFFekMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ2hCLE9BQU87UUFDVCxDQUFDO1FBQ0QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDbkMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsRUFBRSxDQUFDO1lBQzFCLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1lBQzdCLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1lBQzdCLElBQ0UsSUFBSSxDQUFDLGVBQWUsRUFBRSxFQUFFLHFCQUFxQjtnQkFDN0MsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLEVBQ3pCLENBQUM7Z0JBQ0QsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7WUFDL0IsQ0FBQztZQUNELElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQzFDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUN2QixDQUFDO1FBQ0gsQ0FBQzthQUFNLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDakQsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3ZCLENBQUM7SUFDSCxDQUFDO0lBQ0QsSUFBSSxPQUFPO1FBQ1QsT0FBTyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDaEMsQ0FBQztJQUNTLE1BQU0sR0FBRyxJQUFJLFlBQVksRUFBc0IsQ0FBQztJQUVsRCxjQUFjLEdBR2xCO1FBQ0YsUUFBUSxFQUFFLENBQUM7UUFDWCxLQUFLLEVBQUUsb0NBQW9DO1FBQzNDLHFCQUFxQixFQUFFLEtBQUs7UUFDNUIscUJBQXFCLEVBQUUsS0FBSztRQUM1QixTQUFTLEVBQUUsSUFBSTtRQUNmLGtCQUFrQixFQUFFLElBQUk7UUFDeEIsT0FBTyxFQUFFLENBQUM7UUFDVixPQUFPLEVBQUUsSUFBSTtRQUNiLFVBQVUsRUFBRSxJQUFJO1FBQ2hCLGVBQWUsRUFBRSxLQUFLO1FBQ3RCLFNBQVMsRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUM7UUFDL0IsT0FBTyxFQUFFLEVBQUU7UUFDWCxPQUFPLEVBQUUsQ0FBQztRQUNWLHFCQUFxQixFQUFFLEtBQUs7UUFDNUIsV0FBVyxFQUFFLEVBQUU7UUFDZixjQUFjLEVBQUUsR0FBRztRQUNuQixVQUFVLEVBQUU7WUFDVixJQUFJLEVBQUUsVUFBVTtZQUNoQixNQUFNLEVBQUUsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDO1lBQ2YsU0FBUyxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQztTQUNwQjtLQUNGLENBQUM7SUFDTSxtQkFBbUIsR0FBc0IsRUFBRSxDQUFDO0lBQzVDLGtCQUFrQixHQUFHLElBQUksYUFBYSxDQUFVLENBQUMsQ0FBQyxDQUFDO0lBQ25ELFdBQVcsR0FBRyxLQUFLLENBQUM7SUFDcEIsUUFBUSxHQUFHLEtBQUssQ0FBQztJQUNqQixjQUFjLENBQWlCO0lBQy9CLG1CQUFtQixHQUFHLEtBQUssQ0FBQztJQUM1QixhQUFhLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLGNBQWMsQ0FBaUI7SUFDL0IsYUFBYSxHQUFHLElBQUksYUFBYSxDQUFxQixDQUFDLENBQUMsQ0FBQztJQUN6RCxnQkFBZ0IsR0FBRyxJQUFJLE9BQU8sRUFHbEMsQ0FBQztJQUNHLGdCQUFnQixHQUFHLElBQUksT0FBTyxFQUFnQixDQUFDO0lBQy9DLGNBQWMsR0FBRyxJQUFJLE9BQU8sRUFBZ0IsQ0FBQztJQUM3QyxnQkFBZ0IsR0FBRyxJQUFJLE9BQU8sRUFBZ0IsQ0FBQztJQUMvQyxzQkFBc0IsR0FBRyxJQUFJLGFBQWEsQ0FBeUIsQ0FBQyxDQUFDLENBQUM7SUFDdEUsYUFBYSxHQUFHLElBQUksYUFBYSxDQUF3QixDQUFDLENBQUMsQ0FBQztJQUM1RCxhQUFhLEdBRWpCO1FBQ0YsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUMvQixTQUFTLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQ3pDLElBQUksRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDL0IsU0FBUyxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztRQUN6QyxPQUFPLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0tBQ3RDLENBQUM7SUFDTSx1QkFBdUIsR0FBd0IsRUFBRSxDQUFDO0lBQ2xELG1CQUFtQixHQUFHLElBQUksYUFBYSxDQUc1QyxDQUFDLENBQUMsQ0FBQztJQUNFLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFDWCxpQkFBaUIsQ0FBeUM7SUFDM0QsZUFBZSxHQUFHLFFBQVEsQ0FBNEIsR0FBRyxFQUFFO1FBQ2hFLE9BQU8sS0FBSyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsY0FBYyxFQUFFLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUNwRSxDQUFDLENBQUMsQ0FBQztJQUNJLGFBQWEsR0FBRyxNQUFNLENBQWdDLFNBQVMsQ0FBQyxDQUFDO0lBQ2pFLFNBQVMsR0FBRyxNQUFNLENBQTBCLFNBQVMsQ0FBQyxDQUFDO0lBQ3ZELEVBQUUsR0FBRyxJQUFJLEVBQUUsQ0FBQztJQUNaLE9BQU8sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQzVDLEdBQUcsQ0FBMkI7SUFDOUIsWUFBWSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUN0RCxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDOUQsT0FBTyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDNUMsdUJBQXVCLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztJQUNyRSxjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDbkQsYUFBYSxHQUFHLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUN4RCxVQUFVLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ2xELFVBQVUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDbEQsUUFBUSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDOUMsVUFBVSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUNsRCxTQUFTLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ3pCLGNBQWMsR0FBRyxjQUFjLElBQUksQ0FBQyxFQUFFLGlCQUFpQixDQUFDO0lBQy9ELFlBQ1UsSUFBWSxFQUNiLFVBQXNCLEVBQ3RCLFVBQXNCLEVBQ3JCLEdBQXNCLEVBQ3RCLFFBQW1CLEVBQ25CLEdBQXFCLEVBQ3JCLE1BQXNCO1FBTnRCLFNBQUksR0FBSixJQUFJLENBQVE7UUFDYixlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQ3RCLGVBQVUsR0FBVixVQUFVLENBQVk7UUFDckIsUUFBRyxHQUFILEdBQUcsQ0FBbUI7UUFDdEIsYUFBUSxHQUFSLFFBQVEsQ0FBVztRQUNuQixRQUFHLEdBQUgsR0FBRyxDQUFrQjtRQUNyQixXQUFNLEdBQU4sTUFBTSxDQUFnQjtJQUM3QixDQUFDO0lBRUcsZUFBZTtRQUNwQixJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztRQUM3QixJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxFQUFFLHFCQUFxQixJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUN4RSxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDaEIsQ0FBQztRQUNELFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDZCxNQUFNLGtCQUFrQixHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FDcEUsdUJBQXVCLENBQ3hCLENBQUM7WUFDRixLQUFLLElBQUksUUFBUSxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDO2dCQUN6QyxJQUFJLGtCQUFrQixFQUFFLENBQUM7b0JBQ3ZCLE1BQU0sSUFBSSxHQUFHLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUMsQ0FBQztvQkFDN0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7b0JBQzdCLEtBQUssSUFBSSxLQUFLLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO3dCQUNqQyxrQkFBa0IsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7b0JBQ3hDLENBQUM7Z0JBQ0gsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFDTSxNQUFNO1FBQ1gsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDaEUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDN0QsQ0FBQztJQUVPLHFCQUFxQjtRQUMzQixJQUFJLElBQUksQ0FBQyxlQUFlLEVBQUUsRUFBRSxpQkFBaUIsSUFBSSxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDMUQsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO2dCQUM1QixJQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxRQUFRLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztnQkFDMUQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQ2pCLElBQUksQ0FBQyxpQkFBaUIsRUFDdEIsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLGlCQUFpQixDQUN6QyxDQUFDO1lBQ0osQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRU8scUJBQXFCO1FBQzNCLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLEVBQUUsV0FBVyxFQUFFLENBQUM7WUFDekMsT0FBTztRQUNULENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxVQUFVLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsRUFBRSxDQUFDO1lBQzVELElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1lBQzNCLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQy9CLENBQUM7SUFDSCxDQUFDO0lBRU8sbUJBQW1CO1FBQ3pCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUNmLElBQ0UsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLEVBQUUscUJBQXFCO1lBQzlDLENBQUMsSUFBSSxDQUFDLGNBQWMsRUFDcEIsQ0FBQztZQUNELElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxjQUFjLENBQUMsR0FBRyxFQUFFO2dCQUM1QyxJQUFJLENBQUMsR0FBRyxFQUFFLE1BQU0sRUFBRSxDQUFDO1lBQ3JCLENBQUMsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUM3RCxDQUFDO0lBQ0gsQ0FBQztJQUVNLFlBQVk7UUFDakIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQzlCLENBQUM7SUFFTSxZQUFZLENBQUMsS0FBVTtRQUM1QixJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQztZQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRSxFQUFFLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNwQyxDQUFDO1FBQ0QsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN4QyxJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQ1osT0FBTyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN4Qiw0Q0FBNEM7UUFDOUMsQ0FBQztJQUNILENBQUM7SUFFTyxPQUFPO1FBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxHQUFHLEVBQUU7WUFDL0IsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3ZDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDYixPQUFPO1lBQ1QsQ0FBQztZQUNELE1BQU0sVUFBVSxHQUFHO2dCQUNqQixTQUFTLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhO2dCQUNwQyw4RUFBOEU7Z0JBQzlFLEtBQUssRUFBRSxPQUFPLEVBQUUsS0FBSyxJQUFJLGlDQUFpQztnQkFDMUQsV0FBVyxFQUFFLE9BQU8sRUFBRSxXQUFXO2dCQUNqQyxTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVM7Z0JBQzVCLFdBQVcsRUFBRSxJQUFJO2dCQUNqQixlQUFlLEVBQUUsS0FBSztnQkFDdEIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPO2dCQUN4QixRQUFRLEVBQUUsT0FBTyxDQUFDLFFBQVE7Z0JBQzFCLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTztnQkFDeEIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPO2dCQUN4QixVQUFVLEVBQUUsT0FBTyxDQUFDLFVBQVU7Z0JBQzlCLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxrQkFBa0I7Z0JBQzlDLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTztnQkFDeEIsVUFBVSxFQUFFO29CQUNWLElBQUksRUFBRSxPQUFPLENBQUMsVUFBVSxDQUFDLElBQUk7b0JBQzdCLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTTtvQkFDdEIsU0FBUyxFQUFFLE9BQU8sQ0FBQyxVQUFVLENBQUMsU0FBUztpQkFDeEM7YUFDSyxDQUFDO1lBQ1QsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ25CLFVBQVUsQ0FBQyxNQUFNLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztZQUNyQyxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sVUFBVSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO2dCQUNuQyxVQUFVLENBQUMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUM7WUFDakMsQ0FBQztZQUNELElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1lBQ3hDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLENBQUM7WUFDOUMsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7WUFDN0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDL0MsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU8sWUFBWSxDQUFDLEtBQVU7UUFDN0IsTUFBTSxTQUFTLEdBQWlCO1lBQzlCLFFBQVEsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUc7WUFDMUIsU0FBUyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRztZQUMzQixLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUs7WUFDbEIsYUFBYSxFQUFFLEtBQUssQ0FBQyxhQUFhO1lBQ2xDLElBQUksRUFBRSxTQUFTO1NBQ2hCLENBQUM7UUFDRixJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRU8sY0FBYyxDQUFDLEtBQVU7UUFDL0IsTUFBTSxTQUFTLEdBQWlCO1lBQzlCLFFBQVEsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUc7WUFDMUIsU0FBUyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRztZQUMzQixLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUs7WUFDbEIsYUFBYSxFQUFFLEtBQUssQ0FBQyxhQUFhO1lBQ2xDLElBQUksRUFBRSxXQUFXO1NBQ2xCLENBQUM7UUFDRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3RDLElBQUksQ0FBQztZQUNILElBQUksQ0FBQyxRQUFRO1lBQ2IsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDbkMsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxFQUFFLGNBQWMsSUFBSSxHQUFHLENBQUMsQ0FBQztTQUNyRSxDQUFDO2FBQ0MsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDbEQsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFO1lBQ2hCLElBQ0UsTUFBTSxJQUFJLElBQUk7Z0JBQ2QsQ0FBQyxJQUFJLENBQUMsSUFBSSxLQUFLLFdBQVcsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLFlBQVksQ0FBQyxFQUN6RCxDQUFDO2dCQUNELElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUM7b0JBQ3pCLFFBQVEsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUc7b0JBQzFCLFNBQVMsRUFBRSxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUc7b0JBQzNCLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSztvQkFDbEIsSUFBSSxFQUFFLFdBQVc7b0JBQ2pCLGFBQWEsRUFBRSxLQUFLLENBQUMsYUFBYTtpQkFDbkMsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVNLFNBQVM7UUFDZCxJQUFJLElBQUksQ0FBQyxXQUFXLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNuRCxPQUFPO1FBQ1QsQ0FBQztRQUVELElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzlDLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBQ3JCLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQzlCLElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLEVBQUUscUJBQXFCLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3hFLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNoQixDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUMxQyxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVU7aUJBQ2pCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7aUJBQ3pDLFNBQVMsQ0FBQyxDQUFDLElBQVMsRUFBRSxFQUFFO2dCQUN2QixJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO29CQUN6QixRQUFRLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO29CQUNqQyxTQUFTLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO2lCQUNuQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUMsQ0FBQztZQUVMLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVTtpQkFDakIsSUFBSSxDQUNILFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRTtnQkFDZixPQUFPLElBQUksQ0FBQztvQkFDVixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVE7b0JBQ2xCLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDNUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQUksQ0FDWCxLQUFLLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxFQUFFLGNBQWMsSUFBSSxHQUFHLENBQUMsQ0FDckQ7aUJBQ0YsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7WUFDeEQsQ0FBQyxDQUFDLENBQ0g7aUJBQ0EsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFO2dCQUNoQixJQUFJLE1BQU0sSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxXQUFXLEVBQUUsQ0FBQztvQkFDaEQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztZQUNILENBQUMsQ0FBQyxDQUFDO1lBQ0wsSUFBSSxDQUFDLElBQUksQ0FBQyxnQkFBZ0I7aUJBQ3ZCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7aUJBQ3pDLFNBQVMsQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDckIsSUFBSSxDQUFDLEdBQUksQ0FBQyxNQUFNLENBQUM7b0JBQ2YsTUFBTSxFQUFFO3dCQUNOLFNBQVMsQ0FBQyxTQUFTLENBQUMsU0FBUzt3QkFDN0IsU0FBUyxDQUFDLFNBQVMsQ0FBQyxRQUFRO3FCQUM3QjtvQkFDRCxJQUFJLEVBQUUsU0FBUyxDQUFDLFNBQVMsQ0FBQyxJQUFJO29CQUM5QixPQUFPLEVBQUUsU0FBUyxDQUFDLFNBQVMsQ0FBQyxPQUFPLElBQUksQ0FBQztvQkFDekMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxTQUFTLENBQUMsS0FBSyxJQUFJLENBQUM7aUJBQ3RDLENBQUMsQ0FBQztnQkFDSCxJQUFJLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQzlDLENBQUMsQ0FBQyxDQUFDO1lBQ0wsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPO2lCQUNkLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7aUJBQ3pDLFNBQVMsQ0FBQyxNQUFNLENBQUMsRUFBRTtnQkFDbEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDbEMsQ0FBQyxDQUFDLENBQUM7WUFDTCxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU87aUJBQ2QsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ2xELFNBQVMsQ0FBQyxHQUFHLEVBQUU7Z0JBQ2QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQzFCLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1lBQzlCLENBQUMsQ0FBQyxDQUFDO1FBQ1AsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUMxQixJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztZQUM1QixJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ2hELElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3ZELElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3hELElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ25ELElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3BELElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRXZELG9CQUFvQjtRQUN0QixDQUFDO1FBRUQsOEJBQThCO1FBRTlCLElBQ0UsSUFBSSxDQUFDLGVBQWUsRUFBRSxFQUFFLHFCQUFxQjtZQUM3QyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsRUFDekIsQ0FBQztZQUNELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQy9CLENBQUM7SUFDSCxDQUFDO0lBRU0sY0FBYyxDQUFDLEtBQVU7UUFDOUIsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUUsQ0FBQztRQUNyQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO1lBQ3pCLFFBQVEsRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUM7WUFDMUIsU0FBUyxFQUFFLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQztTQUM1QixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU8scUJBQXFCO1FBQzNCLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxJQUFJLENBQUM7UUFFaEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVM7YUFDMUIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzthQUN6QyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUU7WUFDaEIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN0QyxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTSxpQkFBaUIsQ0FBQyxNQUF3QjtRQUMvQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ2QsTUFBTSxJQUFJLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1FBQzVDLENBQUM7UUFDRCxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0lBQ2xDLENBQUM7SUFFTSxpQkFBaUIsQ0FBQyxLQUFnQjtRQUN2QyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ2QsTUFBTSxJQUFJLEtBQUssQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1FBQzVDLENBQUM7UUFDRCxPQUFPLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ25DLENBQUM7SUFFTyxTQUFTO1FBQ2YsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNkLE9BQU87UUFDVCxDQUFDO1FBQ0QsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNwQyxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ2hDLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUM7UUFDcEMsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNwQyxNQUFNLFlBQVksR0FBRztZQUNuQixRQUFRLEVBQUUsTUFBTSxDQUFDLEdBQUc7WUFDcEIsU0FBUyxFQUFFLE1BQU0sQ0FBQyxHQUFHO1lBQ3JCLElBQUk7WUFDSixLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7WUFDbkIsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO1NBQ3RCLENBQUM7UUFDRixJQUFJLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDO1lBQy9CLFlBQVksRUFBRSxJQUFJLENBQUMsdUJBQXVCO1lBQzFDLFNBQVMsRUFBRSxZQUFZO1NBQ3hCLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyx1QkFBdUIsR0FBRyxZQUFZLENBQUM7UUFDNUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO0lBQ2hELENBQUM7SUFFTyxvQkFBb0I7UUFDMUIsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQztZQUN4RCxJQUFJLENBQUMsc0JBQXNCLENBQUMsSUFBSSxDQUFDO2dCQUMvQixZQUFZLEVBQUU7b0JBQ1osUUFBUSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUMsR0FBRztvQkFDbEMsU0FBUyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUMsR0FBRztvQkFDbkMsSUFBSSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFO29CQUN4QixLQUFLLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxLQUFLO29CQUNqQyxNQUFNLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxNQUFNO2lCQUNwQztnQkFDRCxTQUFTLEVBQUU7b0JBQ1QsUUFBUSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUMsR0FBRztvQkFDbEMsU0FBUyxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUMsR0FBRztvQkFDbkMsSUFBSSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxFQUFFO29CQUN4QixLQUFLLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxLQUFLO29CQUNqQyxNQUFNLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxNQUFNO2lCQUNwQzthQUNGLENBQUMsQ0FBQztRQUNMLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNiLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztRQUNoRCxDQUFDO0lBQ0gsQ0FBQztJQUVNLEtBQUssQ0FBQyxPQUFzQjtRQUNqQyxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQzFDLE1BQU0sWUFBWSxHQUFHO2dCQUNuQixHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFHLENBQUMsS0FBSyxDQUFDLGdCQUFnQjthQUM1QyxDQUFDO1lBQ0YsTUFBTSxZQUFZLEdBQUc7Z0JBQ25CLEdBQUcsWUFBWTtnQkFDZixRQUFRLEVBQUUsT0FBTyxDQUFDLFFBQVE7Z0JBQzFCLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUztnQkFDNUIsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJO2FBQ25CLENBQUM7WUFDRixJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRyxDQUFDLFFBQVEsQ0FBQztnQkFDekIsZ0JBQWdCLEVBQUU7b0JBQ2hCLEdBQUcsWUFBWTtvQkFDZixrQkFBa0IsRUFBRSxPQUFPLENBQUMsa0JBQWtCO29CQUM5QyxzQkFBc0IsRUFBRSxJQUFJLGlCQUFpQixFQUFFO2lCQUNoRDthQUNGLENBQUMsQ0FBQztZQUVILElBQUksT0FBTyxDQUFDLGtCQUFrQixLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUNyQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksRUFBRyxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQztvQkFDeEMsWUFBWTtvQkFDWixTQUFTLEVBQUUsWUFBWTtvQkFDdkIsZ0JBQWdCLEVBQUUsRUFBRTtvQkFDcEIsTUFBTSxFQUFFLGtCQUFrQjtpQkFDM0IsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztRQUNILENBQUM7YUFBTSxJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNwQixNQUFNLFlBQVksR0FBUTtnQkFDeEIsTUFBTSxFQUFFLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsUUFBUSxDQUFDO2dCQUM3QyxTQUFTLEVBQUUsSUFBSTtnQkFDZixJQUFJLEVBQUUsT0FBTyxDQUFDLElBQUk7YUFDbkIsQ0FBQztZQUNGLElBQUksT0FBTyxDQUFDLGtCQUFrQixLQUFLLE1BQU0sRUFBRSxDQUFDO2dCQUMxQyxZQUFZLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQztZQUNyRCxDQUFDO1lBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDL0IsQ0FBQztJQUNILENBQUM7SUFFTyxhQUFhO1FBQ25CLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztRQUN2QyxJQUFJLElBQUksQ0FBQyxHQUFHLElBQUksT0FBTyxFQUFFLENBQUM7WUFDeEIsSUFBSSxRQUFRLElBQUksT0FBTyxJQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFDMUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRTtvQkFDakMsT0FBTyxFQUFFLEtBQUs7aUJBQ2YsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO29CQUNkLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTTtvQkFDdEIsSUFBSSxFQUFFLE9BQU8sQ0FBQyxJQUFJO2lCQUNuQixDQUFDLENBQUM7WUFDTCxDQUFDO1lBRUQsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ25CLENBQUM7SUFDSCxDQUFDO0lBRU0sYUFBYSxDQUFDLFNBQWtCO1FBQ3JDLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ2IsSUFBSSxTQUFTLEVBQUUsQ0FBQztnQkFDZCxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUM1QixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDN0IsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRU0sV0FBVztRQUNoQixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDakIsQ0FBQztJQUVNLE9BQU87UUFDWixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQztRQUN4QixJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUNuQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDcEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUM5QixJQUFJLENBQUMsc0JBQXNCLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDdkMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUM5QixLQUFLLElBQUksR0FBRyxJQUFJLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNuQyxJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDYixJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQzdDLENBQUM7UUFDSCxDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDZCxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3ZCLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQzdELElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxFQUFFLENBQUM7UUFDbkMsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ2IsSUFBSSxDQUFDO2dCQUNILElBQUksQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDcEIsQ0FBQztZQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7Z0JBQ1gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNqQixDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7dUdBempCVSxrQkFBa0I7MkZBQWxCLGtCQUFrQiw4aUNDN0QvQiw2c0NBMENBLGlpRERnQmtELE9BQU87OzJGQUc1QyxrQkFBa0I7a0JBUjlCLFNBQVM7K0JBQ0UsWUFBWSxjQUdWLElBQUksV0FDUCxDQUFDLGdCQUFnQixFQUFFLGtCQUFrQixFQUFFLE9BQU8sQ0FBQyxtQkFDdkMsdUJBQXVCLENBQUMsTUFBTTtpUEFHN0IsTUFBTTtzQkFBdkIsU0FBUzt1QkFBQyxLQUFLO2dCQUNNLE9BQU87c0JBQTVCLFNBQVM7dUJBQUMsU0FBUztnQkFDTyxZQUFZO3NCQUF0QyxTQUFTO3VCQUFDLGNBQWM7Z0JBQ0gsT0FBTztzQkFBNUIsU0FBUzt1QkFBQyxTQUFTO2dCQUNNLFNBQVM7c0JBQWxDLFNBQVM7dUJBQUMsYUFBYTtnQkFJZixJQUFJO3NCQUFaLEtBQUs7Z0JBQ08sS0FBSztzQkFBakIsS0FBSztnQkFrQnlCLE9BQU87c0JBQXJDLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFO2dCQTBCZixNQUFNO3NCQUFmLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBBcHBsaWNhdGlvblJlZixcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIENoYW5nZURldGVjdG9yUmVmLFxuICBDb21wb25lbnQsXG4gIGNvbXB1dGVkLFxuICBEZXN0cm95UmVmLFxuICBFbGVtZW50UmVmLFxuICBFdmVudEVtaXR0ZXIsXG4gIGlucHV0LFxuICBJbnB1dCxcbiAgTmdab25lLFxuICBPbkRlc3Ryb3ksXG4gIE91dHB1dCxcbiAgUmVuZGVyZXIyLFxuICBzaWduYWwsXG4gIFRlbXBsYXRlUmVmLFxuICBWaWV3Q2hpbGQsXG4gIFZpZXdDb250YWluZXJSZWYsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0ICogYXMgTWFwYm94R2wgZnJvbSAnbWFwYm94LWdsJztcbmltcG9ydCB7IExuZ0xhdCwgUG9pbnRMaWtlIH0gZnJvbSAnbWFwYm94LWdsJztcbmltcG9ydCB7IEdVSUQgfSBmcm9tICdvcmJpdGFsLXVpL2hlbHBlcnMnO1xuaW1wb3J0IHtcbiAgYXVkaXRUaW1lLFxuICBjb25jYXRNYXAsXG4gIGRlbGF5LFxuICBvZixcbiAgcmFjZSxcbiAgUmVwbGF5U3ViamVjdCxcbiAgc2tpcCxcbiAgU3ViamVjdCxcbiAgdGFrZSxcbn0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyBQaXBlbGluZUhlbHBlciB9IGZyb20gJy4vcGlwZWxpbmVzL3BpcGVsaW5lLWhlbHBlcic7XG5pbXBvcnQgeyB0YWtlVW50aWxEZXN0cm95ZWQgfSBmcm9tICdAYW5ndWxhci9jb3JlL3J4anMtaW50ZXJvcCc7XG5pbXBvcnQge1xuICBJRmx5VG9PcHRpb25zLFxuICBJTW91c2VVcERvd24sXG4gIElNYXBib3hWaWV3U3RhdGVDaGFuZ2UsXG4gIElPdWlNYXBib3hDb21iaW5lZE9wdGlvbnMsXG4gIElPdWlNYXBib3hPcHRpb25zLFxuICBNYXBib3hCYXNlTGF5ZXIsXG59IGZyb20gJy4vdHlwaW5ncyc7XG5pbXBvcnQgeyBPdWlEZWNrQ29tcG9uZW50IH0gZnJvbSAnLi9kZWNrL2RlY2suY29tcG9uZW50JztcbmltcG9ydCB7IG1lcmdlIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IEZseVRvSW50ZXJwb2xhdG9yIH0gZnJvbSAnQGRlY2suZ2wvY29yZS90eXBlZCc7XG5pbXBvcnQgeyBQb3NpdGlvbiB9IGZyb20gJ0B0dXJmL2hlbHBlcnMnO1xuaW1wb3J0IHsgT3VpSWNvbkNvbXBvbmVudCB9IGZyb20gJ29yYml0YWwtdWkvaWNvbic7XG5pbXBvcnQgeyBPdWlSaXBwbGVEaXJlY3RpdmUgfSBmcm9tICdvcmJpdGFsLXVpL3JpcHBsZSc7XG5pbXBvcnQgeyBOZ1N0eWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLW1hcGJveCcsXG4gIHRlbXBsYXRlVXJsOiAnLi9tYXBib3guY29tcG9uZW50Lmh0bWwnLFxuICBzdHlsZVVybHM6IFsnLi9tYXBib3guY29tcG9uZW50LnNjc3MnXSxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW091aUljb25Db21wb25lbnQsIE91aVJpcHBsZURpcmVjdGl2ZSwgTmdTdHlsZV0sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlNYXBib3hDb21wb25lbnQgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0LCBPbkRlc3Ryb3kge1xuICBAVmlld0NoaWxkKCdtYXAnKSBtYXBSZWY6IEVsZW1lbnRSZWY7XG4gIEBWaWV3Q2hpbGQoJ292ZXJsYXknKSBvdmVybGF5OiBFbGVtZW50UmVmO1xuICBAVmlld0NoaWxkKCdtYXBDb250YWluZXInKSBtYXBDb250YWluZXI6IEVsZW1lbnRSZWY7XG4gIEBWaWV3Q2hpbGQoJ2FjdGlvbnMnKSBhY3Rpb25zOiBFbGVtZW50UmVmO1xuICBAVmlld0NoaWxkKCdnYW1tYUZpbHRlcicpIGdhbW1hTWFzazogRWxlbWVudFJlZjtcblxuICBwdWJsaWMgYXR0cmlidXRpb25zID0gaW5wdXQ8VGVtcGxhdGVSZWY8YW55PltdPihbXSk7XG5cbiAgQElucHV0KCkgZGVjazogT3VpRGVja0NvbXBvbmVudDtcbiAgQElucHV0KCkgc2V0IGdhbW1hKG5ld0dhbW1hOiBudW1iZXIpIHtcbiAgICB0aGlzLl9nYW1tYSA9IG5ld0dhbW1hO1xuICAgIGNvbnN0IGZpbHRlcnMgPVxuICAgICAgdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLmdhbW1hRWxlbWVudCcpO1xuICAgIGlmICh0aGlzLl9nYW1tYSA9PT0gMCkge1xuICAgICAgdGhpcy5nYW1tYSA9IC0wLjAwMTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBmaWx0ZXIgb2YgZmlsdGVycykge1xuICAgICAgZmlsdGVyLnNldEF0dHJpYnV0ZSgnYW1wbGl0dWRlJywgYCR7dGhpcy5fZ2FtbWF9YCk7XG4gICAgICBmaWx0ZXIuc2V0QXR0cmlidXRlKCdleHBvbmVudCcsIGAkezEgLyB0aGlzLl9nYW1tYX1gKTtcbiAgICAgIC8vIGZpbHRlci5zZXRBdHRyaWJ1dGUoJ29mZnNldCcsIGAkeyh2YWx1ZSAtIDEpIC8gNX1gKTtcbiAgICB9XG4gICAgdGhpcy5nYW1tYUZpbHRlclVybCA9IGB1cmwoI2dhbW1hLSR7dGhpcy5pZH0pIGJyaWdodG5lc3MoJHt0aGlzLl9nYW1tYX0pYDtcbiAgfVxuXG4gIGdldCBnYW1tYSgpIHtcbiAgICByZXR1cm4gdGhpcy5fZ2FtbWE7XG4gIH1cbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSkgc2V0IG9wdGlvbnMoXG4gICAgbmV3T3B0aW9uczogSU91aU1hcGJveE9wdGlvbnMgfCB1bmRlZmluZWRcbiAgKSB7XG4gICAgaWYgKCFuZXdPcHRpb25zKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMub3B0aW9uc1NpZ25hbC5zZXQobmV3T3B0aW9ucyk7XG4gICAgaWYgKCF0aGlzLmlzSW5pdGlhbGlzZWQoKSkge1xuICAgICAgdGhpcy5hdHRlbXB0SW5pdGlhbGlzYXRpb24oKTtcbiAgICAgIHRoaXMuaW5pdE5hdmlnYXRpb25Db250cm9sKCk7XG4gICAgICBpZiAoXG4gICAgICAgIHRoaXMuY29tYmluZWRPcHRpb25zKCk/LmlzUGlwZWxpbmVEYXRhRW1pdHRlZCAmJlxuICAgICAgICAhdGhpcy5pc0VtaXR0aW5nUGlwZWxpbmVzXG4gICAgICApIHtcbiAgICAgICAgdGhpcy5pbml0RW1pdHRpbmdQaXBlbGluZXMoKTtcbiAgICAgIH1cbiAgICAgIGlmICghdGhpcy5kZWNrIHx8IHRoaXMuZGVjay5pc0ludGVybGVhdmVkKSB7XG4gICAgICAgIHRoaXMucmVwb3NpdGlvbk1hcCgpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoIXRoaXMuZGVjayB8fCB0aGlzLmRlY2suaXNJbnRlcmxlYXZlZCkge1xuICAgICAgdGhpcy5yZXBvc2l0aW9uTWFwKCk7XG4gICAgfVxuICB9XG4gIGdldCBvcHRpb25zKCk6IElPdWlNYXBib3hDb21iaW5lZE9wdGlvbnMgfCB1bmRlZmluZWQge1xuICAgIHJldHVybiB0aGlzLmNvbWJpbmVkT3B0aW9ucygpO1xuICB9XG4gIEBPdXRwdXQoKSBvbkxvYWQgPSBuZXcgRXZlbnRFbWl0dGVyPE91aU1hcGJveENvbXBvbmVudD4oKTtcblxuICBwcml2YXRlIGRlZmF1bHRPcHRpb25zOiBPbWl0PFxuICAgIElPdWlNYXBib3hDb21iaW5lZE9wdGlvbnMsXG4gICAgJ2NlbnRlcicgfCAnYm91bmRzJyB8ICd6b29tJ1xuICA+ID0ge1xuICAgIG1heFBpdGNoOiAwLFxuICAgIHN0eWxlOiAnbWFwYm94Oi8vc3R5bGVzL21hcGJveC9zdHJlZXRzLXYxMicsXG4gICAgZGlzYWJsZVJlc2l6ZVRyYWNraW5nOiBmYWxzZSxcbiAgICBpc1BpcGVsaW5lRGF0YUVtaXR0ZWQ6IGZhbHNlLFxuICAgIGFudGlhbGlhczogdHJ1ZSxcbiAgICBhdHRyaWJ1dGlvbkNvbnRyb2w6IHRydWUsXG4gICAgYmVhcmluZzogMCxcbiAgICBkcmFnUGFuOiB0cnVlLFxuICAgIGRyYWdSb3RhdGU6IHRydWUsXG4gICAgZG91YmxlQ2xpY2tab29tOiBmYWxzZSxcbiAgICBtYXhCb3VuZHM6IFstMTgwLCAtOTAsIDE4MCwgOTBdLFxuICAgIG1heFpvb206IDIwLFxuICAgIG1pblpvb206IDEsXG4gICAgaXNIaWRkZW5PbkluaXRpYWxMb2FkOiBmYWxzZSxcbiAgICBhY2Nlc3NUb2tlbjogJycsXG4gICAgbG9uZ0NsaWNrRGVsYXk6IDUwMCxcbiAgICBwcm9qZWN0aW9uOiB7XG4gICAgICBuYW1lOiAnbWVyY2F0b3InLFxuICAgICAgY2VudGVyOiBbNCwgNTBdLFxuICAgICAgcGFyYWxsZWxzOiBbOTAsIDkwXSxcbiAgICB9LFxuICB9O1xuICBwcml2YXRlIGN1cnJlbnRNYXBib3hMYXllcnM6IE1hcGJveEJhc2VMYXllcltdID0gW107XG4gIHByaXZhdGUgaXNEZXN0cm95ZWRTdWJqZWN0ID0gbmV3IFJlcGxheVN1YmplY3Q8Ym9vbGVhbj4oMSk7XG4gIHByaXZhdGUgaXNEZXN0cm95ZWQgPSBmYWxzZTtcbiAgcHJpdmF0ZSBpc0xvYWRlZCA9IGZhbHNlO1xuICBwcml2YXRlIHBpcGVsaW5lSGVscGVyOiBQaXBlbGluZUhlbHBlcjtcbiAgcHJpdmF0ZSBpc0VtaXR0aW5nUGlwZWxpbmVzID0gZmFsc2U7XG4gIHByaXZhdGUgaXNJbml0aWFsaXNlZCA9IHNpZ25hbChmYWxzZSk7XG4gIHByaXZhdGUgcmVzaXplT2JzZXJ2ZXI6IFJlc2l6ZU9ic2VydmVyO1xuICBwcml2YXRlIG9uTG9hZFN1YmplY3QgPSBuZXcgUmVwbGF5U3ViamVjdDxPdWlNYXBib3hDb21wb25lbnQ+KDEpO1xuICBwcml2YXRlIGRyYWdTdGFydFN1YmplY3QgPSBuZXcgU3ViamVjdDx7XG4gICAgbGF0aXR1ZGU6IG51bWJlcjtcbiAgICBsb25naXR1ZGU6IG51bWJlcjtcbiAgfT4oKTtcbiAgcHJpdmF0ZSBsb25nQ2xpY2tTdWJqZWN0ID0gbmV3IFN1YmplY3Q8SU1vdXNlVXBEb3duPigpO1xuICBwcml2YXRlIG1vdXNlVXBTdWJqZWN0ID0gbmV3IFN1YmplY3Q8SU1vdXNlVXBEb3duPigpO1xuICBwcml2YXRlIG1vdXNlRG93blN1YmplY3QgPSBuZXcgU3ViamVjdDxJTW91c2VVcERvd24+KCk7XG4gIHByaXZhdGUgdmlld1N0YXRlQ2hhbmdlU3ViamVjdCA9IG5ldyBSZXBsYXlTdWJqZWN0PElNYXBib3hWaWV3U3RhdGVDaGFuZ2U+KDEpO1xuICBwcml2YXRlIGJvdW5kc1N1YmplY3QgPSBuZXcgUmVwbGF5U3ViamVjdDxNYXBib3hHbC5MbmdMYXRCb3VuZHM+KDEpO1xuICBwcml2YXRlIGV2ZW50SGFuZGxlcnM6IHtcbiAgICBbeDogc3RyaW5nXTogKC4uLmFyZ3M6IGFueVtdKSA9PiB2b2lkO1xuICB9ID0ge1xuICAgIG1vdmU6IHRoaXMub25NYXBNb3ZlLmJpbmQodGhpcyksXG4gICAgZHJhZ3N0YXJ0OiB0aGlzLm9uTWFwRHJhZ1N0YXJ0LmJpbmQodGhpcyksXG4gICAgbG9hZDogdGhpcy5vbk1hcExvYWQuYmluZCh0aGlzKSxcbiAgICBtb3VzZWRvd246IHRoaXMub25NYXBNb3VzZURvd24uYmluZCh0aGlzKSxcbiAgICBtb3VzZXVwOiB0aGlzLm9uTWFwTW91c2VVcC5iaW5kKHRoaXMpLFxuICB9O1xuICBwcml2YXRlIHByZXZpb3VzTWFwYm94Vmlld1N0YXRlOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge307XG4gIHByaXZhdGUgcGlwZWxpbmVEYXRhU3ViamVjdCA9IG5ldyBSZXBsYXlTdWJqZWN0PHtcbiAgICBkcHA6IG51bWJlcjtcbiAgICBib3VuZHM6IFBvc2l0aW9uW107XG4gIH0+KDEpO1xuICBwcml2YXRlIF9nYW1tYSA9IDE7XG4gIHByaXZhdGUgbmF2aWdhdGlvbkNvbnRyb2w6IE1hcGJveEdsLk5hdmlnYXRpb25Db250cm9sIHwgdW5kZWZpbmVkO1xuICBwdWJsaWMgY29tYmluZWRPcHRpb25zID0gY29tcHV0ZWQ8SU91aU1hcGJveENvbWJpbmVkT3B0aW9ucz4oKCkgPT4ge1xuICAgIHJldHVybiBtZXJnZSh7IC4uLnRoaXMuZGVmYXVsdE9wdGlvbnMsIC4uLnRoaXMub3B0aW9uc1NpZ25hbCgpIH0pO1xuICB9KTtcbiAgcHVibGljIG9wdGlvbnNTaWduYWwgPSBzaWduYWw8SU91aU1hcGJveE9wdGlvbnMgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG4gIHB1YmxpYyBjb250YWluZXIgPSBzaWduYWw8dW5kZWZpbmVkIHwgSFRNTEVsZW1lbnQ+KHVuZGVmaW5lZCk7XG4gIHB1YmxpYyBpZCA9IEdVSUQoKTtcbiAgcHVibGljIG9uTG9hZCQgPSB0aGlzLm9uTG9hZFN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XG4gIHB1YmxpYyBtYXA6IE1hcGJveEdsLk1hcCB8IHVuZGVmaW5lZDtcbiAgcHVibGljIGlzRGVzdHJveWVkJCA9IHRoaXMuaXNEZXN0cm95ZWRTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuICBwdWJsaWMgdmlld1N0YXRlQ2hhbmdlJCA9IHRoaXMudmlld1N0YXRlQ2hhbmdlU3ViamVjdC5hc09ic2VydmFibGUoKTtcbiAgcHVibGljIGJvdW5kcyQgPSB0aGlzLmJvdW5kc1N1YmplY3QuYXNPYnNlcnZhYmxlKCk7XG4gIHB1YmxpYyBhdWRpdGVkVmlld1N0YXRlQ2hhbmdlJCA9IHRoaXMudmlld1N0YXRlQ2hhbmdlJC5waXBlKGF1ZGl0VGltZSg1MDApKTtcbiAgcHVibGljIGF1ZGl0ZWRCb3VuZHMkID0gdGhpcy5ib3VuZHMkLnBpcGUoYXVkaXRUaW1lKDUwMCkpO1xuICBwdWJsaWMgcGlwZWxpbmVEYXRhJCA9IHRoaXMucGlwZWxpbmVEYXRhU3ViamVjdC5hc09ic2VydmFibGUoKTtcbiAgcHVibGljIGRyYWdTdGFydCQgPSB0aGlzLmRyYWdTdGFydFN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XG4gIHB1YmxpYyBsb25nQ2xpY2skID0gdGhpcy5sb25nQ2xpY2tTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuICBwdWJsaWMgbW91c2VVcCQgPSB0aGlzLm1vdXNlVXBTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuICBwdWJsaWMgbW91c2VEb3duJCA9IHRoaXMubW91c2VEb3duU3ViamVjdC5hc09ic2VydmFibGUoKTtcbiAgcHVibGljIGlzTG9hZGluZyA9IHNpZ25hbCh0cnVlKTtcbiAgcHVibGljIGdhbW1hRmlsdGVyVXJsID0gYHVybCgjZ2FtbWEtJHt0aGlzLmlkfSkgYnJpZ2h0bmVzcygxKWA7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgem9uZTogTmdab25lLFxuICAgIHB1YmxpYyBkZXN0cm95UmVmOiBEZXN0cm95UmVmLFxuICAgIHB1YmxpYyBlbGVtZW50UmVmOiBFbGVtZW50UmVmLFxuICAgIHByaXZhdGUgY2RyOiBDaGFuZ2VEZXRlY3RvclJlZixcbiAgICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjIsXG4gICAgcHJpdmF0ZSB2Y3I6IFZpZXdDb250YWluZXJSZWYsXG4gICAgcHJpdmF0ZSBhcHBSZWY6IEFwcGxpY2F0aW9uUmVmXG4gICkge31cblxuICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCkge1xuICAgIHRoaXMuYXR0ZW1wdEluaXRpYWxpc2F0aW9uKCk7XG4gICAgaWYgKCF0aGlzLmNvbWJpbmVkT3B0aW9ucygpPy5pc0hpZGRlbk9uSW5pdGlhbExvYWQgJiYgdGhpcy5tYXBDb250YWluZXIpIHtcbiAgICAgIHRoaXMuZG9TaG93KCk7XG4gICAgfVxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgY29uc3QgYXR0cmlidXRpb25Db250cm9sID0gdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvcihcbiAgICAgICAgJy5tYXBib3hnbC1jdHJsLWF0dHJpYidcbiAgICAgICk7XG4gICAgICBmb3IgKGxldCB0ZW1wbGF0ZSBvZiB0aGlzLmF0dHJpYnV0aW9ucygpKSB7XG4gICAgICAgIGlmIChhdHRyaWJ1dGlvbkNvbnRyb2wpIHtcbiAgICAgICAgICBjb25zdCB2aWV3ID0gdGVtcGxhdGUuY3JlYXRlRW1iZWRkZWRWaWV3KHt9KTtcbiAgICAgICAgICB0aGlzLmFwcFJlZi5hdHRhY2hWaWV3KHZpZXcpO1xuICAgICAgICAgIGZvciAobGV0IGNoaWxkIG9mIHZpZXcucm9vdE5vZGVzKSB7XG4gICAgICAgICAgICBhdHRyaWJ1dGlvbkNvbnRyb2wuYXBwZW5kQ2hpbGQoY2hpbGQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICB9XG4gIHB1YmxpYyBkb1Nob3coKSB7XG4gICAgdGhpcy5yZW5kZXJlci5hZGRDbGFzcyh0aGlzLm1hcENvbnRhaW5lci5uYXRpdmVFbGVtZW50LCAnc2hvdycpO1xuICAgIHRoaXMucmVuZGVyZXIuYWRkQ2xhc3ModGhpcy5vdmVybGF5Lm5hdGl2ZUVsZW1lbnQsICdmYWRlJyk7XG4gIH1cblxuICBwcml2YXRlIGluaXROYXZpZ2F0aW9uQ29udHJvbCgpIHtcbiAgICBpZiAodGhpcy5jb21iaW5lZE9wdGlvbnMoKT8ubmF2aWdhdGlvbkNvbnRyb2wgJiYgdGhpcy5tYXApIHtcbiAgICAgIGlmICghdGhpcy5uYXZpZ2F0aW9uQ29udHJvbCkge1xuICAgICAgICB0aGlzLm5hdmlnYXRpb25Db250cm9sID0gbmV3IE1hcGJveEdsLk5hdmlnYXRpb25Db250cm9sKCk7XG4gICAgICAgIHRoaXMubWFwLmFkZENvbnRyb2woXG4gICAgICAgICAgdGhpcy5uYXZpZ2F0aW9uQ29udHJvbCxcbiAgICAgICAgICB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLm5hdmlnYXRpb25Db250cm9sXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhdHRlbXB0SW5pdGlhbGlzYXRpb24oKSB7XG4gICAgaWYgKCF0aGlzLmNvbWJpbmVkT3B0aW9ucygpPy5hY2Nlc3NUb2tlbikge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAodGhpcy5lbGVtZW50UmVmICYmIHRoaXMubWFwUmVmICYmICF0aGlzLmlzSW5pdGlhbGlzZWQoKSkge1xuICAgICAgdGhpcy5pbml0aWFsaXNlQ29tcG9uZW50KCk7XG4gICAgICB0aGlzLmlzSW5pdGlhbGlzZWQuc2V0KHRydWUpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgaW5pdGlhbGlzZUNvbXBvbmVudCgpIHtcbiAgICB0aGlzLmluaXRNYXAoKTtcbiAgICBpZiAoXG4gICAgICAhdGhpcy5jb21iaW5lZE9wdGlvbnMoKT8uZGlzYWJsZVJlc2l6ZVRyYWNraW5nICYmXG4gICAgICAhdGhpcy5yZXNpemVPYnNlcnZlclxuICAgICkge1xuICAgICAgdGhpcy5yZXNpemVPYnNlcnZlciA9IG5ldyBSZXNpemVPYnNlcnZlcigoKSA9PiB7XG4gICAgICAgIHRoaXMubWFwPy5yZXNpemUoKTtcbiAgICAgIH0pO1xuICAgICAgdGhpcy5yZXNpemVPYnNlcnZlci5vYnNlcnZlKHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50KTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgZ2V0RGVja1Byb3BzKCkge1xuICAgIHJldHVybiB0aGlzLmRlY2suZ2V0UHJvcHMoKTtcbiAgfVxuXG4gIHB1YmxpYyBzZXREZWNrUHJvcHMocHJvcHM6IGFueSkge1xuICAgIGlmICh0aGlzLmRlY2suZGVjaygpKSB7XG4gICAgICB0aGlzLmRlY2suZGVjaygpPy5zZXRQcm9wcyhwcm9wcyk7XG4gICAgfVxuICAgIGNvbnN0IG92ZXJsYXkgPSB0aGlzLmRlY2suZGVja092ZXJsYXkoKTtcbiAgICBpZiAob3ZlcmxheSkge1xuICAgICAgb3ZlcmxheS5zZXRQcm9wcyhwcm9wcyk7XG4gICAgICAvLyB0aGlzLmRlY2suZGVja092ZXJsYXkoKT8uc2V0UHJvcHMocHJvcHMpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgaW5pdE1hcCgpIHtcbiAgICB0aGlzLnpvbmUucnVuT3V0c2lkZUFuZ3VsYXIoKCkgPT4ge1xuICAgICAgY29uc3Qgb3B0aW9ucyA9IHRoaXMuY29tYmluZWRPcHRpb25zKCk7XG4gICAgICBpZiAoIW9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgY29uc3QgbWFwT3B0aW9ucyA9IHtcbiAgICAgICAgY29udGFpbmVyOiB0aGlzLm1hcFJlZi5uYXRpdmVFbGVtZW50LFxuICAgICAgICAvLyBDaG9vc2UgZnJvbSBNYXBib3gncyBjb3JlIHN0eWxlcywgb3IgbWFrZSB5b3VyIG93biBzdHlsZSB3aXRoIE1hcGJveCBTdHVkaW9cbiAgICAgICAgc3R5bGU6IG9wdGlvbnM/LnN0eWxlID8/ICdtYXBib3g6Ly9zdHlsZXMvbWFwYm94L3N0YW5kYXJkJyxcbiAgICAgICAgYWNjZXNzVG9rZW46IG9wdGlvbnM/LmFjY2Vzc1Rva2VuLFxuICAgICAgICBhbnRpYWxpYXM6IG9wdGlvbnMuYW50aWFsaWFzLFxuICAgICAgICB0cmFja1Jlc2l6ZTogdHJ1ZSxcbiAgICAgICAgZG91YmxlQ2xpY2tab29tOiBmYWxzZSxcbiAgICAgICAgbWF4Wm9vbTogb3B0aW9ucy5tYXhab29tLFxuICAgICAgICBtYXhQaXRjaDogb3B0aW9ucy5tYXhQaXRjaCxcbiAgICAgICAgbWluWm9vbTogb3B0aW9ucy5taW5ab29tLFxuICAgICAgICBkcmFnUGFuOiBvcHRpb25zLmRyYWdQYW4sXG4gICAgICAgIGRyYWdSb3RhdGU6IG9wdGlvbnMuZHJhZ1JvdGF0ZSxcbiAgICAgICAgYXR0cmlidXRpb25Db250cm9sOiBvcHRpb25zLmF0dHJpYnV0aW9uQ29udHJvbCxcbiAgICAgICAgYmVhcmluZzogb3B0aW9ucy5iZWFyaW5nLFxuICAgICAgICBwcm9qZWN0aW9uOiB7XG4gICAgICAgICAgbmFtZTogb3B0aW9ucy5wcm9qZWN0aW9uLm5hbWUsXG4gICAgICAgICAgY2VudGVyOiBvcHRpb25zLmNlbnRlcixcbiAgICAgICAgICBwYXJhbGxlbHM6IG9wdGlvbnMucHJvamVjdGlvbi5wYXJhbGxlbHMsXG4gICAgICAgIH0sXG4gICAgICB9IGFzIGFueTtcbiAgICAgIGlmIChvcHRpb25zLmJvdW5kcykge1xuICAgICAgICBtYXBPcHRpb25zLmJvdW5kcyA9IG9wdGlvbnMuYm91bmRzO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbWFwT3B0aW9ucy5jZW50ZXIgPSBvcHRpb25zLmNlbnRlcjtcbiAgICAgICAgbWFwT3B0aW9ucy56b29tID0gb3B0aW9ucy56b29tO1xuICAgICAgfVxuICAgICAgdGhpcy5tYXAgPSBuZXcgTWFwYm94R2wuTWFwKG1hcE9wdGlvbnMpO1xuICAgICAgdGhpcy5jb250YWluZXIuc2V0KHRoaXMubWFwUmVmLm5hdGl2ZUVsZW1lbnQpO1xuICAgICAgdGhpcy5pbml0TmF2aWdhdGlvbkNvbnRyb2woKTtcbiAgICAgIHRoaXMubWFwLm9uKCdpZGxlJywgdGhpcy5ldmVudEhhbmRsZXJzLmxvYWQpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBvbk1hcE1vdXNlVXAoZXZlbnQ6IGFueSkge1xuICAgIGNvbnN0IGV2ZW50RGF0YTogSU1vdXNlVXBEb3duID0ge1xuICAgICAgbGF0aXR1ZGU6IGV2ZW50LmxuZ0xhdC5sbmcsXG4gICAgICBsb25naXR1ZGU6IGV2ZW50LmxuZ0xhdC5sYXQsXG4gICAgICBwb2ludDogZXZlbnQucG9pbnQsXG4gICAgICBvcmlnaW5hbEV2ZW50OiBldmVudC5vcmlnaW5hbEV2ZW50LFxuICAgICAgdHlwZTogJ21vdXNldXAnLFxuICAgIH07XG4gICAgdGhpcy5tb3VzZVVwU3ViamVjdC5uZXh0KGV2ZW50RGF0YSk7XG4gIH1cblxuICBwcml2YXRlIG9uTWFwTW91c2VEb3duKGV2ZW50OiBhbnkpIHtcbiAgICBjb25zdCBldmVudERhdGE6IElNb3VzZVVwRG93biA9IHtcbiAgICAgIGxhdGl0dWRlOiBldmVudC5sbmdMYXQubG5nLFxuICAgICAgbG9uZ2l0dWRlOiBldmVudC5sbmdMYXQubGF0LFxuICAgICAgcG9pbnQ6IGV2ZW50LnBvaW50LFxuICAgICAgb3JpZ2luYWxFdmVudDogZXZlbnQub3JpZ2luYWxFdmVudCxcbiAgICAgIHR5cGU6ICdtb3VzZWRvd24nLFxuICAgIH07XG4gICAgdGhpcy5tb3VzZURvd25TdWJqZWN0Lm5leHQoZXZlbnREYXRhKTtcbiAgICByYWNlKFtcbiAgICAgIHRoaXMubW91c2VVcCQsXG4gICAgICB0aGlzLnZpZXdTdGF0ZUNoYW5nZSQucGlwZShza2lwKDEpKSxcbiAgICAgIG9mKGV2ZW50KS5waXBlKGRlbGF5KHRoaXMuY29tYmluZWRPcHRpb25zKCk/LmxvbmdDbGlja0RlbGF5ID8/IDUwMCkpLFxuICAgIF0pXG4gICAgICAucGlwZSh0YWtlKDEpLCB0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSlcbiAgICAgIC5zdWJzY3JpYmUoZGF0YSA9PiB7XG4gICAgICAgIGlmIChcbiAgICAgICAgICAndHlwZScgaW4gZGF0YSAmJlxuICAgICAgICAgIChkYXRhLnR5cGUgPT09ICdtb3VzZWRvd24nIHx8IGRhdGEudHlwZSA9PT0gJ3RvdWNoc3RhcnQnKVxuICAgICAgICApIHtcbiAgICAgICAgICB0aGlzLmxvbmdDbGlja1N1YmplY3QubmV4dCh7XG4gICAgICAgICAgICBsYXRpdHVkZTogZXZlbnQubG5nTGF0LmxhdCxcbiAgICAgICAgICAgIGxvbmdpdHVkZTogZXZlbnQubG5nTGF0LmxuZyxcbiAgICAgICAgICAgIHBvaW50OiBldmVudC5wb2ludCxcbiAgICAgICAgICAgIHR5cGU6ICdtb3VzZWRvd24nLFxuICAgICAgICAgICAgb3JpZ2luYWxFdmVudDogZXZlbnQub3JpZ2luYWxFdmVudCxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gIH1cblxuICBwdWJsaWMgb25NYXBMb2FkKCkge1xuICAgIGlmICh0aGlzLmlzRGVzdHJveWVkIHx8ICF0aGlzLm1hcCB8fCB0aGlzLmlzTG9hZGVkKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgdGhpcy5tYXAub2ZmKCdpZGxlJywgdGhpcy5ldmVudEhhbmRsZXJzLmxvYWQpO1xuICAgIHRoaXMuaXNMb2FkZWQgPSB0cnVlO1xuICAgIHRoaXMub25Mb2FkLmVtaXQodGhpcyk7XG4gICAgdGhpcy5vbkxvYWRTdWJqZWN0Lm5leHQodGhpcyk7XG4gICAgaWYgKCF0aGlzLmNvbWJpbmVkT3B0aW9ucygpPy5pc0hpZGRlbk9uSW5pdGlhbExvYWQgJiYgdGhpcy5tYXBDb250YWluZXIpIHtcbiAgICAgIHRoaXMuZG9TaG93KCk7XG4gICAgfVxuICAgIGlmICh0aGlzLmRlY2sgJiYgIXRoaXMuZGVjay5pc0ludGVybGVhdmVkKSB7XG4gICAgICB0aGlzLmRlY2suZHJhZ1N0YXJ0JFxuICAgICAgICAucGlwZSh0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSlcbiAgICAgICAgLnN1YnNjcmliZSgoZGF0YTogYW55KSA9PiB7XG4gICAgICAgICAgdGhpcy5kcmFnU3RhcnRTdWJqZWN0Lm5leHQoe1xuICAgICAgICAgICAgbGF0aXR1ZGU6IGRhdGEuaW5mby5jb29yZGluYXRlWzFdLFxuICAgICAgICAgICAgbG9uZ2l0dWRlOiBkYXRhLmluZm8uY29vcmRpbmF0ZVswXSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG5cbiAgICAgIHRoaXMuZGVjay5tb3VzZWRvd24kXG4gICAgICAgIC5waXBlKFxuICAgICAgICAgIGNvbmNhdE1hcChkYXRhID0+IHtcbiAgICAgICAgICAgIHJldHVybiByYWNlKFtcbiAgICAgICAgICAgICAgdGhpcy5kZWNrLm1vdXNldXAkLFxuICAgICAgICAgICAgICB0aGlzLnZpZXdTdGF0ZUNoYW5nZSQucGlwZShza2lwKDEpLCB0YWtlKDEpKSxcbiAgICAgICAgICAgICAgb2YoZGF0YSkucGlwZShcbiAgICAgICAgICAgICAgICBkZWxheSh0aGlzLmNvbWJpbmVkT3B0aW9ucygpPy5sb25nQ2xpY2tEZWxheSA/PyA1MDApXG4gICAgICAgICAgICAgICksXG4gICAgICAgICAgICBdKS5waXBlKHRha2UoMSksIHRha2VVbnRpbERlc3Ryb3llZCh0aGlzLmRlc3Ryb3lSZWYpKTtcbiAgICAgICAgICB9KVxuICAgICAgICApXG4gICAgICAgIC5zdWJzY3JpYmUoZGF0YSA9PiB7XG4gICAgICAgICAgaWYgKCd0eXBlJyBpbiBkYXRhICYmIGRhdGEudHlwZSA9PT0gJ21vdXNlZG93bicpIHtcbiAgICAgICAgICAgIHRoaXMubG9uZ0NsaWNrU3ViamVjdC5uZXh0KGRhdGEpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB0aGlzLmRlY2sudmlld1N0YXRlQ2hhbmdlJFxuICAgICAgICAucGlwZSh0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSlcbiAgICAgICAgLnN1YnNjcmliZSh2aWV3U3RhdGUgPT4ge1xuICAgICAgICAgIHRoaXMubWFwIS5qdW1wVG8oe1xuICAgICAgICAgICAgY2VudGVyOiBbXG4gICAgICAgICAgICAgIHZpZXdTdGF0ZS52aWV3U3RhdGUubG9uZ2l0dWRlLFxuICAgICAgICAgICAgICB2aWV3U3RhdGUudmlld1N0YXRlLmxhdGl0dWRlLFxuICAgICAgICAgICAgXSxcbiAgICAgICAgICAgIHpvb206IHZpZXdTdGF0ZS52aWV3U3RhdGUuem9vbSxcbiAgICAgICAgICAgIGJlYXJpbmc6IHZpZXdTdGF0ZS52aWV3U3RhdGUuYmVhcmluZyA/PyAwLFxuICAgICAgICAgICAgcGl0Y2g6IHZpZXdTdGF0ZS52aWV3U3RhdGUucGl0Y2ggPz8gMCxcbiAgICAgICAgICB9KTtcbiAgICAgICAgICB0aGlzLnZpZXdTdGF0ZUNoYW5nZVN1YmplY3QubmV4dCh2aWV3U3RhdGUpO1xuICAgICAgICB9KTtcbiAgICAgIHRoaXMuZGVjay5ib3VuZHMkXG4gICAgICAgIC5waXBlKHRha2VVbnRpbERlc3Ryb3llZCh0aGlzLmRlc3Ryb3lSZWYpKVxuICAgICAgICAuc3Vic2NyaWJlKGJvdW5kcyA9PiB7XG4gICAgICAgICAgdGhpcy5ib3VuZHNTdWJqZWN0Lm5leHQoYm91bmRzKTtcbiAgICAgICAgfSk7XG4gICAgICB0aGlzLmRlY2sub25Mb2FkJFxuICAgICAgICAucGlwZSh0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSwgdGFrZSgxKSlcbiAgICAgICAgLnN1YnNjcmliZSgoKSA9PiB7XG4gICAgICAgICAgdGhpcy5pc0xvYWRpbmcuc2V0KGZhbHNlKTtcbiAgICAgICAgICB0aGlzLmVtaXRJbml0aWFsVmlld1N0YXRlKCk7XG4gICAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmlzTG9hZGluZy5zZXQoZmFsc2UpO1xuICAgICAgdGhpcy5lbWl0SW5pdGlhbFZpZXdTdGF0ZSgpO1xuICAgICAgdGhpcy5tYXAub24oJ21vdmUnLCB0aGlzLmV2ZW50SGFuZGxlcnNbJ21vdmUnXSk7XG4gICAgICB0aGlzLm1hcC5vbignbW91c2Vkb3duJywgdGhpcy5ldmVudEhhbmRsZXJzLm1vdXNlZG93bik7XG4gICAgICB0aGlzLm1hcC5vbigndG91Y2hzdGFydCcsIHRoaXMuZXZlbnRIYW5kbGVycy5tb3VzZWRvd24pO1xuICAgICAgdGhpcy5tYXAub24oJ21vdXNldXAnLCB0aGlzLmV2ZW50SGFuZGxlcnMubW91c2V1cCk7XG4gICAgICB0aGlzLm1hcC5vbigndG91Y2hlbmQnLCB0aGlzLmV2ZW50SGFuZGxlcnMubW91c2V1cCk7XG4gICAgICB0aGlzLm1hcC5vbignZHJhZ3N0YXJ0JywgdGhpcy5ldmVudEhhbmRsZXJzLmRyYWdzdGFydCk7XG5cbiAgICAgIC8vIHRoaXMub25NYXBNb3ZlKCk7XG4gICAgfVxuXG4gICAgLy8gT25seSBmb3IgZmV0Y2hpbmcgcGlwZWxpbmVzXG5cbiAgICBpZiAoXG4gICAgICB0aGlzLmNvbWJpbmVkT3B0aW9ucygpPy5pc1BpcGVsaW5lRGF0YUVtaXR0ZWQgJiZcbiAgICAgICF0aGlzLmlzRW1pdHRpbmdQaXBlbGluZXNcbiAgICApIHtcbiAgICAgIHRoaXMuaW5pdEVtaXR0aW5nUGlwZWxpbmVzKCk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG9uTWFwRHJhZ1N0YXJ0KGV2ZW50OiBhbnkpIHtcbiAgICBjb25zdCBjZW50ZXIgPSB0aGlzLm1hcD8uZ2V0Q2VudGVyKCk7XG4gICAgdGhpcy5kcmFnU3RhcnRTdWJqZWN0Lm5leHQoe1xuICAgICAgbGF0aXR1ZGU6IGNlbnRlcj8ubGF0ID8/IDAsXG4gICAgICBsb25naXR1ZGU6IGNlbnRlcj8ubG5nID8/IDAsXG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGluaXRFbWl0dGluZ1BpcGVsaW5lcygpIHtcbiAgICB0aGlzLmlzRW1pdHRpbmdQaXBlbGluZXMgPSB0cnVlO1xuXG4gICAgdGhpcy5waXBlbGluZUhlbHBlciA9IG5ldyBQaXBlbGluZUhlbHBlcih0aGlzKTtcbiAgICB0aGlzLnBpcGVsaW5lSGVscGVyLnBpcGVsaW5lJFxuICAgICAgLnBpcGUodGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZikpXG4gICAgICAuc3Vic2NyaWJlKGRhdGEgPT4ge1xuICAgICAgICB0aGlzLnBpcGVsaW5lRGF0YVN1YmplY3QubmV4dChkYXRhKTtcbiAgICAgIH0pO1xuICB9XG5cbiAgcHVibGljIHByb2plY3RMbmdMYXRUb1h5KGxuZ0xhdDogW251bWJlciwgbnVtYmVyXSk6IHsgeDogbnVtYmVyOyB5OiBudW1iZXIgfSB7XG4gICAgaWYgKCF0aGlzLm1hcCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdNYXAgaXMgbm90IGluaXRpYWxpemVkJyk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm1hcC5wcm9qZWN0KGxuZ0xhdCk7XG4gIH1cblxuICBwdWJsaWMgcHJvamVjdFh5VG9MbmdMYXQocG9pbnQ6IFBvaW50TGlrZSk6IExuZ0xhdCB7XG4gICAgaWYgKCF0aGlzLm1hcCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdNYXAgaXMgbm90IGluaXRpYWxpemVkJyk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLm1hcC51bnByb2plY3QocG9pbnQpO1xuICB9XG5cbiAgcHJpdmF0ZSBvbk1hcE1vdmUoKSB7XG4gICAgaWYgKCF0aGlzLm1hcCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCBjZW50ZXIgPSB0aGlzLm1hcC5nZXRDZW50ZXIoKTtcbiAgICBjb25zdCB6b29tID0gdGhpcy5tYXAuZ2V0Wm9vbSgpO1xuICAgIGNvbnN0IGJvdW5kcyA9IHRoaXMubWFwLmdldEJvdW5kcygpO1xuICAgIGNvbnN0IGNhbnZhcyA9IHRoaXMubWFwLmdldENhbnZhcygpO1xuICAgIGNvbnN0IG5ld1ZpZXdTdGF0ZSA9IHtcbiAgICAgIGxhdGl0dWRlOiBjZW50ZXIubGF0LFxuICAgICAgbG9uZ2l0dWRlOiBjZW50ZXIubG5nLFxuICAgICAgem9vbSxcbiAgICAgIHdpZHRoOiBjYW52YXMud2lkdGgsXG4gICAgICBoZWlnaHQ6IGNhbnZhcy5oZWlnaHQsXG4gICAgfTtcbiAgICB0aGlzLnZpZXdTdGF0ZUNoYW5nZVN1YmplY3QubmV4dCh7XG4gICAgICBvbGRWaWV3U3RhdGU6IHRoaXMucHJldmlvdXNNYXBib3hWaWV3U3RhdGUsXG4gICAgICB2aWV3U3RhdGU6IG5ld1ZpZXdTdGF0ZSxcbiAgICB9KTtcbiAgICB0aGlzLnByZXZpb3VzTWFwYm94Vmlld1N0YXRlID0gbmV3Vmlld1N0YXRlO1xuICAgIHRoaXMuYm91bmRzU3ViamVjdC5uZXh0KHRoaXMubWFwLmdldEJvdW5kcygpKTtcbiAgfVxuXG4gIHByaXZhdGUgZW1pdEluaXRpYWxWaWV3U3RhdGUoKSB7XG4gICAgaWYgKHRoaXMubWFwICYmICghdGhpcy5kZWNrIHx8IHRoaXMuZGVjay5pc0ludGVybGVhdmVkKSkge1xuICAgICAgdGhpcy52aWV3U3RhdGVDaGFuZ2VTdWJqZWN0Lm5leHQoe1xuICAgICAgICBvbGRWaWV3U3RhdGU6IHtcbiAgICAgICAgICBsYXRpdHVkZTogdGhpcy5tYXAuZ2V0Q2VudGVyKCkubGF0LFxuICAgICAgICAgIGxvbmdpdHVkZTogdGhpcy5tYXAuZ2V0Q2VudGVyKCkubG5nLFxuICAgICAgICAgIHpvb206IHRoaXMubWFwLmdldFpvb20oKSxcbiAgICAgICAgICB3aWR0aDogdGhpcy5tYXAuZ2V0Q2FudmFzKCkud2lkdGgsXG4gICAgICAgICAgaGVpZ2h0OiB0aGlzLm1hcC5nZXRDYW52YXMoKS5oZWlnaHQsXG4gICAgICAgIH0sXG4gICAgICAgIHZpZXdTdGF0ZToge1xuICAgICAgICAgIGxhdGl0dWRlOiB0aGlzLm1hcC5nZXRDZW50ZXIoKS5sYXQsXG4gICAgICAgICAgbG9uZ2l0dWRlOiB0aGlzLm1hcC5nZXRDZW50ZXIoKS5sbmcsXG4gICAgICAgICAgem9vbTogdGhpcy5tYXAuZ2V0Wm9vbSgpLFxuICAgICAgICAgIHdpZHRoOiB0aGlzLm1hcC5nZXRDYW52YXMoKS53aWR0aCxcbiAgICAgICAgICBoZWlnaHQ6IHRoaXMubWFwLmdldENhbnZhcygpLmhlaWdodCxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAodGhpcy5tYXApIHtcbiAgICAgIHRoaXMuYm91bmRzU3ViamVjdC5uZXh0KHRoaXMubWFwLmdldEJvdW5kcygpKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgZmx5VG8ob3B0aW9uczogSUZseVRvT3B0aW9ucykge1xuICAgIGlmICh0aGlzLmRlY2sgJiYgIXRoaXMuZGVjay5pc0ludGVybGVhdmVkKSB7XG4gICAgICBjb25zdCBvbGRWaWV3U3RhdGUgPSB7XG4gICAgICAgIC4uLnRoaXMuZGVjay5kZWNrKCkhLnByb3BzLmluaXRpYWxWaWV3U3RhdGUsXG4gICAgICB9O1xuICAgICAgY29uc3QgbmV3Vmlld1N0YXRlID0ge1xuICAgICAgICAuLi5vbGRWaWV3U3RhdGUsXG4gICAgICAgIGxhdGl0dWRlOiBvcHRpb25zLmxhdGl0dWRlLFxuICAgICAgICBsb25naXR1ZGU6IG9wdGlvbnMubG9uZ2l0dWRlLFxuICAgICAgICB6b29tOiBvcHRpb25zLnpvb20sXG4gICAgICB9O1xuICAgICAgdGhpcy5kZWNrLmRlY2soKSEuc2V0UHJvcHMoe1xuICAgICAgICBpbml0aWFsVmlld1N0YXRlOiB7XG4gICAgICAgICAgLi4ubmV3Vmlld1N0YXRlLFxuICAgICAgICAgIHRyYW5zaXRpb25EdXJhdGlvbjogb3B0aW9ucy50cmFuc2l0aW9uRHVyYXRpb24sXG4gICAgICAgICAgdHJhbnNpdGlvbkludGVycG9sYXRvcjogbmV3IEZseVRvSW50ZXJwb2xhdG9yKCksXG4gICAgICAgIH0sXG4gICAgICB9KTtcblxuICAgICAgaWYgKG9wdGlvbnMudHJhbnNpdGlvbkR1cmF0aW9uID09PSAwKSB7XG4gICAgICAgIHRoaXMuZGVjay5kZWNrKCkhLnByb3BzLm9uVmlld1N0YXRlQ2hhbmdlKHtcbiAgICAgICAgICBvbGRWaWV3U3RhdGUsXG4gICAgICAgICAgdmlld1N0YXRlOiBuZXdWaWV3U3RhdGUsXG4gICAgICAgICAgaW50ZXJhY3Rpb25TdGF0ZToge30sXG4gICAgICAgICAgdmlld0lkOiAnZGVmYXVsdC1tYXAtdmlldycsXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAodGhpcy5tYXApIHtcbiAgICAgIGNvbnN0IGZseVRvT3B0aW9uczogYW55ID0ge1xuICAgICAgICBjZW50ZXI6IFtvcHRpb25zLmxvbmdpdHVkZSwgb3B0aW9ucy5sYXRpdHVkZV0sXG4gICAgICAgIGVzc2VudGlhbDogdHJ1ZSxcbiAgICAgICAgem9vbTogb3B0aW9ucy56b29tLFxuICAgICAgfTtcbiAgICAgIGlmIChvcHRpb25zLnRyYW5zaXRpb25EdXJhdGlvbiAhPT0gJ2F1dG8nKSB7XG4gICAgICAgIGZseVRvT3B0aW9ucy5kdXJhdGlvbiA9IG9wdGlvbnMudHJhbnNpdGlvbkR1cmF0aW9uO1xuICAgICAgfVxuICAgICAgdGhpcy5tYXAuZmx5VG8oZmx5VG9PcHRpb25zKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHJlcG9zaXRpb25NYXAoKSB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHRoaXMuY29tYmluZWRPcHRpb25zKCk7XG4gICAgaWYgKHRoaXMubWFwICYmIG9wdGlvbnMpIHtcbiAgICAgIGlmICgnYm91bmRzJyBpbiBvcHRpb25zICYmIG9wdGlvbnMuYm91bmRzKSB7XG4gICAgICAgIHRoaXMubWFwLmZpdEJvdW5kcyhvcHRpb25zLmJvdW5kcywge1xuICAgICAgICAgIGFuaW1hdGU6IGZhbHNlXG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5tYXAuanVtcFRvKHtcbiAgICAgICAgICBjZW50ZXI6IG9wdGlvbnMuY2VudGVyLFxuICAgICAgICAgIHpvb206IG9wdGlvbnMuem9vbSxcbiAgICAgICAgfSk7XG4gICAgICB9XG5cbiAgICAgIHRoaXMub25NYXBNb3ZlKCk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIHRvZ2dsZURyYWdQYW4oaXNFbmFibGVkOiBib29sZWFuKSB7XG4gICAgaWYgKHRoaXMubWFwKSB7XG4gICAgICBpZiAoaXNFbmFibGVkKSB7XG4gICAgICAgIHRoaXMubWFwLmRyYWdQYW4uZW5hYmxlKCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLm1hcC5kcmFnUGFuLmRpc2FibGUoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBwdWJsaWMgbmdPbkRlc3Ryb3koKSB7XG4gICAgdGhpcy5jbGVhbnVwKCk7XG4gIH1cblxuICBwdWJsaWMgY2xlYW51cCgpIHtcbiAgICB0aGlzLmlzRGVzdHJveWVkID0gdHJ1ZTtcbiAgICB0aGlzLmlzRGVzdHJveWVkU3ViamVjdC5uZXh0KHRydWUpO1xuICAgIHRoaXMuaXNEZXN0cm95ZWRTdWJqZWN0LmNvbXBsZXRlKCk7XG4gICAgdGhpcy5waXBlbGluZURhdGFTdWJqZWN0LmNvbXBsZXRlKCk7XG4gICAgdGhpcy5vbkxvYWRTdWJqZWN0LmNvbXBsZXRlKCk7XG4gICAgdGhpcy52aWV3U3RhdGVDaGFuZ2VTdWJqZWN0LmNvbXBsZXRlKCk7XG4gICAgdGhpcy5ib3VuZHNTdWJqZWN0LmNvbXBsZXRlKCk7XG4gICAgZm9yIChsZXQga2V5IGluIHRoaXMuZXZlbnRIYW5kbGVycykge1xuICAgICAgaWYgKHRoaXMubWFwKSB7XG4gICAgICAgIHRoaXMubWFwLm9mZihrZXksIHRoaXMuZXZlbnRIYW5kbGVyc1trZXldKTtcbiAgICAgIH1cbiAgICB9XG4gICAgaWYgKHRoaXMuZGVjaykge1xuICAgICAgdGhpcy5kZWNrLmZpbmFsaXplKCk7XG4gICAgfVxuICAgIGlmICh0aGlzLnJlc2l6ZU9ic2VydmVyKSB7XG4gICAgICB0aGlzLnJlc2l6ZU9ic2VydmVyLnVub2JzZXJ2ZSh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCk7XG4gICAgICB0aGlzLnJlc2l6ZU9ic2VydmVyLmRpc2Nvbm5lY3QoKTtcbiAgICB9XG4gICAgaWYgKHRoaXMubWFwKSB7XG4gICAgICB0cnkge1xuICAgICAgICB0aGlzLm1hcC5yZW1vdmUoKTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgY29uc29sZS5sb2coZSk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwibWFwLW92ZXJsYXlcIiAjb3ZlcmxheT5cblxuPC9kaXY+XG48ZGl2IGNsYXNzPVwibWFwYm94LWNvbnRhaW5lclwiICNtYXBDb250YWluZXI+XG4gIDxkaXYgaWQ9XCJtYXBcIiBbbmdTdHlsZV09XCJ7ZmlsdGVyOiBnYW1tYUZpbHRlclVybH1cIiAjbWFwPjwvZGl2PlxuICA8bmctY29udGVudD48L25nLWNvbnRlbnQ+XG4gIDxkaXYgY2xhc3M9XCJhY3Rpb25zXCIgI2FjdGlvbnM+XG5cbiAgPC9kaXY+XG5cbiAgPHN2ZyBjbGFzcz1cImdhbW1hLW1hc2stc3ZnXCI+XG4gICAgPGZpbHRlciBpZD1cImdhbW1hLXt7aWR9fVwiIHByaW1pdGl2ZVVuaXRzPVwib2JqZWN0Qm91bmRpbmdCb3hcIiB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCIgeD1cIjBcIiB5PVwiMFwiPlxuICAgICAgPGZlQ29tcG9uZW50VHJhbnNmZXIgcmVzdWx0PVwiQURKVVNURURcIiB4PVwiMCVcIiB3aWR0aD1cIjEwMCVcIiBoZWlnaHQ9XCIxMDAlXCIgeT1cIjAlXCI+XG4gICAgICAgIDxmZUZ1bmNSXG4gICAgICAgICAgICBjbGFzcz1cImdhbW1hRWxlbWVudFwiXG4gICAgICAgICAgICB0eXBlPVwiZ2FtbWFcIlxuICAgICAgICAgICAgYW1wbGl0dWRlPVwiMVwiXG4gICAgICAgICAgICBleHBvbmVudD1cIjFcIlxuICAgICAgICAgICAgb2Zmc2V0PVwiMFwiXG4gICAgICAgIC8+XG4gICAgICAgIDxmZUZ1bmNHXG4gICAgICAgICAgICBjbGFzcz1cImdhbW1hRWxlbWVudFwiXG4gICAgICAgICAgICB0eXBlPVwiZ2FtbWFcIlxuICAgICAgICAgICAgYW1wbGl0dWRlPVwiMVwiXG4gICAgICAgICAgICBleHBvbmVudD1cIjFcIlxuICAgICAgICAgICAgb2Zmc2V0PVwiMFwiXG4gICAgICAgIC8+XG4gICAgICAgIDxmZUZ1bmNCXG4gICAgICAgICAgICBjbGFzcz1cImdhbW1hRWxlbWVudFwiXG4gICAgICAgICAgICB0eXBlPVwiZ2FtbWFcIlxuICAgICAgICAgICAgYW1wbGl0dWRlPVwiMVwiXG4gICAgICAgICAgICBleHBvbmVudD1cIjFcIlxuICAgICAgICAgICAgb2Zmc2V0PVwiMFwiXG4gICAgICAgIC8+XG4gICAgICA8L2ZlQ29tcG9uZW50VHJhbnNmZXI+XG5cbjwhLS0gICAgICA8ZmVDb21wb3NpdGUgaW4yPVwiU291cmNlR3JhcGhpY1wiIGluPVwiQURKVVNURURcIiBvcGVyYXRvcj1cIm92ZXJcIiByZXN1bHQ9XCJDT01QT1NJVEVcIj4tLT5cblxuPCEtLSAgICAgIDwvZmVDb21wb3NpdGU+LS0+XG4gICAgPC9maWx0ZXI+XG4gIDwvc3ZnPlxuPC9kaXY+XG4iXX0=