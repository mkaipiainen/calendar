/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/select" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-select.d.ts.map