import { OuiInputComponent } from './input.component';
import * as i0 from "@angular/core";
/**
 * Service used to control inputs.
 * Mainly used right now just to keep track of them and to set focus to inputs when clicking on them.
 */
export declare class OuiInputService {
    private document;
    private inputs;
    constructor(document: Document);
    defocusAll(): void;
    register(input: OuiInputComponent): void;
    deregister(input: OuiInputComponent): void;
    setFocus(input: OuiInputComponent, isFocused: boolean): void;
    setError(input: OuiInputComponent, hasError: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiInputService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiInputService>;
}
//# sourceMappingURL=input.service.d.ts.map