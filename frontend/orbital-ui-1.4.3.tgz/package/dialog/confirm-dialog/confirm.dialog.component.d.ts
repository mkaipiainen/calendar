import { OuiDialogComponent } from '../dialog.component';
import { OuiButtonVariant } from 'orbital-ui/button';
import * as i0 from "@angular/core";
/**
 * Represents a confirmation dialog component that extends OuiDialogComponent.
 * Displays a dialog box with a message asking the user to confirm or cancel an action.
 *
 */
export declare class OuiConfirmDialogComponent extends OuiDialogComponent {
    /**
     * The title of the confirmation dialog. Default is 'Are you sure?'.
     */
    title: string;
    /**
     * The message to display in the confirmation dialog. Default is 'Please either confirm or cancel.'.
     */
    content: string;
    /**
     * The label for the submit button. Default is 'Submit'.
     */
    submitLabel: string;
    /**
     * The label for the cancel button. Default is 'Cancel'.
     */
    cancelLabel: string;
    /**
     * The variant of the submit button
     */
    submitVariant: OuiButtonVariant;
    /**
     * The variant of the cancel button
     */
    cancelVariant: OuiButtonVariant;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiConfirmDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiConfirmDialogComponent, "oui-confirm-dialog", never, { "title": { "alias": "title"; "required": false; }; "content": { "alias": "content"; "required": false; }; "submitLabel": { "alias": "submitLabel"; "required": false; }; "cancelLabel": { "alias": "cancelLabel"; "required": false; }; "submitVariant": { "alias": "submitVariant"; "required": false; }; "cancelVariant": { "alias": "cancelVariant"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=confirm.dialog.component.d.ts.map