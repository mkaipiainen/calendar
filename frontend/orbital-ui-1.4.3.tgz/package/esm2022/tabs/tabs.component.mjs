import { ChangeDetectionStrategy, Component, computed, ContentChildren, effect, input, Input, signal, ViewChild, } from '@angular/core';
import { OuiTabComponent } from './tab.component';
import { NgTemplateOutlet } from '@angular/common';
import { filter } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { GUID } from 'orbital-ui/helpers';
import { merge } from 'lodash-es';
import * as i0 from "@angular/core";
import * as i1 from "./tabs.service";
export class OuiTabsComponent {
    tabService;
    elementRef;
    destroyRef;
    tabs;
    underline;
    id = GUID();
    options = input();
    defaultOptions = {
        variant: 'underlined',
        mode: 'standard',
    };
    combinedOptions = computed(() => {
        return merge({ ...this.defaultOptions }, this.options());
    });
    selectedTab = signal(undefined);
    constructor(tabService, elementRef, destroyRef) {
        this.tabService = tabService;
        this.elementRef = elementRef;
        this.destroyRef = destroyRef;
        this.tabService.registerTabs(this);
        effect(() => {
            if (this.tabs?.length) {
                for (const tab of this.tabs) {
                    tab.setOptions(this.combinedOptions());
                }
            }
        });
    }
    ngAfterViewInit() {
        this.tabs.changes
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(tabs => {
            const selectedTabIndex = tabs._results.findIndex((tab) => {
                return tab.id === this.selectedTab()?.id;
            });
            if (selectedTabIndex === -1) {
                this.tabService.selectTab(tabs.first);
            }
            this.setChildParentIds();
        });
        this.tabService.tabSelected$
            .pipe(takeUntilDestroyed(this.destroyRef), filter(tab => tab.parentId === this.id))
            .subscribe(tab => {
            this.selectedTab.set(tab);
            const tabRect = tab.elementRef.nativeElement.getBoundingClientRect();
            const parentRect = this.elementRef.nativeElement.getBoundingClientRect();
            const leftPercentage = (tabRect.left - parentRect.left) / parentRect.width;
            const widthPercentage = tabRect.width / 100;
            const translateXPixels = leftPercentage * parentRect.width;
            this.underline.nativeElement.style.transform = `translateX(${translateXPixels}px) scaleX(${widthPercentage})`;
        });
        for (const tab of this.tabs) {
            tab.parentId = this.id;
            tab.setOptions(this.combinedOptions());
        }
        this.tabService.selectTab(this.tabs.first);
    }
    setChildParentIds() {
        for (const tab of this.tabs) {
            tab.parentId = this.id;
            tab.setOptions(this.combinedOptions());
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTabsComponent, deps: [{ token: i1.OuiTabsService }, { token: i0.ElementRef }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiTabsComponent, isStandalone: true, selector: "oui-tabs", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: false, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null } }, queries: [{ propertyName: "tabs", predicate: OuiTabComponent, descendants: true }], viewQueries: [{ propertyName: "underline", first: true, predicate: ["underline"], descendants: true }], ngImport: i0, template: "<div class=\"tabs-container\">\n  <div class=\"tabs\">\n    <ng-content></ng-content>\n    @if (combinedOptions().variant === 'underlined') {\n      <div\n        class=\"tab-underline\"\n        >\n        <div class=\"tab-underline-bar\" #underline></div>\n      </div>\n    }\n  </div>\n  @if(selectedTab(); as tab) {\n    @if (combinedOptions().mode === 'standard') {\n      <div\n        class=\"content-area\"\n      >\n        <ng-container\n          *ngTemplateOutlet=\"tab.tabContentTemplate\"\n        ></ng-container>\n      </div>\n    }\n  }\n\n</div>\n", styles: [":host{position:relative}:host .tabs{position:relative;margin-bottom:var(--oui-tab-margin-bottom);display:flex}:host .tabs .tab-underline{flex:1;position:absolute;bottom:2px;left:0;height:2px;width:100%}:host .tabs .tab-underline .tab-underline-bar{position:absolute;left:0;top:0;width:100px;transition:transform .3s;height:100%;background-color:var(--color-accent);transform-origin:left}:host .content-area{max-height:max(100%,1000px)}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTabsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-tabs', standalone: true, imports: [NgTemplateOutlet], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"tabs-container\">\n  <div class=\"tabs\">\n    <ng-content></ng-content>\n    @if (combinedOptions().variant === 'underlined') {\n      <div\n        class=\"tab-underline\"\n        >\n        <div class=\"tab-underline-bar\" #underline></div>\n      </div>\n    }\n  </div>\n  @if(selectedTab(); as tab) {\n    @if (combinedOptions().mode === 'standard') {\n      <div\n        class=\"content-area\"\n      >\n        <ng-container\n          *ngTemplateOutlet=\"tab.tabContentTemplate\"\n        ></ng-container>\n      </div>\n    }\n  }\n\n</div>\n", styles: [":host{position:relative}:host .tabs{position:relative;margin-bottom:var(--oui-tab-margin-bottom);display:flex}:host .tabs .tab-underline{flex:1;position:absolute;bottom:2px;left:0;height:2px;width:100%}:host .tabs .tab-underline .tab-underline-bar{position:absolute;left:0;top:0;width:100px;transition:transform .3s;height:100%;background-color:var(--color-accent);transform-origin:left}:host .content-area{max-height:max(100%,1000px)}\n"] }]
        }], ctorParameters: () => [{ type: i1.OuiTabsService }, { type: i0.ElementRef }, { type: i0.DestroyRef }], propDecorators: { tabs: [{
                type: ContentChildren,
                args: [OuiTabComponent, { descendants: true }]
            }], underline: [{
                type: ViewChild,
                args: ['underline']
            }], id: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGFicy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3RhYnMvdGFicy5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3RhYnMvdGFicy5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBRUwsdUJBQXVCLEVBQ3ZCLFNBQVMsRUFBRSxRQUFRLEVBQ25CLGVBQWUsRUFDSCxNQUFNLEVBQ04sS0FBSyxFQUNqQixLQUFLLEVBQ00sTUFBTSxFQUNqQixTQUFTLEdBQ1YsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBRWxELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ25ELE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDOUIsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7QUFDaEUsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQzFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxXQUFXLENBQUM7OztBQWNsQyxNQUFNLE9BQU8sZ0JBQWdCO0lBZWpCO0lBQ0E7SUFDQTtJQWhCK0MsSUFBSSxDQUE2QjtJQUNsRSxTQUFTLENBQWE7SUFFckMsRUFBRSxHQUFHLElBQUksRUFBRSxDQUFDO0lBQ2QsT0FBTyxHQUFHLEtBQUssRUFBaUIsQ0FBQztJQUNoQyxjQUFjLEdBQWtCO1FBQ3RDLE9BQU8sRUFBRSxZQUFZO1FBQ3JCLElBQUksRUFBRSxVQUFVO0tBQ2pCLENBQUM7SUFDSyxlQUFlLEdBQUcsUUFBUSxDQUFDLEdBQUcsRUFBRTtRQUNyQyxPQUFPLEtBQUssQ0FBQyxFQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsRUFBQyxFQUFFLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO0lBQ3pELENBQUMsQ0FBQyxDQUFBO0lBQ0ssV0FBVyxHQUFHLE1BQU0sQ0FBNEIsU0FBUyxDQUFDLENBQUM7SUFDbEUsWUFDVSxVQUEwQixFQUMxQixVQUFzQixFQUN0QixVQUFzQjtRQUZ0QixlQUFVLEdBQVYsVUFBVSxDQUFnQjtRQUMxQixlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQ3RCLGVBQVUsR0FBVixVQUFVLENBQVk7UUFFOUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUM7UUFFbkMsTUFBTSxDQUFDLEdBQUcsRUFBRTtZQUNWLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxNQUFNLEVBQUUsQ0FBQztnQkFDdEIsS0FBSyxNQUFNLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQzVCLEdBQUcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7Z0JBQ3pDLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUE7SUFDSixDQUFDO0lBRU0sZUFBZTtRQUNwQixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU87YUFDZCxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ3pDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNoQixNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUM5QyxDQUFDLEdBQW9CLEVBQUUsRUFBRTtnQkFDdkIsT0FBTyxHQUFHLENBQUMsRUFBRSxLQUFLLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRSxFQUFFLENBQUM7WUFDM0MsQ0FBQyxDQUNGLENBQUM7WUFDRixJQUFJLGdCQUFnQixLQUFLLENBQUMsQ0FBQyxFQUFFLENBQUM7Z0JBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUN4QyxDQUFDO1lBQ0QsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUM7UUFDM0IsQ0FBQyxDQUFDLENBQUM7UUFDTCxJQUFJLENBQUMsVUFBVSxDQUFDLFlBQVk7YUFDekIsSUFBSSxDQUNILGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFDbkMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLFFBQVEsS0FBSyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQ3hDO2FBQ0EsU0FBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1lBQ2YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDMUIsTUFBTSxPQUFPLEdBQ1gsR0FBRyxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQztZQUN2RCxNQUFNLFVBQVUsR0FDZCxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1lBQ3hELE1BQU0sY0FBYyxHQUNsQixDQUFDLE9BQU8sQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUM7WUFDdEQsTUFBTSxlQUFlLEdBQUcsT0FBTyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7WUFDNUMsTUFBTSxnQkFBZ0IsR0FBRyxjQUFjLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQztZQUMzRCxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsU0FBUyxHQUFHLGNBQWMsZ0JBQWdCLGNBQWMsZUFBZSxHQUFHLENBQUM7UUFDaEgsQ0FBQyxDQUFDLENBQUM7UUFFTCxLQUFLLE1BQU0sR0FBRyxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztZQUM1QixHQUFHLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUM7WUFDdkIsR0FBRyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztRQUN6QyxDQUFDO1FBQ0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRU8saUJBQWlCO1FBQ3ZCLEtBQUssTUFBTSxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQzVCLEdBQUcsQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUN2QixHQUFHLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO1FBQ3pDLENBQUM7SUFDSCxDQUFDO3VHQTFFVSxnQkFBZ0I7MkZBQWhCLGdCQUFnQixtVkFDVixlQUFlLHdKQ2hDbEMseWpCQXdCQSwrZURJWSxnQkFBZ0I7OzJGQUdmLGdCQUFnQjtrQkFSNUIsU0FBUzsrQkFDRSxVQUFVLGNBR1IsSUFBSSxXQUNQLENBQUMsZ0JBQWdCLENBQUMsbUJBQ1YsdUJBQXVCLENBQUMsTUFBTTtxSUFHVSxJQUFJO3NCQUE1RCxlQUFlO3VCQUFDLGVBQWUsRUFBRSxFQUFFLFdBQVcsRUFBRSxJQUFJLEVBQUU7Z0JBQy9CLFNBQVM7c0JBQWhDLFNBQVM7dUJBQUMsV0FBVztnQkFFYixFQUFFO3NCQUFWLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcbiAgQ29tcG9uZW50LCBjb21wdXRlZCxcbiAgQ29udGVudENoaWxkcmVuLFxuICBEZXN0cm95UmVmLCBlZmZlY3QsXG4gIEVsZW1lbnRSZWYsIGlucHV0LFxuICBJbnB1dCxcbiAgUXVlcnlMaXN0LCBzaWduYWwsXG4gIFZpZXdDaGlsZCxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPdWlUYWJDb21wb25lbnQgfSBmcm9tICcuL3RhYi5jb21wb25lbnQnO1xuaW1wb3J0IHsgT3VpVGFic1NlcnZpY2UgfSBmcm9tICcuL3RhYnMuc2VydmljZSc7XG5pbXBvcnQgeyBOZ1RlbXBsYXRlT3V0bGV0IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IGZpbHRlciB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgdGFrZVVudGlsRGVzdHJveWVkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZS9yeGpzLWludGVyb3AnO1xuaW1wb3J0IHsgR1VJRCB9IGZyb20gJ29yYml0YWwtdWkvaGVscGVycyc7XG5pbXBvcnQgeyBtZXJnZSB9IGZyb20gJ2xvZGFzaC1lcyc7XG5cbmV4cG9ydCB0eXBlIE91aVRhYk9wdGlvbnMgPSB7XG4gIHZhcmlhbnQ6ICd1bmRlcmxpbmVkJyB8ICdib3JkZXJlZCc7XG4gIG1vZGU/OiAnc3RhbmRhcmQnIHwgJ29ubHktdGFicyc7XG59XG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdvdWktdGFicycsXG4gIHRlbXBsYXRlVXJsOiAnLi90YWJzLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vdGFicy5jb21wb25lbnQuc2NzcyddLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbTmdUZW1wbGF0ZU91dGxldF0sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoXG59KVxuZXhwb3J0IGNsYXNzIE91aVRhYnNDb21wb25lbnQgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0IHtcbiAgQENvbnRlbnRDaGlsZHJlbihPdWlUYWJDb21wb25lbnQsIHsgZGVzY2VuZGFudHM6IHRydWUgfSkgdGFiczogUXVlcnlMaXN0PE91aVRhYkNvbXBvbmVudD47XG4gIEBWaWV3Q2hpbGQoJ3VuZGVybGluZScpIHVuZGVybGluZTogRWxlbWVudFJlZjtcblxuICBASW5wdXQoKSBpZCA9IEdVSUQoKTtcbiAgcHVibGljIG9wdGlvbnMgPSBpbnB1dDxPdWlUYWJPcHRpb25zPigpO1xuICBwcml2YXRlIGRlZmF1bHRPcHRpb25zOiBPdWlUYWJPcHRpb25zID0ge1xuICAgIHZhcmlhbnQ6ICd1bmRlcmxpbmVkJyxcbiAgICBtb2RlOiAnc3RhbmRhcmQnLFxuICB9O1xuICBwdWJsaWMgY29tYmluZWRPcHRpb25zID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIHJldHVybiBtZXJnZSh7Li4udGhpcy5kZWZhdWx0T3B0aW9uc30sIHRoaXMub3B0aW9ucygpKTtcbiAgfSlcbiAgcHVibGljIHNlbGVjdGVkVGFiID0gc2lnbmFsPE91aVRhYkNvbXBvbmVudHx1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgdGFiU2VydmljZTogT3VpVGFic1NlcnZpY2UsXG4gICAgcHJpdmF0ZSBlbGVtZW50UmVmOiBFbGVtZW50UmVmLFxuICAgIHByaXZhdGUgZGVzdHJveVJlZjogRGVzdHJveVJlZlxuICApIHtcbiAgICB0aGlzLnRhYlNlcnZpY2UucmVnaXN0ZXJUYWJzKHRoaXMpO1xuXG4gICAgZWZmZWN0KCgpID0+IHtcbiAgICAgIGlmICh0aGlzLnRhYnM/Lmxlbmd0aCkge1xuICAgICAgICBmb3IgKGNvbnN0IHRhYiBvZiB0aGlzLnRhYnMpIHtcbiAgICAgICAgICB0YWIuc2V0T3B0aW9ucyh0aGlzLmNvbWJpbmVkT3B0aW9ucygpKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG4gIH1cblxuICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCkge1xuICAgIHRoaXMudGFicy5jaGFuZ2VzXG4gICAgICAucGlwZSh0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSlcbiAgICAgIC5zdWJzY3JpYmUodGFicyA9PiB7XG4gICAgICAgIGNvbnN0IHNlbGVjdGVkVGFiSW5kZXggPSB0YWJzLl9yZXN1bHRzLmZpbmRJbmRleChcbiAgICAgICAgICAodGFiOiBPdWlUYWJDb21wb25lbnQpID0+IHtcbiAgICAgICAgICAgIHJldHVybiB0YWIuaWQgPT09IHRoaXMuc2VsZWN0ZWRUYWIoKT8uaWQ7XG4gICAgICAgICAgfVxuICAgICAgICApO1xuICAgICAgICBpZiAoc2VsZWN0ZWRUYWJJbmRleCA9PT0gLTEpIHtcbiAgICAgICAgICB0aGlzLnRhYlNlcnZpY2Uuc2VsZWN0VGFiKHRhYnMuZmlyc3QpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuc2V0Q2hpbGRQYXJlbnRJZHMoKTtcbiAgICAgIH0pO1xuICAgIHRoaXMudGFiU2VydmljZS50YWJTZWxlY3RlZCRcbiAgICAgIC5waXBlKFxuICAgICAgICB0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSxcbiAgICAgICAgZmlsdGVyKHRhYiA9PiB0YWIucGFyZW50SWQgPT09IHRoaXMuaWQpXG4gICAgICApXG4gICAgICAuc3Vic2NyaWJlKHRhYiA9PiB7XG4gICAgICAgIHRoaXMuc2VsZWN0ZWRUYWIuc2V0KHRhYik7XG4gICAgICAgIGNvbnN0IHRhYlJlY3QgPVxuICAgICAgICAgIHRhYi5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICAgIGNvbnN0IHBhcmVudFJlY3QgPVxuICAgICAgICAgIHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICBjb25zdCBsZWZ0UGVyY2VudGFnZSA9XG4gICAgICAgICAgKHRhYlJlY3QubGVmdCAtIHBhcmVudFJlY3QubGVmdCkgLyBwYXJlbnRSZWN0LndpZHRoO1xuICAgICAgICBjb25zdCB3aWR0aFBlcmNlbnRhZ2UgPSB0YWJSZWN0LndpZHRoIC8gMTAwO1xuICAgICAgICBjb25zdCB0cmFuc2xhdGVYUGl4ZWxzID0gbGVmdFBlcmNlbnRhZ2UgKiBwYXJlbnRSZWN0LndpZHRoO1xuICAgICAgICB0aGlzLnVuZGVybGluZS5uYXRpdmVFbGVtZW50LnN0eWxlLnRyYW5zZm9ybSA9IGB0cmFuc2xhdGVYKCR7dHJhbnNsYXRlWFBpeGVsc31weCkgc2NhbGVYKCR7d2lkdGhQZXJjZW50YWdlfSlgO1xuICAgICAgfSk7XG5cbiAgICBmb3IgKGNvbnN0IHRhYiBvZiB0aGlzLnRhYnMpIHtcbiAgICAgIHRhYi5wYXJlbnRJZCA9IHRoaXMuaWQ7XG4gICAgICB0YWIuc2V0T3B0aW9ucyh0aGlzLmNvbWJpbmVkT3B0aW9ucygpKTtcbiAgICB9XG4gICAgdGhpcy50YWJTZXJ2aWNlLnNlbGVjdFRhYih0aGlzLnRhYnMuZmlyc3QpO1xuICB9XG5cbiAgcHJpdmF0ZSBzZXRDaGlsZFBhcmVudElkcygpIHtcbiAgICBmb3IgKGNvbnN0IHRhYiBvZiB0aGlzLnRhYnMpIHtcbiAgICAgIHRhYi5wYXJlbnRJZCA9IHRoaXMuaWQ7XG4gICAgICB0YWIuc2V0T3B0aW9ucyh0aGlzLmNvbWJpbmVkT3B0aW9ucygpKTtcbiAgICB9XG4gIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJ0YWJzLWNvbnRhaW5lclwiPlxuICA8ZGl2IGNsYXNzPVwidGFic1wiPlxuICAgIDxuZy1jb250ZW50PjwvbmctY29udGVudD5cbiAgICBAaWYgKGNvbWJpbmVkT3B0aW9ucygpLnZhcmlhbnQgPT09ICd1bmRlcmxpbmVkJykge1xuICAgICAgPGRpdlxuICAgICAgICBjbGFzcz1cInRhYi11bmRlcmxpbmVcIlxuICAgICAgICA+XG4gICAgICAgIDxkaXYgY2xhc3M9XCJ0YWItdW5kZXJsaW5lLWJhclwiICN1bmRlcmxpbmU+PC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICB9XG4gIDwvZGl2PlxuICBAaWYoc2VsZWN0ZWRUYWIoKTsgYXMgdGFiKSB7XG4gICAgQGlmIChjb21iaW5lZE9wdGlvbnMoKS5tb2RlID09PSAnc3RhbmRhcmQnKSB7XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzPVwiY29udGVudC1hcmVhXCJcbiAgICAgID5cbiAgICAgICAgPG5nLWNvbnRhaW5lclxuICAgICAgICAgICpuZ1RlbXBsYXRlT3V0bGV0PVwidGFiLnRhYkNvbnRlbnRUZW1wbGF0ZVwiXG4gICAgICAgID48L25nLWNvbnRhaW5lcj5cbiAgICAgIDwvZGl2PlxuICAgIH1cbiAgfVxuXG48L2Rpdj5cbiJdfQ==