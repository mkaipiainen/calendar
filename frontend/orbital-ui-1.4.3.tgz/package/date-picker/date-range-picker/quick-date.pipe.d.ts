import { PipeTransform } from '@angular/core';
import { IDateLabelTranslations } from '../date-picker/date-picker.component';
import * as i0 from "@angular/core";
export declare class QuickDatePipe implements PipeTransform {
    transform(value: Date | undefined, translations: IDateLabelTranslations): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<QuickDatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<QuickDatePipe, "quickDate", true>;
}
//# sourceMappingURL=quick-date.pipe.d.ts.map