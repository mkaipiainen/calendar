import { Inject, Injectable, } from '@angular/core';
import { OuiToastComponent } from './toast.component';
import { DOCUMENT } from '@angular/common';
import { GUID } from 'orbital-ui/helpers';
import { ComponentCreator } from 'orbital-ui/helpers';
import * as i0 from "@angular/core";
/**
 * Service used to display toast-messages to the user. These are messages that usually happen in response to a user-action,
 * for example saving an entity, or creating a new one, or deleting an existign one, etc.
 *
 * You can decide which corner the toast appears in, as well as things like the duration, the type of the toast, and the content.
 * Generally you only want to pass in strings as the content, but in cases where you need something totally unique, you can pass in a
 * component as well.
 *
 * Usage-example:
 *
 * this.ouiToastService.open({
 *   type: 'success',
 *   content: 'Succesfully saved the entity!',
 *   duration: 5000
 * });
 */
export class OuiToastService {
    injector;
    appRef;
    rendererFactory;
    document;
    defaultOptions = {
        duration: 3000,
        hideOnClick: true,
        xToClose: false,
        position: 'top-right',
    };
    currentToasts = new Map();
    currentToastWrappers = new Map();
    renderer;
    constructor(injector, appRef, rendererFactory, document) {
        this.injector = injector;
        this.appRef = appRef;
        this.rendererFactory = rendererFactory;
        this.document = document;
        this.renderer = rendererFactory.createRenderer(null, null);
    }
    open(options, inputs, parent) {
        const combinedOptions = {
            id: GUID(),
            ...this.defaultOptions,
            ...options,
        };
        if (typeof combinedOptions.position == 'string') {
            if (!this.currentToastWrappers.has(combinedOptions.position)) {
                this.currentToastWrappers.set(combinedOptions.position, this.createWrapper(combinedOptions.position));
            }
            this.createToast(this.currentToastWrappers.get(combinedOptions.position), combinedOptions, inputs);
        }
        else if (parent) {
            this.createToast(parent.nativeElement, combinedOptions, inputs);
        }
        else {
            this.createToast(this.document.body, combinedOptions, inputs);
        }
    }
    createWrapper(position) {
        const TOASTR_DISTANCE = '5rem';
        const wrapper = this.renderer.createElement('div');
        this.renderer.addClass(wrapper, 'toastr-wrapper');
        this.renderer.setStyle(wrapper, 'display', 'flex');
        this.renderer.setStyle(wrapper, 'flexDirection', 'column');
        this.renderer.setStyle(wrapper, 'position', 'fixed');
        this.renderer.setStyle(wrapper, 'zIndex', '9999');
        switch (position) {
            case 'top':
                this.renderer.setStyle(wrapper, 'top', TOASTR_DISTANCE);
                this.renderer.setStyle(wrapper, 'left', this.document.body.getBoundingClientRect().width / 2 + 'px');
                this.renderer.setStyle(wrapper, 'transform', 'translateX(-50%)');
                break;
            case 'top-right':
                this.renderer.setStyle(wrapper, 'top', TOASTR_DISTANCE);
                this.renderer.setStyle(wrapper, 'right', TOASTR_DISTANCE);
                break;
            case 'top-left':
                this.renderer.setStyle(wrapper, 'top', TOASTR_DISTANCE);
                this.renderer.setStyle(wrapper, 'left', TOASTR_DISTANCE);
                break;
            case 'bottom':
                this.renderer.setStyle(wrapper, 'bottom', TOASTR_DISTANCE);
                this.renderer.setStyle(wrapper, 'left', this.document.body.getBoundingClientRect().width / 2 + 'px');
                this.renderer.setStyle(wrapper, 'transform', 'translateX(-50%)');
                break;
            case 'bottom-right':
                this.renderer.setStyle(wrapper, 'bottom', TOASTR_DISTANCE);
                this.renderer.setStyle(wrapper, 'right', TOASTR_DISTANCE);
                break;
            case 'bottom-left':
                this.renderer.setStyle(wrapper, 'bottom', TOASTR_DISTANCE);
                this.renderer.setStyle(wrapper, 'left', TOASTR_DISTANCE);
                break;
            case 'center':
                this.renderer.setStyle(wrapper, 'top', this.document.body.getBoundingClientRect().height / 2 -
                    wrapper.getBoundingClientRect().height / 2 +
                    'px');
                this.renderer.setStyle(wrapper, 'left', this.document.body.getBoundingClientRect().width / 2 + 'px');
                this.renderer.setStyle(wrapper, 'transform', 'translateX(-50%)');
                break;
            default:
                console.log('invalid position given for toast');
        }
        this.renderer.appendChild(this.document.body, wrapper);
        return wrapper;
    }
    createToast(wrapper, combinedOptions, inputs) {
        if (inputs) {
            combinedOptions.inputs = inputs;
        }
        const createComponentOptions = {
            component: OuiToastComponent,
            parentElement: wrapper,
            appRef: this.appRef,
            createComponentOptions: {
                environmentInjector: this.injector,
            },
            inputs: {
                options: combinedOptions,
            },
        };
        const componentRef = ComponentCreator.createComponent(createComponentOptions);
        if (typeof combinedOptions.position != 'string') {
            this.renderer.setStyle(componentRef.location.nativeElement, 'left', `${combinedOptions.position.x}px`);
            this.renderer.setStyle(componentRef.location.nativeElement, 'top', `${combinedOptions.position.y}px`);
            this.renderer.setStyle(componentRef.location.nativeElement, 'position', 'fixed');
        }
        setTimeout(() => {
            this.renderer.addClass(componentRef.location.nativeElement, 'show');
        });
        this.currentToasts.set(combinedOptions.id, componentRef);
        componentRef.changeDetectorRef.detectChanges();
        setTimeout(() => this.disable(combinedOptions.id), combinedOptions.duration);
    }
    disable(id) {
        const toast = this.currentToasts.get(id);
        if (!toast) {
            return;
        }
        const options = toast.instance.options;
        if (options.position === 'top-right' ||
            options.position === 'bottom-right') {
            this.renderer.addClass(toast.location.nativeElement, 'remove-to-right');
        }
        else if (options.position === 'top') {
            this.renderer.addClass(toast.location.nativeElement, 'remove-to-top');
        }
        else if (options.position === 'top-left' ||
            options.position === 'bottom-left') {
            this.renderer.addClass(toast.location.nativeElement, 'remove-to-left');
        }
        else if (options.position === 'bottom') {
            this.renderer.addClass(toast.location.nativeElement, 'remove-to-bottom');
        }
        this.renderer.removeClass(toast.location.nativeElement, 'show');
        setTimeout(() => {
            if (!this.currentToasts.has(id)) {
                return;
            }
            toast.destroy();
            this.currentToasts.delete(id);
        }, 1000);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiToastService, deps: [{ token: i0.EnvironmentInjector }, { token: i0.ApplicationRef }, { token: i0.RendererFactory2 }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiToastService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiToastService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i0.EnvironmentInjector }, { type: i0.ApplicationRef }, { type: i0.RendererFactory2 }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidG9hc3Quc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvdG9hc3QvdG9hc3Quc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBS0wsTUFBTSxFQUNOLFVBQVUsR0FHWCxNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUV0RCxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDM0MsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQzFDLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLG9CQUFvQixDQUFDOztBQTJDdEQ7Ozs7Ozs7Ozs7Ozs7OztHQWVHO0FBSUgsTUFBTSxPQUFPLGVBQWU7SUFjaEI7SUFDQTtJQUNBO0lBQ2tCO0lBaEJyQixjQUFjLEdBQTRCO1FBQy9DLFFBQVEsRUFBRSxJQUFJO1FBQ2QsV0FBVyxFQUFFLElBQUk7UUFDakIsUUFBUSxFQUFFLEtBQUs7UUFDZixRQUFRLEVBQUUsV0FBVztLQUN0QixDQUFDO0lBRUssYUFBYSxHQUNsQixJQUFJLEdBQUcsRUFBRSxDQUFDO0lBQ0wsb0JBQW9CLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQztJQUNoQyxRQUFRLENBQVk7SUFFNUIsWUFDVSxRQUE2QixFQUM3QixNQUFzQixFQUN0QixlQUFpQyxFQUNmLFFBQWtCO1FBSHBDLGFBQVEsR0FBUixRQUFRLENBQXFCO1FBQzdCLFdBQU0sR0FBTixNQUFNLENBQWdCO1FBQ3RCLG9CQUFlLEdBQWYsZUFBZSxDQUFrQjtRQUNmLGFBQVEsR0FBUixRQUFRLENBQVU7UUFFNUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxlQUFlLENBQUMsY0FBYyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBRU0sSUFBSSxDQUNULE9BQXlCLEVBQ3pCLE1BQWlDLEVBQ2pDLE1BQW1CO1FBRW5CLE1BQU0sZUFBZSxHQUE2QjtZQUNoRCxFQUFFLEVBQUUsSUFBSSxFQUFFO1lBQ1YsR0FBRyxJQUFJLENBQUMsY0FBYztZQUN0QixHQUFHLE9BQU87U0FDWCxDQUFDO1FBRUYsSUFBSSxPQUFPLGVBQWUsQ0FBQyxRQUFRLElBQUksUUFBUSxFQUFFLENBQUM7WUFDaEQsSUFBSSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUM7Z0JBQzdELElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQzNCLGVBQWUsQ0FBQyxRQUFRLEVBQ3hCLElBQUksQ0FBQyxhQUFhLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxDQUM3QyxDQUFDO1lBQ0osQ0FBQztZQUNELElBQUksQ0FBQyxXQUFXLENBQ2QsSUFBSSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLEVBQ3ZELGVBQWUsRUFDZixNQUFNLENBQ1AsQ0FBQztRQUNKLENBQUM7YUFBTSxJQUFJLE1BQU0sRUFBRSxDQUFDO1lBQ2xCLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLGFBQWEsRUFBRSxlQUFlLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDbEUsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLGVBQWUsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUNoRSxDQUFDO0lBQ0gsQ0FBQztJQUVPLGFBQWEsQ0FBQyxRQUFnQjtRQUNwQyxNQUFNLGVBQWUsR0FBRyxNQUFNLENBQUM7UUFDL0IsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbkQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLGdCQUFnQixDQUFDLENBQUM7UUFDbEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsZUFBZSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxVQUFVLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDckQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLENBQUMsQ0FBQztRQUVsRCxRQUFRLFFBQVEsRUFBRSxDQUFDO1lBQ2pCLEtBQUssS0FBSztnQkFDUixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFLGVBQWUsQ0FBQyxDQUFDO2dCQUN4RCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FDcEIsT0FBTyxFQUNQLE1BQU0sRUFDTixJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUM1RCxDQUFDO2dCQUNGLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxXQUFXLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztnQkFDakUsTUFBTTtZQUNSLEtBQUssV0FBVztnQkFDZCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFLGVBQWUsQ0FBQyxDQUFDO2dCQUN4RCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLGVBQWUsQ0FBQyxDQUFDO2dCQUMxRCxNQUFNO1lBQ1IsS0FBSyxVQUFVO2dCQUNiLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBQ3hELElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBQ3pELE1BQU07WUFDUixLQUFLLFFBQVE7Z0JBQ1gsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxlQUFlLENBQUMsQ0FBQztnQkFDM0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQ3BCLE9BQU8sRUFDUCxNQUFNLEVBQ04sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FDNUQsQ0FBQztnQkFDRixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxPQUFPLEVBQUUsV0FBVyxFQUFFLGtCQUFrQixDQUFDLENBQUM7Z0JBQ2pFLE1BQU07WUFDUixLQUFLLGNBQWM7Z0JBQ2pCLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBQzNELElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBQzFELE1BQU07WUFDUixLQUFLLGFBQWE7Z0JBQ2hCLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxRQUFRLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBQzNELElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUUsZUFBZSxDQUFDLENBQUM7Z0JBQ3pELE1BQU07WUFDUixLQUFLLFFBQVE7Z0JBQ1gsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQ3BCLE9BQU8sRUFDUCxLQUFLLEVBQ0wsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLEdBQUcsQ0FBQztvQkFDbkQsT0FBTyxDQUFDLHFCQUFxQixFQUFFLENBQUMsTUFBTSxHQUFHLENBQUM7b0JBQzFDLElBQUksQ0FDUCxDQUFDO2dCQUNGLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUNwQixPQUFPLEVBQ1AsTUFBTSxFQUNOLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQzVELENBQUM7Z0JBQ0YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO2dCQUNqRSxNQUFNO1lBQ1I7Z0JBQ0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO1FBQ3BELENBQUM7UUFDRCxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztRQUN2RCxPQUFPLE9BQU8sQ0FBQztJQUNqQixDQUFDO0lBRU8sV0FBVyxDQUNqQixPQUFvQixFQUNwQixlQUF5QyxFQUN6QyxNQUFpQztRQUVqQyxJQUFJLE1BQU0sRUFBRSxDQUFDO1lBQ1gsZUFBZSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUM7UUFDbEMsQ0FBQztRQUNELE1BQU0sc0JBQXNCLEdBQUc7WUFDN0IsU0FBUyxFQUFFLGlCQUFpQjtZQUM1QixhQUFhLEVBQUUsT0FBTztZQUN0QixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07WUFDbkIsc0JBQXNCLEVBQUU7Z0JBQ3RCLG1CQUFtQixFQUFFLElBQUksQ0FBQyxRQUFRO2FBQ25DO1lBQ0QsTUFBTSxFQUFFO2dCQUNOLE9BQU8sRUFBRSxlQUFlO2FBQ3pCO1NBQ0YsQ0FBQztRQUNGLE1BQU0sWUFBWSxHQUFHLGdCQUFnQixDQUFDLGVBQWUsQ0FDbkQsc0JBQXNCLENBQ3ZCLENBQUM7UUFFRixJQUFJLE9BQU8sZUFBZSxDQUFDLFFBQVEsSUFBSSxRQUFRLEVBQUUsQ0FBQztZQUNoRCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FDcEIsWUFBWSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQ25DLE1BQU0sRUFDTixHQUFHLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQ2xDLENBQUM7WUFDRixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FDcEIsWUFBWSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQ25DLEtBQUssRUFDTCxHQUFHLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQ2xDLENBQUM7WUFDRixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FDcEIsWUFBWSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQ25DLFVBQVUsRUFDVixPQUFPLENBQ1IsQ0FBQztRQUNKLENBQUM7UUFFRCxVQUFVLENBQUMsR0FBRyxFQUFFO1lBQ2QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDdEUsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsRUFBRSxFQUFFLFlBQVksQ0FBQyxDQUFDO1FBQ3pELFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUUvQyxVQUFVLENBQ1IsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsRUFBRSxDQUFDLEVBQ3RDLGVBQWUsQ0FBQyxRQUFRLENBQ3pCLENBQUM7SUFDSixDQUFDO0lBRU0sT0FBTyxDQUFDLEVBQVU7UUFDdkIsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDekMsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQ1gsT0FBTztRQUNULENBQUM7UUFDRCxNQUFNLE9BQU8sR0FBRyxLQUFLLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztRQUN2QyxJQUNFLE9BQU8sQ0FBQyxRQUFRLEtBQUssV0FBVztZQUNoQyxPQUFPLENBQUMsUUFBUSxLQUFLLGNBQWMsRUFDbkMsQ0FBQztZQUNELElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxFQUFFLGlCQUFpQixDQUFDLENBQUM7UUFDMUUsQ0FBQzthQUFNLElBQUksT0FBTyxDQUFDLFFBQVEsS0FBSyxLQUFLLEVBQUUsQ0FBQztZQUN0QyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxlQUFlLENBQUMsQ0FBQztRQUN4RSxDQUFDO2FBQU0sSUFDTCxPQUFPLENBQUMsUUFBUSxLQUFLLFVBQVU7WUFDL0IsT0FBTyxDQUFDLFFBQVEsS0FBSyxhQUFhLEVBQ2xDLENBQUM7WUFDRCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ3pFLENBQUM7YUFBTSxJQUFJLE9BQU8sQ0FBQyxRQUFRLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDekMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztRQUMzRSxDQUFDO1FBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxhQUFhLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDaEUsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDO2dCQUNoQyxPQUFPO1lBQ1QsQ0FBQztZQUNELEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNoQixJQUFJLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNoQyxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDWCxDQUFDO3VHQXpNVSxlQUFlLG1IQWlCaEIsUUFBUTsyR0FqQlAsZUFBZSxjQUZkLE1BQU07OzJGQUVQLGVBQWU7a0JBSDNCLFVBQVU7bUJBQUM7b0JBQ1YsVUFBVSxFQUFFLE1BQU07aUJBQ25COzswQkFrQkksTUFBTTsyQkFBQyxRQUFRIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQXBwbGljYXRpb25SZWYsXG4gIENvbXBvbmVudFJlZixcbiAgRWxlbWVudFJlZixcbiAgRW52aXJvbm1lbnRJbmplY3RvcixcbiAgSW5qZWN0LFxuICBJbmplY3RhYmxlLFxuICBSZW5kZXJlcjIsXG4gIFJlbmRlcmVyRmFjdG9yeTIsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgT3VpVG9hc3RDb21wb25lbnQgfSBmcm9tICcuL3RvYXN0LmNvbXBvbmVudCc7XG5pbXBvcnQgeyBDb21wb25lbnRUeXBlIH0gZnJvbSAnQGFuZ3VsYXIvY2RrL292ZXJsYXknO1xuaW1wb3J0IHsgRE9DVU1FTlQgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgR1VJRCB9IGZyb20gJ29yYml0YWwtdWkvaGVscGVycyc7XG5pbXBvcnQgeyBDb21wb25lbnRDcmVhdG9yIH0gZnJvbSAnb3JiaXRhbC11aS9oZWxwZXJzJztcblxuZXhwb3J0IHR5cGUgSVRvYXN0VHlwZSA9ICdzdWNjZXNzJyB8ICdlcnJvcicgfCAnd2FybmluZycgfCAnaW5mbyc7XG5leHBvcnQgdHlwZSBJVG9hc3RQb3NpdGlvbiA9IElUb2FzdEZpeGVkUG9zaXRpb24gfCBJVG9hc3RIYXJkY29kZWRQb3NpdGlvbjtcbmV4cG9ydCB0eXBlIElUb2FzdEZpeGVkUG9zaXRpb24gPSB7XG4gIHg6IG51bWJlcjtcbiAgeTogbnVtYmVyO1xufTtcbmV4cG9ydCB0eXBlIElUb2FzdEhhcmRjb2RlZFBvc2l0aW9uID1cbiAgfCAndG9wLWxlZnQnXG4gIHwgJ3RvcC1yaWdodCdcbiAgfCAndG9wJ1xuICB8ICdib3R0b20tbGVmdCdcbiAgfCAnYm90dG9tLXJpZ2h0J1xuICB8ICdib3R0b20nXG4gIHwgJ2NlbnRlcic7XG5leHBvcnQgaW50ZXJmYWNlIElPdWlUb2FzdE9wdGlvbnMge1xuICB0eXBlOiBJVG9hc3RUeXBlO1xuICBkdXJhdGlvbj86IG51bWJlcjtcbiAgaGlkZU9uQ2xpY2s/OiBib29sZWFuO1xuICB4VG9DbG9zZT86IGJvb2xlYW47XG4gIGlkPzogc3RyaW5nO1xuICB0aXRsZT86IHN0cmluZztcbiAgcG9zaXRpb24/OiBJVG9hc3RQb3NpdGlvbjtcbiAgY29udGVudDogc3RyaW5nIHwgQ29tcG9uZW50VHlwZTxhbnk+O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElPdWlUb2FzdERlZmF1bHRPcHRpb25zIHtcbiAgcG9zaXRpb246IElUb2FzdFBvc2l0aW9uO1xuICB4VG9DbG9zZTogYm9vbGVhbjtcbiAgaGlkZU9uQ2xpY2s6IGJvb2xlYW47XG4gIGR1cmF0aW9uOiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSUNvbWJpbmVkT3VpVG9hc3RPcHRpb25zIGV4dGVuZHMgSU91aVRvYXN0T3B0aW9ucyB7XG4gIGR1cmF0aW9uOiBudW1iZXI7XG4gIGhpZGVPbkNsaWNrOiBib29sZWFuO1xuICB4VG9DbG9zZTogYm9vbGVhbjtcbiAgcG9zaXRpb246IElUb2FzdFBvc2l0aW9uO1xuICBpZDogc3RyaW5nO1xuICBpbnB1dHM/OiB7IFt4OiBzdHJpbmddOiB1bmtub3duIH07XG59XG5cbi8qKlxuICogU2VydmljZSB1c2VkIHRvIGRpc3BsYXkgdG9hc3QtbWVzc2FnZXMgdG8gdGhlIHVzZXIuIFRoZXNlIGFyZSBtZXNzYWdlcyB0aGF0IHVzdWFsbHkgaGFwcGVuIGluIHJlc3BvbnNlIHRvIGEgdXNlci1hY3Rpb24sXG4gKiBmb3IgZXhhbXBsZSBzYXZpbmcgYW4gZW50aXR5LCBvciBjcmVhdGluZyBhIG5ldyBvbmUsIG9yIGRlbGV0aW5nIGFuIGV4aXN0aWduIG9uZSwgZXRjLlxuICpcbiAqIFlvdSBjYW4gZGVjaWRlIHdoaWNoIGNvcm5lciB0aGUgdG9hc3QgYXBwZWFycyBpbiwgYXMgd2VsbCBhcyB0aGluZ3MgbGlrZSB0aGUgZHVyYXRpb24sIHRoZSB0eXBlIG9mIHRoZSB0b2FzdCwgYW5kIHRoZSBjb250ZW50LlxuICogR2VuZXJhbGx5IHlvdSBvbmx5IHdhbnQgdG8gcGFzcyBpbiBzdHJpbmdzIGFzIHRoZSBjb250ZW50LCBidXQgaW4gY2FzZXMgd2hlcmUgeW91IG5lZWQgc29tZXRoaW5nIHRvdGFsbHkgdW5pcXVlLCB5b3UgY2FuIHBhc3MgaW4gYVxuICogY29tcG9uZW50IGFzIHdlbGwuXG4gKlxuICogVXNhZ2UtZXhhbXBsZTpcbiAqXG4gKiB0aGlzLm91aVRvYXN0U2VydmljZS5vcGVuKHtcbiAqICAgdHlwZTogJ3N1Y2Nlc3MnLFxuICogICBjb250ZW50OiAnU3VjY2VzZnVsbHkgc2F2ZWQgdGhlIGVudGl0eSEnLFxuICogICBkdXJhdGlvbjogNTAwMFxuICogfSk7XG4gKi9cbkBJbmplY3RhYmxlKHtcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlUb2FzdFNlcnZpY2Uge1xuICBwdWJsaWMgZGVmYXVsdE9wdGlvbnM6IElPdWlUb2FzdERlZmF1bHRPcHRpb25zID0ge1xuICAgIGR1cmF0aW9uOiAzMDAwLFxuICAgIGhpZGVPbkNsaWNrOiB0cnVlLFxuICAgIHhUb0Nsb3NlOiBmYWxzZSxcbiAgICBwb3NpdGlvbjogJ3RvcC1yaWdodCcsXG4gIH07XG5cbiAgcHVibGljIGN1cnJlbnRUb2FzdHM6IE1hcDxzdHJpbmcsIENvbXBvbmVudFJlZjxPdWlUb2FzdENvbXBvbmVudD4+ID1cbiAgICBuZXcgTWFwKCk7XG4gIHB1YmxpYyBjdXJyZW50VG9hc3RXcmFwcGVycyA9IG5ldyBNYXAoKTtcbiAgcHJpdmF0ZSByZW5kZXJlcjogUmVuZGVyZXIyO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgaW5qZWN0b3I6IEVudmlyb25tZW50SW5qZWN0b3IsXG4gICAgcHJpdmF0ZSBhcHBSZWY6IEFwcGxpY2F0aW9uUmVmLFxuICAgIHByaXZhdGUgcmVuZGVyZXJGYWN0b3J5OiBSZW5kZXJlckZhY3RvcnkyLFxuICAgIEBJbmplY3QoRE9DVU1FTlQpIHByaXZhdGUgZG9jdW1lbnQ6IERvY3VtZW50XG4gICkge1xuICAgIHRoaXMucmVuZGVyZXIgPSByZW5kZXJlckZhY3RvcnkuY3JlYXRlUmVuZGVyZXIobnVsbCwgbnVsbCk7XG4gIH1cblxuICBwdWJsaWMgb3BlbihcbiAgICBvcHRpb25zOiBJT3VpVG9hc3RPcHRpb25zLFxuICAgIGlucHV0cz86IHsgW3g6IHN0cmluZ106IHVua25vd24gfSxcbiAgICBwYXJlbnQ/OiBFbGVtZW50UmVmXG4gICkge1xuICAgIGNvbnN0IGNvbWJpbmVkT3B0aW9uczogSUNvbWJpbmVkT3VpVG9hc3RPcHRpb25zID0ge1xuICAgICAgaWQ6IEdVSUQoKSxcbiAgICAgIC4uLnRoaXMuZGVmYXVsdE9wdGlvbnMsXG4gICAgICAuLi5vcHRpb25zLFxuICAgIH07XG5cbiAgICBpZiAodHlwZW9mIGNvbWJpbmVkT3B0aW9ucy5wb3NpdGlvbiA9PSAnc3RyaW5nJykge1xuICAgICAgaWYgKCF0aGlzLmN1cnJlbnRUb2FzdFdyYXBwZXJzLmhhcyhjb21iaW5lZE9wdGlvbnMucG9zaXRpb24pKSB7XG4gICAgICAgIHRoaXMuY3VycmVudFRvYXN0V3JhcHBlcnMuc2V0KFxuICAgICAgICAgIGNvbWJpbmVkT3B0aW9ucy5wb3NpdGlvbixcbiAgICAgICAgICB0aGlzLmNyZWF0ZVdyYXBwZXIoY29tYmluZWRPcHRpb25zLnBvc2l0aW9uKVxuICAgICAgICApO1xuICAgICAgfVxuICAgICAgdGhpcy5jcmVhdGVUb2FzdChcbiAgICAgICAgdGhpcy5jdXJyZW50VG9hc3RXcmFwcGVycy5nZXQoY29tYmluZWRPcHRpb25zLnBvc2l0aW9uKSxcbiAgICAgICAgY29tYmluZWRPcHRpb25zLFxuICAgICAgICBpbnB1dHNcbiAgICAgICk7XG4gICAgfSBlbHNlIGlmIChwYXJlbnQpIHtcbiAgICAgIHRoaXMuY3JlYXRlVG9hc3QocGFyZW50Lm5hdGl2ZUVsZW1lbnQsIGNvbWJpbmVkT3B0aW9ucywgaW5wdXRzKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5jcmVhdGVUb2FzdCh0aGlzLmRvY3VtZW50LmJvZHksIGNvbWJpbmVkT3B0aW9ucywgaW5wdXRzKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGNyZWF0ZVdyYXBwZXIocG9zaXRpb246IHN0cmluZykge1xuICAgIGNvbnN0IFRPQVNUUl9ESVNUQU5DRSA9ICc1cmVtJztcbiAgICBjb25zdCB3cmFwcGVyID0gdGhpcy5yZW5kZXJlci5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICB0aGlzLnJlbmRlcmVyLmFkZENsYXNzKHdyYXBwZXIsICd0b2FzdHItd3JhcHBlcicpO1xuICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUod3JhcHBlciwgJ2Rpc3BsYXknLCAnZmxleCcpO1xuICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUod3JhcHBlciwgJ2ZsZXhEaXJlY3Rpb24nLCAnY29sdW1uJyk7XG4gICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZSh3cmFwcGVyLCAncG9zaXRpb24nLCAnZml4ZWQnKTtcbiAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKHdyYXBwZXIsICd6SW5kZXgnLCAnOTk5OScpO1xuXG4gICAgc3dpdGNoIChwb3NpdGlvbikge1xuICAgICAgY2FzZSAndG9wJzpcbiAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZSh3cmFwcGVyLCAndG9wJywgVE9BU1RSX0RJU1RBTkNFKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShcbiAgICAgICAgICB3cmFwcGVyLFxuICAgICAgICAgICdsZWZ0JyxcbiAgICAgICAgICB0aGlzLmRvY3VtZW50LmJvZHkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggLyAyICsgJ3B4J1xuICAgICAgICApO1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKHdyYXBwZXIsICd0cmFuc2Zvcm0nLCAndHJhbnNsYXRlWCgtNTAlKScpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ3RvcC1yaWdodCc6XG4gICAgICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUod3JhcHBlciwgJ3RvcCcsIFRPQVNUUl9ESVNUQU5DRSk7XG4gICAgICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUod3JhcHBlciwgJ3JpZ2h0JywgVE9BU1RSX0RJU1RBTkNFKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICd0b3AtbGVmdCc6XG4gICAgICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUod3JhcHBlciwgJ3RvcCcsIFRPQVNUUl9ESVNUQU5DRSk7XG4gICAgICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUod3JhcHBlciwgJ2xlZnQnLCBUT0FTVFJfRElTVEFOQ0UpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ2JvdHRvbSc6XG4gICAgICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUod3JhcHBlciwgJ2JvdHRvbScsIFRPQVNUUl9ESVNUQU5DRSk7XG4gICAgICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUoXG4gICAgICAgICAgd3JhcHBlcixcbiAgICAgICAgICAnbGVmdCcsXG4gICAgICAgICAgdGhpcy5kb2N1bWVudC5ib2R5LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoIC8gMiArICdweCdcbiAgICAgICAgKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZSh3cmFwcGVyLCAndHJhbnNmb3JtJywgJ3RyYW5zbGF0ZVgoLTUwJSknKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICdib3R0b20tcmlnaHQnOlxuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKHdyYXBwZXIsICdib3R0b20nLCBUT0FTVFJfRElTVEFOQ0UpO1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKHdyYXBwZXIsICdyaWdodCcsIFRPQVNUUl9ESVNUQU5DRSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAnYm90dG9tLWxlZnQnOlxuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKHdyYXBwZXIsICdib3R0b20nLCBUT0FTVFJfRElTVEFOQ0UpO1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKHdyYXBwZXIsICdsZWZ0JywgVE9BU1RSX0RJU1RBTkNFKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICdjZW50ZXInOlxuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKFxuICAgICAgICAgIHdyYXBwZXIsXG4gICAgICAgICAgJ3RvcCcsXG4gICAgICAgICAgdGhpcy5kb2N1bWVudC5ib2R5LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodCAvIDIgLVxuICAgICAgICAgICAgd3JhcHBlci5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5oZWlnaHQgLyAyICtcbiAgICAgICAgICAgICdweCdcbiAgICAgICAgKTtcbiAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShcbiAgICAgICAgICB3cmFwcGVyLFxuICAgICAgICAgICdsZWZ0JyxcbiAgICAgICAgICB0aGlzLmRvY3VtZW50LmJvZHkuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggLyAyICsgJ3B4J1xuICAgICAgICApO1xuICAgICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKHdyYXBwZXIsICd0cmFuc2Zvcm0nLCAndHJhbnNsYXRlWCgtNTAlKScpO1xuICAgICAgICBicmVhaztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIGNvbnNvbGUubG9nKCdpbnZhbGlkIHBvc2l0aW9uIGdpdmVuIGZvciB0b2FzdCcpO1xuICAgIH1cbiAgICB0aGlzLnJlbmRlcmVyLmFwcGVuZENoaWxkKHRoaXMuZG9jdW1lbnQuYm9keSwgd3JhcHBlcik7XG4gICAgcmV0dXJuIHdyYXBwZXI7XG4gIH1cblxuICBwcml2YXRlIGNyZWF0ZVRvYXN0KFxuICAgIHdyYXBwZXI6IEhUTUxFbGVtZW50LFxuICAgIGNvbWJpbmVkT3B0aW9uczogSUNvbWJpbmVkT3VpVG9hc3RPcHRpb25zLFxuICAgIGlucHV0cz86IHsgW3g6IHN0cmluZ106IHVua25vd24gfVxuICApIHtcbiAgICBpZiAoaW5wdXRzKSB7XG4gICAgICBjb21iaW5lZE9wdGlvbnMuaW5wdXRzID0gaW5wdXRzO1xuICAgIH1cbiAgICBjb25zdCBjcmVhdGVDb21wb25lbnRPcHRpb25zID0ge1xuICAgICAgY29tcG9uZW50OiBPdWlUb2FzdENvbXBvbmVudCxcbiAgICAgIHBhcmVudEVsZW1lbnQ6IHdyYXBwZXIsXG4gICAgICBhcHBSZWY6IHRoaXMuYXBwUmVmLFxuICAgICAgY3JlYXRlQ29tcG9uZW50T3B0aW9uczoge1xuICAgICAgICBlbnZpcm9ubWVudEluamVjdG9yOiB0aGlzLmluamVjdG9yLFxuICAgICAgfSxcbiAgICAgIGlucHV0czoge1xuICAgICAgICBvcHRpb25zOiBjb21iaW5lZE9wdGlvbnMsXG4gICAgICB9LFxuICAgIH07XG4gICAgY29uc3QgY29tcG9uZW50UmVmID0gQ29tcG9uZW50Q3JlYXRvci5jcmVhdGVDb21wb25lbnQ8T3VpVG9hc3RDb21wb25lbnQ+KFxuICAgICAgY3JlYXRlQ29tcG9uZW50T3B0aW9uc1xuICAgICk7XG5cbiAgICBpZiAodHlwZW9mIGNvbWJpbmVkT3B0aW9ucy5wb3NpdGlvbiAhPSAnc3RyaW5nJykge1xuICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShcbiAgICAgICAgY29tcG9uZW50UmVmLmxvY2F0aW9uLm5hdGl2ZUVsZW1lbnQsXG4gICAgICAgICdsZWZ0JyxcbiAgICAgICAgYCR7Y29tYmluZWRPcHRpb25zLnBvc2l0aW9uLnh9cHhgXG4gICAgICApO1xuICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShcbiAgICAgICAgY29tcG9uZW50UmVmLmxvY2F0aW9uLm5hdGl2ZUVsZW1lbnQsXG4gICAgICAgICd0b3AnLFxuICAgICAgICBgJHtjb21iaW5lZE9wdGlvbnMucG9zaXRpb24ueX1weGBcbiAgICAgICk7XG4gICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKFxuICAgICAgICBjb21wb25lbnRSZWYubG9jYXRpb24ubmF0aXZlRWxlbWVudCxcbiAgICAgICAgJ3Bvc2l0aW9uJyxcbiAgICAgICAgJ2ZpeGVkJ1xuICAgICAgKTtcbiAgICB9XG5cbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRoaXMucmVuZGVyZXIuYWRkQ2xhc3MoY29tcG9uZW50UmVmLmxvY2F0aW9uLm5hdGl2ZUVsZW1lbnQsICdzaG93Jyk7XG4gICAgfSk7XG5cbiAgICB0aGlzLmN1cnJlbnRUb2FzdHMuc2V0KGNvbWJpbmVkT3B0aW9ucy5pZCwgY29tcG9uZW50UmVmKTtcbiAgICBjb21wb25lbnRSZWYuY2hhbmdlRGV0ZWN0b3JSZWYuZGV0ZWN0Q2hhbmdlcygpO1xuXG4gICAgc2V0VGltZW91dChcbiAgICAgICgpID0+IHRoaXMuZGlzYWJsZShjb21iaW5lZE9wdGlvbnMuaWQpLFxuICAgICAgY29tYmluZWRPcHRpb25zLmR1cmF0aW9uXG4gICAgKTtcbiAgfVxuXG4gIHB1YmxpYyBkaXNhYmxlKGlkOiBzdHJpbmcpIHtcbiAgICBjb25zdCB0b2FzdCA9IHRoaXMuY3VycmVudFRvYXN0cy5nZXQoaWQpO1xuICAgIGlmICghdG9hc3QpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgb3B0aW9ucyA9IHRvYXN0Lmluc3RhbmNlLm9wdGlvbnM7XG4gICAgaWYgKFxuICAgICAgb3B0aW9ucy5wb3NpdGlvbiA9PT0gJ3RvcC1yaWdodCcgfHxcbiAgICAgIG9wdGlvbnMucG9zaXRpb24gPT09ICdib3R0b20tcmlnaHQnXG4gICAgKSB7XG4gICAgICB0aGlzLnJlbmRlcmVyLmFkZENsYXNzKHRvYXN0LmxvY2F0aW9uLm5hdGl2ZUVsZW1lbnQsICdyZW1vdmUtdG8tcmlnaHQnKTtcbiAgICB9IGVsc2UgaWYgKG9wdGlvbnMucG9zaXRpb24gPT09ICd0b3AnKSB7XG4gICAgICB0aGlzLnJlbmRlcmVyLmFkZENsYXNzKHRvYXN0LmxvY2F0aW9uLm5hdGl2ZUVsZW1lbnQsICdyZW1vdmUtdG8tdG9wJyk7XG4gICAgfSBlbHNlIGlmIChcbiAgICAgIG9wdGlvbnMucG9zaXRpb24gPT09ICd0b3AtbGVmdCcgfHxcbiAgICAgIG9wdGlvbnMucG9zaXRpb24gPT09ICdib3R0b20tbGVmdCdcbiAgICApIHtcbiAgICAgIHRoaXMucmVuZGVyZXIuYWRkQ2xhc3ModG9hc3QubG9jYXRpb24ubmF0aXZlRWxlbWVudCwgJ3JlbW92ZS10by1sZWZ0Jyk7XG4gICAgfSBlbHNlIGlmIChvcHRpb25zLnBvc2l0aW9uID09PSAnYm90dG9tJykge1xuICAgICAgdGhpcy5yZW5kZXJlci5hZGRDbGFzcyh0b2FzdC5sb2NhdGlvbi5uYXRpdmVFbGVtZW50LCAncmVtb3ZlLXRvLWJvdHRvbScpO1xuICAgIH1cbiAgICB0aGlzLnJlbmRlcmVyLnJlbW92ZUNsYXNzKHRvYXN0LmxvY2F0aW9uLm5hdGl2ZUVsZW1lbnQsICdzaG93Jyk7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICBpZiAoIXRoaXMuY3VycmVudFRvYXN0cy5oYXMoaWQpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIHRvYXN0LmRlc3Ryb3koKTtcbiAgICAgIHRoaXMuY3VycmVudFRvYXN0cy5kZWxldGUoaWQpO1xuICAgIH0sIDEwMDApO1xuICB9XG59XG4iXX0=