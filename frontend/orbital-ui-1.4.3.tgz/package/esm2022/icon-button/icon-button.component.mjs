import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, } from '@angular/core';
import { OuiIconComponent } from 'orbital-ui/icon';
import { CommonModule } from '@angular/common';
import { OuiSpinnerComponent } from 'orbital-ui/spinner';
import { OuiRippleDirective } from 'orbital-ui/ripple';
import { merge } from 'lodash-es';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
/**
 * Creates a clickable icon, with a little hover effect to signal clickability.
 *
 *  example use:
 *
 *  <oui-icon-button color="primary" icon="assets/icons/my-example-icon.svg" [options]="{fillColor: 'color-white'}" (onClick)="onIconClick($event)"></oui-icon-button>
 */
export class OuiIconButtonComponent {
    cdr;
    /**
     *   The path to the icon
     */
    icon = '';
    /**
     *   if set to true, icon is replaced with a loading spinner
     */
    isLoading = false;
    /**
     *   The options of the icon
     */
    set options(newOptions) {
        this.combinedOptions = merge({ ...this.defaultOptions }, { ...newOptions });
    }
    get options() {
        return this.combinedOptions;
    }
    /**
     *   Emitted when icon is clicked. Usually you want to tie a function to this.
     */
    onClick = new EventEmitter();
    defaultOptions = {
        fillColor: 'color-primary-icons',
        strokeColor: 'color-primary-icons',
        size: '24px',
    };
    combinedOptions = {
        ...this.defaultOptions,
    };
    spinnerColor = '';
    spinnerSize = '';
    constructor(cdr) {
        this.cdr = cdr;
    }
    ngAfterViewInit() {
        if (Array.isArray(this.options.fillColor)) {
            this.spinnerColor = `rgba(${this.options.fillColor[0]}, ${this.options.fillColor[1]}, ${this.options.fillColor[2]}, ${this.options.fillColor.length > 3
                ? this.options.fillColor[3] / 255
                : '1'})`;
        }
        else {
            this.spinnerColor = this.options.fillColor || 'color-primary-text';
        }
        this.spinnerSize = this.options.size ?? '1.6rem';
        this.cdr.detectChanges();
    }
    emitClick(event) {
        this.onClick.emit(event);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiIconButtonComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiIconButtonComponent, isStandalone: true, selector: "oui-icon-button", inputs: { icon: "icon", isLoading: "isLoading", options: "options" }, outputs: { onClick: "onClick" }, ngImport: i0, template: "<div\n  class=\"oui-icon-button-container\"\n  (click)=\"emitClick($event)\"\n  [ngClass]=\"{ disabled: isLoading }\"\n  ouiRipple\n  >\n  @if (!isLoading) {\n    <oui-icon [options]=\"options\" [icon]=\"icon\"></oui-icon>\n  }\n  @if (isLoading) {\n    <oui-spinner\n      type=\"solid\"\n      [color]=\"spinnerColor\"\n      [size]=\"spinnerSize\"\n    ></oui-spinner>\n  }\n</div>\n", styles: [":host{height:100%;width:100%;display:flex;justify-content:center;align-items:center}:host .oui-icon-button-container{border-width:var(--oui-icon-button-border-width);border-style:var(--oui-icon-button-border-style);border-color:var(--oui-icon-button-border-color);border-radius:var(--oui-icon-button-border-radius);background-color:var(--oui-icon-button-background-color);transition:background-color .3s;display:flex;justify-content:center;align-items:center;padding:var(--oui-icon-button-padding);flex:1;box-sizing:border-box;height:100%;width:100%}:host .oui-icon-button-container oui-spinner{width:100%;height:100%}:host .oui-icon-button-container.disabled{pointer-events:none;opacity:.7}:host .oui-icon-button-container:hover{background-color:var(--oui-icon-button-background-color-hover);cursor:pointer}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "component", type: OuiSpinnerComponent, selector: "oui-spinner", inputs: ["color", "size", "type"] }, { kind: "directive", type: OuiRippleDirective, selector: "[ouiRipple]" }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiIconButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-icon-button', standalone: true, imports: [
                        OuiIconComponent,
                        OuiSpinnerComponent,
                        OuiRippleDirective,
                        CommonModule,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"oui-icon-button-container\"\n  (click)=\"emitClick($event)\"\n  [ngClass]=\"{ disabled: isLoading }\"\n  ouiRipple\n  >\n  @if (!isLoading) {\n    <oui-icon [options]=\"options\" [icon]=\"icon\"></oui-icon>\n  }\n  @if (isLoading) {\n    <oui-spinner\n      type=\"solid\"\n      [color]=\"spinnerColor\"\n      [size]=\"spinnerSize\"\n    ></oui-spinner>\n  }\n</div>\n", styles: [":host{height:100%;width:100%;display:flex;justify-content:center;align-items:center}:host .oui-icon-button-container{border-width:var(--oui-icon-button-border-width);border-style:var(--oui-icon-button-border-style);border-color:var(--oui-icon-button-border-color);border-radius:var(--oui-icon-button-border-radius);background-color:var(--oui-icon-button-background-color);transition:background-color .3s;display:flex;justify-content:center;align-items:center;padding:var(--oui-icon-button-padding);flex:1;box-sizing:border-box;height:100%;width:100%}:host .oui-icon-button-container oui-spinner{width:100%;height:100%}:host .oui-icon-button-container.disabled{pointer-events:none;opacity:.7}:host .oui-icon-button-container:hover{background-color:var(--oui-icon-button-background-color-hover);cursor:pointer}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { icon: [{
                type: Input
            }], isLoading: [{
                type: Input
            }], options: [{
                type: Input
            }], onClick: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWNvbi1idXR0b24uY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9pY29uLWJ1dHRvbi9pY29uLWJ1dHRvbi5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL2ljb24tYnV0dG9uL2ljb24tYnV0dG9uLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFFTCx1QkFBdUIsRUFFdkIsU0FBUyxFQUNULFlBQVksRUFDWixLQUFLLEVBQ0wsTUFBTSxHQUNQLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBbUIsZ0JBQWdCLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUNwRSxPQUFPLEVBQUUsWUFBWSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDL0MsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDekQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFDdkQsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLFdBQVcsQ0FBQzs7O0FBRWxDOzs7Ozs7R0FNRztBQWNILE1BQU0sT0FBTyxzQkFBc0I7SUF5Q2I7SUF4Q3BCOztPQUVHO0lBRUgsSUFBSSxHQUFHLEVBQUUsQ0FBQztJQUVWOztPQUVHO0lBRUgsU0FBUyxHQUFHLEtBQUssQ0FBQztJQUVsQjs7T0FFRztJQUNILElBQ0ksT0FBTyxDQUFDLFVBQTJCO1FBQ3JDLElBQUksQ0FBQyxlQUFlLEdBQUcsS0FBSyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsY0FBYyxFQUFFLEVBQUUsRUFBRSxHQUFHLFVBQVUsRUFBRSxDQUFDLENBQUM7SUFDOUUsQ0FBQztJQUVELElBQUksT0FBTztRQUNULE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQztJQUM5QixDQUFDO0lBQ0Q7O09BRUc7SUFDTyxPQUFPLEdBQUcsSUFBSSxZQUFZLEVBQU8sQ0FBQztJQUVwQyxjQUFjLEdBQW9CO1FBQ3hDLFNBQVMsRUFBRSxxQkFBcUI7UUFDaEMsV0FBVyxFQUFFLHFCQUFxQjtRQUNsQyxJQUFJLEVBQUUsTUFBTTtLQUNiLENBQUM7SUFDSyxlQUFlLEdBQW9CO1FBQ3hDLEdBQUcsSUFBSSxDQUFDLGNBQWM7S0FDdkIsQ0FBQztJQUVLLFlBQVksR0FBVyxFQUFFLENBQUM7SUFDMUIsV0FBVyxHQUFXLEVBQUUsQ0FBQztJQUVoQyxZQUFvQixHQUFzQjtRQUF0QixRQUFHLEdBQUgsR0FBRyxDQUFtQjtJQUFHLENBQUM7SUFFdkMsZUFBZTtRQUNwQixJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO1lBQzFDLElBQUksQ0FBQyxZQUFZLEdBQUcsUUFBUSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FDbkQsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUMxQixLQUFLLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUM1QixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQztnQkFDL0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUc7Z0JBQ2pDLENBQUMsQ0FBQyxHQUNOLEdBQUcsQ0FBQztRQUNOLENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsSUFBSSxvQkFBb0IsQ0FBQztRQUNyRSxDQUFDO1FBRUQsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksSUFBSSxRQUFRLENBQUM7UUFDakQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRU0sU0FBUyxDQUFDLEtBQVU7UUFDekIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDM0IsQ0FBQzt1R0E5RFUsc0JBQXNCOzJGQUF0QixzQkFBc0Isa0xDbkNuQyxvWUFpQkEsbzJCRFdJLGdCQUFnQixrRkFDaEIsbUJBQW1CLDJGQUNuQixrQkFBa0IsdURBQ2xCLFlBQVk7OzJGQUlILHNCQUFzQjtrQkFibEMsU0FBUzsrQkFDRSxpQkFBaUIsY0FHZixJQUFJLFdBQ1A7d0JBQ1AsZ0JBQWdCO3dCQUNoQixtQkFBbUI7d0JBQ25CLGtCQUFrQjt3QkFDbEIsWUFBWTtxQkFDYixtQkFDZ0IsdUJBQXVCLENBQUMsTUFBTTtzRkFPL0MsSUFBSTtzQkFESCxLQUFLO2dCQU9OLFNBQVM7c0JBRFIsS0FBSztnQkFPRixPQUFPO3NCQURWLEtBQUs7Z0JBV0ksT0FBTztzQkFBaEIsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFmdGVyVmlld0luaXQsXG4gIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LFxuICBDaGFuZ2VEZXRlY3RvclJlZixcbiAgQ29tcG9uZW50LFxuICBFdmVudEVtaXR0ZXIsXG4gIElucHV0LFxuICBPdXRwdXQsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgSU91aUljb25PcHRpb25zLCBPdWlJY29uQ29tcG9uZW50IH0gZnJvbSAnb3JiaXRhbC11aS9pY29uJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBPdWlTcGlubmVyQ29tcG9uZW50IH0gZnJvbSAnb3JiaXRhbC11aS9zcGlubmVyJztcbmltcG9ydCB7IE91aVJpcHBsZURpcmVjdGl2ZSB9IGZyb20gJ29yYml0YWwtdWkvcmlwcGxlJztcbmltcG9ydCB7IG1lcmdlIH0gZnJvbSAnbG9kYXNoLWVzJztcblxuLyoqXG4gKiBDcmVhdGVzIGEgY2xpY2thYmxlIGljb24sIHdpdGggYSBsaXR0bGUgaG92ZXIgZWZmZWN0IHRvIHNpZ25hbCBjbGlja2FiaWxpdHkuXG4gKlxuICogIGV4YW1wbGUgdXNlOlxuICpcbiAqICA8b3VpLWljb24tYnV0dG9uIGNvbG9yPVwicHJpbWFyeVwiIGljb249XCJhc3NldHMvaWNvbnMvbXktZXhhbXBsZS1pY29uLnN2Z1wiIFtvcHRpb25zXT1cIntmaWxsQ29sb3I6ICdjb2xvci13aGl0ZSd9XCIgKG9uQ2xpY2spPVwib25JY29uQ2xpY2soJGV2ZW50KVwiPjwvb3VpLWljb24tYnV0dG9uPlxuICovXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdvdWktaWNvbi1idXR0b24nLFxuICB0ZW1wbGF0ZVVybDogJy4vaWNvbi1idXR0b24uY29tcG9uZW50Lmh0bWwnLFxuICBzdHlsZVVybHM6IFsnaWNvbi1idXR0b24uY29tcG9uZW50LnNjc3MnXSxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW1xuICAgIE91aUljb25Db21wb25lbnQsXG4gICAgT3VpU3Bpbm5lckNvbXBvbmVudCxcbiAgICBPdWlSaXBwbGVEaXJlY3RpdmUsXG4gICAgQ29tbW9uTW9kdWxlLFxuICBdLFxuICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcbn0pXG5leHBvcnQgY2xhc3MgT3VpSWNvbkJ1dHRvbkNvbXBvbmVudCBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQge1xuICAvKipcbiAgICogICBUaGUgcGF0aCB0byB0aGUgaWNvblxuICAgKi9cbiAgQElucHV0KClcbiAgaWNvbiA9ICcnO1xuXG4gIC8qKlxuICAgKiAgIGlmIHNldCB0byB0cnVlLCBpY29uIGlzIHJlcGxhY2VkIHdpdGggYSBsb2FkaW5nIHNwaW5uZXJcbiAgICovXG4gIEBJbnB1dCgpXG4gIGlzTG9hZGluZyA9IGZhbHNlO1xuXG4gIC8qKlxuICAgKiAgIFRoZSBvcHRpb25zIG9mIHRoZSBpY29uXG4gICAqL1xuICBASW5wdXQoKVxuICBzZXQgb3B0aW9ucyhuZXdPcHRpb25zOiBJT3VpSWNvbk9wdGlvbnMpIHtcbiAgICB0aGlzLmNvbWJpbmVkT3B0aW9ucyA9IG1lcmdlKHsgLi4udGhpcy5kZWZhdWx0T3B0aW9ucyB9LCB7IC4uLm5ld09wdGlvbnMgfSk7XG4gIH1cblxuICBnZXQgb3B0aW9ucygpIHtcbiAgICByZXR1cm4gdGhpcy5jb21iaW5lZE9wdGlvbnM7XG4gIH1cbiAgLyoqXG4gICAqICAgRW1pdHRlZCB3aGVuIGljb24gaXMgY2xpY2tlZC4gVXN1YWxseSB5b3Ugd2FudCB0byB0aWUgYSBmdW5jdGlvbiB0byB0aGlzLlxuICAgKi9cbiAgQE91dHB1dCgpIG9uQ2xpY2sgPSBuZXcgRXZlbnRFbWl0dGVyPGFueT4oKTtcblxuICBwcml2YXRlIGRlZmF1bHRPcHRpb25zOiBJT3VpSWNvbk9wdGlvbnMgPSB7XG4gICAgZmlsbENvbG9yOiAnY29sb3ItcHJpbWFyeS1pY29ucycsXG4gICAgc3Ryb2tlQ29sb3I6ICdjb2xvci1wcmltYXJ5LWljb25zJyxcbiAgICBzaXplOiAnMjRweCcsXG4gIH07XG4gIHB1YmxpYyBjb21iaW5lZE9wdGlvbnM6IElPdWlJY29uT3B0aW9ucyA9IHtcbiAgICAuLi50aGlzLmRlZmF1bHRPcHRpb25zLFxuICB9O1xuXG4gIHB1YmxpYyBzcGlubmVyQ29sb3I6IHN0cmluZyA9ICcnO1xuICBwdWJsaWMgc3Bpbm5lclNpemU6IHN0cmluZyA9ICcnO1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgY2RyOiBDaGFuZ2VEZXRlY3RvclJlZikge31cblxuICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCkge1xuICAgIGlmIChBcnJheS5pc0FycmF5KHRoaXMub3B0aW9ucy5maWxsQ29sb3IpKSB7XG4gICAgICB0aGlzLnNwaW5uZXJDb2xvciA9IGByZ2JhKCR7dGhpcy5vcHRpb25zLmZpbGxDb2xvclswXX0sICR7XG4gICAgICAgIHRoaXMub3B0aW9ucy5maWxsQ29sb3JbMV1cbiAgICAgIH0sICR7dGhpcy5vcHRpb25zLmZpbGxDb2xvclsyXX0sICR7XG4gICAgICAgIHRoaXMub3B0aW9ucy5maWxsQ29sb3IubGVuZ3RoID4gM1xuICAgICAgICAgID8gdGhpcy5vcHRpb25zLmZpbGxDb2xvclszXSAvIDI1NVxuICAgICAgICAgIDogJzEnXG4gICAgICB9KWA7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuc3Bpbm5lckNvbG9yID0gdGhpcy5vcHRpb25zLmZpbGxDb2xvciB8fCAnY29sb3ItcHJpbWFyeS10ZXh0JztcbiAgICB9XG5cbiAgICB0aGlzLnNwaW5uZXJTaXplID0gdGhpcy5vcHRpb25zLnNpemUgPz8gJzEuNnJlbSc7XG4gICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xuICB9XG5cbiAgcHVibGljIGVtaXRDbGljayhldmVudDogYW55KSB7XG4gICAgdGhpcy5vbkNsaWNrLmVtaXQoZXZlbnQpO1xuICB9XG59XG4iLCI8ZGl2XG4gIGNsYXNzPVwib3VpLWljb24tYnV0dG9uLWNvbnRhaW5lclwiXG4gIChjbGljayk9XCJlbWl0Q2xpY2soJGV2ZW50KVwiXG4gIFtuZ0NsYXNzXT1cInsgZGlzYWJsZWQ6IGlzTG9hZGluZyB9XCJcbiAgb3VpUmlwcGxlXG4gID5cbiAgQGlmICghaXNMb2FkaW5nKSB7XG4gICAgPG91aS1pY29uIFtvcHRpb25zXT1cIm9wdGlvbnNcIiBbaWNvbl09XCJpY29uXCI+PC9vdWktaWNvbj5cbiAgfVxuICBAaWYgKGlzTG9hZGluZykge1xuICAgIDxvdWktc3Bpbm5lclxuICAgICAgdHlwZT1cInNvbGlkXCJcbiAgICAgIFtjb2xvcl09XCJzcGlubmVyQ29sb3JcIlxuICAgICAgW3NpemVdPVwic3Bpbm5lclNpemVcIlxuICAgID48L291aS1zcGlubmVyPlxuICB9XG48L2Rpdj5cbiJdfQ==