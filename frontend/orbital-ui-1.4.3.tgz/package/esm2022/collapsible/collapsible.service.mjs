import { Injectable } from '@angular/core';
import { ReplaySubject, Subject } from 'rxjs';
import { isNil } from 'lodash-es';
import * as i0 from "@angular/core";
/**
 * Service used to control oui-collapsible-content and oui-collapsible-toggle.
 * All collapsibles are stored in this service, and you can programmatically toggle any group to be open or closed from here.
 * Contains a collapsibleToggled$ observable that you can subscribe to in order to be notified when a collapsible group is toggled
 */
export class OuiCollapsibleService {
    collapsibleToggledSubject = new ReplaySubject(1);
    refreshCollapsibleContentHeightSubject = new Subject();
    collapsibleToggled$ = this.collapsibleToggledSubject.asObservable();
    refreshCollapsibleContentHeight$ = this.refreshCollapsibleContentHeightSubject.asObservable();
    collapsibles = {};
    constructor() { }
    registerToggle(group, toggle) {
        if (!this.collapsibles[group]) {
            this.collapsibles[group] = {
                content: null,
                toggle: toggle,
                isOpen: toggle.isOpen,
            };
        }
        else {
            this.collapsibles[group].toggle = toggle;
            this.collapsibles[group].isOpen = toggle.isOpen;
        }
    }
    refreshCollapsibleContentHeight(group) {
        if (this.collapsibles[group]) {
            this.refreshCollapsibleContentHeightSubject.next(group);
        }
    }
    registerContent(group, content) {
        if (!this.collapsibles[group]) {
            this.collapsibles[group] = {
                content: content,
                toggle: null,
                isOpen: false,
            };
        }
        else {
            this.collapsibles[group].content = content;
        }
    }
    deregisterCollapsible(group) {
        if (this.collapsibles[group]) {
            delete this.collapsibles[group];
        }
    }
    toggle(group, isOpen) {
        if (this.collapsibles[group]) {
            const newIsOpen = isNil(isOpen)
                ? !this.collapsibles[group].isOpen
                : isOpen;
            this.collapsibles[group].isOpen = newIsOpen;
            this.collapsibleToggledSubject.next({
                group,
                isOpen: newIsOpen,
            });
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCollapsibleService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCollapsibleService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCollapsibleService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29sbGFwc2libGUuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvY29sbGFwc2libGUvY29sbGFwc2libGUuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRzNDLE9BQU8sRUFBRSxhQUFhLEVBQUUsT0FBTyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQzlDLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxXQUFXLENBQUM7O0FBT2xDOzs7O0dBSUc7QUFJSCxNQUFNLE9BQU8scUJBQXFCO0lBQ3hCLHlCQUF5QixHQUFHLElBQUksYUFBYSxDQUFzQixDQUFDLENBQUMsQ0FBQztJQUN0RSxzQ0FBc0MsR0FBRyxJQUFJLE9BQU8sRUFBVSxDQUFDO0lBQ2hFLG1CQUFtQixHQUFHLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUNwRSxnQ0FBZ0MsR0FDckMsSUFBSSxDQUFDLHNDQUFzQyxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ3JELFlBQVksR0FNaEIsRUFBRSxDQUFDO0lBRVAsZ0JBQWUsQ0FBQztJQUVULGNBQWMsQ0FBQyxLQUFhLEVBQUUsTUFBcUM7UUFDeEUsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUM5QixJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxHQUFHO2dCQUN6QixPQUFPLEVBQUUsSUFBSTtnQkFDYixNQUFNLEVBQUUsTUFBTTtnQkFDZCxNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07YUFDdEIsQ0FBQztRQUNKLENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO1lBQ3pDLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDbEQsQ0FBQztJQUNILENBQUM7SUFFTSwrQkFBK0IsQ0FBQyxLQUFhO1FBQ2xELElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQzdCLElBQUksQ0FBQyxzQ0FBc0MsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDMUQsQ0FBQztJQUNILENBQUM7SUFFTSxlQUFlLENBQ3BCLEtBQWEsRUFDYixPQUF1QztRQUV2QyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQzlCLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLEdBQUc7Z0JBQ3pCLE9BQU8sRUFBRSxPQUFPO2dCQUNoQixNQUFNLEVBQUUsSUFBSTtnQkFDWixNQUFNLEVBQUUsS0FBSzthQUNkLENBQUM7UUFDSixDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztRQUM3QyxDQUFDO0lBQ0gsQ0FBQztJQUVNLHFCQUFxQixDQUFDLEtBQWE7UUFDeEMsSUFBSSxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDN0IsT0FBTyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2xDLENBQUM7SUFDSCxDQUFDO0lBRU0sTUFBTSxDQUFDLEtBQWEsRUFBRSxNQUFnQjtRQUMzQyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUM3QixNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO2dCQUM3QixDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU07Z0JBQ2xDLENBQUMsQ0FBQyxNQUFNLENBQUM7WUFDWCxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUM7WUFDNUMsSUFBSSxDQUFDLHlCQUF5QixDQUFDLElBQUksQ0FBQztnQkFDbEMsS0FBSztnQkFDTCxNQUFNLEVBQUUsU0FBUzthQUNsQixDQUFDLENBQUM7UUFDTCxDQUFDO0lBQ0gsQ0FBQzt1R0FuRVUscUJBQXFCOzJHQUFyQixxQkFBcUIsY0FGcEIsTUFBTTs7MkZBRVAscUJBQXFCO2tCQUhqQyxVQUFVO21CQUFDO29CQUNWLFVBQVUsRUFBRSxNQUFNO2lCQUNuQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE91aUNvbGxhcHNpYmxlQ29udGVudENvbXBvbmVudCB9IGZyb20gJy4vY29sbGFwc2libGUtY29udGVudC9jb2xsYXBzaWJsZS1jb250ZW50LmNvbXBvbmVudCc7XG5pbXBvcnQgeyBPdWlDb2xsYXBzaWJsZVRvZ2dsZUNvbXBvbmVudCB9IGZyb20gJy4vY29sbGFwc2libGUtdG9nZ2xlL2NvbGxhcHNpYmxlLXRvZ2dsZS5jb21wb25lbnQnO1xuaW1wb3J0IHsgUmVwbGF5U3ViamVjdCwgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgaXNOaWwgfSBmcm9tICdsb2Rhc2gtZXMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIElDb2xsYXBzaWJsZVRvZ2dsZWQge1xuICBncm91cDogc3RyaW5nO1xuICBpc09wZW46IGJvb2xlYW47XG59XG5cbi8qKlxuICogU2VydmljZSB1c2VkIHRvIGNvbnRyb2wgb3VpLWNvbGxhcHNpYmxlLWNvbnRlbnQgYW5kIG91aS1jb2xsYXBzaWJsZS10b2dnbGUuXG4gKiBBbGwgY29sbGFwc2libGVzIGFyZSBzdG9yZWQgaW4gdGhpcyBzZXJ2aWNlLCBhbmQgeW91IGNhbiBwcm9ncmFtbWF0aWNhbGx5IHRvZ2dsZSBhbnkgZ3JvdXAgdG8gYmUgb3BlbiBvciBjbG9zZWQgZnJvbSBoZXJlLlxuICogQ29udGFpbnMgYSBjb2xsYXBzaWJsZVRvZ2dsZWQkIG9ic2VydmFibGUgdGhhdCB5b3UgY2FuIHN1YnNjcmliZSB0byBpbiBvcmRlciB0byBiZSBub3RpZmllZCB3aGVuIGEgY29sbGFwc2libGUgZ3JvdXAgaXMgdG9nZ2xlZFxuICovXG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290Jyxcbn0pXG5leHBvcnQgY2xhc3MgT3VpQ29sbGFwc2libGVTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBjb2xsYXBzaWJsZVRvZ2dsZWRTdWJqZWN0ID0gbmV3IFJlcGxheVN1YmplY3Q8SUNvbGxhcHNpYmxlVG9nZ2xlZD4oMSk7XG4gIHByaXZhdGUgcmVmcmVzaENvbGxhcHNpYmxlQ29udGVudEhlaWdodFN1YmplY3QgPSBuZXcgU3ViamVjdDxzdHJpbmc+KCk7XG4gIHB1YmxpYyBjb2xsYXBzaWJsZVRvZ2dsZWQkID0gdGhpcy5jb2xsYXBzaWJsZVRvZ2dsZWRTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuICBwdWJsaWMgcmVmcmVzaENvbGxhcHNpYmxlQ29udGVudEhlaWdodCQgPVxuICAgIHRoaXMucmVmcmVzaENvbGxhcHNpYmxlQ29udGVudEhlaWdodFN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XG4gIHByaXZhdGUgY29sbGFwc2libGVzOiB7XG4gICAgW2tleTogc3RyaW5nXToge1xuICAgICAgY29udGVudDogT3VpQ29sbGFwc2libGVDb250ZW50Q29tcG9uZW50IHwgbnVsbDtcbiAgICAgIHRvZ2dsZTogT3VpQ29sbGFwc2libGVUb2dnbGVDb21wb25lbnQgfCBudWxsO1xuICAgICAgaXNPcGVuOiBib29sZWFuO1xuICAgIH07XG4gIH0gPSB7fTtcblxuICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgcHVibGljIHJlZ2lzdGVyVG9nZ2xlKGdyb3VwOiBzdHJpbmcsIHRvZ2dsZTogT3VpQ29sbGFwc2libGVUb2dnbGVDb21wb25lbnQpIHtcbiAgICBpZiAoIXRoaXMuY29sbGFwc2libGVzW2dyb3VwXSkge1xuICAgICAgdGhpcy5jb2xsYXBzaWJsZXNbZ3JvdXBdID0ge1xuICAgICAgICBjb250ZW50OiBudWxsLFxuICAgICAgICB0b2dnbGU6IHRvZ2dsZSxcbiAgICAgICAgaXNPcGVuOiB0b2dnbGUuaXNPcGVuLFxuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5jb2xsYXBzaWJsZXNbZ3JvdXBdLnRvZ2dsZSA9IHRvZ2dsZTtcbiAgICAgIHRoaXMuY29sbGFwc2libGVzW2dyb3VwXS5pc09wZW4gPSB0b2dnbGUuaXNPcGVuO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyByZWZyZXNoQ29sbGFwc2libGVDb250ZW50SGVpZ2h0KGdyb3VwOiBzdHJpbmcpIHtcbiAgICBpZiAodGhpcy5jb2xsYXBzaWJsZXNbZ3JvdXBdKSB7XG4gICAgICB0aGlzLnJlZnJlc2hDb2xsYXBzaWJsZUNvbnRlbnRIZWlnaHRTdWJqZWN0Lm5leHQoZ3JvdXApO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyByZWdpc3RlckNvbnRlbnQoXG4gICAgZ3JvdXA6IHN0cmluZyxcbiAgICBjb250ZW50OiBPdWlDb2xsYXBzaWJsZUNvbnRlbnRDb21wb25lbnRcbiAgKSB7XG4gICAgaWYgKCF0aGlzLmNvbGxhcHNpYmxlc1tncm91cF0pIHtcbiAgICAgIHRoaXMuY29sbGFwc2libGVzW2dyb3VwXSA9IHtcbiAgICAgICAgY29udGVudDogY29udGVudCxcbiAgICAgICAgdG9nZ2xlOiBudWxsLFxuICAgICAgICBpc09wZW46IGZhbHNlLFxuICAgICAgfTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5jb2xsYXBzaWJsZXNbZ3JvdXBdLmNvbnRlbnQgPSBjb250ZW50O1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBkZXJlZ2lzdGVyQ29sbGFwc2libGUoZ3JvdXA6IHN0cmluZykge1xuICAgIGlmICh0aGlzLmNvbGxhcHNpYmxlc1tncm91cF0pIHtcbiAgICAgIGRlbGV0ZSB0aGlzLmNvbGxhcHNpYmxlc1tncm91cF07XG4gICAgfVxuICB9XG5cbiAgcHVibGljIHRvZ2dsZShncm91cDogc3RyaW5nLCBpc09wZW4/OiBib29sZWFuKSB7XG4gICAgaWYgKHRoaXMuY29sbGFwc2libGVzW2dyb3VwXSkge1xuICAgICAgY29uc3QgbmV3SXNPcGVuID0gaXNOaWwoaXNPcGVuKVxuICAgICAgICA/ICF0aGlzLmNvbGxhcHNpYmxlc1tncm91cF0uaXNPcGVuXG4gICAgICAgIDogaXNPcGVuO1xuICAgICAgdGhpcy5jb2xsYXBzaWJsZXNbZ3JvdXBdLmlzT3BlbiA9IG5ld0lzT3BlbjtcbiAgICAgIHRoaXMuY29sbGFwc2libGVUb2dnbGVkU3ViamVjdC5uZXh0KHtcbiAgICAgICAgZ3JvdXAsXG4gICAgICAgIGlzT3BlbjogbmV3SXNPcGVuLFxuICAgICAgfSk7XG4gICAgfVxuICB9XG59XG4iXX0=