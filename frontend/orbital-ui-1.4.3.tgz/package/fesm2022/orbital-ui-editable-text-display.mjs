import * as i0 from '@angular/core';
import { EventEmitter, signal, Component, ChangeDetectionStrategy, Inject, ViewChild, Input, Output } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { OuiInputComponent } from 'orbital-ui/input';
import { OuiIconButtonComponent } from 'orbital-ui/icon-button';

/**
 * Component to enable having a text that's display normally, but that can be toggled to be editable
 * by clicking on a button. The edit can then be either canceled or accepted.
 *
 *   Example use:
 *
 *   <oui-editable-text-display [(model)]="myText"></oui-editable-text-display>
 */
class OuiEditableTextDisplayComponent {
    document;
    placeholderElement;
    textInput;
    set options(options) {
        this.optionsSignal.set({
            ...this.defaultOptions,
            ...options
        });
    }
    ;
    /**
     * A placeholder to be shown if there's no text
     */
    placeholder;
    /**
     *   The text to be shown
     */
    model;
    /**
     *   Whether or not the text-field is currently being edited
     */
    isEditing = false;
    /**
     *  Whether or not the text-field should size to the content
     */
    sizeToContent = false;
    /**
     *   Event that's emitted when the text is edited
     */
    modelChange = new EventEmitter();
    textDisplay;
    originalModel;
    defaultOptions = {
        placeholder: '',
        sizeToContent: false,
        maxLength: undefined
    };
    optionsSignal = signal({
        ...this.defaultOptions
    });
    iconOptions = {
        strokeColor: 'oui-editable-text-display-edit-icon-color',
        fillColor: 'oui-editable-text-display-edit-icon-color',
        size: 'oui-editable-text-display-edit-icon-size',
    };
    fontSize = '1.6rem';
    constructor(document) {
        this.document = document;
    }
    onModelChange(model) {
        this.model = model;
    }
    submitEdit() {
        this.stopEditing();
        this.originalModel = this.model;
        this.modelChange.emit(this.model);
    }
    cancelEdit() {
        this.stopEditing();
        this.model = this.originalModel;
    }
    stopEditing() {
        this.isEditing = false;
        this.textDisplay.nativeElement.style.width = 'auto';
        this.textDisplay.nativeElement.style.minWidth = 'auto';
    }
    startEdit() {
        if (!this.optionsSignal().sizeToContent) {
            this.textDisplay.nativeElement.style.width =
                this.textDisplay.nativeElement.getBoundingClientRect().width + 'px';
        }
        else {
            this.textDisplay.nativeElement.style.minWidth =
                this.textDisplay.nativeElement.getBoundingClientRect().width + 'px';
        }
        this.isEditing = true;
        setTimeout(() => {
            this.textInput.inputElement.nativeElement.focus();
        });
    }
    ngAfterViewInit() {
        this.originalModel = this.model;
        this.fontSize = getComputedStyle(this.document.documentElement).getPropertyValue(`--oui-editable-text-display-font-size`);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiEditableTextDisplayComponent, deps: [{ token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiEditableTextDisplayComponent, isStandalone: true, selector: "oui-editable-text-display", inputs: { options: "options", placeholder: "placeholder", model: "model", isEditing: "isEditing", sizeToContent: "sizeToContent" }, outputs: { modelChange: "modelChange" }, viewQueries: [{ propertyName: "placeholderElement", first: true, predicate: ["placeholderElement"], descendants: true }, { propertyName: "textInput", first: true, predicate: ["textInput"], descendants: true }, { propertyName: "textDisplay", first: true, predicate: ["textDisplay"], descendants: true }], ngImport: i0, template: "<div class=\"editable-text-display-container\">\n  <div class=\"text\" #textDisplay>\n    @if (!isEditing && !model && optionsSignal().placeholder) {\n      <span\n        (click)=\"startEdit()\"\n        #placeholderElement\n        class=\"text-display placeholder\"\n        >{{ optionsSignal().placeholder }}</span\n        >\n      }\n      @if (!isEditing) {\n        <span (click)=\"startEdit()\" class=\"text-display\">{{\n          model\n        }}</span>\n      }\n      @if (isEditing) {\n        <oui-input\n          #textInput\n      [options]=\"{\n        fontSize: fontSize,\n        variant: 'underlined',\n        sizeToContent: optionsSignal().sizeToContent,\n        noPadding: true,\n      }\"\n          [model]=\"model\"\n          (modelChange)=\"onModelChange($event)\"\n        ></oui-input>\n      }\n    </div>\n    <div class=\"actions\">\n      @if (!isEditing) {\n        <oui-icon-button\n          [options]=\"iconOptions\"\n          (onClick)=\"startEdit()\"\n          icon=\"assets/icons/edit.svg\"\n        ></oui-icon-button>\n      }\n      @if (isEditing) {\n        <oui-icon-button\n      [options]=\"{\n        strokeColor: 'color-success',\n        fillColor: 'color-success',\n        size: iconOptions.size,\n        height: iconOptions.height,\n        width: iconOptions.width\n      }\"\n          color=\"transparent\"\n          (onClick)=\"submitEdit()\"\n          icon=\"assets/icons/check.svg\"\n        ></oui-icon-button>\n      }\n      @if (isEditing) {\n        <oui-icon-button\n      [options]=\"{\n        strokeColor: 'color-danger',\n        fillColor: 'color-danger',\n        size: iconOptions.size,\n        height: iconOptions.height,\n        width: iconOptions.width\n      }\"\n          color=\"transparent\"\n          (onClick)=\"cancelEdit()\"\n          icon=\"assets/icons/close.svg\"\n        ></oui-icon-button>\n      }\n    </div>\n  </div>\n", styles: [":host{min-height:3rem;--oui-input-underline-color: var(--oui-editable-text-display-underline-color);--oui-icon-button-background-color: var( --oui-editable-text-display-edit-icon-background );--oui-icon-button-background-color-hover: var( --oui-editable-text-display-edit-icon-background-hover )}:host .editable-text-display-container{display:flex;align-items:center}:host .editable-text-display-container .text-display{color:var(--oui-editable-text-display-text-color)}:host .editable-text-display-container .text{min-height:3rem;font-size:var(--font-size-body-regular);min-width:1rem;width:100%;margin-right:1rem;display:flex;color:var(--oui-editable-text-display-text-color);align-items:center}:host .editable-text-display-container .text:hover{cursor:pointer}:host .editable-text-display-container .text oui-input{min-height:3rem;height:100%;width:100%}:host .editable-text-display-container .text .text-display{font-size:var(--oui-editable-text-display-font-size);color:var(--oui-editable-text-display-text-color);align-items:center;display:flex;margin-right:1rem}:host .editable-text-display-container .text .text-display.placeholder{color:var(--oui-editable-text-display-placeholder-color)}:host .editable-text-display-container .actions{display:flex;align-items:center;justify-content:center;height:100%}\n"], dependencies: [{ kind: "component", type: OuiInputComponent, selector: "oui-input", inputs: ["model", "options"], outputs: ["modelChange", "hasErrorChange"] }, { kind: "component", type: OuiIconButtonComponent, selector: "oui-icon-button", inputs: ["icon", "isLoading", "options"], outputs: ["onClick"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiEditableTextDisplayComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-editable-text-display', standalone: true, imports: [OuiInputComponent, OuiIconButtonComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"editable-text-display-container\">\n  <div class=\"text\" #textDisplay>\n    @if (!isEditing && !model && optionsSignal().placeholder) {\n      <span\n        (click)=\"startEdit()\"\n        #placeholderElement\n        class=\"text-display placeholder\"\n        >{{ optionsSignal().placeholder }}</span\n        >\n      }\n      @if (!isEditing) {\n        <span (click)=\"startEdit()\" class=\"text-display\">{{\n          model\n        }}</span>\n      }\n      @if (isEditing) {\n        <oui-input\n          #textInput\n      [options]=\"{\n        fontSize: fontSize,\n        variant: 'underlined',\n        sizeToContent: optionsSignal().sizeToContent,\n        noPadding: true,\n      }\"\n          [model]=\"model\"\n          (modelChange)=\"onModelChange($event)\"\n        ></oui-input>\n      }\n    </div>\n    <div class=\"actions\">\n      @if (!isEditing) {\n        <oui-icon-button\n          [options]=\"iconOptions\"\n          (onClick)=\"startEdit()\"\n          icon=\"assets/icons/edit.svg\"\n        ></oui-icon-button>\n      }\n      @if (isEditing) {\n        <oui-icon-button\n      [options]=\"{\n        strokeColor: 'color-success',\n        fillColor: 'color-success',\n        size: iconOptions.size,\n        height: iconOptions.height,\n        width: iconOptions.width\n      }\"\n          color=\"transparent\"\n          (onClick)=\"submitEdit()\"\n          icon=\"assets/icons/check.svg\"\n        ></oui-icon-button>\n      }\n      @if (isEditing) {\n        <oui-icon-button\n      [options]=\"{\n        strokeColor: 'color-danger',\n        fillColor: 'color-danger',\n        size: iconOptions.size,\n        height: iconOptions.height,\n        width: iconOptions.width\n      }\"\n          color=\"transparent\"\n          (onClick)=\"cancelEdit()\"\n          icon=\"assets/icons/close.svg\"\n        ></oui-icon-button>\n      }\n    </div>\n  </div>\n", styles: [":host{min-height:3rem;--oui-input-underline-color: var(--oui-editable-text-display-underline-color);--oui-icon-button-background-color: var( --oui-editable-text-display-edit-icon-background );--oui-icon-button-background-color-hover: var( --oui-editable-text-display-edit-icon-background-hover )}:host .editable-text-display-container{display:flex;align-items:center}:host .editable-text-display-container .text-display{color:var(--oui-editable-text-display-text-color)}:host .editable-text-display-container .text{min-height:3rem;font-size:var(--font-size-body-regular);min-width:1rem;width:100%;margin-right:1rem;display:flex;color:var(--oui-editable-text-display-text-color);align-items:center}:host .editable-text-display-container .text:hover{cursor:pointer}:host .editable-text-display-container .text oui-input{min-height:3rem;height:100%;width:100%}:host .editable-text-display-container .text .text-display{font-size:var(--oui-editable-text-display-font-size);color:var(--oui-editable-text-display-text-color);align-items:center;display:flex;margin-right:1rem}:host .editable-text-display-container .text .text-display.placeholder{color:var(--oui-editable-text-display-placeholder-color)}:host .editable-text-display-container .actions{display:flex;align-items:center;justify-content:center;height:100%}\n"] }]
        }], ctorParameters: () => [{ type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { placeholderElement: [{
                type: ViewChild,
                args: ['placeholderElement']
            }], textInput: [{
                type: ViewChild,
                args: ['textInput']
            }], options: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], model: [{
                type: Input
            }], isEditing: [{
                type: Input
            }], sizeToContent: [{
                type: Input
            }], modelChange: [{
                type: Output
            }], textDisplay: [{
                type: ViewChild,
                args: ['textDisplay']
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiEditableTextDisplayComponent };
//# sourceMappingURL=orbital-ui-editable-text-display.mjs.map
