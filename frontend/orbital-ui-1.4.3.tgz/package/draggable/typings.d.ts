import { OuiDraggableDirective } from './draggable.directive';
export interface IDragMoveHookFunction {
    (draggable: OuiDraggableDirective, targetRect: DOMRect, event: MouseEvent | TouchEvent | undefined): DOMRect;
}
export type IDefaultBehaviorOptions = Partial<ICombinedDefaultBehaviorOptions>;
export type ICombinedDefaultBehaviorOptions = {
    throttle: number;
};
export interface IDraggableBehavior {
    onDragMove: (event: MouseEvent | TouchEvent) => void;
    onDragEnd: (event: MouseEvent | TouchEvent) => void;
    onDragStart: (event: MouseEvent | TouchEvent) => void;
}
export declare abstract class DraggableBehavior {
    private draggable;
    constructor(draggable: OuiDraggableDirective);
}
export interface IContainerConstraintOptions {
    container: HTMLElement;
    anchor: 'edge' | 'center';
}
export type IOuiSnapEvent = {
    target: HTMLElement;
    x: number;
    y: number;
};
export type IOuiDragMoveEvent = {
    event?: MouseEvent | TouchEvent;
    targetTransform: {
        x: number;
        y: number;
    };
    viewportPoint: {
        x: number;
        y: number;
    };
    currentTranslate: {
        x: number;
        y: number;
    };
};
export type IOuiDragMove = IOuiSnapEvent | IOuiDragMoveEvent;
export type IOuiDragStart = (event: MouseEvent | TouchEvent) => void;
export type IOuiDragEnd = (event: MouseEvent | TouchEvent | undefined) => void;
export interface IOuiDraggable {
    dragStart: (event: MouseEvent | TouchEvent) => void;
    dragMove: (event: IOuiDragMoveEvent) => void;
    dragEnd: (event: MouseEvent | TouchEvent) => void;
}
export interface IOuiSnapDraggable extends Omit<IOuiDraggable, 'dragMove'> {
    dragMove: (event: IOuiSnapEvent) => void;
}
//# sourceMappingURL=typings.d.ts.map