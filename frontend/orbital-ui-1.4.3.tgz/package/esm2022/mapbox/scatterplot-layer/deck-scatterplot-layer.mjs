import { ScatterplotLayer } from '@deck.gl/layers/typed';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { BindCommonDeckOptions } from '../deck/bind-default-deck-options';
import * as i0 from "@angular/core";
export class DeckScatterplotLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new ScatterplotLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            getPosition: this.options.getPosition,
            stroked: this.options.stroked ?? true,
            filled: this.options.filled ?? true,
            radiusScale: this.options.radiusScale ?? 1,
            radiusMinPixels: this.options.radiusMinPixels ?? 1,
            radiusMaxPixels: this.options.radiusMaxPixels ?? 9999,
            lineWidthMinPixels: this.options.lineWidthMinPixels ?? 1,
            lineWidthMaxPixels: this.options.lineWidthMaxPixels ?? 999,
            lineWidthUnits: this.options.lineWidthUnits ?? 'pixels',
            getRadius: this.options.getRadius,
            getFillColor: this.options.getFillColor,
            getLineColor: this.options.getLineColor,
            getLineWidth: this.options.getLineWidth
                ? this.options.getLineWidth
                : () => {
                    return 1;
                },
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckScatterplotLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckScatterplotLayer, isStandalone: true, selector: "oui-deck-scatterplot-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckScatterplotLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-scatterplot-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay1zY2F0dGVycGxvdC1sYXllci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvbWFwYm94L3NjYXR0ZXJwbG90LWxheWVyL2RlY2stc2NhdHRlcnBsb3QtbGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFLekQsT0FBTyxFQUFFLHVCQUF1QixFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDMUUsT0FBTyxFQUFFLGFBQWEsRUFBRSxNQUFNLDhCQUE4QixDQUFDO0FBQzdELE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxNQUFNLG1DQUFtQyxDQUFDOztBQVcxRSxNQUFNLE9BQU8sb0JBQXFCLFNBQVEsYUFBc0M7SUFDM0MsT0FBTyxDQUErQjtJQUV6RTtRQUNFLEtBQUssRUFBRSxDQUFDO0lBQ1YsQ0FBQztJQUVNLFFBQVE7UUFDYixPQUFPLElBQUksZ0JBQWdCLENBQUM7WUFDMUIsR0FBRyxxQkFBcUIsQ0FBQyxJQUFJLENBQUM7WUFDOUIsSUFBSSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSTtZQUN2QixXQUFXLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXO1lBQ3JDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sSUFBSSxJQUFJO1lBQ3JDLE1BQU0sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sSUFBSSxJQUFJO1lBQ25DLFdBQVcsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsSUFBSSxDQUFDO1lBQzFDLGVBQWUsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsSUFBSSxDQUFDO1lBQ2xELGVBQWUsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsSUFBSSxJQUFJO1lBQ3JELGtCQUFrQixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsa0JBQWtCLElBQUksQ0FBQztZQUN4RCxrQkFBa0IsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGtCQUFrQixJQUFJLEdBQUc7WUFDMUQsY0FBYyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxJQUFJLFFBQVE7WUFDdkQsU0FBUyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUztZQUNqQyxZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZO1lBQ3ZDLFlBQVksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVk7WUFDdkMsWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWTtnQkFDckMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWTtnQkFDM0IsQ0FBQyxDQUFDLEdBQUcsRUFBRTtvQkFDSCxPQUFPLENBQUMsQ0FBQztnQkFDWCxDQUFDO1NBQ04sQ0FBQyxDQUFDO0lBQ0wsQ0FBQzt1R0E3QlUsb0JBQW9COzJGQUFwQixvQkFBb0IsNklBTHJCLEVBQUU7OzJGQUtELG9CQUFvQjtrQkFQaEMsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsNEJBQTRCO29CQUN0QyxRQUFRLEVBQUUsRUFBRTtvQkFDWixVQUFVLEVBQUUsSUFBSTtvQkFDaEIsT0FBTyxFQUFFLEVBQUU7b0JBQ1gsZUFBZSxFQUFFLHVCQUF1QixDQUFDLE1BQU07aUJBQ2hEO3dEQUVvQyxPQUFPO3NCQUF6QyxLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFNjYXR0ZXJwbG90TGF5ZXIgfSBmcm9tICdAZGVjay5nbC9sYXllcnMvdHlwZWQnO1xuaW1wb3J0IHtcbiAgSUNvbW1vbkRlY2tMYXllck9wdGlvbnMsXG4gIElEZWNrU2NhdHRlcnBsb3RMYXllck9wdGlvbnMsXG59IGZyb20gJy4uL3R5cGluZ3MnO1xuaW1wb3J0IHsgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksIENvbXBvbmVudCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEJhc2VEZWNrTGF5ZXIgfSBmcm9tICcuLi9iYXNlLWRlY2stbGF5ZXIuY29tcG9uZW50JztcbmltcG9ydCB7IEJpbmRDb21tb25EZWNrT3B0aW9ucyB9IGZyb20gJy4uL2RlY2svYmluZC1kZWZhdWx0LWRlY2stb3B0aW9ucyc7XG4vLyBAdHMtaWdub3JlXG5pbXBvcnQgeyBNYXBib3hMYXllciB9IGZyb20gJ0BkZWNrLmdsL21hcGJveCc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1kZWNrLXNjYXR0ZXJwbG90LWxheWVyJyxcbiAgdGVtcGxhdGU6ICcnLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIERlY2tTY2F0dGVycGxvdExheWVyIGV4dGVuZHMgQmFzZURlY2tMYXllcjxJQ29tbW9uRGVja0xheWVyT3B0aW9ucz4ge1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KSBkZWNsYXJlIG9wdGlvbnM6IElEZWNrU2NhdHRlcnBsb3RMYXllck9wdGlvbnM7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHB1YmxpYyBnZXRMYXllcigpIHtcbiAgICByZXR1cm4gbmV3IFNjYXR0ZXJwbG90TGF5ZXIoe1xuICAgICAgLi4uQmluZENvbW1vbkRlY2tPcHRpb25zKHRoaXMpLFxuICAgICAgZGF0YTogdGhpcy5vcHRpb25zLmRhdGEsXG4gICAgICBnZXRQb3NpdGlvbjogdGhpcy5vcHRpb25zLmdldFBvc2l0aW9uLFxuICAgICAgc3Ryb2tlZDogdGhpcy5vcHRpb25zLnN0cm9rZWQgPz8gdHJ1ZSxcbiAgICAgIGZpbGxlZDogdGhpcy5vcHRpb25zLmZpbGxlZCA/PyB0cnVlLFxuICAgICAgcmFkaXVzU2NhbGU6IHRoaXMub3B0aW9ucy5yYWRpdXNTY2FsZSA/PyAxLFxuICAgICAgcmFkaXVzTWluUGl4ZWxzOiB0aGlzLm9wdGlvbnMucmFkaXVzTWluUGl4ZWxzID8/IDEsXG4gICAgICByYWRpdXNNYXhQaXhlbHM6IHRoaXMub3B0aW9ucy5yYWRpdXNNYXhQaXhlbHMgPz8gOTk5OSxcbiAgICAgIGxpbmVXaWR0aE1pblBpeGVsczogdGhpcy5vcHRpb25zLmxpbmVXaWR0aE1pblBpeGVscyA/PyAxLFxuICAgICAgbGluZVdpZHRoTWF4UGl4ZWxzOiB0aGlzLm9wdGlvbnMubGluZVdpZHRoTWF4UGl4ZWxzID8/IDk5OSxcbiAgICAgIGxpbmVXaWR0aFVuaXRzOiB0aGlzLm9wdGlvbnMubGluZVdpZHRoVW5pdHMgPz8gJ3BpeGVscycsXG4gICAgICBnZXRSYWRpdXM6IHRoaXMub3B0aW9ucy5nZXRSYWRpdXMsXG4gICAgICBnZXRGaWxsQ29sb3I6IHRoaXMub3B0aW9ucy5nZXRGaWxsQ29sb3IsXG4gICAgICBnZXRMaW5lQ29sb3I6IHRoaXMub3B0aW9ucy5nZXRMaW5lQ29sb3IsXG4gICAgICBnZXRMaW5lV2lkdGg6IHRoaXMub3B0aW9ucy5nZXRMaW5lV2lkdGhcbiAgICAgICAgPyB0aGlzLm9wdGlvbnMuZ2V0TGluZVdpZHRoXG4gICAgICAgIDogKCkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIDE7XG4gICAgICAgICAgfSxcbiAgICB9KTtcbiAgfVxufVxuIl19