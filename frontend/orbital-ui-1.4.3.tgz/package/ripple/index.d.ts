/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/ripple" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-ripple.d.ts.map