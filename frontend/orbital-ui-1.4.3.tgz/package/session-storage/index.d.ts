/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/session-storage" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-session-storage.d.ts.map