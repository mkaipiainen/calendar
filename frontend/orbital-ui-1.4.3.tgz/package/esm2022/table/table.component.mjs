import { Component, computed, Input, signal, ViewChild, } from '@angular/core';
import { NgTemplateOutlet } from '@angular/common';
import { TableService } from './table.service';
import { OuiTableBodyComponent } from './table-body/oui-table-body.component';
import { OuiTableHeadComponent } from './table-head/oui-table-head.component';
import { NgxResize } from 'ngxtension/resize';
import * as i0 from "@angular/core";
import * as i1 from "./table.service";
export class OuiTableComponent {
    tableService;
    outerColumnWrapper;
    innerColumnWrapper;
    componentWrapper;
    items = [];
    set columns(newColumns) {
        this.columnsSignal.set(newColumns);
    }
    get columns() {
        return this.columnsSignal();
    }
    set options(newOptions) {
        this.optionsSignal.set(newOptions);
        this.onOptionsChanged();
    }
    get options() {
        return this.optionsSignal();
    }
    columnsSignal = signal([]);
    defaultOptions = {
        hasVirtualScroll: true,
        itemHeight: 50,
        trackBy: 'id',
    };
    optionsSignal = signal({});
    combinedOptions = computed(() => {
        return {
            ...this.defaultOptions,
            ...this.optionsSignal(),
        };
    });
    constructor(tableService) {
        this.tableService = tableService;
    }
    onResize(result) {
        this.tableService.setTableHeight(result);
    }
    onItemsChanged() {
        this.tableService.setItems(this.items.map((item, index) => {
            return {
                item,
                index,
            };
        }));
    }
    onOptionsChanged() {
        this.tableService.setOptions(this.combinedOptions());
    }
    onColumnsChanged() {
        this.tableService.setColumns(this.columnsSignal());
    }
    ngOnChanges(changes) {
        if ('items' in changes) {
            this.items = changes.items.currentValue;
            this.onItemsChanged();
        }
        if ('columns' in changes) {
            this.columns = changes.columns.currentValue;
            this.onColumnsChanged();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTableComponent, deps: [{ token: i1.TableService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiTableComponent, isStandalone: true, selector: "oui-table", inputs: { items: "items", columns: "columns", options: "options" }, providers: [TableService], viewQueries: [{ propertyName: "outerColumnWrapper", first: true, predicate: ["outerColumnWrapper"], descendants: true, static: true }, { propertyName: "innerColumnWrapper", first: true, predicate: ["innerColumnWrapper"], descendants: true, static: true }, { propertyName: "componentWrapper", first: true, predicate: ["componentWrapper"], descendants: true, static: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"table-wrapper\" #componentWrapper (ngxResize)=\"onResize($event)\">\n  <div class=\"table-inner-wrapper\">\n    <div class=\"column-header-wrapper\">\n      <oui-table-head [tableService]=\"tableService\"></oui-table-head>\n    </div>\n    <div class=\"column-body-wrapper\">\n      <oui-table-body [tableService]=\"tableService\" [options]=\"combinedOptions()\"></oui-table-body>\n    </div>\n  </div>\n</div>\n", styles: [":host{width:100%;height:100%}:host .table-wrapper{width:100%;height:100%;max-height:100%;position:relative}:host .table-wrapper .table-inner-wrapper{width:100%;height:100%;display:flex;flex-direction:column;position:relative}:host .table-wrapper .table-inner-wrapper .column-header-wrapper{display:flex;flex:0 0 var(--oui-table-header-height);border-width:var(--oui-table-header-border-width);border-style:var(--oui-table-header-border-style);border-color:var(--oui-table-header-border-color);border-radius:var(--oui-table-border-radius);height:auto;position:relative}:host .table-wrapper .table-inner-wrapper .column-body-wrapper{display:flex;flex:1;position:relative;flex-direction:column;overflow:hidden}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .row{display:flex}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .row .item{flex:1;height:var(--oui-table-item-height)}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .inner-column-body-wrapper{flex:1;position:absolute;top:0;width:100%;left:0;transition:transform .3s;display:flex}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .inner-column-body-wrapper .scrollDummy{position:relative;width:100%;height:100%}\n"], dependencies: [{ kind: "component", type: OuiTableBodyComponent, selector: "oui-table-body", inputs: ["tableService", "options"] }, { kind: "component", type: OuiTableHeadComponent, selector: "oui-table-head", inputs: ["tableService"] }, { kind: "directive", type: NgxResize, selector: "[ngxResize]", inputs: ["ngxResizeOptions"], outputs: ["ngxResize"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-table', standalone: true, imports: [
                        NgTemplateOutlet,
                        OuiTableBodyComponent,
                        OuiTableHeadComponent,
                        NgxResize,
                    ], providers: [TableService], template: "<div class=\"table-wrapper\" #componentWrapper (ngxResize)=\"onResize($event)\">\n  <div class=\"table-inner-wrapper\">\n    <div class=\"column-header-wrapper\">\n      <oui-table-head [tableService]=\"tableService\"></oui-table-head>\n    </div>\n    <div class=\"column-body-wrapper\">\n      <oui-table-body [tableService]=\"tableService\" [options]=\"combinedOptions()\"></oui-table-body>\n    </div>\n  </div>\n</div>\n", styles: [":host{width:100%;height:100%}:host .table-wrapper{width:100%;height:100%;max-height:100%;position:relative}:host .table-wrapper .table-inner-wrapper{width:100%;height:100%;display:flex;flex-direction:column;position:relative}:host .table-wrapper .table-inner-wrapper .column-header-wrapper{display:flex;flex:0 0 var(--oui-table-header-height);border-width:var(--oui-table-header-border-width);border-style:var(--oui-table-header-border-style);border-color:var(--oui-table-header-border-color);border-radius:var(--oui-table-border-radius);height:auto;position:relative}:host .table-wrapper .table-inner-wrapper .column-body-wrapper{display:flex;flex:1;position:relative;flex-direction:column;overflow:hidden}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .row{display:flex}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .row .item{flex:1;height:var(--oui-table-item-height)}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .inner-column-body-wrapper{flex:1;position:absolute;top:0;width:100%;left:0;transition:transform .3s;display:flex}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .inner-column-body-wrapper .scrollDummy{position:relative;width:100%;height:100%}\n"] }]
        }], ctorParameters: () => [{ type: i1.TableService }], propDecorators: { outerColumnWrapper: [{
                type: ViewChild,
                args: ['outerColumnWrapper', { static: true }]
            }], innerColumnWrapper: [{
                type: ViewChild,
                args: ['innerColumnWrapper', { static: true }]
            }], componentWrapper: [{
                type: ViewChild,
                args: ['componentWrapper', { static: true }]
            }], items: [{
                type: Input,
                args: [{ required: true }]
            }], columns: [{
                type: Input,
                args: [{ required: true }]
            }], options: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGFibGUuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS90YWJsZS90YWJsZS5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3RhYmxlL3RhYmxlLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFFTCxTQUFTLEVBQ1QsUUFBUSxFQUdSLEtBQUssRUFFTCxNQUFNLEVBRU4sU0FBUyxHQUNWLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ25ELE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQU0vQyxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSx1Q0FBdUMsQ0FBQztBQUM5RSxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSx1Q0FBdUMsQ0FBQztBQUM5RSxPQUFPLEVBQUUsU0FBUyxFQUFnQixNQUFNLG1CQUFtQixDQUFDOzs7QUFlNUQsTUFBTSxPQUFPLGlCQUFpQjtJQXFDVDtJQW5DbkIsa0JBQWtCLENBQWtCO0lBRXBDLGtCQUFrQixDQUFrQjtJQUVwQyxnQkFBZ0IsQ0FBa0I7SUFDUCxLQUFLLEdBQVUsRUFBRSxDQUFDO0lBQzdDLElBQStCLE9BQU8sQ0FBQyxVQUE2QjtRQUNsRSxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUNyQyxDQUFDO0lBRUQsSUFBSSxPQUFPO1FBQ1QsT0FBTyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDOUIsQ0FBQztJQUNELElBQWEsT0FBTyxDQUFDLFVBQTRCO1FBQy9DLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFDRCxJQUFJLE9BQU87UUFDVCxPQUFPLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBRU0sYUFBYSxHQUFHLE1BQU0sQ0FBb0IsRUFBRSxDQUFDLENBQUM7SUFDN0MsY0FBYyxHQUE2QjtRQUNqRCxnQkFBZ0IsRUFBRSxJQUFJO1FBQ3RCLFVBQVUsRUFBRSxFQUFFO1FBQ2QsT0FBTyxFQUFFLElBQUk7S0FDZCxDQUFDO0lBRUssYUFBYSxHQUFHLE1BQU0sQ0FBbUIsRUFBRSxDQUFDLENBQUM7SUFDN0MsZUFBZSxHQUFHLFFBQVEsQ0FBQyxHQUFHLEVBQUU7UUFDckMsT0FBTztZQUNMLEdBQUcsSUFBSSxDQUFDLGNBQWM7WUFDdEIsR0FBRyxJQUFJLENBQUMsYUFBYSxFQUFFO1NBQ3hCLENBQUM7SUFDSixDQUFDLENBQUMsQ0FBQztJQUNILFlBQW1CLFlBQTBCO1FBQTFCLGlCQUFZLEdBQVosWUFBWSxDQUFjO0lBQUcsQ0FBQztJQUMxQyxRQUFRLENBQUMsTUFBb0I7UUFDbEMsSUFBSSxDQUFDLFlBQVksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUNPLGNBQWM7UUFDcEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQ3hCLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxFQUFFO1lBQzdCLE9BQU87Z0JBQ0wsSUFBSTtnQkFDSixLQUFLO2FBQ04sQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUNILENBQUM7SUFDSixDQUFDO0lBRU8sZ0JBQWdCO1FBQ3RCLElBQUksQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZELENBQUM7SUFFTyxnQkFBZ0I7UUFDdEIsSUFBSSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUVNLFdBQVcsQ0FBQyxPQUFzQjtRQUN2QyxJQUFJLE9BQU8sSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUN2QixJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN4QixDQUFDO1FBQ0QsSUFBSSxTQUFTLElBQUksT0FBTyxFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQztZQUM1QyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUMxQixDQUFDO0lBQ0gsQ0FBQzt1R0FyRVUsaUJBQWlCOzJGQUFqQixpQkFBaUIsNEhBRmpCLENBQUMsWUFBWSxDQUFDLHFhQ2xDM0IsMmFBVUEsc3dDRG9CSSxxQkFBcUIsZ0dBQ3JCLHFCQUFxQixxRkFDckIsU0FBUzs7MkZBSUEsaUJBQWlCO2tCQWI3QixTQUFTOytCQUNFLFdBQVcsY0FHVCxJQUFJLFdBQ1A7d0JBQ1AsZ0JBQWdCO3dCQUNoQixxQkFBcUI7d0JBQ3JCLHFCQUFxQjt3QkFDckIsU0FBUztxQkFDVixhQUNVLENBQUMsWUFBWSxDQUFDO2lGQUl6QixrQkFBa0I7c0JBRGpCLFNBQVM7dUJBQUMsb0JBQW9CLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFO2dCQUdqRCxrQkFBa0I7c0JBRGpCLFNBQVM7dUJBQUMsb0JBQW9CLEVBQUUsRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFO2dCQUdqRCxnQkFBZ0I7c0JBRGYsU0FBUzt1QkFBQyxrQkFBa0IsRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUU7Z0JBRXBCLEtBQUs7c0JBQS9CLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFO2dCQUNNLE9BQU87c0JBQXJDLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFO2dCQU9aLE9BQU87c0JBQW5CLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBDb21wb25lbnQsXG4gIGNvbXB1dGVkLFxuICBEZXN0cm95UmVmLFxuICBFbGVtZW50UmVmLFxuICBJbnB1dCxcbiAgT25DaGFuZ2VzLFxuICBzaWduYWwsXG4gIFNpbXBsZUNoYW5nZXMsXG4gIFZpZXdDaGlsZCxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOZ1RlbXBsYXRlT3V0bGV0IH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IFRhYmxlU2VydmljZSB9IGZyb20gJy4vdGFibGUuc2VydmljZSc7XG5pbXBvcnQge1xuICBJT3VpVGFibGVDb2x1bW4sXG4gIElPdWlUYWJsZUNvbWJpbmVkT3B0aW9ucyxcbiAgSU91aVRhYmxlT3B0aW9ucyxcbn0gZnJvbSAnLi90eXBlcyc7XG5pbXBvcnQgeyBPdWlUYWJsZUJvZHlDb21wb25lbnQgfSBmcm9tICcuL3RhYmxlLWJvZHkvb3VpLXRhYmxlLWJvZHkuY29tcG9uZW50JztcbmltcG9ydCB7IE91aVRhYmxlSGVhZENvbXBvbmVudCB9IGZyb20gJy4vdGFibGUtaGVhZC9vdWktdGFibGUtaGVhZC5jb21wb25lbnQnO1xuaW1wb3J0IHsgTmd4UmVzaXplLCBSZXNpemVSZXN1bHQgfSBmcm9tICduZ3h0ZW5zaW9uL3Jlc2l6ZSc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS10YWJsZScsXG4gIHRlbXBsYXRlVXJsOiAnLi90YWJsZS5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL3RhYmxlLmNvbXBvbmVudC5zY3NzJ10sXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtcbiAgICBOZ1RlbXBsYXRlT3V0bGV0LFxuICAgIE91aVRhYmxlQm9keUNvbXBvbmVudCxcbiAgICBPdWlUYWJsZUhlYWRDb21wb25lbnQsXG4gICAgTmd4UmVzaXplLFxuICBdLFxuICBwcm92aWRlcnM6IFtUYWJsZVNlcnZpY2VdLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlUYWJsZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XG4gIEBWaWV3Q2hpbGQoJ291dGVyQ29sdW1uV3JhcHBlcicsIHsgc3RhdGljOiB0cnVlIH0pXG4gIG91dGVyQ29sdW1uV3JhcHBlcjogRWxlbWVudFJlZjxhbnk+O1xuICBAVmlld0NoaWxkKCdpbm5lckNvbHVtbldyYXBwZXInLCB7IHN0YXRpYzogdHJ1ZSB9KVxuICBpbm5lckNvbHVtbldyYXBwZXI6IEVsZW1lbnRSZWY8YW55PjtcbiAgQFZpZXdDaGlsZCgnY29tcG9uZW50V3JhcHBlcicsIHsgc3RhdGljOiB0cnVlIH0pXG4gIGNvbXBvbmVudFdyYXBwZXI6IEVsZW1lbnRSZWY8YW55PjtcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSkgaXRlbXM6IGFueVtdID0gW107XG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pIHNldCBjb2x1bW5zKG5ld0NvbHVtbnM6IElPdWlUYWJsZUNvbHVtbltdKSB7XG4gICAgdGhpcy5jb2x1bW5zU2lnbmFsLnNldChuZXdDb2x1bW5zKTtcbiAgfVxuXG4gIGdldCBjb2x1bW5zKCkge1xuICAgIHJldHVybiB0aGlzLmNvbHVtbnNTaWduYWwoKTtcbiAgfVxuICBASW5wdXQoKSBzZXQgb3B0aW9ucyhuZXdPcHRpb25zOiBJT3VpVGFibGVPcHRpb25zKSB7XG4gICAgdGhpcy5vcHRpb25zU2lnbmFsLnNldChuZXdPcHRpb25zKTtcbiAgICB0aGlzLm9uT3B0aW9uc0NoYW5nZWQoKTtcbiAgfVxuICBnZXQgb3B0aW9ucygpIHtcbiAgICByZXR1cm4gdGhpcy5vcHRpb25zU2lnbmFsKCk7XG4gIH1cblxuICBwdWJsaWMgY29sdW1uc1NpZ25hbCA9IHNpZ25hbDxJT3VpVGFibGVDb2x1bW5bXT4oW10pO1xuICBwcml2YXRlIGRlZmF1bHRPcHRpb25zOiBJT3VpVGFibGVDb21iaW5lZE9wdGlvbnMgPSB7XG4gICAgaGFzVmlydHVhbFNjcm9sbDogdHJ1ZSxcbiAgICBpdGVtSGVpZ2h0OiA1MCxcbiAgICB0cmFja0J5OiAnaWQnLFxuICB9O1xuXG4gIHB1YmxpYyBvcHRpb25zU2lnbmFsID0gc2lnbmFsPElPdWlUYWJsZU9wdGlvbnM+KHt9KTtcbiAgcHVibGljIGNvbWJpbmVkT3B0aW9ucyA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICByZXR1cm4ge1xuICAgICAgLi4udGhpcy5kZWZhdWx0T3B0aW9ucyxcbiAgICAgIC4uLnRoaXMub3B0aW9uc1NpZ25hbCgpLFxuICAgIH07XG4gIH0pO1xuICBjb25zdHJ1Y3RvcihwdWJsaWMgdGFibGVTZXJ2aWNlOiBUYWJsZVNlcnZpY2UpIHt9XG4gIHB1YmxpYyBvblJlc2l6ZShyZXN1bHQ6IFJlc2l6ZVJlc3VsdCkge1xuICAgIHRoaXMudGFibGVTZXJ2aWNlLnNldFRhYmxlSGVpZ2h0KHJlc3VsdCk7XG4gIH1cbiAgcHJpdmF0ZSBvbkl0ZW1zQ2hhbmdlZCgpIHtcbiAgICB0aGlzLnRhYmxlU2VydmljZS5zZXRJdGVtcyhcbiAgICAgIHRoaXMuaXRlbXMubWFwKChpdGVtLCBpbmRleCkgPT4ge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIGl0ZW0sXG4gICAgICAgICAgaW5kZXgsXG4gICAgICAgIH07XG4gICAgICB9KVxuICAgICk7XG4gIH1cblxuICBwcml2YXRlIG9uT3B0aW9uc0NoYW5nZWQoKSB7XG4gICAgdGhpcy50YWJsZVNlcnZpY2Uuc2V0T3B0aW9ucyh0aGlzLmNvbWJpbmVkT3B0aW9ucygpKTtcbiAgfVxuXG4gIHByaXZhdGUgb25Db2x1bW5zQ2hhbmdlZCgpIHtcbiAgICB0aGlzLnRhYmxlU2VydmljZS5zZXRDb2x1bW5zKHRoaXMuY29sdW1uc1NpZ25hbCgpKTtcbiAgfVxuXG4gIHB1YmxpYyBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XG4gICAgaWYgKCdpdGVtcycgaW4gY2hhbmdlcykge1xuICAgICAgdGhpcy5pdGVtcyA9IGNoYW5nZXMuaXRlbXMuY3VycmVudFZhbHVlO1xuICAgICAgdGhpcy5vbkl0ZW1zQ2hhbmdlZCgpO1xuICAgIH1cbiAgICBpZiAoJ2NvbHVtbnMnIGluIGNoYW5nZXMpIHtcbiAgICAgIHRoaXMuY29sdW1ucyA9IGNoYW5nZXMuY29sdW1ucy5jdXJyZW50VmFsdWU7XG4gICAgICB0aGlzLm9uQ29sdW1uc0NoYW5nZWQoKTtcbiAgICB9XG4gIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJ0YWJsZS13cmFwcGVyXCIgI2NvbXBvbmVudFdyYXBwZXIgKG5neFJlc2l6ZSk9XCJvblJlc2l6ZSgkZXZlbnQpXCI+XG4gIDxkaXYgY2xhc3M9XCJ0YWJsZS1pbm5lci13cmFwcGVyXCI+XG4gICAgPGRpdiBjbGFzcz1cImNvbHVtbi1oZWFkZXItd3JhcHBlclwiPlxuICAgICAgPG91aS10YWJsZS1oZWFkIFt0YWJsZVNlcnZpY2VdPVwidGFibGVTZXJ2aWNlXCI+PC9vdWktdGFibGUtaGVhZD5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiY29sdW1uLWJvZHktd3JhcHBlclwiPlxuICAgICAgPG91aS10YWJsZS1ib2R5IFt0YWJsZVNlcnZpY2VdPVwidGFibGVTZXJ2aWNlXCIgW29wdGlvbnNdPVwiY29tYmluZWRPcHRpb25zKClcIj48L291aS10YWJsZS1ib2R5PlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvZGl2PlxuIl19