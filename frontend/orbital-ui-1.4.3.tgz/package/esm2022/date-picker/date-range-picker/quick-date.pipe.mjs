import { Pipe } from '@angular/core';
import { format, getMonth } from 'date-fns';
import * as i0 from "@angular/core";
export class QuickDatePipe {
    transform(value, translations) {
        if (!value) {
            return '';
        }
        const month = getMonth(value);
        return (translations.months[month].substring(0, 3) +
            ' ' +
            format(value, 'dd') +
            ', ' +
            format(value, 'yyyy'));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: QuickDatePipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: QuickDatePipe, isStandalone: true, name: "quickDate" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: QuickDatePipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'quickDate',
                    standalone: true,
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicXVpY2stZGF0ZS5waXBlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9kYXRlLXBpY2tlci9kYXRlLXJhbmdlLXBpY2tlci9xdWljay1kYXRlLnBpcGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLElBQUksRUFBaUIsTUFBTSxlQUFlLENBQUM7QUFDcEQsT0FBTyxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsTUFBTSxVQUFVLENBQUM7O0FBTzVDLE1BQU0sT0FBTyxhQUFhO0lBQ3hCLFNBQVMsQ0FDUCxLQUF1QixFQUN2QixZQUFvQztRQUVwQyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDWCxPQUFPLEVBQUUsQ0FBQztRQUNaLENBQUM7UUFDRCxNQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDOUIsT0FBTyxDQUNMLFlBQVksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDMUMsR0FBRztZQUNILE1BQU0sQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDO1lBQ25CLElBQUk7WUFDSixNQUFNLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUN0QixDQUFDO0lBQ0osQ0FBQzt1R0FoQlUsYUFBYTtxR0FBYixhQUFhOzsyRkFBYixhQUFhO2tCQUp6QixJQUFJO21CQUFDO29CQUNKLElBQUksRUFBRSxXQUFXO29CQUNqQixVQUFVLEVBQUUsSUFBSTtpQkFDakIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQaXBlLCBQaXBlVHJhbnNmb3JtIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBmb3JtYXQsIGdldE1vbnRoIH0gZnJvbSAnZGF0ZS1mbnMnO1xuaW1wb3J0IHsgSURhdGVMYWJlbFRyYW5zbGF0aW9ucyB9IGZyb20gJy4uL2RhdGUtcGlja2VyL2RhdGUtcGlja2VyLmNvbXBvbmVudCc7XG5cbkBQaXBlKHtcbiAgbmFtZTogJ3F1aWNrRGF0ZScsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG59KVxuZXhwb3J0IGNsYXNzIFF1aWNrRGF0ZVBpcGUgaW1wbGVtZW50cyBQaXBlVHJhbnNmb3JtIHtcbiAgdHJhbnNmb3JtKFxuICAgIHZhbHVlOiBEYXRlIHwgdW5kZWZpbmVkLFxuICAgIHRyYW5zbGF0aW9uczogSURhdGVMYWJlbFRyYW5zbGF0aW9uc1xuICApOiBzdHJpbmcge1xuICAgIGlmICghdmFsdWUpIHtcbiAgICAgIHJldHVybiAnJztcbiAgICB9XG4gICAgY29uc3QgbW9udGggPSBnZXRNb250aCh2YWx1ZSk7XG4gICAgcmV0dXJuIChcbiAgICAgIHRyYW5zbGF0aW9ucy5tb250aHNbbW9udGhdLnN1YnN0cmluZygwLCAzKSArXG4gICAgICAnICcgK1xuICAgICAgZm9ybWF0KHZhbHVlLCAnZGQnKSArXG4gICAgICAnLCAnICtcbiAgICAgIGZvcm1hdCh2YWx1ZSwgJ3l5eXknKVxuICAgICk7XG4gIH1cbn1cbiJdfQ==