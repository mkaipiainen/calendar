import { AfterViewInit, ElementRef, OnDestroy } from '@angular/core';
import { OuiPopupComponent } from './popup.component';
import * as i0 from "@angular/core";
export declare class BasicTextPopupComponent extends OuiPopupComponent implements AfterViewInit, OnDestroy {
    private elementRef;
    content: string;
    private destroyed$;
    constructor(elementRef: ElementRef);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BasicTextPopupComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BasicTextPopupComponent, "example-popup", never, { "content": { "alias": "content"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=basic-text-popup.component.d.ts.map