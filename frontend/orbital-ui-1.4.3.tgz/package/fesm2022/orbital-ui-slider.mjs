import * as i0 from '@angular/core';
import { model, input, computed, EventEmitter, Component, ViewChild, Output, ChangeDetectionStrategy, Inject, ViewChildren } from '@angular/core';
import { merge, debounce, isNil, throttle } from 'lodash-es';
import * as i1 from '@angular/common';
import { CommonModule, DOCUMENT, NgTemplateOutlet, NgClass, NgStyle } from '@angular/common';
import { OuiIconComponent } from 'orbital-ui/icon';
import { OuiDraggableDirective, OuiSnappableDirective } from 'orbital-ui/draggable';
import { GUID } from 'orbital-ui/helpers';
import { toObservable, takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { startWith, pairwise } from 'rxjs';

class OuiSliderComponent {
    thumbFrom;
    thumbFromContainer;
    thumbFromDraggable;
    thumbTo;
    thumbToContainer;
    thumbToDraggable;
    sliderBar;
    /**
     * The model for 'smaller' value. Use this alone if you want just a single-thumb mode.
     */
    value = model.required();
    /**
     * The model for the 'larger' value. Can be only used together with value-input
     */
    valueTo = model();
    /**
     * The options of the slider.
     */
    options = input.required();
    combinedOptions = computed(() => {
        const minLabel = this.options().minLabel ?? this.options().min.toString();
        const maxLabel = this.options().maxLabel ?? this.options().max.toString();
        return merge({ ...this.defaultOptions }, { ...this.options(), ...{ minLabel, maxLabel } });
    });
    /**
     * The event that's triggered whenever value changes (even by a little bit)
     */
    /**
     * The event that's triggered whenever the value changed, but this event is debounced by 300ms.
     */
    debouncedvalueChange = new EventEmitter();
    /**
     * The event that's triggered whenever valueTo changes (even by a little bit)
     */
    /**
     * The event that's triggered whenever the valueTo changed, but this event is debounced by 300ms.
     */
    debouncedValueToChange = new EventEmitter();
    defaultOptions = {
        min: 0,
        max: 100,
        minLabel: '0',
        maxLabel: '100',
        alignment: 'horizontal',
    };
    resizeObserver;
    _debouncedValueToChange = debounce((value) => {
        this.debouncedValueToChange.emit(value);
    }, 300);
    _debouncedvalueChange = debounce((value) => {
        this.debouncedvalueChange.emit(value);
    }, 300);
    constructor() { }
    updateBarFill() {
        const valueTo = this.valueTo();
        const value = this.value();
        if (!isNil(valueTo)) {
            const fillElement = this.sliderBar?.nativeElement?.querySelector(`.slider-bar-section-fill`);
            if (!fillElement) {
                return;
            }
            const percentageFrom = ((value - this.combinedOptions().min) /
                (this.combinedOptions().max - this.combinedOptions().min)) *
                100;
            const percentageTo = ((valueTo - this.combinedOptions().min) /
                (this.combinedOptions().max - this.combinedOptions().min)) *
                100;
            fillElement.style.width = `calc(${percentageTo}% - ${percentageFrom}%)`;
            fillElement.style.left = `calc(${percentageFrom}%`;
        }
        else {
            const fillElement = this.sliderBar?.nativeElement?.querySelector(`.slider-bar-section-fill`);
            if (!fillElement) {
                return;
            }
            const percentageFrom = ((value - this.combinedOptions().min) /
                (this.combinedOptions().max - this.combinedOptions().min)) *
                100;
            fillElement.style.width = `calc(${percentageFrom}%)`;
        }
    }
    initValues() {
        const value = this.value();
        const valueTo = this.valueTo();
        if (value < this.combinedOptions().min) {
            this.value.set(this.combinedOptions().min);
        }
        else if (value > this.combinedOptions().max) {
            this.value.set(this.combinedOptions().max);
        }
        if (!isNil(valueTo)) {
            if (valueTo > this.combinedOptions().max) {
                this.valueTo.set(this.combinedOptions().max);
            }
            else if (valueTo < this.combinedOptions().min) {
                this.valueTo.set(this.combinedOptions().min);
            }
        }
    }
    setThumbPosition(type) {
        const thumbContainer = this.getThumbContainer(type);
        const value = this.getValue(type);
        if (isNil(value)) {
            return;
        }
        if (thumbContainer?.nativeElement && !isNil(value)) {
            const percentage = (value - this.combinedOptions().min) /
                (this.combinedOptions().max - this.combinedOptions().min);
            const left = percentage *
                this.sliderBar?.nativeElement?.getBoundingClientRect().width -
                this.getOffset(type);
            if (type === 'from') {
                this.thumbFromDraggable.updateTransform({
                    x: left,
                    y: 0,
                });
            }
            else if (this.thumbToDraggable) {
                this.thumbToDraggable.updateTransform({
                    x: left,
                    y: 0,
                });
            }
        }
    }
    getThumbContainer(type) {
        if (type === 'from') {
            return this.thumbFromContainer;
        }
        else {
            return this.thumbToContainer;
        }
    }
    getValue(type) {
        if (type === 'from') {
            return this.value();
        }
        else {
            return this.valueTo();
        }
    }
    onDragMove(type, data) {
        const eventData = data;
        const newValue = this.getPercentage(eventData.currentTranslate.x + this.getOffset(type)) *
            (this.combinedOptions().max - this.combinedOptions().min) +
            this.combinedOptions().min;
        if (type === 'from') {
            this.value.set(newValue);
        }
        else {
            this.valueTo.set(newValue);
        }
        if (type === 'from') {
            this._debouncedvalueChange(this.value());
        }
        else {
            this._debouncedValueToChange(this.valueTo());
        }
        this.updateBarFill();
    }
    getOffset(type) {
        if (type === 'from') {
            return (this.thumbFromContainer.nativeElement.getBoundingClientRect().width / 2);
        }
        else {
            return (this.thumbToContainer?.nativeElement?.getBoundingClientRect()?.width /
                2 ?? 0);
        }
    }
    constrainPosition(clientPosition, type) {
        if (!isNil(this.valueTo())) {
            clientPosition = this.constrainPositionRange(clientPosition, type);
        }
        return clientPosition;
    }
    /**
     * Prevents the thumbs from crossing over one another
     * @param position
     * @param type
     * @private
     */
    constrainPositionRange(position, type) {
        const leftThumb = this.thumbFromContainer;
        const rightThumb = this.thumbToContainer;
        const targetPosition = position;
        if (type === 'from') {
            const left = rightThumb.nativeElement.getBoundingClientRect().left -
                this.sliderBar.nativeElement.getBoundingClientRect().left;
            if (targetPosition.x > left) {
                targetPosition.x = left;
            }
        }
        else {
            const left = leftThumb.nativeElement.getBoundingClientRect().left -
                this.sliderBar.nativeElement.getBoundingClientRect().left +
                leftThumb.nativeElement.getBoundingClientRect().width;
            if (targetPosition.x < left) {
                targetPosition.x = left;
            }
        }
        return targetPosition;
    }
    getPercentage(targetLeft) {
        const percentage = targetLeft / this.sliderBar.nativeElement.getBoundingClientRect().width;
        return Math.max(0, Math.min(1, percentage));
    }
    ngAfterViewInit() {
        this.thumbFromDraggable.addDefaultBehavior();
        this.thumbFromDraggable.addContainerConstraint({
            container: this.sliderBar.nativeElement,
            anchor: 'center',
        });
        this.thumbFromDraggable.addAxisConstraint(this.combinedOptions().alignment === 'horizontal' ? 'x' : 'y');
        if (this.thumbToDraggable) {
            this.thumbToDraggable.addDefaultBehavior();
            this.thumbToDraggable.addContainerConstraint({
                container: this.sliderBar.nativeElement,
                anchor: 'center',
            });
            this.thumbToDraggable.addAxisConstraint(this.combinedOptions().alignment === 'horizontal' ? 'x' : 'y');
        }
        setTimeout(() => {
            this.initResizeObserver();
            this.initValues();
            this.setThumbPositions();
            this.updateBarFill();
        });
    }
    initResizeObserver() {
        const debouncedResize = throttle(() => {
            this.setThumbPositions();
        }, 50);
        this.resizeObserver = new ResizeObserver(() => {
            debouncedResize();
        });
        this.resizeObserver.observe(this.sliderBar?.nativeElement);
    }
    ngOnChanges(changes) {
        const changeKeys = Object.keys(changes);
        if (changeKeys.includes('options')) {
            this.initValues();
            this.setThumbPositions();
        }
        if (changeKeys.includes('value') || changeKeys.includes('valueTo')) {
            this.initValues();
            this.setThumbPositions();
        }
        setTimeout(() => {
            this.updateBarFill();
        });
    }
    setThumbPositions() {
        this.setThumbPosition('from');
        if (!isNil(this.valueTo())) {
            this.setThumbPosition('to');
        }
    }
    trackById(index, item) {
        return item['id'];
    }
    ngOnDestroy() {
        this.resizeObserver?.unobserve(this.sliderBar?.nativeElement);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSliderComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiSliderComponent, isStandalone: true, selector: "oui-slider", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, valueTo: { classPropertyName: "valueTo", publicName: "valueTo", isSignal: true, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { value: "valueChange", valueTo: "valueToChange", debouncedvalueChange: "debouncedvalueChange", debouncedValueToChange: "debouncedValueToChange" }, viewQueries: [{ propertyName: "thumbFrom", first: true, predicate: ["thumbFrom"], descendants: true }, { propertyName: "thumbFromContainer", first: true, predicate: ["thumbFromContainer"], descendants: true }, { propertyName: "thumbFromDraggable", first: true, predicate: ["thumbFromDraggable"], descendants: true }, { propertyName: "thumbTo", first: true, predicate: ["thumbTo"], descendants: true }, { propertyName: "thumbToContainer", first: true, predicate: ["thumbToContainer"], descendants: true }, { propertyName: "thumbToDraggable", first: true, predicate: ["thumbToDraggable"], descendants: true }, { propertyName: "sliderBar", first: true, predicate: ["sliderBar"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"slider-container {{ combinedOptions().alignment }}\">\n  <div class=\"slider-content-container\">\n    <div class=\"slider-bar-container\">\n      <div class=\"slider-bar\" #sliderBar>\n\n        <div class=\"slider-bar-section\">\n          <div class=\"slider-bar-section-fill\"></div>\n        </div>\n        <div\n          #thumbFromContainer\n          #thumbFromDraggable=\"OuiDraggableDirective\"\n          class=\"slider-thumb-container from\"\n          oui-draggable\n          (dragMove)=\"onDragMove('from', $event)\"\n          >\n          <div #thumbFrom class=\"thumb\">\n            @if (combinedOptions().thumbContentTemplate; as template) {\n              <ng-container *ngTemplateOutlet=\"template\"></ng-container>\n            }\n          </div>\n        </div>\n        @if (valueTo() !== undefined) {\n          <div\n            #thumbToContainer\n            #thumbToDraggable=\"OuiDraggableDirective\"\n            class=\"slider-thumb-container to\"\n            oui-draggable\n            (dragMove)=\"onDragMove('to', $event)\"\n            >\n            <div #thumbTo class=\"thumb\">\n              @if (combinedOptions().thumbToContentTemplate; as template) {\n                <ng-container *ngTemplateOutlet=\"template\"></ng-container>\n              }\n            </div>\n          </div>\n        }\n      </div>\n    </div>\n    @if (combinedOptions().minLabel !== undefined || combinedOptions().maxLabel !== undefined) {\n      <div\n        class=\"slider-labels-container\"\n        >\n        @if (combinedOptions().minLabel !== undefined) {\n          <div class=\"min-label\">\n            {{ combinedOptions().minLabel }}\n          </div>\n        }\n        @if (combinedOptions().maxLabel !== undefined) {\n          <div class=\"max-label\">\n            {{ combinedOptions().maxLabel }}\n          </div>\n        }\n      </div>\n    }\n  </div>\n</div>\n", styles: [":host{flex:1;height:100%;display:flex;align-items:center}:host .icon-between-ticks{position:absolute}:host .slider-container{height:100%;width:100%;position:relative}:host .slider-container .slider-content-container{height:100%;width:100%;position:relative;display:flex;flex-direction:column;justify-content:center;align-items:center}:host .slider-container .slider-content-container .slider-bar-container{width:100%;height:var(--oui-slider-bar-container-height);display:flex;align-items:center;position:relative}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container{min-height:14px;min-width:14px;display:flex;justify-content:center;align-items:center;position:absolute;z-index:2;height:var(--oui-slider-thumb-height);width:var(--oui-slider-thumb-width)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.dragging .thumb{box-shadow:var(--oui-slider-thumb-dragging-box-shadow)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.from .thumb{background-color:var(--oui-slider-thumb-color-primary);border:var(--oui-slider-thumb-primary-border)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.from .thumb:hover{background-color:var(--oui-slider-thumb-color-primary-hover)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.to .thumb{background-color:var(--oui-slider-thumb-color-secondary);border:var(--oui-slider-thumb-secondary-border)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.to .thumb:hover{background-color:var(--oui-slider-thumb-color-secondary-hover)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container .thumb{border-radius:var(--oui-slider-thumb-border-radius);height:var(--oui-slider-thumb-height);width:var(--oui-slider-thumb-width);min-width:var(--oui-slider-thumb-width);min-height:var(--oui-slider-thumb-height);transition:background-color .3s,box-shadow .3s;display:flex;justify-content:center;align-items:center;box-shadow:var(--oui-slider-thumb-box-shadow)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container .thumb:hover{cursor:pointer}:host .slider-container .slider-content-container .slider-bar-container .outer-bar{width:100%;position:absolute;height:4px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar{width:100%;height:var(--oui-slider-bar-height);display:flex;align-items:center;position:relative;border:1px solid transparent;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container{position:absolute;width:100%;height:100%;display:flex;align-items:center}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick{pointer-events:none;display:flex;position:absolute;top:calc(var(--oui-slider-tick-height) / 2);transform:translateY(-100%);flex-direction:column;width:var(--oui-slider-tick-width);align-self:flex-start}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick .tick-line-wrapper{grid-area:middle;display:flex;justify-items:center;align-items:center;flex:0 1 auto}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick .tick-line-wrapper .tick-line{width:var(--oui-slider-tick-width);height:var(--oui-slider-tick-height);background-color:var(--oui-slider-tick-background-color);border-radius:var(--oui-slider-tick-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section{flex:1;background:var(--oui-slider-bar-inactive);height:100%;position:relative;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-1{margin-left:1px;margin-right:1px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-2{margin-left:2px;margin-right:2px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-3{margin-left:3px;margin-right:3px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-4{margin-left:4px;margin-right:4px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-5{margin-left:5px;margin-right:5px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-6{margin-left:6px;margin-right:6px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-7{margin-left:7px;margin-right:7px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-8{margin-left:8px;margin-right:8px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section .slider-bar-section-fill{height:100%;width:0;background:var(--oui-slider-bar-active);pointer-events:none;position:absolute;left:0;top:0;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section .slider-bar-section-fill.full{background:var(--oui-slider-bar-active)}:host .slider-container .slider-content-container .slider-labels-container{width:100%;display:flex;justify-content:space-between;align-items:center;position:absolute;bottom:-2rem;color:var(--oui-slider-label-color);font-size:1.5rem}:host .slider-container .slider-content-container .slider-labels-container .min-label{transform:translate(-50%)}:host .slider-container .slider-content-container .slider-labels-container .max-label{transform:translate(50%)}\n"], dependencies: [{ kind: "directive", type: OuiDraggableDirective, selector: "[oui-draggable]", outputs: ["dragMove", "dragStart", "dragEnd"], exportAs: ["OuiDraggableDirective"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSliderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-slider', standalone: true, imports: [OuiDraggableDirective, CommonModule, OuiIconComponent], template: "<div class=\"slider-container {{ combinedOptions().alignment }}\">\n  <div class=\"slider-content-container\">\n    <div class=\"slider-bar-container\">\n      <div class=\"slider-bar\" #sliderBar>\n\n        <div class=\"slider-bar-section\">\n          <div class=\"slider-bar-section-fill\"></div>\n        </div>\n        <div\n          #thumbFromContainer\n          #thumbFromDraggable=\"OuiDraggableDirective\"\n          class=\"slider-thumb-container from\"\n          oui-draggable\n          (dragMove)=\"onDragMove('from', $event)\"\n          >\n          <div #thumbFrom class=\"thumb\">\n            @if (combinedOptions().thumbContentTemplate; as template) {\n              <ng-container *ngTemplateOutlet=\"template\"></ng-container>\n            }\n          </div>\n        </div>\n        @if (valueTo() !== undefined) {\n          <div\n            #thumbToContainer\n            #thumbToDraggable=\"OuiDraggableDirective\"\n            class=\"slider-thumb-container to\"\n            oui-draggable\n            (dragMove)=\"onDragMove('to', $event)\"\n            >\n            <div #thumbTo class=\"thumb\">\n              @if (combinedOptions().thumbToContentTemplate; as template) {\n                <ng-container *ngTemplateOutlet=\"template\"></ng-container>\n              }\n            </div>\n          </div>\n        }\n      </div>\n    </div>\n    @if (combinedOptions().minLabel !== undefined || combinedOptions().maxLabel !== undefined) {\n      <div\n        class=\"slider-labels-container\"\n        >\n        @if (combinedOptions().minLabel !== undefined) {\n          <div class=\"min-label\">\n            {{ combinedOptions().minLabel }}\n          </div>\n        }\n        @if (combinedOptions().maxLabel !== undefined) {\n          <div class=\"max-label\">\n            {{ combinedOptions().maxLabel }}\n          </div>\n        }\n      </div>\n    }\n  </div>\n</div>\n", styles: [":host{flex:1;height:100%;display:flex;align-items:center}:host .icon-between-ticks{position:absolute}:host .slider-container{height:100%;width:100%;position:relative}:host .slider-container .slider-content-container{height:100%;width:100%;position:relative;display:flex;flex-direction:column;justify-content:center;align-items:center}:host .slider-container .slider-content-container .slider-bar-container{width:100%;height:var(--oui-slider-bar-container-height);display:flex;align-items:center;position:relative}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container{min-height:14px;min-width:14px;display:flex;justify-content:center;align-items:center;position:absolute;z-index:2;height:var(--oui-slider-thumb-height);width:var(--oui-slider-thumb-width)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.dragging .thumb{box-shadow:var(--oui-slider-thumb-dragging-box-shadow)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.from .thumb{background-color:var(--oui-slider-thumb-color-primary);border:var(--oui-slider-thumb-primary-border)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.from .thumb:hover{background-color:var(--oui-slider-thumb-color-primary-hover)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.to .thumb{background-color:var(--oui-slider-thumb-color-secondary);border:var(--oui-slider-thumb-secondary-border)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.to .thumb:hover{background-color:var(--oui-slider-thumb-color-secondary-hover)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container .thumb{border-radius:var(--oui-slider-thumb-border-radius);height:var(--oui-slider-thumb-height);width:var(--oui-slider-thumb-width);min-width:var(--oui-slider-thumb-width);min-height:var(--oui-slider-thumb-height);transition:background-color .3s,box-shadow .3s;display:flex;justify-content:center;align-items:center;box-shadow:var(--oui-slider-thumb-box-shadow)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container .thumb:hover{cursor:pointer}:host .slider-container .slider-content-container .slider-bar-container .outer-bar{width:100%;position:absolute;height:4px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar{width:100%;height:var(--oui-slider-bar-height);display:flex;align-items:center;position:relative;border:1px solid transparent;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container{position:absolute;width:100%;height:100%;display:flex;align-items:center}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick{pointer-events:none;display:flex;position:absolute;top:calc(var(--oui-slider-tick-height) / 2);transform:translateY(-100%);flex-direction:column;width:var(--oui-slider-tick-width);align-self:flex-start}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick .tick-line-wrapper{grid-area:middle;display:flex;justify-items:center;align-items:center;flex:0 1 auto}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick .tick-line-wrapper .tick-line{width:var(--oui-slider-tick-width);height:var(--oui-slider-tick-height);background-color:var(--oui-slider-tick-background-color);border-radius:var(--oui-slider-tick-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section{flex:1;background:var(--oui-slider-bar-inactive);height:100%;position:relative;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-1{margin-left:1px;margin-right:1px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-2{margin-left:2px;margin-right:2px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-3{margin-left:3px;margin-right:3px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-4{margin-left:4px;margin-right:4px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-5{margin-left:5px;margin-right:5px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-6{margin-left:6px;margin-right:6px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-7{margin-left:7px;margin-right:7px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-8{margin-left:8px;margin-right:8px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section .slider-bar-section-fill{height:100%;width:0;background:var(--oui-slider-bar-active);pointer-events:none;position:absolute;left:0;top:0;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section .slider-bar-section-fill.full{background:var(--oui-slider-bar-active)}:host .slider-container .slider-content-container .slider-labels-container{width:100%;display:flex;justify-content:space-between;align-items:center;position:absolute;bottom:-2rem;color:var(--oui-slider-label-color);font-size:1.5rem}:host .slider-container .slider-content-container .slider-labels-container .min-label{transform:translate(-50%)}:host .slider-container .slider-content-container .slider-labels-container .max-label{transform:translate(50%)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { thumbFrom: [{
                type: ViewChild,
                args: ['thumbFrom']
            }], thumbFromContainer: [{
                type: ViewChild,
                args: ['thumbFromContainer']
            }], thumbFromDraggable: [{
                type: ViewChild,
                args: ['thumbFromDraggable']
            }], thumbTo: [{
                type: ViewChild,
                args: ['thumbTo']
            }], thumbToContainer: [{
                type: ViewChild,
                args: ['thumbToContainer']
            }], thumbToDraggable: [{
                type: ViewChild,
                args: ['thumbToDraggable']
            }], sliderBar: [{
                type: ViewChild,
                args: ['sliderBar']
            }], debouncedvalueChange: [{
                type: Output
            }], debouncedValueToChange: [{
                type: Output
            }] } });

class OuiTickSliderComponent {
    document;
    destroyRef;
    sliderBar;
    fill;
    thumbFromContainer;
    thumbFromDraggable;
    thumbToContainer;
    thumbToDraggable;
    iconBetweenTicks;
    tickContainer;
    ticks;
    options = input.required();
    combinedOptions = computed(() => {
        return merge({
            ...this.defaultOptions,
        }, { ...this.options() });
    });
    /**
     * The model for 'smaller' value. Use this alone if you want just a single-thumb mode.
     */
    value = model.required();
    /**
     * The model for the 'larger' value. Can be only used together with value-input
     */
    valueTo = model();
    debouncedValueToChange = new EventEmitter();
    debouncedValueChange = new EventEmitter();
    previousXPosition = undefined;
    defaultOptions = {
        ticks: [],
        compareBy: (a, b) => a === b.value,
        alignment: 'horizontal',
    };
    resizeObserver;
    _debouncedValueToChange = debounce((value) => {
        this.debouncedValueToChange.emit(value);
    }, 300);
    _debouncedValueChange = debounce((value) => {
        this.debouncedValueChange.emit(value);
    }, 300);
    indexFrom = computed(() => {
        const valueFrom = this.value();
        const index = this.combinedOptions().ticks.findIndex(tick => {
            return this.combinedOptions().compareBy(valueFrom, tick);
        });
        return index;
    });
    indexTo = computed(() => {
        const valueTo = this.valueTo();
        const index = this.combinedOptions().ticks.findIndex(tick => {
            return this.combinedOptions().compareBy(valueTo, tick);
        });
        return index;
    });
    tickFrom = computed(() => {
        return this.combinedOptions().ticks[this.indexFrom()];
    });
    tickTo = computed(() => {
        return this.combinedOptions().ticks[this.indexTo()];
    });
    id = GUID();
    activeTicks = new Set([]);
    constructor(document, destroyRef) {
        this.document = document;
        this.destroyRef = destroyRef;
        toObservable(this.indexFrom)
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(index => {
            if (this.thumbFromDraggable?.behavior &&
                'snapTo' in this.thumbFromDraggable.behavior) {
                const target = this.ticks.toArray()[index]?.nativeElement;
                if (target) {
                    this.thumbFromDraggable.behavior.snapTo(target, undefined, true);
                }
            }
        });
        toObservable(this.indexTo)
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(index => {
            if (this.thumbToDraggable?.behavior &&
                'snapTo' in this.thumbToDraggable.behavior) {
                const target = this.ticks.toArray()[index]?.nativeElement;
                if (target) {
                    this.thumbToDraggable.behavior.snapTo(target, undefined, true);
                }
            }
        });
        toObservable(this.value)
            .pipe(takeUntilDestroyed(this.destroyRef), startWith(null), pairwise())
            .subscribe(([previousValue, currentValue]) => {
            const options = this.combinedOptions();
            if (previousValue !== currentValue && !!options) {
                this.initThumbToDraggable();
                this.updateBarFill();
                this.updateActiveTicks();
            }
        });
        toObservable(this.valueTo)
            .pipe(takeUntilDestroyed(this.destroyRef), pairwise())
            .subscribe(([previousValue, currentValue]) => {
            const options = this.combinedOptions();
            if (previousValue !== currentValue && !!options) {
                this.updateBarFill();
                this.updateActiveTicks();
            }
        });
    }
    onDragMove(type, event) {
        const snapEvent = event;
        const currentIndex = this.getIndex(type);
        const tickIndex = this.getTickIndex(snapEvent.target);
        if (currentIndex === tickIndex) {
            return;
        }
        if (tickIndex > -1) {
            if (type === 'from') {
                this.value.set(this.combinedOptions().ticks[tickIndex].value);
                this._debouncedValueChange(this.value());
            }
            else {
                this.valueTo.set(this.combinedOptions().ticks[tickIndex].value);
                this._debouncedValueToChange(this.valueTo());
            }
            this.updateActiveTicks();
        }
        else {
            console.error('Could not find tick based on selected tick and ticks given in options');
        }
        this.updateBarFill();
    }
    updateActiveTicks() {
        const indexFrom = this.indexFrom() ?? -1;
        const indexTo = this.indexTo() ?? -1;
        this.activeTicks = new Set([]);
        for (let tick of this.combinedOptions().ticks) {
            if (indexTo === undefined && tick.index < indexFrom) {
                this.activeTicks.add(tick);
            }
            else if (indexTo !== undefined &&
                tick.index >= indexFrom &&
                tick.index <= indexTo) {
                this.activeTicks.add(tick);
            }
        }
    }
    updateBarFill() {
        if (this.combinedOptions().alignment === 'horizontal') {
            this.updateBarFillHorizontal();
        }
        else {
            this.updateBarFillVertical();
        }
    }
    updateBarFillHorizontal() {
        const indexFrom = this.indexFrom();
        const indexTo = this.indexTo();
        if (indexFrom > -1 && indexTo > -1) {
            const thumbWidth = this.thumbFromContainer.nativeElement.getBoundingClientRect().width;
            const percentageFrom = (indexFrom * 100) / (this.combinedOptions().ticks.length - 1);
            const percentageTo = (indexTo * 100) / (this.combinedOptions().ticks.length - 1);
            this.fill.nativeElement.style.width = `calc(${percentageTo}% - ${percentageFrom}% + ${thumbWidth / 2}px)`;
            this.fill.nativeElement.style.left = `calc(${percentageFrom}% - ${thumbWidth / 2}px)`;
        }
        else if (indexFrom > -1) {
            const percentage = (indexFrom * 100) / (this.combinedOptions().ticks.length - 1);
            this.fill.nativeElement.style.width = `calc(${percentage}% + 5px)`;
        }
    }
    getIndex(type) {
        const value = this.value();
        const valueTo = this.valueTo();
        const usedValue = type === 'from' ? value : valueTo;
        const index = this.combinedOptions().ticks.findIndex(tick => {
            return this.combinedOptions().compareBy(usedValue, tick);
        });
        return index;
    }
    onTickClick(tick) {
        if (this.combinedOptions().areTicksClickable &&
            this.valueTo() === undefined) {
            const index = this.combinedOptions().ticks.findIndex(singleTick => singleTick.index === tick.index);
            const newSelectedTick = this.combinedOptions().ticks[index];
            this.value.set(newSelectedTick.value);
            this._debouncedValueChange(this.value());
        }
    }
    updateBarFillVertical() {
        const valueTo = this.valueTo();
        const indexFrom = this.indexFrom();
        const indexTo = this.indexTo();
        if (!isNil(valueTo) && !isNil(indexFrom) && !isNil(indexTo)) {
            const fillElement = this.sliderBar?.nativeElement?.querySelector(`.slider-bar-section-fill`);
            if (!fillElement) {
                return;
            }
            const percentageFrom = (indexFrom * 100) / (this.combinedOptions().ticks.length - 1);
            const percentageTo = (indexTo * 100) / (this.combinedOptions().ticks.length - 1);
            fillElement.style.height = `calc(${percentageTo}% - ${percentageFrom}% + 5px)`;
            fillElement.style.top = `calc(${percentageFrom}% - 5px)`;
        }
        else if (!isNil(indexFrom)) {
            const fillElement = this.sliderBar?.nativeElement?.querySelector(`.slider-bar-section-fill`);
            if (!fillElement) {
                return;
            }
            const percentage = (indexFrom * 100) / (this.combinedOptions().ticks.length - 1);
            fillElement.style.height = `calc(${percentage}% + 5px)`;
        }
    }
    ngAfterViewInit() {
        this.thumbFromDraggable.addSnapBehavior({
            groupId: this.id,
        });
        this.thumbFromDraggable.addContainerConstraint({
            container: this.sliderBar.nativeElement,
            anchor: 'center',
        });
        this.thumbFromDraggable.addAxisConstraint(this.combinedOptions().alignment === 'horizontal' ? 'x' : 'y');
        setTimeout(() => {
            this.initResizeObserver();
            this.updateBarFill();
        });
    }
    initThumbToDraggable() {
        if (this.thumbToDraggable && !this.thumbToDraggable?.behavior) {
            this.thumbToDraggable.addSnapBehavior({
                groupId: this.id,
            });
            this.thumbToDraggable.addContainerConstraint({
                container: this.sliderBar.nativeElement,
                anchor: 'center',
            });
            this.thumbToDraggable.addAxisConstraint(this.combinedOptions().alignment === 'horizontal' ? 'x' : 'y');
            this.thumbToDraggable.addCustomConstraint((draggable, targetRect, event) => {
                return targetRect;
            });
        }
    }
    getTickIndex(target) {
        return this.ticks
            .toArray()
            .findIndex(tick => target.isEqualNode(tick.nativeElement));
    }
    initResizeObserver() {
        const debouncedResize = throttle(() => {
            this.positionTicks();
            this.reSnapDraggables();
        }, 50);
        this.resizeObserver = new ResizeObserver(() => {
            debouncedResize();
        });
        this.resizeObserver.observe(this.tickContainer.nativeElement);
    }
    positionTicks() {
        const tickElements = this.ticks.toArray();
        if (this.combinedOptions().alignment === 'horizontal') {
            tickElements.forEach((tick, index) => {
                const left = this.sliderBar.nativeElement.getBoundingClientRect().width *
                    (index / (tickElements.length - 1)) -
                    tick.nativeElement.getBoundingClientRect().width / 2;
                tick.nativeElement.style.left = `${left}px`;
            });
        }
        else {
            tickElements.forEach((tick, index) => {
                const top = this.sliderBar.nativeElement.getBoundingClientRect().height *
                    (index / (tickElements.length - 1)) +
                    tick.nativeElement.getBoundingClientRect().height / 2;
                tick.nativeElement.style.top = `${top}px`;
            });
        }
        if (this.combinedOptions().iconBetweenTicks) {
            this.positionIconBetweenTicks();
        }
    }
    reSnapDraggables() {
        if (this.thumbFromDraggable.behavior &&
            'snapTo' in this.thumbFromDraggable.behavior) {
            const index = this.getIndex('from');
            if (index > -1) {
                this.thumbFromDraggable.behavior.snapTo(this.ticks.toArray()[index].nativeElement);
            }
        }
        if (this.thumbToDraggable?.behavior &&
            'snapTo' in this.thumbToDraggable.behavior) {
            const index = this.getIndex('to');
            if (index > -1) {
                this.thumbToDraggable.behavior.snapTo(this.ticks.toArray()[index].nativeElement);
            }
        }
    }
    positionIconBetweenTicks() {
        setTimeout(() => {
            const iconBetweenTicks = this.combinedOptions().iconBetweenTicks;
            if (!iconBetweenTicks ||
                !this.combinedOptions().ticks?.length ||
                !this.iconBetweenTicks?.elementRef) {
                return;
            }
            const tickElementFrom = this.ticks.toArray()[iconBetweenTicks.fromIndex];
            const tickElementTo = this.ticks.toArray()[iconBetweenTicks.toIndex];
            if (tickElementTo && tickElementFrom) {
                const rectFrom = tickElementFrom.nativeElement.getBoundingClientRect();
                const rectTo = tickElementTo.nativeElement.getBoundingClientRect();
                const rectBar = this.sliderBar.nativeElement.getBoundingClientRect();
                const rectIcon = this.iconBetweenTicks.elementRef.nativeElement.getBoundingClientRect();
                const left = (rectFrom.right - rectBar.left + (rectTo.left - rectBar.left)) / 2 -
                    rectIcon.width / 2;
                this.iconBetweenTicks.elementRef.nativeElement.style.left = `${left}px`;
            }
        });
    }
    trackByValue(index, item) {
        return item.value;
    }
    ngOnDestroy() {
        this.resizeObserver?.unobserve(this.sliderBar?.nativeElement);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTickSliderComponent, deps: [{ token: DOCUMENT }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiTickSliderComponent, isStandalone: true, selector: "oui-tick-slider", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: true, transformFunction: null }, valueTo: { classPropertyName: "valueTo", publicName: "valueTo", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { value: "valueChange", valueTo: "valueToChange", debouncedValueToChange: "debouncedValueToChange", debouncedValueChange: "debouncedValueChange" }, viewQueries: [{ propertyName: "sliderBar", first: true, predicate: ["sliderBar"], descendants: true }, { propertyName: "fill", first: true, predicate: ["fill"], descendants: true }, { propertyName: "thumbFromContainer", first: true, predicate: ["thumbFromContainer"], descendants: true }, { propertyName: "thumbFromDraggable", first: true, predicate: ["thumbFromDraggable"], descendants: true }, { propertyName: "thumbToContainer", first: true, predicate: ["thumbToContainer"], descendants: true }, { propertyName: "thumbToDraggable", first: true, predicate: ["thumbToDraggable"], descendants: true }, { propertyName: "iconBetweenTicks", first: true, predicate: ["iconBetweenTicks"], descendants: true }, { propertyName: "tickContainer", first: true, predicate: ["tickContainer"], descendants: true }, { propertyName: "ticks", predicate: ["tick"], descendants: true }], ngImport: i0, template: "<div class=\"slider-container {{ combinedOptions().alignment }}\">\n  <div class=\"slider-content-container\">\n    <div class=\"slider-bar-container\">\n      <div class=\"slider-bar\" #sliderBar>\n        <div\n          #thumbFromContainer\n          #thumbFromDraggable=\"OuiDraggableDirective\"\n          class=\"slider-thumb-container from\"\n          oui-draggable\n          (dragMove)=\"onDragMove('from', $event)\"\n          >\n          <div class=\"thumb\">\n            @if (combinedOptions().thumbContentTemplate; as template) {\n              <ng-container *ngTemplateOutlet=\"template\"></ng-container>\n            }\n          </div>\n        </div>\n        @if (valueTo() !== undefined) {\n          <div\n            #thumbToContainer\n            #thumbToDraggable=\"OuiDraggableDirective\"\n            class=\"slider-thumb-container to\"\n            oui-draggable\n            (dragMove)=\"onDragMove('to', $event)\"\n            >\n            <div class=\"thumb\">\n              @if (combinedOptions().thumbToContentTemplate; as template) {\n                <ng-container *ngTemplateOutlet=\"template\"></ng-container>\n              }\n            </div>\n          </div>\n        }\n\n\n        <ng-container>\n          <div class=\"slider-bar-section\">\n            <div class=\"slider-bar-section-fill\" #fill></div>\n          </div>\n        </ng-container>\n\n        @if (combinedOptions().iconBetweenTicks; as iconBetweenTicks) {\n          <oui-icon\n            class=\"icon-between-ticks\"\n            #iconBetweenTicks\n            [icon]=\"iconBetweenTicks.icon\"\n            [options]=\"iconBetweenTicks.iconOptions\"\n          ></oui-icon>\n        }\n\n        <ng-container>\n          <div #tickContainer class=\"tick-container\">\n            @for (\n              tick of combinedOptions().ticks; track trackByValue($index,\n              tick)) {\n              <div\n                class=\"tick-wrapper\"\n                [ngClass]=\"{'active': activeTicks.has(tick), 'clickable': combinedOptions().areTicksClickable && valueTo() === undefined}\"\n                (click)=\"onTickClick(tick)\"\n                [ouiSnappable]=\"id\"\n                #tick\n                >\n                <div class=\"tick\"></div>\n                <div class=\"label-wrapper\">\n                  @if (combinedOptions().tickLabelTemplate; as template) {\n                    <ng-container\n                      *ngTemplateOutlet=\"\n                    template;\n                    context: { value: tick }\n                  \"\n                    ></ng-container>\n                  }\n                </div>\n              </div>\n            }\n          </div>\n        </ng-container>\n      </div>\n    </div>\n  </div>\n</div>\n", styles: [":host{flex:1;height:100%;display:flex;align-items:center}:host .icon-between-ticks{position:absolute}:host .slider-container{height:100%;width:100%;position:relative}:host .slider-container.vertical .slider-content-container{flex-direction:column}:host .slider-container.vertical .slider-content-container .slider-bar-container{height:100%;width:14px}:host .slider-container.vertical .slider-content-container .slider-bar-container .slider-bar{width:4px;height:100%;flex-direction:column}:host .slider-container.vertical .slider-content-container .slider-bar-container .slider-bar .slider-bar-section{height:100%;width:100%}:host .slider-container.vertical .slider-content-container .slider-bar-container .slider-bar .slider-bar-section .slider-bar-section-fill{width:100%;height:unset}:host .slider-container.vertical .slider-content-container .slider-bar-container .slider-bar .tick-container{flex-direction:column}:host .slider-container.vertical .slider-content-container .slider-bar-container .slider-bar .tick-container .tick{align-self:center;flex-direction:row-reverse;transform:translate(100%);width:auto;height:var(--oui-slider-tick-height);top:auto;left:calc(var(--oui-slider-tick-width) / -2)}:host .slider-container.vertical .slider-content-container .slider-bar-container .slider-bar .tick-container .tick .tick-label-wrapper{flex-direction:row}:host .slider-container.vertical .slider-content-container .slider-bar-container .slider-bar .tick-container .tick .tick-label-wrapper .tick-line{width:var(--oui-slider-tick-width);height:var(--oui-slider-tick-height);background-color:var(--oui-slider-tick-background-color);border-radius:var(--oui-slider-tick-border-radius)}:host .slider-container .slider-content-container{height:100%;width:100%;position:relative;display:flex;flex-direction:column;justify-content:var(--oui-tick-slider-justify-content);align-items:var(--oui-tick-slider-align-items)}:host .slider-container .slider-content-container .slider-bar-container{width:100%;height:var(--oui-slider-bar-height);display:flex;align-items:center;position:relative}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container{min-height:14px;min-width:14px;display:flex;justify-content:center;align-items:center;position:absolute;z-index:2;height:var(--oui-slider-thumb-height);width:var(--oui-slider-thumb-width)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.dragging .thumb{box-shadow:var(--oui-slider-thumb-dragging-box-shadow)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.from .thumb{background-color:var(--oui-slider-thumb-color-primary);border:var(--oui-slider-thumb-primary-border)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.from .thumb:hover{background-color:var(--oui-slider-thumb-color-primary-hover)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.to .thumb{background-color:var(--oui-slider-thumb-color-secondary);border:var(--oui-slider-thumb-secondary-border)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.to .thumb:hover{background-color:var(--oui-slider-thumb-color-secondary-hover)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container .thumb{border-radius:var(--oui-slider-thumb-border-radius);height:var(--oui-slider-thumb-height);width:var(--oui-slider-thumb-width);min-width:var(--oui-slider-thumb-width);min-height:var(--oui-slider-thumb-height);transition:background-color .3s;display:flex;justify-content:center;align-items:center;box-shadow:var(--oui-slider-thumb-box-shadow)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container .thumb:hover{cursor:pointer}:host .slider-container .slider-content-container .slider-bar-container .outer-bar{width:100%;position:absolute;height:4px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar{width:100%;height:4px;display:flex;align-items:center;position:relative;border:1px solid transparent;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container{position:absolute;width:100%;height:100%;display:flex;align-items:center}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick-wrapper{height:0;width:0;min-width:0;position:absolute;display:flex;justify-content:center;align-items:center}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick-wrapper.clickable .tick{pointer-events:all}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick-wrapper.clickable .tick:hover{cursor:pointer}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick-wrapper.clickable .label-wrapper:hover{cursor:pointer}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick-wrapper.active .tick{background-color:var(--oui-slider-tick-background-color-active)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick-wrapper .label-wrapper{height:0;width:0;position:absolute;display:flex;justify-content:center;align-items:center}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick-wrapper .tick{pointer-events:none;display:flex;position:absolute;top:calc(var(--oui-slider-tick-height) / 2);transform:translateY(-100%);flex-direction:column;width:var(--oui-slider-tick-width);align-self:center;height:var(--oui-slider-tick-height);background-color:var(--oui-slider-tick-background-color);border-radius:var(--oui-slider-tick-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section{flex:1;background:var(--oui-slider-bar-inactive);height:100%;position:relative}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-1{margin-left:1px;margin-right:1px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-2{margin-left:2px;margin-right:2px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-3{margin-left:3px;margin-right:3px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-4{margin-left:4px;margin-right:4px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-5{margin-left:5px;margin-right:5px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-6{margin-left:6px;margin-right:6px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-7{margin-left:7px;margin-right:7px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-8{margin-left:8px;margin-right:8px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section .slider-bar-section-fill{height:100%;width:0;background:var(--oui-slider-bar-active);pointer-events:none;position:absolute;left:0;top:0;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section .slider-bar-section-fill.full{background:var(--oui-slider-bar-active)}\n"], dependencies: [{ kind: "directive", type: OuiDraggableDirective, selector: "[oui-draggable]", outputs: ["dragMove", "dragStart", "dragEnd"], exportAs: ["OuiDraggableDirective"] }, { kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: OuiSnappableDirective, selector: "[ouiSnappable]", inputs: ["ouiSnappable"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTickSliderComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-tick-slider', standalone: true, imports: [
                        OuiDraggableDirective,
                        OuiIconComponent,
                        NgTemplateOutlet,
                        NgClass,
                        OuiSnappableDirective,
                        NgStyle,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"slider-container {{ combinedOptions().alignment }}\">\n  <div class=\"slider-content-container\">\n    <div class=\"slider-bar-container\">\n      <div class=\"slider-bar\" #sliderBar>\n        <div\n          #thumbFromContainer\n          #thumbFromDraggable=\"OuiDraggableDirective\"\n          class=\"slider-thumb-container from\"\n          oui-draggable\n          (dragMove)=\"onDragMove('from', $event)\"\n          >\n          <div class=\"thumb\">\n            @if (combinedOptions().thumbContentTemplate; as template) {\n              <ng-container *ngTemplateOutlet=\"template\"></ng-container>\n            }\n          </div>\n        </div>\n        @if (valueTo() !== undefined) {\n          <div\n            #thumbToContainer\n            #thumbToDraggable=\"OuiDraggableDirective\"\n            class=\"slider-thumb-container to\"\n            oui-draggable\n            (dragMove)=\"onDragMove('to', $event)\"\n            >\n            <div class=\"thumb\">\n              @if (combinedOptions().thumbToContentTemplate; as template) {\n                <ng-container *ngTemplateOutlet=\"template\"></ng-container>\n              }\n            </div>\n          </div>\n        }\n\n\n        <ng-container>\n          <div class=\"slider-bar-section\">\n            <div class=\"slider-bar-section-fill\" #fill></div>\n          </div>\n        </ng-container>\n\n        @if (combinedOptions().iconBetweenTicks; as iconBetweenTicks) {\n          <oui-icon\n            class=\"icon-between-ticks\"\n            #iconBetweenTicks\n            [icon]=\"iconBetweenTicks.icon\"\n            [options]=\"iconBetweenTicks.iconOptions\"\n          ></oui-icon>\n        }\n\n        <ng-container>\n          <div #tickContainer class=\"tick-container\">\n            @for (\n              tick of combinedOptions().ticks; track trackByValue($index,\n              tick)) {\n              <div\n                class=\"tick-wrapper\"\n                [ngClass]=\"{'active': activeTicks.has(tick), 'clickable': combinedOptions().areTicksClickable && valueTo() === undefined}\"\n                (click)=\"onTickClick(tick)\"\n                [ouiSnappable]=\"id\"\n                #tick\n                >\n                <div class=\"tick\"></div>\n                <div class=\"label-wrapper\">\n                  @if (combinedOptions().tickLabelTemplate; as template) {\n                    <ng-container\n                      *ngTemplateOutlet=\"\n                    template;\n                    context: { value: tick }\n                  \"\n                    ></ng-container>\n                  }\n                </div>\n              </div>\n            }\n          </div>\n        </ng-container>\n      </div>\n    </div>\n  </div>\n</div>\n", styles: [":host{flex:1;height:100%;display:flex;align-items:center}:host .icon-between-ticks{position:absolute}:host .slider-container{height:100%;width:100%;position:relative}:host .slider-container.vertical .slider-content-container{flex-direction:column}:host .slider-container.vertical .slider-content-container .slider-bar-container{height:100%;width:14px}:host .slider-container.vertical .slider-content-container .slider-bar-container .slider-bar{width:4px;height:100%;flex-direction:column}:host .slider-container.vertical .slider-content-container .slider-bar-container .slider-bar .slider-bar-section{height:100%;width:100%}:host .slider-container.vertical .slider-content-container .slider-bar-container .slider-bar .slider-bar-section .slider-bar-section-fill{width:100%;height:unset}:host .slider-container.vertical .slider-content-container .slider-bar-container .slider-bar .tick-container{flex-direction:column}:host .slider-container.vertical .slider-content-container .slider-bar-container .slider-bar .tick-container .tick{align-self:center;flex-direction:row-reverse;transform:translate(100%);width:auto;height:var(--oui-slider-tick-height);top:auto;left:calc(var(--oui-slider-tick-width) / -2)}:host .slider-container.vertical .slider-content-container .slider-bar-container .slider-bar .tick-container .tick .tick-label-wrapper{flex-direction:row}:host .slider-container.vertical .slider-content-container .slider-bar-container .slider-bar .tick-container .tick .tick-label-wrapper .tick-line{width:var(--oui-slider-tick-width);height:var(--oui-slider-tick-height);background-color:var(--oui-slider-tick-background-color);border-radius:var(--oui-slider-tick-border-radius)}:host .slider-container .slider-content-container{height:100%;width:100%;position:relative;display:flex;flex-direction:column;justify-content:var(--oui-tick-slider-justify-content);align-items:var(--oui-tick-slider-align-items)}:host .slider-container .slider-content-container .slider-bar-container{width:100%;height:var(--oui-slider-bar-height);display:flex;align-items:center;position:relative}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container{min-height:14px;min-width:14px;display:flex;justify-content:center;align-items:center;position:absolute;z-index:2;height:var(--oui-slider-thumb-height);width:var(--oui-slider-thumb-width)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.dragging .thumb{box-shadow:var(--oui-slider-thumb-dragging-box-shadow)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.from .thumb{background-color:var(--oui-slider-thumb-color-primary);border:var(--oui-slider-thumb-primary-border)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.from .thumb:hover{background-color:var(--oui-slider-thumb-color-primary-hover)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.to .thumb{background-color:var(--oui-slider-thumb-color-secondary);border:var(--oui-slider-thumb-secondary-border)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container.to .thumb:hover{background-color:var(--oui-slider-thumb-color-secondary-hover)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container .thumb{border-radius:var(--oui-slider-thumb-border-radius);height:var(--oui-slider-thumb-height);width:var(--oui-slider-thumb-width);min-width:var(--oui-slider-thumb-width);min-height:var(--oui-slider-thumb-height);transition:background-color .3s;display:flex;justify-content:center;align-items:center;box-shadow:var(--oui-slider-thumb-box-shadow)}:host .slider-container .slider-content-container .slider-bar-container .slider-thumb-container .thumb:hover{cursor:pointer}:host .slider-container .slider-content-container .slider-bar-container .outer-bar{width:100%;position:absolute;height:4px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar{width:100%;height:4px;display:flex;align-items:center;position:relative;border:1px solid transparent;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container{position:absolute;width:100%;height:100%;display:flex;align-items:center}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick-wrapper{height:0;width:0;min-width:0;position:absolute;display:flex;justify-content:center;align-items:center}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick-wrapper.clickable .tick{pointer-events:all}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick-wrapper.clickable .tick:hover{cursor:pointer}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick-wrapper.clickable .label-wrapper:hover{cursor:pointer}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick-wrapper.active .tick{background-color:var(--oui-slider-tick-background-color-active)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick-wrapper .label-wrapper{height:0;width:0;position:absolute;display:flex;justify-content:center;align-items:center}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .tick-container .tick-wrapper .tick{pointer-events:none;display:flex;position:absolute;top:calc(var(--oui-slider-tick-height) / 2);transform:translateY(-100%);flex-direction:column;width:var(--oui-slider-tick-width);align-self:center;height:var(--oui-slider-tick-height);background-color:var(--oui-slider-tick-background-color);border-radius:var(--oui-slider-tick-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section{flex:1;background:var(--oui-slider-bar-inactive);height:100%;position:relative}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-1{margin-left:1px;margin-right:1px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-2{margin-left:2px;margin-right:2px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-3{margin-left:3px;margin-right:3px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-4{margin-left:4px;margin-right:4px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-5{margin-left:5px;margin-right:5px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-6{margin-left:6px;margin-right:6px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-7{margin-left:7px;margin-right:7px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section.gap-8{margin-left:8px;margin-right:8px}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section .slider-bar-section-fill{height:100%;width:0;background:var(--oui-slider-bar-active);pointer-events:none;position:absolute;left:0;top:0;border-radius:var(--oui-slider-bar-border-radius)}:host .slider-container .slider-content-container .slider-bar-container .slider-bar .slider-bar-section .slider-bar-section-fill.full{background:var(--oui-slider-bar-active)}\n"] }]
        }], ctorParameters: () => [{ type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.DestroyRef }], propDecorators: { sliderBar: [{
                type: ViewChild,
                args: ['sliderBar']
            }], fill: [{
                type: ViewChild,
                args: ['fill']
            }], thumbFromContainer: [{
                type: ViewChild,
                args: ['thumbFromContainer']
            }], thumbFromDraggable: [{
                type: ViewChild,
                args: ['thumbFromDraggable']
            }], thumbToContainer: [{
                type: ViewChild,
                args: ['thumbToContainer']
            }], thumbToDraggable: [{
                type: ViewChild,
                args: ['thumbToDraggable']
            }], iconBetweenTicks: [{
                type: ViewChild,
                args: ['iconBetweenTicks']
            }], tickContainer: [{
                type: ViewChild,
                args: ['tickContainer']
            }], ticks: [{
                type: ViewChildren,
                args: ['tick']
            }], debouncedValueToChange: [{
                type: Output
            }], debouncedValueChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiSliderComponent, OuiTickSliderComponent };
//# sourceMappingURL=orbital-ui-slider.mjs.map
