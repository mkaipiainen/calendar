import * as i0 from '@angular/core';
import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { OuiCollapsibleContentComponent, OuiCollapsibleToggleComponent } from 'orbital-ui/collapsible';
import { OuiTabsComponent, OuiTabComponent } from 'orbital-ui/tabs';
import { OuiIconComponent } from 'orbital-ui/icon';

class OuiCodeDisplayComponent {
    cdr;
    typescriptPath;
    htmlPath;
    isOpen = false;
    typescriptCode;
    htmlCode;
    constructor(cdr) {
        this.cdr = cdr;
    }
    async ngAfterViewInit() {
        fetch(this.typescriptPath)
            .then(response => response.text())
            .then(text => {
            this.typescriptCode = text;
            this.cdr.detectChanges();
        });
        fetch(this.htmlPath)
            .then(response => response.text())
            .then(text => {
            this.htmlCode = text;
            this.cdr.detectChanges();
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCodeDisplayComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiCodeDisplayComponent, isStandalone: true, selector: "oui-code-display", inputs: { typescriptPath: "typescriptPath", htmlPath: "htmlPath" }, ngImport: i0, template: "<div class=\"code-display-container\">\n  <div class=\"code-display-inner-container\">\n    <oui-collapsible-toggle [(isOpen)]=\"isOpen\">\n      <div class=\"code-display-toggle\">\n        <div class=\"code-display-toggle-text\">\n          <span class=\"code-display-toggle-text-title\">Show TS/HTML</span>\n        </div>\n        <div class=\"code-display-toggle-icon\">\n          @if (!isOpen) {\n            <oui-icon\n            [options]=\"{\n              fillColor: 'color-background-text',\n              strokeColor: 'color-background-text',\n              size: '24px'\n            }\"\n              icon=\"assets/icons/caret_down.svg\"\n            ></oui-icon>\n          }\n          @if (isOpen) {\n            <oui-icon\n            [options]=\"{\n              fillColor: 'color-background-text',\n              strokeColor: 'color-background-text',\n              size: '24px'\n            }\"\n              icon=\"assets/icons/caret_up.svg\"\n            ></oui-icon>\n          }\n        </div>\n      </div>\n    </oui-collapsible-toggle>\n    <oui-collapsible-content>\n      <oui-tabs [options]=\"{ variant: 'underlined' }\">\n        <oui-tab [title]=\"'Typescript'\">\n          <div\n            class=\"code-display-content-outer oui-scrollbar oui-scrollbar-auto\"\n            >\n            <div class=\"code-display-collapsed-content\">\n              <pre><code [innerHTML]=\"typescriptCode\"></code></pre>\n            </div>\n          </div>\n        </oui-tab>\n        <oui-tab [title]=\"'HTML'\">\n          <div\n            class=\"code-display-content-outer oui-scrollbar oui-scrollbar-auto\"\n            >\n            <div class=\"code-display-collapsed-content\">\n              <pre>{{ htmlCode }}</pre>\n            </div>\n          </div>\n        </oui-tab>\n      </oui-tabs>\n    </oui-collapsible-content>\n  </div>\n</div>\n", styles: [":host{width:100%;flex:1;min-height:5rem;display:flex;flex-direction:column}:host .code-display-container{border:1px dashed #ccc;display:flex;flex-direction:column}:host .code-display-container .code-display-inner-container{background-color:var(--color-background-light);box-shadow:var(--box-shadow-bottom)}:host .code-display-toggle{padding:1rem;display:flex;align-items:center;justify-content:space-between;background-color:var(--color-background-light);color:var(--color-background-light-text);cursor:pointer}:host .code-display-content-outer{padding:1rem;max-height:500px;height:500px;border-top:1px solid #ccc;background-color:var(--color-background-light)}:host .code-display-content-outer .code-display-collapsed-content{max-height:500px}:host .empty{height:1rem;background-color:transparent;pointer-events:none;opacity:0;width:100%}:host pre{font-size:var(--font-size-body-smaller);white-space:pre-wrap}\n"], dependencies: [{ kind: "component", type: OuiCollapsibleContentComponent, selector: "oui-collapsible-content", inputs: ["group"] }, { kind: "component", type: OuiCollapsibleToggleComponent, selector: "oui-collapsible-toggle", inputs: ["group", "isOpen", "disableClickToggle"], outputs: ["isOpenChange"] }, { kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "component", type: OuiTabsComponent, selector: "oui-tabs", inputs: ["id", "options"] }, { kind: "component", type: OuiTabComponent, selector: "oui-tab", inputs: ["title", "tabTitleTemplate", "parentId", "id", "disabled"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCodeDisplayComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-code-display', standalone: true, imports: [
                        OuiCollapsibleContentComponent,
                        OuiCollapsibleToggleComponent,
                        OuiIconComponent,
                        OuiTabsComponent,
                        OuiTabComponent
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"code-display-container\">\n  <div class=\"code-display-inner-container\">\n    <oui-collapsible-toggle [(isOpen)]=\"isOpen\">\n      <div class=\"code-display-toggle\">\n        <div class=\"code-display-toggle-text\">\n          <span class=\"code-display-toggle-text-title\">Show TS/HTML</span>\n        </div>\n        <div class=\"code-display-toggle-icon\">\n          @if (!isOpen) {\n            <oui-icon\n            [options]=\"{\n              fillColor: 'color-background-text',\n              strokeColor: 'color-background-text',\n              size: '24px'\n            }\"\n              icon=\"assets/icons/caret_down.svg\"\n            ></oui-icon>\n          }\n          @if (isOpen) {\n            <oui-icon\n            [options]=\"{\n              fillColor: 'color-background-text',\n              strokeColor: 'color-background-text',\n              size: '24px'\n            }\"\n              icon=\"assets/icons/caret_up.svg\"\n            ></oui-icon>\n          }\n        </div>\n      </div>\n    </oui-collapsible-toggle>\n    <oui-collapsible-content>\n      <oui-tabs [options]=\"{ variant: 'underlined' }\">\n        <oui-tab [title]=\"'Typescript'\">\n          <div\n            class=\"code-display-content-outer oui-scrollbar oui-scrollbar-auto\"\n            >\n            <div class=\"code-display-collapsed-content\">\n              <pre><code [innerHTML]=\"typescriptCode\"></code></pre>\n            </div>\n          </div>\n        </oui-tab>\n        <oui-tab [title]=\"'HTML'\">\n          <div\n            class=\"code-display-content-outer oui-scrollbar oui-scrollbar-auto\"\n            >\n            <div class=\"code-display-collapsed-content\">\n              <pre>{{ htmlCode }}</pre>\n            </div>\n          </div>\n        </oui-tab>\n      </oui-tabs>\n    </oui-collapsible-content>\n  </div>\n</div>\n", styles: [":host{width:100%;flex:1;min-height:5rem;display:flex;flex-direction:column}:host .code-display-container{border:1px dashed #ccc;display:flex;flex-direction:column}:host .code-display-container .code-display-inner-container{background-color:var(--color-background-light);box-shadow:var(--box-shadow-bottom)}:host .code-display-toggle{padding:1rem;display:flex;align-items:center;justify-content:space-between;background-color:var(--color-background-light);color:var(--color-background-light-text);cursor:pointer}:host .code-display-content-outer{padding:1rem;max-height:500px;height:500px;border-top:1px solid #ccc;background-color:var(--color-background-light)}:host .code-display-content-outer .code-display-collapsed-content{max-height:500px}:host .empty{height:1rem;background-color:transparent;pointer-events:none;opacity:0;width:100%}:host pre{font-size:var(--font-size-body-smaller);white-space:pre-wrap}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { typescriptPath: [{
                type: Input
            }], htmlPath: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiCodeDisplayComponent };
//# sourceMappingURL=orbital-ui-code-display.mjs.map
