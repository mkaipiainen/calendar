/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/mapbox" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-mapbox.d.ts.map