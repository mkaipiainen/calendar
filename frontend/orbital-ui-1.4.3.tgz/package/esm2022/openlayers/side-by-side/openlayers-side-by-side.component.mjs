import { Component, computed, effect, EventEmitter, Inject, input, Output, signal, ViewChild, } from '@angular/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { OuiIconComponent } from 'orbital-ui/icon';
import { fromEvent, take } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { OuiSliderComponent } from 'orbital-ui/slider';
import { OuiDraggableDirective } from 'orbital-ui/draggable';
import { debounce, isNil } from 'lodash-es';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export class OpenlayersSideBySideComponent {
    renderer;
    destroyRef;
    elementRef;
    document;
    leftLabelTemplate = input();
    rightLabelTemplate = input();
    mapContainer = input.required();
    map = input.required();
    options = input.required();
    clipChange = new EventEmitter();
    dragged = new EventEmitter();
    clicked = new EventEmitter();
    released = new EventEmitter();
    dragContainer;
    drag;
    imageLabelRight;
    imageLabelLeft;
    thumbIconTemplate;
    mapContent;
    draggable;
    mapsWrapper;
    gammaMaskRight;
    gammaMaskLeft;
    currentDragPosition = signal({
        x: 0,
        y: 0,
    });
    resizeObserver;
    dragLeftRatio = signal(0);
    dragLeftRatioWithDragWidthOffset = computed(() => {
        return (this.dragLeftRatio() +
            this.getDragContainerWidthOffset() / this.getMapContainerWidth());
    });
    isInitialisationStarted = signal(false);
    refreshInterval;
    debouncedEndClip = debounce(this.getClipAndEmit.bind(this), 50);
    unlisteners = [];
    mapListeners = {
        movestart: this.startClipping.bind(this),
        move: this.storeBounds.bind(this),
        moveend: this.endClipping.bind(this),
    };
    isInitialised = signal(false);
    isVertical = signal(true);
    beforeGamma = signal(1);
    afterGamma = signal(1);
    gammaSliderOptions = signal({
        min: 0.01,
        max: 2,
        minLabel: '',
        maxLabel: '',
    });
    currentBounds = signal(undefined);
    constructor(renderer, destroyRef, elementRef, document) {
        this.renderer = renderer;
        this.destroyRef = destroyRef;
        this.elementRef = elementRef;
        this.document = document;
        const unload = effect(() => {
            if (this.map() && !this.isInitialisationStarted() && this.mapContent) {
                this.subscribeToMapLoad();
                unload.destroy();
            }
        }, {
            allowSignalWrites: true,
        });
    }
    ngAfterViewInit() {
        fromEvent(this.document.body, 'keydown')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            if (event.code === 'KeyZ' && this.options().enabledEvents?.moveSlider) {
                this.draggable.updateTransform({
                    x: 0,
                    y: 0,
                });
            }
            else if (event.code === 'KeyX' &&
                this.options().enabledEvents?.moveSlider) {
                this.draggable.updateTransform({
                    x: this.getMapContainerWidth() -
                        this.getDragContainerWidthOffset() * 2,
                    y: 0,
                });
            }
            else if (event.code === 'KeyA' &&
                this.options().enabledEvents?.zoomInOut) {
                const map = this.map()?.state?.map();
                const currentZoom = map?.getView()?.getZoom();
                if (map && !isNil(currentZoom)) {
                    map.getView().animate({
                        zoom: currentZoom + 0.25,
                        duration: 250,
                    });
                }
            }
            else if (event.code === 'KeyS' &&
                this.options().enabledEvents?.zoomInOut) {
                const map = this.map()?.state?.map();
                const currentZoom = map?.getView()?.getZoom();
                if (map && !isNil(currentZoom)) {
                    map.getView().animate({
                        zoom: Math.max(currentZoom - 0.25, 0),
                        duration: 250,
                    });
                }
            }
        });
        this.gammaSliderOptions.set({
            min: 0.01,
            max: 2,
            minLabel: '',
            maxLabel: '',
            thumbContentTemplate: this.thumbIconTemplate,
        });
        if (this.map()) {
            if (!this.isInitialisationStarted) {
                this.subscribeToMapLoad();
            }
        }
    }
    initDraggable() {
        this.draggable.addDefaultBehavior();
        this.draggable.addContainerConstraint({
            container: this.mapsWrapper.nativeElement,
            anchor: 'edge',
        });
        this.currentDragPosition.set({
            x: this.getMapContainerWidth() / 2 - this.getDragContainerWidthOffset(),
            y: 0,
        });
        this.draggable.updateTransform(this.currentDragPosition());
        this.dragLeftRatio.set(this.currentDragPosition().x / this.getMapContainerWidth());
    }
    subscribeToMapLoad() {
        this.isInitialisationStarted.set(true);
        const map = this.map();
        if (!map) {
            return;
        }
        map.onLoad$
            .pipe(takeUntilDestroyed(this.destroyRef), take(1))
            .subscribe(() => {
            this.initialiseComponent();
            setTimeout(() => {
                this.isInitialised.set(true);
            });
        });
    }
    initialiseComponent() {
        this.mapContent.nativeElement.style.filter = `url('#gammaFilter')`;
        setTimeout(() => {
            this.initDraggable();
            this.initializeEventListeners();
        });
        this.initializeResizeObserver();
    }
    getMapContainerWidth() {
        return this.mapContainer().nativeElement.getBoundingClientRect().width;
    }
    getMapContainerHeight() {
        return this.mapContainer().nativeElement.getBoundingClientRect().height;
    }
    getDragWidthOffset() {
        return this.drag.nativeElement.offsetWidth / 2;
    }
    getDragHeightOffset() {
        return this.drag.nativeElement.offsetHeight / 2;
    }
    getDragContainerWidthOffset() {
        return this.dragContainer.nativeElement.offsetWidth / 2;
    }
    getDragContainerHeightOffset() {
        return this.dragContainer.nativeElement.offsetHeight / 2;
    }
    getClip() {
        const map = this.map();
        const actualMap = map?.state?.map();
        if (!actualMap || !map) {
            return;
        }
        if (!this.currentBounds()) {
            this.currentBounds.set(map.getBounds());
        }
        const bounds = this.currentBounds();
        if (!bounds) {
            throw 'Could not get bounds from map';
        }
        return {
            left: [
                [0, 0],
                [0, 1],
                [this.dragLeftRatioWithDragWidthOffset(), 1],
                [this.dragLeftRatioWithDragWidthOffset(), 0],
            ],
            right: [
                [this.dragLeftRatioWithDragWidthOffset(), 0],
                [this.dragLeftRatioWithDragWidthOffset(), 1],
                [1, 1],
                [1, 0],
            ],
        };
    }
    initializeEventListeners() {
        const map = this.map();
        const actualMap = this.map()?.state?.map();
        if (!actualMap || !map) {
            throw 'Map not initialized, failed to initialize event listeners';
        }
        this.currentBounds.set(map.getBounds());
        actualMap.on('movestart', this.mapListeners['movestart']);
        actualMap.on('moveend', this.mapListeners['moveend']);
        actualMap.getView().on('change:center', this.mapListeners['move']);
    }
    storeBounds(event) {
        this.currentBounds.set(this.map()?.getBounds());
    }
    getClipAndEmit() {
        const clip = this.getClip();
        if (clip) {
            this.map().clipLayers(clip);
        }
    }
    onDragMove(event) {
        if ('currentTranslate' in event) {
            const wrapperBbox = this.mapsWrapper.nativeElement.getBoundingClientRect();
            const width = wrapperBbox.width;
            const leftWidth = ((event.currentTranslate.x + this.getDragContainerWidthOffset()) /
                width) *
                100;
            const rightWidth = 100 - leftWidth;
            const rightLeft = event.currentTranslate.x + this.getDragContainerWidthOffset();
            this.renderer.setAttribute(this.gammaMaskLeft.nativeElement, 'width', `${leftWidth}%`);
            this.renderer.setAttribute(this.gammaMaskRight.nativeElement, 'width', `${rightWidth}%`);
            this.renderer.setAttribute(this.gammaMaskRight.nativeElement, 'x', `${(rightLeft / width) * 100}%`);
            this.clipChange.emit(this.getClip());
            this.currentDragPosition.set({
                x: event.currentTranslate.x,
                y: event.currentTranslate.y,
            });
            this.dragLeftRatio.set(this.currentDragPosition().x / this.getMapContainerWidth());
            this.getClipAndEmit();
        }
    }
    onDragEnd() {
        this.debouncedEndClip();
    }
    setLeftLabelPosition() {
        if (!this.imageLabelLeft) {
            return;
        }
        const left = this.currentDragPosition().x -
            this.imageLabelLeft.nativeElement.getBoundingClientRect().width +
            this.getDragContainerWidthOffset() -
            this.getDragWidthOffset();
        this.renderer.setStyle(this.imageLabelLeft.nativeElement, 'transform', `translate(${left}px, ${0}px)`);
    }
    resizeSideBySide() {
        const mapContainerWidth = this.getMapContainerWidth();
        let newLeft = mapContainerWidth * this.dragLeftRatio();
        const leftEdge = this.getDragContainerWidthOffset();
        const rightEdge = mapContainerWidth - this.getDragContainerWidthOffset();
        if (newLeft < leftEdge) {
            newLeft = leftEdge;
        }
        else if (newLeft > rightEdge) {
            newLeft = rightEdge;
        }
        this.currentDragPosition.set({
            x: newLeft,
            y: this.currentDragPosition().y,
        });
        this.draggable.updateTransform(this.currentDragPosition());
        this.clipChange.emit(this.getClip());
    }
    initializeResizeObserver() {
        this.resizeObserver = new ResizeObserver(() => {
            this.resizeSideBySide();
        });
        this.resizeObserver.observe(this.mapContainer().nativeElement);
    }
    startClipping() {
        if (this.refreshInterval) {
            return;
        }
        this.refreshInterval = setInterval(() => {
            this.clipChange.emit(this.getClip());
        }, 20);
    }
    endClipping() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = undefined;
            setTimeout(() => {
                this.clipChange.emit(this.getClip());
            });
        }
    }
    onBeforeGammaChange(value) {
        this.beforeGamma.set(value);
        const filters = this.elementRef.nativeElement.querySelectorAll('.beforeGammaElement');
        for (const filter of filters) {
            filter.setAttribute('amplitude', `${value}`);
            filter.setAttribute('exponent', `${1 / value}`);
            // filter.setAttribute('offset', `${(value - 1) / 5}`);
        }
    }
    onAfterGammaChange(value) {
        this.afterGamma.set(value);
        const filters = this.elementRef.nativeElement.querySelectorAll('.afterGammaElement');
        for (const filter of filters) {
            // filter.setAttribute('amplitude', `${value}`);
            filter.setAttribute('exponent', `${1 / value}`);
            // filter.setAttribute('offset', `${(value - 1) / 5}`);
        }
    }
    ngOnDestroy() {
        for (const unlistener of this.unlisteners) {
            unlistener();
        }
        if (this.resizeObserver) {
            this.resizeObserver.unobserve(this.mapContainer().nativeElement);
        }
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }
        const actualMap = this.map()?.state?.map();
        if (actualMap) {
            for (let listener in this.mapListeners) {
                actualMap.un(listener, this.mapListeners[listener]);
                actualMap.getView().un(listener, this.mapListeners[listener]);
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersSideBySideComponent, deps: [{ token: i0.Renderer2 }, { token: i0.DestroyRef }, { token: i0.ElementRef }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "17.3.1", type: OpenlayersSideBySideComponent, isStandalone: true, selector: "oui-openlayers-side-by-side", inputs: { leftLabelTemplate: { classPropertyName: "leftLabelTemplate", publicName: "leftLabelTemplate", isSignal: true, isRequired: false, transformFunction: null }, rightLabelTemplate: { classPropertyName: "rightLabelTemplate", publicName: "rightLabelTemplate", isSignal: true, isRequired: false, transformFunction: null }, mapContainer: { classPropertyName: "mapContainer", publicName: "mapContainer", isSignal: true, isRequired: true, transformFunction: null }, map: { classPropertyName: "map", publicName: "map", isSignal: true, isRequired: true, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, outputs: { clipChange: "clipChange", dragged: "dragged", clicked: "clicked", released: "released" }, viewQueries: [{ propertyName: "dragContainer", first: true, predicate: ["dragContainer"], descendants: true }, { propertyName: "drag", first: true, predicate: ["drag"], descendants: true }, { propertyName: "imageLabelRight", first: true, predicate: ["imageLabelRight"], descendants: true }, { propertyName: "imageLabelLeft", first: true, predicate: ["imageLabelLeft"], descendants: true }, { propertyName: "thumbIconTemplate", first: true, predicate: ["thumbIconTemplate"], descendants: true }, { propertyName: "mapContent", first: true, predicate: ["mapContent"], descendants: true }, { propertyName: "draggable", first: true, predicate: ["draggable"], descendants: true }, { propertyName: "mapsWrapper", first: true, predicate: ["mapsWrapper"], descendants: true }, { propertyName: "gammaMaskRight", first: true, predicate: ["gammaMaskRight"], descendants: true }, { propertyName: "gammaMaskLeft", first: true, predicate: ["gammaMaskLeft"], descendants: true }], ngImport: i0, template: "<div class=\"side-by-side-wrapper\" [ngClass]=\"{'initialised': isInitialised()}\">\n  <div class=\"maps-wrapper\" #mapsWrapper>\n    <div\n        oui-draggable\n        (dragMove)=\"onDragMove($event)\"\n        (dragEnd)=\"onDragEnd()\"\n        #draggable=\"OuiDraggableDirective\"\n        class=\"drag-container\"\n        #dragContainer\n        [ngClass]=\"{ vertical: isVertical(), horizontal: !isVertical() }\"\n    >\n      <div class=\"drag shadow\" #drag></div>\n      <div class=\"drag-caret-container\">\n        <oui-icon\n            icon=\"assets/icons/caret-left.svg\"\n            [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n            class=\"drag-caret-left\"\n        ></oui-icon>\n        <oui-icon\n            icon=\"assets/icons/caret-right.svg\"\n            [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n            class=\"drag-caret-right\"\n        ></oui-icon>\n      </div>\n    </div>\n    <div class=\"map-content\" #mapContent>\n      <svg class=\"gamma-mask-svg\">\n        <filter id=\"gammaFilter\" primitiveUnits=\"objectBoundingBox\" width=\"100%\" height=\"100%\" x=\"0\" y=\"0\">\n          <feColorMatrix result=\"CURRENT\"></feColorMatrix>\n          <feComponentTransfer #gammaMaskLeft result=\"LEFT\" x=\"0%\" width=\"50%\" height=\"100%\" y=\"0%\">\n            <feFuncR\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n            <feFuncG\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n            <feFuncB\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n          </feComponentTransfer>\n          <feComposite in2=\"CURRENT\" in=\"LEFT\" operator=\"over\" result=\"CURRENT\"></feComposite>\n          <feComponentTransfer #gammaMaskRight result=\"RIGHT\" x=\"50%\" width=\"50%\" height=\"100%\" y=\"0%\">\n            <feFuncR\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n            <feFuncG\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n            <feFuncB\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n          </feComponentTransfer>\n\n          <feComposite in2=\"CURRENT\" in=\"RIGHT\" operator=\"over\" result=\"COMPOSITE\">\n\n          </feComposite>\n<!--          <feComposite in2=\"SourceGraphic\" in=\"FIRST_COMPOSITE\" operator=\"over\" result=\"FIRST_COMBINED_COMPOSITE\">-->\n\n<!--          </feComposite>-->\n<!--          <feComposite in2=\"FIRST_COMBINED_COMPOSITE\" in=\"SECOND\" operator=\"over\" result=\"SECOND_COMPOSITE\">-->\n\n<!--          </feComposite>-->\n<!--          <feComposite in2=\"FIRST_COMBINED_COMPOSITE\" in=\"SECOND_COMPOSITE\" operator=\"in\"></feComposite>-->\n        </filter>\n      </svg>\n\n      <ng-content>\n\n      </ng-content>\n    </div>\n\n\n<!--    <div class=\"side-by-side-label-wrapper left\" *ngIf=\"leftLabelTemplate\">-->\n<!--      <ng-content *ngTemplateOutlet=\"leftLabelTemplate\"></ng-content>-->\n<!--    </div>-->\n\n<!--    <div class=\"side-by-side-label-wrapper right\" [ngClass]=\"{'has-geolocate': map?.options?.geoLocateControl}\" *ngIf=\"rightLabelTemplate\">-->\n<!--      <ng-content *ngTemplateOutlet=\"rightLabelTemplate\"></ng-content>-->\n<!--    </div>-->\n\n  </div>\n  <div class=\"gamma-slider-wrapper\">\n    <div class=\"gamma-slider left\">\n      <oui-slider [options]=\"gammaSliderOptions()\" [value]=\"beforeGamma()\" (valueChange)=\"onBeforeGammaChange($event)\"\n      ></oui-slider>\n    </div>\n    <div class=\"gamma-slider right\">\n      <oui-slider\n          [options]=\"gammaSliderOptions()\"\n          [value]=\"afterGamma()\"\n          (valueChange)=\"onAfterGammaChange($event)\"\n      ></oui-slider>\n    </div>\n\n    <ng-template #thumbIconTemplate>\n      <oui-icon  [icon]=\"'assets/icons/brightness.svg'\"\n                 [options]=\"{\n    viewBox: '0 0 48 48',\n    size: '13px',\n    fillColor: 'color-background-primary-text',\n    strokeColor: 'color-background-primary-text',\n    }\">\n\n      </oui-icon>\n    </ng-template>\n  </div>\n\n\n</div>\n", styles: [":host{width:100%;height:100%;position:absolute;top:0;left:0;z-index:1;pointer-events:none}:host .gamma-mask-svg{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:-9999}:host .side-by-side-wrapper{width:100%;height:100%;opacity:0;transition:opacity .3s;pointer-events:none;display:flex;flex-direction:column}:host .side-by-side-wrapper .gamma-slider-wrapper{display:flex;height:5rem;justify-content:space-around;pointer-events:all;--oui-slider-thumb-color-primary: var(--color-background-primary);--oui-slider-thumb-border-radius: 50%;--oui-slider-thumb-width: 20px;--oui-slider-thumb-height: 20px;--oui-slider-thumb-color-primary-hover: var(--color-background-primary-hover)}:host .side-by-side-wrapper .gamma-slider-wrapper .gamma-slider{width:25%;height:100%}:host .side-by-side-wrapper .maps-wrapper{height:100%;width:100%;flex:1;position:relative;overflow:hidden;box-shadow:var(--oui-openlayers-side-by-side-map-box-shadow)}:host .side-by-side-wrapper .maps-wrapper .map-content{height:100%;width:100%;position:relative}:host .side-by-side-wrapper .maps-wrapper .drag-container{position:absolute;width:var(--oui-openlayers-side-by-side-caret-container-width);pointer-events:all;z-index:2;cursor:col-resize}:host .side-by-side-wrapper .maps-wrapper .drag-container .drag-caret-container{display:flex;justify-content:space-between;align-items:center;position:absolute;border-width:var(--oui-openlayers-side-by-side-caret-container-border-width);border-style:var(--oui-openlayers-side-by-side-caret-container-border-style);border-color:var(--oui-openlayers-side-by-side-caret-container-border-color);height:var(--oui-openlayers-side-by-side-caret-container-height);width:var(--oui-openlayers-side-by-side-caret-container-width);background-color:var(--oui-openlayers-side-by-side-caret-container-background-color);border-radius:var(--oui-openlayers-side-by-side-caret-container-border-radius)}:host .side-by-side-wrapper .maps-wrapper .drag-container .drag-caret-container oui-icon{filter:var(--oui-openlayers-side-by-side-caret-icon-filter)}:host .side-by-side-wrapper .maps-wrapper .drag-container:hover{cursor:col-resize}:host .side-by-side-wrapper .maps-wrapper .drag-container.vertical{height:100%;width:40px;display:flex;justify-content:center;align-items:center}:host .side-by-side-wrapper .maps-wrapper .drag-container.vertical .drag{width:var(--oui-openlayers-side-by-side-drag-width);background-color:var(--oui-openlayers-side-by-side-drag-background-color);border:solid var(--border-color-primary);border-width:0 1px;height:100%}:host .side-by-side-wrapper .maps-wrapper .drag-container.horizontal{width:100%;height:40px;display:flex;justify-content:center}:host .side-by-side-wrapper .maps-wrapper .drag-container.horizontal .drag{height:4px;background-color:#fff;width:100%}:host .side-by-side-wrapper.initialised{opacity:1}:host .side-by-side-wrapper .side-by-side-label-wrapper{display:flex;align-items:center;position:absolute;top:2rem;flex:0;min-height:3rem;-webkit-user-select:none;user-select:none;font-size:var(--font-size-body-smaller);border-radius:var(--border-radius-default);color:var(--color-dark)}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-content{line-height:1px}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-icon{margin-right:10px}:host .side-by-side-wrapper .side-by-side-label-wrapper.left{z-index:1;left:1rem}:host .side-by-side-wrapper .side-by-side-label-wrapper.right{z-index:0;right:1rem}:host .side-by-side-wrapper .side-by-side-label-wrapper.right.has-geolocate{right:5rem;margin-right:1rem}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: OuiSliderComponent, selector: "oui-slider", inputs: ["value", "valueTo", "options"], outputs: ["valueChange", "valueToChange", "debouncedvalueChange", "debouncedValueToChange"] }, { kind: "directive", type: OuiDraggableDirective, selector: "[oui-draggable]", outputs: ["dragMove", "dragStart", "dragEnd"], exportAs: ["OuiDraggableDirective"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersSideBySideComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-openlayers-side-by-side', standalone: true, imports: [
                        OuiIconComponent,
                        CommonModule,
                        OuiSliderComponent,
                        OuiDraggableDirective,
                    ], template: "<div class=\"side-by-side-wrapper\" [ngClass]=\"{'initialised': isInitialised()}\">\n  <div class=\"maps-wrapper\" #mapsWrapper>\n    <div\n        oui-draggable\n        (dragMove)=\"onDragMove($event)\"\n        (dragEnd)=\"onDragEnd()\"\n        #draggable=\"OuiDraggableDirective\"\n        class=\"drag-container\"\n        #dragContainer\n        [ngClass]=\"{ vertical: isVertical(), horizontal: !isVertical() }\"\n    >\n      <div class=\"drag shadow\" #drag></div>\n      <div class=\"drag-caret-container\">\n        <oui-icon\n            icon=\"assets/icons/caret-left.svg\"\n            [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n            class=\"drag-caret-left\"\n        ></oui-icon>\n        <oui-icon\n            icon=\"assets/icons/caret-right.svg\"\n            [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n            class=\"drag-caret-right\"\n        ></oui-icon>\n      </div>\n    </div>\n    <div class=\"map-content\" #mapContent>\n      <svg class=\"gamma-mask-svg\">\n        <filter id=\"gammaFilter\" primitiveUnits=\"objectBoundingBox\" width=\"100%\" height=\"100%\" x=\"0\" y=\"0\">\n          <feColorMatrix result=\"CURRENT\"></feColorMatrix>\n          <feComponentTransfer #gammaMaskLeft result=\"LEFT\" x=\"0%\" width=\"50%\" height=\"100%\" y=\"0%\">\n            <feFuncR\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n            <feFuncG\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n            <feFuncB\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n          </feComponentTransfer>\n          <feComposite in2=\"CURRENT\" in=\"LEFT\" operator=\"over\" result=\"CURRENT\"></feComposite>\n          <feComponentTransfer #gammaMaskRight result=\"RIGHT\" x=\"50%\" width=\"50%\" height=\"100%\" y=\"0%\">\n            <feFuncR\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n            <feFuncG\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n            <feFuncB\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n          </feComponentTransfer>\n\n          <feComposite in2=\"CURRENT\" in=\"RIGHT\" operator=\"over\" result=\"COMPOSITE\">\n\n          </feComposite>\n<!--          <feComposite in2=\"SourceGraphic\" in=\"FIRST_COMPOSITE\" operator=\"over\" result=\"FIRST_COMBINED_COMPOSITE\">-->\n\n<!--          </feComposite>-->\n<!--          <feComposite in2=\"FIRST_COMBINED_COMPOSITE\" in=\"SECOND\" operator=\"over\" result=\"SECOND_COMPOSITE\">-->\n\n<!--          </feComposite>-->\n<!--          <feComposite in2=\"FIRST_COMBINED_COMPOSITE\" in=\"SECOND_COMPOSITE\" operator=\"in\"></feComposite>-->\n        </filter>\n      </svg>\n\n      <ng-content>\n\n      </ng-content>\n    </div>\n\n\n<!--    <div class=\"side-by-side-label-wrapper left\" *ngIf=\"leftLabelTemplate\">-->\n<!--      <ng-content *ngTemplateOutlet=\"leftLabelTemplate\"></ng-content>-->\n<!--    </div>-->\n\n<!--    <div class=\"side-by-side-label-wrapper right\" [ngClass]=\"{'has-geolocate': map?.options?.geoLocateControl}\" *ngIf=\"rightLabelTemplate\">-->\n<!--      <ng-content *ngTemplateOutlet=\"rightLabelTemplate\"></ng-content>-->\n<!--    </div>-->\n\n  </div>\n  <div class=\"gamma-slider-wrapper\">\n    <div class=\"gamma-slider left\">\n      <oui-slider [options]=\"gammaSliderOptions()\" [value]=\"beforeGamma()\" (valueChange)=\"onBeforeGammaChange($event)\"\n      ></oui-slider>\n    </div>\n    <div class=\"gamma-slider right\">\n      <oui-slider\n          [options]=\"gammaSliderOptions()\"\n          [value]=\"afterGamma()\"\n          (valueChange)=\"onAfterGammaChange($event)\"\n      ></oui-slider>\n    </div>\n\n    <ng-template #thumbIconTemplate>\n      <oui-icon  [icon]=\"'assets/icons/brightness.svg'\"\n                 [options]=\"{\n    viewBox: '0 0 48 48',\n    size: '13px',\n    fillColor: 'color-background-primary-text',\n    strokeColor: 'color-background-primary-text',\n    }\">\n\n      </oui-icon>\n    </ng-template>\n  </div>\n\n\n</div>\n", styles: [":host{width:100%;height:100%;position:absolute;top:0;left:0;z-index:1;pointer-events:none}:host .gamma-mask-svg{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:-9999}:host .side-by-side-wrapper{width:100%;height:100%;opacity:0;transition:opacity .3s;pointer-events:none;display:flex;flex-direction:column}:host .side-by-side-wrapper .gamma-slider-wrapper{display:flex;height:5rem;justify-content:space-around;pointer-events:all;--oui-slider-thumb-color-primary: var(--color-background-primary);--oui-slider-thumb-border-radius: 50%;--oui-slider-thumb-width: 20px;--oui-slider-thumb-height: 20px;--oui-slider-thumb-color-primary-hover: var(--color-background-primary-hover)}:host .side-by-side-wrapper .gamma-slider-wrapper .gamma-slider{width:25%;height:100%}:host .side-by-side-wrapper .maps-wrapper{height:100%;width:100%;flex:1;position:relative;overflow:hidden;box-shadow:var(--oui-openlayers-side-by-side-map-box-shadow)}:host .side-by-side-wrapper .maps-wrapper .map-content{height:100%;width:100%;position:relative}:host .side-by-side-wrapper .maps-wrapper .drag-container{position:absolute;width:var(--oui-openlayers-side-by-side-caret-container-width);pointer-events:all;z-index:2;cursor:col-resize}:host .side-by-side-wrapper .maps-wrapper .drag-container .drag-caret-container{display:flex;justify-content:space-between;align-items:center;position:absolute;border-width:var(--oui-openlayers-side-by-side-caret-container-border-width);border-style:var(--oui-openlayers-side-by-side-caret-container-border-style);border-color:var(--oui-openlayers-side-by-side-caret-container-border-color);height:var(--oui-openlayers-side-by-side-caret-container-height);width:var(--oui-openlayers-side-by-side-caret-container-width);background-color:var(--oui-openlayers-side-by-side-caret-container-background-color);border-radius:var(--oui-openlayers-side-by-side-caret-container-border-radius)}:host .side-by-side-wrapper .maps-wrapper .drag-container .drag-caret-container oui-icon{filter:var(--oui-openlayers-side-by-side-caret-icon-filter)}:host .side-by-side-wrapper .maps-wrapper .drag-container:hover{cursor:col-resize}:host .side-by-side-wrapper .maps-wrapper .drag-container.vertical{height:100%;width:40px;display:flex;justify-content:center;align-items:center}:host .side-by-side-wrapper .maps-wrapper .drag-container.vertical .drag{width:var(--oui-openlayers-side-by-side-drag-width);background-color:var(--oui-openlayers-side-by-side-drag-background-color);border:solid var(--border-color-primary);border-width:0 1px;height:100%}:host .side-by-side-wrapper .maps-wrapper .drag-container.horizontal{width:100%;height:40px;display:flex;justify-content:center}:host .side-by-side-wrapper .maps-wrapper .drag-container.horizontal .drag{height:4px;background-color:#fff;width:100%}:host .side-by-side-wrapper.initialised{opacity:1}:host .side-by-side-wrapper .side-by-side-label-wrapper{display:flex;align-items:center;position:absolute;top:2rem;flex:0;min-height:3rem;-webkit-user-select:none;user-select:none;font-size:var(--font-size-body-smaller);border-radius:var(--border-radius-default);color:var(--color-dark)}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-content{line-height:1px}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-icon{margin-right:10px}:host .side-by-side-wrapper .side-by-side-label-wrapper.left{z-index:1;left:1rem}:host .side-by-side-wrapper .side-by-side-label-wrapper.right{z-index:0;right:1rem}:host .side-by-side-wrapper .side-by-side-label-wrapper.right.has-geolocate{right:5rem;margin-right:1rem}\n"] }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.DestroyRef }, { type: i0.ElementRef }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { clipChange: [{
                type: Output
            }], dragged: [{
                type: Output
            }], clicked: [{
                type: Output
            }], released: [{
                type: Output
            }], dragContainer: [{
                type: ViewChild,
                args: ['dragContainer']
            }], drag: [{
                type: ViewChild,
                args: ['drag']
            }], imageLabelRight: [{
                type: ViewChild,
                args: ['imageLabelRight']
            }], imageLabelLeft: [{
                type: ViewChild,
                args: ['imageLabelLeft']
            }], thumbIconTemplate: [{
                type: ViewChild,
                args: ['thumbIconTemplate']
            }], mapContent: [{
                type: ViewChild,
                args: ['mapContent']
            }], draggable: [{
                type: ViewChild,
                args: ['draggable']
            }], mapsWrapper: [{
                type: ViewChild,
                args: ['mapsWrapper']
            }], gammaMaskRight: [{
                type: ViewChild,
                args: ['gammaMaskRight']
            }], gammaMaskLeft: [{
                type: ViewChild,
                args: ['gammaMaskLeft']
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BlbmxheWVycy1zaWRlLWJ5LXNpZGUuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9vcGVubGF5ZXJzL3NpZGUtYnktc2lkZS9vcGVubGF5ZXJzLXNpZGUtYnktc2lkZS5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL29wZW5sYXllcnMvc2lkZS1ieS1zaWRlL29wZW5sYXllcnMtc2lkZS1ieS1zaWRlLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFFTCxTQUFTLEVBQ1QsUUFBUSxFQUVSLE1BQU0sRUFFTixZQUFZLEVBQ1osTUFBTSxFQUNOLEtBQUssRUFFTCxNQUFNLEVBRU4sTUFBTSxFQUVOLFNBQVMsR0FDVixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsWUFBWSxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3pELE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ25ELE9BQU8sRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQ3ZDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ2hFLE9BQU8sRUFBcUIsa0JBQWtCLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUMxRSxPQUFPLEVBQWdCLHFCQUFxQixFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFDM0UsT0FBTyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsTUFBTSxXQUFXLENBQUM7OztBQWdDNUMsTUFBTSxPQUFPLDZCQUE2QjtJQTJEOUI7SUFDQTtJQUNBO0lBQ2tCO0lBN0RyQixpQkFBaUIsR0FBRyxLQUFLLEVBQW9CLENBQUM7SUFDOUMsa0JBQWtCLEdBQUcsS0FBSyxFQUFvQixDQUFDO0lBQy9DLFlBQVksR0FBRyxLQUFLLENBQUMsUUFBUSxFQUFjLENBQUM7SUFDNUMsR0FBRyxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQXVCLENBQUM7SUFDNUMsT0FBTyxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQStCLENBQUM7SUFFckQsVUFBVSxHQUFHLElBQUksWUFBWSxFQUFlLENBQUM7SUFDN0MsT0FBTyxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7SUFDN0IsT0FBTyxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7SUFDN0IsUUFBUSxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7SUFFSixhQUFhLENBQWE7SUFDbkMsSUFBSSxDQUFhO0lBQ04sZUFBZSxDQUFhO0lBQzdCLGNBQWMsQ0FBYTtJQUNoQyxpQkFBaUIsQ0FBbUI7SUFDM0MsVUFBVSxDQUFhO0lBQ3hCLFNBQVMsQ0FBd0I7SUFDL0IsV0FBVyxDQUFhO0lBQ3JCLGNBQWMsQ0FBYTtJQUM1QixhQUFhLENBQWE7SUFFOUMsbUJBQW1CLEdBQUcsTUFBTSxDQUFnQjtRQUNsRCxDQUFDLEVBQUUsQ0FBQztRQUNKLENBQUMsRUFBRSxDQUFDO0tBQ0wsQ0FBQyxDQUFDO0lBQ0ssY0FBYyxDQUFpQjtJQUMvQixhQUFhLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzFCLGdDQUFnQyxHQUFHLFFBQVEsQ0FBQyxHQUFHLEVBQUU7UUFDdkQsT0FBTyxDQUNMLElBQUksQ0FBQyxhQUFhLEVBQUU7WUFDcEIsSUFBSSxDQUFDLDJCQUEyQixFQUFFLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQ2pFLENBQUM7SUFDSixDQUFDLENBQUMsQ0FBQztJQUNLLHVCQUF1QixHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUN4QyxlQUFlLENBQU07SUFDckIsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBRWhFLFdBQVcsR0FBbUIsRUFBRSxDQUFDO0lBQ2pDLFlBQVksR0FFaEI7UUFDRixTQUFTLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQ3hDLElBQUksRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDakMsT0FBTyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztLQUNyQyxDQUFDO0lBQ0ssYUFBYSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUM5QixVQUFVLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQzFCLFdBQVcsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDeEIsVUFBVSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN2QixrQkFBa0IsR0FBRyxNQUFNLENBQW9CO1FBQ3BELEdBQUcsRUFBRSxJQUFJO1FBQ1QsR0FBRyxFQUFFLENBQUM7UUFDTixRQUFRLEVBQUUsRUFBRTtRQUNaLFFBQVEsRUFBRSxFQUFFO0tBQ2IsQ0FBQyxDQUFDO0lBQ0ksYUFBYSxHQUFHLE1BQU0sQ0FBOEIsU0FBUyxDQUFDLENBQUM7SUFDdEUsWUFDVSxRQUFtQixFQUNuQixVQUFzQixFQUN0QixVQUFzQixFQUNKLFFBQWtCO1FBSHBDLGFBQVEsR0FBUixRQUFRLENBQVc7UUFDbkIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtRQUN0QixlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQ0osYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUU1QyxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQ25CLEdBQUcsRUFBRTtZQUNILElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNyRSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztnQkFDMUIsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ25CLENBQUM7UUFDSCxDQUFDLEVBQ0Q7WUFDRSxpQkFBaUIsRUFBRSxJQUFJO1NBQ3hCLENBQ0YsQ0FBQztJQUNKLENBQUM7SUFFRCxlQUFlO1FBQ2IsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQzthQUNyQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ3pDLFNBQVMsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQ3hCLElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLGFBQWEsRUFBRSxVQUFVLEVBQUUsQ0FBQztnQkFDdEUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUM7b0JBQzdCLENBQUMsRUFBRSxDQUFDO29CQUNKLENBQUMsRUFBRSxDQUFDO2lCQUNMLENBQUMsQ0FBQztZQUNMLENBQUM7aUJBQU0sSUFDTCxLQUFLLENBQUMsSUFBSSxLQUFLLE1BQU07Z0JBQ3JCLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxhQUFhLEVBQUUsVUFBVSxFQUN4QyxDQUFDO2dCQUNELElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDO29CQUM3QixDQUFDLEVBQ0MsSUFBSSxDQUFDLG9CQUFvQixFQUFFO3dCQUMzQixJQUFJLENBQUMsMkJBQTJCLEVBQUUsR0FBRyxDQUFDO29CQUN4QyxDQUFDLEVBQUUsQ0FBQztpQkFDTCxDQUFDLENBQUM7WUFDTCxDQUFDO2lCQUFNLElBQ0wsS0FBSyxDQUFDLElBQUksS0FBSyxNQUFNO2dCQUNyQixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsYUFBYSxFQUFFLFNBQVMsRUFDdkMsQ0FBQztnQkFDRCxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxDQUFDO2dCQUNyQyxNQUFNLFdBQVcsR0FBRyxHQUFHLEVBQUUsT0FBTyxFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUM7Z0JBQzlDLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7b0JBQy9CLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxPQUFPLENBQUM7d0JBQ3BCLElBQUksRUFBRSxXQUFXLEdBQUcsSUFBSTt3QkFDeEIsUUFBUSxFQUFFLEdBQUc7cUJBQ2QsQ0FBQyxDQUFDO2dCQUNMLENBQUM7WUFDSCxDQUFDO2lCQUFNLElBQ0wsS0FBSyxDQUFDLElBQUksS0FBSyxNQUFNO2dCQUNyQixJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsYUFBYSxFQUFFLFNBQVMsRUFDdkMsQ0FBQztnQkFDRCxNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxDQUFDO2dCQUNyQyxNQUFNLFdBQVcsR0FBRyxHQUFHLEVBQUUsT0FBTyxFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUM7Z0JBQzlDLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUM7b0JBQy9CLEdBQUcsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxPQUFPLENBQUM7d0JBQ3BCLElBQUksRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsR0FBRyxJQUFJLEVBQUUsQ0FBQyxDQUFDO3dCQUNyQyxRQUFRLEVBQUUsR0FBRztxQkFDZCxDQUFDLENBQUM7Z0JBQ0wsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVMLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxHQUFHLENBQUM7WUFDMUIsR0FBRyxFQUFFLElBQUk7WUFDVCxHQUFHLEVBQUUsQ0FBQztZQUNOLFFBQVEsRUFBRSxFQUFFO1lBQ1osUUFBUSxFQUFFLEVBQUU7WUFDWixvQkFBb0IsRUFBRSxJQUFJLENBQUMsaUJBQWlCO1NBQzdDLENBQUMsQ0FBQztRQUVILElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUM7WUFDZixJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QixFQUFFLENBQUM7Z0JBQ2xDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1lBQzVCLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVPLGFBQWE7UUFDbkIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQ3BDLElBQUksQ0FBQyxTQUFTLENBQUMsc0JBQXNCLENBQUM7WUFDcEMsU0FBUyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYTtZQUN6QyxNQUFNLEVBQUUsTUFBTTtTQUNmLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUM7WUFDM0IsQ0FBQyxFQUFFLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsMkJBQTJCLEVBQUU7WUFDdkUsQ0FBQyxFQUFFLENBQUM7U0FDTCxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUNwQixJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQzNELENBQUM7SUFDSixDQUFDO0lBRU8sa0JBQWtCO1FBQ3hCLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDdkMsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNULE9BQU87UUFDVCxDQUFDO1FBQ0QsR0FBRyxDQUFDLE9BQU87YUFDUixJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNsRCxTQUFTLENBQUMsR0FBRyxFQUFFO1lBQ2QsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUM7WUFDM0IsVUFBVSxDQUFDLEdBQUcsRUFBRTtnQkFDZCxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUMvQixDQUFDLENBQUMsQ0FBQztRQUNMLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVPLG1CQUFtQjtRQUN6QixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLHFCQUFxQixDQUFDO1FBQ25FLFVBQVUsQ0FBQyxHQUFHLEVBQUU7WUFDZCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDckIsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUM7UUFDbEMsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRU8sb0JBQW9CO1FBQzFCLE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQztJQUN6RSxDQUFDO0lBRU8scUJBQXFCO1FBQzNCLE9BQU8sSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLE1BQU0sQ0FBQztJQUMxRSxDQUFDO0lBRU8sa0JBQWtCO1FBQ3hCLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBRU8sbUJBQW1CO1FBQ3pCLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBRU8sMkJBQTJCO1FBQ2pDLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBRU8sNEJBQTRCO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBRU8sT0FBTztRQUNiLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUN2QixNQUFNLFNBQVMsR0FBb0IsR0FBRyxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsQ0FBQztRQUNyRCxJQUFJLENBQUMsU0FBUyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDdkIsT0FBTztRQUNULENBQUM7UUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxFQUFFLENBQUM7WUFDMUIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUM7UUFDMUMsQ0FBQztRQUNELE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUNwQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDWixNQUFNLCtCQUErQixDQUFDO1FBQ3hDLENBQUM7UUFDRCxPQUFPO1lBQ0wsSUFBSSxFQUFFO2dCQUNKLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDTixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ04sQ0FBQyxJQUFJLENBQUMsZ0NBQWdDLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQzVDLENBQUMsSUFBSSxDQUFDLGdDQUFnQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2FBQzdDO1lBQ0QsS0FBSyxFQUFFO2dCQUNMLENBQUMsSUFBSSxDQUFDLGdDQUFnQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUM1QyxDQUFDLElBQUksQ0FBQyxnQ0FBZ0MsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDNUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNOLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQzthQUNQO1NBQ0YsQ0FBQztJQUNKLENBQUM7SUFFTyx3QkFBd0I7UUFDOUIsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ3ZCLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLENBQUM7UUFDM0MsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ3ZCLE1BQU0sMkRBQTJELENBQUM7UUFDcEUsQ0FBQztRQUNELElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQ3hDLFNBQVMsQ0FBQyxFQUFFLENBQUMsV0FBa0IsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7UUFFakUsU0FBUyxDQUFDLEVBQUUsQ0FBQyxTQUFnQixFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQztRQUM3RCxTQUFTLENBQUMsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLGVBQXNCLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQzVFLENBQUM7SUFFTyxXQUFXLENBQUMsS0FBVTtRQUM1QixJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsU0FBUyxFQUFFLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBRU8sY0FBYztRQUNwQixNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDNUIsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUNULElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDOUIsQ0FBQztJQUNILENBQUM7SUFFTSxVQUFVLENBQUMsS0FBbUI7UUFDbkMsSUFBSSxrQkFBa0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUNoQyxNQUFNLFdBQVcsR0FDZixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1lBQ3pELE1BQU0sS0FBSyxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUM7WUFDaEMsTUFBTSxTQUFTLEdBQ2IsQ0FBQyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUM7Z0JBQzlELEtBQUssQ0FBQztnQkFDUixHQUFHLENBQUM7WUFDTixNQUFNLFVBQVUsR0FBRyxHQUFHLEdBQUcsU0FBUyxDQUFDO1lBQ25DLE1BQU0sU0FBUyxHQUNiLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUM7WUFDaEUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQ3hCLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxFQUNoQyxPQUFPLEVBQ1AsR0FBRyxTQUFTLEdBQUcsQ0FDaEIsQ0FBQztZQUNGLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUN4QixJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsRUFDakMsT0FBTyxFQUNQLEdBQUcsVUFBVSxHQUFHLENBQ2pCLENBQUM7WUFDRixJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FDeEIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLEVBQ2pDLEdBQUcsRUFDSCxHQUFHLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUNoQyxDQUFDO1lBQ0YsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFDckMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLEdBQUcsQ0FBQztnQkFDM0IsQ0FBQyxFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUMzQixDQUFDLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUM7YUFDNUIsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQ3BCLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FDM0QsQ0FBQztZQUNGLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN4QixDQUFDO0lBQ0gsQ0FBQztJQUVNLFNBQVM7UUFDZCxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBRU8sb0JBQW9CO1FBQzFCLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDekIsT0FBTztRQUNULENBQUM7UUFDRCxNQUFNLElBQUksR0FDUixJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxDQUFDO1lBQzVCLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSztZQUMvRCxJQUFJLENBQUMsMkJBQTJCLEVBQUU7WUFDbEMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQ3BCLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxFQUNqQyxXQUFXLEVBQ1gsYUFBYSxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQy9CLENBQUM7SUFDSixDQUFDO0lBRU8sZ0JBQWdCO1FBQ3RCLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDdEQsSUFBSSxPQUFPLEdBQUcsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3ZELE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQywyQkFBMkIsRUFBRSxDQUFDO1FBQ3BELE1BQU0sU0FBUyxHQUFHLGlCQUFpQixHQUFHLElBQUksQ0FBQywyQkFBMkIsRUFBRSxDQUFDO1FBQ3pFLElBQUksT0FBTyxHQUFHLFFBQVEsRUFBRSxDQUFDO1lBQ3ZCLE9BQU8sR0FBRyxRQUFRLENBQUM7UUFDckIsQ0FBQzthQUFNLElBQUksT0FBTyxHQUFHLFNBQVMsRUFBRSxDQUFDO1lBQy9CLE9BQU8sR0FBRyxTQUFTLENBQUM7UUFDdEIsQ0FBQztRQUNELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQUM7WUFDM0IsQ0FBQyxFQUFFLE9BQU87WUFDVixDQUFDLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixFQUFFLENBQUMsQ0FBQztTQUNoQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxDQUFDO1FBQzNELElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFTyx3QkFBd0I7UUFDOUIsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLGNBQWMsQ0FBQyxHQUFHLEVBQUU7WUFDNUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsYUFBYSxDQUFDLENBQUM7SUFDakUsQ0FBQztJQUVPLGFBQWE7UUFDbkIsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDekIsT0FBTztRQUNULENBQUM7UUFDRCxJQUFJLENBQUMsZUFBZSxHQUFHLFdBQVcsQ0FBQyxHQUFHLEVBQUU7WUFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDdkMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQ1QsQ0FBQztJQUVPLFdBQVc7UUFDakIsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDekIsYUFBYSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUNwQyxJQUFJLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQztZQUNqQyxVQUFVLENBQUMsR0FBRyxFQUFFO2dCQUNkLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQ3ZDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztJQUNILENBQUM7SUFFTSxtQkFBbUIsQ0FBQyxLQUFhO1FBQ3RDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRTVCLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUM1RCxxQkFBcUIsQ0FDdEIsQ0FBQztRQUNGLEtBQUssTUFBTSxNQUFNLElBQUksT0FBTyxFQUFFLENBQUM7WUFDN0IsTUFBTSxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUUsR0FBRyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1lBQzdDLE1BQU0sQ0FBQyxZQUFZLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLENBQUM7WUFDaEQsdURBQXVEO1FBQ3pELENBQUM7SUFDSCxDQUFDO0lBRU0sa0JBQWtCLENBQUMsS0FBYTtRQUNyQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUUzQixNQUFNLE9BQU8sR0FDWCxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQ3ZFLEtBQUssTUFBTSxNQUFNLElBQUksT0FBTyxFQUFFLENBQUM7WUFDN0IsZ0RBQWdEO1lBQ2hELE1BQU0sQ0FBQyxZQUFZLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLENBQUM7WUFDaEQsdURBQXVEO1FBQ3pELENBQUM7SUFDSCxDQUFDO0lBRU0sV0FBVztRQUNoQixLQUFLLE1BQU0sVUFBVSxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUMxQyxVQUFVLEVBQUUsQ0FBQztRQUNmLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDbkUsQ0FBQztRQUVELElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3pCLGFBQWEsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDdEMsQ0FBQztRQUNELE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLENBQUM7UUFDM0MsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUNkLEtBQUssSUFBSSxRQUFRLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO2dCQUN2QyxTQUFTLENBQUMsRUFBRSxDQUFDLFFBQWUsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0JBQzNELFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsUUFBZSxFQUFFLElBQUksQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUN2RSxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7dUdBblpVLDZCQUE2QiwrRkE4RDlCLFFBQVE7MkZBOURQLDZCQUE2QixrMERDdkQxQyx1OEpBNklBLG9tSEQ1RkksZ0JBQWdCLGlGQUNoQixZQUFZLDZIQUNaLGtCQUFrQiw2TEFDbEIscUJBQXFCOzsyRkFHWiw2QkFBNkI7a0JBWnpDLFNBQVM7K0JBQ0UsNkJBQTZCLGNBRzNCLElBQUksV0FDUDt3QkFDUCxnQkFBZ0I7d0JBQ2hCLFlBQVk7d0JBQ1osa0JBQWtCO3dCQUNsQixxQkFBcUI7cUJBQ3RCOzswQkFnRUUsTUFBTTsyQkFBQyxRQUFRO3lDQXZEUixVQUFVO3NCQUFuQixNQUFNO2dCQUNHLE9BQU87c0JBQWhCLE1BQU07Z0JBQ0csT0FBTztzQkFBaEIsTUFBTTtnQkFDRyxRQUFRO3NCQUFqQixNQUFNO2dCQUU2QixhQUFhO3NCQUFoRCxTQUFTO3VCQUFDLGVBQWU7Z0JBQ0MsSUFBSTtzQkFBOUIsU0FBUzt1QkFBQyxNQUFNO2dCQUNxQixlQUFlO3NCQUFwRCxTQUFTO3VCQUFDLGlCQUFpQjtnQkFDUyxjQUFjO3NCQUFsRCxTQUFTO3VCQUFDLGdCQUFnQjtnQkFDSyxpQkFBaUI7c0JBQWhELFNBQVM7dUJBQUMsbUJBQW1CO2dCQUNMLFVBQVU7c0JBQWxDLFNBQVM7dUJBQUMsWUFBWTtnQkFDQyxTQUFTO3NCQUFoQyxTQUFTO3VCQUFDLFdBQVc7Z0JBQ0ksV0FBVztzQkFBcEMsU0FBUzt1QkFBQyxhQUFhO2dCQUNLLGNBQWM7c0JBQTFDLFNBQVM7dUJBQUMsZ0JBQWdCO2dCQUNDLGFBQWE7c0JBQXhDLFNBQVM7dUJBQUMsZUFBZSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFmdGVyVmlld0luaXQsXG4gIENvbXBvbmVudCxcbiAgY29tcHV0ZWQsXG4gIERlc3Ryb3lSZWYsXG4gIGVmZmVjdCxcbiAgRWxlbWVudFJlZixcbiAgRXZlbnRFbWl0dGVyLFxuICBJbmplY3QsXG4gIGlucHV0LFxuICBPbkRlc3Ryb3ksXG4gIE91dHB1dCxcbiAgUmVuZGVyZXIyLFxuICBzaWduYWwsXG4gIFRlbXBsYXRlUmVmLFxuICBWaWV3Q2hpbGQsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlLCBET0NVTUVOVCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBPdWlJY29uQ29tcG9uZW50IH0gZnJvbSAnb3JiaXRhbC11aS9pY29uJztcbmltcG9ydCB7IGZyb21FdmVudCwgdGFrZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgdGFrZVVudGlsRGVzdHJveWVkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZS9yeGpzLWludGVyb3AnO1xuaW1wb3J0IHsgSU91aVNsaWRlck9wdGlvbnMsIE91aVNsaWRlckNvbXBvbmVudCB9IGZyb20gJ29yYml0YWwtdWkvc2xpZGVyJztcbmltcG9ydCB7IElPdWlEcmFnTW92ZSwgT3VpRHJhZ2dhYmxlRGlyZWN0aXZlIH0gZnJvbSAnb3JiaXRhbC11aS9kcmFnZ2FibGUnO1xuaW1wb3J0IHsgZGVib3VuY2UsIGlzTmlsIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IE1hcCB9IGZyb20gJ29sJztcbmltcG9ydCB7IE9wZW5sYXllcnNDb21wb25lbnQgfSBmcm9tICcuLi9vcGVubGF5ZXJzLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBPcGVubGF5ZXJzU2lkZUJ5U2lkZU9wdGlvbnMsIE91aUxvbkxhdEJvdW5kcyB9IGZyb20gJy4uL3R5cGVzJztcbmludGVyZmFjZSBJRHJhZ1Bvc2l0aW9uIHtcbiAgeDogbnVtYmVyO1xuICB5OiBudW1iZXI7XG59XG5cbmV4cG9ydCB0eXBlIENsaXBDb29yZGluYXRlcyA9IFtcbiAgW251bWJlciwgbnVtYmVyXSxcbiAgW251bWJlciwgbnVtYmVyXSxcbiAgW251bWJlciwgbnVtYmVyXSxcbiAgW251bWJlciwgbnVtYmVyXSxcbl07IC8vIEJvdHRvbSBsZWZ0IGNsb2Nrd2lzZVxuZXhwb3J0IGludGVyZmFjZSBJQ2xpcENoYW5nZSB7XG4gIGxlZnQ6IENsaXBDb29yZGluYXRlcztcbiAgcmlnaHQ6IENsaXBDb29yZGluYXRlcztcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLW9wZW5sYXllcnMtc2lkZS1ieS1zaWRlJyxcbiAgdGVtcGxhdGVVcmw6ICcuL29wZW5sYXllcnMtc2lkZS1ieS1zaWRlLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vb3BlbmxheWVycy1zaWRlLWJ5LXNpZGUuY29tcG9uZW50LnNjc3MnXSxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW1xuICAgIE91aUljb25Db21wb25lbnQsXG4gICAgQ29tbW9uTW9kdWxlLFxuICAgIE91aVNsaWRlckNvbXBvbmVudCxcbiAgICBPdWlEcmFnZ2FibGVEaXJlY3RpdmUsXG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIE9wZW5sYXllcnNTaWRlQnlTaWRlQ29tcG9uZW50IGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95IHtcbiAgcHVibGljIGxlZnRMYWJlbFRlbXBsYXRlID0gaW5wdXQ8VGVtcGxhdGVSZWY8YW55Pj4oKTtcbiAgcHVibGljIHJpZ2h0TGFiZWxUZW1wbGF0ZSA9IGlucHV0PFRlbXBsYXRlUmVmPGFueT4+KCk7XG4gIHB1YmxpYyBtYXBDb250YWluZXIgPSBpbnB1dC5yZXF1aXJlZDxFbGVtZW50UmVmPigpO1xuICBwdWJsaWMgbWFwID0gaW5wdXQucmVxdWlyZWQ8T3BlbmxheWVyc0NvbXBvbmVudD4oKTtcbiAgcHVibGljIG9wdGlvbnMgPSBpbnB1dC5yZXF1aXJlZDxPcGVubGF5ZXJzU2lkZUJ5U2lkZU9wdGlvbnM+KCk7XG5cbiAgQE91dHB1dCgpIGNsaXBDaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyPElDbGlwQ2hhbmdlPigpO1xuICBAT3V0cHV0KCkgZHJhZ2dlZCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiAgQE91dHB1dCgpIGNsaWNrZWQgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gIEBPdXRwdXQoKSByZWxlYXNlZCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICBAVmlld0NoaWxkKCdkcmFnQ29udGFpbmVyJykgcHJpdmF0ZSBkcmFnQ29udGFpbmVyOiBFbGVtZW50UmVmO1xuICBAVmlld0NoaWxkKCdkcmFnJykgcHJpdmF0ZSBkcmFnOiBFbGVtZW50UmVmO1xuICBAVmlld0NoaWxkKCdpbWFnZUxhYmVsUmlnaHQnKSBwcml2YXRlIGltYWdlTGFiZWxSaWdodDogRWxlbWVudFJlZjtcbiAgQFZpZXdDaGlsZCgnaW1hZ2VMYWJlbExlZnQnKSBwcml2YXRlIGltYWdlTGFiZWxMZWZ0OiBFbGVtZW50UmVmO1xuICBAVmlld0NoaWxkKCd0aHVtYkljb25UZW1wbGF0ZScpIHRodW1iSWNvblRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xuICBAVmlld0NoaWxkKCdtYXBDb250ZW50JykgbWFwQ29udGVudDogRWxlbWVudFJlZjtcbiAgQFZpZXdDaGlsZCgnZHJhZ2dhYmxlJykgZHJhZ2dhYmxlOiBPdWlEcmFnZ2FibGVEaXJlY3RpdmU7XG4gIEBWaWV3Q2hpbGQoJ21hcHNXcmFwcGVyJykgbWFwc1dyYXBwZXI6IEVsZW1lbnRSZWY7XG4gIEBWaWV3Q2hpbGQoJ2dhbW1hTWFza1JpZ2h0JykgZ2FtbWFNYXNrUmlnaHQ6IEVsZW1lbnRSZWY7XG4gIEBWaWV3Q2hpbGQoJ2dhbW1hTWFza0xlZnQnKSBnYW1tYU1hc2tMZWZ0OiBFbGVtZW50UmVmO1xuXG4gIHByaXZhdGUgY3VycmVudERyYWdQb3NpdGlvbiA9IHNpZ25hbDxJRHJhZ1Bvc2l0aW9uPih7XG4gICAgeDogMCxcbiAgICB5OiAwLFxuICB9KTtcbiAgcHJpdmF0ZSByZXNpemVPYnNlcnZlcjogUmVzaXplT2JzZXJ2ZXI7XG4gIHByaXZhdGUgZHJhZ0xlZnRSYXRpbyA9IHNpZ25hbCgwKTtcbiAgcHJpdmF0ZSBkcmFnTGVmdFJhdGlvV2l0aERyYWdXaWR0aE9mZnNldCA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICByZXR1cm4gKFxuICAgICAgdGhpcy5kcmFnTGVmdFJhdGlvKCkgK1xuICAgICAgdGhpcy5nZXREcmFnQ29udGFpbmVyV2lkdGhPZmZzZXQoKSAvIHRoaXMuZ2V0TWFwQ29udGFpbmVyV2lkdGgoKVxuICAgICk7XG4gIH0pO1xuICBwcml2YXRlIGlzSW5pdGlhbGlzYXRpb25TdGFydGVkID0gc2lnbmFsKGZhbHNlKTtcbiAgcHJpdmF0ZSByZWZyZXNoSW50ZXJ2YWw6IGFueTtcbiAgcHJpdmF0ZSBkZWJvdW5jZWRFbmRDbGlwID0gZGVib3VuY2UodGhpcy5nZXRDbGlwQW5kRW1pdC5iaW5kKHRoaXMpLCA1MCk7XG5cbiAgcHJpdmF0ZSB1bmxpc3RlbmVyczogKCgpID0+IHZvaWQpW10gPSBbXTtcbiAgcHJpdmF0ZSBtYXBMaXN0ZW5lcnM6IHtcbiAgICBbZXZlbnROYW1lOiBzdHJpbmddOiAoZXZlbnQ6IGFueSkgPT4gdm9pZDtcbiAgfSA9IHtcbiAgICBtb3Zlc3RhcnQ6IHRoaXMuc3RhcnRDbGlwcGluZy5iaW5kKHRoaXMpLFxuICAgIG1vdmU6IHRoaXMuc3RvcmVCb3VuZHMuYmluZCh0aGlzKSxcbiAgICBtb3ZlZW5kOiB0aGlzLmVuZENsaXBwaW5nLmJpbmQodGhpcyksXG4gIH07XG4gIHB1YmxpYyBpc0luaXRpYWxpc2VkID0gc2lnbmFsKGZhbHNlKTtcbiAgcHVibGljIGlzVmVydGljYWwgPSBzaWduYWwodHJ1ZSk7XG4gIHB1YmxpYyBiZWZvcmVHYW1tYSA9IHNpZ25hbCgxKTtcbiAgcHVibGljIGFmdGVyR2FtbWEgPSBzaWduYWwoMSk7XG4gIHB1YmxpYyBnYW1tYVNsaWRlck9wdGlvbnMgPSBzaWduYWw8SU91aVNsaWRlck9wdGlvbnM+KHtcbiAgICBtaW46IDAuMDEsXG4gICAgbWF4OiAyLFxuICAgIG1pbkxhYmVsOiAnJyxcbiAgICBtYXhMYWJlbDogJycsXG4gIH0pO1xuICBwdWJsaWMgY3VycmVudEJvdW5kcyA9IHNpZ25hbDxPdWlMb25MYXRCb3VuZHMgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgcmVuZGVyZXI6IFJlbmRlcmVyMixcbiAgICBwcml2YXRlIGRlc3Ryb3lSZWY6IERlc3Ryb3lSZWYsXG4gICAgcHJpdmF0ZSBlbGVtZW50UmVmOiBFbGVtZW50UmVmLFxuICAgIEBJbmplY3QoRE9DVU1FTlQpIHByaXZhdGUgZG9jdW1lbnQ6IERvY3VtZW50XG4gICkge1xuICAgIGNvbnN0IHVubG9hZCA9IGVmZmVjdChcbiAgICAgICgpID0+IHtcbiAgICAgICAgaWYgKHRoaXMubWFwKCkgJiYgIXRoaXMuaXNJbml0aWFsaXNhdGlvblN0YXJ0ZWQoKSAmJiB0aGlzLm1hcENvbnRlbnQpIHtcbiAgICAgICAgICB0aGlzLnN1YnNjcmliZVRvTWFwTG9hZCgpO1xuICAgICAgICAgIHVubG9hZC5kZXN0cm95KCk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIGFsbG93U2lnbmFsV3JpdGVzOiB0cnVlLFxuICAgICAgfVxuICAgICk7XG4gIH1cblxuICBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgZnJvbUV2ZW50KHRoaXMuZG9jdW1lbnQuYm9keSwgJ2tleWRvd24nKVxuICAgICAgLnBpcGUodGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZikpXG4gICAgICAuc3Vic2NyaWJlKChldmVudDogYW55KSA9PiB7XG4gICAgICAgIGlmIChldmVudC5jb2RlID09PSAnS2V5WicgJiYgdGhpcy5vcHRpb25zKCkuZW5hYmxlZEV2ZW50cz8ubW92ZVNsaWRlcikge1xuICAgICAgICAgIHRoaXMuZHJhZ2dhYmxlLnVwZGF0ZVRyYW5zZm9ybSh7XG4gICAgICAgICAgICB4OiAwLFxuICAgICAgICAgICAgeTogMCxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgICBldmVudC5jb2RlID09PSAnS2V5WCcgJiZcbiAgICAgICAgICB0aGlzLm9wdGlvbnMoKS5lbmFibGVkRXZlbnRzPy5tb3ZlU2xpZGVyXG4gICAgICAgICkge1xuICAgICAgICAgIHRoaXMuZHJhZ2dhYmxlLnVwZGF0ZVRyYW5zZm9ybSh7XG4gICAgICAgICAgICB4OlxuICAgICAgICAgICAgICB0aGlzLmdldE1hcENvbnRhaW5lcldpZHRoKCkgLVxuICAgICAgICAgICAgICB0aGlzLmdldERyYWdDb250YWluZXJXaWR0aE9mZnNldCgpICogMixcbiAgICAgICAgICAgIHk6IDAsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgICAgZXZlbnQuY29kZSA9PT0gJ0tleUEnICYmXG4gICAgICAgICAgdGhpcy5vcHRpb25zKCkuZW5hYmxlZEV2ZW50cz8uem9vbUluT3V0XG4gICAgICAgICkge1xuICAgICAgICAgIGNvbnN0IG1hcCA9IHRoaXMubWFwKCk/LnN0YXRlPy5tYXAoKTtcbiAgICAgICAgICBjb25zdCBjdXJyZW50Wm9vbSA9IG1hcD8uZ2V0VmlldygpPy5nZXRab29tKCk7XG4gICAgICAgICAgaWYgKG1hcCAmJiAhaXNOaWwoY3VycmVudFpvb20pKSB7XG4gICAgICAgICAgICBtYXAuZ2V0VmlldygpLmFuaW1hdGUoe1xuICAgICAgICAgICAgICB6b29tOiBjdXJyZW50Wm9vbSArIDAuMjUsXG4gICAgICAgICAgICAgIGR1cmF0aW9uOiAyNTAsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgICAgZXZlbnQuY29kZSA9PT0gJ0tleVMnICYmXG4gICAgICAgICAgdGhpcy5vcHRpb25zKCkuZW5hYmxlZEV2ZW50cz8uem9vbUluT3V0XG4gICAgICAgICkge1xuICAgICAgICAgIGNvbnN0IG1hcCA9IHRoaXMubWFwKCk/LnN0YXRlPy5tYXAoKTtcbiAgICAgICAgICBjb25zdCBjdXJyZW50Wm9vbSA9IG1hcD8uZ2V0VmlldygpPy5nZXRab29tKCk7XG4gICAgICAgICAgaWYgKG1hcCAmJiAhaXNOaWwoY3VycmVudFpvb20pKSB7XG4gICAgICAgICAgICBtYXAuZ2V0VmlldygpLmFuaW1hdGUoe1xuICAgICAgICAgICAgICB6b29tOiBNYXRoLm1heChjdXJyZW50Wm9vbSAtIDAuMjUsIDApLFxuICAgICAgICAgICAgICBkdXJhdGlvbjogMjUwLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgIHRoaXMuZ2FtbWFTbGlkZXJPcHRpb25zLnNldCh7XG4gICAgICBtaW46IDAuMDEsXG4gICAgICBtYXg6IDIsXG4gICAgICBtaW5MYWJlbDogJycsXG4gICAgICBtYXhMYWJlbDogJycsXG4gICAgICB0aHVtYkNvbnRlbnRUZW1wbGF0ZTogdGhpcy50aHVtYkljb25UZW1wbGF0ZSxcbiAgICB9KTtcblxuICAgIGlmICh0aGlzLm1hcCgpKSB7XG4gICAgICBpZiAoIXRoaXMuaXNJbml0aWFsaXNhdGlvblN0YXJ0ZWQpIHtcbiAgICAgICAgdGhpcy5zdWJzY3JpYmVUb01hcExvYWQoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGluaXREcmFnZ2FibGUoKSB7XG4gICAgdGhpcy5kcmFnZ2FibGUuYWRkRGVmYXVsdEJlaGF2aW9yKCk7XG4gICAgdGhpcy5kcmFnZ2FibGUuYWRkQ29udGFpbmVyQ29uc3RyYWludCh7XG4gICAgICBjb250YWluZXI6IHRoaXMubWFwc1dyYXBwZXIubmF0aXZlRWxlbWVudCxcbiAgICAgIGFuY2hvcjogJ2VkZ2UnLFxuICAgIH0pO1xuICAgIHRoaXMuY3VycmVudERyYWdQb3NpdGlvbi5zZXQoe1xuICAgICAgeDogdGhpcy5nZXRNYXBDb250YWluZXJXaWR0aCgpIC8gMiAtIHRoaXMuZ2V0RHJhZ0NvbnRhaW5lcldpZHRoT2Zmc2V0KCksXG4gICAgICB5OiAwLFxuICAgIH0pO1xuICAgIHRoaXMuZHJhZ2dhYmxlLnVwZGF0ZVRyYW5zZm9ybSh0aGlzLmN1cnJlbnREcmFnUG9zaXRpb24oKSk7XG4gICAgdGhpcy5kcmFnTGVmdFJhdGlvLnNldChcbiAgICAgIHRoaXMuY3VycmVudERyYWdQb3NpdGlvbigpLnggLyB0aGlzLmdldE1hcENvbnRhaW5lcldpZHRoKClcbiAgICApO1xuICB9XG5cbiAgcHJpdmF0ZSBzdWJzY3JpYmVUb01hcExvYWQoKSB7XG4gICAgdGhpcy5pc0luaXRpYWxpc2F0aW9uU3RhcnRlZC5zZXQodHJ1ZSk7XG4gICAgY29uc3QgbWFwID0gdGhpcy5tYXAoKTtcbiAgICBpZiAoIW1hcCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBtYXAub25Mb2FkJFxuICAgICAgLnBpcGUodGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZiksIHRha2UoMSkpXG4gICAgICAuc3Vic2NyaWJlKCgpID0+IHtcbiAgICAgICAgdGhpcy5pbml0aWFsaXNlQ29tcG9uZW50KCk7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIHRoaXMuaXNJbml0aWFsaXNlZC5zZXQodHJ1ZSk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGluaXRpYWxpc2VDb21wb25lbnQoKSB7XG4gICAgdGhpcy5tYXBDb250ZW50Lm5hdGl2ZUVsZW1lbnQuc3R5bGUuZmlsdGVyID0gYHVybCgnI2dhbW1hRmlsdGVyJylgO1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGhpcy5pbml0RHJhZ2dhYmxlKCk7XG4gICAgICB0aGlzLmluaXRpYWxpemVFdmVudExpc3RlbmVycygpO1xuICAgIH0pO1xuICAgIHRoaXMuaW5pdGlhbGl6ZVJlc2l6ZU9ic2VydmVyKCk7XG4gIH1cblxuICBwcml2YXRlIGdldE1hcENvbnRhaW5lcldpZHRoKCkge1xuICAgIHJldHVybiB0aGlzLm1hcENvbnRhaW5lcigpLm5hdGl2ZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGg7XG4gIH1cblxuICBwcml2YXRlIGdldE1hcENvbnRhaW5lckhlaWdodCgpIHtcbiAgICByZXR1cm4gdGhpcy5tYXBDb250YWluZXIoKS5uYXRpdmVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodDtcbiAgfVxuXG4gIHByaXZhdGUgZ2V0RHJhZ1dpZHRoT2Zmc2V0KCkge1xuICAgIHJldHVybiB0aGlzLmRyYWcubmF0aXZlRWxlbWVudC5vZmZzZXRXaWR0aCAvIDI7XG4gIH1cblxuICBwcml2YXRlIGdldERyYWdIZWlnaHRPZmZzZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZHJhZy5uYXRpdmVFbGVtZW50Lm9mZnNldEhlaWdodCAvIDI7XG4gIH1cblxuICBwcml2YXRlIGdldERyYWdDb250YWluZXJXaWR0aE9mZnNldCgpIHtcbiAgICByZXR1cm4gdGhpcy5kcmFnQ29udGFpbmVyLm5hdGl2ZUVsZW1lbnQub2Zmc2V0V2lkdGggLyAyO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXREcmFnQ29udGFpbmVySGVpZ2h0T2Zmc2V0KCkge1xuICAgIHJldHVybiB0aGlzLmRyYWdDb250YWluZXIubmF0aXZlRWxlbWVudC5vZmZzZXRIZWlnaHQgLyAyO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRDbGlwKCk6IElDbGlwQ2hhbmdlIHwgdW5kZWZpbmVkIHtcbiAgICBjb25zdCBtYXAgPSB0aGlzLm1hcCgpO1xuICAgIGNvbnN0IGFjdHVhbE1hcDogTWFwIHwgdW5kZWZpbmVkID0gbWFwPy5zdGF0ZT8ubWFwKCk7XG4gICAgaWYgKCFhY3R1YWxNYXAgfHwgIW1hcCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoIXRoaXMuY3VycmVudEJvdW5kcygpKSB7XG4gICAgICB0aGlzLmN1cnJlbnRCb3VuZHMuc2V0KG1hcC5nZXRCb3VuZHMoKSk7XG4gICAgfVxuICAgIGNvbnN0IGJvdW5kcyA9IHRoaXMuY3VycmVudEJvdW5kcygpO1xuICAgIGlmICghYm91bmRzKSB7XG4gICAgICB0aHJvdyAnQ291bGQgbm90IGdldCBib3VuZHMgZnJvbSBtYXAnO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgbGVmdDogW1xuICAgICAgICBbMCwgMF0sXG4gICAgICAgIFswLCAxXSxcbiAgICAgICAgW3RoaXMuZHJhZ0xlZnRSYXRpb1dpdGhEcmFnV2lkdGhPZmZzZXQoKSwgMV0sXG4gICAgICAgIFt0aGlzLmRyYWdMZWZ0UmF0aW9XaXRoRHJhZ1dpZHRoT2Zmc2V0KCksIDBdLFxuICAgICAgXSxcbiAgICAgIHJpZ2h0OiBbXG4gICAgICAgIFt0aGlzLmRyYWdMZWZ0UmF0aW9XaXRoRHJhZ1dpZHRoT2Zmc2V0KCksIDBdLFxuICAgICAgICBbdGhpcy5kcmFnTGVmdFJhdGlvV2l0aERyYWdXaWR0aE9mZnNldCgpLCAxXSxcbiAgICAgICAgWzEsIDFdLFxuICAgICAgICBbMSwgMF0sXG4gICAgICBdLFxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIGluaXRpYWxpemVFdmVudExpc3RlbmVycygpIHtcbiAgICBjb25zdCBtYXAgPSB0aGlzLm1hcCgpO1xuICAgIGNvbnN0IGFjdHVhbE1hcCA9IHRoaXMubWFwKCk/LnN0YXRlPy5tYXAoKTtcbiAgICBpZiAoIWFjdHVhbE1hcCB8fCAhbWFwKSB7XG4gICAgICB0aHJvdyAnTWFwIG5vdCBpbml0aWFsaXplZCwgZmFpbGVkIHRvIGluaXRpYWxpemUgZXZlbnQgbGlzdGVuZXJzJztcbiAgICB9XG4gICAgdGhpcy5jdXJyZW50Qm91bmRzLnNldChtYXAuZ2V0Qm91bmRzKCkpO1xuICAgIGFjdHVhbE1hcC5vbignbW92ZXN0YXJ0JyBhcyBhbnksIHRoaXMubWFwTGlzdGVuZXJzWydtb3Zlc3RhcnQnXSk7XG5cbiAgICBhY3R1YWxNYXAub24oJ21vdmVlbmQnIGFzIGFueSwgdGhpcy5tYXBMaXN0ZW5lcnNbJ21vdmVlbmQnXSk7XG4gICAgYWN0dWFsTWFwLmdldFZpZXcoKS5vbignY2hhbmdlOmNlbnRlcicgYXMgYW55LCB0aGlzLm1hcExpc3RlbmVyc1snbW92ZSddKTtcbiAgfVxuXG4gIHByaXZhdGUgc3RvcmVCb3VuZHMoZXZlbnQ6IGFueSkge1xuICAgIHRoaXMuY3VycmVudEJvdW5kcy5zZXQodGhpcy5tYXAoKT8uZ2V0Qm91bmRzKCkpO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRDbGlwQW5kRW1pdCgpIHtcbiAgICBjb25zdCBjbGlwID0gdGhpcy5nZXRDbGlwKCk7XG4gICAgaWYgKGNsaXApIHtcbiAgICAgIHRoaXMubWFwKCkuY2xpcExheWVycyhjbGlwKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgb25EcmFnTW92ZShldmVudDogSU91aURyYWdNb3ZlKSB7XG4gICAgaWYgKCdjdXJyZW50VHJhbnNsYXRlJyBpbiBldmVudCkge1xuICAgICAgY29uc3Qgd3JhcHBlckJib3ggPVxuICAgICAgICB0aGlzLm1hcHNXcmFwcGVyLm5hdGl2ZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICBjb25zdCB3aWR0aCA9IHdyYXBwZXJCYm94LndpZHRoO1xuICAgICAgY29uc3QgbGVmdFdpZHRoID1cbiAgICAgICAgKChldmVudC5jdXJyZW50VHJhbnNsYXRlLnggKyB0aGlzLmdldERyYWdDb250YWluZXJXaWR0aE9mZnNldCgpKSAvXG4gICAgICAgICAgd2lkdGgpICpcbiAgICAgICAgMTAwO1xuICAgICAgY29uc3QgcmlnaHRXaWR0aCA9IDEwMCAtIGxlZnRXaWR0aDtcbiAgICAgIGNvbnN0IHJpZ2h0TGVmdCA9XG4gICAgICAgIGV2ZW50LmN1cnJlbnRUcmFuc2xhdGUueCArIHRoaXMuZ2V0RHJhZ0NvbnRhaW5lcldpZHRoT2Zmc2V0KCk7XG4gICAgICB0aGlzLnJlbmRlcmVyLnNldEF0dHJpYnV0ZShcbiAgICAgICAgdGhpcy5nYW1tYU1hc2tMZWZ0Lm5hdGl2ZUVsZW1lbnQsXG4gICAgICAgICd3aWR0aCcsXG4gICAgICAgIGAke2xlZnRXaWR0aH0lYFxuICAgICAgKTtcbiAgICAgIHRoaXMucmVuZGVyZXIuc2V0QXR0cmlidXRlKFxuICAgICAgICB0aGlzLmdhbW1hTWFza1JpZ2h0Lm5hdGl2ZUVsZW1lbnQsXG4gICAgICAgICd3aWR0aCcsXG4gICAgICAgIGAke3JpZ2h0V2lkdGh9JWBcbiAgICAgICk7XG4gICAgICB0aGlzLnJlbmRlcmVyLnNldEF0dHJpYnV0ZShcbiAgICAgICAgdGhpcy5nYW1tYU1hc2tSaWdodC5uYXRpdmVFbGVtZW50LFxuICAgICAgICAneCcsXG4gICAgICAgIGAkeyhyaWdodExlZnQgLyB3aWR0aCkgKiAxMDB9JWBcbiAgICAgICk7XG4gICAgICB0aGlzLmNsaXBDaGFuZ2UuZW1pdCh0aGlzLmdldENsaXAoKSk7XG4gICAgICB0aGlzLmN1cnJlbnREcmFnUG9zaXRpb24uc2V0KHtcbiAgICAgICAgeDogZXZlbnQuY3VycmVudFRyYW5zbGF0ZS54LFxuICAgICAgICB5OiBldmVudC5jdXJyZW50VHJhbnNsYXRlLnksXG4gICAgICB9KTtcbiAgICAgIHRoaXMuZHJhZ0xlZnRSYXRpby5zZXQoXG4gICAgICAgIHRoaXMuY3VycmVudERyYWdQb3NpdGlvbigpLnggLyB0aGlzLmdldE1hcENvbnRhaW5lcldpZHRoKClcbiAgICAgICk7XG4gICAgICB0aGlzLmdldENsaXBBbmRFbWl0KCk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG9uRHJhZ0VuZCgpIHtcbiAgICB0aGlzLmRlYm91bmNlZEVuZENsaXAoKTtcbiAgfVxuXG4gIHByaXZhdGUgc2V0TGVmdExhYmVsUG9zaXRpb24oKSB7XG4gICAgaWYgKCF0aGlzLmltYWdlTGFiZWxMZWZ0KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGxlZnQgPVxuICAgICAgdGhpcy5jdXJyZW50RHJhZ1Bvc2l0aW9uKCkueCAtXG4gICAgICB0aGlzLmltYWdlTGFiZWxMZWZ0Lm5hdGl2ZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGggK1xuICAgICAgdGhpcy5nZXREcmFnQ29udGFpbmVyV2lkdGhPZmZzZXQoKSAtXG4gICAgICB0aGlzLmdldERyYWdXaWR0aE9mZnNldCgpO1xuICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUoXG4gICAgICB0aGlzLmltYWdlTGFiZWxMZWZ0Lm5hdGl2ZUVsZW1lbnQsXG4gICAgICAndHJhbnNmb3JtJyxcbiAgICAgIGB0cmFuc2xhdGUoJHtsZWZ0fXB4LCAkezB9cHgpYFxuICAgICk7XG4gIH1cblxuICBwcml2YXRlIHJlc2l6ZVNpZGVCeVNpZGUoKSB7XG4gICAgY29uc3QgbWFwQ29udGFpbmVyV2lkdGggPSB0aGlzLmdldE1hcENvbnRhaW5lcldpZHRoKCk7XG4gICAgbGV0IG5ld0xlZnQgPSBtYXBDb250YWluZXJXaWR0aCAqIHRoaXMuZHJhZ0xlZnRSYXRpbygpO1xuICAgIGNvbnN0IGxlZnRFZGdlID0gdGhpcy5nZXREcmFnQ29udGFpbmVyV2lkdGhPZmZzZXQoKTtcbiAgICBjb25zdCByaWdodEVkZ2UgPSBtYXBDb250YWluZXJXaWR0aCAtIHRoaXMuZ2V0RHJhZ0NvbnRhaW5lcldpZHRoT2Zmc2V0KCk7XG4gICAgaWYgKG5ld0xlZnQgPCBsZWZ0RWRnZSkge1xuICAgICAgbmV3TGVmdCA9IGxlZnRFZGdlO1xuICAgIH0gZWxzZSBpZiAobmV3TGVmdCA+IHJpZ2h0RWRnZSkge1xuICAgICAgbmV3TGVmdCA9IHJpZ2h0RWRnZTtcbiAgICB9XG4gICAgdGhpcy5jdXJyZW50RHJhZ1Bvc2l0aW9uLnNldCh7XG4gICAgICB4OiBuZXdMZWZ0LFxuICAgICAgeTogdGhpcy5jdXJyZW50RHJhZ1Bvc2l0aW9uKCkueSxcbiAgICB9KTtcbiAgICB0aGlzLmRyYWdnYWJsZS51cGRhdGVUcmFuc2Zvcm0odGhpcy5jdXJyZW50RHJhZ1Bvc2l0aW9uKCkpO1xuICAgIHRoaXMuY2xpcENoYW5nZS5lbWl0KHRoaXMuZ2V0Q2xpcCgpKTtcbiAgfVxuXG4gIHByaXZhdGUgaW5pdGlhbGl6ZVJlc2l6ZU9ic2VydmVyKCkge1xuICAgIHRoaXMucmVzaXplT2JzZXJ2ZXIgPSBuZXcgUmVzaXplT2JzZXJ2ZXIoKCkgPT4ge1xuICAgICAgdGhpcy5yZXNpemVTaWRlQnlTaWRlKCk7XG4gICAgfSk7XG5cbiAgICB0aGlzLnJlc2l6ZU9ic2VydmVyLm9ic2VydmUodGhpcy5tYXBDb250YWluZXIoKS5uYXRpdmVFbGVtZW50KTtcbiAgfVxuXG4gIHByaXZhdGUgc3RhcnRDbGlwcGluZygpIHtcbiAgICBpZiAodGhpcy5yZWZyZXNoSW50ZXJ2YWwpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5yZWZyZXNoSW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICB0aGlzLmNsaXBDaGFuZ2UuZW1pdCh0aGlzLmdldENsaXAoKSk7XG4gICAgfSwgMjApO1xuICB9XG5cbiAgcHJpdmF0ZSBlbmRDbGlwcGluZygpIHtcbiAgICBpZiAodGhpcy5yZWZyZXNoSW50ZXJ2YWwpIHtcbiAgICAgIGNsZWFySW50ZXJ2YWwodGhpcy5yZWZyZXNoSW50ZXJ2YWwpO1xuICAgICAgdGhpcy5yZWZyZXNoSW50ZXJ2YWwgPSB1bmRlZmluZWQ7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdGhpcy5jbGlwQ2hhbmdlLmVtaXQodGhpcy5nZXRDbGlwKCkpO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG9uQmVmb3JlR2FtbWFDaGFuZ2UodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuYmVmb3JlR2FtbWEuc2V0KHZhbHVlKTtcblxuICAgIGNvbnN0IGZpbHRlcnMgPSB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yQWxsKFxuICAgICAgJy5iZWZvcmVHYW1tYUVsZW1lbnQnXG4gICAgKTtcbiAgICBmb3IgKGNvbnN0IGZpbHRlciBvZiBmaWx0ZXJzKSB7XG4gICAgICBmaWx0ZXIuc2V0QXR0cmlidXRlKCdhbXBsaXR1ZGUnLCBgJHt2YWx1ZX1gKTtcbiAgICAgIGZpbHRlci5zZXRBdHRyaWJ1dGUoJ2V4cG9uZW50JywgYCR7MSAvIHZhbHVlfWApO1xuICAgICAgLy8gZmlsdGVyLnNldEF0dHJpYnV0ZSgnb2Zmc2V0JywgYCR7KHZhbHVlIC0gMSkgLyA1fWApO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBvbkFmdGVyR2FtbWFDaGFuZ2UodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuYWZ0ZXJHYW1tYS5zZXQodmFsdWUpO1xuXG4gICAgY29uc3QgZmlsdGVycyA9XG4gICAgICB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuYWZ0ZXJHYW1tYUVsZW1lbnQnKTtcbiAgICBmb3IgKGNvbnN0IGZpbHRlciBvZiBmaWx0ZXJzKSB7XG4gICAgICAvLyBmaWx0ZXIuc2V0QXR0cmlidXRlKCdhbXBsaXR1ZGUnLCBgJHt2YWx1ZX1gKTtcbiAgICAgIGZpbHRlci5zZXRBdHRyaWJ1dGUoJ2V4cG9uZW50JywgYCR7MSAvIHZhbHVlfWApO1xuICAgICAgLy8gZmlsdGVyLnNldEF0dHJpYnV0ZSgnb2Zmc2V0JywgYCR7KHZhbHVlIC0gMSkgLyA1fWApO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBuZ09uRGVzdHJveSgpIHtcbiAgICBmb3IgKGNvbnN0IHVubGlzdGVuZXIgb2YgdGhpcy51bmxpc3RlbmVycykge1xuICAgICAgdW5saXN0ZW5lcigpO1xuICAgIH1cbiAgICBpZiAodGhpcy5yZXNpemVPYnNlcnZlcikge1xuICAgICAgdGhpcy5yZXNpemVPYnNlcnZlci51bm9ic2VydmUodGhpcy5tYXBDb250YWluZXIoKS5uYXRpdmVFbGVtZW50KTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5yZWZyZXNoSW50ZXJ2YWwpIHtcbiAgICAgIGNsZWFySW50ZXJ2YWwodGhpcy5yZWZyZXNoSW50ZXJ2YWwpO1xuICAgIH1cbiAgICBjb25zdCBhY3R1YWxNYXAgPSB0aGlzLm1hcCgpPy5zdGF0ZT8ubWFwKCk7XG4gICAgaWYgKGFjdHVhbE1hcCkge1xuICAgICAgZm9yIChsZXQgbGlzdGVuZXIgaW4gdGhpcy5tYXBMaXN0ZW5lcnMpIHtcbiAgICAgICAgYWN0dWFsTWFwLnVuKGxpc3RlbmVyIGFzIGFueSwgdGhpcy5tYXBMaXN0ZW5lcnNbbGlzdGVuZXJdKTtcbiAgICAgICAgYWN0dWFsTWFwLmdldFZpZXcoKS51bihsaXN0ZW5lciBhcyBhbnksIHRoaXMubWFwTGlzdGVuZXJzW2xpc3RlbmVyXSk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwic2lkZS1ieS1zaWRlLXdyYXBwZXJcIiBbbmdDbGFzc109XCJ7J2luaXRpYWxpc2VkJzogaXNJbml0aWFsaXNlZCgpfVwiPlxuICA8ZGl2IGNsYXNzPVwibWFwcy13cmFwcGVyXCIgI21hcHNXcmFwcGVyPlxuICAgIDxkaXZcbiAgICAgICAgb3VpLWRyYWdnYWJsZVxuICAgICAgICAoZHJhZ01vdmUpPVwib25EcmFnTW92ZSgkZXZlbnQpXCJcbiAgICAgICAgKGRyYWdFbmQpPVwib25EcmFnRW5kKClcIlxuICAgICAgICAjZHJhZ2dhYmxlPVwiT3VpRHJhZ2dhYmxlRGlyZWN0aXZlXCJcbiAgICAgICAgY2xhc3M9XCJkcmFnLWNvbnRhaW5lclwiXG4gICAgICAgICNkcmFnQ29udGFpbmVyXG4gICAgICAgIFtuZ0NsYXNzXT1cInsgdmVydGljYWw6IGlzVmVydGljYWwoKSwgaG9yaXpvbnRhbDogIWlzVmVydGljYWwoKSB9XCJcbiAgICA+XG4gICAgICA8ZGl2IGNsYXNzPVwiZHJhZyBzaGFkb3dcIiAjZHJhZz48L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3M9XCJkcmFnLWNhcmV0LWNvbnRhaW5lclwiPlxuICAgICAgICA8b3VpLWljb25cbiAgICAgICAgICAgIGljb249XCJhc3NldHMvaWNvbnMvY2FyZXQtbGVmdC5zdmdcIlxuICAgICAgICAgICAgW29wdGlvbnNdPVwie1xuICAgICAgICAgIHN0cm9rZUNvbG9yOiAnb3VpLW1hcGJveC1zaWRlLWJ5LXNpZGUtaWNvbi1jb2xvcicsXG4gICAgICAgICAgZmlsbENvbG9yOiAnb3VpLW1hcGJveC1zaWRlLWJ5LXNpZGUtaWNvbi1jb2xvcicsXG4gICAgICAgICAgdmlld0JveDogJzAgMCA0OCA0OCdcbiAgICAgICAgfVwiXG4gICAgICAgICAgICBjbGFzcz1cImRyYWctY2FyZXQtbGVmdFwiXG4gICAgICAgID48L291aS1pY29uPlxuICAgICAgICA8b3VpLWljb25cbiAgICAgICAgICAgIGljb249XCJhc3NldHMvaWNvbnMvY2FyZXQtcmlnaHQuc3ZnXCJcbiAgICAgICAgICAgIFtvcHRpb25zXT1cIntcbiAgICAgICAgICBzdHJva2VDb2xvcjogJ291aS1tYXBib3gtc2lkZS1ieS1zaWRlLWljb24tY29sb3InLFxuICAgICAgICAgIGZpbGxDb2xvcjogJ291aS1tYXBib3gtc2lkZS1ieS1zaWRlLWljb24tY29sb3InLFxuICAgICAgICAgIHZpZXdCb3g6ICcwIDAgNDggNDgnXG4gICAgICAgIH1cIlxuICAgICAgICAgICAgY2xhc3M9XCJkcmFnLWNhcmV0LXJpZ2h0XCJcbiAgICAgICAgPjwvb3VpLWljb24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwibWFwLWNvbnRlbnRcIiAjbWFwQ29udGVudD5cbiAgICAgIDxzdmcgY2xhc3M9XCJnYW1tYS1tYXNrLXN2Z1wiPlxuICAgICAgICA8ZmlsdGVyIGlkPVwiZ2FtbWFGaWx0ZXJcIiBwcmltaXRpdmVVbml0cz1cIm9iamVjdEJvdW5kaW5nQm94XCIgd2lkdGg9XCIxMDAlXCIgaGVpZ2h0PVwiMTAwJVwiIHg9XCIwXCIgeT1cIjBcIj5cbiAgICAgICAgICA8ZmVDb2xvck1hdHJpeCByZXN1bHQ9XCJDVVJSRU5UXCI+PC9mZUNvbG9yTWF0cml4PlxuICAgICAgICAgIDxmZUNvbXBvbmVudFRyYW5zZmVyICNnYW1tYU1hc2tMZWZ0IHJlc3VsdD1cIkxFRlRcIiB4PVwiMCVcIiB3aWR0aD1cIjUwJVwiIGhlaWdodD1cIjEwMCVcIiB5PVwiMCVcIj5cbiAgICAgICAgICAgIDxmZUZ1bmNSXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJiZWZvcmVHYW1tYUVsZW1lbnRcIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJnYW1tYVwiXG4gICAgICAgICAgICAgICAgYW1wbGl0dWRlPVwiMFwiXG4gICAgICAgICAgICAgICAgZXhwb25lbnQ9XCIxXCJcbiAgICAgICAgICAgICAgICBvZmZzZXQ9XCIwXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8ZmVGdW5jR1xuICAgICAgICAgICAgICAgIGNsYXNzPVwiYmVmb3JlR2FtbWFFbGVtZW50XCJcbiAgICAgICAgICAgICAgICB0eXBlPVwiZ2FtbWFcIlxuICAgICAgICAgICAgICAgIGFtcGxpdHVkZT1cIjBcIlxuICAgICAgICAgICAgICAgIGV4cG9uZW50PVwiMVwiXG4gICAgICAgICAgICAgICAgb2Zmc2V0PVwiMFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGZlRnVuY0JcbiAgICAgICAgICAgICAgICBjbGFzcz1cImJlZm9yZUdhbW1hRWxlbWVudFwiXG4gICAgICAgICAgICAgICAgdHlwZT1cImdhbW1hXCJcbiAgICAgICAgICAgICAgICBhbXBsaXR1ZGU9XCIwXCJcbiAgICAgICAgICAgICAgICBleHBvbmVudD1cIjFcIlxuICAgICAgICAgICAgICAgIG9mZnNldD1cIjBcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2ZlQ29tcG9uZW50VHJhbnNmZXI+XG4gICAgICAgICAgPGZlQ29tcG9zaXRlIGluMj1cIkNVUlJFTlRcIiBpbj1cIkxFRlRcIiBvcGVyYXRvcj1cIm92ZXJcIiByZXN1bHQ9XCJDVVJSRU5UXCI+PC9mZUNvbXBvc2l0ZT5cbiAgICAgICAgICA8ZmVDb21wb25lbnRUcmFuc2ZlciAjZ2FtbWFNYXNrUmlnaHQgcmVzdWx0PVwiUklHSFRcIiB4PVwiNTAlXCIgd2lkdGg9XCI1MCVcIiBoZWlnaHQ9XCIxMDAlXCIgeT1cIjAlXCI+XG4gICAgICAgICAgICA8ZmVGdW5jUlxuICAgICAgICAgICAgICAgIGNsYXNzPVwiYWZ0ZXJHYW1tYUVsZW1lbnRcIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJnYW1tYVwiXG4gICAgICAgICAgICAgICAgYW1wbGl0dWRlPVwiMVwiXG4gICAgICAgICAgICAgICAgZXhwb25lbnQ9XCIwXCJcbiAgICAgICAgICAgICAgICBvZmZzZXQ9XCIwXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8ZmVGdW5jR1xuICAgICAgICAgICAgICAgIGNsYXNzPVwiYWZ0ZXJHYW1tYUVsZW1lbnRcIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJnYW1tYVwiXG4gICAgICAgICAgICAgICAgYW1wbGl0dWRlPVwiMVwiXG4gICAgICAgICAgICAgICAgZXhwb25lbnQ9XCIwXCJcbiAgICAgICAgICAgICAgICBvZmZzZXQ9XCIwXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8ZmVGdW5jQlxuICAgICAgICAgICAgICAgIGNsYXNzPVwiYWZ0ZXJHYW1tYUVsZW1lbnRcIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJnYW1tYVwiXG4gICAgICAgICAgICAgICAgYW1wbGl0dWRlPVwiMVwiXG4gICAgICAgICAgICAgICAgZXhwb25lbnQ9XCIwXCJcbiAgICAgICAgICAgICAgICBvZmZzZXQ9XCIwXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9mZUNvbXBvbmVudFRyYW5zZmVyPlxuXG4gICAgICAgICAgPGZlQ29tcG9zaXRlIGluMj1cIkNVUlJFTlRcIiBpbj1cIlJJR0hUXCIgb3BlcmF0b3I9XCJvdmVyXCIgcmVzdWx0PVwiQ09NUE9TSVRFXCI+XG5cbiAgICAgICAgICA8L2ZlQ29tcG9zaXRlPlxuPCEtLSAgICAgICAgICA8ZmVDb21wb3NpdGUgaW4yPVwiU291cmNlR3JhcGhpY1wiIGluPVwiRklSU1RfQ09NUE9TSVRFXCIgb3BlcmF0b3I9XCJvdmVyXCIgcmVzdWx0PVwiRklSU1RfQ09NQklORURfQ09NUE9TSVRFXCI+LS0+XG5cbjwhLS0gICAgICAgICAgPC9mZUNvbXBvc2l0ZT4tLT5cbjwhLS0gICAgICAgICAgPGZlQ29tcG9zaXRlIGluMj1cIkZJUlNUX0NPTUJJTkVEX0NPTVBPU0lURVwiIGluPVwiU0VDT05EXCIgb3BlcmF0b3I9XCJvdmVyXCIgcmVzdWx0PVwiU0VDT05EX0NPTVBPU0lURVwiPi0tPlxuXG48IS0tICAgICAgICAgIDwvZmVDb21wb3NpdGU+LS0+XG48IS0tICAgICAgICAgIDxmZUNvbXBvc2l0ZSBpbjI9XCJGSVJTVF9DT01CSU5FRF9DT01QT1NJVEVcIiBpbj1cIlNFQ09ORF9DT01QT1NJVEVcIiBvcGVyYXRvcj1cImluXCI+PC9mZUNvbXBvc2l0ZT4tLT5cbiAgICAgICAgPC9maWx0ZXI+XG4gICAgICA8L3N2Zz5cblxuICAgICAgPG5nLWNvbnRlbnQ+XG5cbiAgICAgIDwvbmctY29udGVudD5cbiAgICA8L2Rpdj5cblxuXG48IS0tICAgIDxkaXYgY2xhc3M9XCJzaWRlLWJ5LXNpZGUtbGFiZWwtd3JhcHBlciBsZWZ0XCIgKm5nSWY9XCJsZWZ0TGFiZWxUZW1wbGF0ZVwiPi0tPlxuPCEtLSAgICAgIDxuZy1jb250ZW50ICpuZ1RlbXBsYXRlT3V0bGV0PVwibGVmdExhYmVsVGVtcGxhdGVcIj48L25nLWNvbnRlbnQ+LS0+XG48IS0tICAgIDwvZGl2Pi0tPlxuXG48IS0tICAgIDxkaXYgY2xhc3M9XCJzaWRlLWJ5LXNpZGUtbGFiZWwtd3JhcHBlciByaWdodFwiIFtuZ0NsYXNzXT1cInsnaGFzLWdlb2xvY2F0ZSc6IG1hcD8ub3B0aW9ucz8uZ2VvTG9jYXRlQ29udHJvbH1cIiAqbmdJZj1cInJpZ2h0TGFiZWxUZW1wbGF0ZVwiPi0tPlxuPCEtLSAgICAgIDxuZy1jb250ZW50ICpuZ1RlbXBsYXRlT3V0bGV0PVwicmlnaHRMYWJlbFRlbXBsYXRlXCI+PC9uZy1jb250ZW50Pi0tPlxuPCEtLSAgICA8L2Rpdj4tLT5cblxuICA8L2Rpdj5cbiAgPGRpdiBjbGFzcz1cImdhbW1hLXNsaWRlci13cmFwcGVyXCI+XG4gICAgPGRpdiBjbGFzcz1cImdhbW1hLXNsaWRlciBsZWZ0XCI+XG4gICAgICA8b3VpLXNsaWRlciBbb3B0aW9uc109XCJnYW1tYVNsaWRlck9wdGlvbnMoKVwiIFt2YWx1ZV09XCJiZWZvcmVHYW1tYSgpXCIgKHZhbHVlQ2hhbmdlKT1cIm9uQmVmb3JlR2FtbWFDaGFuZ2UoJGV2ZW50KVwiXG4gICAgICA+PC9vdWktc2xpZGVyPlxuICAgIDwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJnYW1tYS1zbGlkZXIgcmlnaHRcIj5cbiAgICAgIDxvdWktc2xpZGVyXG4gICAgICAgICAgW29wdGlvbnNdPVwiZ2FtbWFTbGlkZXJPcHRpb25zKClcIlxuICAgICAgICAgIFt2YWx1ZV09XCJhZnRlckdhbW1hKClcIlxuICAgICAgICAgICh2YWx1ZUNoYW5nZSk9XCJvbkFmdGVyR2FtbWFDaGFuZ2UoJGV2ZW50KVwiXG4gICAgICA+PC9vdWktc2xpZGVyPlxuICAgIDwvZGl2PlxuXG4gICAgPG5nLXRlbXBsYXRlICN0aHVtYkljb25UZW1wbGF0ZT5cbiAgICAgIDxvdWktaWNvbiAgW2ljb25dPVwiJ2Fzc2V0cy9pY29ucy9icmlnaHRuZXNzLnN2ZydcIlxuICAgICAgICAgICAgICAgICBbb3B0aW9uc109XCJ7XG4gICAgdmlld0JveDogJzAgMCA0OCA0OCcsXG4gICAgc2l6ZTogJzEzcHgnLFxuICAgIGZpbGxDb2xvcjogJ2NvbG9yLWJhY2tncm91bmQtcHJpbWFyeS10ZXh0JyxcbiAgICBzdHJva2VDb2xvcjogJ2NvbG9yLWJhY2tncm91bmQtcHJpbWFyeS10ZXh0JyxcbiAgICB9XCI+XG5cbiAgICAgIDwvb3VpLWljb24+XG4gICAgPC9uZy10ZW1wbGF0ZT5cbiAgPC9kaXY+XG5cblxuPC9kaXY+XG4iXX0=