/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/editable-text-display" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-editable-text-display.d.ts.map