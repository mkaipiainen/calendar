import DeckViewport from '@deck.gl/core/typed';

declare module 'mapboxgljs-ellipsis' {
  export class EllipsisRasterLayer {
    constructor(props: any);
  }

  export class EllipsisVectorLayer {
    constructor(props: any);
  }
}

declare module '@deck.gl/core/typed' {
  export class Viewport extends DeckViewport {
    latitude: number;
    longitude: number;
    zoom: number;
    pitch: number;
    bearing: number;
  }
}

declare module '@luma.gl/shadertools/src/modules/image-adjust-filters/brightnesscontrast' {
  export const brightnessContrast: any;
}
declare module 'supercluster' {
  export default class Supercluster {
    constructor(props: any);
  }
}
