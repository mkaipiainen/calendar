import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Pipe to check if a value is null or undefined
 * @param value value to check
 */
export declare class IsNilPipe implements PipeTransform {
    transform(value: any): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<IsNilPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<IsNilPipe, "isNil", true>;
}
//# sourceMappingURL=is-nil.pipe.d.ts.map