/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/date-picker" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-date-picker.d.ts.map