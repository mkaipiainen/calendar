import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, } from '@angular/core';
import { NgClass } from '@angular/common';
import { isNil } from 'lodash-es';
import { OuiIconComponent } from 'orbital-ui/icon';
import * as i0 from "@angular/core";
/**
 * A component used to display checkboxes. Can either work as a simple boolean on/off switch, or as a way to selectively
 * add/remove values from an array. If the passed in model is an array, then when turned on, the value of the checkbox will be
 * added to the array/vice versa. If the pasesd in model is a boolean, then checkbox functions as a on/off switch.
 *
 * Example-usage:
 *
 * Boolean mode:
 *
 * <oui-checkbox [(model)]="isEnabled">Check this if you want the item to be enabled</oui-checkbox>
 *
 * Array mode:
 *
 * <oui-checkbox [(model)]="selectedItems" value="'first_item'">First item</oui-checkbox>
 * <oui-checkbox [(model)]="selectedItems" value="'second_item'">Second item</oui-checkbox>
 * <oui-checkbox [(model)]="selectedItems" value="'third_item'">Third item</oui-checkbox>
 */
export class OuiCheckboxComponent {
    cdr;
    /**
     *  either a boolean or an array. If an array is given, then the value of the checkbox will either be
     *  removed or added to the model when checked/unchecked.
     */
    model = false;
    /**
     * if model is an array, then this value will be added to the array if checkbox is checked.
     * If using boolean mode, then this field is ignored.
     */
    value;
    /**
     * whether or not a faint 'ghost'-checkmark should appear on the checkbox.
     */
    ghostSelect = false;
    /**
     * Used together with array-mode if passing in an array of objects. This is the key that will be used to figure out
     * whether a given checkbox is selected.
     */
    idKey;
    /**
     * emitted when model changes (with the current model)
     */
    modelChange = new EventEmitter();
    disabled = false;
    internalModel = false;
    constructor(cdr) {
        this.cdr = cdr;
    }
    ngAfterViewInit() {
        if (Array.isArray(this.model)) {
            this.internalModel = this.idKey
                ? this.model.findIndex(item => {
                    return item[this.idKey] === this.value[this.idKey];
                }) > -1
                : this.model.includes(this.value);
        }
        else {
            this.internalModel = this.model;
        }
    }
    emitChange(value) {
        this.internalModel = value;
        if (Array.isArray(this.model)) {
            if (this.internalModel) {
                this.model.push(this.value);
            }
            else {
                this.model.splice(this.model.indexOf(this.value), 1);
            }
        }
        else {
            this.model = value;
        }
        this.modelChange.emit(this.model);
        this.setIsChecked();
    }
    setIsChecked() {
        if (Array.isArray(this.model)) {
            this.internalModel = this.model.includes(this.value);
        }
        else {
            this.internalModel = this.model;
        }
        this.cdr.detectChanges();
    }
    ngOnChanges(changes) {
        if (!isNil(changes['model'])) {
            this.model = changes['model'].currentValue;
            this.setIsChecked();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCheckboxComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiCheckboxComponent, isStandalone: true, selector: "oui-checkbox", inputs: { model: "model", value: "value", ghostSelect: "ghostSelect", idKey: "idKey", disabled: "disabled" }, outputs: { modelChange: "modelChange" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"oui-checkbox-container\" [ngClass]=\"{ disabled: disabled }\">\n  <div class=\"checkbox-wrapper\" (click)=\"emitChange(!internalModel)\">\n    <div class=\"checkbox\">\n      <input [checked]=\"internalModel\" class=\"checkbox-input\" type=\"checkbox\" />\n      @if (internalModel) {\n        <div class=\"checkbox-icon\">\n          <oui-icon\n            [options]=\"{ size: '12px' }\"\n            icon=\"assets/icons/check.svg\"\n          ></oui-icon>\n        </div>\n      }\n      @if (ghostSelect) {\n        <div class=\"checkbox-icon ghost\">\n          <oui-icon\n            [options]=\"{ strokeColor: 'white', fillColor: 'grey', size: '12px' }\"\n            icon=\"assets/icons/check.svg\"\n          ></oui-icon>\n        </div>\n      }\n    </div>\n    <span class=\"checkbox-label\"><ng-content></ng-content></span>\n  </div>\n</div>\n", styles: [":host .oui-checkbox-container{display:flex}:host .oui-checkbox-container.disabled{pointer-events:none;opacity:.8}:host .oui-checkbox-container .checkbox-wrapper{display:flex;align-items:center}:host .oui-checkbox-container .checkbox-wrapper:hover{cursor:pointer}:host .oui-checkbox-container .checkbox-wrapper .checkbox-label{color:var(--oui-checkbox-text-color)}:host .oui-checkbox-container .checkbox-wrapper .checkbox{margin-right:10px;display:flex;justify-content:center;align-items:center;position:relative}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-icon{position:absolute;pointer-events:none;width:80%;height:80%;display:flex;justify-content:center;align-items:center}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-input{margin:0;appearance:none;border:1px solid var(--border-color-primary);background-color:var(--oui-checkbox-background-color);width:var(--oui-checkbox-size);height:var(--oui-checkbox-size);border-radius:3px;box-shadow:var(--box-shadow-bottom);outline:none;transition:background-color .3s}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-input:hover{cursor:pointer}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-input:checked{background-color:var(--oui-checkbox-check-color)}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-checkbox', standalone: true, imports: [NgClass, OuiIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"oui-checkbox-container\" [ngClass]=\"{ disabled: disabled }\">\n  <div class=\"checkbox-wrapper\" (click)=\"emitChange(!internalModel)\">\n    <div class=\"checkbox\">\n      <input [checked]=\"internalModel\" class=\"checkbox-input\" type=\"checkbox\" />\n      @if (internalModel) {\n        <div class=\"checkbox-icon\">\n          <oui-icon\n            [options]=\"{ size: '12px' }\"\n            icon=\"assets/icons/check.svg\"\n          ></oui-icon>\n        </div>\n      }\n      @if (ghostSelect) {\n        <div class=\"checkbox-icon ghost\">\n          <oui-icon\n            [options]=\"{ strokeColor: 'white', fillColor: 'grey', size: '12px' }\"\n            icon=\"assets/icons/check.svg\"\n          ></oui-icon>\n        </div>\n      }\n    </div>\n    <span class=\"checkbox-label\"><ng-content></ng-content></span>\n  </div>\n</div>\n", styles: [":host .oui-checkbox-container{display:flex}:host .oui-checkbox-container.disabled{pointer-events:none;opacity:.8}:host .oui-checkbox-container .checkbox-wrapper{display:flex;align-items:center}:host .oui-checkbox-container .checkbox-wrapper:hover{cursor:pointer}:host .oui-checkbox-container .checkbox-wrapper .checkbox-label{color:var(--oui-checkbox-text-color)}:host .oui-checkbox-container .checkbox-wrapper .checkbox{margin-right:10px;display:flex;justify-content:center;align-items:center;position:relative}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-icon{position:absolute;pointer-events:none;width:80%;height:80%;display:flex;justify-content:center;align-items:center}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-input{margin:0;appearance:none;border:1px solid var(--border-color-primary);background-color:var(--oui-checkbox-background-color);width:var(--oui-checkbox-size);height:var(--oui-checkbox-size);border-radius:3px;box-shadow:var(--box-shadow-bottom);outline:none;transition:background-color .3s}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-input:hover{cursor:pointer}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-input:checked{background-color:var(--oui-checkbox-check-color)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { model: [{
                type: Input
            }], value: [{
                type: Input
            }], ghostSelect: [{
                type: Input
            }], idKey: [{
                type: Input
            }], modelChange: [{
                type: Output
            }], disabled: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hlY2tib3guY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9jaGVja2JveC9jaGVja2JveC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL2NoZWNrYm94L2NoZWNrYm94LmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFFTCx1QkFBdUIsRUFFdkIsU0FBUyxFQUNULFlBQVksRUFDWixLQUFLLEVBRUwsTUFBTSxHQUVQLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMxQyxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sV0FBVyxDQUFDO0FBQ2xDLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLGlCQUFpQixDQUFDOztBQUVuRDs7Ozs7Ozs7Ozs7Ozs7OztHQWdCRztBQVNILE1BQU0sT0FBTyxvQkFBb0I7SUFpQ1g7SUFoQ3BCOzs7T0FHRztJQUNNLEtBQUssR0FBUSxLQUFLLENBQUM7SUFFNUI7OztPQUdHO0lBQ00sS0FBSyxDQUFNO0lBQ3BCOztPQUVHO0lBQ00sV0FBVyxHQUFHLEtBQUssQ0FBQztJQUU3Qjs7O09BR0c7SUFDTSxLQUFLLENBQVM7SUFFdkI7O09BRUc7SUFFSCxXQUFXLEdBQUcsSUFBSSxZQUFZLEVBQU8sQ0FBQztJQUU3QixRQUFRLEdBQUcsS0FBSyxDQUFDO0lBRW5CLGFBQWEsR0FBRyxLQUFLLENBQUM7SUFFN0IsWUFBb0IsR0FBc0I7UUFBdEIsUUFBRyxHQUFILEdBQUcsQ0FBbUI7SUFBRyxDQUFDO0lBRXZDLGVBQWU7UUFDcEIsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQzlCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLEtBQUs7Z0JBQzdCLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDMUIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNyRCxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ1QsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN0QyxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUNsQyxDQUFDO0lBQ0gsQ0FBQztJQUVNLFVBQVUsQ0FBQyxLQUFVO1FBQzFCLElBQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFDO1FBRTNCLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUM5QixJQUFJLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztnQkFDdkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzlCLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDdkQsQ0FBQztRQUNILENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDckIsQ0FBQztRQUNELElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNsQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDdEIsQ0FBQztJQUVPLFlBQVk7UUFDbEIsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQzlCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZELENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ2xDLENBQUM7UUFDRCxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFTSxXQUFXLENBQUMsT0FBc0I7UUFDdkMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQzdCLElBQUksQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLFlBQVksQ0FBQztZQUMzQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDdEIsQ0FBQztJQUNILENBQUM7dUdBN0VVLG9CQUFvQjsyRkFBcEIsb0JBQW9CLG9QQ3hDakMsczJCQXdCQSxpMENEYVksT0FBTyxvRkFBRSxnQkFBZ0I7OzJGQUd4QixvQkFBb0I7a0JBUmhDLFNBQVM7K0JBQ0UsY0FBYyxjQUdaLElBQUksV0FDUCxDQUFDLE9BQU8sRUFBRSxnQkFBZ0IsQ0FBQyxtQkFDbkIsdUJBQXVCLENBQUMsTUFBTTtzRkFPdEMsS0FBSztzQkFBYixLQUFLO2dCQU1HLEtBQUs7c0JBQWIsS0FBSztnQkFJRyxXQUFXO3NCQUFuQixLQUFLO2dCQU1HLEtBQUs7c0JBQWIsS0FBSztnQkFNTixXQUFXO3NCQURWLE1BQU07Z0JBR0UsUUFBUTtzQkFBaEIsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFmdGVyVmlld0luaXQsXG4gIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LFxuICBDaGFuZ2VEZXRlY3RvclJlZixcbiAgQ29tcG9uZW50LFxuICBFdmVudEVtaXR0ZXIsXG4gIElucHV0LFxuICBPbkNoYW5nZXMsXG4gIE91dHB1dCxcbiAgU2ltcGxlQ2hhbmdlcyxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOZ0NsYXNzIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IGlzTmlsIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IE91aUljb25Db21wb25lbnQgfSBmcm9tICdvcmJpdGFsLXVpL2ljb24nO1xuXG4vKipcbiAqIEEgY29tcG9uZW50IHVzZWQgdG8gZGlzcGxheSBjaGVja2JveGVzLiBDYW4gZWl0aGVyIHdvcmsgYXMgYSBzaW1wbGUgYm9vbGVhbiBvbi9vZmYgc3dpdGNoLCBvciBhcyBhIHdheSB0byBzZWxlY3RpdmVseVxuICogYWRkL3JlbW92ZSB2YWx1ZXMgZnJvbSBhbiBhcnJheS4gSWYgdGhlIHBhc3NlZCBpbiBtb2RlbCBpcyBhbiBhcnJheSwgdGhlbiB3aGVuIHR1cm5lZCBvbiwgdGhlIHZhbHVlIG9mIHRoZSBjaGVja2JveCB3aWxsIGJlXG4gKiBhZGRlZCB0byB0aGUgYXJyYXkvdmljZSB2ZXJzYS4gSWYgdGhlIHBhc2VzZCBpbiBtb2RlbCBpcyBhIGJvb2xlYW4sIHRoZW4gY2hlY2tib3ggZnVuY3Rpb25zIGFzIGEgb24vb2ZmIHN3aXRjaC5cbiAqXG4gKiBFeGFtcGxlLXVzYWdlOlxuICpcbiAqIEJvb2xlYW4gbW9kZTpcbiAqXG4gKiA8b3VpLWNoZWNrYm94IFsobW9kZWwpXT1cImlzRW5hYmxlZFwiPkNoZWNrIHRoaXMgaWYgeW91IHdhbnQgdGhlIGl0ZW0gdG8gYmUgZW5hYmxlZDwvb3VpLWNoZWNrYm94PlxuICpcbiAqIEFycmF5IG1vZGU6XG4gKlxuICogPG91aS1jaGVja2JveCBbKG1vZGVsKV09XCJzZWxlY3RlZEl0ZW1zXCIgdmFsdWU9XCInZmlyc3RfaXRlbSdcIj5GaXJzdCBpdGVtPC9vdWktY2hlY2tib3g+XG4gKiA8b3VpLWNoZWNrYm94IFsobW9kZWwpXT1cInNlbGVjdGVkSXRlbXNcIiB2YWx1ZT1cIidzZWNvbmRfaXRlbSdcIj5TZWNvbmQgaXRlbTwvb3VpLWNoZWNrYm94PlxuICogPG91aS1jaGVja2JveCBbKG1vZGVsKV09XCJzZWxlY3RlZEl0ZW1zXCIgdmFsdWU9XCIndGhpcmRfaXRlbSdcIj5UaGlyZCBpdGVtPC9vdWktY2hlY2tib3g+XG4gKi9cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1jaGVja2JveCcsXG4gIHRlbXBsYXRlVXJsOiAnLi9jaGVja2JveC5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL2NoZWNrYm94LmNvbXBvbmVudC5zY3NzJ10sXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtOZ0NsYXNzLCBPdWlJY29uQ29tcG9uZW50XSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIE91aUNoZWNrYm94Q29tcG9uZW50IGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCwgT25DaGFuZ2VzIHtcbiAgLyoqXG4gICAqICBlaXRoZXIgYSBib29sZWFuIG9yIGFuIGFycmF5LiBJZiBhbiBhcnJheSBpcyBnaXZlbiwgdGhlbiB0aGUgdmFsdWUgb2YgdGhlIGNoZWNrYm94IHdpbGwgZWl0aGVyIGJlXG4gICAqICByZW1vdmVkIG9yIGFkZGVkIHRvIHRoZSBtb2RlbCB3aGVuIGNoZWNrZWQvdW5jaGVja2VkLlxuICAgKi9cbiAgQElucHV0KCkgbW9kZWw6IGFueSA9IGZhbHNlO1xuXG4gIC8qKlxuICAgKiBpZiBtb2RlbCBpcyBhbiBhcnJheSwgdGhlbiB0aGlzIHZhbHVlIHdpbGwgYmUgYWRkZWQgdG8gdGhlIGFycmF5IGlmIGNoZWNrYm94IGlzIGNoZWNrZWQuXG4gICAqIElmIHVzaW5nIGJvb2xlYW4gbW9kZSwgdGhlbiB0aGlzIGZpZWxkIGlzIGlnbm9yZWQuXG4gICAqL1xuICBASW5wdXQoKSB2YWx1ZTogYW55O1xuICAvKipcbiAgICogd2hldGhlciBvciBub3QgYSBmYWludCAnZ2hvc3QnLWNoZWNrbWFyayBzaG91bGQgYXBwZWFyIG9uIHRoZSBjaGVja2JveC5cbiAgICovXG4gIEBJbnB1dCgpIGdob3N0U2VsZWN0ID0gZmFsc2U7XG5cbiAgLyoqXG4gICAqIFVzZWQgdG9nZXRoZXIgd2l0aCBhcnJheS1tb2RlIGlmIHBhc3NpbmcgaW4gYW4gYXJyYXkgb2Ygb2JqZWN0cy4gVGhpcyBpcyB0aGUga2V5IHRoYXQgd2lsbCBiZSB1c2VkIHRvIGZpZ3VyZSBvdXRcbiAgICogd2hldGhlciBhIGdpdmVuIGNoZWNrYm94IGlzIHNlbGVjdGVkLlxuICAgKi9cbiAgQElucHV0KCkgaWRLZXk6IHN0cmluZztcblxuICAvKipcbiAgICogZW1pdHRlZCB3aGVuIG1vZGVsIGNoYW5nZXMgKHdpdGggdGhlIGN1cnJlbnQgbW9kZWwpXG4gICAqL1xuICBAT3V0cHV0KClcbiAgbW9kZWxDaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyPGFueT4oKTtcblxuICBASW5wdXQoKSBkaXNhYmxlZCA9IGZhbHNlO1xuXG4gIHB1YmxpYyBpbnRlcm5hbE1vZGVsID0gZmFsc2U7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBjZHI6IENoYW5nZURldGVjdG9yUmVmKSB7fVxuXG4gIHB1YmxpYyBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodGhpcy5tb2RlbCkpIHtcbiAgICAgIHRoaXMuaW50ZXJuYWxNb2RlbCA9IHRoaXMuaWRLZXlcbiAgICAgICAgPyB0aGlzLm1vZGVsLmZpbmRJbmRleChpdGVtID0+IHtcbiAgICAgICAgICAgIHJldHVybiBpdGVtW3RoaXMuaWRLZXldID09PSB0aGlzLnZhbHVlW3RoaXMuaWRLZXldO1xuICAgICAgICAgIH0pID4gLTFcbiAgICAgICAgOiB0aGlzLm1vZGVsLmluY2x1ZGVzKHRoaXMudmFsdWUpO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmludGVybmFsTW9kZWwgPSB0aGlzLm1vZGVsO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBlbWl0Q2hhbmdlKHZhbHVlOiBhbnkpIHtcbiAgICB0aGlzLmludGVybmFsTW9kZWwgPSB2YWx1ZTtcblxuICAgIGlmIChBcnJheS5pc0FycmF5KHRoaXMubW9kZWwpKSB7XG4gICAgICBpZiAodGhpcy5pbnRlcm5hbE1vZGVsKSB7XG4gICAgICAgIHRoaXMubW9kZWwucHVzaCh0aGlzLnZhbHVlKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMubW9kZWwuc3BsaWNlKHRoaXMubW9kZWwuaW5kZXhPZih0aGlzLnZhbHVlKSwgMSk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMubW9kZWwgPSB2YWx1ZTtcbiAgICB9XG4gICAgdGhpcy5tb2RlbENoYW5nZS5lbWl0KHRoaXMubW9kZWwpO1xuICAgIHRoaXMuc2V0SXNDaGVja2VkKCk7XG4gIH1cblxuICBwcml2YXRlIHNldElzQ2hlY2tlZCgpIHtcbiAgICBpZiAoQXJyYXkuaXNBcnJheSh0aGlzLm1vZGVsKSkge1xuICAgICAgdGhpcy5pbnRlcm5hbE1vZGVsID0gdGhpcy5tb2RlbC5pbmNsdWRlcyh0aGlzLnZhbHVlKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5pbnRlcm5hbE1vZGVsID0gdGhpcy5tb2RlbDtcbiAgICB9XG4gICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xuICB9XG5cbiAgcHVibGljIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcbiAgICBpZiAoIWlzTmlsKGNoYW5nZXNbJ21vZGVsJ10pKSB7XG4gICAgICB0aGlzLm1vZGVsID0gY2hhbmdlc1snbW9kZWwnXS5jdXJyZW50VmFsdWU7XG4gICAgICB0aGlzLnNldElzQ2hlY2tlZCgpO1xuICAgIH1cbiAgfVxufVxuIiwiPGRpdiBjbGFzcz1cIm91aS1jaGVja2JveC1jb250YWluZXJcIiBbbmdDbGFzc109XCJ7IGRpc2FibGVkOiBkaXNhYmxlZCB9XCI+XG4gIDxkaXYgY2xhc3M9XCJjaGVja2JveC13cmFwcGVyXCIgKGNsaWNrKT1cImVtaXRDaGFuZ2UoIWludGVybmFsTW9kZWwpXCI+XG4gICAgPGRpdiBjbGFzcz1cImNoZWNrYm94XCI+XG4gICAgICA8aW5wdXQgW2NoZWNrZWRdPVwiaW50ZXJuYWxNb2RlbFwiIGNsYXNzPVwiY2hlY2tib3gtaW5wdXRcIiB0eXBlPVwiY2hlY2tib3hcIiAvPlxuICAgICAgQGlmIChpbnRlcm5hbE1vZGVsKSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjaGVja2JveC1pY29uXCI+XG4gICAgICAgICAgPG91aS1pY29uXG4gICAgICAgICAgICBbb3B0aW9uc109XCJ7IHNpemU6ICcxMnB4JyB9XCJcbiAgICAgICAgICAgIGljb249XCJhc3NldHMvaWNvbnMvY2hlY2suc3ZnXCJcbiAgICAgICAgICA+PC9vdWktaWNvbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICB9XG4gICAgICBAaWYgKGdob3N0U2VsZWN0KSB7XG4gICAgICAgIDxkaXYgY2xhc3M9XCJjaGVja2JveC1pY29uIGdob3N0XCI+XG4gICAgICAgICAgPG91aS1pY29uXG4gICAgICAgICAgICBbb3B0aW9uc109XCJ7IHN0cm9rZUNvbG9yOiAnd2hpdGUnLCBmaWxsQ29sb3I6ICdncmV5Jywgc2l6ZTogJzEycHgnIH1cIlxuICAgICAgICAgICAgaWNvbj1cImFzc2V0cy9pY29ucy9jaGVjay5zdmdcIlxuICAgICAgICAgID48L291aS1pY29uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIH1cbiAgICA8L2Rpdj5cbiAgICA8c3BhbiBjbGFzcz1cImNoZWNrYm94LWxhYmVsXCI+PG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50Pjwvc3Bhbj5cbiAgPC9kaXY+XG48L2Rpdj5cbiJdfQ==