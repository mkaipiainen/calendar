import { ChangeDetectionStrategy, Component, Input, signal, ViewChildren, } from '@angular/core';
import { JsonPipe, NgClass, NgStyle, NgTemplateOutlet } from '@angular/common';
import { OuiHoverDirective } from 'orbital-ui/hover';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i0 from "@angular/core";
export class OuiTableRowComponent {
    elementRef;
    destroyRef;
    cdr;
    columnRefs;
    item;
    options;
    tableService;
    isClickable = false;
    isLoaded = signal(false);
    columns = signal([]);
    constructor(elementRef, destroyRef, cdr) {
        this.elementRef = elementRef;
        this.destroyRef = destroyRef;
        this.cdr = cdr;
    }
    ngAfterViewInit() {
        this.isClickable = !!this.options.onItemClick;
        if (this.options.onItemClick) {
            this.elementRef.nativeElement.classList.add('clickable');
        }
        this.tableService.columns$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(columns => {
            this.columns.set(columns);
            setTimeout(() => {
                this.initColumnWidths();
                this.isLoaded.set(true);
            });
        });
    }
    trackById(index, column) {
        return column.id;
    }
    onItemClick(event) {
        if (this.options.onItemClick) {
            this.options.onItemClick(this.item, event);
        }
    }
    initColumnWidths() {
        for (const column of this.columns()) {
            const element = this.columnRefs.find(columnRef => {
                return columnRef.nativeElement.id === `row-${column.id}`;
            });
            if (!element) {
                continue;
            }
            if (column.flex) {
                element.nativeElement.style.flex = column.flex;
            }
            else {
                element.nativeElement.style.flex = '1';
            }
        }
    }
    ngOnChanges(changes) {
        if ('options' in changes) {
            this.options = changes['options'].currentValue;
            if (this.options.onItemClick) {
                this.elementRef.nativeElement.classList.add('clickable');
            }
            else {
                this.elementRef.nativeElement.classList.remove('clickable');
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTableRowComponent, deps: [{ token: i0.ElementRef }, { token: i0.DestroyRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiTableRowComponent, isStandalone: true, selector: "oui-table-row", inputs: { item: "item", options: "options", tableService: "tableService" }, viewQueries: [{ propertyName: "columnRefs", predicate: ["columnRef"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"table-row\" (click)=\"onItemClick($event)\" [ngClass]=\"{'is-loaded': isLoaded}\">\n  @for (column of columns(); track trackById($index, column)) {\n    <div #columnRef id=\"row-{{column.id}}\" class=\"item\" [ngStyle]=\"{overflow: column.overflow ?? 'auto'}\">\n      @if (!column.cellTemplate) {\n        <span [ngStyle]=\"{textOverflow: column.textOverflow ?? 'clip', overflow: column.overflow ?? 'auto'}\" class=\"body-cell\">{{item[column.valueKey]}}</span>\n      }\n      @if (column.cellTemplate) {\n        <ng-container\n          *ngTemplateOutlet=\"\n                    column.cellTemplate;\n                    context: { $implicit: item, item: item }\n                  \"\n        ></ng-container>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{flex:var(--oui-table-row-flex);display:flex;height:var(--oui-table-item-height);min-height:var(--oui-table-item-height);border-width:var(--oui-table-row-border-width-top) 0 var(--oui-table-row-border-width-bottom) 0;border-style:var(--oui-table-row-border-style);border-color:var(--oui-table-row-border-color);background-color:var(--oui-table-row-background-color);color:var(--oui-table-row-text-color);transition:background-color .3s;font-size:var(--oui-table-cell-font-size)}:host:hover{background-color:var(--oui-table-row-hover-background-color);color:var(--oui-table-row-hover-text-color)}:host .table-row{width:100%;display:flex;align-items:center;opacity:0;transition:opacity .3s}:host .table-row.is-loaded{opacity:1}:host .table-row .item{flex:1;padding:var(--oui-table-cell-padding);display:flex;align-items:center;justify-content:var(--oui-table-cell-alignment)}:host.cell-hovered{background-color:var(--oui-table-cell-hover-background-color);color:var(--oui-table-cell-hover-text-color)}:host.row-hovered{background-color:var(--oui-table-row-hover-background-color);color:var(--oui-table-row-hover-text-color)}:host.clickable{cursor:pointer}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTableRowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-table-row', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgTemplateOutlet, JsonPipe, OuiHoverDirective, NgClass, NgStyle], template: "<div class=\"table-row\" (click)=\"onItemClick($event)\" [ngClass]=\"{'is-loaded': isLoaded}\">\n  @for (column of columns(); track trackById($index, column)) {\n    <div #columnRef id=\"row-{{column.id}}\" class=\"item\" [ngStyle]=\"{overflow: column.overflow ?? 'auto'}\">\n      @if (!column.cellTemplate) {\n        <span [ngStyle]=\"{textOverflow: column.textOverflow ?? 'clip', overflow: column.overflow ?? 'auto'}\" class=\"body-cell\">{{item[column.valueKey]}}</span>\n      }\n      @if (column.cellTemplate) {\n        <ng-container\n          *ngTemplateOutlet=\"\n                    column.cellTemplate;\n                    context: { $implicit: item, item: item }\n                  \"\n        ></ng-container>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{flex:var(--oui-table-row-flex);display:flex;height:var(--oui-table-item-height);min-height:var(--oui-table-item-height);border-width:var(--oui-table-row-border-width-top) 0 var(--oui-table-row-border-width-bottom) 0;border-style:var(--oui-table-row-border-style);border-color:var(--oui-table-row-border-color);background-color:var(--oui-table-row-background-color);color:var(--oui-table-row-text-color);transition:background-color .3s;font-size:var(--oui-table-cell-font-size)}:host:hover{background-color:var(--oui-table-row-hover-background-color);color:var(--oui-table-row-hover-text-color)}:host .table-row{width:100%;display:flex;align-items:center;opacity:0;transition:opacity .3s}:host .table-row.is-loaded{opacity:1}:host .table-row .item{flex:1;padding:var(--oui-table-cell-padding);display:flex;align-items:center;justify-content:var(--oui-table-cell-alignment)}:host.cell-hovered{background-color:var(--oui-table-cell-hover-background-color);color:var(--oui-table-cell-hover-text-color)}:host.row-hovered{background-color:var(--oui-table-row-hover-background-color);color:var(--oui-table-row-hover-text-color)}:host.clickable{cursor:pointer}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.DestroyRef }, { type: i0.ChangeDetectorRef }], propDecorators: { columnRefs: [{
                type: ViewChildren,
                args: ['columnRef']
            }], item: [{
                type: Input,
                args: [{ required: true }]
            }], options: [{
                type: Input,
                args: [{ required: true }]
            }], tableService: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3VpLXRhYmxlLXJvdy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3RhYmxlL3RhYmxlLXJvdy9vdWktdGFibGUtcm93LmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvdGFibGUvdGFibGUtcm93L291aS10YWJsZS1yb3cuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUVMLHVCQUF1QixFQUV2QixTQUFTLEVBR1QsS0FBSyxFQUdMLE1BQU0sRUFFTixZQUFZLEdBQ2IsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFHL0UsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sa0JBQWtCLENBQUM7QUFDckQsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7O0FBVWhFLE1BQU0sT0FBTyxvQkFBb0I7SUFVckI7SUFDQTtJQUNBO0lBWGlCLFVBQVUsQ0FBd0I7SUFDbEMsSUFBSSxDQUFNO0lBQ1YsT0FBTyxDQUEyQjtJQUNsQyxZQUFZLENBQWU7SUFDL0MsV0FBVyxHQUFHLEtBQUssQ0FBQztJQUNwQixRQUFRLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3pCLE9BQU8sR0FBRyxNQUFNLENBQW9CLEVBQUUsQ0FBQyxDQUFDO0lBRS9DLFlBQ1UsVUFBc0IsRUFDdEIsVUFBc0IsRUFDdEIsR0FBc0I7UUFGdEIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtRQUN0QixlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQ3RCLFFBQUcsR0FBSCxHQUFHLENBQW1CO0lBQzdCLENBQUM7SUFFRyxlQUFlO1FBQ3BCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDO1FBQzlDLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUM3QixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQzNELENBQUM7UUFDRCxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVE7YUFDdkIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzthQUN6QyxTQUFTLENBQUMsT0FBTyxDQUFDLEVBQUU7WUFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDMUIsVUFBVSxDQUFDLEdBQUcsRUFBRTtnQkFDZCxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDeEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7WUFDMUIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTSxTQUFTLENBQUMsS0FBYSxFQUFFLE1BQXVCO1FBQ3JELE9BQU8sTUFBTSxDQUFDLEVBQUUsQ0FBQztJQUNuQixDQUFDO0lBRU0sV0FBVyxDQUFDLEtBQVk7UUFDN0IsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzdCLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDN0MsQ0FBQztJQUNILENBQUM7SUFFTyxnQkFBZ0I7UUFDdEIsS0FBSyxNQUFNLE1BQU0sSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQztZQUNwQyxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRTtnQkFDL0MsT0FBTyxTQUFTLENBQUMsYUFBYSxDQUFDLEVBQUUsS0FBSyxPQUFPLE1BQU0sQ0FBQyxFQUFFLEVBQUUsQ0FBQztZQUMzRCxDQUFDLENBQUMsQ0FBQztZQUNILElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDYixTQUFTO1lBQ1gsQ0FBQztZQUNELElBQUksTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNoQixPQUFPLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQztZQUNqRCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sT0FBTyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQztZQUN6QyxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFTSxXQUFXLENBQUMsT0FBc0I7UUFDdkMsSUFBSSxTQUFTLElBQUksT0FBTyxFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsWUFBWSxDQUFDO1lBQy9DLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUMzRCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztZQUM5RCxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7dUdBbEVVLG9CQUFvQjsyRkFBcEIsb0JBQW9CLHNRQzVCakMsNHZCQWlCQSxrc0NEU1ksZ0JBQWdCLG9KQUErQixPQUFPLG9GQUFFLE9BQU87OzJGQUU5RCxvQkFBb0I7a0JBUmhDLFNBQVM7K0JBQ0UsZUFBZSxjQUdiLElBQUksbUJBQ0MsdUJBQXVCLENBQUMsTUFBTSxXQUN0QyxDQUFDLGdCQUFnQixFQUFFLFFBQVEsRUFBRSxpQkFBaUIsRUFBRSxPQUFPLEVBQUUsT0FBTyxDQUFDO3dJQUcvQyxVQUFVO3NCQUFwQyxZQUFZO3VCQUFDLFdBQVc7Z0JBQ0UsSUFBSTtzQkFBOUIsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUU7Z0JBQ0UsT0FBTztzQkFBakMsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUU7Z0JBQ0UsWUFBWTtzQkFBdEMsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcbiAgQ2hhbmdlRGV0ZWN0b3JSZWYsXG4gIENvbXBvbmVudCxcbiAgRGVzdHJveVJlZixcbiAgRWxlbWVudFJlZixcbiAgSW5wdXQsXG4gIE9uQ2hhbmdlcyxcbiAgUXVlcnlMaXN0LFxuICBzaWduYWwsXG4gIFNpbXBsZUNoYW5nZXMsXG4gIFZpZXdDaGlsZHJlbixcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBKc29uUGlwZSwgTmdDbGFzcywgTmdTdHlsZSwgTmdUZW1wbGF0ZU91dGxldCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBJT3VpVGFibGVDb2x1bW4sIElPdWlUYWJsZUNvbWJpbmVkT3B0aW9ucyB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IFRhYmxlU2VydmljZSB9IGZyb20gJy4uL3RhYmxlLnNlcnZpY2UnO1xuaW1wb3J0IHsgT3VpSG92ZXJEaXJlY3RpdmUgfSBmcm9tICdvcmJpdGFsLXVpL2hvdmVyJztcbmltcG9ydCB7IHRha2VVbnRpbERlc3Ryb3llZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUvcnhqcy1pbnRlcm9wJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLXRhYmxlLXJvdycsXG4gIHRlbXBsYXRlVXJsOiAnLi9vdWktdGFibGUtcm93LmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vb3VpLXRhYmxlLXJvdy5jb21wb25lbnQuc2NzcyddLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcbiAgaW1wb3J0czogW05nVGVtcGxhdGVPdXRsZXQsIEpzb25QaXBlLCBPdWlIb3ZlckRpcmVjdGl2ZSwgTmdDbGFzcywgTmdTdHlsZV0sXG59KVxuZXhwb3J0IGNsYXNzIE91aVRhYmxlUm93Q29tcG9uZW50IGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCwgT25DaGFuZ2VzIHtcbiAgQFZpZXdDaGlsZHJlbignY29sdW1uUmVmJykgY29sdW1uUmVmczogUXVlcnlMaXN0PEVsZW1lbnRSZWY+O1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KSBpdGVtOiBhbnk7XG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pIG9wdGlvbnM6IElPdWlUYWJsZUNvbWJpbmVkT3B0aW9ucztcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSkgdGFibGVTZXJ2aWNlOiBUYWJsZVNlcnZpY2U7XG4gIHB1YmxpYyBpc0NsaWNrYWJsZSA9IGZhbHNlO1xuICBwdWJsaWMgaXNMb2FkZWQgPSBzaWduYWwoZmFsc2UpO1xuICBwdWJsaWMgY29sdW1ucyA9IHNpZ25hbDxJT3VpVGFibGVDb2x1bW5bXT4oW10pO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgZWxlbWVudFJlZjogRWxlbWVudFJlZixcbiAgICBwcml2YXRlIGRlc3Ryb3lSZWY6IERlc3Ryb3lSZWYsXG4gICAgcHJpdmF0ZSBjZHI6IENoYW5nZURldGVjdG9yUmVmXG4gICkge31cblxuICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCkge1xuICAgIHRoaXMuaXNDbGlja2FibGUgPSAhIXRoaXMub3B0aW9ucy5vbkl0ZW1DbGljaztcbiAgICBpZiAodGhpcy5vcHRpb25zLm9uSXRlbUNsaWNrKSB7XG4gICAgICB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5jbGFzc0xpc3QuYWRkKCdjbGlja2FibGUnKTtcbiAgICB9XG4gICAgdGhpcy50YWJsZVNlcnZpY2UuY29sdW1ucyRcbiAgICAgIC5waXBlKHRha2VVbnRpbERlc3Ryb3llZCh0aGlzLmRlc3Ryb3lSZWYpKVxuICAgICAgLnN1YnNjcmliZShjb2x1bW5zID0+IHtcbiAgICAgICAgdGhpcy5jb2x1bW5zLnNldChjb2x1bW5zKTtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgdGhpcy5pbml0Q29sdW1uV2lkdGhzKCk7XG4gICAgICAgICAgdGhpcy5pc0xvYWRlZC5zZXQodHJ1ZSk7XG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gIH1cblxuICBwdWJsaWMgdHJhY2tCeUlkKGluZGV4OiBudW1iZXIsIGNvbHVtbjogSU91aVRhYmxlQ29sdW1uKSB7XG4gICAgcmV0dXJuIGNvbHVtbi5pZDtcbiAgfVxuXG4gIHB1YmxpYyBvbkl0ZW1DbGljayhldmVudDogRXZlbnQpIHtcbiAgICBpZiAodGhpcy5vcHRpb25zLm9uSXRlbUNsaWNrKSB7XG4gICAgICB0aGlzLm9wdGlvbnMub25JdGVtQ2xpY2sodGhpcy5pdGVtLCBldmVudCk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBpbml0Q29sdW1uV2lkdGhzKCkge1xuICAgIGZvciAoY29uc3QgY29sdW1uIG9mIHRoaXMuY29sdW1ucygpKSB7XG4gICAgICBjb25zdCBlbGVtZW50ID0gdGhpcy5jb2x1bW5SZWZzLmZpbmQoY29sdW1uUmVmID0+IHtcbiAgICAgICAgcmV0dXJuIGNvbHVtblJlZi5uYXRpdmVFbGVtZW50LmlkID09PSBgcm93LSR7Y29sdW1uLmlkfWA7XG4gICAgICB9KTtcbiAgICAgIGlmICghZWxlbWVudCkge1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cbiAgICAgIGlmIChjb2x1bW4uZmxleCkge1xuICAgICAgICBlbGVtZW50Lm5hdGl2ZUVsZW1lbnQuc3R5bGUuZmxleCA9IGNvbHVtbi5mbGV4O1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZWxlbWVudC5uYXRpdmVFbGVtZW50LnN0eWxlLmZsZXggPSAnMSc7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpIHtcbiAgICBpZiAoJ29wdGlvbnMnIGluIGNoYW5nZXMpIHtcbiAgICAgIHRoaXMub3B0aW9ucyA9IGNoYW5nZXNbJ29wdGlvbnMnXS5jdXJyZW50VmFsdWU7XG4gICAgICBpZiAodGhpcy5vcHRpb25zLm9uSXRlbUNsaWNrKSB7XG4gICAgICAgIHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ2NsaWNrYWJsZScpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnY2xpY2thYmxlJyk7XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwidGFibGUtcm93XCIgKGNsaWNrKT1cIm9uSXRlbUNsaWNrKCRldmVudClcIiBbbmdDbGFzc109XCJ7J2lzLWxvYWRlZCc6IGlzTG9hZGVkfVwiPlxuICBAZm9yIChjb2x1bW4gb2YgY29sdW1ucygpOyB0cmFjayB0cmFja0J5SWQoJGluZGV4LCBjb2x1bW4pKSB7XG4gICAgPGRpdiAjY29sdW1uUmVmIGlkPVwicm93LXt7Y29sdW1uLmlkfX1cIiBjbGFzcz1cIml0ZW1cIiBbbmdTdHlsZV09XCJ7b3ZlcmZsb3c6IGNvbHVtbi5vdmVyZmxvdyA/PyAnYXV0byd9XCI+XG4gICAgICBAaWYgKCFjb2x1bW4uY2VsbFRlbXBsYXRlKSB7XG4gICAgICAgIDxzcGFuIFtuZ1N0eWxlXT1cInt0ZXh0T3ZlcmZsb3c6IGNvbHVtbi50ZXh0T3ZlcmZsb3cgPz8gJ2NsaXAnLCBvdmVyZmxvdzogY29sdW1uLm92ZXJmbG93ID8/ICdhdXRvJ31cIiBjbGFzcz1cImJvZHktY2VsbFwiPnt7aXRlbVtjb2x1bW4udmFsdWVLZXldfX08L3NwYW4+XG4gICAgICB9XG4gICAgICBAaWYgKGNvbHVtbi5jZWxsVGVtcGxhdGUpIHtcbiAgICAgICAgPG5nLWNvbnRhaW5lclxuICAgICAgICAgICpuZ1RlbXBsYXRlT3V0bGV0PVwiXG4gICAgICAgICAgICAgICAgICAgIGNvbHVtbi5jZWxsVGVtcGxhdGU7XG4gICAgICAgICAgICAgICAgICAgIGNvbnRleHQ6IHsgJGltcGxpY2l0OiBpdGVtLCBpdGVtOiBpdGVtIH1cbiAgICAgICAgICAgICAgICAgIFwiXG4gICAgICAgID48L25nLWNvbnRhaW5lcj5cbiAgICAgIH1cbiAgICA8L2Rpdj5cbiAgfVxuPC9kaXY+XG4iXX0=