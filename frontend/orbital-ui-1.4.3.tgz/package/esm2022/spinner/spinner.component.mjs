import { Component, Input, ViewChild, } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Can be used to add loading spinners. Control whether or not the spinner is visible with the *ngIf directive.
 */
export class OuiSpinnerComponent {
    svgElement;
    pathElement;
    spinnerContainer;
    /**
     *   Either a color defined in the COLORS-constant, or alternatively a css-variable
     */
    color = 'primary';
    /**
     *   The size of the spinner
     */
    size = '1.6rem';
    type = 'solid';
    constructor() { }
    ngAfterViewInit() {
        this.updateColor();
        this.updateSize();
    }
    updateColor() {
        let actualColor;
        const cssFillVariableColor = getComputedStyle(document.documentElement).getPropertyValue(`--${this.color}`);
        actualColor = cssFillVariableColor
            ? cssFillVariableColor
            : this.color;
        if (this.pathElement) {
            this.pathElement.nativeElement.style.stroke = actualColor;
        }
        if (this.svgElement) {
            this.svgElement.nativeElement.style.fill = actualColor;
        }
    }
    updateSize() {
        if (this.svgElement) {
            this.svgElement.nativeElement.style.width = this.size;
            this.svgElement.nativeElement.style.height = this.size;
        }
        if (this.pathElement) {
            this.pathElement.nativeElement.style.width = this.size;
            this.pathElement.nativeElement.style.height = this.size;
        }
        if (this.spinnerContainer) {
            this.spinnerContainer.nativeElement.style.width = this.size;
            this.spinnerContainer.nativeElement.style.height = this.size;
        }
    }
    ngOnChanges(changes) {
        if ('color' in changes) {
            this.color = changes['color'].currentValue;
            this.updateColor();
        }
        if ('size' in changes) {
            this.size = changes['size'].currentValue;
            this.updateSize();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSpinnerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiSpinnerComponent, isStandalone: true, selector: "oui-spinner", inputs: { color: "color", size: "size", type: "type" }, viewQueries: [{ propertyName: "svgElement", first: true, predicate: ["svgElement"], descendants: true }, { propertyName: "pathElement", first: true, predicate: ["pathElement"], descendants: true }, { propertyName: "spinnerContainer", first: true, predicate: ["spinnerContainer"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"oui-spinner-container\" #spinnerContainer>\n  @if (type === 'solid') {\n    <svg\n      #svgElement\n      xmlns=\"http://www.w3.org/2000/svg\"\n      xmlns:xlink=\"http://www.w3.org/1999/xlink\"\n      style=\"margin: auto; shape-rendering: auto\"\n      viewBox=\"0 0 100 100\"\n      preserveAspectRatio=\"xMidYMid\"\n      >\n      <circle\n        #pathElement\n        cx=\"50\"\n        cy=\"50\"\n        fill=\"none\"\n        stroke=\"#e15b64\"\n        stroke-width=\"6\"\n        r=\"40\"\n        stroke-dasharray=\"188.49555921538757 64.83185307179586\"\n        >\n        <animateTransform\n          attributeName=\"transform\"\n          type=\"rotate\"\n          repeatCount=\"indefinite\"\n          dur=\"1s\"\n          values=\"0 50 50;360 50 50\"\n          keyTimes=\"0;1\"\n        ></animateTransform>\n      </circle>\n    </svg>\n  }\n\n  @if (type === 'stroke') {\n    <svg\n      #svgElement\n      xmlns=\"http://www.w3.org/2000/svg\"\n      xmlns:xlink=\"http://www.w3.org/1999/xlink\"\n      style=\"shape-rendering: auto\"\n      viewBox=\"0 0 100 100\"\n      preserveAspectRatio=\"xMidYMid\"\n      >\n      <path #pathElement d=\"M10 50A40 40 0 0 0 90 50A40 42 0 0 1 10 50\">\n        <animateTransform\n          attributeName=\"transform\"\n          type=\"rotate\"\n          dur=\"1s\"\n          repeatCount=\"indefinite\"\n          keyTimes=\"0;1\"\n          values=\"0 50 51;360 50 51\"\n        ></animateTransform>\n      </path>\n    </svg>\n  }\n</div>\n", styles: [":host{z-index:1;display:flex;align-items:center;justify-content:center}:host .oui-spinner-container{display:flex;justify-content:center;align-items:center}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSpinnerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-spinner', standalone: true, imports: [], template: "<div class=\"oui-spinner-container\" #spinnerContainer>\n  @if (type === 'solid') {\n    <svg\n      #svgElement\n      xmlns=\"http://www.w3.org/2000/svg\"\n      xmlns:xlink=\"http://www.w3.org/1999/xlink\"\n      style=\"margin: auto; shape-rendering: auto\"\n      viewBox=\"0 0 100 100\"\n      preserveAspectRatio=\"xMidYMid\"\n      >\n      <circle\n        #pathElement\n        cx=\"50\"\n        cy=\"50\"\n        fill=\"none\"\n        stroke=\"#e15b64\"\n        stroke-width=\"6\"\n        r=\"40\"\n        stroke-dasharray=\"188.49555921538757 64.83185307179586\"\n        >\n        <animateTransform\n          attributeName=\"transform\"\n          type=\"rotate\"\n          repeatCount=\"indefinite\"\n          dur=\"1s\"\n          values=\"0 50 50;360 50 50\"\n          keyTimes=\"0;1\"\n        ></animateTransform>\n      </circle>\n    </svg>\n  }\n\n  @if (type === 'stroke') {\n    <svg\n      #svgElement\n      xmlns=\"http://www.w3.org/2000/svg\"\n      xmlns:xlink=\"http://www.w3.org/1999/xlink\"\n      style=\"shape-rendering: auto\"\n      viewBox=\"0 0 100 100\"\n      preserveAspectRatio=\"xMidYMid\"\n      >\n      <path #pathElement d=\"M10 50A40 40 0 0 0 90 50A40 42 0 0 1 10 50\">\n        <animateTransform\n          attributeName=\"transform\"\n          type=\"rotate\"\n          dur=\"1s\"\n          repeatCount=\"indefinite\"\n          keyTimes=\"0;1\"\n          values=\"0 50 51;360 50 51\"\n        ></animateTransform>\n      </path>\n    </svg>\n  }\n</div>\n", styles: [":host{z-index:1;display:flex;align-items:center;justify-content:center}:host .oui-spinner-container{display:flex;justify-content:center;align-items:center}\n"] }]
        }], ctorParameters: () => [], propDecorators: { svgElement: [{
                type: ViewChild,
                args: ['svgElement', { static: false }]
            }], pathElement: [{
                type: ViewChild,
                args: ['pathElement', { static: false }]
            }], spinnerContainer: [{
                type: ViewChild,
                args: ['spinnerContainer', { static: false }]
            }], color: [{
                type: Input
            }], size: [{
                type: Input
            }], type: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3Bpbm5lci5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3NwaW5uZXIvc3Bpbm5lci5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3NwaW5uZXIvc3Bpbm5lci5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBRUwsU0FBUyxFQUVULEtBQUssRUFHTCxTQUFTLEdBQ1YsTUFBTSxlQUFlLENBQUM7O0FBR3ZCOztHQUVHO0FBUUgsTUFBTSxPQUFPLG1CQUFtQjtJQUNjLFVBQVUsQ0FBYTtJQUN0QixXQUFXLENBQWE7SUFFckUsZ0JBQWdCLENBQWE7SUFFN0I7O09BRUc7SUFFSCxLQUFLLEdBQUcsU0FBUyxDQUFDO0lBRWxCOztPQUVHO0lBRUgsSUFBSSxHQUFHLFFBQVEsQ0FBQztJQUdoQixJQUFJLEdBQXVCLE9BQU8sQ0FBQztJQUVuQyxnQkFBZSxDQUFDO0lBRVQsZUFBZTtRQUNwQixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO0lBQ3BCLENBQUM7SUFFTyxXQUFXO1FBQ2pCLElBQUksV0FBbUIsQ0FBQztRQUN4QixNQUFNLG9CQUFvQixHQUFHLGdCQUFnQixDQUMzQyxRQUFRLENBQUMsZUFBZSxDQUN6QixDQUFDLGdCQUFnQixDQUFDLEtBQUssSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUM7UUFDdEMsV0FBVyxHQUFHLG9CQUFvQjtZQUNoQyxDQUFDLENBQUMsb0JBQW9CO1lBQ3RCLENBQUMsQ0FBRSxJQUFJLENBQUMsS0FBZ0IsQ0FBQztRQUMzQixJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNyQixJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLFdBQVcsQ0FBQztRQUM1RCxDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDcEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxXQUFXLENBQUM7UUFDekQsQ0FBQztJQUNILENBQUM7SUFFTyxVQUFVO1FBQ2hCLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztZQUN0RCxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDekQsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQztZQUN2RCxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDMUQsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7WUFDMUIsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7WUFDNUQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDL0QsQ0FBQztJQUNILENBQUM7SUFFTSxXQUFXLENBQUMsT0FBc0I7UUFDdkMsSUFBSSxPQUFPLElBQUksT0FBTyxFQUFFLENBQUM7WUFDdkIsSUFBSSxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsWUFBWSxDQUFDO1lBQzNDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUNyQixDQUFDO1FBQ0QsSUFBSSxNQUFNLElBQUksT0FBTyxFQUFFLENBQUM7WUFDdEIsSUFBSSxDQUFDLElBQUksR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsWUFBWSxDQUFDO1lBQ3pDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNwQixDQUFDO0lBQ0gsQ0FBQzt1R0FwRVUsbUJBQW1COzJGQUFuQixtQkFBbUIsa2NDckJoQyxrL0NBc0RBOzsyRkRqQ2EsbUJBQW1CO2tCQVAvQixTQUFTOytCQUNFLGFBQWEsY0FHWCxJQUFJLFdBQ1AsRUFBRTt3REFHaUMsVUFBVTtzQkFBckQsU0FBUzt1QkFBQyxZQUFZLEVBQUUsRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFO2dCQUNHLFdBQVc7c0JBQXZELFNBQVM7dUJBQUMsYUFBYSxFQUFFLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRTtnQkFFM0MsZ0JBQWdCO3NCQURmLFNBQVM7dUJBQUMsa0JBQWtCLEVBQUUsRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFO2dCQU9oRCxLQUFLO3NCQURKLEtBQUs7Z0JBT04sSUFBSTtzQkFESCxLQUFLO2dCQUlOLElBQUk7c0JBREgsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFmdGVyVmlld0luaXQsXG4gIENvbXBvbmVudCxcbiAgRWxlbWVudFJlZixcbiAgSW5wdXQsXG4gIE9uQ2hhbmdlcyxcbiAgU2ltcGxlQ2hhbmdlcyxcbiAgVmlld0NoaWxkLFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuXG4vKipcbiAqIENhbiBiZSB1c2VkIHRvIGFkZCBsb2FkaW5nIHNwaW5uZXJzLiBDb250cm9sIHdoZXRoZXIgb3Igbm90IHRoZSBzcGlubmVyIGlzIHZpc2libGUgd2l0aCB0aGUgKm5nSWYgZGlyZWN0aXZlLlxuICovXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdvdWktc3Bpbm5lcicsXG4gIHRlbXBsYXRlVXJsOiAnLi9zcGlubmVyLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vc3Bpbm5lci5jb21wb25lbnQuc2NzcyddLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbXSxcbn0pXG5leHBvcnQgY2xhc3MgT3VpU3Bpbm5lckNvbXBvbmVudCBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQsIE9uQ2hhbmdlcyB7XG4gIEBWaWV3Q2hpbGQoJ3N2Z0VsZW1lbnQnLCB7IHN0YXRpYzogZmFsc2UgfSkgc3ZnRWxlbWVudDogRWxlbWVudFJlZjtcbiAgQFZpZXdDaGlsZCgncGF0aEVsZW1lbnQnLCB7IHN0YXRpYzogZmFsc2UgfSkgcGF0aEVsZW1lbnQ6IEVsZW1lbnRSZWY7XG4gIEBWaWV3Q2hpbGQoJ3NwaW5uZXJDb250YWluZXInLCB7IHN0YXRpYzogZmFsc2UgfSlcbiAgc3Bpbm5lckNvbnRhaW5lcjogRWxlbWVudFJlZjtcblxuICAvKipcbiAgICogICBFaXRoZXIgYSBjb2xvciBkZWZpbmVkIGluIHRoZSBDT0xPUlMtY29uc3RhbnQsIG9yIGFsdGVybmF0aXZlbHkgYSBjc3MtdmFyaWFibGVcbiAgICovXG4gIEBJbnB1dCgpXG4gIGNvbG9yID0gJ3ByaW1hcnknO1xuXG4gIC8qKlxuICAgKiAgIFRoZSBzaXplIG9mIHRoZSBzcGlubmVyXG4gICAqL1xuICBASW5wdXQoKVxuICBzaXplID0gJzEuNnJlbSc7XG5cbiAgQElucHV0KClcbiAgdHlwZTogJ3N0cm9rZScgfCAnc29saWQnID0gJ3NvbGlkJztcblxuICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgcHVibGljIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICB0aGlzLnVwZGF0ZUNvbG9yKCk7XG4gICAgdGhpcy51cGRhdGVTaXplKCk7XG4gIH1cblxuICBwcml2YXRlIHVwZGF0ZUNvbG9yKCkge1xuICAgIGxldCBhY3R1YWxDb2xvcjogc3RyaW5nO1xuICAgIGNvbnN0IGNzc0ZpbGxWYXJpYWJsZUNvbG9yID0gZ2V0Q29tcHV0ZWRTdHlsZShcbiAgICAgIGRvY3VtZW50LmRvY3VtZW50RWxlbWVudFxuICAgICkuZ2V0UHJvcGVydHlWYWx1ZShgLS0ke3RoaXMuY29sb3J9YCk7XG4gICAgYWN0dWFsQ29sb3IgPSBjc3NGaWxsVmFyaWFibGVDb2xvclxuICAgICAgPyBjc3NGaWxsVmFyaWFibGVDb2xvclxuICAgICAgOiAodGhpcy5jb2xvciBhcyBzdHJpbmcpO1xuICAgIGlmICh0aGlzLnBhdGhFbGVtZW50KSB7XG4gICAgICB0aGlzLnBhdGhFbGVtZW50Lm5hdGl2ZUVsZW1lbnQuc3R5bGUuc3Ryb2tlID0gYWN0dWFsQ29sb3I7XG4gICAgfVxuICAgIGlmICh0aGlzLnN2Z0VsZW1lbnQpIHtcbiAgICAgIHRoaXMuc3ZnRWxlbWVudC5uYXRpdmVFbGVtZW50LnN0eWxlLmZpbGwgPSBhY3R1YWxDb2xvcjtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHVwZGF0ZVNpemUoKSB7XG4gICAgaWYgKHRoaXMuc3ZnRWxlbWVudCkge1xuICAgICAgdGhpcy5zdmdFbGVtZW50Lm5hdGl2ZUVsZW1lbnQuc3R5bGUud2lkdGggPSB0aGlzLnNpemU7XG4gICAgICB0aGlzLnN2Z0VsZW1lbnQubmF0aXZlRWxlbWVudC5zdHlsZS5oZWlnaHQgPSB0aGlzLnNpemU7XG4gICAgfVxuICAgIGlmICh0aGlzLnBhdGhFbGVtZW50KSB7XG4gICAgICB0aGlzLnBhdGhFbGVtZW50Lm5hdGl2ZUVsZW1lbnQuc3R5bGUud2lkdGggPSB0aGlzLnNpemU7XG4gICAgICB0aGlzLnBhdGhFbGVtZW50Lm5hdGl2ZUVsZW1lbnQuc3R5bGUuaGVpZ2h0ID0gdGhpcy5zaXplO1xuICAgIH1cbiAgICBpZiAodGhpcy5zcGlubmVyQ29udGFpbmVyKSB7XG4gICAgICB0aGlzLnNwaW5uZXJDb250YWluZXIubmF0aXZlRWxlbWVudC5zdHlsZS53aWR0aCA9IHRoaXMuc2l6ZTtcbiAgICAgIHRoaXMuc3Bpbm5lckNvbnRhaW5lci5uYXRpdmVFbGVtZW50LnN0eWxlLmhlaWdodCA9IHRoaXMuc2l6ZTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgIGlmICgnY29sb3InIGluIGNoYW5nZXMpIHtcbiAgICAgIHRoaXMuY29sb3IgPSBjaGFuZ2VzWydjb2xvciddLmN1cnJlbnRWYWx1ZTtcbiAgICAgIHRoaXMudXBkYXRlQ29sb3IoKTtcbiAgICB9XG4gICAgaWYgKCdzaXplJyBpbiBjaGFuZ2VzKSB7XG4gICAgICB0aGlzLnNpemUgPSBjaGFuZ2VzWydzaXplJ10uY3VycmVudFZhbHVlO1xuICAgICAgdGhpcy51cGRhdGVTaXplKCk7XG4gICAgfVxuICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwib3VpLXNwaW5uZXItY29udGFpbmVyXCIgI3NwaW5uZXJDb250YWluZXI+XG4gIEBpZiAodHlwZSA9PT0gJ3NvbGlkJykge1xuICAgIDxzdmdcbiAgICAgICNzdmdFbGVtZW50XG4gICAgICB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCJcbiAgICAgIHhtbG5zOnhsaW5rPVwiaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGlua1wiXG4gICAgICBzdHlsZT1cIm1hcmdpbjogYXV0bzsgc2hhcGUtcmVuZGVyaW5nOiBhdXRvXCJcbiAgICAgIHZpZXdCb3g9XCIwIDAgMTAwIDEwMFwiXG4gICAgICBwcmVzZXJ2ZUFzcGVjdFJhdGlvPVwieE1pZFlNaWRcIlxuICAgICAgPlxuICAgICAgPGNpcmNsZVxuICAgICAgICAjcGF0aEVsZW1lbnRcbiAgICAgICAgY3g9XCI1MFwiXG4gICAgICAgIGN5PVwiNTBcIlxuICAgICAgICBmaWxsPVwibm9uZVwiXG4gICAgICAgIHN0cm9rZT1cIiNlMTViNjRcIlxuICAgICAgICBzdHJva2Utd2lkdGg9XCI2XCJcbiAgICAgICAgcj1cIjQwXCJcbiAgICAgICAgc3Ryb2tlLWRhc2hhcnJheT1cIjE4OC40OTU1NTkyMTUzODc1NyA2NC44MzE4NTMwNzE3OTU4NlwiXG4gICAgICAgID5cbiAgICAgICAgPGFuaW1hdGVUcmFuc2Zvcm1cbiAgICAgICAgICBhdHRyaWJ1dGVOYW1lPVwidHJhbnNmb3JtXCJcbiAgICAgICAgICB0eXBlPVwicm90YXRlXCJcbiAgICAgICAgICByZXBlYXRDb3VudD1cImluZGVmaW5pdGVcIlxuICAgICAgICAgIGR1cj1cIjFzXCJcbiAgICAgICAgICB2YWx1ZXM9XCIwIDUwIDUwOzM2MCA1MCA1MFwiXG4gICAgICAgICAga2V5VGltZXM9XCIwOzFcIlxuICAgICAgICA+PC9hbmltYXRlVHJhbnNmb3JtPlxuICAgICAgPC9jaXJjbGU+XG4gICAgPC9zdmc+XG4gIH1cblxuICBAaWYgKHR5cGUgPT09ICdzdHJva2UnKSB7XG4gICAgPHN2Z1xuICAgICAgI3N2Z0VsZW1lbnRcbiAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxuICAgICAgeG1sbnM6eGxpbms9XCJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rXCJcbiAgICAgIHN0eWxlPVwic2hhcGUtcmVuZGVyaW5nOiBhdXRvXCJcbiAgICAgIHZpZXdCb3g9XCIwIDAgMTAwIDEwMFwiXG4gICAgICBwcmVzZXJ2ZUFzcGVjdFJhdGlvPVwieE1pZFlNaWRcIlxuICAgICAgPlxuICAgICAgPHBhdGggI3BhdGhFbGVtZW50IGQ9XCJNMTAgNTBBNDAgNDAgMCAwIDAgOTAgNTBBNDAgNDIgMCAwIDEgMTAgNTBcIj5cbiAgICAgICAgPGFuaW1hdGVUcmFuc2Zvcm1cbiAgICAgICAgICBhdHRyaWJ1dGVOYW1lPVwidHJhbnNmb3JtXCJcbiAgICAgICAgICB0eXBlPVwicm90YXRlXCJcbiAgICAgICAgICBkdXI9XCIxc1wiXG4gICAgICAgICAgcmVwZWF0Q291bnQ9XCJpbmRlZmluaXRlXCJcbiAgICAgICAgICBrZXlUaW1lcz1cIjA7MVwiXG4gICAgICAgICAgdmFsdWVzPVwiMCA1MCA1MTszNjAgNTAgNTFcIlxuICAgICAgICA+PC9hbmltYXRlVHJhbnNmb3JtPlxuICAgICAgPC9wYXRoPlxuICAgIDwvc3ZnPlxuICB9XG48L2Rpdj5cbiJdfQ==