import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { isEqual } from 'lodash-es';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
/**
 * Component to add radio-buttons.
 *
 *   example use:
 *
 *   <oui-radio group="radioButtons"[(model)]="radioModel" value="First value">The label for first radio-button</oui-radio>
 *   <oui-radio group="radioButtons" [(model)]="radioModel" value="Second value">The label for second radio-button</oui-radio>
 *
 */
export class OuiRadioComponent {
    cdr;
    /**
     *   Group that the radio-button belongs to.
     */
    group;
    /**
     *   The model attached to the input field value-changes
     */
    model;
    /**
     *   The value of the radio-button. When radio-button is selected, the attached model gets this value
     */
    value;
    /**
     *   The event emitted when model changes
     */
    modelChange = new EventEmitter();
    /**
     *  The property of the model to compare with the value
     */
    compareBy;
    isChecked = false;
    constructor(cdr) {
        this.cdr = cdr;
    }
    ngAfterViewInit() {
        if (this.model && this.value) {
            this.doCheckIsChecked();
        }
    }
    doCheckIsChecked() {
        this.isChecked = this.isSelected();
        this.cdr.detectChanges();
    }
    isSelected() {
        if (this.compareBy) {
            return this.model[this.compareBy] === this.value[this.compareBy];
        }
        else {
            return isEqual(this.model, this.value);
        }
    }
    setModel() {
        this.model = this.value;
        this.isChecked = true;
        this.modelChange.emit(this.model);
        this.cdr.detectChanges();
    }
    ngOnChanges(changes) {
        if (changes['model'] || changes['value']) {
            this.model = changes['model'].currentValue;
            this.doCheckIsChecked();
        }
        if (changes['value']) {
            this.value = changes['value'].currentValue;
            this.doCheckIsChecked();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiRadioComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiRadioComponent, isStandalone: true, selector: "oui-radio", inputs: { group: "group", model: "model", value: "value", compareBy: "compareBy" }, outputs: { modelChange: "modelChange" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"oui-radio-container\" (click)=\"setModel()\">\n  <div class=\"oui-radio-inner-container\">\n    <input\n      type=\"radio\"\n      name=\"{{ group }}\"\n      value=\"{{ value }}\"\n      [ngModel]=\"model\"\n      />\n    <span class=\"oui-radio-circle\">\n      @if (isChecked) {\n        <span class=\"oui-radio-check\"></span>\n      }\n    </span>\n  </div>\n  <div class=\"oui-radio-label-container\">\n    <ng-content></ng-content>\n  </div>\n</div>\n", styles: [":host{cursor:pointer;min-width:50px;min-height:20px;display:flex;align-items:center}:host input[type=radio]{-webkit-appearance:none;appearance:none;opacity:0;position:absolute}:host .oui-radio-container{display:flex;align-items:center;flex-wrap:nowrap;flex:1}:host .oui-radio-container .oui-radio-inner-container{display:flex;align-items:center;flex-wrap:nowrap;margin-right:var(--oui-radio-label-distance)}:host .oui-radio-container .oui-radio-inner-container .oui-radio-circle{width:var(--oui-radio-size);height:var(--oui-radio-size);border-radius:50%;border:1px solid var(--oui-radio-border-color);background-color:#fff;display:flex;justify-content:center;align-items:center;transition:border-color .3s;flex:0 0 auto;margin-right:5px}:host .oui-radio-container .oui-radio-inner-container .oui-radio-circle .oui-radio-check{border-radius:50%;width:10px;height:10px;background-color:var(--oui-radio-check-color)}:host .oui-radio-container .oui-radio-label-container{flex:1;display:inline-block;position:relative;color:var(--oui-radio-text-color);font-size:var(--oui-radio-label-font-size)}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.RadioControlValueAccessor, selector: "input[type=radio][formControlName],input[type=radio][formControl],input[type=radio][ngModel]", inputs: ["name", "formControlName", "value"] }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiRadioComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-radio', standalone: true, imports: [FormsModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"oui-radio-container\" (click)=\"setModel()\">\n  <div class=\"oui-radio-inner-container\">\n    <input\n      type=\"radio\"\n      name=\"{{ group }}\"\n      value=\"{{ value }}\"\n      [ngModel]=\"model\"\n      />\n    <span class=\"oui-radio-circle\">\n      @if (isChecked) {\n        <span class=\"oui-radio-check\"></span>\n      }\n    </span>\n  </div>\n  <div class=\"oui-radio-label-container\">\n    <ng-content></ng-content>\n  </div>\n</div>\n", styles: [":host{cursor:pointer;min-width:50px;min-height:20px;display:flex;align-items:center}:host input[type=radio]{-webkit-appearance:none;appearance:none;opacity:0;position:absolute}:host .oui-radio-container{display:flex;align-items:center;flex-wrap:nowrap;flex:1}:host .oui-radio-container .oui-radio-inner-container{display:flex;align-items:center;flex-wrap:nowrap;margin-right:var(--oui-radio-label-distance)}:host .oui-radio-container .oui-radio-inner-container .oui-radio-circle{width:var(--oui-radio-size);height:var(--oui-radio-size);border-radius:50%;border:1px solid var(--oui-radio-border-color);background-color:#fff;display:flex;justify-content:center;align-items:center;transition:border-color .3s;flex:0 0 auto;margin-right:5px}:host .oui-radio-container .oui-radio-inner-container .oui-radio-circle .oui-radio-check{border-radius:50%;width:10px;height:10px;background-color:var(--oui-radio-check-color)}:host .oui-radio-container .oui-radio-label-container{flex:1;display:inline-block;position:relative;color:var(--oui-radio-text-color);font-size:var(--oui-radio-label-font-size)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { group: [{
                type: Input
            }], model: [{
                type: Input
            }], value: [{
                type: Input
            }], modelChange: [{
                type: Output
            }], compareBy: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmFkaW8uY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9yYWRpby9yYWRpby5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3JhZGlvL3JhZGlvLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFFTCx1QkFBdUIsRUFFdkIsU0FBUyxFQUNULFlBQVksRUFDWixLQUFLLEVBRUwsTUFBTSxHQUVQLE1BQU0sZUFBZSxDQUFDO0FBRXZCLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUM3QyxPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0sV0FBVyxDQUFDOzs7QUFFcEM7Ozs7Ozs7O0dBUUc7QUFTSCxNQUFNLE9BQU8saUJBQWlCO0lBaUNSO0lBaENwQjs7T0FFRztJQUVJLEtBQUssQ0FBUztJQUVyQjs7T0FFRztJQUVJLEtBQUssQ0FBTTtJQUVsQjs7T0FFRztJQUVJLEtBQUssQ0FBTTtJQUVsQjs7T0FFRztJQUVILFdBQVcsR0FBRyxJQUFJLFlBQVksRUFBTyxDQUFDO0lBRXRDOztPQUVHO0lBRUksU0FBUyxDQUFTO0lBRWxCLFNBQVMsR0FBRyxLQUFLLENBQUM7SUFFekIsWUFBb0IsR0FBc0I7UUFBdEIsUUFBRyxHQUFILEdBQUcsQ0FBbUI7SUFBRyxDQUFDO0lBRXZDLGVBQWU7UUFDcEIsSUFBSSxJQUFJLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUM3QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUMxQixDQUFDO0lBQ0gsQ0FBQztJQUVPLGdCQUFnQjtRQUN0QixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNuQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFTyxVQUFVO1FBQ2hCLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ25CLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDbkUsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN6QyxDQUFDO0lBQ0gsQ0FBQztJQUVNLFFBQVE7UUFDYixJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDeEIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7UUFDdEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVELFdBQVcsQ0FBQyxPQUFzQjtRQUNoQyxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztZQUN6QyxJQUFJLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxZQUFZLENBQUM7WUFDM0MsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDMUIsQ0FBQztRQUNELElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7WUFDckIsSUFBSSxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsWUFBWSxDQUFDO1lBQzNDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQzFCLENBQUM7SUFDSCxDQUFDO3VHQXRFVSxpQkFBaUI7MkZBQWpCLGlCQUFpQix1TkNoQzlCLDBkQWtCQSw2bkNEV1ksV0FBVzs7MkZBR1YsaUJBQWlCO2tCQVI3QixTQUFTOytCQUNFLFdBQVcsY0FHVCxJQUFJLFdBQ1AsQ0FBQyxXQUFXLENBQUMsbUJBQ0wsdUJBQXVCLENBQUMsTUFBTTtzRkFPeEMsS0FBSztzQkFEWCxLQUFLO2dCQU9DLEtBQUs7c0JBRFgsS0FBSztnQkFPQyxLQUFLO3NCQURYLEtBQUs7Z0JBT04sV0FBVztzQkFEVixNQUFNO2dCQU9BLFNBQVM7c0JBRGYsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFmdGVyVmlld0luaXQsXG4gIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LFxuICBDaGFuZ2VEZXRlY3RvclJlZixcbiAgQ29tcG9uZW50LFxuICBFdmVudEVtaXR0ZXIsXG4gIElucHV0LFxuICBPbkNoYW5nZXMsXG4gIE91dHB1dCxcbiAgU2ltcGxlQ2hhbmdlcyxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IEZvcm1zTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgaXNFcXVhbCB9IGZyb20gJ2xvZGFzaC1lcyc7XG5cbi8qKlxuICogQ29tcG9uZW50IHRvIGFkZCByYWRpby1idXR0b25zLlxuICpcbiAqICAgZXhhbXBsZSB1c2U6XG4gKlxuICogICA8b3VpLXJhZGlvIGdyb3VwPVwicmFkaW9CdXR0b25zXCJbKG1vZGVsKV09XCJyYWRpb01vZGVsXCIgdmFsdWU9XCJGaXJzdCB2YWx1ZVwiPlRoZSBsYWJlbCBmb3IgZmlyc3QgcmFkaW8tYnV0dG9uPC9vdWktcmFkaW8+XG4gKiAgIDxvdWktcmFkaW8gZ3JvdXA9XCJyYWRpb0J1dHRvbnNcIiBbKG1vZGVsKV09XCJyYWRpb01vZGVsXCIgdmFsdWU9XCJTZWNvbmQgdmFsdWVcIj5UaGUgbGFiZWwgZm9yIHNlY29uZCByYWRpby1idXR0b248L291aS1yYWRpbz5cbiAqXG4gKi9cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1yYWRpbycsXG4gIHRlbXBsYXRlVXJsOiAnLi9yYWRpby5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL3JhZGlvLmNvbXBvbmVudC5zY3NzJ10sXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtGb3Jtc01vZHVsZV0sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlSYWRpb0NvbXBvbmVudCBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQsIE9uQ2hhbmdlcyB7XG4gIC8qKlxuICAgKiAgIEdyb3VwIHRoYXQgdGhlIHJhZGlvLWJ1dHRvbiBiZWxvbmdzIHRvLlxuICAgKi9cbiAgQElucHV0KClcbiAgcHVibGljIGdyb3VwOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqICAgVGhlIG1vZGVsIGF0dGFjaGVkIHRvIHRoZSBpbnB1dCBmaWVsZCB2YWx1ZS1jaGFuZ2VzXG4gICAqL1xuICBASW5wdXQoKVxuICBwdWJsaWMgbW9kZWw6IGFueTtcblxuICAvKipcbiAgICogICBUaGUgdmFsdWUgb2YgdGhlIHJhZGlvLWJ1dHRvbi4gV2hlbiByYWRpby1idXR0b24gaXMgc2VsZWN0ZWQsIHRoZSBhdHRhY2hlZCBtb2RlbCBnZXRzIHRoaXMgdmFsdWVcbiAgICovXG4gIEBJbnB1dCgpXG4gIHB1YmxpYyB2YWx1ZTogYW55O1xuXG4gIC8qKlxuICAgKiAgIFRoZSBldmVudCBlbWl0dGVkIHdoZW4gbW9kZWwgY2hhbmdlc1xuICAgKi9cbiAgQE91dHB1dCgpXG4gIG1vZGVsQ2hhbmdlID0gbmV3IEV2ZW50RW1pdHRlcjxhbnk+KCk7XG5cbiAgLyoqXG4gICAqICBUaGUgcHJvcGVydHkgb2YgdGhlIG1vZGVsIHRvIGNvbXBhcmUgd2l0aCB0aGUgdmFsdWVcbiAgICovXG4gIEBJbnB1dCgpXG4gIHB1YmxpYyBjb21wYXJlQnk6IHN0cmluZztcblxuICBwdWJsaWMgaXNDaGVja2VkID0gZmFsc2U7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBjZHI6IENoYW5nZURldGVjdG9yUmVmKSB7fVxuXG4gIHB1YmxpYyBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgaWYgKHRoaXMubW9kZWwgJiYgdGhpcy52YWx1ZSkge1xuICAgICAgdGhpcy5kb0NoZWNrSXNDaGVja2VkKCk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBkb0NoZWNrSXNDaGVja2VkKCkge1xuICAgIHRoaXMuaXNDaGVja2VkID0gdGhpcy5pc1NlbGVjdGVkKCk7XG4gICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xuICB9XG5cbiAgcHJpdmF0ZSBpc1NlbGVjdGVkKCkge1xuICAgIGlmICh0aGlzLmNvbXBhcmVCeSkge1xuICAgICAgcmV0dXJuIHRoaXMubW9kZWxbdGhpcy5jb21wYXJlQnldID09PSB0aGlzLnZhbHVlW3RoaXMuY29tcGFyZUJ5XTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIGlzRXF1YWwodGhpcy5tb2RlbCwgdGhpcy52YWx1ZSk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIHNldE1vZGVsKCkge1xuICAgIHRoaXMubW9kZWwgPSB0aGlzLnZhbHVlO1xuICAgIHRoaXMuaXNDaGVja2VkID0gdHJ1ZTtcbiAgICB0aGlzLm1vZGVsQ2hhbmdlLmVtaXQodGhpcy5tb2RlbCk7XG4gICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xuICB9XG5cbiAgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgIGlmIChjaGFuZ2VzWydtb2RlbCddIHx8IGNoYW5nZXNbJ3ZhbHVlJ10pIHtcbiAgICAgIHRoaXMubW9kZWwgPSBjaGFuZ2VzWydtb2RlbCddLmN1cnJlbnRWYWx1ZTtcbiAgICAgIHRoaXMuZG9DaGVja0lzQ2hlY2tlZCgpO1xuICAgIH1cbiAgICBpZiAoY2hhbmdlc1sndmFsdWUnXSkge1xuICAgICAgdGhpcy52YWx1ZSA9IGNoYW5nZXNbJ3ZhbHVlJ10uY3VycmVudFZhbHVlO1xuICAgICAgdGhpcy5kb0NoZWNrSXNDaGVja2VkKCk7XG4gICAgfVxuICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwib3VpLXJhZGlvLWNvbnRhaW5lclwiIChjbGljayk9XCJzZXRNb2RlbCgpXCI+XG4gIDxkaXYgY2xhc3M9XCJvdWktcmFkaW8taW5uZXItY29udGFpbmVyXCI+XG4gICAgPGlucHV0XG4gICAgICB0eXBlPVwicmFkaW9cIlxuICAgICAgbmFtZT1cInt7IGdyb3VwIH19XCJcbiAgICAgIHZhbHVlPVwie3sgdmFsdWUgfX1cIlxuICAgICAgW25nTW9kZWxdPVwibW9kZWxcIlxuICAgICAgLz5cbiAgICA8c3BhbiBjbGFzcz1cIm91aS1yYWRpby1jaXJjbGVcIj5cbiAgICAgIEBpZiAoaXNDaGVja2VkKSB7XG4gICAgICAgIDxzcGFuIGNsYXNzPVwib3VpLXJhZGlvLWNoZWNrXCI+PC9zcGFuPlxuICAgICAgfVxuICAgIDwvc3Bhbj5cbiAgPC9kaXY+XG4gIDxkaXYgY2xhc3M9XCJvdWktcmFkaW8tbGFiZWwtY29udGFpbmVyXCI+XG4gICAgPG5nLWNvbnRlbnQ+PC9uZy1jb250ZW50PlxuICA8L2Rpdj5cbjwvZGl2PlxuIl19