import { ChangeDetectionStrategy, Component, computed, effect, Inject, Input, signal, ViewChild, } from '@angular/core';
// @ts-ignore
import SVGInjector from 'svg-injector/dist/svg-injector.min.js';
import { DOCUMENT, NgClass, NgOptimizedImage } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i0 from "@angular/core";
import * as i1 from "orbital-ui/themes";
/**
 * Component to be used to display icons. Streamlines use of especially svg-icons, but can also display images like pngs.
 * Created because configuration of svg-icons is cumbersome, and this component acts as an abstraction that does a lot of
 * the hard work automatically.
 *
 * Under the hood uses a method to 'unpack' a given svg-image, and inlines it directly into the DOM. This is done
 * to enable coloring the SVG on the fly.
 *
 *
 *  Example use:
 *
 *  <oui-icon icon="assets/icons/my-svg.svg" [options]={fillColor: 'color-white', strokeColor: 'color-white', viewBox: '0 0 48 48'}></oui-icon>
 */
export class OuiIconComponent {
    ouiThemeService;
    renderer;
    elementRef;
    document;
    destroyRef;
    iconContainerElement;
    /**
     *   The path to the icon to be used
     */
    set icon(newIcon) {
        this.iconSignal.set(newIcon);
        if (this.iconContainerElement) {
            this.iconContainerElement.nativeElement.replaceChildren();
            const newImage = this.renderer.createElement('img');
            this.renderer.setAttribute(newImage, 'src', this.iconSignal());
            this.renderer.setAttribute(newImage, 'id', 'svg-inject-image');
            newImage.src = this.iconSignal();
            this.iconElement = newImage;
            this.renderer.appendChild(this.iconContainerElement.nativeElement, this.iconElement);
            this.setUsedColors(this.combinedOptions());
            this.doSvgInjection(this.combinedOptions());
        }
    }
    get icon() {
        return this.iconSignal();
    }
    iconElement;
    /**
     *   The options that are to be used with the icons. Important options are:
     *     fillColor: string - the fillColor of the svg. Can be a hex-color, or a css-variable
     *     strokeColor: string - the strokeColor of the svg. Can be a hex-color or a css-variable
     *     viewBox: string - Controls the viewbox of the svg. This is usually taken by default from the svg-image.
     *                       Sometimes SVGs don't have the viewbox proprety by default, in which case you might need to provide it yourself.
     *                       In these cases, you can usually look at the dimensions of the image and match the viewBox with that. For example,
     *                       if an image is 40 pixels wide and 30 pixels high, you can pass the following viewBox: '0 0 40 30'.
     *
     *     size: string - The size of the icon, for example '20px' or '2rem'. A quick way to pass a single proprety instead of height and width separately.
     *     height: string - The same as size, except only for height
     *     width: string - The same as size, except only for width
     *     disableTransform: boolean - If set to true, svg-injecting is disabled. This should be set to true for example for png-icons.
     *     disableColorChange: boolean - If set to true, color of the SVG isn't altered. This should be set to true if SVG already contains colors.
     *     preserveAspectRatio: string - alters the preserveAspectRatio-proprety of the svg. Rarely used.
     *     margin: string - way to pass a margin to be used for the icon if needed
     */
    set options(newOptions) {
        this.optionsSignal.set(newOptions);
    }
    get options() {
        return this.optionsSignal();
    }
    #actualFillColor;
    #actualStrokeColor;
    defaultOptions = {
        fillColor: 'color-primary-icons',
        strokeColor: 'color-primary-icons',
        size: '24px',
    };
    optionsSignal = signal(this.defaultOptions);
    iconSignal = signal('');
    combinedOptions = computed(() => {
        return {
            ...this.defaultOptions,
            ...this.optionsSignal(),
        };
    });
    fallbackSize = '24px';
    constructor(ouiThemeService, renderer, elementRef, document, destroyRef) {
        this.ouiThemeService = ouiThemeService;
        this.renderer = renderer;
        this.elementRef = elementRef;
        this.document = document;
        this.destroyRef = destroyRef;
        effect(() => {
            const options = this.combinedOptions();
            this.setElementSize(options);
            this.setUsedColors(options);
            this.doSvgInjection(options);
        });
    }
    ngAfterViewInit() {
        this.iconElement =
            this.iconContainerElement.nativeElement.querySelector('.svg-inject-image');
        this.ouiThemeService.theme$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => {
            setTimeout(() => {
                this.setUsedColors(this.combinedOptions());
                this.colorSvgAndContents(this.combinedOptions());
            });
        });
    }
    setElementSize(options) {
        const height = options.height || options.size || this.fallbackSize;
        const width = options.width || options.size || this.fallbackSize;
        const heightCssVariableValue = getComputedStyle(this.document.documentElement).getPropertyValue(`--${height}`);
        const widthCssVariableValue = getComputedStyle(this.document.documentElement).getPropertyValue(`--${width}`);
        const actualHeight = heightCssVariableValue || height;
        const actualWidth = widthCssVariableValue || width;
        this.renderer.setStyle(this.iconContainerElement.nativeElement, 'height', actualHeight);
        this.renderer.setStyle(this.iconContainerElement.nativeElement, 'width', actualWidth);
    }
    doSvgInjection(options) {
        const height = options.height || options.size || this.fallbackSize;
        const width = options.width || options.size || this.fallbackSize;
        const heightCssVariableValue = getComputedStyle(this.document.documentElement).getPropertyValue(`--${height}`);
        const widthCssVariableValue = getComputedStyle(this.document.documentElement).getPropertyValue(`--${width}`);
        const actualHeight = heightCssVariableValue || height;
        const actualWidth = widthCssVariableValue || width;
        if (this.iconContainerElement && height) {
            this.renderer.setStyle(this.iconContainerElement.nativeElement, 'height', actualHeight);
        }
        if (this.iconContainerElement && width) {
            this.renderer.setStyle(this.iconContainerElement.nativeElement, 'width', actualWidth);
        }
        if (this.iconElement && height) {
            this.renderer.setStyle(this.iconElement, 'height', actualHeight);
        }
        if (this.iconElement && width) {
            this.renderer.setStyle(this.iconElement, 'width', actualWidth);
        }
        if (!options.disableTransform && this.iconElement) {
            SVGInjector(this.iconElement, {}, () => {
                const svg = this.iconContainerElement.nativeElement.querySelector('svg');
                if (options.preserveAspectRatio) {
                    this.renderer.setAttribute(svg, 'preserveAspectRatio', options.preserveAspectRatio);
                }
                const viewBox = options.viewBox;
                if (viewBox) {
                    this.renderer.setAttribute(svg, 'viewBox', viewBox);
                }
                else if (!svg.getAttribute('viewBox')) {
                    this.renderer.setAttribute(svg, 'viewBox', '0 0 48 48');
                }
                if (options.height) {
                    this.renderer.setAttribute(svg, 'height', actualHeight);
                }
                if (options.width) {
                    this.renderer.setAttribute(svg, 'width', actualWidth);
                }
                const margin = options.margin;
                if (margin) {
                    this.renderer.setAttribute(svg, 'margin', margin);
                }
                this.colorSvgAndContents(options);
            });
        }
    }
    setUsedColors(options) {
        const fillColor = options.fillColor;
        if (Array.isArray(fillColor)) {
            this.#actualFillColor = `rgba(${fillColor[0]}, ${fillColor[1]}, ${fillColor[2]}, ${fillColor.length > 3 ? fillColor[3] / 255 : '1'})`;
        }
        else {
            this.#actualFillColor = fillColor;
        }
        const strokeColor = options.strokeColor;
        if (Array.isArray(strokeColor)) {
            this.#actualStrokeColor = `rgba(${strokeColor[0]}, ${strokeColor[1]}, ${strokeColor[2]}, ${strokeColor.length > 3 ? strokeColor[3] / 255 : '1'})`;
        }
        else {
            this.#actualStrokeColor = strokeColor;
        }
    }
    colorSvgAndContents(options) {
        const paths = this.iconContainerElement.nativeElement.querySelectorAll('path');
        if (paths && paths.length) {
            for (const path of paths) {
                if (this.#actualFillColor !== 'original' &&
                    !options.disableColorChange) {
                    const cssFillVariableColor = getComputedStyle(this.document.documentElement).getPropertyValue(`--${this.#actualFillColor}`);
                    path.style.fill = cssFillVariableColor
                        ? `var(--${this.#actualFillColor})`
                        : this.#actualFillColor;
                }
                if (this.#actualStrokeColor !== 'original' &&
                    !options.disableColorChange) {
                    const cssStrokeVariableColor = getComputedStyle(this.document.documentElement).getPropertyValue(`--${this.#actualFillColor}`);
                    path.style.stroke = cssStrokeVariableColor
                        ? `var(--${this.#actualStrokeColor})`
                        : this.#actualStrokeColor;
                }
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiIconComponent, deps: [{ token: i1.OuiThemeService }, { token: i0.Renderer2 }, { token: i0.ElementRef }, { token: DOCUMENT }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiIconComponent, isStandalone: true, selector: "oui-icon", inputs: { icon: "icon", options: "options" }, viewQueries: [{ propertyName: "iconContainerElement", first: true, predicate: ["iconContainerElement"], descendants: true }], ngImport: i0, template: `
    <div #iconContainerElement class="oui-icon-container">
      <img
        class="svg-inject svg-inject-image"
        [ngClass]="{ 'disable-transform': combinedOptions().disableTransform }"
        src="{{ icon }}"
      />
    </div>
  `, isInline: true, styles: [":host{background-color:transparent;display:flex;justify-content:center;align-items:center}:host .oui-icon-container{display:flex;justify-content:center;align-items:center;background-color:transparent;position:relative}:host .oui-icon-container img{opacity:0}:host .oui-icon-container img.disable-transform{opacity:1}:host .oui-icon-container .svg-inject path{fill:var(--color-secondary)}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-icon', template: `
    <div #iconContainerElement class="oui-icon-container">
      <img
        class="svg-inject svg-inject-image"
        [ngClass]="{ 'disable-transform': combinedOptions().disableTransform }"
        src="{{ icon }}"
      />
    </div>
  `, standalone: true, imports: [NgOptimizedImage, NgClass], changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{background-color:transparent;display:flex;justify-content:center;align-items:center}:host .oui-icon-container{display:flex;justify-content:center;align-items:center;background-color:transparent;position:relative}:host .oui-icon-container img{opacity:0}:host .oui-icon-container img.disable-transform{opacity:1}:host .oui-icon-container .svg-inject path{fill:var(--color-secondary)}\n"] }]
        }], ctorParameters: () => [{ type: i1.OuiThemeService }, { type: i0.Renderer2 }, { type: i0.ElementRef }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.DestroyRef }], propDecorators: { iconContainerElement: [{
                type: ViewChild,
                args: ['iconContainerElement']
            }], icon: [{
                type: Input,
                args: [{ required: true }]
            }], options: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWNvbi5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL2ljb24vaWNvbi5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUVMLHVCQUF1QixFQUN2QixTQUFTLEVBQ1QsUUFBUSxFQUVSLE1BQU0sRUFFTixNQUFNLEVBQ04sS0FBSyxFQUdMLE1BQU0sRUFDTixTQUFTLEdBQ1YsTUFBTSxlQUFlLENBQUM7QUFDdkIsYUFBYTtBQUNiLE9BQU8sV0FBVyxNQUFNLHVDQUF1QyxDQUFDO0FBQ2hFLE9BQU8sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDdEUsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7OztBQWlCaEU7Ozs7Ozs7Ozs7OztHQVlHO0FBaUJILE1BQU0sT0FBTyxnQkFBZ0I7SUEyRWpCO0lBQ0E7SUFDRDtJQUNtQjtJQUNsQjtJQTlFeUIsb0JBQW9CLENBQU07SUFDN0Q7O09BRUc7SUFDSCxJQUErQixJQUFJLENBQUMsT0FBZTtRQUNqRCxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM3QixJQUFJLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1lBQzlCLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxhQUFhLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDMUQsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDcEQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQztZQUMvRCxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLGtCQUFrQixDQUFDLENBQUM7WUFDL0QsUUFBUSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDakMsSUFBSSxDQUFDLFdBQVcsR0FBRyxRQUFRLENBQUM7WUFDNUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQ3ZCLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxhQUFhLEVBQ3ZDLElBQUksQ0FBQyxXQUFXLENBQ2pCLENBQUM7WUFDRixJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO1lBQzNDLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7UUFDOUMsQ0FBQztJQUNILENBQUM7SUFFRCxJQUFJLElBQUk7UUFDTixPQUFPLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRUQsV0FBVyxDQUFjO0lBRXpCOzs7Ozs7Ozs7Ozs7Ozs7O09BZ0JHO0lBQ0gsSUFBYSxPQUFPLENBQUMsVUFBMkI7UUFDOUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVELElBQUksT0FBTztRQUNULE9BQU8sSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQzlCLENBQUM7SUFFRCxnQkFBZ0IsQ0FBUztJQUN6QixrQkFBa0IsQ0FBUztJQUVuQixjQUFjLEdBQW9CO1FBQ3hDLFNBQVMsRUFBRSxxQkFBcUI7UUFDaEMsV0FBVyxFQUFFLHFCQUFxQjtRQUNsQyxJQUFJLEVBQUUsTUFBTTtLQUNiLENBQUM7SUFDSyxhQUFhLEdBQUcsTUFBTSxDQUFrQixJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDN0QsVUFBVSxHQUFHLE1BQU0sQ0FBUyxFQUFFLENBQUMsQ0FBQztJQUVoQyxlQUFlLEdBQTRCLFFBQVEsQ0FBQyxHQUFHLEVBQUU7UUFDOUQsT0FBTztZQUNMLEdBQUcsSUFBSSxDQUFDLGNBQWM7WUFDdEIsR0FBRyxJQUFJLENBQUMsYUFBYSxFQUFFO1NBQ3hCLENBQUM7SUFDSixDQUFDLENBQUMsQ0FBQztJQUVJLFlBQVksR0FBRyxNQUFNLENBQUM7SUFFN0IsWUFDVSxlQUFnQyxFQUNoQyxRQUFtQixFQUNwQixVQUFzQixFQUNILFFBQWtCLEVBQ3BDLFVBQXNCO1FBSnRCLG9CQUFlLEdBQWYsZUFBZSxDQUFpQjtRQUNoQyxhQUFRLEdBQVIsUUFBUSxDQUFXO1FBQ3BCLGVBQVUsR0FBVixVQUFVLENBQVk7UUFDSCxhQUFRLEdBQVIsUUFBUSxDQUFVO1FBQ3BDLGVBQVUsR0FBVixVQUFVLENBQVk7UUFFOUIsTUFBTSxDQUFDLEdBQUcsRUFBRTtZQUNWLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQztZQUN2QyxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzdCLElBQUksQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDNUIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMvQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxlQUFlO1FBQ2IsSUFBSSxDQUFDLFdBQVc7WUFDZCxJQUFJLENBQUMsb0JBQW9CLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FDbkQsbUJBQW1CLENBQ3BCLENBQUM7UUFDSixJQUFJLENBQUMsZUFBZSxDQUFDLE1BQU07YUFDeEIsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzthQUN6QyxTQUFTLENBQUMsR0FBRyxFQUFFO1lBQ2QsVUFBVSxDQUFDLEdBQUcsRUFBRTtnQkFDZCxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO2dCQUMzQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7WUFDbkQsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxjQUFjLENBQUMsT0FBd0I7UUFDN0MsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLE1BQU0sSUFBSSxPQUFPLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDbkUsTUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLEtBQUssSUFBSSxPQUFPLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDakUsTUFBTSxzQkFBc0IsR0FBRyxnQkFBZ0IsQ0FDN0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQzlCLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQ2xDLE1BQU0scUJBQXFCLEdBQUcsZ0JBQWdCLENBQzVDLElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUM5QixDQUFDLGdCQUFnQixDQUFDLEtBQUssS0FBSyxFQUFFLENBQUMsQ0FBQztRQUNqQyxNQUFNLFlBQVksR0FBRyxzQkFBc0IsSUFBSSxNQUFNLENBQUM7UUFDdEQsTUFBTSxXQUFXLEdBQUcscUJBQXFCLElBQUksS0FBSyxDQUFDO1FBQ25ELElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUNwQixJQUFJLENBQUMsb0JBQW9CLENBQUMsYUFBYSxFQUN2QyxRQUFRLEVBQ1IsWUFBWSxDQUNiLENBQUM7UUFDRixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FDcEIsSUFBSSxDQUFDLG9CQUFvQixDQUFDLGFBQWEsRUFDdkMsT0FBTyxFQUNQLFdBQVcsQ0FDWixDQUFDO0lBQ0osQ0FBQztJQUVPLGNBQWMsQ0FBQyxPQUF3QjtRQUM3QyxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsTUFBTSxJQUFJLE9BQU8sQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQztRQUNuRSxNQUFNLEtBQUssR0FBRyxPQUFPLENBQUMsS0FBSyxJQUFJLE9BQU8sQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQztRQUNqRSxNQUFNLHNCQUFzQixHQUFHLGdCQUFnQixDQUM3QyxJQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FDOUIsQ0FBQyxnQkFBZ0IsQ0FBQyxLQUFLLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDbEMsTUFBTSxxQkFBcUIsR0FBRyxnQkFBZ0IsQ0FDNUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQzlCLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBQ2pDLE1BQU0sWUFBWSxHQUFHLHNCQUFzQixJQUFJLE1BQU0sQ0FBQztRQUN0RCxNQUFNLFdBQVcsR0FBRyxxQkFBcUIsSUFBSSxLQUFLLENBQUM7UUFDbkQsSUFBSSxJQUFJLENBQUMsb0JBQW9CLElBQUksTUFBTSxFQUFFLENBQUM7WUFDeEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQ3BCLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxhQUFhLEVBQ3ZDLFFBQVEsRUFDUixZQUFZLENBQ2IsQ0FBQztRQUNKLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxvQkFBb0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUN2QyxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FDcEIsSUFBSSxDQUFDLG9CQUFvQixDQUFDLGFBQWEsRUFDdkMsT0FBTyxFQUNQLFdBQVcsQ0FDWixDQUFDO1FBQ0osQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLFdBQVcsSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUMvQixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLFFBQVEsRUFBRSxZQUFZLENBQUMsQ0FBQztRQUNuRSxDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsV0FBVyxJQUFJLEtBQUssRUFBRSxDQUFDO1lBQzlCLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsT0FBTyxFQUFFLFdBQVcsQ0FBQyxDQUFDO1FBQ2pFLENBQUM7UUFDRCxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNsRCxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxFQUFFLEVBQUUsR0FBRyxFQUFFO2dCQUNyQyxNQUFNLEdBQUcsR0FDUCxJQUFJLENBQUMsb0JBQW9CLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDL0QsSUFBSSxPQUFPLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztvQkFDaEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQ3hCLEdBQUcsRUFDSCxxQkFBcUIsRUFDckIsT0FBTyxDQUFDLG1CQUFtQixDQUM1QixDQUFDO2dCQUNKLENBQUM7Z0JBQ0QsTUFBTSxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQztnQkFDaEMsSUFBSSxPQUFPLEVBQUUsQ0FBQztvQkFDWixJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUN0RCxDQUFDO3FCQUFNLElBQUksQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7b0JBQ3hDLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUUsV0FBVyxDQUFDLENBQUM7Z0JBQzFELENBQUM7Z0JBQ0QsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBQ25CLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxRQUFRLEVBQUUsWUFBWSxDQUFDLENBQUM7Z0JBQzFELENBQUM7Z0JBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ2xCLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLEdBQUcsRUFBRSxPQUFPLEVBQUUsV0FBVyxDQUFDLENBQUM7Z0JBQ3hELENBQUM7Z0JBQ0QsTUFBTSxNQUFNLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztnQkFDOUIsSUFBSSxNQUFNLEVBQUUsQ0FBQztvQkFDWCxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUUsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUNwRCxDQUFDO2dCQUNELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNwQyxDQUFDLENBQUMsQ0FBQztRQUNMLENBQUM7SUFDSCxDQUFDO0lBRU8sYUFBYSxDQUFDLE9BQXdCO1FBQzVDLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUM7UUFDcEMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQUM7WUFDN0IsSUFBSSxDQUFDLGdCQUFnQixHQUFHLFFBQVEsU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FDM0QsU0FBUyxDQUFDLENBQUMsQ0FDYixLQUFLLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztRQUMxRCxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxTQUFtQixDQUFDO1FBQzlDLENBQUM7UUFDRCxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsV0FBVyxDQUFDO1FBQ3hDLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDO1lBQy9CLElBQUksQ0FBQyxrQkFBa0IsR0FBRyxRQUFRLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQ2pFLFdBQVcsQ0FBQyxDQUFDLENBQ2YsS0FBSyxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7UUFDOUQsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsa0JBQWtCLEdBQUcsV0FBcUIsQ0FBQztRQUNsRCxDQUFDO0lBQ0gsQ0FBQztJQUVPLG1CQUFtQixDQUFDLE9BQXdCO1FBQ2xELE1BQU0sS0FBSyxHQUNULElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxhQUFhLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDbkUsSUFBSSxLQUFLLElBQUksS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQzFCLEtBQUssTUFBTSxJQUFJLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQ3pCLElBQ0UsSUFBSSxDQUFDLGdCQUFnQixLQUFLLFVBQVU7b0JBQ3BDLENBQUMsT0FBTyxDQUFDLGtCQUFrQixFQUMzQixDQUFDO29CQUNELE1BQU0sb0JBQW9CLEdBQUcsZ0JBQWdCLENBQzNDLElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUM5QixDQUFDLGdCQUFnQixDQUFDLEtBQUssSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUMsQ0FBQztvQkFDakQsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsb0JBQW9CO3dCQUNwQyxDQUFDLENBQUMsU0FBUyxJQUFJLENBQUMsZ0JBQWdCLEdBQUc7d0JBQ25DLENBQUMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUM7Z0JBQzVCLENBQUM7Z0JBQ0QsSUFDRSxJQUFJLENBQUMsa0JBQWtCLEtBQUssVUFBVTtvQkFDdEMsQ0FBQyxPQUFPLENBQUMsa0JBQWtCLEVBQzNCLENBQUM7b0JBQ0QsTUFBTSxzQkFBc0IsR0FBRyxnQkFBZ0IsQ0FDN0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQzlCLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxDQUFDO29CQUNqRCxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxzQkFBc0I7d0JBQ3hDLENBQUMsQ0FBQyxTQUFTLElBQUksQ0FBQyxrQkFBa0IsR0FBRzt3QkFDckMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQztnQkFDOUIsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQzt1R0E5T1UsZ0JBQWdCLG9HQThFakIsUUFBUTsyRkE5RVAsZ0JBQWdCLGdQQWRqQjs7Ozs7Ozs7R0FRVCwrY0FHMkIsT0FBTzs7MkZBR3hCLGdCQUFnQjtrQkFoQjVCLFNBQVM7K0JBQ0UsVUFBVSxZQUNWOzs7Ozs7OztHQVFULGNBRVcsSUFBSSxXQUNQLENBQUMsZ0JBQWdCLEVBQUUsT0FBTyxDQUFDLG1CQUNuQix1QkFBdUIsQ0FBQyxNQUFNOzswQkFnRjVDLE1BQU07MkJBQUMsUUFBUTtrRUE3RWlCLG9CQUFvQjtzQkFBdEQsU0FBUzt1QkFBQyxzQkFBc0I7Z0JBSUYsSUFBSTtzQkFBbEMsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUU7Z0JBeUNaLE9BQU87c0JBQW5CLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcbiAgQ29tcG9uZW50LFxuICBjb21wdXRlZCxcbiAgRGVzdHJveVJlZixcbiAgZWZmZWN0LFxuICBFbGVtZW50UmVmLFxuICBJbmplY3QsXG4gIElucHV0LFxuICBSZW5kZXJlcjIsXG4gIFNpZ25hbCxcbiAgc2lnbmFsLFxuICBWaWV3Q2hpbGQsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuLy8gQHRzLWlnbm9yZVxuaW1wb3J0IFNWR0luamVjdG9yIGZyb20gJ3N2Zy1pbmplY3Rvci9kaXN0L3N2Zy1pbmplY3Rvci5taW4uanMnO1xuaW1wb3J0IHsgRE9DVU1FTlQsIE5nQ2xhc3MsIE5nT3B0aW1pemVkSW1hZ2UgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgdGFrZVVudGlsRGVzdHJveWVkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZS9yeGpzLWludGVyb3AnO1xuaW1wb3J0IHsgT3VpVGhlbWVTZXJ2aWNlIH0gZnJvbSAnb3JiaXRhbC11aS90aGVtZXMnO1xuaW1wb3J0IHsgbWVyZ2UgfSBmcm9tICdsb2Rhc2gtZXMnO1xuXG5leHBvcnQgaW50ZXJmYWNlIElPdWlJY29uT3B0aW9ucyB7XG4gIHNpemU/OiBzdHJpbmc7XG4gIHdpZHRoPzogc3RyaW5nO1xuICBoZWlnaHQ/OiBzdHJpbmc7XG4gIGZpbGxDb2xvcj86IHN0cmluZyB8IG51bWJlcltdO1xuICBzdHJva2VDb2xvcj86IHN0cmluZyB8IG51bWJlcltdO1xuICBkaXNhYmxlVHJhbnNmb3JtPzogYm9vbGVhbjtcbiAgcHJlc2VydmVBc3BlY3RSYXRpbz86IHN0cmluZztcbiAgdmlld0JveD86IHN0cmluZztcbiAgZGlzYWJsZUNvbG9yQ2hhbmdlPzogYm9vbGVhbjtcbiAgbWFyZ2luPzogc3RyaW5nO1xufVxuXG4vKipcbiAqIENvbXBvbmVudCB0byBiZSB1c2VkIHRvIGRpc3BsYXkgaWNvbnMuIFN0cmVhbWxpbmVzIHVzZSBvZiBlc3BlY2lhbGx5IHN2Zy1pY29ucywgYnV0IGNhbiBhbHNvIGRpc3BsYXkgaW1hZ2VzIGxpa2UgcG5ncy5cbiAqIENyZWF0ZWQgYmVjYXVzZSBjb25maWd1cmF0aW9uIG9mIHN2Zy1pY29ucyBpcyBjdW1iZXJzb21lLCBhbmQgdGhpcyBjb21wb25lbnQgYWN0cyBhcyBhbiBhYnN0cmFjdGlvbiB0aGF0IGRvZXMgYSBsb3Qgb2ZcbiAqIHRoZSBoYXJkIHdvcmsgYXV0b21hdGljYWxseS5cbiAqXG4gKiBVbmRlciB0aGUgaG9vZCB1c2VzIGEgbWV0aG9kIHRvICd1bnBhY2snIGEgZ2l2ZW4gc3ZnLWltYWdlLCBhbmQgaW5saW5lcyBpdCBkaXJlY3RseSBpbnRvIHRoZSBET00uIFRoaXMgaXMgZG9uZVxuICogdG8gZW5hYmxlIGNvbG9yaW5nIHRoZSBTVkcgb24gdGhlIGZseS5cbiAqXG4gKlxuICogIEV4YW1wbGUgdXNlOlxuICpcbiAqICA8b3VpLWljb24gaWNvbj1cImFzc2V0cy9pY29ucy9teS1zdmcuc3ZnXCIgW29wdGlvbnNdPXtmaWxsQ29sb3I6ICdjb2xvci13aGl0ZScsIHN0cm9rZUNvbG9yOiAnY29sb3Itd2hpdGUnLCB2aWV3Qm94OiAnMCAwIDQ4IDQ4J30+PC9vdWktaWNvbj5cbiAqL1xuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLWljb24nLFxuICB0ZW1wbGF0ZTogYFxuICAgIDxkaXYgI2ljb25Db250YWluZXJFbGVtZW50IGNsYXNzPVwib3VpLWljb24tY29udGFpbmVyXCI+XG4gICAgICA8aW1nXG4gICAgICAgIGNsYXNzPVwic3ZnLWluamVjdCBzdmctaW5qZWN0LWltYWdlXCJcbiAgICAgICAgW25nQ2xhc3NdPVwieyAnZGlzYWJsZS10cmFuc2Zvcm0nOiBjb21iaW5lZE9wdGlvbnMoKS5kaXNhYmxlVHJhbnNmb3JtIH1cIlxuICAgICAgICBzcmM9XCJ7eyBpY29uIH19XCJcbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gIGAsXG4gIHN0eWxlVXJsczogWydpY29uLmNvbXBvbmVudC5zY3NzJ10sXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtOZ09wdGltaXplZEltYWdlLCBOZ0NsYXNzXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIE91aUljb25Db21wb25lbnQgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0IHtcbiAgQFZpZXdDaGlsZCgnaWNvbkNvbnRhaW5lckVsZW1lbnQnKSBpY29uQ29udGFpbmVyRWxlbWVudDogYW55O1xuICAvKipcbiAgICogICBUaGUgcGF0aCB0byB0aGUgaWNvbiB0byBiZSB1c2VkXG4gICAqL1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KSBzZXQgaWNvbihuZXdJY29uOiBzdHJpbmcpIHtcbiAgICB0aGlzLmljb25TaWduYWwuc2V0KG5ld0ljb24pO1xuICAgIGlmICh0aGlzLmljb25Db250YWluZXJFbGVtZW50KSB7XG4gICAgICB0aGlzLmljb25Db250YWluZXJFbGVtZW50Lm5hdGl2ZUVsZW1lbnQucmVwbGFjZUNoaWxkcmVuKCk7XG4gICAgICBjb25zdCBuZXdJbWFnZSA9IHRoaXMucmVuZGVyZXIuY3JlYXRlRWxlbWVudCgnaW1nJyk7XG4gICAgICB0aGlzLnJlbmRlcmVyLnNldEF0dHJpYnV0ZShuZXdJbWFnZSwgJ3NyYycsIHRoaXMuaWNvblNpZ25hbCgpKTtcbiAgICAgIHRoaXMucmVuZGVyZXIuc2V0QXR0cmlidXRlKG5ld0ltYWdlLCAnaWQnLCAnc3ZnLWluamVjdC1pbWFnZScpO1xuICAgICAgbmV3SW1hZ2Uuc3JjID0gdGhpcy5pY29uU2lnbmFsKCk7XG4gICAgICB0aGlzLmljb25FbGVtZW50ID0gbmV3SW1hZ2U7XG4gICAgICB0aGlzLnJlbmRlcmVyLmFwcGVuZENoaWxkKFxuICAgICAgICB0aGlzLmljb25Db250YWluZXJFbGVtZW50Lm5hdGl2ZUVsZW1lbnQsXG4gICAgICAgIHRoaXMuaWNvbkVsZW1lbnRcbiAgICAgICk7XG4gICAgICB0aGlzLnNldFVzZWRDb2xvcnModGhpcy5jb21iaW5lZE9wdGlvbnMoKSk7XG4gICAgICB0aGlzLmRvU3ZnSW5qZWN0aW9uKHRoaXMuY29tYmluZWRPcHRpb25zKCkpO1xuICAgIH1cbiAgfVxuXG4gIGdldCBpY29uKCkge1xuICAgIHJldHVybiB0aGlzLmljb25TaWduYWwoKTtcbiAgfVxuXG4gIGljb25FbGVtZW50OiBIVE1MRWxlbWVudDtcblxuICAvKipcbiAgICogICBUaGUgb3B0aW9ucyB0aGF0IGFyZSB0byBiZSB1c2VkIHdpdGggdGhlIGljb25zLiBJbXBvcnRhbnQgb3B0aW9ucyBhcmU6XG4gICAqICAgICBmaWxsQ29sb3I6IHN0cmluZyAtIHRoZSBmaWxsQ29sb3Igb2YgdGhlIHN2Zy4gQ2FuIGJlIGEgaGV4LWNvbG9yLCBvciBhIGNzcy12YXJpYWJsZVxuICAgKiAgICAgc3Ryb2tlQ29sb3I6IHN0cmluZyAtIHRoZSBzdHJva2VDb2xvciBvZiB0aGUgc3ZnLiBDYW4gYmUgYSBoZXgtY29sb3Igb3IgYSBjc3MtdmFyaWFibGVcbiAgICogICAgIHZpZXdCb3g6IHN0cmluZyAtIENvbnRyb2xzIHRoZSB2aWV3Ym94IG9mIHRoZSBzdmcuIFRoaXMgaXMgdXN1YWxseSB0YWtlbiBieSBkZWZhdWx0IGZyb20gdGhlIHN2Zy1pbWFnZS5cbiAgICogICAgICAgICAgICAgICAgICAgICAgIFNvbWV0aW1lcyBTVkdzIGRvbid0IGhhdmUgdGhlIHZpZXdib3ggcHJvcHJldHkgYnkgZGVmYXVsdCwgaW4gd2hpY2ggY2FzZSB5b3UgbWlnaHQgbmVlZCB0byBwcm92aWRlIGl0IHlvdXJzZWxmLlxuICAgKiAgICAgICAgICAgICAgICAgICAgICAgSW4gdGhlc2UgY2FzZXMsIHlvdSBjYW4gdXN1YWxseSBsb29rIGF0IHRoZSBkaW1lbnNpb25zIG9mIHRoZSBpbWFnZSBhbmQgbWF0Y2ggdGhlIHZpZXdCb3ggd2l0aCB0aGF0LiBGb3IgZXhhbXBsZSxcbiAgICogICAgICAgICAgICAgICAgICAgICAgIGlmIGFuIGltYWdlIGlzIDQwIHBpeGVscyB3aWRlIGFuZCAzMCBwaXhlbHMgaGlnaCwgeW91IGNhbiBwYXNzIHRoZSBmb2xsb3dpbmcgdmlld0JveDogJzAgMCA0MCAzMCcuXG4gICAqXG4gICAqICAgICBzaXplOiBzdHJpbmcgLSBUaGUgc2l6ZSBvZiB0aGUgaWNvbiwgZm9yIGV4YW1wbGUgJzIwcHgnIG9yICcycmVtJy4gQSBxdWljayB3YXkgdG8gcGFzcyBhIHNpbmdsZSBwcm9wcmV0eSBpbnN0ZWFkIG9mIGhlaWdodCBhbmQgd2lkdGggc2VwYXJhdGVseS5cbiAgICogICAgIGhlaWdodDogc3RyaW5nIC0gVGhlIHNhbWUgYXMgc2l6ZSwgZXhjZXB0IG9ubHkgZm9yIGhlaWdodFxuICAgKiAgICAgd2lkdGg6IHN0cmluZyAtIFRoZSBzYW1lIGFzIHNpemUsIGV4Y2VwdCBvbmx5IGZvciB3aWR0aFxuICAgKiAgICAgZGlzYWJsZVRyYW5zZm9ybTogYm9vbGVhbiAtIElmIHNldCB0byB0cnVlLCBzdmctaW5qZWN0aW5nIGlzIGRpc2FibGVkLiBUaGlzIHNob3VsZCBiZSBzZXQgdG8gdHJ1ZSBmb3IgZXhhbXBsZSBmb3IgcG5nLWljb25zLlxuICAgKiAgICAgZGlzYWJsZUNvbG9yQ2hhbmdlOiBib29sZWFuIC0gSWYgc2V0IHRvIHRydWUsIGNvbG9yIG9mIHRoZSBTVkcgaXNuJ3QgYWx0ZXJlZC4gVGhpcyBzaG91bGQgYmUgc2V0IHRvIHRydWUgaWYgU1ZHIGFscmVhZHkgY29udGFpbnMgY29sb3JzLlxuICAgKiAgICAgcHJlc2VydmVBc3BlY3RSYXRpbzogc3RyaW5nIC0gYWx0ZXJzIHRoZSBwcmVzZXJ2ZUFzcGVjdFJhdGlvLXByb3ByZXR5IG9mIHRoZSBzdmcuIFJhcmVseSB1c2VkLlxuICAgKiAgICAgbWFyZ2luOiBzdHJpbmcgLSB3YXkgdG8gcGFzcyBhIG1hcmdpbiB0byBiZSB1c2VkIGZvciB0aGUgaWNvbiBpZiBuZWVkZWRcbiAgICovXG4gIEBJbnB1dCgpIHNldCBvcHRpb25zKG5ld09wdGlvbnM6IElPdWlJY29uT3B0aW9ucykge1xuICAgIHRoaXMub3B0aW9uc1NpZ25hbC5zZXQobmV3T3B0aW9ucyk7XG4gIH1cblxuICBnZXQgb3B0aW9ucygpIHtcbiAgICByZXR1cm4gdGhpcy5vcHRpb25zU2lnbmFsKCk7XG4gIH1cblxuICAjYWN0dWFsRmlsbENvbG9yOiBzdHJpbmc7XG4gICNhY3R1YWxTdHJva2VDb2xvcjogc3RyaW5nO1xuXG4gIHByaXZhdGUgZGVmYXVsdE9wdGlvbnM6IElPdWlJY29uT3B0aW9ucyA9IHtcbiAgICBmaWxsQ29sb3I6ICdjb2xvci1wcmltYXJ5LWljb25zJyxcbiAgICBzdHJva2VDb2xvcjogJ2NvbG9yLXByaW1hcnktaWNvbnMnLFxuICAgIHNpemU6ICcyNHB4JyxcbiAgfTtcbiAgcHVibGljIG9wdGlvbnNTaWduYWwgPSBzaWduYWw8SU91aUljb25PcHRpb25zPih0aGlzLmRlZmF1bHRPcHRpb25zKTtcbiAgcHVibGljIGljb25TaWduYWwgPSBzaWduYWw8c3RyaW5nPignJyk7XG5cbiAgcHVibGljIGNvbWJpbmVkT3B0aW9uczogU2lnbmFsPElPdWlJY29uT3B0aW9ucz4gPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLnRoaXMuZGVmYXVsdE9wdGlvbnMsXG4gICAgICAuLi50aGlzLm9wdGlvbnNTaWduYWwoKSxcbiAgICB9O1xuICB9KTtcblxuICBwdWJsaWMgZmFsbGJhY2tTaXplID0gJzI0cHgnO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgb3VpVGhlbWVTZXJ2aWNlOiBPdWlUaGVtZVNlcnZpY2UsXG4gICAgcHJpdmF0ZSByZW5kZXJlcjogUmVuZGVyZXIyLFxuICAgIHB1YmxpYyBlbGVtZW50UmVmOiBFbGVtZW50UmVmLFxuICAgIEBJbmplY3QoRE9DVU1FTlQpIHByaXZhdGUgZG9jdW1lbnQ6IERvY3VtZW50LFxuICAgIHByaXZhdGUgZGVzdHJveVJlZjogRGVzdHJveVJlZlxuICApIHtcbiAgICBlZmZlY3QoKCkgPT4ge1xuICAgICAgY29uc3Qgb3B0aW9ucyA9IHRoaXMuY29tYmluZWRPcHRpb25zKCk7XG4gICAgICB0aGlzLnNldEVsZW1lbnRTaXplKG9wdGlvbnMpO1xuICAgICAgdGhpcy5zZXRVc2VkQ29sb3JzKG9wdGlvbnMpO1xuICAgICAgdGhpcy5kb1N2Z0luamVjdGlvbihvcHRpb25zKTtcbiAgICB9KTtcbiAgfVxuXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICB0aGlzLmljb25FbGVtZW50ID1cbiAgICAgIHRoaXMuaWNvbkNvbnRhaW5lckVsZW1lbnQubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yKFxuICAgICAgICAnLnN2Zy1pbmplY3QtaW1hZ2UnXG4gICAgICApO1xuICAgIHRoaXMub3VpVGhlbWVTZXJ2aWNlLnRoZW1lJFxuICAgICAgLnBpcGUodGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZikpXG4gICAgICAuc3Vic2NyaWJlKCgpID0+IHtcbiAgICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgICAgdGhpcy5zZXRVc2VkQ29sb3JzKHRoaXMuY29tYmluZWRPcHRpb25zKCkpO1xuICAgICAgICAgIHRoaXMuY29sb3JTdmdBbmRDb250ZW50cyh0aGlzLmNvbWJpbmVkT3B0aW9ucygpKTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgc2V0RWxlbWVudFNpemUob3B0aW9uczogSU91aUljb25PcHRpb25zKSB7XG4gICAgY29uc3QgaGVpZ2h0ID0gb3B0aW9ucy5oZWlnaHQgfHwgb3B0aW9ucy5zaXplIHx8IHRoaXMuZmFsbGJhY2tTaXplO1xuICAgIGNvbnN0IHdpZHRoID0gb3B0aW9ucy53aWR0aCB8fCBvcHRpb25zLnNpemUgfHwgdGhpcy5mYWxsYmFja1NpemU7XG4gICAgY29uc3QgaGVpZ2h0Q3NzVmFyaWFibGVWYWx1ZSA9IGdldENvbXB1dGVkU3R5bGUoXG4gICAgICB0aGlzLmRvY3VtZW50LmRvY3VtZW50RWxlbWVudFxuICAgICkuZ2V0UHJvcGVydHlWYWx1ZShgLS0ke2hlaWdodH1gKTtcbiAgICBjb25zdCB3aWR0aENzc1ZhcmlhYmxlVmFsdWUgPSBnZXRDb21wdXRlZFN0eWxlKFxuICAgICAgdGhpcy5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnRcbiAgICApLmdldFByb3BlcnR5VmFsdWUoYC0tJHt3aWR0aH1gKTtcbiAgICBjb25zdCBhY3R1YWxIZWlnaHQgPSBoZWlnaHRDc3NWYXJpYWJsZVZhbHVlIHx8IGhlaWdodDtcbiAgICBjb25zdCBhY3R1YWxXaWR0aCA9IHdpZHRoQ3NzVmFyaWFibGVWYWx1ZSB8fCB3aWR0aDtcbiAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKFxuICAgICAgdGhpcy5pY29uQ29udGFpbmVyRWxlbWVudC5uYXRpdmVFbGVtZW50LFxuICAgICAgJ2hlaWdodCcsXG4gICAgICBhY3R1YWxIZWlnaHRcbiAgICApO1xuICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUoXG4gICAgICB0aGlzLmljb25Db250YWluZXJFbGVtZW50Lm5hdGl2ZUVsZW1lbnQsXG4gICAgICAnd2lkdGgnLFxuICAgICAgYWN0dWFsV2lkdGhcbiAgICApO1xuICB9XG5cbiAgcHJpdmF0ZSBkb1N2Z0luamVjdGlvbihvcHRpb25zOiBJT3VpSWNvbk9wdGlvbnMpIHtcbiAgICBjb25zdCBoZWlnaHQgPSBvcHRpb25zLmhlaWdodCB8fCBvcHRpb25zLnNpemUgfHwgdGhpcy5mYWxsYmFja1NpemU7XG4gICAgY29uc3Qgd2lkdGggPSBvcHRpb25zLndpZHRoIHx8IG9wdGlvbnMuc2l6ZSB8fCB0aGlzLmZhbGxiYWNrU2l6ZTtcbiAgICBjb25zdCBoZWlnaHRDc3NWYXJpYWJsZVZhbHVlID0gZ2V0Q29tcHV0ZWRTdHlsZShcbiAgICAgIHRoaXMuZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50XG4gICAgKS5nZXRQcm9wZXJ0eVZhbHVlKGAtLSR7aGVpZ2h0fWApO1xuICAgIGNvbnN0IHdpZHRoQ3NzVmFyaWFibGVWYWx1ZSA9IGdldENvbXB1dGVkU3R5bGUoXG4gICAgICB0aGlzLmRvY3VtZW50LmRvY3VtZW50RWxlbWVudFxuICAgICkuZ2V0UHJvcGVydHlWYWx1ZShgLS0ke3dpZHRofWApO1xuICAgIGNvbnN0IGFjdHVhbEhlaWdodCA9IGhlaWdodENzc1ZhcmlhYmxlVmFsdWUgfHwgaGVpZ2h0O1xuICAgIGNvbnN0IGFjdHVhbFdpZHRoID0gd2lkdGhDc3NWYXJpYWJsZVZhbHVlIHx8IHdpZHRoO1xuICAgIGlmICh0aGlzLmljb25Db250YWluZXJFbGVtZW50ICYmIGhlaWdodCkge1xuICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShcbiAgICAgICAgdGhpcy5pY29uQ29udGFpbmVyRWxlbWVudC5uYXRpdmVFbGVtZW50LFxuICAgICAgICAnaGVpZ2h0JyxcbiAgICAgICAgYWN0dWFsSGVpZ2h0XG4gICAgICApO1xuICAgIH1cbiAgICBpZiAodGhpcy5pY29uQ29udGFpbmVyRWxlbWVudCAmJiB3aWR0aCkge1xuICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZShcbiAgICAgICAgdGhpcy5pY29uQ29udGFpbmVyRWxlbWVudC5uYXRpdmVFbGVtZW50LFxuICAgICAgICAnd2lkdGgnLFxuICAgICAgICBhY3R1YWxXaWR0aFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKHRoaXMuaWNvbkVsZW1lbnQgJiYgaGVpZ2h0KSB7XG4gICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKHRoaXMuaWNvbkVsZW1lbnQsICdoZWlnaHQnLCBhY3R1YWxIZWlnaHQpO1xuICAgIH1cbiAgICBpZiAodGhpcy5pY29uRWxlbWVudCAmJiB3aWR0aCkge1xuICAgICAgdGhpcy5yZW5kZXJlci5zZXRTdHlsZSh0aGlzLmljb25FbGVtZW50LCAnd2lkdGgnLCBhY3R1YWxXaWR0aCk7XG4gICAgfVxuICAgIGlmICghb3B0aW9ucy5kaXNhYmxlVHJhbnNmb3JtICYmIHRoaXMuaWNvbkVsZW1lbnQpIHtcbiAgICAgIFNWR0luamVjdG9yKHRoaXMuaWNvbkVsZW1lbnQsIHt9LCAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHN2ZyA9XG4gICAgICAgICAgdGhpcy5pY29uQ29udGFpbmVyRWxlbWVudC5uYXRpdmVFbGVtZW50LnF1ZXJ5U2VsZWN0b3IoJ3N2ZycpO1xuICAgICAgICBpZiAob3B0aW9ucy5wcmVzZXJ2ZUFzcGVjdFJhdGlvKSB7XG4gICAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRBdHRyaWJ1dGUoXG4gICAgICAgICAgICBzdmcsXG4gICAgICAgICAgICAncHJlc2VydmVBc3BlY3RSYXRpbycsXG4gICAgICAgICAgICBvcHRpb25zLnByZXNlcnZlQXNwZWN0UmF0aW9cbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHZpZXdCb3ggPSBvcHRpb25zLnZpZXdCb3g7XG4gICAgICAgIGlmICh2aWV3Qm94KSB7XG4gICAgICAgICAgdGhpcy5yZW5kZXJlci5zZXRBdHRyaWJ1dGUoc3ZnLCAndmlld0JveCcsIHZpZXdCb3gpO1xuICAgICAgICB9IGVsc2UgaWYgKCFzdmcuZ2V0QXR0cmlidXRlKCd2aWV3Qm94JykpIHtcbiAgICAgICAgICB0aGlzLnJlbmRlcmVyLnNldEF0dHJpYnV0ZShzdmcsICd2aWV3Qm94JywgJzAgMCA0OCA0OCcpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChvcHRpb25zLmhlaWdodCkge1xuICAgICAgICAgIHRoaXMucmVuZGVyZXIuc2V0QXR0cmlidXRlKHN2ZywgJ2hlaWdodCcsIGFjdHVhbEhlaWdodCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG9wdGlvbnMud2lkdGgpIHtcbiAgICAgICAgICB0aGlzLnJlbmRlcmVyLnNldEF0dHJpYnV0ZShzdmcsICd3aWR0aCcsIGFjdHVhbFdpZHRoKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBtYXJnaW4gPSBvcHRpb25zLm1hcmdpbjtcbiAgICAgICAgaWYgKG1hcmdpbikge1xuICAgICAgICAgIHRoaXMucmVuZGVyZXIuc2V0QXR0cmlidXRlKHN2ZywgJ21hcmdpbicsIG1hcmdpbik7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jb2xvclN2Z0FuZENvbnRlbnRzKG9wdGlvbnMpO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBzZXRVc2VkQ29sb3JzKG9wdGlvbnM6IElPdWlJY29uT3B0aW9ucykge1xuICAgIGNvbnN0IGZpbGxDb2xvciA9IG9wdGlvbnMuZmlsbENvbG9yO1xuICAgIGlmIChBcnJheS5pc0FycmF5KGZpbGxDb2xvcikpIHtcbiAgICAgIHRoaXMuI2FjdHVhbEZpbGxDb2xvciA9IGByZ2JhKCR7ZmlsbENvbG9yWzBdfSwgJHtmaWxsQ29sb3JbMV19LCAke1xuICAgICAgICBmaWxsQ29sb3JbMl1cbiAgICAgIH0sICR7ZmlsbENvbG9yLmxlbmd0aCA+IDMgPyBmaWxsQ29sb3JbM10gLyAyNTUgOiAnMSd9KWA7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuI2FjdHVhbEZpbGxDb2xvciA9IGZpbGxDb2xvciBhcyBzdHJpbmc7XG4gICAgfVxuICAgIGNvbnN0IHN0cm9rZUNvbG9yID0gb3B0aW9ucy5zdHJva2VDb2xvcjtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShzdHJva2VDb2xvcikpIHtcbiAgICAgIHRoaXMuI2FjdHVhbFN0cm9rZUNvbG9yID0gYHJnYmEoJHtzdHJva2VDb2xvclswXX0sICR7c3Ryb2tlQ29sb3JbMV19LCAke1xuICAgICAgICBzdHJva2VDb2xvclsyXVxuICAgICAgfSwgJHtzdHJva2VDb2xvci5sZW5ndGggPiAzID8gc3Ryb2tlQ29sb3JbM10gLyAyNTUgOiAnMSd9KWA7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMuI2FjdHVhbFN0cm9rZUNvbG9yID0gc3Ryb2tlQ29sb3IgYXMgc3RyaW5nO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgY29sb3JTdmdBbmRDb250ZW50cyhvcHRpb25zOiBJT3VpSWNvbk9wdGlvbnMpIHtcbiAgICBjb25zdCBwYXRocyA9XG4gICAgICB0aGlzLmljb25Db250YWluZXJFbGVtZW50Lm5hdGl2ZUVsZW1lbnQucXVlcnlTZWxlY3RvckFsbCgncGF0aCcpO1xuICAgIGlmIChwYXRocyAmJiBwYXRocy5sZW5ndGgpIHtcbiAgICAgIGZvciAoY29uc3QgcGF0aCBvZiBwYXRocykge1xuICAgICAgICBpZiAoXG4gICAgICAgICAgdGhpcy4jYWN0dWFsRmlsbENvbG9yICE9PSAnb3JpZ2luYWwnICYmXG4gICAgICAgICAgIW9wdGlvbnMuZGlzYWJsZUNvbG9yQ2hhbmdlXG4gICAgICAgICkge1xuICAgICAgICAgIGNvbnN0IGNzc0ZpbGxWYXJpYWJsZUNvbG9yID0gZ2V0Q29tcHV0ZWRTdHlsZShcbiAgICAgICAgICAgIHRoaXMuZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50XG4gICAgICAgICAgKS5nZXRQcm9wZXJ0eVZhbHVlKGAtLSR7dGhpcy4jYWN0dWFsRmlsbENvbG9yfWApO1xuICAgICAgICAgIHBhdGguc3R5bGUuZmlsbCA9IGNzc0ZpbGxWYXJpYWJsZUNvbG9yXG4gICAgICAgICAgICA/IGB2YXIoLS0ke3RoaXMuI2FjdHVhbEZpbGxDb2xvcn0pYFxuICAgICAgICAgICAgOiB0aGlzLiNhY3R1YWxGaWxsQ29sb3I7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKFxuICAgICAgICAgIHRoaXMuI2FjdHVhbFN0cm9rZUNvbG9yICE9PSAnb3JpZ2luYWwnICYmXG4gICAgICAgICAgIW9wdGlvbnMuZGlzYWJsZUNvbG9yQ2hhbmdlXG4gICAgICAgICkge1xuICAgICAgICAgIGNvbnN0IGNzc1N0cm9rZVZhcmlhYmxlQ29sb3IgPSBnZXRDb21wdXRlZFN0eWxlKFxuICAgICAgICAgICAgdGhpcy5kb2N1bWVudC5kb2N1bWVudEVsZW1lbnRcbiAgICAgICAgICApLmdldFByb3BlcnR5VmFsdWUoYC0tJHt0aGlzLiNhY3R1YWxGaWxsQ29sb3J9YCk7XG4gICAgICAgICAgcGF0aC5zdHlsZS5zdHJva2UgPSBjc3NTdHJva2VWYXJpYWJsZUNvbG9yXG4gICAgICAgICAgICA/IGB2YXIoLS0ke3RoaXMuI2FjdHVhbFN0cm9rZUNvbG9yfSlgXG4gICAgICAgICAgICA6IHRoaXMuI2FjdHVhbFN0cm9rZUNvbG9yO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG59XG4iXX0=