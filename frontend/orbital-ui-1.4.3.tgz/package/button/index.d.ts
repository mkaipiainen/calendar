/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/button" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-button.d.ts.map