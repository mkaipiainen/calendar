import { ElementRef, EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * A component that generates on/off switches. Functionally works the same as a checkbox, but looks visually different.
 * Can be used without labels, in which case behaves as a classic switch-component. Alternatively, can give labels to
 * the component in which case the outlook changes, and labels are added to the on/off sides.
 */
export declare class OuiSwitchComponent {
    svgElement: ElementRef;
    pathElement: ElementRef;
    /**
     *   The model bound to the switch
     */
    model: any;
    /**
     *   The values attached to the different states to the switch. These values are bound to the model.
     */
    values: {
        on: any;
        off: any;
    };
    /**
     *   The labels that are shown on the on/off sides of the switch. Changes how the component looks.
     */
    labels: {
        on: any;
        off: any;
    };
    /**
     *   Changes how the switch looks visually based on the theme
     */
    type: 'primary' | 'secondary' | 'tertiary' | 'danger' | 'warning' | 'success' | 'accent' | '';
    /**
     * The mode of the switch. If using labels, remember to pass the labels-input.
     */
    mode: 'boolean' | 'labels';
    /**
     *  If true, the switch will not toggle when clicked
     */
    disableClickToggle: boolean;
    /**
     *   Triggered when the model changes
     */
    modelChange: EventEmitter<any>;
    constructor();
    getButtonClass(): "on" | "off";
    onClick(): void;
    getOnLabel(): any;
    getOffLabel(): any;
    isSelected(side: 'on' | 'off'): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiSwitchComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiSwitchComponent, "oui-switch", never, { "model": { "alias": "model"; "required": false; }; "values": { "alias": "values"; "required": false; }; "labels": { "alias": "labels"; "required": false; }; "type": { "alias": "type"; "required": false; }; "mode": { "alias": "mode"; "required": false; }; "disableClickToggle": { "alias": "disableClickToggle"; "required": false; }; }, { "modelChange": "modelChange"; }, never, ["*"], true, never>;
}
//# sourceMappingURL=switch.component.d.ts.map