import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Pipe to check if a value is null or undefined
 * @param value value to check
 */
export declare class InputClassPipe implements PipeTransform {
    transform(model: any, variant: string, isInitialized: boolean, isActive: boolean): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputClassPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<InputClassPipe, "inputClass", true>;
}
//# sourceMappingURL=input-class.pipe.d.ts.map