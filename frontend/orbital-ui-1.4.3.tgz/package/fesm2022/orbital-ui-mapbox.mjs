import * as i0 from '@angular/core';
import { input, EventEmitter, signal, computed, Component, ChangeDetectionStrategy, ViewChild, Input, Output, inject, DestroyRef, Injectable, Inject, effect, Directive } from '@angular/core';
import * as MapboxGl from 'mapbox-gl';
import { LngLatBounds, LngLat } from 'mapbox-gl';
import { GUID } from 'orbital-ui/helpers';
import { ReplaySubject, zip, map, Subject, auditTime, race, skip, of, delay, take, concatMap, combineLatest } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { merge, isNil, debounce } from 'lodash-es';
import { FlyToInterpolator, CompositeLayer, Deck, WebMercatorViewport } from '@deck.gl/core/typed';
import { OuiIconComponent } from 'orbital-ui/icon';
import { OuiRippleDirective } from 'orbital-ui/ripple';
import * as i1$1 from '@angular/common';
import { NgStyle, DOCUMENT, CommonModule } from '@angular/common';
import Supercluster from 'supercluster';
import { IconLayer, TextLayer, BitmapLayer, PathLayer, PolygonLayer, ScatterplotLayer, GeoJsonLayer } from '@deck.gl/layers/typed';
import { EditableGeoJsonLayer } from '@nebula.gl/layers';
import { ModifyMode, ViewMode, DrawPolygonMode, MeasureDistanceMode, DrawRectangleMode, DrawPointMode, DrawLineStringMode } from '@nebula.gl/edit-modes';
import midpoint from '@turf/midpoint';
import { MVTLayer, TileLayer } from '@deck.gl/geo-layers/typed';
import { ImageLoader } from '@loaders.gl/images';
import { load } from '@loaders.gl/core';
import * as i1 from 'orbital-ui/core';
import { IsWmtsImageBrokerImage } from 'orbital-ui/core';
import { OuiSliderComponent } from 'orbital-ui/slider';
import { OuiDraggableDirective } from 'orbital-ui/draggable';
import { MapboxOverlay } from '@deck.gl/mapbox/typed';

class PipelineHelper {
    map;
    state = {
        currentFetchSubscription: null,
        previousBounds: new LngLatBounds(),
        previousDpp: Infinity,
    };
    pipelineSubject = new ReplaySubject(1);
    pipeline$ = this.pipelineSubject.asObservable();
    constructor(map) {
        this.map = map;
        this.startPipelineSubscription();
    }
    startPipelineSubscription() {
        const pipelineObservable = zip([
            this.map.auditedViewStateChange$,
            this.map.auditedBounds$,
        ]).pipe(takeUntilDestroyed(this.map.destroyRef), map(data => {
            return {
                viewState: data[0].viewState,
                bounds: data[1],
            };
        }));
        this.map.destroyRef.onDestroy(() => {
            this.state.currentFetchSubscription?.unsubscribe();
            this.pipelineSubject.complete();
        });
        pipelineObservable
            .pipe(takeUntilDestroyed(this.map.destroyRef))
            .subscribe(data => {
            if (!data.viewState.width || !data.viewState.height) {
                return;
            }
            const viewState = data.viewState;
            const bounds = data.bounds;
            // Calculate the degrees per pixel (DPP)
            const bboxDimensions = this.getBoundingBoxDimensions(bounds);
            const dppX = bboxDimensions.width / viewState.width;
            const dppY = bboxDimensions.height / viewState.height;
            const dpp = Math.min(dppX, dppY);
            const dppChange = Math.abs(dpp - this.state.previousDpp) / dpp;
            const isLargeDppChange = dppChange > 0.1;
            if (this.state.previousBounds?.isEmpty() ||
                isLargeDppChange ||
                !(this.state.previousBounds.contains(bounds._ne) &&
                    this.state.previousBounds.contains(bounds._sw))) {
                const bufferFactor = 0.4;
                const boundingBoxWidth = bounds._ne.lng - bounds._sw.lng;
                const boundingBoxHeight = bounds._ne.lat - bounds._sw.lat;
                const currentBufferedSwLng = Math.max(-180, bounds._sw.lng - bufferFactor * boundingBoxWidth);
                const currentBufferedNeLng = Math.min(180, bounds._ne.lng + bufferFactor * boundingBoxWidth);
                const currentBufferedSwLat = Math.max(-90, bounds._sw.lat - bufferFactor * boundingBoxHeight);
                const currentBufferedNeLat = Math.min(90, bounds._ne.lat + bufferFactor * boundingBoxHeight);
                const newSW = new LngLat(currentBufferedSwLng, currentBufferedSwLat);
                const newNE = new LngLat(currentBufferedNeLng, currentBufferedNeLat);
                this.state.previousBounds = new LngLatBounds(newSW, newNE);
                this.state.previousDpp = dpp;
                const boundingBox = [
                    [currentBufferedSwLng, currentBufferedNeLat],
                    [currentBufferedNeLng, currentBufferedNeLat],
                    [currentBufferedNeLng, currentBufferedSwLat],
                    [currentBufferedSwLng, currentBufferedSwLat],
                    [currentBufferedSwLng, currentBufferedNeLat],
                ];
                this.pipelineSubject.next({
                    bounds: boundingBox,
                    dpp: dpp,
                });
            }
        });
    }
    getBoundingBoxDimensions(bounds) {
        const boundingBoxWidth = bounds._ne.lng - bounds._sw.lng;
        const boundingBoxHeight = bounds._ne.lat - bounds._sw.lat;
        return {
            width: boundingBoxWidth,
            height: boundingBoxHeight,
        };
    }
}

class OuiMapboxComponent {
    zone;
    destroyRef;
    elementRef;
    cdr;
    renderer;
    vcr;
    appRef;
    mapRef;
    overlay;
    mapContainer;
    actions;
    gammaMask;
    attributions = input([]);
    deck;
    set gamma(newGamma) {
        this._gamma = newGamma;
        const filters = this.elementRef.nativeElement.querySelectorAll('.gammaElement');
        if (this._gamma === 0) {
            this.gamma = -0.001;
        }
        for (const filter of filters) {
            filter.setAttribute('amplitude', `${this._gamma}`);
            filter.setAttribute('exponent', `${1 / this._gamma}`);
            // filter.setAttribute('offset', `${(value - 1) / 5}`);
        }
        this.gammaFilterUrl = `url(#gamma-${this.id}) brightness(${this._gamma})`;
    }
    get gamma() {
        return this._gamma;
    }
    set options(newOptions) {
        if (!newOptions) {
            return;
        }
        this.optionsSignal.set(newOptions);
        if (!this.isInitialised()) {
            this.attemptInitialisation();
            this.initNavigationControl();
            if (this.combinedOptions()?.isPipelineDataEmitted &&
                !this.isEmittingPipelines) {
                this.initEmittingPipelines();
            }
            if (!this.deck || this.deck.isInterleaved) {
                this.repositionMap();
            }
        }
        else if (!this.deck || this.deck.isInterleaved) {
            this.repositionMap();
        }
    }
    get options() {
        return this.combinedOptions();
    }
    onLoad = new EventEmitter();
    defaultOptions = {
        maxPitch: 0,
        style: 'mapbox://styles/mapbox/streets-v12',
        disableResizeTracking: false,
        isPipelineDataEmitted: false,
        antialias: true,
        attributionControl: true,
        bearing: 0,
        dragPan: true,
        dragRotate: true,
        doubleClickZoom: false,
        maxBounds: [-180, -90, 180, 90],
        maxZoom: 20,
        minZoom: 1,
        isHiddenOnInitialLoad: false,
        accessToken: '',
        longClickDelay: 500,
        projection: {
            name: 'mercator',
            center: [4, 50],
            parallels: [90, 90],
        },
    };
    currentMapboxLayers = [];
    isDestroyedSubject = new ReplaySubject(1);
    isDestroyed = false;
    isLoaded = false;
    pipelineHelper;
    isEmittingPipelines = false;
    isInitialised = signal(false);
    resizeObserver;
    onLoadSubject = new ReplaySubject(1);
    dragStartSubject = new Subject();
    longClickSubject = new Subject();
    mouseUpSubject = new Subject();
    mouseDownSubject = new Subject();
    viewStateChangeSubject = new ReplaySubject(1);
    boundsSubject = new ReplaySubject(1);
    eventHandlers = {
        move: this.onMapMove.bind(this),
        dragstart: this.onMapDragStart.bind(this),
        load: this.onMapLoad.bind(this),
        mousedown: this.onMapMouseDown.bind(this),
        mouseup: this.onMapMouseUp.bind(this),
    };
    previousMapboxViewState = {};
    pipelineDataSubject = new ReplaySubject(1);
    _gamma = 1;
    navigationControl;
    combinedOptions = computed(() => {
        return merge({ ...this.defaultOptions, ...this.optionsSignal() });
    });
    optionsSignal = signal(undefined);
    container = signal(undefined);
    id = GUID();
    onLoad$ = this.onLoadSubject.asObservable();
    map;
    isDestroyed$ = this.isDestroyedSubject.asObservable();
    viewStateChange$ = this.viewStateChangeSubject.asObservable();
    bounds$ = this.boundsSubject.asObservable();
    auditedViewStateChange$ = this.viewStateChange$.pipe(auditTime(500));
    auditedBounds$ = this.bounds$.pipe(auditTime(500));
    pipelineData$ = this.pipelineDataSubject.asObservable();
    dragStart$ = this.dragStartSubject.asObservable();
    longClick$ = this.longClickSubject.asObservable();
    mouseUp$ = this.mouseUpSubject.asObservable();
    mouseDown$ = this.mouseDownSubject.asObservable();
    isLoading = signal(true);
    gammaFilterUrl = `url(#gamma-${this.id}) brightness(1)`;
    constructor(zone, destroyRef, elementRef, cdr, renderer, vcr, appRef) {
        this.zone = zone;
        this.destroyRef = destroyRef;
        this.elementRef = elementRef;
        this.cdr = cdr;
        this.renderer = renderer;
        this.vcr = vcr;
        this.appRef = appRef;
    }
    ngAfterViewInit() {
        this.attemptInitialisation();
        if (!this.combinedOptions()?.isHiddenOnInitialLoad && this.mapContainer) {
            this.doShow();
        }
        setTimeout(() => {
            const attributionControl = this.elementRef.nativeElement.querySelector('.mapboxgl-ctrl-attrib');
            for (let template of this.attributions()) {
                if (attributionControl) {
                    const view = template.createEmbeddedView({});
                    this.appRef.attachView(view);
                    for (let child of view.rootNodes) {
                        attributionControl.appendChild(child);
                    }
                }
            }
        });
    }
    doShow() {
        this.renderer.addClass(this.mapContainer.nativeElement, 'show');
        this.renderer.addClass(this.overlay.nativeElement, 'fade');
    }
    initNavigationControl() {
        if (this.combinedOptions()?.navigationControl && this.map) {
            if (!this.navigationControl) {
                this.navigationControl = new MapboxGl.NavigationControl();
                this.map.addControl(this.navigationControl, this.combinedOptions().navigationControl);
            }
        }
    }
    attemptInitialisation() {
        if (!this.combinedOptions()?.accessToken) {
            return;
        }
        if (this.elementRef && this.mapRef && !this.isInitialised()) {
            this.initialiseComponent();
            this.isInitialised.set(true);
        }
    }
    initialiseComponent() {
        this.initMap();
        if (!this.combinedOptions()?.disableResizeTracking &&
            !this.resizeObserver) {
            this.resizeObserver = new ResizeObserver(() => {
                this.map?.resize();
            });
            this.resizeObserver.observe(this.elementRef.nativeElement);
        }
    }
    getDeckProps() {
        return this.deck.getProps();
    }
    setDeckProps(props) {
        if (this.deck.deck()) {
            this.deck.deck()?.setProps(props);
        }
        const overlay = this.deck.deckOverlay();
        if (overlay) {
            overlay.setProps(props);
            // this.deck.deckOverlay()?.setProps(props);
        }
    }
    initMap() {
        this.zone.runOutsideAngular(() => {
            const options = this.combinedOptions();
            if (!options) {
                return;
            }
            const mapOptions = {
                container: this.mapRef.nativeElement,
                // Choose from Mapbox's core styles, or make your own style with Mapbox Studio
                style: options?.style ?? 'mapbox://styles/mapbox/standard',
                accessToken: options?.accessToken,
                antialias: options.antialias,
                trackResize: true,
                doubleClickZoom: false,
                maxZoom: options.maxZoom,
                maxPitch: options.maxPitch,
                minZoom: options.minZoom,
                dragPan: options.dragPan,
                dragRotate: options.dragRotate,
                attributionControl: options.attributionControl,
                bearing: options.bearing,
                projection: {
                    name: options.projection.name,
                    center: options.center,
                    parallels: options.projection.parallels,
                },
            };
            if (options.bounds) {
                mapOptions.bounds = options.bounds;
            }
            else {
                mapOptions.center = options.center;
                mapOptions.zoom = options.zoom;
            }
            this.map = new MapboxGl.Map(mapOptions);
            this.container.set(this.mapRef.nativeElement);
            this.initNavigationControl();
            this.map.on('idle', this.eventHandlers.load);
        });
    }
    onMapMouseUp(event) {
        const eventData = {
            latitude: event.lngLat.lng,
            longitude: event.lngLat.lat,
            point: event.point,
            originalEvent: event.originalEvent,
            type: 'mouseup',
        };
        this.mouseUpSubject.next(eventData);
    }
    onMapMouseDown(event) {
        const eventData = {
            latitude: event.lngLat.lng,
            longitude: event.lngLat.lat,
            point: event.point,
            originalEvent: event.originalEvent,
            type: 'mousedown',
        };
        this.mouseDownSubject.next(eventData);
        race([
            this.mouseUp$,
            this.viewStateChange$.pipe(skip(1)),
            of(event).pipe(delay(this.combinedOptions()?.longClickDelay ?? 500)),
        ])
            .pipe(take(1), takeUntilDestroyed(this.destroyRef))
            .subscribe(data => {
            if ('type' in data &&
                (data.type === 'mousedown' || data.type === 'touchstart')) {
                this.longClickSubject.next({
                    latitude: event.lngLat.lat,
                    longitude: event.lngLat.lng,
                    point: event.point,
                    type: 'mousedown',
                    originalEvent: event.originalEvent,
                });
            }
        });
    }
    onMapLoad() {
        if (this.isDestroyed || !this.map || this.isLoaded) {
            return;
        }
        this.map.off('idle', this.eventHandlers.load);
        this.isLoaded = true;
        this.onLoad.emit(this);
        this.onLoadSubject.next(this);
        if (!this.combinedOptions()?.isHiddenOnInitialLoad && this.mapContainer) {
            this.doShow();
        }
        if (this.deck && !this.deck.isInterleaved) {
            this.deck.dragStart$
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe((data) => {
                this.dragStartSubject.next({
                    latitude: data.info.coordinate[1],
                    longitude: data.info.coordinate[0],
                });
            });
            this.deck.mousedown$
                .pipe(concatMap(data => {
                return race([
                    this.deck.mouseup$,
                    this.viewStateChange$.pipe(skip(1), take(1)),
                    of(data).pipe(delay(this.combinedOptions()?.longClickDelay ?? 500)),
                ]).pipe(take(1), takeUntilDestroyed(this.destroyRef));
            }))
                .subscribe(data => {
                if ('type' in data && data.type === 'mousedown') {
                    this.longClickSubject.next(data);
                }
            });
            this.deck.viewStateChange$
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe(viewState => {
                this.map.jumpTo({
                    center: [
                        viewState.viewState.longitude,
                        viewState.viewState.latitude,
                    ],
                    zoom: viewState.viewState.zoom,
                    bearing: viewState.viewState.bearing ?? 0,
                    pitch: viewState.viewState.pitch ?? 0,
                });
                this.viewStateChangeSubject.next(viewState);
            });
            this.deck.bounds$
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe(bounds => {
                this.boundsSubject.next(bounds);
            });
            this.deck.onLoad$
                .pipe(takeUntilDestroyed(this.destroyRef), take(1))
                .subscribe(() => {
                this.isLoading.set(false);
                this.emitInitialViewState();
            });
        }
        else {
            this.isLoading.set(false);
            this.emitInitialViewState();
            this.map.on('move', this.eventHandlers['move']);
            this.map.on('mousedown', this.eventHandlers.mousedown);
            this.map.on('touchstart', this.eventHandlers.mousedown);
            this.map.on('mouseup', this.eventHandlers.mouseup);
            this.map.on('touchend', this.eventHandlers.mouseup);
            this.map.on('dragstart', this.eventHandlers.dragstart);
            // this.onMapMove();
        }
        // Only for fetching pipelines
        if (this.combinedOptions()?.isPipelineDataEmitted &&
            !this.isEmittingPipelines) {
            this.initEmittingPipelines();
        }
    }
    onMapDragStart(event) {
        const center = this.map?.getCenter();
        this.dragStartSubject.next({
            latitude: center?.lat ?? 0,
            longitude: center?.lng ?? 0,
        });
    }
    initEmittingPipelines() {
        this.isEmittingPipelines = true;
        this.pipelineHelper = new PipelineHelper(this);
        this.pipelineHelper.pipeline$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(data => {
            this.pipelineDataSubject.next(data);
        });
    }
    projectLngLatToXy(lngLat) {
        if (!this.map) {
            throw new Error('Map is not initialized');
        }
        return this.map.project(lngLat);
    }
    projectXyToLngLat(point) {
        if (!this.map) {
            throw new Error('Map is not initialized');
        }
        return this.map.unproject(point);
    }
    onMapMove() {
        if (!this.map) {
            return;
        }
        const center = this.map.getCenter();
        const zoom = this.map.getZoom();
        const bounds = this.map.getBounds();
        const canvas = this.map.getCanvas();
        const newViewState = {
            latitude: center.lat,
            longitude: center.lng,
            zoom,
            width: canvas.width,
            height: canvas.height,
        };
        this.viewStateChangeSubject.next({
            oldViewState: this.previousMapboxViewState,
            viewState: newViewState,
        });
        this.previousMapboxViewState = newViewState;
        this.boundsSubject.next(this.map.getBounds());
    }
    emitInitialViewState() {
        if (this.map && (!this.deck || this.deck.isInterleaved)) {
            this.viewStateChangeSubject.next({
                oldViewState: {
                    latitude: this.map.getCenter().lat,
                    longitude: this.map.getCenter().lng,
                    zoom: this.map.getZoom(),
                    width: this.map.getCanvas().width,
                    height: this.map.getCanvas().height,
                },
                viewState: {
                    latitude: this.map.getCenter().lat,
                    longitude: this.map.getCenter().lng,
                    zoom: this.map.getZoom(),
                    width: this.map.getCanvas().width,
                    height: this.map.getCanvas().height,
                },
            });
        }
        if (this.map) {
            this.boundsSubject.next(this.map.getBounds());
        }
    }
    flyTo(options) {
        if (this.deck && !this.deck.isInterleaved) {
            const oldViewState = {
                ...this.deck.deck().props.initialViewState,
            };
            const newViewState = {
                ...oldViewState,
                latitude: options.latitude,
                longitude: options.longitude,
                zoom: options.zoom,
            };
            this.deck.deck().setProps({
                initialViewState: {
                    ...newViewState,
                    transitionDuration: options.transitionDuration,
                    transitionInterpolator: new FlyToInterpolator(),
                },
            });
            if (options.transitionDuration === 0) {
                this.deck.deck().props.onViewStateChange({
                    oldViewState,
                    viewState: newViewState,
                    interactionState: {},
                    viewId: 'default-map-view',
                });
            }
        }
        else if (this.map) {
            const flyToOptions = {
                center: [options.longitude, options.latitude],
                essential: true,
                zoom: options.zoom,
            };
            if (options.transitionDuration !== 'auto') {
                flyToOptions.duration = options.transitionDuration;
            }
            this.map.flyTo(flyToOptions);
        }
    }
    repositionMap() {
        const options = this.combinedOptions();
        if (this.map && options) {
            if ('bounds' in options && options.bounds) {
                this.map.fitBounds(options.bounds, {
                    animate: false
                });
            }
            else {
                this.map.jumpTo({
                    center: options.center,
                    zoom: options.zoom,
                });
            }
            this.onMapMove();
        }
    }
    toggleDragPan(isEnabled) {
        if (this.map) {
            if (isEnabled) {
                this.map.dragPan.enable();
            }
            else {
                this.map.dragPan.disable();
            }
        }
    }
    ngOnDestroy() {
        this.cleanup();
    }
    cleanup() {
        this.isDestroyed = true;
        this.isDestroyedSubject.next(true);
        this.isDestroyedSubject.complete();
        this.pipelineDataSubject.complete();
        this.onLoadSubject.complete();
        this.viewStateChangeSubject.complete();
        this.boundsSubject.complete();
        for (let key in this.eventHandlers) {
            if (this.map) {
                this.map.off(key, this.eventHandlers[key]);
            }
        }
        if (this.deck) {
            this.deck.finalize();
        }
        if (this.resizeObserver) {
            this.resizeObserver.unobserve(this.elementRef.nativeElement);
            this.resizeObserver.disconnect();
        }
        if (this.map) {
            try {
                this.map.remove();
            }
            catch (e) {
                console.log(e);
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMapboxComponent, deps: [{ token: i0.NgZone }, { token: i0.DestroyRef }, { token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i0.Renderer2 }, { token: i0.ViewContainerRef }, { token: i0.ApplicationRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "17.3.1", type: OuiMapboxComponent, isStandalone: true, selector: "oui-mapbox", inputs: { attributions: { classPropertyName: "attributions", publicName: "attributions", isSignal: true, isRequired: false, transformFunction: null }, deck: { classPropertyName: "deck", publicName: "deck", isSignal: false, isRequired: false, transformFunction: null }, gamma: { classPropertyName: "gamma", publicName: "gamma", isSignal: false, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: false, isRequired: true, transformFunction: null } }, outputs: { onLoad: "onLoad" }, viewQueries: [{ propertyName: "mapRef", first: true, predicate: ["map"], descendants: true }, { propertyName: "overlay", first: true, predicate: ["overlay"], descendants: true }, { propertyName: "mapContainer", first: true, predicate: ["mapContainer"], descendants: true }, { propertyName: "actions", first: true, predicate: ["actions"], descendants: true }, { propertyName: "gammaMask", first: true, predicate: ["gammaFilter"], descendants: true }], ngImport: i0, template: "<div class=\"map-overlay\" #overlay>\n\n</div>\n<div class=\"mapbox-container\" #mapContainer>\n  <div id=\"map\" [ngStyle]=\"{filter: gammaFilterUrl}\" #map></div>\n  <ng-content></ng-content>\n  <div class=\"actions\" #actions>\n\n  </div>\n\n  <svg class=\"gamma-mask-svg\">\n    <filter id=\"gamma-{{id}}\" primitiveUnits=\"objectBoundingBox\" width=\"100%\" height=\"100%\" x=\"0\" y=\"0\">\n      <feComponentTransfer result=\"ADJUSTED\" x=\"0%\" width=\"100%\" height=\"100%\" y=\"0%\">\n        <feFuncR\n            class=\"gammaElement\"\n            type=\"gamma\"\n            amplitude=\"1\"\n            exponent=\"1\"\n            offset=\"0\"\n        />\n        <feFuncG\n            class=\"gammaElement\"\n            type=\"gamma\"\n            amplitude=\"1\"\n            exponent=\"1\"\n            offset=\"0\"\n        />\n        <feFuncB\n            class=\"gammaElement\"\n            type=\"gamma\"\n            amplitude=\"1\"\n            exponent=\"1\"\n            offset=\"0\"\n        />\n      </feComponentTransfer>\n\n<!--      <feComposite in2=\"SourceGraphic\" in=\"ADJUSTED\" operator=\"over\" result=\"COMPOSITE\">-->\n\n<!--      </feComposite>-->\n    </filter>\n  </svg>\n</div>\n", styles: [":host{flex:1;display:flex;position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:all;box-shadow:var(--oui-mapbox-side-by-side-map-box-shadow);border-radius:var(--oui-mapbox-side-by-side-map-border-radius);border-width:var(--oui-mapbox-side-by-side-map-border-width);border-style:var(--oui-mapbox-side-by-side-map-border-style);border-color:var(--oui-mapbox-side-by-side-map-border-color);overflow:hidden}:host .map-overlay{position:absolute;top:0;left:0;height:100%;width:100%;background-color:var(--oui-mapbox-loading-overlay-color);opacity:1;transition:opacity .5s}:host .map-overlay.fade{opacity:0;pointer-events:none}:host .mapbox-container{position:relative;top:0;right:0;width:100%;height:100%;opacity:0;transition:opacity .5s}:host .mapbox-container.show{opacity:1}:host .mapbox-container .deck-canvas.disabled{display:none}:host .mapbox-container .actions{position:absolute;right:2rem;top:2rem;display:flex;flex-direction:column;left:auto;height:auto;width:3rem;z-index:1;pointer-events:none}:host .mapbox-container .actions .action{margin-bottom:1rem;width:3rem;height:3rem;border-radius:4px;background-color:var(--oui-mapbox-geolocate-background);display:flex;justify-content:center;align-items:center;box-shadow:0 0 5px #0000004d;pointer-events:all}:host .mapbox-container .actions .action:hover{background-color:var(--oui-mapbox-geolocate-background-hover);cursor:pointer}:host .mapbox-container canvas{position:absolute}:host .mapbox-container *{top:0;left:0;width:100%;height:100%}\n"], dependencies: [{ kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMapboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-mapbox', standalone: true, imports: [OuiIconComponent, OuiRippleDirective, NgStyle], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"map-overlay\" #overlay>\n\n</div>\n<div class=\"mapbox-container\" #mapContainer>\n  <div id=\"map\" [ngStyle]=\"{filter: gammaFilterUrl}\" #map></div>\n  <ng-content></ng-content>\n  <div class=\"actions\" #actions>\n\n  </div>\n\n  <svg class=\"gamma-mask-svg\">\n    <filter id=\"gamma-{{id}}\" primitiveUnits=\"objectBoundingBox\" width=\"100%\" height=\"100%\" x=\"0\" y=\"0\">\n      <feComponentTransfer result=\"ADJUSTED\" x=\"0%\" width=\"100%\" height=\"100%\" y=\"0%\">\n        <feFuncR\n            class=\"gammaElement\"\n            type=\"gamma\"\n            amplitude=\"1\"\n            exponent=\"1\"\n            offset=\"0\"\n        />\n        <feFuncG\n            class=\"gammaElement\"\n            type=\"gamma\"\n            amplitude=\"1\"\n            exponent=\"1\"\n            offset=\"0\"\n        />\n        <feFuncB\n            class=\"gammaElement\"\n            type=\"gamma\"\n            amplitude=\"1\"\n            exponent=\"1\"\n            offset=\"0\"\n        />\n      </feComponentTransfer>\n\n<!--      <feComposite in2=\"SourceGraphic\" in=\"ADJUSTED\" operator=\"over\" result=\"COMPOSITE\">-->\n\n<!--      </feComposite>-->\n    </filter>\n  </svg>\n</div>\n", styles: [":host{flex:1;display:flex;position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:all;box-shadow:var(--oui-mapbox-side-by-side-map-box-shadow);border-radius:var(--oui-mapbox-side-by-side-map-border-radius);border-width:var(--oui-mapbox-side-by-side-map-border-width);border-style:var(--oui-mapbox-side-by-side-map-border-style);border-color:var(--oui-mapbox-side-by-side-map-border-color);overflow:hidden}:host .map-overlay{position:absolute;top:0;left:0;height:100%;width:100%;background-color:var(--oui-mapbox-loading-overlay-color);opacity:1;transition:opacity .5s}:host .map-overlay.fade{opacity:0;pointer-events:none}:host .mapbox-container{position:relative;top:0;right:0;width:100%;height:100%;opacity:0;transition:opacity .5s}:host .mapbox-container.show{opacity:1}:host .mapbox-container .deck-canvas.disabled{display:none}:host .mapbox-container .actions{position:absolute;right:2rem;top:2rem;display:flex;flex-direction:column;left:auto;height:auto;width:3rem;z-index:1;pointer-events:none}:host .mapbox-container .actions .action{margin-bottom:1rem;width:3rem;height:3rem;border-radius:4px;background-color:var(--oui-mapbox-geolocate-background);display:flex;justify-content:center;align-items:center;box-shadow:0 0 5px #0000004d;pointer-events:all}:host .mapbox-container .actions .action:hover{background-color:var(--oui-mapbox-geolocate-background-hover);cursor:pointer}:host .mapbox-container canvas{position:absolute}:host .mapbox-container *{top:0;left:0;width:100%;height:100%}\n"] }]
        }], ctorParameters: () => [{ type: i0.NgZone }, { type: i0.DestroyRef }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i0.Renderer2 }, { type: i0.ViewContainerRef }, { type: i0.ApplicationRef }], propDecorators: { mapRef: [{
                type: ViewChild,
                args: ['map']
            }], overlay: [{
                type: ViewChild,
                args: ['overlay']
            }], mapContainer: [{
                type: ViewChild,
                args: ['mapContainer']
            }], actions: [{
                type: ViewChild,
                args: ['actions']
            }], gammaMask: [{
                type: ViewChild,
                args: ['gammaFilter']
            }], deck: [{
                type: Input
            }], gamma: [{
                type: Input
            }], options: [{
                type: Input,
                args: [{ required: true }]
            }], onLoad: [{
                type: Output
            }] } });

class BaseDeckLayer {
    options;
    deck;
    onOptionsChange = new EventEmitter();
    isAdded = false;
    options$ = new ReplaySubject(1);
    destroyRef = inject(DestroyRef);
    constructor() { }
    onHover(info) {
        if (this.options.onHover) {
            this.options.onHover(info);
        }
        this.deck.setHoveredLayer(this);
    }
    onClick(item, event) {
        if (item.object && 'onClick' in this.options && this.options.onClick) {
            this.options.onClick(item.object, event);
        }
    }
    getCursor(state) {
        return state.isHovering
            ? 'pointer'
            : state.isDragging
                ? 'grabbing'
                : 'grab';
    }
    ngAfterViewInit() {
        combineLatest([this.deck.onLoad$, this.options$])
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(([_, options]) => {
            if (!this.isAdded) {
                this.deck.addLayer(this);
                this.isAdded = true;
            }
            else {
                this.deck.refreshLayer(this);
            }
        });
    }
    ngOnChanges(changes) {
        if ('options' in changes && changes.options.currentValue) {
            const options = {
                ...changes.options.currentValue,
                isEnabled: isNil(changes.options.currentValue?.isEnabled)
                    ? !!changes.options.currentValue
                    : changes.options.currentValue.isEnabled,
            };
            this.options = options;
            this.options$.next(this.options);
        }
    }
    ngOnDestroy() {
        if (this.deck) {
            this.deck.removeLayer(this);
        }
        if (this.options$) {
            this.options$.complete();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: BaseDeckLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: BaseDeckLayer, isStandalone: true, selector: "oui-base-deck-layer", inputs: { options: "options", deck: "deck" }, outputs: { onOptionsChange: "onOptionsChange" }, usesOnChanges: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: BaseDeckLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-base-deck-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }], deck: [{
                type: Input,
                args: [{ required: true }]
            }], onOptionsChange: [{
                type: Output
            }] } });

function BindCommonDeckOptions(layer) {
    return {
        id: layer.options.id,
        autoHighlight: layer.options.autoHighlight ?? false,
        loadOptions: layer.options.loadOptions,
        visible: layer.options.visible ?? true,
        opacity: layer.options.opacity ?? 1,
        extensions: layer.options.extensions ?? [],
        pickable: layer.options.pickable ?? false,
        transitions: layer.options.transitions,
        clipBounds: layer.options.clipBounds,
        onHover: layer.onHover.bind(layer),
        updateTriggers: layer.options.updateTriggers ?? [],
        dataComparator: layer.options.dataComparator,
        getCursor: layer.options.getCursor,
        _dataDiff: layer.options._dataDiff,
        getDashArray: layer.options.getDashArray,
        dashJustified: layer.options.dashJustified,
        dashGapPickable: layer.options.dashGapPickable,
        onClick: (item, event) => {
            if (item.object && layer.options.onClick) {
                layer.options.onClick(item.object, event);
            }
        },
        getOffset: layer.options.getOffset,
        ...(layer.options.maskId ? { maskId: layer.options.maskId } : {}),
        ...(layer.options.maskByInstance
            ? { maskByInstance: layer.options.maskByInstance }
            : {}),
        ...(layer.options.operation ? { operation: layer.options.operation } : {}),
    };
}

class DeckClusterLayerComponent extends BaseDeckLayer {
    isHovering = false;
    options;
    constructor() {
        super();
    }
    getCursor(state) {
        return state.isHovering
            ? 'pointer'
            : state.isDragging
                ? 'grabbing'
                : 'grab';
    }
    getLayer() {
        return new IconClusterLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            getPosition: this.options.getPosition
                ? this.options.getPosition
                : (d) => {
                    const coords = d.geometry;
                    return coords;
                },
            onClick: (info, event) => {
                if (this.options.onClick) {
                    let nextZoomLevel = null;
                    if (info.object.properties.cluster_id) {
                        nextZoomLevel = info.layer.state.index.getClusterExpansionZoom(info.object.properties.cluster_id);
                    }
                    this.options.onClick(info, nextZoomLevel, event);
                }
            },
            pickable: false,
            getColor: this.options.getColor ? this.options.getColor : [0, 0, 0, 180],
            getSize: this.options.getClusterSize,
            getIconName: this.options.getIconName,
            iconAtlas: this.options.iconAtlas,
            mask: this.options.mask ?? false,
            iconMapping: this.options.iconMapping,
            sizeScale: this.options.sizeScale ?? 1,
            reduceProps: this.options.reduceProps,
            mapProps: this.options.mapProps,
            clusterProps: this.options.clusterProps,
            textLayerProps: this.options.textLayerProps,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckClusterLayerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckClusterLayerComponent, isStandalone: true, selector: "oui-deck-cluster-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckClusterLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-cluster-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
class IconClusterLayer extends CompositeLayer {
    options;
    supercluster;
    constructor(props) {
        super(props);
        this.options = props;
    }
    shouldUpdateState({ changeFlags }) {
        if (this.options.shouldUpdateState) {
            return this.options.shouldUpdateState(changeFlags);
        }
        else {
            return changeFlags.dataChanged || changeFlags.viewportChanged;
        }
    }
    updateState({ props, oldProps, changeFlags }) {
        const rebuildIndex = changeFlags.dataChanged || props.sizeScale !== oldProps.sizeScale;
        if (rebuildIndex) {
            const transformedData = [];
            for (const data of props.data) {
                if (!props.getPosition(data)) {
                    continue;
                }
                const singleItem = {
                    geometry: { coordinates: props.getPosition(data) },
                    properties: data,
                };
                transformedData.push(singleItem);
            }
            this.supercluster = new Supercluster({
                maxZoom: 20,
                radius: props.sizeScale,
                map: this.props.mapProps
                    ? this.props.mapProps
                    : (props) => {
                        return props;
                    },
                reduce: this.props.reduceProps ? this.props.reduceProps : () => { },
            });
            try {
                // @ts-ignore
                this.supercluster.load(transformedData);
            }
            catch (e) {
                console.error('Error encountered when loading index of cluster', e);
            }
            this.setState({ index: this.supercluster });
        }
        const z = Math.floor(this.context.viewport.zoom);
        if (rebuildIndex || z !== this.state['z']) {
            this.setState({
                data: this.state['index'].getClusters([-180, -85, 180, 85], z),
            });
        }
    }
    renderLayers() {
        const { data } = this.state;
        const { iconAtlas, iconMapping } = this.props;
        const layers = [
            new IconLayer(this.getSubLayerProps({
                data,
                iconAtlas,
                iconMapping,
                isHovering: this.props.isHovering,
                sizeScale: this.props.sizeScale,
                getPosition: (d) => {
                    return d.geometry.coordinates;
                },
                visible: this.props.visible,
                getSize: this.props.getSize,
                getColor: this.props.getColor,
                pickable: true,
                updateTriggers: this.props.updateTriggers ?? [],
                getIcon: this.props.getIconName,
            })),
        ];
        if (this.props.textLayerProps) {
            // TODO: Spreading the textLayerProps for some reason causes errors. Need to investigate why and fix.
            layers.push(new TextLayer({
                getPosition: this.props.textLayerProps.getPosition,
                getSize: () => 12,
                visible: this.props.visible,
                getColor: () => [0, 0, 0, 255],
                getText: this.props.textLayerProps.getText,
                data,
            }));
        }
        return layers;
    }
}

class DeckBitmapLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new BitmapLayer({
            ...BindCommonDeckOptions(this),
            image: this.options.image,
            bounds: this.options.bounds,
            loadOptions: this.options.loadOptions,
            textureParameters: this.options.textureParameters,
        }, {
            data: this.options.data,
            image: this.options.image,
            bounds: this.options.bounds,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckBitmapLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckBitmapLayer, isStandalone: true, selector: "oui-deck-bitmap-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckBitmapLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-bitmap-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });

const EDITABLE_GEOJSON_LAYER_MODES = {
    MODIFY: ModifyMode,
    VIEW: ViewMode,
    DRAW: DrawPolygonMode,
    MEASURE_DISTANCE: MeasureDistanceMode,
    DRAW_RECTANGLE: DrawRectangleMode,
    DRAW_POINT: DrawPointMode,
    DRAW_LINESTRING: DrawLineStringMode,
};
class DeckEditableGeoJsonlayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        // @ts-ignore
        return new EditableGeoJsonLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            selectedFeatureIndexes: this.options.selectedFeatureIndexes ?? [],
            mode: this.options.mode,
            // Styles
            modeConfig: this.options.modeConfig ?? {},
            filled: this.options.filled ?? true,
            editHandlePointStrokeWidth: this.options.editHandlePointStrokeWidth ?? 2,
            getEditHandlePointColor: this.options.getEditHandlePointColor ?? [
                255, 0, 0, 255,
            ],
            getEditHandlePointOutlineColor: this.options
                .getEditHandlePointOutlineColor ?? [255, 255, 255, 255],
            pointRadiusMinPixels: this.options.pointRadiusMinPixels ?? 2,
            getEditHandlePointRadius: this.options.getEditHandlePointRadius ?? 8,
            pointRadiusScale: this.options.pointRadiusScale ?? 1,
            getFillColor: this.options.getFillColor
                ? this.options.getFillColor
                : [200, 0, 80, 180],
            getTentativeFillColor: this.options.getTentativeFillColor
                ? this.options.getTentativeFillColor
                : [200, 0, 80, 180],
            autoHighlight: this.options.autoHighlight ?? false,
            onEdit: this.options.onEdit ? this.options.onEdit : () => { },
            pickingRadius: this.options.pickingRadius ?? 10,
            _subLayerProps: this.options._subLayerProps ?? {},
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckEditableGeoJsonlayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckEditableGeoJsonlayer, isStandalone: true, selector: "oui-deck-editable-geojson-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckEditableGeoJsonlayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-editable-geojson-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class DeckIconLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new IconLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            getIcon: this.options.getIcon,
            iconAtlas: this.options.iconAtlas,
            iconMapping: this.options.iconMapping,
            getPosition: this.options.getPosition,
            pickable: this.options.pickable ?? true,
            sizeScale: this.options.sizeScale ?? 1,
            getSize: this.options.getSize ? this.options.getSize : 1,
            getPixelOffset: this.options.getPixelOffset
                ? this.options.getPixelOffset
                : () => [0, 0],
            onDrag: this.options.onDrag ? this.options.onDrag : () => { },
            onDragStart: this.options.onDragStart
                ? this.options.onDragStart
                : () => { },
            onDragEnd: this.options.onDragEnd ? this.options.onDragEnd : () => { },
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckIconLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckIconLayer, isStandalone: true, selector: "oui-deck-icon-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckIconLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-icon-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class OuiMeasureDistanceMode extends MeasureDistanceMode {
    constructor() {
        super();
    }
    handleClick(event, props) {
        super.handleClick(event, props);
        const clickSequence = this.getClickSequence();
        if (clickSequence.length === 2) {
            this._isMeasuringSessionFinished = true;
            const tooltipPosition = midpoint(clickSequence[clickSequence.length - 2], clickSequence[clickSequence.length - 1]).geometry.coordinates;
            this._currentTooltips = [
                {
                    position: tooltipPosition,
                    text: this._formatTooltip(this._currentDistance, props.modeConfig),
                },
            ];
        }
    }
}

class DeckMeasureLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        const modeConfig = {
            ...{
                centerTooltipsOnLine: true,
                formatTooltip: (distance) => {
                    if (distance >= 1) {
                        return `${distance.toFixed(2)} km`;
                    }
                    else {
                        return `${(distance * 1000).toFixed(2)} m`;
                    }
                },
            },
            ...(this.options.modeConfig ?? {}),
        };
        // @ts-ignore
        return new EditableGeoJsonLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            selectedFeatureIndexes: this.options.selectedFeatureIndexes ?? [],
            mode: OuiMeasureDistanceMode,
            // Styles
            modeConfig: modeConfig,
            filled: this.options.filled ?? true,
            editHandlePointStrokeWidth: this.options.editHandlePointStrokeWidth ?? 2,
            getEditHandlePointColor: this.options.getEditHandlePointColor ?? [
                255, 0, 0, 255,
            ],
            getEditHandlePointOutlineColor: this.options
                .getEditHandlePointOutlineColor ?? [255, 255, 255, 255],
            pointRadiusMinPixels: this.options.pointRadiusMinPixels ?? 2,
            getEditHandlePointRadius: this.options.getEditHandlePointRadius ?? 8,
            pointRadiusScale: this.options.pointRadiusScale ?? 1,
            getFillColor: this.options.getFillColor
                ? this.options.getFillColor
                : [200, 0, 80, 180],
            getTentativeFillColor: this.options.getTentativeFillColor
                ? this.options.getTentativeFillColor
                : [200, 0, 80, 180],
            autoHighlight: this.options.autoHighlight ?? false,
            onEdit: this.options.onEdit ? this.options.onEdit : () => { },
            pickingRadius: this.options.pickingRadius ?? 10,
            _subLayerProps: this.options._subLayerProps ?? {},
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckMeasureLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckMeasureLayer, isStandalone: true, selector: "oui-deck-measure-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckMeasureLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-measure-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class DeckMvtLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new MVTLayer({
            ...BindCommonDeckOptions(this),
            onDataLoad: this.options.onDataLoad,
            data: this.options.data,
            getLineColor: this.options.getLineColor,
            getFillColor: this.options.getFillColor,
            minZoom: this.options.minZoom,
            maxZoom: this.options.maxZoom,
            renderSubLayers: this.options.renderSubLayers,
            uniqueIdProperty: this.options.uniqueIdProperty,
            highlightedFeatureId: this.options.highlightedFeatureId,
            binary: this.options.binary,
            loaders: this.options.loaders,
            lineWidthMinPixels: this.options.lineWidthMinPixels,
            getLineWidth: this.options.getLineWidth,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckMvtLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckMvtLayer, isStandalone: true, selector: "oui-deck-mvt-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckMvtLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-mvt-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class DeckPathLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new PathLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            getWidth: this.options.getWidth ? this.options.getWidth : () => 1,
            widthMinPixels: this.options.widthMinPixels ?? 1,
            widthMaxPixels: this.options.widthMaxPixels ?? 9999,
            getColor: this.options.getColor,
            getPath: this.options.getPath,
            widthUnits: this.options.widthUnits ?? 'pixels',
            jointRounded: this.options.jointRounded ?? false,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckPathLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckPathLayer, isStandalone: true, selector: "oui-deck-path-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckPathLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-path-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class DeckPolygonLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new PolygonLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            stroked: this.options.stroked ?? true,
            filled: this.options.filled ?? true,
            wireframe: this.options.wireframe ?? false,
            lineWidthMinPixels: this.options.lineWidthMinPixels ?? 1,
            getFillColor: this.options.getFillColor,
            getLineColor: this.options.getLineColor,
            getLineWidth: this.options.getLineWidth,
            getElevation: this.options.getElevation ?? 1,
            getPolygon: this.options.getPolygon,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckPolygonLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckPolygonLayer, isStandalone: true, selector: "oui-deck-polygon-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckPolygonLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-polygon-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class DeckScatterplotLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new ScatterplotLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            getPosition: this.options.getPosition,
            stroked: this.options.stroked ?? true,
            filled: this.options.filled ?? true,
            radiusScale: this.options.radiusScale ?? 1,
            radiusMinPixels: this.options.radiusMinPixels ?? 1,
            radiusMaxPixels: this.options.radiusMaxPixels ?? 9999,
            lineWidthMinPixels: this.options.lineWidthMinPixels ?? 1,
            lineWidthMaxPixels: this.options.lineWidthMaxPixels ?? 999,
            lineWidthUnits: this.options.lineWidthUnits ?? 'pixels',
            getRadius: this.options.getRadius,
            getFillColor: this.options.getFillColor,
            getLineColor: this.options.getLineColor,
            getLineWidth: this.options.getLineWidth
                ? this.options.getLineWidth
                : () => {
                    return 1;
                },
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckScatterplotLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckScatterplotLayer, isStandalone: true, selector: "oui-deck-scatterplot-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckScatterplotLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-scatterplot-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class DeckGeojsonLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new GeoJsonLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            pointType: this.options.pointType,
            lineWidthScale: this.options.lineWidthScale ?? 1,
            lineWidthMinPixels: this.options.lineWidthMinPixels ?? 1,
            lineWidthMaxPixels: this.options.lineWidthMaxPixels ?? 999,
            lineWithUnits: this.options.lineWithUnits ?? 'pixels',
            getFillColor: this.options.getFillColor,
            getLineColor: this.options.getLineColor,
            getPointRadius: this.options.getPointRadius ?? 20,
            getLineWidth: this.options.getLineWidth ?? 1,
            getElevation: this.options.getElevation ?? 20,
            extruded: this.options.extruded ?? false,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckGeojsonLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckGeojsonLayer, isStandalone: true, selector: "oui-deck-geojson-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckGeojsonLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-geojson-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class DeckGeolocateLayer extends BaseDeckLayer {
    options;
    isGeolocateStarted = false;
    location = [0, 0];
    accuracy = {
        position: [0, 0],
        radius: 0,
    };
    heading = null;
    pingState = {
        isInProgress: false,
        isDone: false,
    };
    interval;
    constructor() {
        super();
    }
    onGeolocateEvent(data) {
        this.location = [data.coords.longitude, data.coords.latitude];
        this.accuracy.position = [data.coords.longitude, data.coords.latitude];
        this.accuracy.radius = data.coords.accuracy;
        this.deck.refreshLayer(this);
    }
    locateUser() {
        this.deck.map.flyTo({
            latitude: this.location[1],
            longitude: this.location[0],
            zoom: 15,
            transitionDuration: 'auto',
        });
    }
    getLayer() {
        if (!this.isGeolocateStarted) {
            this.isGeolocateStarted = true;
            if (!this.interval) {
                this.interval = setInterval(() => {
                    this.pingState = {
                        isInProgress: true,
                        isDone: false,
                    };
                    this.deck.refreshLayer(this);
                    setTimeout(() => {
                        this.pingState = {
                            isInProgress: false,
                            isDone: true,
                        };
                        this.deck.refreshLayer(this);
                        setTimeout(() => {
                            this.pingState = {
                                isInProgress: false,
                                isDone: false,
                            };
                            this.deck.refreshLayer(this);
                        }, 1000);
                    }, 1000);
                }, 3000);
            }
            this.deck.onLoad$
                .pipe(takeUntilDestroyed(this.destroyRef), take(1))
                .subscribe(() => {
                if (navigator.geolocation) {
                    navigator.geolocation.watchPosition(this.onGeolocateEvent.bind(this));
                }
            });
        }
        return new GeolocateLayer({
            options: this.options,
            location: this.location,
            accuracy: this.accuracy,
            heading: this.heading,
            pingState: this.pingState,
        });
    }
    ngOnDestroy() {
        if (this.interval) {
            clearInterval(this.interval);
        }
        super.ngOnDestroy();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckGeolocateLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckGeolocateLayer, isStandalone: true, selector: "oui-deck-geolocate-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '<div class="geolocate" ouiRipple (click)="locateUser()"><oui-icon icon="assets/icons/location.svg" [options]="{fillColor: \'oui-mapbox-geolocate-color\', strokeColor: \'oui-mapbox-geolocate-color\', size: \'18px\'}"></oui-icon></div>', isInline: true, styles: [":host{position:absolute;top:1rem;right:1rem}:host .geolocate{height:var(--oui-mapbox-geolocate-height);width:var(--oui-mapbox-geolocate-width);display:flex;justify-content:center;align-items:center;background-color:var(--oui-mapbox-geolocate-background);border-radius:var(--border-radius-default);padding:.5rem;transition:background-color .3s;box-shadow:var(--box-shadow-bottom)}:host .geolocate:hover{cursor:pointer;background-color:var(--oui-mapbox-geolocate-background-hover)}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "directive", type: OuiRippleDirective, selector: "[ouiRipple]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckGeolocateLayer, decorators: [{
            type: Component,
            args: [{ selector: 'oui-deck-geolocate-layer', template: '<div class="geolocate" ouiRipple (click)="locateUser()"><oui-icon icon="assets/icons/location.svg" [options]="{fillColor: \'oui-mapbox-geolocate-color\', strokeColor: \'oui-mapbox-geolocate-color\', size: \'18px\'}"></oui-icon></div>', standalone: true, imports: [OuiIconComponent, OuiRippleDirective], changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{position:absolute;top:1rem;right:1rem}:host .geolocate{height:var(--oui-mapbox-geolocate-height);width:var(--oui-mapbox-geolocate-width);display:flex;justify-content:center;align-items:center;background-color:var(--oui-mapbox-geolocate-background);border-radius:var(--border-radius-default);padding:.5rem;transition:background-color .3s;box-shadow:var(--box-shadow-bottom)}:host .geolocate:hover{cursor:pointer;background-color:var(--oui-mapbox-geolocate-background-hover)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
// TODO: Implement heading
class GeolocateLayer extends CompositeLayer {
    options;
    location = [0, 0];
    accuracy = {
        position: [0, 0],
        radius: 0,
    };
    heading = 0;
    pingState = {
        isInProgress: false,
        isDone: false,
    };
    constructor(props) {
        super(props);
        this.options = props.options;
        this.accuracy = props.accuracy;
        this.location = props.location;
        this.heading = props.heading;
        this.pingState = props.pingState;
    }
    shouldUpdateState({ changeFlags }) {
        return changeFlags.propsChanged || changeFlags.dataChanged;
    }
    // override updateState({ props, oldProps, changeFlags }: any) {
    //   return true;
    // }
    renderLayers() {
        const layers = [
            new ScatterplotLayer(this.getSubLayerProps({
                data: [this.accuracy],
                id: 'accuracy',
                radiusUnits: 'meters',
                getPosition: (d) => {
                    return d.position;
                },
                stroked: false,
                filled: true,
                getFillColor: this.options.getFillColor ?? [29, 161, 242, 125],
                getRadius: (d) => {
                    return d.radius;
                },
            })),
            new ScatterplotLayer(this.getSubLayerProps({
                data: [this.location],
                transitions: {
                    getFillColor: 1000,
                    getRadius: 1000,
                },
                id: 'ping',
                getRadius: this.pingState.isDone
                    ? 0
                    : this.pingState.isInProgress
                        ? 30
                        : 0,
                getFillColor: () => {
                    if (this.pingState.isDone || this.pingState.isInProgress) {
                        return [29, 161, 242, 0];
                    }
                    else {
                        return [26, 122, 200, 255];
                    }
                },
                filled: true,
                stroked: false,
                getPosition: (d) => d,
                radiusUnits: 'pixels',
                updateTriggers: {
                    getFillColor: this.pingState,
                    getRadius: this.pingState,
                },
            })),
            new ScatterplotLayer(this.getSubLayerProps({
                data: [this.location],
                id: 'location',
                radiusUnits: 'pixels',
                getPosition: (d) => d,
                stroked: this.options.stroked ?? true,
                filled: this.options.filled ?? true,
                getRadius: this.options.getRadius ?? 7,
                getFillColor: this.options.getFillColor ?? [29, 161, 242, 255],
                getLineColor: this.options.getLineColor ?? [255, 255, 255, 255],
                getLineWidth: this.options.getLineWidth ?? 2,
                lineWidthMinPixels: this.options.getLineWidth ?? 2,
            })),
        ];
        return layers;
    }
}

class DeckTextLayer extends BaseDeckLayer {
    name = 'Text';
    options;
    constructor() {
        super();
    }
    getLayer() {
        new TextLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            characterSet: this.options.characterSet ?? 'auto',
            getText: this.options.getText,
            getPosition: this.options.getPosition,
            getColor: this.options.getColor ? this.options.getColor : [0, 0, 0, 255],
            getSize: this.options.getSize ? this.options.getSize : 20,
            sizeScale: this.options.sizeScale ?? 1,
            updateTriggers: this.options.updateTriggers ?? [],
            getAngle: 0,
            getTextAnchor: this.options.getTextAnchor,
            getAlignmentBaseline: this.options.getAlignmentBaseline ?? 'top',
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckTextLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckTextLayer, isStandalone: true, selector: "oui-deck-text-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckTextLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-text-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class DeckTileLayer extends BaseDeckLayer {
    options;
    constructor() {
        super();
    }
    getLayer() {
        return new TileLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            minZoom: this.options.minZoom ?? 0,
            maxZoom: this.options.maxZoom ?? 24,
            tileSize: this.options.tileSize ?? 256,
            renderSubLayers: this.options.renderSubLayers
                ? this.options.renderSubLayers
                : (props) => {
                    const { bbox: { west, south, east, north }, } = props.tile;
                    return new BitmapLayer({ ...props }, {
                        data: undefined,
                        // image: parse(props.data.body, ImageLoader),
                        image: props.data,
                        transparentColor: [0, 0, 0, 0],
                        bounds: [west, south, east, north],
                    });
                },
            getTileData: this.options.getTileData,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckTileLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckTileLayer, isStandalone: true, selector: "oui-deck-tile-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckTileLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-tile-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });

/**
 * Service to handle fetching of raster-layers for the map.
 * Caches tiles in memory to prevent unnecessary requests.
 * Handles canceling of requests in case of the layer getting removed from the map, or the map being destroyed, and so on.
 * Also handles attaching the access token to the requests.
 */
class TileLayerService {
    requestQueueService;
    zone;
    cachedTiles = {};
    constructor(requestQueueService, zone) {
        this.requestQueueService = requestQueueService;
        this.zone = zone;
        setInterval(() => {
            this.clearCache();
        }, 60000 * 10);
    }
    /**
     * Returns a Deck.GL tileLayer-configuration for a map. This should work out of the gate by just giving the function
     * a unique ID (IMPORTANT), and the desired opticalImage-object. The function will then handle the rest.
     * @param id
     * @param data
     * @param options
     * @param layerOptions
     */
    getTileLayer(options, layerOptions = {}) {
        const defaultOptions = {
            isWebMercator: false,
            useCache: true,
            isWmts: false,
        };
        const combinedOptions = {
            ...defaultOptions,
            ...options,
        };
        const sourceUrls = (options.data ?? []).map(singleData => {
            if (typeof singleData === 'string') {
                return singleData;
            }
            else {
                const url = options.buildUrl
                    ? options.buildUrl(singleData, options)
                    : this.defaultUrlBuilder(singleData, options);
                return url;
            }
        });
        return {
            id: options.id,
            data: sourceUrls,
            isEnabled: !!sourceUrls.length,
            visible: !!sourceUrls.length,
            getTileData: (tile) => {
                return this.responseToObjectUrl(tile, combinedOptions);
            },
            ...layerOptions,
        };
    }
    defaultUrlBuilder(image, options) {
        let url = '';
        const origin = options.origin;
        // TODO: FIX WMTS
        if (IsWmtsImageBrokerImage(image)) {
            // const parsedWmtsUrl = image.wmts_data.url.replace('/wmts', '');
            // url = `${origin}/https://tiles1.geoserve.eu/Pleiades-NEO/tileserver/20230402_105346_PNEO-03_1_45_30cm_RD_8bit_RGB_Rijswijk/{z}/{x}/{y}`;
            url = `${origin}/https://tiles1.geoserve.eu/Pleiades-NEO/20231017_110049_PNEO-03_1_1_30cm_RD_8bit_RGB_DeLier/{z}/{x}/{y}`;
        }
        else {
            url = `${origin}/${image?.wms_data.image_url}&REQUEST=GetMap&SERVICE=${image?.service_type}&LAYERS=${image?.wms_data.wms_layer_name}&FORMAT=image/png&TRANSPARENT=TRUE&SRS=EPSG:3857&CRS=EPSG:4326&WIDTH=256&HEIGHT=256&VERSION=1.3.0&STYLES=`;
        }
        return url;
    }
    responseToObjectUrl(tile, options) {
        return new Promise((resolve, reject) => {
            if (options.useCache && !this.cachedTiles[options.id]) {
                this.cachedTiles[options.id] = {};
            }
            (options.accessToken$ ?? of('test')).pipe(take(1)).subscribe(token => {
                let finalUrl = tile.url;
                if (!options.isWmts) {
                    let bbox = [
                        tile.bbox.south,
                        tile.bbox.west,
                        tile.bbox.north,
                        tile.bbox.east,
                    ].join(',');
                    if (options.isWebMercator) {
                        const xySouthWest = this.latLonToMercator(tile.bbox.west, tile.bbox.south);
                        const xyNorthEast = this.latLonToMercator(tile.bbox.east, tile.bbox.north);
                        bbox = [
                            xySouthWest.x,
                            xySouthWest.y,
                            xyNorthEast.x,
                            xyNorthEast.y,
                        ].join(',');
                    }
                    finalUrl = `${tile.url}&BBOX=${bbox}`;
                }
                if (this.cachedTiles[options.id][finalUrl]) {
                    resolve(this.cachedTiles[options.id][finalUrl]);
                }
                else {
                    let headers = {};
                    if (token !== 'test') {
                        const authHeader = `Bearer ${token}`;
                        headers = {
                            Authorization: authHeader,
                        };
                    }
                    const promise = fetch(finalUrl, {
                        signal: tile.signal,
                        headers: headers,
                    });
                    this.zone.runOutsideAngular(() => {
                        const imagePromise = this.requestQueueService.addToQueue(promise, tile.signal, options.refreshedAccessToken$);
                        imagePromise
                            .catch(error => {
                            reject(error);
                        })
                            .then(async (response) => {
                            if (!response) {
                                reject(response);
                            }
                            try {
                                const image = await load(response, ImageLoader, {});
                                if (this.cachedTiles[options.id]) {
                                    this.cachedTiles[options.id][finalUrl] = image;
                                }
                                resolve(image);
                                return image;
                            }
                            catch (e) {
                                reject(e);
                            }
                        }, reject);
                    });
                }
            });
        });
    }
    latLonToMercator(lon, lat) {
        const rMajor = 6378137; //Equatorial Radius, WGS84
        const shift = Math.PI * rMajor;
        const x = (lon * shift) / 180;
        let y = Math.log(Math.tan(((90 + lat) * Math.PI) / 360)) / (Math.PI / 180);
        y = (y * shift) / 180;
        return {
            x,
            y,
        };
    }
    clearCache(id) {
        if (id) {
            delete this.cachedTiles[id];
        }
        else {
            this.cachedTiles = {};
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: TileLayerService, deps: [{ token: i1.RequestQueueService }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: TileLayerService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: TileLayerService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.RequestQueueService }, { type: i0.NgZone }] });

/**
 * Component to display two maps side-by-side with a comparison slider
 * Requires the maps inside the parent container to have position absolute, and full width + height.
 */
class MapboxSideBySideComponent {
    renderer;
    document;
    destroyRef;
    cdr;
    defaultOptions = {
        orientation: 'vertical',
    };
    usedOptions = this.defaultOptions;
    currentDragPosition = {
        left: 0,
        top: 0,
    };
    isDragging = false;
    offsetAtDragStart = 0;
    resizeObserver;
    dragLeftRatio = 0;
    isInitialisationStarted = false;
    #isPassiveSupported = {
        passive: false,
    };
    isVertical = true;
    leftMap;
    rightMap;
    mapContainer;
    options = this.defaultOptions;
    leftLabelTemplate;
    rightLabelTemplate;
    dragged = new EventEmitter();
    clicked = new EventEmitter();
    released = new EventEmitter();
    dragContainer;
    drag;
    imageLabelRight;
    imageLabelLeft;
    unlisteners = [];
    isInitialised = false;
    constructor(renderer, document, destroyRef, cdr) {
        this.renderer = renderer;
        this.document = document;
        this.destroyRef = destroyRef;
        this.cdr = cdr;
        try {
            window.addEventListener('test', null, Object.defineProperty({}, 'passive', {
                get: () => {
                    this.#isPassiveSupported = { passive: true };
                },
            }));
        }
        catch (err) { }
    }
    ngAfterViewInit() {
        if (this.rightMap && this.leftMap && !this.isInitialisationStarted) {
            this.subscribeToMapLoad();
        }
    }
    subscribeToMapLoad() {
        zip([this.rightMap.onLoad$, this.leftMap.onLoad$])
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => {
            this.initialiseComponent();
            setTimeout(() => {
                this.isInitialised = true;
                this.cdr.detectChanges();
            });
        });
    }
    initialiseComponent() {
        this.usedOptions = { ...this.defaultOptions, ...this.options };
        this.isVertical = this.usedOptions.orientation === 'vertical';
        setTimeout(() => {
            this.initializeSideBySide();
            this.initializeEventListeners();
        });
        this.initializeResizeObserver();
    }
    initializeSideBySide() {
        this.currentDragPosition = {
            top: this.isVertical ? 0 : this.getHeightMidpoint(),
            left: this.isVertical ? this.getWidthMidpoint() : 0,
        };
        this.calculateDragRatio();
        this.setDragPositionAndClip();
    }
    calculateDragRatio() {
        this.dragLeftRatio =
            this.currentDragPosition.left / this.getMapContainerWidth();
    }
    getMapContainerWidth() {
        return this.mapContainer.getBoundingClientRect().width;
    }
    getMapContainerHeight() {
        return this.mapContainer.getBoundingClientRect().height;
    }
    getWidthMidpoint() {
        return this.getMapContainerWidth() / 2 - this.getDragContainerWidthOffset();
    }
    getHeightMidpoint() {
        return (this.getMapContainerHeight() / 2 - this.getDragContainerWidthOffset());
    }
    getDragWidthOffset() {
        return this.drag.nativeElement.offsetWidth / 2;
    }
    getDragHeightOffset() {
        return this.drag.nativeElement.offsetHeight / 2;
    }
    getDragContainerWidthOffset() {
        return this.dragContainer.nativeElement.offsetWidth / 2;
    }
    getDragContainerHeightOffset() {
        return this.dragContainer.nativeElement.offsetHeight / 2;
    }
    setDragPositionAndClip() {
        if (this.leftMap?.map && this.rightMap?.map) {
            this.setTransform(this.currentDragPosition.left, this.currentDragPosition.top);
            this.renderer.setStyle(this.leftMap.elementRef.nativeElement, 'clipPath', this.getLeftMapClip());
            this.renderer.setStyle(this.rightMap.elementRef.nativeElement, 'clipPath', this.getRightMapClip());
            this.setLeftLabelPosition();
        }
        else {
            console.warn('Tried to initialize side by side without maps');
        }
    }
    setTransform(x, y) {
        this.renderer.setStyle(this.dragContainer.nativeElement, 'transform', `translate(${x}px, ${y}px)`);
    }
    getLeftMapClip() {
        let clip = '';
        if (this.isVertical) {
            const mapWidth = this.getMapContainerWidth();
            const percentage = ((this.currentDragPosition.left + this.getDragContainerWidthOffset()) /
                mapWidth) *
                100;
            clip = `polygon(0 0, ${percentage}% 0, ${percentage}% 100%, 0% 100%)`;
        }
        else {
            const mapHeight = this.getMapContainerHeight();
            const percentage = ((this.currentDragPosition.top - this.getDragContainerHeightOffset()) /
                mapHeight) *
                100;
            clip = `polygon(0 ${percentage}%, 100% ${percentage}%, 100% 100%, 0% 100%)`;
        }
        return clip;
    }
    getRightMapClip() {
        let clip = '';
        if (this.isVertical) {
            const mapWidth = this.getMapContainerWidth();
            const percentage = ((this.currentDragPosition.left + this.getDragContainerWidthOffset()) /
                mapWidth) *
                100;
            clip = `polygon(${percentage}% 0%, 100% 0%, 100% 100%, ${percentage}% 100%)`;
        }
        else {
            const mapHeight = this.getMapContainerHeight();
            const percentage = ((this.currentDragPosition.top - this.getDragContainerHeightOffset()) /
                mapHeight) *
                100;
            clip = `polygon(0% 100%, 100% 100%, 100% ${percentage}%, 0% ${percentage}%)`;
        }
        return clip;
    }
    initializeEventListeners() {
        this.unlisteners.push(this.renderer.listen(this.dragContainer.nativeElement, 'mousedown', this.onMouseDown.bind(this)));
        this.unlisteners.push(this.renderer.listen(this.dragContainer.nativeElement, 'touchstart', this.onMouseDown.bind(this)));
        this.unlisteners.push(this.renderer.listen(this.document, 'mouseup', this.onMouseUp.bind(this)));
        this.unlisteners.push(this.renderer.listen(this.document, 'touchend', this.onMouseUp.bind(this)));
        this.unlisteners.push(this.renderer.listen(this.document, 'mousemove', this.onMouseMove.bind(this)));
        this.unlisteners.push(this.renderer.listen(this.document, 'touchmove', this.onMouseMove.bind(this)));
    }
    onMouseDown(event) {
        this.renderer.addClass(this.document.body, 'user-select-none');
        this.isDragging = true;
        const clientX = event instanceof MouseEvent ? event.clientX : event.touches[0].clientX;
        const clientY = event instanceof MouseEvent ? event.clientY : event.touches[0].clientY;
        const dragBbox = this.dragContainer.nativeElement.getBoundingClientRect();
        this.offsetAtDragStart = this.isVertical
            ? clientX - dragBbox.left
            : clientY - dragBbox.top;
        this.clicked.emit(event);
    }
    onMouseUp(event) {
        this.renderer.removeClass(this.document.body, 'user-select-none');
        this.isDragging = false;
        this.released.emit(event);
    }
    onMouseMove(event) {
        if (this.isDragging &&
            (event instanceof MouseEvent ||
                (window.TouchEvent && event instanceof TouchEvent))) {
            event.stopPropagation();
            if (!this.#isPassiveSupported.passive) {
                event.preventDefault();
                event.returnValue = false;
            }
            event.cancelBubble = true;
            const clientX = event instanceof MouseEvent ? event.clientX : event.touches[0].clientX;
            this.dragged.emit(event);
            const mapBbox = this.mapContainer.getBoundingClientRect();
            const left = clientX -
                mapBbox.left -
                this.getDragWidthOffset() -
                this.offsetAtDragStart;
            const containerWidth = this.dragContainer.nativeElement.getBoundingClientRect().width;
            const isLeftEdge = left < containerWidth / 2;
            const isRightEdge = left + containerWidth > mapBbox.width;
            if (isLeftEdge || isRightEdge) {
                return;
            }
            this.currentDragPosition = {
                top: 0,
                left,
            };
            this.calculateDragRatio();
            this.setDragPositionAndClip();
        }
    }
    setLeftLabelPosition() {
        if (!this.imageLabelLeft) {
            return;
        }
        const left = this.currentDragPosition.left -
            this.imageLabelLeft.nativeElement.getBoundingClientRect().width +
            this.getDragContainerWidthOffset() -
            this.getDragWidthOffset();
        this.renderer.setStyle(this.imageLabelLeft.nativeElement, 'transform', `translate(${left}px, ${0}px)`);
    }
    resizeSideBySide() {
        const mapContainerWidth = this.getMapContainerWidth();
        let newLeft = mapContainerWidth * this.dragLeftRatio;
        const leftEdge = this.getDragContainerWidthOffset();
        const rightEdge = mapContainerWidth - this.getDragContainerWidthOffset();
        if (newLeft < leftEdge) {
            newLeft = leftEdge;
        }
        else if (newLeft > rightEdge) {
            newLeft = rightEdge;
        }
        this.currentDragPosition = {
            left: newLeft,
            top: this.currentDragPosition.top,
        };
        this.setDragPositionAndClip();
    }
    initializeResizeObserver() {
        this.resizeObserver = new ResizeObserver(() => {
            this.resizeSideBySide();
        });
        this.resizeObserver.observe(this.mapContainer);
    }
    ngOnDestroy() {
        for (const unlistener of this.unlisteners) {
            unlistener();
        }
        if (this.resizeObserver) {
            this.resizeObserver.unobserve(this.mapContainer);
        }
    }
    ngOnChanges(changes) {
        if ('leftMap' in changes) {
            this.leftMap = changes['leftMap'].currentValue;
        }
        if ('rightMap' in changes) {
            this.rightMap = changes['rightMap'].currentValue;
        }
        if (this.rightMap && this.leftMap && !this.isInitialisationStarted) {
            this.subscribeToMapLoad();
        }
        this.cdr.detectChanges();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: MapboxSideBySideComponent, deps: [{ token: i0.Renderer2 }, { token: DOCUMENT }, { token: i0.DestroyRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: MapboxSideBySideComponent, isStandalone: true, selector: "mapbox-side-by-side", inputs: { leftMap: "leftMap", rightMap: "rightMap", mapContainer: "mapContainer", options: "options", leftLabelTemplate: "leftLabelTemplate", rightLabelTemplate: "rightLabelTemplate" }, outputs: { dragged: "dragged", clicked: "clicked", released: "released" }, viewQueries: [{ propertyName: "dragContainer", first: true, predicate: ["dragContainer"], descendants: true }, { propertyName: "drag", first: true, predicate: ["drag"], descendants: true }, { propertyName: "imageLabelRight", first: true, predicate: ["imageLabelRight"], descendants: true }, { propertyName: "imageLabelLeft", first: true, predicate: ["imageLabelLeft"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"side-by-side-wrapper\" [ngClass]=\"{'no-show': !isInitialised}\">\n  <div\n    class=\"drag-container\"\n    #dragContainer\n    [ngClass]=\"{ vertical: isVertical, horizontal: !isVertical }\"\n    >\n    <div class=\"drag shadow\" #drag></div>\n    <div class=\"drag-caret-container\">\n      <oui-icon\n        icon=\"assets/icons/caret-left.svg\"\n        [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n        class=\"drag-caret-left\"\n      ></oui-icon>\n      <oui-icon\n        icon=\"assets/icons/caret-right.svg\"\n        [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n        class=\"drag-caret-right\"\n      ></oui-icon>\n    </div>\n  </div>\n\n  @if (leftLabelTemplate) {\n    <div class=\"side-by-side-label-wrapper left\">\n      <ng-content *ngTemplateOutlet=\"leftLabelTemplate\"></ng-content>\n    </div>\n  }\n\n  @if (rightLabelTemplate) {\n    <div class=\"side-by-side-label-wrapper right\">\n      <ng-content *ngTemplateOutlet=\"rightLabelTemplate\"></ng-content>\n    </div>\n  }\n</div>\n", styles: [":host{width:100%;height:100%}:host .side-by-side-wrapper{width:100%;height:100%;opacity:1;transition:opacity .3s}:host .side-by-side-wrapper.no-show{opacity:0;pointer-events:none;transition:opacity 0s}:host .side-by-side-wrapper .drag-container{position:absolute;width:var(--mapbox-side-by-side-caret-container-width)}:host .side-by-side-wrapper .drag-container .drag-caret-container{display:flex;justify-content:space-between;align-items:center;position:absolute;border-width:var(--oui-mapbox-side-by-side-caret-container-border-width);border-style:var(--oui-mapbox-side-by-side-caret-container-border-style);border-color:var(--oui-mapbox-side-by-side-caret-container-border-color);height:var(--mapbox-side-by-side-caret-container-height);width:var(--mapbox-side-by-side-caret-container-width);background-color:var(--mapbox-side-by-side-caret-container-background-color);border-radius:var(--mapbox-side-by-side-caret-container-border-radius)}:host .side-by-side-wrapper .drag-container .drag-caret-container oui-icon{filter:var(--oui-mapbox-side-by-side-caret-icon-filter)}:host .side-by-side-wrapper .drag-container:hover{cursor:col-resize}:host .side-by-side-wrapper .drag-container.vertical{height:100%;width:40px;display:flex;justify-content:center;align-items:center}:host .side-by-side-wrapper .drag-container.vertical .drag{width:var(--mapbox-side-by-side-drag-width);background-color:var(--mapbox-side-by-side-drag-background-color);border:solid var(--border-color-primary);border-width:0 1px;height:100%}:host .side-by-side-wrapper .drag-container.horizontal{width:100%;height:40px;display:flex;justify-content:center}:host .side-by-side-wrapper .drag-container.horizontal .drag{height:4px;background-color:#fff;width:100%}:host .side-by-side-wrapper .side-by-side-dropdown{display:flex;align-items:center;position:absolute;top:20px;right:0;width:110px;height:24px;justify-content:center;-webkit-user-select:none;user-select:none}:host .side-by-side-wrapper .side-by-side-dropdown.left{left:0;right:auto}:host .side-by-side-wrapper .side-by-side-label-wrapper{display:flex;align-items:center;position:absolute;top:2rem;flex:0;min-height:3rem;-webkit-user-select:none;user-select:none;font-size:var(--font-size-body-smaller);border-radius:var(--border-radius-default);color:var(--color-dark)}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-content{line-height:1px}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-icon{margin-right:10px}:host .side-by-side-wrapper .side-by-side-label-wrapper.left{z-index:1;right:var(--oui-mapbox-side-by-side-left-label-left)}:host .side-by-side-wrapper .side-by-side-label-wrapper.right{z-index:0;right:var(--oui-mapbox-side-by-side-right-label-right)}:host .side-by-side-wrapper .side-by-side-label-wrapper.right.has-geolocate{right:5rem;margin-right:1rem}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1$1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: MapboxSideBySideComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mapbox-side-by-side', standalone: true, imports: [OuiIconComponent, CommonModule], template: "<div class=\"side-by-side-wrapper\" [ngClass]=\"{'no-show': !isInitialised}\">\n  <div\n    class=\"drag-container\"\n    #dragContainer\n    [ngClass]=\"{ vertical: isVertical, horizontal: !isVertical }\"\n    >\n    <div class=\"drag shadow\" #drag></div>\n    <div class=\"drag-caret-container\">\n      <oui-icon\n        icon=\"assets/icons/caret-left.svg\"\n        [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n        class=\"drag-caret-left\"\n      ></oui-icon>\n      <oui-icon\n        icon=\"assets/icons/caret-right.svg\"\n        [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n        class=\"drag-caret-right\"\n      ></oui-icon>\n    </div>\n  </div>\n\n  @if (leftLabelTemplate) {\n    <div class=\"side-by-side-label-wrapper left\">\n      <ng-content *ngTemplateOutlet=\"leftLabelTemplate\"></ng-content>\n    </div>\n  }\n\n  @if (rightLabelTemplate) {\n    <div class=\"side-by-side-label-wrapper right\">\n      <ng-content *ngTemplateOutlet=\"rightLabelTemplate\"></ng-content>\n    </div>\n  }\n</div>\n", styles: [":host{width:100%;height:100%}:host .side-by-side-wrapper{width:100%;height:100%;opacity:1;transition:opacity .3s}:host .side-by-side-wrapper.no-show{opacity:0;pointer-events:none;transition:opacity 0s}:host .side-by-side-wrapper .drag-container{position:absolute;width:var(--mapbox-side-by-side-caret-container-width)}:host .side-by-side-wrapper .drag-container .drag-caret-container{display:flex;justify-content:space-between;align-items:center;position:absolute;border-width:var(--oui-mapbox-side-by-side-caret-container-border-width);border-style:var(--oui-mapbox-side-by-side-caret-container-border-style);border-color:var(--oui-mapbox-side-by-side-caret-container-border-color);height:var(--mapbox-side-by-side-caret-container-height);width:var(--mapbox-side-by-side-caret-container-width);background-color:var(--mapbox-side-by-side-caret-container-background-color);border-radius:var(--mapbox-side-by-side-caret-container-border-radius)}:host .side-by-side-wrapper .drag-container .drag-caret-container oui-icon{filter:var(--oui-mapbox-side-by-side-caret-icon-filter)}:host .side-by-side-wrapper .drag-container:hover{cursor:col-resize}:host .side-by-side-wrapper .drag-container.vertical{height:100%;width:40px;display:flex;justify-content:center;align-items:center}:host .side-by-side-wrapper .drag-container.vertical .drag{width:var(--mapbox-side-by-side-drag-width);background-color:var(--mapbox-side-by-side-drag-background-color);border:solid var(--border-color-primary);border-width:0 1px;height:100%}:host .side-by-side-wrapper .drag-container.horizontal{width:100%;height:40px;display:flex;justify-content:center}:host .side-by-side-wrapper .drag-container.horizontal .drag{height:4px;background-color:#fff;width:100%}:host .side-by-side-wrapper .side-by-side-dropdown{display:flex;align-items:center;position:absolute;top:20px;right:0;width:110px;height:24px;justify-content:center;-webkit-user-select:none;user-select:none}:host .side-by-side-wrapper .side-by-side-dropdown.left{left:0;right:auto}:host .side-by-side-wrapper .side-by-side-label-wrapper{display:flex;align-items:center;position:absolute;top:2rem;flex:0;min-height:3rem;-webkit-user-select:none;user-select:none;font-size:var(--font-size-body-smaller);border-radius:var(--border-radius-default);color:var(--color-dark)}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-content{line-height:1px}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-icon{margin-right:10px}:host .side-by-side-wrapper .side-by-side-label-wrapper.left{z-index:1;right:var(--oui-mapbox-side-by-side-left-label-left)}:host .side-by-side-wrapper .side-by-side-label-wrapper.right{z-index:0;right:var(--oui-mapbox-side-by-side-right-label-right)}:host .side-by-side-wrapper .side-by-side-label-wrapper.right.has-geolocate{right:5rem;margin-right:1rem}\n"] }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.DestroyRef }, { type: i0.ChangeDetectorRef }], propDecorators: { leftMap: [{
                type: Input,
                args: [{ required: true }]
            }], rightMap: [{
                type: Input,
                args: [{ required: true }]
            }], mapContainer: [{
                type: Input,
                args: [{ required: true }]
            }], options: [{
                type: Input
            }], leftLabelTemplate: [{
                type: Input
            }], rightLabelTemplate: [{
                type: Input
            }], dragged: [{
                type: Output
            }], clicked: [{
                type: Output
            }], released: [{
                type: Output
            }], dragContainer: [{
                type: ViewChild,
                args: ['dragContainer']
            }], drag: [{
                type: ViewChild,
                args: ['drag']
            }], imageLabelRight: [{
                type: ViewChild,
                args: ['imageLabelRight']
            }], imageLabelLeft: [{
                type: ViewChild,
                args: ['imageLabelLeft']
            }] } });

class DeckSideBySideComponent {
    renderer;
    document;
    destroyRef;
    cdr;
    elementRef;
    leftLabelTemplate;
    rightLabelTemplate;
    mapContainer;
    map;
    clipChange = new EventEmitter();
    dragged = new EventEmitter();
    clicked = new EventEmitter();
    released = new EventEmitter();
    dragContainer;
    drag;
    imageLabelRight;
    imageLabelLeft;
    thumbIconTemplate;
    mapContent;
    draggable;
    mapsWrapper;
    gammaMaskRight;
    gammaMaskLeft;
    currentDragPosition = {
        x: 0,
        y: 0,
    };
    resizeObserver;
    dragLeftRatio = 0;
    isInitialisationStarted = false;
    refreshInterval;
    debouncedEndClip = debounce(this.getClipAndEmit.bind(this), 50);
    unlisteners = [];
    mapListeners = {
        movestart: this.startClipping.bind(this),
        move: this.storeBounds.bind(this),
        moveend: this.endClipping.bind(this),
    };
    isInitialised = false;
    isVertical = true;
    beforeGamma = signal(1);
    afterGamma = signal(1);
    gammaSliderOptions = signal({
        min: 0.01,
        max: 2,
        minLabel: '',
        maxLabel: '',
    });
    currentBounds;
    constructor(renderer, document, destroyRef, cdr, elementRef) {
        this.renderer = renderer;
        this.document = document;
        this.destroyRef = destroyRef;
        this.cdr = cdr;
        this.elementRef = elementRef;
    }
    ngAfterViewInit() {
        this.gammaSliderOptions.set({
            min: 0.01,
            max: 2,
            minLabel: '',
            maxLabel: '',
            thumbContentTemplate: this.thumbIconTemplate,
        });
        if (this.map) {
            if (!this.isInitialisationStarted) {
                this.subscribeToMapLoad();
            }
        }
        this.cdr.detectChanges();
    }
    initDraggable() {
        this.draggable.addDefaultBehavior();
        this.draggable.addContainerConstraint({
            container: this.mapsWrapper.nativeElement,
            anchor: 'edge',
        });
        this.currentDragPosition = {
            x: this.getMapContainerWidth() / 2 - this.getDragContainerWidthOffset(),
            y: 0,
        };
        this.draggable.updateTransform(this.currentDragPosition);
        this.dragLeftRatio =
            this.currentDragPosition.x / this.getMapContainerWidth();
    }
    subscribeToMapLoad() {
        this.isInitialisationStarted = true;
        this.map.onLoad$
            .pipe(takeUntilDestroyed(this.destroyRef), take(1))
            .subscribe(() => {
            this.initialiseComponent();
            setTimeout(() => {
                this.isInitialised = true;
                this.cdr.detectChanges();
            });
        });
    }
    initialiseComponent() {
        this.mapContent.nativeElement.style.filter = `url('#gammaFilter')`;
        setTimeout(() => {
            this.initDraggable();
            this.initializeEventListeners();
        });
        this.initializeResizeObserver();
    }
    getMapContainerWidth() {
        return this.mapContainer.getBoundingClientRect().width;
    }
    getMapContainerHeight() {
        return this.mapContainer.getBoundingClientRect().height;
    }
    getDragWidthOffset() {
        return this.drag.nativeElement.offsetWidth / 2;
    }
    getDragHeightOffset() {
        return this.drag.nativeElement.offsetHeight / 2;
    }
    getDragContainerWidthOffset() {
        return this.dragContainer.nativeElement.offsetWidth / 2;
    }
    getDragContainerHeightOffset() {
        return this.dragContainer.nativeElement.offsetHeight / 2;
    }
    getClip() {
        if (!this.map.map) {
            return;
        }
        if (!this.currentBounds) {
            this.currentBounds = this.map.map?.getBounds();
        }
        const left = this.dragContainer.nativeElement.getBoundingClientRect().left -
            this.mapsWrapper.nativeElement.getBoundingClientRect().left +
            this.getDragContainerWidthOffset();
        const dragLongitude = this.map.projectXyToLngLat([left, 0]).lng;
        const topLatitude = Math.min(this.currentBounds._ne.lat + 0.1, 85);
        const bottomLatitude = Math.max(this.currentBounds._sw.lat - 0.1, -85);
        return {
            left: {
                type: 'FeatureCollection',
                features: [
                    {
                        type: 'Feature',
                        properties: {},
                        geometry: {
                            coordinates: [
                                [
                                    [dragLongitude, bottomLatitude],
                                    [dragLongitude, topLatitude],
                                    [this.currentBounds._sw.lng - 0.1, topLatitude],
                                    [this.currentBounds._sw.lng - 0.1, bottomLatitude],
                                    [dragLongitude, bottomLatitude],
                                ],
                            ],
                            type: 'Polygon',
                        },
                    },
                ],
            },
            right: {
                type: 'FeatureCollection',
                features: [
                    {
                        type: 'Feature',
                        properties: {},
                        geometry: {
                            coordinates: [
                                [
                                    [dragLongitude, bottomLatitude],
                                    [dragLongitude, topLatitude],
                                    [this.currentBounds._ne.lng + 0.1, topLatitude],
                                    [this.currentBounds._ne.lng + 0.1, bottomLatitude],
                                    [dragLongitude, bottomLatitude],
                                ],
                            ],
                            type: 'Polygon',
                        },
                    },
                ],
            },
        };
    }
    initializeEventListeners() {
        this.currentBounds = this.map.map.getBounds();
        if (this.map.deck.isInterleaved && this.map.map) {
            this.map.map.on('movestart', this.mapListeners['movestart']);
            this.map.map.on('moveend', this.mapListeners['moveend']);
            this.map.map.on('move', this.mapListeners['move']);
        }
        else {
            this.map.deck.viewStateChange$
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe(data => {
                this.currentBounds = data.viewState.bounds;
                this.clipChange.emit(this.getClip());
                this.debouncedEndClip();
            });
        }
    }
    storeBounds(event) {
        this.currentBounds = this.map.map.getBounds();
    }
    getClipAndEmit() {
        this.clipChange.emit(this.getClip());
    }
    onDragMove(event) {
        if ('currentTranslate' in event) {
            const wrapperBbox = this.mapsWrapper.nativeElement.getBoundingClientRect();
            const width = wrapperBbox.width;
            const leftWidth = ((event.currentTranslate.x + this.getDragContainerWidthOffset()) /
                width) *
                100;
            const rightWidth = 100 - leftWidth;
            const rightLeft = event.currentTranslate.x + this.getDragContainerWidthOffset();
            this.renderer.setAttribute(this.gammaMaskLeft.nativeElement, 'width', `${leftWidth}%`);
            this.renderer.setAttribute(this.gammaMaskRight.nativeElement, 'width', `${rightWidth}%`);
            this.renderer.setAttribute(this.gammaMaskRight.nativeElement, 'x', `${(rightLeft / width) * 100}%`);
            this.clipChange.emit(this.getClip());
            this.currentDragPosition = {
                x: event.currentTranslate.x,
                y: event.currentTranslate.y,
            };
            this.dragLeftRatio =
                this.currentDragPosition.x / this.getMapContainerWidth();
            this.debouncedEndClip();
        }
    }
    onDragEnd() {
        this.debouncedEndClip();
    }
    setLeftLabelPosition() {
        if (!this.imageLabelLeft) {
            return;
        }
        const left = this.currentDragPosition.x -
            this.imageLabelLeft.nativeElement.getBoundingClientRect().width +
            this.getDragContainerWidthOffset() -
            this.getDragWidthOffset();
        this.renderer.setStyle(this.imageLabelLeft.nativeElement, 'transform', `translate(${left}px, ${0}px)`);
    }
    resizeSideBySide() {
        const mapContainerWidth = this.getMapContainerWidth();
        let newLeft = mapContainerWidth * this.dragLeftRatio;
        const leftEdge = this.getDragContainerWidthOffset();
        const rightEdge = mapContainerWidth - this.getDragContainerWidthOffset();
        if (newLeft < leftEdge) {
            newLeft = leftEdge;
        }
        else if (newLeft > rightEdge) {
            newLeft = rightEdge;
        }
        this.currentDragPosition = {
            x: newLeft,
            y: this.currentDragPosition.y,
        };
        this.draggable.updateTransform(this.currentDragPosition);
        this.clipChange.emit(this.getClip());
    }
    initializeResizeObserver() {
        this.resizeObserver = new ResizeObserver(() => {
            this.resizeSideBySide();
        });
        this.resizeObserver.observe(this.mapContainer);
    }
    startClipping() {
        if (this.refreshInterval) {
            return;
        }
        this.refreshInterval = setInterval(() => {
            this.clipChange.emit(this.getClip());
        }, 20);
    }
    endClipping() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = undefined;
            setTimeout(() => {
                this.clipChange.emit(this.getClip());
            });
        }
    }
    onBeforeGammaChange(value) {
        this.beforeGamma.set(value);
        const filters = this.elementRef.nativeElement.querySelectorAll('.beforeGammaElement');
        for (const filter of filters) {
            filter.setAttribute('amplitude', `${value}`);
            filter.setAttribute('exponent', `${1 / value}`);
            // filter.setAttribute('offset', `${(value - 1) / 5}`);
        }
    }
    onAfterGammaChange(value) {
        this.afterGamma.set(value);
        const filters = this.elementRef.nativeElement.querySelectorAll('.afterGammaElement');
        for (const filter of filters) {
            // filter.setAttribute('amplitude', `${value}`);
            filter.setAttribute('exponent', `${1 / value}`);
            // filter.setAttribute('offset', `${(value - 1) / 5}`);
        }
    }
    ngOnDestroy() {
        for (const unlistener of this.unlisteners) {
            unlistener();
        }
        if (this.resizeObserver) {
            this.resizeObserver.unobserve(this.mapContainer);
        }
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }
        if (this.map?.map) {
            for (let listener in this.mapListeners) {
                this.map.map.off(listener, this.mapListeners[listener]);
                this.map.map.off(listener, this.mapListeners[listener]);
            }
        }
    }
    ngOnChanges(changes) {
        if ('map' in changes) {
            this.map = changes['map'].currentValue;
            if (this.map && !this.isInitialisationStarted && this.mapContent) {
                this.subscribeToMapLoad();
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckSideBySideComponent, deps: [{ token: i0.Renderer2 }, { token: DOCUMENT }, { token: i0.DestroyRef }, { token: i0.ChangeDetectorRef }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckSideBySideComponent, isStandalone: true, selector: "oui-deck-side-by-side", inputs: { leftLabelTemplate: "leftLabelTemplate", rightLabelTemplate: "rightLabelTemplate", mapContainer: "mapContainer", map: "map" }, outputs: { clipChange: "clipChange", dragged: "dragged", clicked: "clicked", released: "released" }, viewQueries: [{ propertyName: "dragContainer", first: true, predicate: ["dragContainer"], descendants: true }, { propertyName: "drag", first: true, predicate: ["drag"], descendants: true }, { propertyName: "imageLabelRight", first: true, predicate: ["imageLabelRight"], descendants: true }, { propertyName: "imageLabelLeft", first: true, predicate: ["imageLabelLeft"], descendants: true }, { propertyName: "thumbIconTemplate", first: true, predicate: ["thumbIconTemplate"], descendants: true }, { propertyName: "mapContent", first: true, predicate: ["mapContent"], descendants: true }, { propertyName: "draggable", first: true, predicate: ["draggable"], descendants: true }, { propertyName: "mapsWrapper", first: true, predicate: ["mapsWrapper"], descendants: true }, { propertyName: "gammaMaskRight", first: true, predicate: ["gammaMaskRight"], descendants: true }, { propertyName: "gammaMaskLeft", first: true, predicate: ["gammaMaskLeft"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"side-by-side-wrapper\" [ngClass]=\"{'initialised': isInitialised}\">\n  <div class=\"maps-wrapper\" #mapsWrapper>\n    <div\n        oui-draggable\n        (dragMove)=\"onDragMove($event)\"\n        (dragEnd)=\"onDragEnd()\"\n        #draggable=\"OuiDraggableDirective\"\n        class=\"drag-container\"\n        #dragContainer\n        [ngClass]=\"{ vertical: isVertical, horizontal: !isVertical }\"\n    >\n      <div class=\"drag shadow\" #drag></div>\n      <div class=\"drag-caret-container\">\n        <oui-icon\n            icon=\"assets/icons/caret-left.svg\"\n            [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n            class=\"drag-caret-left\"\n        ></oui-icon>\n        <oui-icon\n            icon=\"assets/icons/caret-right.svg\"\n            [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n            class=\"drag-caret-right\"\n        ></oui-icon>\n      </div>\n    </div>\n    <div class=\"map-content\" #mapContent>\n      <svg class=\"gamma-mask-svg\">\n        <filter id=\"gammaFilter\" primitiveUnits=\"objectBoundingBox\" width=\"100%\" height=\"100%\" x=\"0\" y=\"0\">\n          <feColorMatrix result=\"CURRENT\"></feColorMatrix>\n          <feComponentTransfer #gammaMaskLeft result=\"LEFT\" x=\"0%\" width=\"50%\" height=\"100%\" y=\"0%\">\n            <feFuncR\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n            <feFuncG\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n            <feFuncB\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n          </feComponentTransfer>\n          <feComposite in2=\"CURRENT\" in=\"LEFT\" operator=\"over\" result=\"CURRENT\"></feComposite>\n          <feComponentTransfer #gammaMaskRight result=\"RIGHT\" x=\"50%\" width=\"50%\" height=\"100%\" y=\"0%\">\n            <feFuncR\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n            <feFuncG\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n            <feFuncB\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n          </feComponentTransfer>\n\n          <feComposite in2=\"CURRENT\" in=\"RIGHT\" operator=\"over\" result=\"COMPOSITE\">\n\n          </feComposite>\n<!--          <feComposite in2=\"SourceGraphic\" in=\"FIRST_COMPOSITE\" operator=\"over\" result=\"FIRST_COMBINED_COMPOSITE\">-->\n\n<!--          </feComposite>-->\n<!--          <feComposite in2=\"FIRST_COMBINED_COMPOSITE\" in=\"SECOND\" operator=\"over\" result=\"SECOND_COMPOSITE\">-->\n\n<!--          </feComposite>-->\n<!--          <feComposite in2=\"FIRST_COMBINED_COMPOSITE\" in=\"SECOND_COMPOSITE\" operator=\"in\"></feComposite>-->\n        </filter>\n      </svg>\n\n      <ng-content>\n\n      </ng-content>\n    </div>\n\n\n<!--    <div class=\"side-by-side-label-wrapper left\" *ngIf=\"leftLabelTemplate\">-->\n<!--      <ng-content *ngTemplateOutlet=\"leftLabelTemplate\"></ng-content>-->\n<!--    </div>-->\n\n<!--    <div class=\"side-by-side-label-wrapper right\" [ngClass]=\"{'has-geolocate': map?.options?.geoLocateControl}\" *ngIf=\"rightLabelTemplate\">-->\n<!--      <ng-content *ngTemplateOutlet=\"rightLabelTemplate\"></ng-content>-->\n<!--    </div>-->\n\n  </div>\n  <div class=\"gamma-slider-wrapper\">\n    <div class=\"gamma-slider left\">\n      <oui-slider [options]=\"gammaSliderOptions()\" [value]=\"beforeGamma()\" (valueChange)=\"onBeforeGammaChange($event)\"\n      ></oui-slider>\n    </div>\n    <div class=\"gamma-slider right\">\n      <oui-slider\n          [options]=\"gammaSliderOptions()\"\n          [value]=\"afterGamma()\"\n          (valueChange)=\"onAfterGammaChange($event)\"\n      ></oui-slider>\n    </div>\n\n    <ng-template #thumbIconTemplate>\n      <oui-icon  [icon]=\"'assets/icons/brightness.svg'\"\n                 [options]=\"{\n    viewBox: '0 0 48 48',\n    size: '13px',\n    fillColor: 'color-background-primary-text',\n    strokeColor: 'color-background-primary-text',\n    }\">\n\n      </oui-icon>\n    </ng-template>\n  </div>\n\n\n</div>\n", styles: [":host{width:100%;height:100%;position:absolute;top:0;left:0;z-index:1;pointer-events:none}:host .gamma-mask-svg{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:-9999}:host .side-by-side-wrapper{width:100%;height:100%;opacity:0;transition:opacity .3s;pointer-events:none;display:flex;flex-direction:column}:host .side-by-side-wrapper .gamma-slider-wrapper{display:flex;height:5rem;justify-content:space-around;pointer-events:all;--oui-slider-thumb-color-primary: var(--color-background-primary);--oui-slider-thumb-border-radius: 50%;--oui-slider-thumb-width: 20px;--oui-slider-thumb-height: 20px;--oui-slider-thumb-color-primary-hover: var(--color-background-primary-hover)}:host .side-by-side-wrapper .gamma-slider-wrapper .gamma-slider{width:25%;height:100%}:host .side-by-side-wrapper .maps-wrapper{height:100%;width:100%;flex:1;position:relative;overflow:hidden}:host .side-by-side-wrapper .maps-wrapper .map-content{height:100%;width:100%;position:relative}:host .side-by-side-wrapper .maps-wrapper .drag-container{position:absolute;width:var(--mapbox-side-by-side-caret-container-width);pointer-events:all;z-index:2;cursor:col-resize}:host .side-by-side-wrapper .maps-wrapper .drag-container .drag-caret-container{display:flex;justify-content:space-between;align-items:center;position:absolute;border-width:var(--oui-mapbox-side-by-side-caret-container-border-width);border-style:var(--oui-mapbox-side-by-side-caret-container-border-style);border-color:var(--oui-mapbox-side-by-side-caret-container-border-color);height:var(--mapbox-side-by-side-caret-container-height);width:var(--mapbox-side-by-side-caret-container-width);background-color:var(--mapbox-side-by-side-caret-container-background-color);border-radius:var(--mapbox-side-by-side-caret-container-border-radius)}:host .side-by-side-wrapper .maps-wrapper .drag-container .drag-caret-container oui-icon{filter:var(--oui-mapbox-side-by-side-caret-icon-filter)}:host .side-by-side-wrapper .maps-wrapper .drag-container:hover{cursor:col-resize}:host .side-by-side-wrapper .maps-wrapper .drag-container.vertical{height:100%;width:40px;display:flex;justify-content:center;align-items:center}:host .side-by-side-wrapper .maps-wrapper .drag-container.vertical .drag{width:var(--mapbox-side-by-side-drag-width);background-color:var(--mapbox-side-by-side-drag-background-color);border:solid var(--border-color-primary);border-width:0 1px;height:100%}:host .side-by-side-wrapper .maps-wrapper .drag-container.horizontal{width:100%;height:40px;display:flex;justify-content:center}:host .side-by-side-wrapper .maps-wrapper .drag-container.horizontal .drag{height:4px;background-color:#fff;width:100%}:host .side-by-side-wrapper.initialised{opacity:1}:host .side-by-side-wrapper .side-by-side-label-wrapper{display:flex;align-items:center;position:absolute;top:2rem;flex:0;min-height:3rem;-webkit-user-select:none;user-select:none;font-size:var(--font-size-body-smaller);border-radius:var(--border-radius-default);color:var(--color-dark)}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-content{line-height:1px}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-icon{margin-right:10px}:host .side-by-side-wrapper .side-by-side-label-wrapper.left{z-index:1;left:1rem}:host .side-by-side-wrapper .side-by-side-label-wrapper.right{z-index:0;right:1rem}:host .side-by-side-wrapper .side-by-side-label-wrapper.right.has-geolocate{right:5rem;margin-right:1rem}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1$1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: OuiSliderComponent, selector: "oui-slider", inputs: ["value", "valueTo", "options"], outputs: ["valueChange", "valueToChange", "debouncedvalueChange", "debouncedValueToChange"] }, { kind: "directive", type: OuiDraggableDirective, selector: "[oui-draggable]", outputs: ["dragMove", "dragStart", "dragEnd"], exportAs: ["OuiDraggableDirective"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckSideBySideComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-deck-side-by-side', standalone: true, imports: [
                        OuiIconComponent,
                        CommonModule,
                        OuiSliderComponent,
                        OuiDraggableDirective,
                    ], template: "<div class=\"side-by-side-wrapper\" [ngClass]=\"{'initialised': isInitialised}\">\n  <div class=\"maps-wrapper\" #mapsWrapper>\n    <div\n        oui-draggable\n        (dragMove)=\"onDragMove($event)\"\n        (dragEnd)=\"onDragEnd()\"\n        #draggable=\"OuiDraggableDirective\"\n        class=\"drag-container\"\n        #dragContainer\n        [ngClass]=\"{ vertical: isVertical, horizontal: !isVertical }\"\n    >\n      <div class=\"drag shadow\" #drag></div>\n      <div class=\"drag-caret-container\">\n        <oui-icon\n            icon=\"assets/icons/caret-left.svg\"\n            [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n            class=\"drag-caret-left\"\n        ></oui-icon>\n        <oui-icon\n            icon=\"assets/icons/caret-right.svg\"\n            [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n            class=\"drag-caret-right\"\n        ></oui-icon>\n      </div>\n    </div>\n    <div class=\"map-content\" #mapContent>\n      <svg class=\"gamma-mask-svg\">\n        <filter id=\"gammaFilter\" primitiveUnits=\"objectBoundingBox\" width=\"100%\" height=\"100%\" x=\"0\" y=\"0\">\n          <feColorMatrix result=\"CURRENT\"></feColorMatrix>\n          <feComponentTransfer #gammaMaskLeft result=\"LEFT\" x=\"0%\" width=\"50%\" height=\"100%\" y=\"0%\">\n            <feFuncR\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n            <feFuncG\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n            <feFuncB\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n          </feComponentTransfer>\n          <feComposite in2=\"CURRENT\" in=\"LEFT\" operator=\"over\" result=\"CURRENT\"></feComposite>\n          <feComponentTransfer #gammaMaskRight result=\"RIGHT\" x=\"50%\" width=\"50%\" height=\"100%\" y=\"0%\">\n            <feFuncR\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n            <feFuncG\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n            <feFuncB\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n          </feComponentTransfer>\n\n          <feComposite in2=\"CURRENT\" in=\"RIGHT\" operator=\"over\" result=\"COMPOSITE\">\n\n          </feComposite>\n<!--          <feComposite in2=\"SourceGraphic\" in=\"FIRST_COMPOSITE\" operator=\"over\" result=\"FIRST_COMBINED_COMPOSITE\">-->\n\n<!--          </feComposite>-->\n<!--          <feComposite in2=\"FIRST_COMBINED_COMPOSITE\" in=\"SECOND\" operator=\"over\" result=\"SECOND_COMPOSITE\">-->\n\n<!--          </feComposite>-->\n<!--          <feComposite in2=\"FIRST_COMBINED_COMPOSITE\" in=\"SECOND_COMPOSITE\" operator=\"in\"></feComposite>-->\n        </filter>\n      </svg>\n\n      <ng-content>\n\n      </ng-content>\n    </div>\n\n\n<!--    <div class=\"side-by-side-label-wrapper left\" *ngIf=\"leftLabelTemplate\">-->\n<!--      <ng-content *ngTemplateOutlet=\"leftLabelTemplate\"></ng-content>-->\n<!--    </div>-->\n\n<!--    <div class=\"side-by-side-label-wrapper right\" [ngClass]=\"{'has-geolocate': map?.options?.geoLocateControl}\" *ngIf=\"rightLabelTemplate\">-->\n<!--      <ng-content *ngTemplateOutlet=\"rightLabelTemplate\"></ng-content>-->\n<!--    </div>-->\n\n  </div>\n  <div class=\"gamma-slider-wrapper\">\n    <div class=\"gamma-slider left\">\n      <oui-slider [options]=\"gammaSliderOptions()\" [value]=\"beforeGamma()\" (valueChange)=\"onBeforeGammaChange($event)\"\n      ></oui-slider>\n    </div>\n    <div class=\"gamma-slider right\">\n      <oui-slider\n          [options]=\"gammaSliderOptions()\"\n          [value]=\"afterGamma()\"\n          (valueChange)=\"onAfterGammaChange($event)\"\n      ></oui-slider>\n    </div>\n\n    <ng-template #thumbIconTemplate>\n      <oui-icon  [icon]=\"'assets/icons/brightness.svg'\"\n                 [options]=\"{\n    viewBox: '0 0 48 48',\n    size: '13px',\n    fillColor: 'color-background-primary-text',\n    strokeColor: 'color-background-primary-text',\n    }\">\n\n      </oui-icon>\n    </ng-template>\n  </div>\n\n\n</div>\n", styles: [":host{width:100%;height:100%;position:absolute;top:0;left:0;z-index:1;pointer-events:none}:host .gamma-mask-svg{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:-9999}:host .side-by-side-wrapper{width:100%;height:100%;opacity:0;transition:opacity .3s;pointer-events:none;display:flex;flex-direction:column}:host .side-by-side-wrapper .gamma-slider-wrapper{display:flex;height:5rem;justify-content:space-around;pointer-events:all;--oui-slider-thumb-color-primary: var(--color-background-primary);--oui-slider-thumb-border-radius: 50%;--oui-slider-thumb-width: 20px;--oui-slider-thumb-height: 20px;--oui-slider-thumb-color-primary-hover: var(--color-background-primary-hover)}:host .side-by-side-wrapper .gamma-slider-wrapper .gamma-slider{width:25%;height:100%}:host .side-by-side-wrapper .maps-wrapper{height:100%;width:100%;flex:1;position:relative;overflow:hidden}:host .side-by-side-wrapper .maps-wrapper .map-content{height:100%;width:100%;position:relative}:host .side-by-side-wrapper .maps-wrapper .drag-container{position:absolute;width:var(--mapbox-side-by-side-caret-container-width);pointer-events:all;z-index:2;cursor:col-resize}:host .side-by-side-wrapper .maps-wrapper .drag-container .drag-caret-container{display:flex;justify-content:space-between;align-items:center;position:absolute;border-width:var(--oui-mapbox-side-by-side-caret-container-border-width);border-style:var(--oui-mapbox-side-by-side-caret-container-border-style);border-color:var(--oui-mapbox-side-by-side-caret-container-border-color);height:var(--mapbox-side-by-side-caret-container-height);width:var(--mapbox-side-by-side-caret-container-width);background-color:var(--mapbox-side-by-side-caret-container-background-color);border-radius:var(--mapbox-side-by-side-caret-container-border-radius)}:host .side-by-side-wrapper .maps-wrapper .drag-container .drag-caret-container oui-icon{filter:var(--oui-mapbox-side-by-side-caret-icon-filter)}:host .side-by-side-wrapper .maps-wrapper .drag-container:hover{cursor:col-resize}:host .side-by-side-wrapper .maps-wrapper .drag-container.vertical{height:100%;width:40px;display:flex;justify-content:center;align-items:center}:host .side-by-side-wrapper .maps-wrapper .drag-container.vertical .drag{width:var(--mapbox-side-by-side-drag-width);background-color:var(--mapbox-side-by-side-drag-background-color);border:solid var(--border-color-primary);border-width:0 1px;height:100%}:host .side-by-side-wrapper .maps-wrapper .drag-container.horizontal{width:100%;height:40px;display:flex;justify-content:center}:host .side-by-side-wrapper .maps-wrapper .drag-container.horizontal .drag{height:4px;background-color:#fff;width:100%}:host .side-by-side-wrapper.initialised{opacity:1}:host .side-by-side-wrapper .side-by-side-label-wrapper{display:flex;align-items:center;position:absolute;top:2rem;flex:0;min-height:3rem;-webkit-user-select:none;user-select:none;font-size:var(--font-size-body-smaller);border-radius:var(--border-radius-default);color:var(--color-dark)}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-content{line-height:1px}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-icon{margin-right:10px}:host .side-by-side-wrapper .side-by-side-label-wrapper.left{z-index:1;left:1rem}:host .side-by-side-wrapper .side-by-side-label-wrapper.right{z-index:0;right:1rem}:host .side-by-side-wrapper .side-by-side-label-wrapper.right.has-geolocate{right:5rem;margin-right:1rem}\n"] }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.DestroyRef }, { type: i0.ChangeDetectorRef }, { type: i0.ElementRef }], propDecorators: { leftLabelTemplate: [{
                type: Input
            }], rightLabelTemplate: [{
                type: Input
            }], mapContainer: [{
                type: Input
            }], map: [{
                type: Input
            }], clipChange: [{
                type: Output
            }], dragged: [{
                type: Output
            }], clicked: [{
                type: Output
            }], released: [{
                type: Output
            }], dragContainer: [{
                type: ViewChild,
                args: ['dragContainer']
            }], drag: [{
                type: ViewChild,
                args: ['drag']
            }], imageLabelRight: [{
                type: ViewChild,
                args: ['imageLabelRight']
            }], imageLabelLeft: [{
                type: ViewChild,
                args: ['imageLabelLeft']
            }], thumbIconTemplate: [{
                type: ViewChild,
                args: ['thumbIconTemplate']
            }], mapContent: [{
                type: ViewChild,
                args: ['mapContent']
            }], draggable: [{
                type: ViewChild,
                args: ['draggable']
            }], mapsWrapper: [{
                type: ViewChild,
                args: ['mapsWrapper']
            }], gammaMaskRight: [{
                type: ViewChild,
                args: ['gammaMaskRight']
            }], gammaMaskLeft: [{
                type: ViewChild,
                args: ['gammaMaskLeft']
            }] } });

class OuiDeckComponent {
    zone;
    elementRef;
    destroyRef;
    canvas;
    set options(options) {
        this.optionsSignal.set(options);
        if (options) {
            this.optionsSubject.next(options);
        }
    }
    get options() {
        return this.optionsSignal();
    }
    map;
    isInterleaved = true;
    onLoad = new EventEmitter();
    viewStateChangeSubject = new ReplaySubject(1);
    dragStartSubject = new Subject();
    mouseDownSubject = new Subject();
    mouseUpSubject = new Subject();
    webGlContext;
    optionsSignal = signal(undefined);
    boundsSubject = new ReplaySubject(1);
    onLoadSubject = new ReplaySubject(1);
    optionsSubject = new ReplaySubject(1);
    defaultEventListeners = {
        mouseup: {
            listener: (event) => {
                const x = event.screenX;
                const y = event.screenY;
                if (this.map) {
                    const coordinates = this.map.projectXyToLngLat([x, y]);
                    const data = {
                        latitude: coordinates.lat,
                        longitude: coordinates.lng,
                        point: {
                            x,
                            y,
                        },
                        type: 'mouseup',
                        originalEvent: event,
                    };
                    this.mouseUpSubject.next(data);
                }
            },
            options: { passive: true },
        },
        mousedown: {
            listener: (event) => {
                const x = event.screenX;
                const y = event.screenY;
                if (this.map) {
                    const coordinates = this.map.projectXyToLngLat([x, y]);
                    const data = {
                        latitude: coordinates.lat,
                        longitude: coordinates.lng,
                        point: {
                            x,
                            y,
                        },
                        type: 'mousedown',
                        originalEvent: event,
                    };
                    this.mouseDownSubject.next(data);
                }
            },
            options: { passive: true },
        },
        touchstart: {
            listener: (event) => {
                const x = event.changedTouches[0].clientX;
                const y = event.changedTouches[0].clientY;
                if (this.map) {
                    const coordinates = this.map.projectXyToLngLat([x, y]);
                    const data = {
                        latitude: coordinates.lat,
                        longitude: coordinates.lng,
                        point: {
                            x,
                            y,
                        },
                        type: 'mousedown',
                        originalEvent: event,
                    };
                    this.mouseDownSubject.next(data);
                }
            },
            options: { passive: true },
        },
        touchend: {
            listener: (event) => {
                const x = event.changedTouches[0].clientX;
                const y = event.changedTouches[0].clientY;
                if (this.map) {
                    const coordinates = this.map.projectXyToLngLat([x, y]);
                    const data = {
                        latitude: coordinates.lat,
                        longitude: coordinates.lng,
                        point: {
                            x,
                            y,
                        },
                        originalEvent: event,
                        type: 'mouseup',
                    };
                    this.mouseUpSubject.next(data);
                }
            },
            options: { passive: true },
        },
    };
    hoveredLayer = signal(undefined);
    cursorState = signal({
        isDragging: false,
        isHovering: false,
    });
    cursor = computed(() => {
        if (this.hoveredLayer()) {
            return this.hoveredLayer()?.getCursor(this.cursorState());
        }
        else {
            return this.options?.getCursor
                ? this.options?.getCursor(this.cursorState())
                : this.cursorState().isDragging
                    ? 'grabbing'
                    : 'grab';
        }
    });
    layers = signal([]);
    enabledLayers = computed(() => {
        return this.layers()
            .sort((a, b) => {
            // Sort by order if both layers have an order, otherwise put the layers on top that have an order
            if (a.options?.order && b.options?.order) {
                return b.options.order - a.options.order;
            }
            else if (a.options?.order) {
                return -1;
            }
            else if (b.options?.order) {
                return 1;
            }
            else {
                return -1;
            }
        })
            .map((layer) => {
            return layer.getLayer();
        });
    });
    options$ = this.optionsSubject.asObservable();
    isDestroying = false;
    deck = signal(undefined);
    deckOverlay = signal(undefined);
    onLoad$ = this.onLoadSubject.asObservable();
    viewStateChange$ = this.viewStateChangeSubject.asObservable();
    bounds$ = this.boundsSubject.asObservable();
    dragStart$ = this.dragStartSubject.asObservable();
    mousedown$ = this.mouseDownSubject.asObservable();
    mouseup$ = this.mouseUpSubject.asObservable();
    constructor(zone, elementRef, destroyRef) {
        this.zone = zone;
        this.elementRef = elementRef;
        this.destroyRef = destroyRef;
        effect(() => {
            if (this.isDestroying) {
                return;
            }
            if (!this.deck() && !this.deckOverlay()) {
                return;
            }
            if (this.isInterleaved && this.deckOverlay()) {
                this.deckOverlay().setProps({
                    layers: this.enabledLayers(),
                });
            }
            else if (this.deck()) {
                this.deck().setProps({
                    layers: this.enabledLayers(),
                });
            }
        });
    }
    getProps() {
        if (!this.deck()) {
            console.error('Attempted to fetch deck-props before initialisation');
            return undefined;
        }
        else {
            return this.deck().props;
        }
    }
    ngAfterViewInit() {
        if (!this.map) {
            console.error('Deck-component has no map assigned to it. You are probably missing an input');
        }
        if (this.isInterleaved) {
            this.elementRef.nativeElement.classList.add('interleaved');
        }
        combineLatest([this.map.onLoad$, this.options$])
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(([map, options]) => {
            if (map && options && !this.deck() && !this.deckOverlay()) {
                this.initDeck();
            }
        });
        this.destroyRef.onDestroy(() => {
            this.finalize();
        });
    }
    initDeck() {
        this.zone.runOutsideAngular(() => {
            if (!this.options || !this.map.map) {
                console.error('Attempted to initialise DeckGL without options');
                return;
            }
            const initialViewState = {
                longitude: this.options.initialViewState['longitude'] ??
                    this.map.map.getCenter().lng,
                latitude: this.options.initialViewState['latitude'] ??
                    this.map.map.getCenter().lat,
                zoom: this.options.initialViewState['zoom'] ?? this.map.map.getZoom(),
                minZoom: this.options.initialViewState?.['minZoom'] ?? 1,
                maxZoom: this.options.initialViewState?.['maxZoom'] ?? 20,
                maxPitch: 0,
            };
            if (!this.isInterleaved) {
                this.deck.set(new Deck({
                    onClick: this.options.onClick ? this.options.onClick : () => { },
                    onDrag: this.options.onDrag ? this.options?.onDrag : () => { },
                    layerFilter: this.options.layerFilter,
                    onDragStart: (info, event) => {
                        this.dragStartSubject.next({
                            info,
                            event,
                        });
                        if (this.options?.onDragStart) {
                            this.options.onDragStart(info, event);
                        }
                    },
                    onDragEnd: this.options.onDragEnd
                        ? this.options.onDragEnd
                        : () => { },
                    getCursor: state => {
                        this.cursorState.set(state);
                        return this.cursor();
                    },
                    onHover: info => {
                        if (!info.picked) {
                            this.hoveredLayer.set(undefined);
                        }
                    },
                    views: this.options.views,
                    canvas: this.canvas.nativeElement,
                    initialViewState: initialViewState,
                    onWebGLInitialized: (webGlContext) => {
                        this.webGlContext = webGlContext;
                    },
                    controller: this.options.controller || true,
                    onViewStateChange: (viewState) => {
                        this.deck().setProps({
                            initialViewState: { ...viewState.viewState, maxPitch: 0 },
                        });
                        if (!viewState.viewState) {
                            return;
                        }
                        const bounds = this.getBoundsFromViewState(viewState.viewState);
                        this.viewStateChangeSubject.next({
                            oldViewState: viewState.oldViewState,
                            viewState: viewState.viewState,
                        });
                        this.boundsSubject.next(bounds);
                        if (this.options?.onViewStateChange) {
                            this.options.onViewStateChange(viewState);
                        }
                    },
                    effects: this.options.effects ?? [],
                    onBeforeRender: () => {
                        // const viewport: any = this.deck()!.getViewports(undefined)?.[0];
                        // if (viewport && this.map.map) {
                        //   this.map.map.jumpTo({
                        //     center: [viewport.longitude, viewport.latitude],
                        //     zoom: viewport.zoom,
                        //     bearing: viewport.bearing,
                        //     pitch: viewport.pitch,
                        //   });
                        //   this.map.map.resize();
                        // }
                    },
                }));
                for (const event in this.defaultEventListeners) {
                    this.zone.run(() => {
                        this.canvas.nativeElement.addEventListener(event, this.defaultEventListeners[event].listener, this.defaultEventListeners[event].options);
                    });
                }
                if (this.options.eventListeners) {
                    for (const event in this.options.eventListeners) {
                        this.zone.run(() => {
                            this.canvas.nativeElement.addEventListener(event, this.options.eventListeners[event].listener, this.options.eventListeners[event].options);
                        });
                    }
                }
                this.emitViewStateChange();
            }
            else {
                this.deckOverlay.set(new MapboxOverlay({
                    id: 'mapbox-overlay',
                    interleaved: true,
                    layers: [...this.enabledLayers()],
                    onClick: this.options.onClick ? this.options.onClick : () => { },
                    onDrag: this.options.onDrag ? this.options?.onDrag : () => { },
                    onDragStart: this.options.onDragStart
                        ? this.options.onDragStart
                        : () => { },
                    onDragEnd: this.options.onDragEnd
                        ? this.options.onDragEnd
                        : () => { },
                    getCursor: state => {
                        this.cursorState.set(state);
                        return this.cursor();
                    },
                    onHover: info => {
                        if (!info.picked) {
                            this.hoveredLayer.set(undefined);
                        }
                    },
                    onWebGLInitialized: (webGlContext) => {
                        this.webGlContext = webGlContext;
                    },
                    effects: this.options.effects ?? [],
                }));
                this.map.map.addControl(this.deckOverlay());
            }
            this.onLoadSubject.next(this);
            this.onLoad.emit(this);
        });
    }
    addLayer(layer) {
        this.layers.update(layers => {
            return [...layers, layer];
        });
    }
    refreshLayer(layer) {
        this.layers.update(layers => {
            const index = layers.findIndex(l => l.options?.id === layer.options?.id);
            if (index === -1) {
                return layers;
            }
            layers[index] = layer;
            return [...layers];
        });
    }
    removeLayer(layer) {
        this.layers.update(layers => {
            return layers.filter(l => l.options?.id !== layer.options?.id);
        });
    }
    setHoveredLayer(layer) {
        this.hoveredLayer.set(layer);
    }
    refreshLayers() {
        if (this.deck()) {
            this.deck().setProps({
                layers: [...this.enabledLayers()],
            });
        }
        else if (this.deckOverlay()) {
            this.deckOverlay().setProps({
                layers: this.enabledLayers(),
            });
        }
        else {
            console.error('Attempted to refresh deck-layers before initialisation');
        }
    }
    getBoundsFromViewState(viewState) {
        const viewport = new WebMercatorViewport(viewState);
        const ne = viewport.unproject([viewport.width, 0]);
        const sw = viewport.unproject([0, viewport.height]);
        const newNE = new LngLat(ne[0], ne[1]).wrap();
        const newSW = new LngLat(sw[0], sw[1]).wrap();
        const bounds = new LngLatBounds(newSW, newNE);
        return bounds;
    }
    emitViewStateChange() {
        const viewState = this.deck()?.props?.viewState ?? this.deck()?.props?.initialViewState;
        this.viewStateChangeSubject.next({
            viewState: viewState,
            oldViewState: viewState,
        });
        if (!viewState) {
            return;
        }
        const bounds = this.getBoundsFromViewState(viewState);
        this.boundsSubject.next(bounds);
    }
    ngOnChanges(changes) {
        if ('options' in changes && changes.options.currentValue) {
            this.options = changes.options.currentValue;
            this.updateChangedDeckOptions(this.options);
            this.optionsSubject.next(this.options);
        }
        if ('isInterleaved' in changes) {
            if (changes.isInterleaved.currentValue) {
                this.elementRef.nativeElement.classList.add('interleaved');
            }
            else {
                this.elementRef.nativeElement.classList.remove('interleaved');
            }
        }
    }
    // Difficult to dynamically update all props - some of them can be affected by external things like mapsync
    updateChangedDeckOptions(options) {
        if (this.deck()) {
            const oldViewState = { ...this.deck().props.initialViewState };
            const newViewState = {
                ...(options.initialViewState ?? this.deck().props.initialViewState),
                maxPitch: 0,
            };
            const newOptions = {
                initialViewState: newViewState,
                effects: options.effects ?? this.deck().props.effects,
                views: options.views ?? this.deck().props.views,
                onClick: this.options?.onClick ?? this.deck().props.onClick,
                onDrag: this.options?.onDrag ?? this.deck().props.onDrag,
            };
            this.deck()?.setProps({
                ...newOptions,
            });
            this.deck().props.onViewStateChange({
                viewState: {
                    ...options.initialViewState,
                    maxPitch: 0,
                },
                oldViewState: oldViewState,
                viewId: 'default-map-view',
                interactionState: {},
            });
        }
    }
    finalize() {
        this.isDestroying = true;
        if (this.webGlContext) {
            this.webGlContext.getExtension('WEBGL_lose_context')?.loseContext();
        }
        if (this.canvas?.nativeElement) {
            this.canvas.nativeElement.replaceWith(this.canvas.nativeElement.cloneNode(true));
        }
        if (this.deck()) {
            this.deck().setProps({
                layers: [],
            });
            this.deck().finalize();
            this.deck.set(undefined);
        }
        if (this.deckOverlay()) {
            this.deckOverlay().setProps({
                layers: [],
            });
            this.deckOverlay().finalize();
        }
    }
    reinitialize() {
        this.initDeck();
    }
    ngOnDestroy() {
        this.isDestroying = true;
        // this.finalize();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDeckComponent, deps: [{ token: i0.NgZone }, { token: i0.ElementRef }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiDeckComponent, isStandalone: true, selector: "oui-deck", inputs: { options: "options", map: "map", isInterleaved: "isInterleaved" }, outputs: { onLoad: "onLoad" }, viewQueries: [{ propertyName: "canvas", first: true, predicate: ["canvas"], descendants: true, static: true }], usesOnChanges: true, ngImport: i0, template: '<canvas #canvas class="deck-canvas"></canvas>', isInline: true, styles: [":host{position:absolute;top:0;left:0;height:100%;width:100%}:host.interleaved{pointer-events:none}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDeckComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-deck', template: '<canvas #canvas class="deck-canvas"></canvas>', standalone: true, imports: [], changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{position:absolute;top:0;left:0;height:100%;width:100%}:host.interleaved{pointer-events:none}\n"] }]
        }], ctorParameters: () => [{ type: i0.NgZone }, { type: i0.ElementRef }, { type: i0.DestroyRef }], propDecorators: { canvas: [{
                type: ViewChild,
                args: ['canvas', { static: true }]
            }], options: [{
                type: Input,
                args: [{ required: true }]
            }], map: [{
                type: Input,
                args: [{ required: true }]
            }], isInterleaved: [{
                type: Input
            }], onLoad: [{
                type: Output
            }] } });

class OuiMapSyncService {
    // Variable to store all maps (and their viewStateChange-listeners) in groups
    mapGroups = {};
    constructor() { }
    registerMap(map, group) {
        // Add map to the correct group
        if (map.deck && !map.deck.isInterleaved) {
            map.deck.onLoad$.subscribe(() => {
                this.initSyncDeck(map, group);
            });
        }
        else {
            this.initSyncMapbox(map, group);
        }
    }
    deRegisterMap(map, group) {
        if (map.deck && !map.deck.isInterleaved) {
            if (this.mapGroups[group] && map.id in this.mapGroups[group]) {
                delete this.mapGroups[group][map.id];
            }
        }
        else {
            if (this.mapGroups[group] && map.id in this.mapGroups[group] && map.map) {
                map.map.off('move', this.mapGroups[group][map.id].moveListener);
                delete this.mapGroups[group][map.id];
            }
        }
    }
    initSyncDeck(map, group) {
        if (!this.mapGroups || !(group in this.mapGroups)) {
            const props = map.getDeckProps();
            if (props) {
                this.mapGroups[group] = {
                    [map.id]: {
                        map,
                        deck: map.deck,
                        existingViewStateChangeListener: props.onViewStateChange,
                    },
                };
            }
        }
        else {
            const props = map.getDeckProps();
            if (props) {
                this.mapGroups[group][map.id] = {
                    deck: map.deck,
                    map,
                    existingViewStateChangeListener: props.onViewStateChange,
                };
            }
        }
        // Set initial syncing of viewStates
        map.setDeckProps({
            onViewStateChange: (viewStateChange) => {
                this.mapGroups[group][map.id].existingViewStateChangeListener(viewStateChange);
                this.syncDeckViewState(this.mapGroups[group], map, viewStateChange);
            },
        });
    }
    initSyncMapbox(map, group) {
        if (!this.mapGroups || !(group in this.mapGroups)) {
            this.mapGroups[group] = {
                [map.id]: {
                    map: map,
                    moveListener: (event) => {
                        this.syncMapboxViewState(group, map);
                    },
                },
            };
        }
        else {
            this.mapGroups[group][map.id] = {
                map,
                moveListener: (event) => {
                    this.syncMapboxViewState(group, map);
                },
            };
        }
        if (map.map) {
            map.map.on('move', this.mapGroups[group][map.id].moveListener);
        }
    }
    syncMapboxViewState(group, parentMap) {
        for (const map of Object.values(this.mapGroups[group])) {
            if (map.map.id === parentMap.id) {
                continue;
            }
            if ('deck' in map) {
                this.syncDeckToMapboxViewState(map, parentMap);
                map.deck.deck().setProps({
                    onViewStateChange: (vsc) => {
                        map.existingViewStateChangeListener(vsc);
                        this.syncDeckViewState(this.mapGroups[group], map.map, vsc);
                    },
                });
            }
            else if (map.map.map) {
                map.map.map.off('move', map.moveListener);
                this.moveMapToParent(parentMap, map.map);
                map.map.map.on('move', map.moveListener);
            }
        }
    }
    syncDeckToMapboxViewState(map, parentMap) {
        if (!map.deck.deck()) {
            return;
        }
        map.deck.deck().props.onViewStateChange = (vsc) => {
            map.existingViewStateChangeListener(vsc);
        };
        if (parentMap.map) {
            map.deck.deck().setProps({
                initialViewState: {
                    ...this.mapboxToDeckViewState(parentMap.map),
                },
            });
        }
    }
    syncMapboxToDeckViewState(mapGroup, viewStateChange) {
        const center = [viewStateChange.longitude, viewStateChange.latitude];
        const zoom = viewStateChange.zoom;
        const bearing = viewStateChange.bearing;
        const pitch = viewStateChange.pitch;
        if (mapGroup.map.map) {
            mapGroup.map.map.jumpTo({
                center: center,
                zoom: zoom,
                bearing: bearing ?? 0,
                pitch: pitch ?? 0,
            });
        }
    }
    moveMapToParent(parentMap, childMap) {
        const center = parentMap.map.getCenter();
        const zoom = parentMap.map.getZoom();
        const bearing = parentMap.map.getBearing();
        const pitch = parentMap.map.getPitch();
        childMap.map.jumpTo({
            center: center,
            zoom: zoom,
            bearing: bearing,
            pitch: pitch,
        });
    }
    // Function that syncs maps in a given group according to a given viewStateChange
    syncDeckViewState(group, map, viewStateChange) {
        // First loop over the maps, removing the sync-function from all maps except the one that triggered the viewStateChange
        // Simultaneously also set their initialViewStates to the one that triggered the viewStateChange
        const maps = Object.values(group);
        for (let i = 0; i < maps.length; i++) {
            if ('deck' in maps[i]) {
                maps[i].map.deck.deck().props.onViewStateChange = (vsc) => {
                    maps[i].existingViewStateChangeListener(vsc);
                };
                maps[i].map.setDeckProps({
                    initialViewState: {
                        ...map.deck.deck().props.initialViewState,
                    },
                });
                maps[i].map.deck.deck().props.onViewStateChange(viewStateChange);
                maps[i].map.deck.deck().setProps({
                    onViewStateChange: (vsc) => {
                        maps[i].existingViewStateChangeListener(vsc);
                        this.syncDeckViewState(group, maps[i].map, vsc);
                    },
                });
            }
            else {
                const singleMap = maps[i].map.map;
                if (singleMap) {
                    singleMap.off('move', maps[i].moveListener);
                    this.syncMapboxToDeckViewState(maps[i], map.deck.deck().props.initialViewState);
                    singleMap.on('move', maps[i].moveListener);
                }
            }
        }
    }
    mapboxToDeckViewState(map) {
        const center = map.getCenter();
        const zoom = map.getZoom();
        const bearing = map.getBearing();
        const pitch = map.getPitch();
        return {
            latitude: center.lat,
            longitude: center.lng,
            zoom: zoom,
            bearing: bearing,
            pitch: pitch,
        };
    }
    deckToMapboxViewState(deckViewState) {
        const mapboxViewState = {
            ...deckViewState,
            bearing: deckViewState.bearing,
            pitch: deckViewState.pitch,
            zoom: deckViewState.zoom,
        };
        return mapboxViewState;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMapSyncService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMapSyncService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMapSyncService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

class OuiMapSyncDirective {
    mapSyncService;
    map;
    /** simple directive that syncs the maps with the given group */
    mapSyncGroup;
    constructor(mapSyncService, map) {
        this.mapSyncService = mapSyncService;
        this.map = map;
    }
    ngOnInit() { }
    ngAfterViewInit() {
        const interval = setInterval(() => {
            if (this.map?.map) {
                this.mapSyncService.registerMap(this.map, this.mapSyncGroup);
                clearInterval(interval);
            }
        }, 500);
    }
    ngOnDestroy() {
        this.mapSyncService.deRegisterMap(this.map, this.mapSyncGroup);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMapSyncDirective, deps: [{ token: OuiMapSyncService }, { token: OuiMapboxComponent }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.1", type: OuiMapSyncDirective, isStandalone: true, selector: "[oui-map-sync]", inputs: { mapSyncGroup: "mapSyncGroup" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMapSyncDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[oui-map-sync]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: OuiMapSyncService }, { type: OuiMapboxComponent }], propDecorators: { mapSyncGroup: [{
                type: Input,
                args: [{ required: true }]
            }] } });

const SELECTION_TYPE = {
    NONE: null,
    RECTANGLE: 'rectangle',
    POLYGON: 'polygon',
};

/**
 * Generated bundle index. Do not edit.
 */

export { BaseDeckLayer, BindCommonDeckOptions, DeckBitmapLayer, DeckClusterLayerComponent, DeckEditableGeoJsonlayer, DeckGeojsonLayer, DeckGeolocateLayer, DeckIconLayer, DeckMeasureLayer, DeckMvtLayer, DeckPathLayer, DeckPolygonLayer, DeckScatterplotLayer, DeckSideBySideComponent, DeckTextLayer, DeckTileLayer, EDITABLE_GEOJSON_LAYER_MODES, MapboxSideBySideComponent, OuiDeckComponent, OuiMapSyncDirective, OuiMapSyncService, OuiMapboxComponent, SELECTION_TYPE, TileLayerService };
//# sourceMappingURL=orbital-ui-mapbox.mjs.map
