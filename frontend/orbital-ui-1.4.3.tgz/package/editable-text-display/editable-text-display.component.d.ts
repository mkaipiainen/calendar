import { AfterViewInit, ElementRef, EventEmitter } from '@angular/core';
import { OuiInputComponent } from 'orbital-ui/input';
import { IOuiIconOptions } from 'orbital-ui/icon';
import * as i0 from "@angular/core";
export interface IOuiEditableTextDisplayOptions {
    placeholder?: string;
    sizeToContent?: boolean;
    maxLength?: number;
}
/**
 * Component to enable having a text that's display normally, but that can be toggled to be editable
 * by clicking on a button. The edit can then be either canceled or accepted.
 *
 *   Example use:
 *
 *   <oui-editable-text-display [(model)]="myText"></oui-editable-text-display>
 */
export declare class OuiEditableTextDisplayComponent implements AfterViewInit {
    private document;
    placeholderElement: ElementRef;
    textInput: OuiInputComponent;
    set options(options: IOuiEditableTextDisplayOptions);
    /**
     * A placeholder to be shown if there's no text
     */
    placeholder: string;
    /**
     *   The text to be shown
     */
    model: string;
    /**
     *   Whether or not the text-field is currently being edited
     */
    isEditing: boolean;
    /**
     *  Whether or not the text-field should size to the content
     */
    sizeToContent: boolean;
    /**
     *   Event that's emitted when the text is edited
     */
    modelChange: EventEmitter<string>;
    textDisplay: ElementRef;
    private originalModel;
    private defaultOptions;
    optionsSignal: import("@angular/core").WritableSignal<IOuiEditableTextDisplayOptions>;
    iconOptions: IOuiIconOptions;
    fontSize: string;
    constructor(document: Document);
    onModelChange(model: string | number): void;
    submitEdit(): void;
    cancelEdit(): void;
    stopEditing(): void;
    startEdit(): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiEditableTextDisplayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiEditableTextDisplayComponent, "oui-editable-text-display", never, { "options": { "alias": "options"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "model": { "alias": "model"; "required": false; }; "isEditing": { "alias": "isEditing"; "required": false; }; "sizeToContent": { "alias": "sizeToContent"; "required": false; }; }, { "modelChange": "modelChange"; }, never, never, true, never>;
}
//# sourceMappingURL=editable-text-display.component.d.ts.map