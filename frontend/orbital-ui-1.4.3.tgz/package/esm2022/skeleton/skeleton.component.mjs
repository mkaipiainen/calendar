import { ChangeDetectionStrategy, Component, Input, } from '@angular/core';
import { NgStyle } from '@angular/common';
import * as i0 from "@angular/core";
/**
 * This component streamlines creation of skeleton loading-sections. Has a few different modes you can choose from, although
 * right now the table-mode is probably the most useful one.
 *
 * Example use:
 *
 *  <oui-skeleton [options]="loadingSkeletonOptions" *ngIf="isLoading && loadingSkeletonOptions.rows.count">
 *  </oui-skeleton>
 *
 *  Where loadingSkeletonOptions are
 *
 *  public loadingSkeletonOptions: ISkeletonTableOptions = {
 *    type: 'table',
 *    rows: {
 *      count: 0,
 *      verticalSpacing: '10px',
 *      height: '25px',
 *    },
 *    columns: {
 *      count: 4,
 *    },
 *    cells: {
 *      inset: '4px',
 *      horizontalSpacing: '4px',
 *    },
 *    header: {
 *      margin: '14px',
 *      height: '30px',
 *    }
 *  }
 */
export class OuiSkeletonComponent {
    /**
     *   The options that define the skeleton. Currently suggested to use only the table-mode until further modes have been implemented.
     */
    options;
    columns = [];
    rows = [];
    constructor() { }
    combineOptions() {
        if (this.options.type === 'grid' || this.options.type === 'table') {
            const gridOptions = this
                .options;
            if (Array.isArray(gridOptions.columns)) {
                this.columns = gridOptions.columns;
            }
            else {
                this.columns = Array(gridOptions.columns.count)
                    .fill(0)
                    .map(() => {
                    return {
                        width: '10px',
                        margin: gridOptions.columns.margin,
                    };
                });
            }
            if (Array.isArray(gridOptions.rows)) {
                this.rows = gridOptions.rows;
            }
            else {
                this.rows = Array(gridOptions.rows.count)
                    .fill(0)
                    .map(() => {
                    return {
                        height: '10px',
                        margin: gridOptions.rows.margin,
                    };
                });
            }
        }
    }
    getRowStyle(row) {
        return {
            height: row.height,
            margin: `${row.margin} 0`,
        };
    }
    getColumnStyle(column) {
        return {
            width: column.width,
            margin: `0 ${column.margin}`,
        };
    }
    getTableRowStyle(type) {
        const tableOptions = this.options;
        const height = type === 'head'
            ? tableOptions.header?.height ?? tableOptions.rows.height
            : tableOptions.rows.height;
        return {
            height: height,
            margin: `${tableOptions.rows.verticalSpacing} 0`,
        };
    }
    getTableCellStyle() {
        const tableOptions = this.options;
        const style = {
            // 'padding': tableOptions.cells.inset,
            // 'border-width': tableOptions.borderWidth,
            margin: `0 ${tableOptions.cells.horizontalSpacing}`,
        };
        return style;
    }
    getTableInnerCellStyle() {
        const tableOptions = this.options;
        const style = {
            padding: tableOptions.cells.inset,
            // 'margin': `0 ${tableOptions.cells.horizontalSpacing}`
        };
        return style;
    }
    getSingleStyle() {
        const style = {};
        if (this.options.type === 'single' && this.options.backgroundImageOptions) {
            style['background-image'] = `url(${this.options.backgroundImageOptions.backgroundImage})`;
            style['background-repeat'] = 'no-repeat';
            style['background-position'] =
                this.options.backgroundImageOptions.backgroundPosition ?? 'center';
            style['background-size'] =
                this.options.backgroundImageOptions.backgroundSize ?? 'cover';
        }
        return style;
    }
    ngOnInit() {
        this.combineOptions();
    }
    ngOnChanges(changes) {
        if ('options' in changes) {
            this.combineOptions();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSkeletonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiSkeletonComponent, isStandalone: true, selector: "oui-skeleton", inputs: { options: "options" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"skeleton-container\">\n  @if (options.type === 'grid') {\n    <div class=\"skeleton-grid-container\">\n      @for (column of columns; track column) {\n        <div\n          class=\"skeleton-column\"\n          [ngStyle]=\"{ width: column.width, margin: '0 ' + column.margin }\"\n          >\n          @for (row of rows; track row) {\n            <div\n              class=\"skeleton-row\"\n              [ngStyle]=\"{ height: row.height, margin: row.margin + ' 0' }\"\n            ></div>\n          }\n        </div>\n      }\n    </div>\n  }\n  @if (options.type === 'single') {\n    <div class=\"skeleton-single-container\">\n      <div class=\"skeleton-single\" [ngStyle]=\"getSingleStyle()\"></div>\n    </div>\n  }\n  @if (options.type === 'table') {\n    <div class=\"skeleton-table-container\">\n      <div class=\"skeleton-table\">\n        @if (options.header) {\n          <div\n            class=\"skeleton-table-head\"\n            [ngStyle]=\"getTableRowStyle('head')\"\n            >\n            @for (column of columns; track column) {\n              <div\n                class=\"skeleton-table-head-cell cell\"\n                [ngStyle]=\"getTableCellStyle()\"\n                >\n                <div class=\"cell-inner\" [ngStyle]=\"getTableInnerCellStyle()\"></div>\n              </div>\n            }\n          </div>\n        }\n        @for (row of rows; track row) {\n          <div\n            class=\"skeleton-table-row\"\n            [ngStyle]=\"getTableRowStyle('body')\"\n            >\n            @for (column of columns; track column) {\n              <div\n                class=\"skeleton-table-row-cell cell\"\n                [ngStyle]=\"getTableCellStyle()\"\n                >\n                <div class=\"cell-inner\" [ngStyle]=\"getTableInnerCellStyle()\"></div>\n              </div>\n            }\n          </div>\n        }\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{display:flex;flex:1}:host .skeleton-container{display:flex;flex:1}:host .skeleton-container .skeleton-table-container{flex:1}:host .skeleton-container .skeleton-table-container .skeleton-table{width:100%;background-color:transparent;display:flex;flex-direction:column}:host .skeleton-container .skeleton-table-container .skeleton-table .skeleton-table-head{display:flex}:host .skeleton-container .skeleton-table-container .skeleton-table .skeleton-table-row{display:flex}:host .skeleton-container .skeleton-table-container .skeleton-table .cell{border-color:transparent;flex:1;display:flex;box-sizing:border-box}:host .skeleton-container .skeleton-table-container .skeleton-table .cell .cell-inner{flex:1;background-color:var(--oui-skeleton-background);position:relative;overflow:hidden;border:1px solid transparent;border-radius:4px}:host .skeleton-container .skeleton-table-container .skeleton-table .cell .cell-inner:after{content:\"\";display:block;width:100%;height:100%;position:absolute;top:0;left:0;transform:translate(-100%);animation:skeleton-animation 2s infinite;animation-timing-function:linear;z-index:1;background-image:linear-gradient(90deg,rgba(255,255,255,0),var(--oui-skeleton-active),rgba(255,255,255,0))}:host .skeleton-container .skeleton-grid-container{flex:1;display:flex}:host .skeleton-container .skeleton-grid-container .skeleton-column{display:flex;flex-direction:column;flex:1}:host .skeleton-container .skeleton-grid-container .skeleton-column .skeleton-row{background-color:#bbb;flex:1}@keyframes skeleton-animation{0%{transform:translate(-100%)}to{transform:translate(100%)}}\n"], dependencies: [{ kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSkeletonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-skeleton', standalone: true, imports: [NgStyle], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"skeleton-container\">\n  @if (options.type === 'grid') {\n    <div class=\"skeleton-grid-container\">\n      @for (column of columns; track column) {\n        <div\n          class=\"skeleton-column\"\n          [ngStyle]=\"{ width: column.width, margin: '0 ' + column.margin }\"\n          >\n          @for (row of rows; track row) {\n            <div\n              class=\"skeleton-row\"\n              [ngStyle]=\"{ height: row.height, margin: row.margin + ' 0' }\"\n            ></div>\n          }\n        </div>\n      }\n    </div>\n  }\n  @if (options.type === 'single') {\n    <div class=\"skeleton-single-container\">\n      <div class=\"skeleton-single\" [ngStyle]=\"getSingleStyle()\"></div>\n    </div>\n  }\n  @if (options.type === 'table') {\n    <div class=\"skeleton-table-container\">\n      <div class=\"skeleton-table\">\n        @if (options.header) {\n          <div\n            class=\"skeleton-table-head\"\n            [ngStyle]=\"getTableRowStyle('head')\"\n            >\n            @for (column of columns; track column) {\n              <div\n                class=\"skeleton-table-head-cell cell\"\n                [ngStyle]=\"getTableCellStyle()\"\n                >\n                <div class=\"cell-inner\" [ngStyle]=\"getTableInnerCellStyle()\"></div>\n              </div>\n            }\n          </div>\n        }\n        @for (row of rows; track row) {\n          <div\n            class=\"skeleton-table-row\"\n            [ngStyle]=\"getTableRowStyle('body')\"\n            >\n            @for (column of columns; track column) {\n              <div\n                class=\"skeleton-table-row-cell cell\"\n                [ngStyle]=\"getTableCellStyle()\"\n                >\n                <div class=\"cell-inner\" [ngStyle]=\"getTableInnerCellStyle()\"></div>\n              </div>\n            }\n          </div>\n        }\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{display:flex;flex:1}:host .skeleton-container{display:flex;flex:1}:host .skeleton-container .skeleton-table-container{flex:1}:host .skeleton-container .skeleton-table-container .skeleton-table{width:100%;background-color:transparent;display:flex;flex-direction:column}:host .skeleton-container .skeleton-table-container .skeleton-table .skeleton-table-head{display:flex}:host .skeleton-container .skeleton-table-container .skeleton-table .skeleton-table-row{display:flex}:host .skeleton-container .skeleton-table-container .skeleton-table .cell{border-color:transparent;flex:1;display:flex;box-sizing:border-box}:host .skeleton-container .skeleton-table-container .skeleton-table .cell .cell-inner{flex:1;background-color:var(--oui-skeleton-background);position:relative;overflow:hidden;border:1px solid transparent;border-radius:4px}:host .skeleton-container .skeleton-table-container .skeleton-table .cell .cell-inner:after{content:\"\";display:block;width:100%;height:100%;position:absolute;top:0;left:0;transform:translate(-100%);animation:skeleton-animation 2s infinite;animation-timing-function:linear;z-index:1;background-image:linear-gradient(90deg,rgba(255,255,255,0),var(--oui-skeleton-active),rgba(255,255,255,0))}:host .skeleton-container .skeleton-grid-container{flex:1;display:flex}:host .skeleton-container .skeleton-grid-container .skeleton-column{display:flex;flex-direction:column;flex:1}:host .skeleton-container .skeleton-grid-container .skeleton-column .skeleton-row{background-color:#bbb;flex:1}@keyframes skeleton-animation{0%{transform:translate(-100%)}to{transform:translate(100%)}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2tlbGV0b24uY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9za2VsZXRvbi9za2VsZXRvbi5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3NrZWxldG9uL3NrZWxldG9uLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDTCx1QkFBdUIsRUFDdkIsU0FBUyxFQUNULEtBQUssR0FJTixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsT0FBTyxFQUFFLE1BQU0saUJBQWlCLENBQUM7O0FBb0UxQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBOEJHO0FBU0gsTUFBTSxPQUFPLG9CQUFvQjtJQUMvQjs7T0FFRztJQUNNLE9BQU8sQ0FBbUI7SUFFNUIsT0FBTyxHQUFzQixFQUFFLENBQUM7SUFDaEMsSUFBSSxHQUFtQixFQUFFLENBQUM7SUFFakMsZ0JBQWUsQ0FBQztJQUVSLGNBQWM7UUFDcEIsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksS0FBSyxNQUFNLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEtBQUssT0FBTyxFQUFFLENBQUM7WUFDbEUsTUFBTSxXQUFXLEdBQXlCLElBQUk7aUJBQzNDLE9BQStCLENBQUM7WUFFbkMsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO2dCQUN2QyxJQUFJLENBQUMsT0FBTyxHQUFHLFdBQVcsQ0FBQyxPQUE0QixDQUFDO1lBQzFELENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBRSxXQUFXLENBQUMsT0FBK0IsQ0FBQyxLQUFLLENBQUM7cUJBQ3JFLElBQUksQ0FBQyxDQUFDLENBQUM7cUJBQ1AsR0FBRyxDQUFDLEdBQUcsRUFBRTtvQkFDUixPQUFPO3dCQUNMLEtBQUssRUFBRSxNQUFNO3dCQUNiLE1BQU0sRUFBRyxXQUFXLENBQUMsT0FBK0IsQ0FBQyxNQUFNO3FCQUM1RCxDQUFDO2dCQUNKLENBQUMsQ0FBQyxDQUFDO1lBQ1AsQ0FBQztZQUNELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztnQkFDcEMsSUFBSSxDQUFDLElBQUksR0FBRyxXQUFXLENBQUMsSUFBc0IsQ0FBQztZQUNqRCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUUsV0FBVyxDQUFDLElBQXlCLENBQUMsS0FBSyxDQUFDO3FCQUM1RCxJQUFJLENBQUMsQ0FBQyxDQUFDO3FCQUNQLEdBQUcsQ0FBQyxHQUFHLEVBQUU7b0JBQ1IsT0FBTzt3QkFDTCxNQUFNLEVBQUUsTUFBTTt3QkFDZCxNQUFNLEVBQUcsV0FBVyxDQUFDLElBQXlCLENBQUMsTUFBTTtxQkFDdEQsQ0FBQztnQkFDSixDQUFDLENBQUMsQ0FBQztZQUNQLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVNLFdBQVcsQ0FBQyxHQUFpQjtRQUNsQyxPQUFPO1lBQ0wsTUFBTSxFQUFFLEdBQUcsQ0FBQyxNQUFNO1lBQ2xCLE1BQU0sRUFBRSxHQUFHLEdBQUcsQ0FBQyxNQUFNLElBQUk7U0FDMUIsQ0FBQztJQUNKLENBQUM7SUFFTSxjQUFjLENBQUMsTUFBdUI7UUFDM0MsT0FBTztZQUNMLEtBQUssRUFBRSxNQUFNLENBQUMsS0FBSztZQUNuQixNQUFNLEVBQUUsS0FBSyxNQUFNLENBQUMsTUFBTSxFQUFFO1NBQzdCLENBQUM7SUFDSixDQUFDO0lBRU0sZ0JBQWdCLENBQUMsSUFBcUI7UUFDM0MsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLE9BQWdDLENBQUM7UUFDM0QsTUFBTSxNQUFNLEdBQ1YsSUFBSSxLQUFLLE1BQU07WUFDYixDQUFDLENBQUMsWUFBWSxDQUFDLE1BQU0sRUFBRSxNQUFNLElBQUksWUFBWSxDQUFDLElBQUksQ0FBQyxNQUFNO1lBQ3pELENBQUMsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUMvQixPQUFPO1lBQ0wsTUFBTSxFQUFFLE1BQU07WUFDZCxNQUFNLEVBQUUsR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDLGVBQWUsSUFBSTtTQUNqRCxDQUFDO0lBQ0osQ0FBQztJQUVNLGlCQUFpQjtRQUN0QixNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsT0FBZ0MsQ0FBQztRQUMzRCxNQUFNLEtBQUssR0FFUDtZQUNGLHVDQUF1QztZQUN2Qyw0Q0FBNEM7WUFDNUMsTUFBTSxFQUFFLEtBQUssWUFBWSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRTtTQUNwRCxDQUFDO1FBQ0YsT0FBTyxLQUFLLENBQUM7SUFDZixDQUFDO0lBRU0sc0JBQXNCO1FBQzNCLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxPQUFnQyxDQUFDO1FBQzNELE1BQU0sS0FBSyxHQUVQO1lBQ0YsT0FBTyxFQUFFLFlBQVksQ0FBQyxLQUFLLENBQUMsS0FBSztZQUNqQyx3REFBd0Q7U0FDekQsQ0FBQztRQUNGLE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVNLGNBQWM7UUFDbkIsTUFBTSxLQUFLLEdBRVAsRUFBRSxDQUFDO1FBQ1AsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1lBQzFFLEtBQUssQ0FDSCxrQkFBa0IsQ0FDbkIsR0FBRyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsc0JBQXNCLENBQUMsZUFBZSxHQUFHLENBQUM7WUFDbEUsS0FBSyxDQUFDLG1CQUFtQixDQUFDLEdBQUcsV0FBVyxDQUFDO1lBQ3pDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQztnQkFDMUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxrQkFBa0IsSUFBSSxRQUFRLENBQUM7WUFDckUsS0FBSyxDQUFDLGlCQUFpQixDQUFDO2dCQUN0QixJQUFJLENBQUMsT0FBTyxDQUFDLHNCQUFzQixDQUFDLGNBQWMsSUFBSSxPQUFPLENBQUM7UUFDbEUsQ0FBQztRQUNELE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVNLFFBQVE7UUFDYixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7SUFDeEIsQ0FBQztJQUVNLFdBQVcsQ0FBQyxPQUFzQjtRQUN2QyxJQUFJLFNBQVMsSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUN6QixJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7UUFDeEIsQ0FBQztJQUNILENBQUM7dUdBckhVLG9CQUFvQjsyRkFBcEIsb0JBQW9CLDZIQ25IakMsODREQTREQSx5b0REb0RZLE9BQU87OzJGQUdOLG9CQUFvQjtrQkFSaEMsU0FBUzsrQkFDRSxjQUFjLGNBR1osSUFBSSxXQUNQLENBQUMsT0FBTyxDQUFDLG1CQUNELHVCQUF1QixDQUFDLE1BQU07d0RBTXRDLE9BQU87c0JBQWYsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LFxuICBDb21wb25lbnQsXG4gIElucHV0LFxuICBPbkNoYW5nZXMsXG4gIE9uSW5pdCxcbiAgU2ltcGxlQ2hhbmdlcyxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOZ1N0eWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcblxuZXhwb3J0IGludGVyZmFjZSBJU2tlbGV0b25TaW5nbGVPcHRpb25zIHtcbiAgdHlwZTogJ3NpbmdsZSc7XG4gIHdpZHRoPzogc3RyaW5nO1xuICBoZWlnaHQ/OiBzdHJpbmc7XG4gIGJvcmRlclJhZGl1cz86IHN0cmluZztcbiAgYmFja2dyb3VuZEltYWdlT3B0aW9ucz86IHtcbiAgICBiYWNrZ3JvdW5kSW1hZ2U6IHN0cmluZztcbiAgICBiYWNrZ3JvdW5kU2l6ZT86IHN0cmluZztcbiAgICBiYWNrZ3JvdW5kUG9zaXRpb24/OiBzdHJpbmc7XG4gIH07XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSVNrZWxldG9uUm93IHtcbiAgaGVpZ2h0OiBzdHJpbmc7XG4gIG1hcmdpbjogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElTa2VsZXRvbkF1dG9Sb3cge1xuICBjb3VudDogbnVtYmVyO1xuICBtYXJnaW46IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBJU2tlbGV0b25BdXRvQ29sdW1uIHtcbiAgY291bnQ6IG51bWJlcjtcbiAgbWFyZ2luOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSVNrZWxldG9uQ29sdW1uIHtcbiAgd2lkdGg6IHN0cmluZztcbiAgbWFyZ2luOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSVNrZWxldG9uR3JpZE9wdGlvbnMge1xuICB0eXBlOiAnZ3JpZCc7XG4gIHJvd3M6IElTa2VsZXRvbkF1dG9Sb3cgfCBJU2tlbGV0b25Sb3dbXTtcbiAgY29sdW1uczogSVNrZWxldG9uQXV0b0NvbHVtbiB8IElTa2VsZXRvbkNvbHVtbltdO1xuICBib3JkZXJSYWRpdXM/OiBzdHJpbmc7XG4gIHdpZHRoPzogc3RyaW5nO1xuICBoZWlnaHQ/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgSVNrZWxldG9uVGFibGVPcHRpb25zIHtcbiAgdHlwZTogJ3RhYmxlJztcbiAgcm93czoge1xuICAgIGNvdW50OiBudW1iZXI7XG4gICAgdmVydGljYWxTcGFjaW5nOiBzdHJpbmc7XG4gICAgaGVpZ2h0OiBzdHJpbmc7XG4gIH07XG4gIGNvbHVtbnM6IHtcbiAgICBjb3VudDogbnVtYmVyO1xuICB9O1xuICBoZWFkZXI/OiB7XG4gICAgbWFyZ2luPzogc3RyaW5nO1xuICAgIGhlaWdodD86IHN0cmluZztcbiAgfTtcbiAgY2VsbHM6IHtcbiAgICBpbnNldDogc3RyaW5nO1xuICAgIGhvcml6b250YWxTcGFjaW5nOiBzdHJpbmc7XG4gIH07XG59XG5cbmV4cG9ydCB0eXBlIElTa2VsZXRvbk9wdGlvbnMgPVxuICB8IElTa2VsZXRvblNpbmdsZU9wdGlvbnNcbiAgfCBJU2tlbGV0b25HcmlkT3B0aW9uc1xuICB8IElTa2VsZXRvblRhYmxlT3B0aW9ucztcblxuLyoqXG4gKiBUaGlzIGNvbXBvbmVudCBzdHJlYW1saW5lcyBjcmVhdGlvbiBvZiBza2VsZXRvbiBsb2FkaW5nLXNlY3Rpb25zLiBIYXMgYSBmZXcgZGlmZmVyZW50IG1vZGVzIHlvdSBjYW4gY2hvb3NlIGZyb20sIGFsdGhvdWdoXG4gKiByaWdodCBub3cgdGhlIHRhYmxlLW1vZGUgaXMgcHJvYmFibHkgdGhlIG1vc3QgdXNlZnVsIG9uZS5cbiAqXG4gKiBFeGFtcGxlIHVzZTpcbiAqXG4gKiAgPG91aS1za2VsZXRvbiBbb3B0aW9uc109XCJsb2FkaW5nU2tlbGV0b25PcHRpb25zXCIgKm5nSWY9XCJpc0xvYWRpbmcgJiYgbG9hZGluZ1NrZWxldG9uT3B0aW9ucy5yb3dzLmNvdW50XCI+XG4gKiAgPC9vdWktc2tlbGV0b24+XG4gKlxuICogIFdoZXJlIGxvYWRpbmdTa2VsZXRvbk9wdGlvbnMgYXJlXG4gKlxuICogIHB1YmxpYyBsb2FkaW5nU2tlbGV0b25PcHRpb25zOiBJU2tlbGV0b25UYWJsZU9wdGlvbnMgPSB7XG4gKiAgICB0eXBlOiAndGFibGUnLFxuICogICAgcm93czoge1xuICogICAgICBjb3VudDogMCxcbiAqICAgICAgdmVydGljYWxTcGFjaW5nOiAnMTBweCcsXG4gKiAgICAgIGhlaWdodDogJzI1cHgnLFxuICogICAgfSxcbiAqICAgIGNvbHVtbnM6IHtcbiAqICAgICAgY291bnQ6IDQsXG4gKiAgICB9LFxuICogICAgY2VsbHM6IHtcbiAqICAgICAgaW5zZXQ6ICc0cHgnLFxuICogICAgICBob3Jpem9udGFsU3BhY2luZzogJzRweCcsXG4gKiAgICB9LFxuICogICAgaGVhZGVyOiB7XG4gKiAgICAgIG1hcmdpbjogJzE0cHgnLFxuICogICAgICBoZWlnaHQ6ICczMHB4JyxcbiAqICAgIH1cbiAqICB9XG4gKi9cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1za2VsZXRvbicsXG4gIHRlbXBsYXRlVXJsOiAnLi9za2VsZXRvbi5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL3NrZWxldG9uLmNvbXBvbmVudC5zY3NzJ10sXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtOZ1N0eWxlXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIE91aVNrZWxldG9uQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0LCBPbkNoYW5nZXMge1xuICAvKipcbiAgICogICBUaGUgb3B0aW9ucyB0aGF0IGRlZmluZSB0aGUgc2tlbGV0b24uIEN1cnJlbnRseSBzdWdnZXN0ZWQgdG8gdXNlIG9ubHkgdGhlIHRhYmxlLW1vZGUgdW50aWwgZnVydGhlciBtb2RlcyBoYXZlIGJlZW4gaW1wbGVtZW50ZWQuXG4gICAqL1xuICBASW5wdXQoKSBvcHRpb25zOiBJU2tlbGV0b25PcHRpb25zO1xuXG4gIHB1YmxpYyBjb2x1bW5zOiBJU2tlbGV0b25Db2x1bW5bXSA9IFtdO1xuICBwdWJsaWMgcm93czogSVNrZWxldG9uUm93W10gPSBbXTtcblxuICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgcHJpdmF0ZSBjb21iaW5lT3B0aW9ucygpIHtcbiAgICBpZiAodGhpcy5vcHRpb25zLnR5cGUgPT09ICdncmlkJyB8fCB0aGlzLm9wdGlvbnMudHlwZSA9PT0gJ3RhYmxlJykge1xuICAgICAgY29uc3QgZ3JpZE9wdGlvbnM6IElTa2VsZXRvbkdyaWRPcHRpb25zID0gdGhpc1xuICAgICAgICAub3B0aW9ucyBhcyBJU2tlbGV0b25HcmlkT3B0aW9ucztcblxuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoZ3JpZE9wdGlvbnMuY29sdW1ucykpIHtcbiAgICAgICAgdGhpcy5jb2x1bW5zID0gZ3JpZE9wdGlvbnMuY29sdW1ucyBhcyBJU2tlbGV0b25Db2x1bW5bXTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuY29sdW1ucyA9IEFycmF5KChncmlkT3B0aW9ucy5jb2x1bW5zIGFzIElTa2VsZXRvbkF1dG9Db2x1bW4pLmNvdW50KVxuICAgICAgICAgIC5maWxsKDApXG4gICAgICAgICAgLm1hcCgoKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICB3aWR0aDogJzEwcHgnLFxuICAgICAgICAgICAgICBtYXJnaW46IChncmlkT3B0aW9ucy5jb2x1bW5zIGFzIElTa2VsZXRvbkF1dG9Db2x1bW4pLm1hcmdpbixcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheShncmlkT3B0aW9ucy5yb3dzKSkge1xuICAgICAgICB0aGlzLnJvd3MgPSBncmlkT3B0aW9ucy5yb3dzIGFzIElTa2VsZXRvblJvd1tdO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5yb3dzID0gQXJyYXkoKGdyaWRPcHRpb25zLnJvd3MgYXMgSVNrZWxldG9uQXV0b1JvdykuY291bnQpXG4gICAgICAgICAgLmZpbGwoMClcbiAgICAgICAgICAubWFwKCgpID0+IHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgIGhlaWdodDogJzEwcHgnLFxuICAgICAgICAgICAgICBtYXJnaW46IChncmlkT3B0aW9ucy5yb3dzIGFzIElTa2VsZXRvbkF1dG9Sb3cpLm1hcmdpbixcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcHVibGljIGdldFJvd1N0eWxlKHJvdzogSVNrZWxldG9uUm93KSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGhlaWdodDogcm93LmhlaWdodCxcbiAgICAgIG1hcmdpbjogYCR7cm93Lm1hcmdpbn0gMGAsXG4gICAgfTtcbiAgfVxuXG4gIHB1YmxpYyBnZXRDb2x1bW5TdHlsZShjb2x1bW46IElTa2VsZXRvbkNvbHVtbikge1xuICAgIHJldHVybiB7XG4gICAgICB3aWR0aDogY29sdW1uLndpZHRoLFxuICAgICAgbWFyZ2luOiBgMCAke2NvbHVtbi5tYXJnaW59YCxcbiAgICB9O1xuICB9XG5cbiAgcHVibGljIGdldFRhYmxlUm93U3R5bGUodHlwZTogJ2hlYWQnIHwgJ2JvZHknKSB7XG4gICAgY29uc3QgdGFibGVPcHRpb25zID0gdGhpcy5vcHRpb25zIGFzIElTa2VsZXRvblRhYmxlT3B0aW9ucztcbiAgICBjb25zdCBoZWlnaHQgPVxuICAgICAgdHlwZSA9PT0gJ2hlYWQnXG4gICAgICAgID8gdGFibGVPcHRpb25zLmhlYWRlcj8uaGVpZ2h0ID8/IHRhYmxlT3B0aW9ucy5yb3dzLmhlaWdodFxuICAgICAgICA6IHRhYmxlT3B0aW9ucy5yb3dzLmhlaWdodDtcbiAgICByZXR1cm4ge1xuICAgICAgaGVpZ2h0OiBoZWlnaHQsXG4gICAgICBtYXJnaW46IGAke3RhYmxlT3B0aW9ucy5yb3dzLnZlcnRpY2FsU3BhY2luZ30gMGAsXG4gICAgfTtcbiAgfVxuXG4gIHB1YmxpYyBnZXRUYWJsZUNlbGxTdHlsZSgpIHtcbiAgICBjb25zdCB0YWJsZU9wdGlvbnMgPSB0aGlzLm9wdGlvbnMgYXMgSVNrZWxldG9uVGFibGVPcHRpb25zO1xuICAgIGNvbnN0IHN0eWxlOiB7XG4gICAgICBbeDogc3RyaW5nXTogc3RyaW5nO1xuICAgIH0gPSB7XG4gICAgICAvLyAncGFkZGluZyc6IHRhYmxlT3B0aW9ucy5jZWxscy5pbnNldCxcbiAgICAgIC8vICdib3JkZXItd2lkdGgnOiB0YWJsZU9wdGlvbnMuYm9yZGVyV2lkdGgsXG4gICAgICBtYXJnaW46IGAwICR7dGFibGVPcHRpb25zLmNlbGxzLmhvcml6b250YWxTcGFjaW5nfWAsXG4gICAgfTtcbiAgICByZXR1cm4gc3R5bGU7XG4gIH1cblxuICBwdWJsaWMgZ2V0VGFibGVJbm5lckNlbGxTdHlsZSgpIHtcbiAgICBjb25zdCB0YWJsZU9wdGlvbnMgPSB0aGlzLm9wdGlvbnMgYXMgSVNrZWxldG9uVGFibGVPcHRpb25zO1xuICAgIGNvbnN0IHN0eWxlOiB7XG4gICAgICBbeDogc3RyaW5nXTogc3RyaW5nO1xuICAgIH0gPSB7XG4gICAgICBwYWRkaW5nOiB0YWJsZU9wdGlvbnMuY2VsbHMuaW5zZXQsXG4gICAgICAvLyAnbWFyZ2luJzogYDAgJHt0YWJsZU9wdGlvbnMuY2VsbHMuaG9yaXpvbnRhbFNwYWNpbmd9YFxuICAgIH07XG4gICAgcmV0dXJuIHN0eWxlO1xuICB9XG5cbiAgcHVibGljIGdldFNpbmdsZVN0eWxlKCkge1xuICAgIGNvbnN0IHN0eWxlOiB7XG4gICAgICBbeDogc3RyaW5nXTogc3RyaW5nO1xuICAgIH0gPSB7fTtcbiAgICBpZiAodGhpcy5vcHRpb25zLnR5cGUgPT09ICdzaW5nbGUnICYmIHRoaXMub3B0aW9ucy5iYWNrZ3JvdW5kSW1hZ2VPcHRpb25zKSB7XG4gICAgICBzdHlsZVtcbiAgICAgICAgJ2JhY2tncm91bmQtaW1hZ2UnXG4gICAgICBdID0gYHVybCgke3RoaXMub3B0aW9ucy5iYWNrZ3JvdW5kSW1hZ2VPcHRpb25zLmJhY2tncm91bmRJbWFnZX0pYDtcbiAgICAgIHN0eWxlWydiYWNrZ3JvdW5kLXJlcGVhdCddID0gJ25vLXJlcGVhdCc7XG4gICAgICBzdHlsZVsnYmFja2dyb3VuZC1wb3NpdGlvbiddID1cbiAgICAgICAgdGhpcy5vcHRpb25zLmJhY2tncm91bmRJbWFnZU9wdGlvbnMuYmFja2dyb3VuZFBvc2l0aW9uID8/ICdjZW50ZXInO1xuICAgICAgc3R5bGVbJ2JhY2tncm91bmQtc2l6ZSddID1cbiAgICAgICAgdGhpcy5vcHRpb25zLmJhY2tncm91bmRJbWFnZU9wdGlvbnMuYmFja2dyb3VuZFNpemUgPz8gJ2NvdmVyJztcbiAgICB9XG4gICAgcmV0dXJuIHN0eWxlO1xuICB9XG5cbiAgcHVibGljIG5nT25Jbml0KCkge1xuICAgIHRoaXMuY29tYmluZU9wdGlvbnMoKTtcbiAgfVxuXG4gIHB1YmxpYyBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XG4gICAgaWYgKCdvcHRpb25zJyBpbiBjaGFuZ2VzKSB7XG4gICAgICB0aGlzLmNvbWJpbmVPcHRpb25zKCk7XG4gICAgfVxuICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwic2tlbGV0b24tY29udGFpbmVyXCI+XG4gIEBpZiAob3B0aW9ucy50eXBlID09PSAnZ3JpZCcpIHtcbiAgICA8ZGl2IGNsYXNzPVwic2tlbGV0b24tZ3JpZC1jb250YWluZXJcIj5cbiAgICAgIEBmb3IgKGNvbHVtbiBvZiBjb2x1bW5zOyB0cmFjayBjb2x1bW4pIHtcbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzPVwic2tlbGV0b24tY29sdW1uXCJcbiAgICAgICAgICBbbmdTdHlsZV09XCJ7IHdpZHRoOiBjb2x1bW4ud2lkdGgsIG1hcmdpbjogJzAgJyArIGNvbHVtbi5tYXJnaW4gfVwiXG4gICAgICAgICAgPlxuICAgICAgICAgIEBmb3IgKHJvdyBvZiByb3dzOyB0cmFjayByb3cpIHtcbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgY2xhc3M9XCJza2VsZXRvbi1yb3dcIlxuICAgICAgICAgICAgICBbbmdTdHlsZV09XCJ7IGhlaWdodDogcm93LmhlaWdodCwgbWFyZ2luOiByb3cubWFyZ2luICsgJyAwJyB9XCJcbiAgICAgICAgICAgID48L2Rpdj5cbiAgICAgICAgICB9XG4gICAgICAgIDwvZGl2PlxuICAgICAgfVxuICAgIDwvZGl2PlxuICB9XG4gIEBpZiAob3B0aW9ucy50eXBlID09PSAnc2luZ2xlJykge1xuICAgIDxkaXYgY2xhc3M9XCJza2VsZXRvbi1zaW5nbGUtY29udGFpbmVyXCI+XG4gICAgICA8ZGl2IGNsYXNzPVwic2tlbGV0b24tc2luZ2xlXCIgW25nU3R5bGVdPVwiZ2V0U2luZ2xlU3R5bGUoKVwiPjwvZGl2PlxuICAgIDwvZGl2PlxuICB9XG4gIEBpZiAob3B0aW9ucy50eXBlID09PSAndGFibGUnKSB7XG4gICAgPGRpdiBjbGFzcz1cInNrZWxldG9uLXRhYmxlLWNvbnRhaW5lclwiPlxuICAgICAgPGRpdiBjbGFzcz1cInNrZWxldG9uLXRhYmxlXCI+XG4gICAgICAgIEBpZiAob3B0aW9ucy5oZWFkZXIpIHtcbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzcz1cInNrZWxldG9uLXRhYmxlLWhlYWRcIlxuICAgICAgICAgICAgW25nU3R5bGVdPVwiZ2V0VGFibGVSb3dTdHlsZSgnaGVhZCcpXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgIEBmb3IgKGNvbHVtbiBvZiBjb2x1bW5zOyB0cmFjayBjb2x1bW4pIHtcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGNsYXNzPVwic2tlbGV0b24tdGFibGUtaGVhZC1jZWxsIGNlbGxcIlxuICAgICAgICAgICAgICAgIFtuZ1N0eWxlXT1cImdldFRhYmxlQ2VsbFN0eWxlKClcIlxuICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVwiY2VsbC1pbm5lclwiIFtuZ1N0eWxlXT1cImdldFRhYmxlSW5uZXJDZWxsU3R5bGUoKVwiPjwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIH1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgfVxuICAgICAgICBAZm9yIChyb3cgb2Ygcm93czsgdHJhY2sgcm93KSB7XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3M9XCJza2VsZXRvbi10YWJsZS1yb3dcIlxuICAgICAgICAgICAgW25nU3R5bGVdPVwiZ2V0VGFibGVSb3dTdHlsZSgnYm9keScpXCJcbiAgICAgICAgICAgID5cbiAgICAgICAgICAgIEBmb3IgKGNvbHVtbiBvZiBjb2x1bW5zOyB0cmFjayBjb2x1bW4pIHtcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGNsYXNzPVwic2tlbGV0b24tdGFibGUtcm93LWNlbGwgY2VsbFwiXG4gICAgICAgICAgICAgICAgW25nU3R5bGVdPVwiZ2V0VGFibGVDZWxsU3R5bGUoKVwiXG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XCJjZWxsLWlubmVyXCIgW25nU3R5bGVdPVwiZ2V0VGFibGVJbm5lckNlbGxTdHlsZSgpXCI+PC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgfVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICB9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgfVxuPC9kaXY+XG4iXX0=