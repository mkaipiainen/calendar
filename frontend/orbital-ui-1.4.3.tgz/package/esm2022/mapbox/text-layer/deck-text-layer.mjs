import { TextLayer } from '@deck.gl/layers/typed';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { BindCommonDeckOptions } from '../deck/bind-default-deck-options';
import * as i0 from "@angular/core";
export class DeckTextLayer extends BaseDeckLayer {
    name = 'Text';
    options;
    constructor() {
        super();
    }
    getLayer() {
        new TextLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            characterSet: this.options.characterSet ?? 'auto',
            getText: this.options.getText,
            getPosition: this.options.getPosition,
            getColor: this.options.getColor ? this.options.getColor : [0, 0, 0, 255],
            getSize: this.options.getSize ? this.options.getSize : 20,
            sizeScale: this.options.sizeScale ?? 1,
            updateTriggers: this.options.updateTriggers ?? [],
            getAngle: 0,
            getTextAnchor: this.options.getTextAnchor,
            getAlignmentBaseline: this.options.getAlignmentBaseline ?? 'top',
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckTextLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckTextLayer, isStandalone: true, selector: "oui-deck-text-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckTextLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-text-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay10ZXh0LWxheWVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9tYXBib3gvdGV4dC1sYXllci9kZWNrLXRleHQtbGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBRWxELE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM3RCxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQzs7QUFTMUUsTUFBTSxPQUFPLGFBQWMsU0FBUSxhQUFzQztJQUNoRSxJQUFJLEdBQUcsTUFBTSxDQUFDO0lBQ2MsT0FBTyxDQUF3QjtJQUVsRTtRQUNFLEtBQUssRUFBRSxDQUFDO0lBQ1YsQ0FBQztJQUVNLFFBQVE7UUFDYixJQUFJLFNBQVMsQ0FBQztZQUNaLEdBQUcscUJBQXFCLENBQUMsSUFBSSxDQUFDO1lBQzlCLElBQUksRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUk7WUFDdkIsWUFBWSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxJQUFJLE1BQU07WUFDakQsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTztZQUM3QixXQUFXLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXO1lBQ3JDLFFBQVEsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDO1lBQ3hFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDekQsU0FBUyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxJQUFJLENBQUM7WUFDdEMsY0FBYyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsY0FBYyxJQUFJLEVBQUU7WUFDakQsUUFBUSxFQUFFLENBQUM7WUFDWCxhQUFhLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhO1lBQ3pDLG9CQUFvQixFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsb0JBQW9CLElBQUksS0FBSztTQUNqRSxDQUFDLENBQUM7SUFDTCxDQUFDO3VHQXZCVSxhQUFhOzJGQUFiLGFBQWEsc0lBTGQsRUFBRTs7MkZBS0QsYUFBYTtrQkFQekIsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUscUJBQXFCO29CQUMvQixRQUFRLEVBQUUsRUFBRTtvQkFDWixVQUFVLEVBQUUsSUFBSTtvQkFDaEIsT0FBTyxFQUFFLEVBQUU7b0JBQ1gsZUFBZSxFQUFFLHVCQUF1QixDQUFDLE1BQU07aUJBQ2hEO3dEQUdvQyxPQUFPO3NCQUF6QyxLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFRleHRMYXllciB9IGZyb20gJ0BkZWNrLmdsL2xheWVycy90eXBlZCc7XG5pbXBvcnQgeyBJQ29tbW9uRGVja0xheWVyT3B0aW9ucywgSURlY2tUZXh0TGF5ZXJPcHRpb25zIH0gZnJvbSAnLi4vdHlwaW5ncyc7XG5pbXBvcnQgeyBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSwgQ29tcG9uZW50LCBJbnB1dCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmFzZURlY2tMYXllciB9IGZyb20gJy4uL2Jhc2UtZGVjay1sYXllci5jb21wb25lbnQnO1xuaW1wb3J0IHsgQmluZENvbW1vbkRlY2tPcHRpb25zIH0gZnJvbSAnLi4vZGVjay9iaW5kLWRlZmF1bHQtZGVjay1vcHRpb25zJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLWRlY2stdGV4dC1sYXllcicsXG4gIHRlbXBsYXRlOiAnJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW10sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBEZWNrVGV4dExheWVyIGV4dGVuZHMgQmFzZURlY2tMYXllcjxJQ29tbW9uRGVja0xheWVyT3B0aW9ucz4ge1xuICBwdWJsaWMgbmFtZSA9ICdUZXh0JztcbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSkgZGVjbGFyZSBvcHRpb25zOiBJRGVja1RleHRMYXllck9wdGlvbnM7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHB1YmxpYyBnZXRMYXllcigpIHtcbiAgICBuZXcgVGV4dExheWVyKHtcbiAgICAgIC4uLkJpbmRDb21tb25EZWNrT3B0aW9ucyh0aGlzKSxcbiAgICAgIGRhdGE6IHRoaXMub3B0aW9ucy5kYXRhLFxuICAgICAgY2hhcmFjdGVyU2V0OiB0aGlzLm9wdGlvbnMuY2hhcmFjdGVyU2V0ID8/ICdhdXRvJyxcbiAgICAgIGdldFRleHQ6IHRoaXMub3B0aW9ucy5nZXRUZXh0LFxuICAgICAgZ2V0UG9zaXRpb246IHRoaXMub3B0aW9ucy5nZXRQb3NpdGlvbixcbiAgICAgIGdldENvbG9yOiB0aGlzLm9wdGlvbnMuZ2V0Q29sb3IgPyB0aGlzLm9wdGlvbnMuZ2V0Q29sb3IgOiBbMCwgMCwgMCwgMjU1XSxcbiAgICAgIGdldFNpemU6IHRoaXMub3B0aW9ucy5nZXRTaXplID8gdGhpcy5vcHRpb25zLmdldFNpemUgOiAyMCxcbiAgICAgIHNpemVTY2FsZTogdGhpcy5vcHRpb25zLnNpemVTY2FsZSA/PyAxLFxuICAgICAgdXBkYXRlVHJpZ2dlcnM6IHRoaXMub3B0aW9ucy51cGRhdGVUcmlnZ2VycyA/PyBbXSxcbiAgICAgIGdldEFuZ2xlOiAwLFxuICAgICAgZ2V0VGV4dEFuY2hvcjogdGhpcy5vcHRpb25zLmdldFRleHRBbmNob3IsXG4gICAgICBnZXRBbGlnbm1lbnRCYXNlbGluZTogdGhpcy5vcHRpb25zLmdldEFsaWdubWVudEJhc2VsaW5lID8/ICd0b3AnLFxuICAgIH0pO1xuICB9XG59XG4iXX0=