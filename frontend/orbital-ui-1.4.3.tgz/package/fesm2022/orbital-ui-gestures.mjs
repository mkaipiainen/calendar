import * as i0 from '@angular/core';
import { Directive, Inject, Input } from '@angular/core';
import { DOCUMENT } from '@angular/common';

/**
 * TinyGesture.js
 *
 * This service uses passive listeners, so you can't call event.preventDefault()
 * on any of the events.
 *
 * Adapted from https://gist.github.com/SleepWalker/da5636b1abcbaff48c4d
 * and https://github.com/uxitten/xwiper
 */
class OuiGesturesDirective {
    renderer;
    elementRef;
    document;
    destroyRef;
    set gestureOptions(options) {
        this.#combinedOptions = {
            disabled: options.disabled ?? false,
            swipe: options.swipe
                ? {
                    velocityThreshold: 0,
                    requiredSwipeDistance: 50,
                    distanceToDisregardVelocity: Infinity,
                    hasDiagonalSwipes: false,
                    diagonalLimit: Math.tan(((45 * 1.5) / 180) * Math.PI),
                    ...options.swipe,
                }
                : undefined,
            doubleTap: options.doubleTap
                ? {
                    ...options.doubleTap,
                }
                : undefined,
            longPress: options.longPress
                ? { pressThreshold: 10, ...options.longPress }
                : undefined,
        };
        this.#originalOptions = options;
    }
    get gestureOptions() {
        return this.#originalOptions;
    }
    #isPassiveSupported = {
        passive: false,
    };
    #longPressTimer = null;
    #originalOptions;
    #combinedOptions;
    touchStartX = null;
    touchStartY = null;
    touchEndX = null;
    touchEndY = null;
    touchMoveX = null;
    touchMoveY = null;
    velocityX = 0;
    velocityY = 0;
    longPressTimer = null;
    doubleTapTimer = null;
    doubleTapWaiting = false;
    swipingHorizontal = false;
    swipingVertical = false;
    swipingDirection = null;
    swipedHorizontal = false;
    swipedVertical = false;
    unlisteners = {};
    constructor(renderer, elementRef, document, destroyRef) {
        // Check if passive is supported
        this.renderer = renderer;
        this.elementRef = elementRef;
        this.document = document;
        this.destroyRef = destroyRef;
        try {
            window.addEventListener('test', null, Object.defineProperty({}, 'passive', {
                get: () => {
                    this.#isPassiveSupported = { passive: true };
                },
            }));
        }
        catch (err) { }
    }
    ngAfterViewInit() {
        this.renderer.setStyle(this.elementRef.nativeElement, 'user-gestures', 'none');
        this.renderer.setStyle(this.elementRef.nativeElement, 'touch-action', 'none');
        this.unlisteners['touchstart'] = this.renderer.listen(this.elementRef.nativeElement, 'touchstart', this.onTouchStart.bind(this));
        this.unlisteners['touchmove'] = this.renderer.listen(this.document.body, 'touchmove', this.onTouchMove.bind(this));
        this.unlisteners['touchend'] = this.renderer.listen(this.document.body, 'touchend', this.onTouchEnd.bind(this));
        this.unlisteners['mousedown'] = this.renderer.listen(this.elementRef.nativeElement, 'mousedown', this.onTouchStart.bind(this));
        this.unlisteners['mousemove'] = this.renderer.listen(this.document.body, 'mousemove', this.onTouchMove.bind(this));
        this.unlisteners['mouseup'] = this.renderer.listen(this.document.body, 'mouseup', this.onTouchEnd.bind(this));
        this.destroyRef.onDestroy(() => {
            for (let unlistener of Object.values(this.unlisteners)) {
                unlistener();
            }
        });
    }
    ngOnDestroy() {
        clearTimeout(this.longPressTimer ?? undefined);
        clearTimeout(this.doubleTapTimer ?? undefined);
        for (let unlistener of Object.values(this.unlisteners)) {
            unlistener();
        }
    }
    onTouchStart(event) {
        if (this.#combinedOptions.disabled) {
            return;
        }
        this.touchStartX =
            event.type === 'mousedown'
                ? event.screenX
                : event.changedTouches[0].screenX;
        this.touchStartY =
            event.type === 'mousedown'
                ? event.screenY
                : event.changedTouches[0].screenY;
        this.touchMoveX = null;
        this.touchMoveY = null;
        this.touchEndX = null;
        this.touchEndY = null;
        this.swipingDirection = null;
        // Long press.
        if (this.#combinedOptions.longPress) {
            this.#longPressTimer = setTimeout(() => {
                if (this.#combinedOptions.longPress) {
                    this.#combinedOptions.longPress.onLongPress(event);
                }
            }, this.#combinedOptions.longPress.time);
        }
    }
    onTouchMove(event) {
        if (this.#combinedOptions.disabled) {
            return;
        }
        if (event.type === 'mousemove' &&
            (!this.touchStartX || this.touchEndX !== null)) {
            return;
        }
        const touchMoveX = (event.type === 'mousemove'
            ? event.screenX
            : event.changedTouches[0].screenX) -
            (this.touchStartX ?? 0);
        this.velocityX = touchMoveX - (this.touchMoveX ?? 0);
        this.touchMoveX = touchMoveX;
        const touchMoveY = (event.type === 'mousemove'
            ? event.screenY
            : event.changedTouches[0].screenY) -
            (this.touchStartY ?? 0);
        this.velocityY = touchMoveY - (this.touchMoveY ?? 0);
        this.touchMoveY = touchMoveY;
        const absTouchMoveX = Math.abs(this.touchMoveX);
        const absTouchMoveY = Math.abs(this.touchMoveY);
        this.swipingHorizontal = this.#combinedOptions.swipe
            ? absTouchMoveX > this.#combinedOptions.swipe.requiredSwipeDistance
            : false;
        this.swipingVertical = this.#combinedOptions.swipe
            ? absTouchMoveY > this.#combinedOptions.swipe.requiredSwipeDistance
            : false;
        if (this.#combinedOptions.longPress) {
            if (Math.max(absTouchMoveX, absTouchMoveY) >
                this.#combinedOptions.longPress.pressThreshold) {
                clearTimeout(this.longPressTimer ?? undefined);
            }
        }
    }
    onTouchEnd(event) {
        if (this.#combinedOptions.disabled ||
            !this.touchStartX ||
            !this.touchStartY ||
            !this.touchMoveX ||
            !this.touchMoveY) {
            return;
        }
        if (event.type === 'mouseup' &&
            (!this.touchStartX || this.touchEndX !== null)) {
            return;
        }
        this.touchEndX =
            event.type === 'mouseup'
                ? event.screenX
                : event.changedTouches[0].screenX;
        this.touchEndY =
            event.type === 'mouseup'
                ? event.screenY
                : event.changedTouches[0].screenY;
        clearTimeout(this.longPressTimer ?? undefined);
        const x = this.touchEndX - (this.touchStartX ?? 0);
        const absX = Math.abs(x);
        const y = this.touchEndY - (this.touchStartY ?? 0);
        const absY = Math.abs(y);
        if (this.#combinedOptions.swipe) {
            if (absX > this.#combinedOptions.swipe.requiredSwipeDistance ||
                absY > this.#combinedOptions.swipe.requiredSwipeDistance) {
                this.swipedHorizontal = this.#combinedOptions.swipe.hasDiagonalSwipes
                    ? Math.abs(x / y) <= this.#combinedOptions.swipe.diagonalLimit
                    : absX >= absY &&
                        absX > this.#combinedOptions.swipe.requiredSwipeDistance;
                this.swipedVertical = this.#combinedOptions.swipe.hasDiagonalSwipes
                    ? Math.abs(y / x) <= this.#combinedOptions.swipe.diagonalLimit
                    : absY > absX &&
                        absY > this.#combinedOptions.swipe.requiredSwipeDistance;
                if (this.swipedHorizontal) {
                    if (x < 0) {
                        // Left swipe.
                        if ((this.velocityX ?? 0) <
                            -this.#combinedOptions.swipe.velocityThreshold ||
                            x < -this.#combinedOptions.swipe.distanceToDisregardVelocity) {
                            this.#combinedOptions.swipe.onSwipe({
                                type: 'left',
                                velocityX: this.velocityX,
                                velocityY: this.velocityY,
                                distanceX: absX,
                                distanceY: absY,
                                event,
                            });
                        }
                    }
                    else {
                        // Right swipe.
                        if ((this.velocityX ?? 0) >
                            this.#combinedOptions.swipe.velocityThreshold ||
                            x > this.#combinedOptions.swipe.distanceToDisregardVelocity) {
                            this.#combinedOptions.swipe.onSwipe({
                                type: 'right',
                                velocityX: this.velocityX,
                                velocityY: this.velocityY,
                                distanceX: absX,
                                distanceY: absY,
                                event,
                            });
                        }
                    }
                }
                if (this.swipedVertical) {
                    if (y < 0) {
                        // Upward swipe.
                        if ((this.velocityY ?? 0) <
                            -this.#combinedOptions.swipe.velocityThreshold ||
                            y < -this.#combinedOptions.swipe.distanceToDisregardVelocity) {
                            this.#combinedOptions.swipe.onSwipe({
                                type: 'up',
                                velocityX: this.velocityX,
                                velocityY: this.velocityY,
                                distanceX: absX,
                                distanceY: absY,
                                event,
                            });
                        }
                    }
                    else {
                        // Downward swipe.
                        if ((this.velocityY ?? 0) >
                            this.#combinedOptions.swipe.velocityThreshold ||
                            y > this.#combinedOptions.swipe.distanceToDisregardVelocity) {
                            this.#combinedOptions.swipe.onSwipe({
                                type: 'down',
                                velocityX: this.velocityX,
                                velocityY: this.velocityY,
                                distanceX: absX,
                                distanceY: absY,
                                event,
                            });
                        }
                    }
                }
            }
        }
        if (this.#combinedOptions.doubleTap) {
            if (this.doubleTapWaiting) {
                this.doubleTapWaiting = false;
                clearTimeout(this.doubleTapTimer ?? undefined);
                this.#combinedOptions.doubleTap.onDoubleTap(event);
            }
            else {
                this.doubleTapWaiting = true;
                this.doubleTapTimer = setTimeout(() => (this.doubleTapWaiting = false), this.#combinedOptions.doubleTap.time);
            }
        }
        this.touchStartX = null;
        this.touchStartY = null;
        this.touchMoveX = null;
        this.touchMoveY = null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiGesturesDirective, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }, { token: DOCUMENT }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.1", type: OuiGesturesDirective, isStandalone: true, selector: "[oui-gestures]", inputs: { gestureOptions: "gestureOptions" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiGesturesDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[oui-gestures]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.DestroyRef }], propDecorators: { gestureOptions: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiGesturesDirective };
//# sourceMappingURL=orbital-ui-gestures.mjs.map
