import { AfterViewInit, ElementRef, OnChanges, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Can be used to add loading spinners. Control whether or not the spinner is visible with the *ngIf directive.
 */
export declare class OuiSpinnerComponent implements AfterViewInit, OnChanges {
    svgElement: ElementRef;
    pathElement: ElementRef;
    spinnerContainer: ElementRef;
    /**
     *   Either a color defined in the COLORS-constant, or alternatively a css-variable
     */
    color: string;
    /**
     *   The size of the spinner
     */
    size: string;
    type: 'stroke' | 'solid';
    constructor();
    ngAfterViewInit(): void;
    private updateColor;
    private updateSize;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiSpinnerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiSpinnerComponent, "oui-spinner", never, { "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; "type": { "alias": "type"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=spinner.component.d.ts.map