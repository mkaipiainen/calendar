export * from './is-nil.pipe';
//# sourceMappingURL=public-api.d.ts.map