import { ApplicationRef, EnvironmentInjector, NgZone, RendererFactory2 } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { Router } from '@angular/router';
import { ComponentType } from '@angular/cdk/overlay';
import { OuiDialogComponent } from './dialog.component';
import * as i0 from "@angular/core";
export interface IDialogOptions {
    id?: string;
    closeOnEscape?: boolean;
    classList?: string[];
    closeOnOutsideClick?: boolean;
}
export interface IDialog {
    dialogElement: HTMLElement;
    componentRef: any;
    id: string;
    subject: Subject<IDialogSubject>;
    options: IDialogOptions;
}
export interface IDialogSubject {
    confirm: boolean;
    data: any;
}
/**
 * This service can be used to open dialogs. You can pass in a custom dialog, which will be inserted
 * into the DOM and opened. You can call dialogService.submitDialog or dialogService.cancelDialog to easily close or open the dialog.
 * Alternatively, you can pass the option closeOnEscape to automatically close the dialog when the escape key is pressed.
 *
 * When creating new components, the workflow is as follows:
 *  - Create a component extended from OuiDialogComponent
 *  - Open the component using the openDialog() method
 *  - The openDialog returns an observable you can subscribe to in order to get the result of the dialog
 *
 *
 * Example:
 *
 * ouiDialogService.openDialog(StConfirmDialogComponent, {title: 'This is an example title'}, {closeOnEscape: true}).subscribe((result) => {
 *   if(result.confirm) {
 *     // User confirmed the dialog, do something
 *   } else {
 *     // User canceled the dialog, do something else
 *   }
 * });
 */
export declare class OuiDialogService {
    private router;
    private zone;
    private appRef;
    private injector;
    private rendererFactory;
    private document;
    private overlay;
    private wrapper;
    private openDialogs;
    private renderer;
    constructor(router: Router, zone: NgZone, appRef: ApplicationRef, injector: EnvironmentInjector, rendererFactory: RendererFactory2, document: Document);
    onEscapePress(): void;
    destroyDialogs(): void;
    /**
     * Opens a dialog with the given content and options. The content can be any component, which will be inserted into the DOM.
     * @param content The component to be used for the dialog
     * @param inputs A javascript object of inputs to be passed to the component
     * @param options Options for the dialog. See IDialogOptions for more information.
     */
    openDialog<T extends OuiDialogComponent>(content: ComponentType<T>, inputs: {
        [x: string]: unknown;
    }, options?: IDialogOptions): Observable<IDialogSubject>;
    submitDialog(id: string, data: any): void;
    cancelDialog(id: string, data: any): void;
    dispose(id: string): void;
    private doDispose;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiDialogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiDialogService>;
}
//# sourceMappingURL=dialog.service.d.ts.map