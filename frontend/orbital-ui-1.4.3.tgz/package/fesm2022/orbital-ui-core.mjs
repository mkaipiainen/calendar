import * as i0 from '@angular/core';
import { Injectable } from '@angular/core';
import { Subject, take } from 'rxjs';

/**
 * Used to queue requests done by the Deck.GL tileLayer.
 * This is needed in cases where the token expires in the middle of loading tiles, in which case
 * requests go into a queue, and are then executed once the token has been refreshed.
 *
 * This is used by rasterLayerService, which should be used for handling optical layers for maps.
 */
class RequestQueueService {
    refreshRequiredSubject = new Subject();
    refreshRequired$ = this.refreshRequiredSubject.asObservable();
    queue = [];
    isRefreshingToken = false;
    constructor() { }
    addToQueue(promise, signal, refreshedAccessToken$) {
        let promiseResolve;
        let promiseReject;
        const wrapperPromise = new Promise((resolve, reject) => {
            promiseResolve = resolve;
            promiseReject = reject;
        });
        promise
            .catch(error => {
            promiseReject(error);
        })
            .then((result) => {
            if (!result) {
                promiseReject(result);
                return;
            }
            if (result.status === 401 && !refreshedAccessToken$) {
                promiseReject(result);
            }
            else if (result.status === 401 && refreshedAccessToken$) {
                this.queue.push(result);
                if (!this.isRefreshingToken) {
                    this.isRefreshingToken = true;
                    this.refreshRequiredSubject.next();
                    refreshedAccessToken$.pipe(take(1)).subscribe(token => {
                        this.isRefreshingToken = false;
                        for (const singleResult of this.queue) {
                            fetch(singleResult.url, {
                                signal,
                                headers: {
                                    Authorization: `Bearer ${token}`,
                                },
                            })
                                .then(response => {
                                promiseResolve(response);
                            }, error => {
                                promiseReject(error);
                            })
                                .catch(error => {
                                console.log(error);
                            });
                        }
                        this.queue = [];
                    });
                }
            }
            else if (result.status !== 200) {
                promiseReject(result);
            }
            else {
                promiseResolve(result);
            }
        }, error => {
            promiseResolve(error);
        });
        return wrapperPromise;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: RequestQueueService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: RequestQueueService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: RequestQueueService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

function IsImageBrokerImage(image) {
    return 'wms_data' in image || 'wmts_data' in image;
}
function IsWmtsImageBrokerImage(image) {
    return IsImageBrokerImage(image) && 'wmts_data' in image && !!image.wmts_data;
}
function IsWmsImageBrokerImage(image) {
    return IsImageBrokerImage(image) && !IsWmtsImageBrokerImage(image);
}
function IsS2Image(image) {
    return ('pixel_resolution_x' in image &&
        'image_url' in image &&
        'wms_layer_name' in image);
}

/**
 * Generated bundle index. Do not edit.
 */

export { IsImageBrokerImage, IsS2Image, IsWmsImageBrokerImage, IsWmtsImageBrokerImage, RequestQueueService };
//# sourceMappingURL=orbital-ui-core.mjs.map
