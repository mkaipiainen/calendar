import * as i0 from '@angular/core';
import { Pipe } from '@angular/core';
import { isNil } from 'lodash-es';

/**
 * Pipe to check if a value is null or undefined
 * @param value value to check
 */
class IsNilPipe {
    transform(value) {
        return isNil(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsNilPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: IsNilPipe, isStandalone: true, name: "isNil" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsNilPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'isNil',
                    standalone: true,
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { IsNilPipe };
//# sourceMappingURL=orbital-ui-pipes.mjs.map
