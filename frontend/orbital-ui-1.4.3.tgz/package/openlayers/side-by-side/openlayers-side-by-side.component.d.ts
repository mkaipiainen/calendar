import { AfterViewInit, DestroyRef, ElementRef, EventEmitter, OnDestroy, Renderer2, TemplateRef } from '@angular/core';
import { IOuiSliderOptions } from 'orbital-ui/slider';
import { IOuiDragMove, OuiDraggableDirective } from 'orbital-ui/draggable';
import { OpenlayersComponent } from '../openlayers.component';
import { OpenlayersSideBySideOptions, OuiLonLatBounds } from '../types';
import * as i0 from "@angular/core";
export type ClipCoordinates = [
    [
        number,
        number
    ],
    [
        number,
        number
    ],
    [
        number,
        number
    ],
    [
        number,
        number
    ]
];
export interface IClipChange {
    left: ClipCoordinates;
    right: ClipCoordinates;
}
export declare class OpenlayersSideBySideComponent implements AfterViewInit, OnDestroy {
    private renderer;
    private destroyRef;
    private elementRef;
    private document;
    leftLabelTemplate: import("@angular/core").InputSignal<TemplateRef<any> | undefined>;
    rightLabelTemplate: import("@angular/core").InputSignal<TemplateRef<any> | undefined>;
    mapContainer: import("@angular/core").InputSignal<ElementRef<any>>;
    map: import("@angular/core").InputSignal<OpenlayersComponent>;
    options: import("@angular/core").InputSignal<OpenlayersSideBySideOptions>;
    clipChange: EventEmitter<IClipChange>;
    dragged: EventEmitter<any>;
    clicked: EventEmitter<any>;
    released: EventEmitter<any>;
    private dragContainer;
    private drag;
    private imageLabelRight;
    private imageLabelLeft;
    thumbIconTemplate: TemplateRef<any>;
    mapContent: ElementRef;
    draggable: OuiDraggableDirective;
    mapsWrapper: ElementRef;
    gammaMaskRight: ElementRef;
    gammaMaskLeft: ElementRef;
    private currentDragPosition;
    private resizeObserver;
    private dragLeftRatio;
    private dragLeftRatioWithDragWidthOffset;
    private isInitialisationStarted;
    private refreshInterval;
    private debouncedEndClip;
    private unlisteners;
    private mapListeners;
    isInitialised: import("@angular/core").WritableSignal<boolean>;
    isVertical: import("@angular/core").WritableSignal<boolean>;
    beforeGamma: import("@angular/core").WritableSignal<number>;
    afterGamma: import("@angular/core").WritableSignal<number>;
    gammaSliderOptions: import("@angular/core").WritableSignal<IOuiSliderOptions>;
    currentBounds: import("@angular/core").WritableSignal<OuiLonLatBounds | undefined>;
    constructor(renderer: Renderer2, destroyRef: DestroyRef, elementRef: ElementRef, document: Document);
    ngAfterViewInit(): void;
    private initDraggable;
    private subscribeToMapLoad;
    private initialiseComponent;
    private getMapContainerWidth;
    private getMapContainerHeight;
    private getDragWidthOffset;
    private getDragHeightOffset;
    private getDragContainerWidthOffset;
    private getDragContainerHeightOffset;
    private getClip;
    private initializeEventListeners;
    private storeBounds;
    private getClipAndEmit;
    onDragMove(event: IOuiDragMove): void;
    onDragEnd(): void;
    private setLeftLabelPosition;
    private resizeSideBySide;
    private initializeResizeObserver;
    private startClipping;
    private endClipping;
    onBeforeGammaChange(value: number): void;
    onAfterGammaChange(value: number): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpenlayersSideBySideComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpenlayersSideBySideComponent, "oui-openlayers-side-by-side", never, { "leftLabelTemplate": { "alias": "leftLabelTemplate"; "required": false; "isSignal": true; }; "rightLabelTemplate": { "alias": "rightLabelTemplate"; "required": false; "isSignal": true; }; "mapContainer": { "alias": "mapContainer"; "required": true; "isSignal": true; }; "map": { "alias": "map"; "required": true; "isSignal": true; }; "options": { "alias": "options"; "required": true; "isSignal": true; }; }, { "clipChange": "clipChange"; "dragged": "dragged"; "clicked": "clicked"; "released": "released"; }, never, ["*"], true, never>;
}
//# sourceMappingURL=openlayers-side-by-side.component.d.ts.map