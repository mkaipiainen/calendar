import { ChangeDetectionStrategy, Component, computed, effect, Inject, input, signal, } from '@angular/core';
import { isFunction } from 'lodash-es';
import { OpenlayersBaseLayerComponent } from './openlayers-base-layer.component';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import { Circle, Fill, Stroke, Style } from 'ol/style';
import { Draw, Modify, Select, Snap } from 'ol/interaction';
import { fromEvent, take } from 'rxjs';
import { GeoJSON } from 'ol/format';
import { DEFAULT_COMMON_OPTIONS } from '../constants';
import { DOCUMENT } from '@angular/common';
import { takeUntilDestroyed, toObservable } from '@angular/core/rxjs-interop';
import * as i0 from "@angular/core";
export class OpenlayersEditableGeojsonLayerComponent extends OpenlayersBaseLayerComponent {
    document;
    options = input.required();
    isDrawingEnabled = input.required();
    source = signal(new VectorSource());
    layer = signal(new VectorLayer({
        source: this.source(),
        style: feature => {
            return this.getStyleForFeature(feature);
        },
    }));
    selectInteraction = signal(new Select({
        filter: (feature) => {
            const isEditable = this.combinedOptions().isFeatureEditable;
            return isEditable ? isEditable(feature) : true;
        },
    }));
    drawInteraction = signal(new Draw({
        source: this.source(),
        type: 'Polygon',
    }));
    modifyInteraction = signal(new Modify({
        source: this.source(),
        features: this.selectInteraction().getFeatures(),
    }));
    snapInteraction = signal(new Snap({ source: this.source() }));
    drawEventListeners = {
        drawstart: this.onDrawStart.bind(this),
        drawend: this.onDrawEnd.bind(this),
    };
    modifyEventListeners = {
        modifyend: this.onModifyEnd.bind(this),
    };
    combinedOptions = computed(() => {
        return {
            ...DEFAULT_COMMON_OPTIONS,
            ...{
                getFillColor: [255, 0, 0, 255],
                getStrokeColor: [0, 0, 0, 255],
            },
            ...this.options(),
        };
    });
    constructor(document) {
        super();
        this.document = document;
        toObservable(this.combinedOptions)
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(newOptions => {
            this.refreshDrawInteraction();
        });
        effect(() => {
            const map = this.map().state.map();
            if (map) {
                map.removeInteraction(this.drawInteraction());
                map.addInteraction(this.drawInteraction());
            }
        });
        effect(() => {
            this.toggleDrawing(this.isDrawingEnabled());
        });
        fromEvent(this.document.body, 'keydown')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((evt) => {
            if (evt.key === 'Escape') {
                const interaction = this.drawInteraction();
                if (interaction) {
                    interaction.abortDrawing();
                    this.selectInteraction().setActive(true);
                }
            }
        });
    }
    ngAfterViewInit() {
        this.addDrawEventListeners();
        this.addModifyEventListeners();
    }
    getStyleForFeature(feature, isHighlighted = false) {
        const fillColorAccessor = isHighlighted
            ? this.combinedOptions().highlightColor ??
                this.combinedOptions().getFillColor
            : this.combinedOptions().getFillColor;
        const fillColor = fillColorAccessor instanceof Function
            ? fillColorAccessor(feature)
            : [...fillColorAccessor];
        fillColor[3] = fillColor[3] / 255;
        const strokeColorAccessor = isFunction(this.combinedOptions().getStrokeColor)
            ? this.combinedOptions().getStrokeColor
            : this.combinedOptions().getStrokeColor;
        const strokeColor = strokeColorAccessor instanceof Function
            ? strokeColorAccessor(feature)
            : [...strokeColorAccessor];
        strokeColor[3] = strokeColor[3] / 255;
        const lineWidth = isFunction(this.combinedOptions().getLineWidth)
            ? this.combinedOptions().getLineWidth(feature)
            : this.combinedOptions().getLineWidth;
        const type = feature.getGeometry()?.getType();
        if (type === 'Point') {
            return new Style({
                image: new Circle({
                    radius: this.combinedOptions().pointRadius ?? 5,
                    fill: new Fill({
                        color: `rgba(${fillColor.join(',')})`,
                    }),
                    stroke: new Stroke({
                        color: `rgba(${strokeColor.join(',')})`,
                        width: lineWidth,
                    }),
                }),
            });
        }
        else if (type === 'LineString') {
            return new Style({
                stroke: new Stroke({
                    color: `rgba(${strokeColor.join(',')})`,
                    width: lineWidth,
                }),
            });
        }
        else if (type === 'Polygon') {
            return new Style({
                fill: new Fill({
                    color: `rgba(${fillColor.join(',')})`,
                }),
                stroke: new Stroke({
                    color: `rgba(${strokeColor.join(',')})`,
                    width: lineWidth,
                }),
            });
        }
        else if (type === 'MultiPolygon') {
            return new Style({
                fill: new Fill({
                    color: `rgba(${fillColor.join(',')})`,
                }),
                stroke: new Stroke({
                    color: `rgba(${strokeColor.join(',')})`,
                    width: lineWidth,
                }),
            });
        }
        else {
            return new Style();
        }
    }
    onHover(feature) {
        super.onHover(feature);
        if (this.combinedOptions().autoHighlight) {
            feature.setStyle(this.getStyleForFeature(feature, true));
        }
    }
    onUnHover(feature) {
        super.onUnHover(feature);
        if (this.combinedOptions().autoHighlight) {
            feature.setStyle(this.getStyleForFeature(feature));
        }
    }
    updateLayer() {
        const dataWithLayer = {
            ...this.combinedOptions().data,
            features: this.combinedOptions().data.features.map((feature) => {
                return {
                    ...feature,
                    properties: {
                        ...feature.properties,
                        layer: this,
                    },
                };
            }),
        };
        this.layer().setZIndex(this.combinedOptions().order ?? 0);
        this.source().clear(true);
        this.source().addFeatures(new GeoJSON().readFeatures(dataWithLayer, {
            featureProjection: 'EPSG:3857', // Ensure the projection matches your map's projection
        }));
    }
    onAdd(map) {
        const actualMap = map.state.map();
        if (!actualMap) {
            this.map()
                .onLoad$.pipe(take(1))
                .subscribe(map => {
                const actualMap = map.state.map();
                if (actualMap) {
                    this.addInteractions(actualMap);
                }
            });
            return;
        }
        else {
            this.addInteractions(actualMap);
        }
    }
    onRemove(map) {
        const actualMap = map.state.map();
        if (!actualMap) {
            return;
        }
        else {
            this.removeInteractions(actualMap);
        }
    }
    addInteractions(map) {
        // MODIFY + DRAW
        map.addInteraction(this.modifyInteraction());
        map.addInteraction(this.drawInteraction());
        // SNAPPING TO FEATURES
        map.addInteraction(this.snapInteraction());
        // SELECTING FEATURES
        map.addInteraction(this.selectInteraction());
    }
    removeInteractions(map) {
        map.removeInteraction(this.drawInteraction());
        map.removeInteraction(this.modifyInteraction());
        map.removeInteraction(this.snapInteraction());
        map.removeInteraction(this.selectInteraction());
    }
    onDrawStart(data) {
        const map = this.map().state.map();
        if (map) {
            map.removeInteraction(this.selectInteraction());
        }
    }
    onDrawEnd(data) {
        const map = this.map().state.map();
        this.selectInteraction().setActive(true);
        if (map) {
            map.addInteraction(this.selectInteraction());
        }
        this.drawInteraction().setActive(false);
        const onCreate = this.combinedOptions().onCreate;
        if (onCreate) {
            onCreate(data);
        }
    }
    onModifyEnd(data) {
        const onEdit = this.combinedOptions().onEdit;
        if (onEdit) {
            onEdit(data);
        }
    }
    toggleDrawing(isEnabled) {
        const drawInteraction = this.drawInteraction();
        if (drawInteraction) {
            drawInteraction.setActive(isEnabled);
        }
    }
    refreshDrawInteraction() {
        const drawMode = this.combinedOptions().mode;
        const map = this.map().state.map();
        this.removeDrawEventListeners();
        if (map) {
            map.removeInteraction(this.drawInteraction());
            this.drawInteraction.set(new Draw({
                source: this.source(),
                type: drawMode,
            }));
            map.addInteraction(this.drawInteraction());
        }
        this.addDrawEventListeners();
    }
    addDrawEventListeners() {
        this.drawInteraction().setActive(this.isDrawingEnabled());
        for (let event in this.drawEventListeners) {
            this.drawInteraction().on(event, this.drawEventListeners[event]);
        }
    }
    removeDrawEventListeners() {
        const drawInteraction = this.drawInteraction();
        if (drawInteraction) {
            for (let event in this.drawEventListeners) {
                drawInteraction.un(event, this.drawEventListeners[event]);
            }
        }
    }
    addModifyEventListeners() {
        for (let event in this.modifyEventListeners) {
            this.modifyInteraction().on(event, this.modifyEventListeners[event]);
        }
    }
    removeModifyEventListeners() {
        const modifyInteraction = this.modifyInteraction();
        if (modifyInteraction) {
            for (let event in this.modifyEventListeners) {
                modifyInteraction.un(event, this.modifyEventListeners[event]);
            }
        }
    }
    onDestroy() {
        this.removeDrawEventListeners();
        this.removeModifyEventListeners();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersEditableGeojsonLayerComponent, deps: [{ token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "17.3.1", type: OpenlayersEditableGeojsonLayerComponent, isStandalone: true, selector: "oui-openlayers-editable-geojson-layer", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, isDrawingEnabled: { classPropertyName: "isDrawingEnabled", publicName: "isDrawingEnabled", isSignal: true, isRequired: true, transformFunction: null } }, providers: [
            {
                provide: OpenlayersBaseLayerComponent,
                useExisting: OpenlayersEditableGeojsonLayerComponent,
            },
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersEditableGeojsonLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-openlayers-editable-geojson-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [
                        {
                            provide: OpenlayersBaseLayerComponent,
                            useExisting: OpenlayersEditableGeojsonLayerComponent,
                        },
                    ],
                }]
        }], ctorParameters: () => [{ type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BlbmxheWVycy1lZGl0YWJsZS1nZW9qc29uLWxheWVyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvb3BlbmxheWVycy9sYXllcnMvb3BlbmxheWVycy1lZGl0YWJsZS1nZW9qc29uLWxheWVyLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBRUwsdUJBQXVCLEVBQ3ZCLFNBQVMsRUFDVCxRQUFRLEVBQ1IsTUFBTSxFQUNOLE1BQU0sRUFDTixLQUFLLEVBQ0wsTUFBTSxHQUNQLE1BQU0sZUFBZSxDQUFDO0FBR3ZCLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFDdkMsT0FBTyxFQUFFLDRCQUE0QixFQUFFLE1BQU0sbUNBQW1DLENBQUM7QUFDakYsT0FBTyxXQUFXLE1BQU0saUJBQWlCLENBQUM7QUFDMUMsT0FBTyxZQUFZLE1BQU0sa0JBQWtCLENBQUM7QUFDNUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLFVBQVUsQ0FBQztBQUl2RCxPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDNUQsT0FBTyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFFdkMsT0FBTyxFQUFFLE9BQU8sRUFBRSxNQUFNLFdBQVcsQ0FBQztBQUNwQyxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSxjQUFjLENBQUM7QUFJdEQsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzNDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxZQUFZLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQzs7QUFlOUUsTUFBTSxPQUFPLHVDQUNYLFNBQVEsNEJBQXNFO0lBa0V4QztJQS9EdEIsT0FBTyxHQUNyQixLQUFLLENBQUMsUUFBUSxFQUE0QyxDQUFDO0lBRXRELGdCQUFnQixHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQVcsQ0FBQztJQUU3QyxNQUFNLEdBQUcsTUFBTSxDQUFlLElBQUksWUFBWSxFQUFFLENBQUMsQ0FBQztJQUNsRCxLQUFLLEdBQUcsTUFBTSxDQUNuQixJQUFJLFdBQVcsQ0FBQztRQUNkLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQ3JCLEtBQUssRUFBRSxPQUFPLENBQUMsRUFBRTtZQUNmLE9BQU8sSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzFDLENBQUM7S0FDRixDQUFDLENBQ0gsQ0FBQztJQUVNLGlCQUFpQixHQUFHLE1BQU0sQ0FDaEMsSUFBSSxNQUFNLENBQUM7UUFDVCxNQUFNLEVBQUUsQ0FBQyxPQUFrQixFQUFFLEVBQUU7WUFDN0IsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLGlCQUFpQixDQUFDO1lBQzVELE9BQU8sVUFBVSxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUNqRCxDQUFDO0tBQ0YsQ0FBQyxDQUNILENBQUM7SUFDTSxlQUFlLEdBQUcsTUFBTSxDQUM5QixJQUFJLElBQUksQ0FBQztRQUNQLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQ3JCLElBQUksRUFBRSxTQUFTO0tBQ2hCLENBQUMsQ0FDSCxDQUFDO0lBQ00saUJBQWlCLEdBQUcsTUFBTSxDQUNoQyxJQUFJLE1BQU0sQ0FBQztRQUNULE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFO1FBQ3JCLFFBQVEsRUFBRSxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxXQUFXLEVBQUU7S0FDakQsQ0FBQyxDQUNILENBQUM7SUFDTSxlQUFlLEdBQUcsTUFBTSxDQUFPLElBQUksSUFBSSxDQUFDLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUVwRSxrQkFBa0IsR0FFdEI7UUFDRixTQUFTLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQ3RDLE9BQU8sRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7S0FDbkMsQ0FBQztJQUVNLG9CQUFvQixHQUV4QjtRQUNGLFNBQVMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7S0FDdkMsQ0FBQztJQUVLLGVBQWUsR0FBRyxRQUFRLENBQy9CLEdBQUcsRUFBRTtRQUNILE9BQU87WUFDTCxHQUFHLHNCQUFzQjtZQUN6QixHQUFHO2dCQUNELFlBQVksRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQztnQkFDOUIsY0FBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFDO2FBQy9CO1lBQ0QsR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFO1NBQ2xCLENBQUM7SUFDSixDQUFDLENBQ0YsQ0FBQztJQUVGLFlBQXNDLFFBQWtCO1FBQ3RELEtBQUssRUFBRSxDQUFDO1FBRDRCLGFBQVEsR0FBUixRQUFRLENBQVU7UUFHdEQsWUFBWSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUM7YUFDL0IsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzthQUN6QyxTQUFTLENBQUMsVUFBVSxDQUFDLEVBQUU7WUFDdEIsSUFBSSxDQUFDLHNCQUFzQixFQUFFLENBQUM7UUFDaEMsQ0FBQyxDQUFDLENBQUM7UUFFTCxNQUFNLENBQUMsR0FBRyxFQUFFO1lBQ1YsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNuQyxJQUFJLEdBQUcsRUFBRSxDQUFDO2dCQUNSLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztnQkFDOUMsR0FBRyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztZQUM3QyxDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7UUFFSCxNQUFNLENBQUMsR0FBRyxFQUFFO1lBQ1YsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxDQUFDO1FBQzlDLENBQUMsQ0FBQyxDQUFDO1FBRUgsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQzthQUNyQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ3pDLFNBQVMsQ0FBQyxDQUFDLEdBQVEsRUFBRSxFQUFFO1lBQ3RCLElBQUksR0FBRyxDQUFDLEdBQUcsS0FBSyxRQUFRLEVBQUUsQ0FBQztnQkFDekIsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO2dCQUMzQyxJQUFJLFdBQVcsRUFBRSxDQUFDO29CQUNoQixXQUFXLENBQUMsWUFBWSxFQUFFLENBQUM7b0JBQzNCLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDM0MsQ0FBQztZQUNILENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTSxlQUFlO1FBQ3BCLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO1FBQzdCLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFTyxrQkFBa0IsQ0FBQyxPQUFvQixFQUFFLGFBQWEsR0FBRyxLQUFLO1FBQ3BFLE1BQU0saUJBQWlCLEdBQUcsYUFBYTtZQUNyQyxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLGNBQWM7Z0JBQ3JDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxZQUFZO1lBQ3JDLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsWUFBWSxDQUFDO1FBQ3hDLE1BQU0sU0FBUyxHQUNiLGlCQUFpQixZQUFZLFFBQVE7WUFDbkMsQ0FBQyxDQUFFLGlCQUE4QixDQUFDLE9BQU8sQ0FBQztZQUMxQyxDQUFDLENBQUMsQ0FBQyxHQUFHLGlCQUFpQixDQUFDLENBQUM7UUFDN0IsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7UUFFbEMsTUFBTSxtQkFBbUIsR0FBRyxVQUFVLENBQ3BDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxjQUFjLENBQ3RDO1lBQ0MsQ0FBQyxDQUFFLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxjQUEyQjtZQUNyRCxDQUFDLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLGNBQWMsQ0FBQztRQUMxQyxNQUFNLFdBQVcsR0FDZixtQkFBbUIsWUFBWSxRQUFRO1lBQ3JDLENBQUMsQ0FBRSxtQkFBZ0MsQ0FBQyxPQUFPLENBQUM7WUFDNUMsQ0FBQyxDQUFDLENBQUMsR0FBSSxtQkFBNEIsQ0FBQyxDQUFDO1FBRXpDLFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1FBQ3RDLE1BQU0sU0FBUyxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsWUFBWSxDQUFDO1lBQy9ELENBQUMsQ0FBRSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsWUFBeUIsQ0FBQyxPQUFPLENBQUM7WUFDNUQsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxZQUFZLENBQUM7UUFDeEMsTUFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLFdBQVcsRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDO1FBRTlDLElBQUksSUFBSSxLQUFLLE9BQU8sRUFBRSxDQUFDO1lBQ3JCLE9BQU8sSUFBSSxLQUFLLENBQUM7Z0JBQ2YsS0FBSyxFQUFFLElBQUksTUFBTSxDQUFDO29CQUNoQixNQUFNLEVBQUUsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLFdBQVcsSUFBSSxDQUFDO29CQUMvQyxJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUM7d0JBQ2IsS0FBSyxFQUFFLFFBQVEsU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRztxQkFDdEMsQ0FBQztvQkFDRixNQUFNLEVBQUUsSUFBSSxNQUFNLENBQUM7d0JBQ2pCLEtBQUssRUFBRSxRQUFRLFdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUc7d0JBQ3ZDLEtBQUssRUFBRSxTQUFTO3FCQUNqQixDQUFDO2lCQUNILENBQUM7YUFDSCxDQUFDLENBQUM7UUFDTCxDQUFDO2FBQU0sSUFBSSxJQUFJLEtBQUssWUFBWSxFQUFFLENBQUM7WUFDakMsT0FBTyxJQUFJLEtBQUssQ0FBQztnQkFDZixNQUFNLEVBQUUsSUFBSSxNQUFNLENBQUM7b0JBQ2pCLEtBQUssRUFBRSxRQUFRLFdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUc7b0JBQ3ZDLEtBQUssRUFBRSxTQUFTO2lCQUNqQixDQUFDO2FBQ0gsQ0FBQyxDQUFDO1FBQ0wsQ0FBQzthQUFNLElBQUksSUFBSSxLQUFLLFNBQVMsRUFBRSxDQUFDO1lBQzlCLE9BQU8sSUFBSSxLQUFLLENBQUM7Z0JBQ2YsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDO29CQUNiLEtBQUssRUFBRSxRQUFRLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUc7aUJBQ3RDLENBQUM7Z0JBQ0YsTUFBTSxFQUFFLElBQUksTUFBTSxDQUFDO29CQUNqQixLQUFLLEVBQUUsUUFBUSxXQUFXLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHO29CQUN2QyxLQUFLLEVBQUUsU0FBUztpQkFDakIsQ0FBQzthQUNILENBQUMsQ0FBQztRQUNMLENBQUM7YUFBTSxJQUFJLElBQUksS0FBSyxjQUFjLEVBQUUsQ0FBQztZQUNuQyxPQUFPLElBQUksS0FBSyxDQUFDO2dCQUNmLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQztvQkFDYixLQUFLLEVBQUUsUUFBUSxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHO2lCQUN0QyxDQUFDO2dCQUNGLE1BQU0sRUFBRSxJQUFJLE1BQU0sQ0FBQztvQkFDakIsS0FBSyxFQUFFLFFBQVEsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRztvQkFDdkMsS0FBSyxFQUFFLFNBQVM7aUJBQ2pCLENBQUM7YUFDSCxDQUFDLENBQUM7UUFDTCxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sSUFBSSxLQUFLLEVBQUUsQ0FBQztRQUNyQixDQUFDO0lBQ0gsQ0FBQztJQUVlLE9BQU8sQ0FBQyxPQUFrQjtRQUN4QyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3ZCLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3pDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzNELENBQUM7SUFDSCxDQUFDO0lBRWUsU0FBUyxDQUFDLE9BQWtCO1FBQzFDLEtBQUssQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDekIsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDekMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztRQUNyRCxDQUFDO0lBQ0gsQ0FBQztJQUVNLFdBQVc7UUFDaEIsTUFBTSxhQUFhLEdBQUc7WUFDcEIsR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsSUFBSTtZQUM5QixRQUFRLEVBQUUsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBZ0IsRUFBRSxFQUFFO2dCQUN0RSxPQUFPO29CQUNMLEdBQUcsT0FBTztvQkFDVixVQUFVLEVBQUU7d0JBQ1YsR0FBRyxPQUFPLENBQUMsVUFBVTt3QkFDckIsS0FBSyxFQUFFLElBQUk7cUJBQ1o7aUJBQ0YsQ0FBQztZQUNKLENBQUMsQ0FBQztTQUNILENBQUM7UUFFRixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDMUQsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMxQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsV0FBVyxDQUN2QixJQUFJLE9BQU8sRUFBRSxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUU7WUFDeEMsaUJBQWlCLEVBQUUsV0FBVyxFQUFFLHNEQUFzRDtTQUN2RixDQUFRLENBQ1YsQ0FBQztJQUNKLENBQUM7SUFFZSxLQUFLLENBQUMsR0FBd0I7UUFDNUMsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNsQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDZixJQUFJLENBQUMsR0FBRyxFQUFFO2lCQUNQLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNyQixTQUFTLENBQUMsR0FBRyxDQUFDLEVBQUU7Z0JBQ2YsTUFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDbEMsSUFBSSxTQUFTLEVBQUUsQ0FBQztvQkFDZCxJQUFJLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUNsQyxDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7WUFDTCxPQUFPO1FBQ1QsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2xDLENBQUM7SUFDSCxDQUFDO0lBRWUsUUFBUSxDQUFDLEdBQXdCO1FBQy9DLE1BQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDbEMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ2YsT0FBTztRQUNULENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3JDLENBQUM7SUFDSCxDQUFDO0lBRU8sZUFBZSxDQUFDLEdBQVE7UUFDOUIsZ0JBQWdCO1FBRWhCLEdBQUcsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQztRQUM3QyxHQUFHLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO1FBRTNDLHVCQUF1QjtRQUN2QixHQUFHLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO1FBRTNDLHFCQUFxQjtRQUNyQixHQUFHLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVPLGtCQUFrQixDQUFDLEdBQVE7UUFDakMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO1FBQzlDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxDQUFDO1FBQ2hELEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztRQUM5QyxHQUFHLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBRU8sV0FBVyxDQUFDLElBQWU7UUFDakMsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNuQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1lBQ1IsR0FBRyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLENBQUM7UUFDbEQsQ0FBQztJQUNILENBQUM7SUFDTyxTQUFTLENBQUMsSUFBZTtRQUMvQixNQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ25DLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN6QyxJQUFJLEdBQUcsRUFBRSxDQUFDO1lBQ1IsR0FBRyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxDQUFDO1FBQy9DLENBQUM7UUFDRCxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3hDLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxRQUFRLENBQUM7UUFDakQsSUFBSSxRQUFRLEVBQUUsQ0FBQztZQUNiLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNqQixDQUFDO0lBQ0gsQ0FBQztJQUVPLFdBQVcsQ0FBQyxJQUFpQjtRQUNuQyxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsTUFBTSxDQUFDO1FBQzdDLElBQUksTUFBTSxFQUFFLENBQUM7WUFDWCxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDZixDQUFDO0lBQ0gsQ0FBQztJQUVPLGFBQWEsQ0FBQyxTQUFrQjtRQUN0QyxNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDL0MsSUFBSSxlQUFlLEVBQUUsQ0FBQztZQUNwQixlQUFlLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3ZDLENBQUM7SUFDSCxDQUFDO0lBRU8sc0JBQXNCO1FBQzVCLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxJQUFJLENBQUM7UUFDN0MsTUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNuQyxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztRQUNoQyxJQUFJLEdBQUcsRUFBRSxDQUFDO1lBQ1IsR0FBRyxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO1lBQzlDLElBQUksQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUN0QixJQUFJLElBQUksQ0FBQztnQkFDUCxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRTtnQkFDckIsSUFBSSxFQUFFLFFBQVE7YUFDZixDQUFDLENBQ0gsQ0FBQztZQUNGLEdBQUcsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7UUFDN0MsQ0FBQztRQUNELElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO0lBQy9CLENBQUM7SUFFTyxxQkFBcUI7UUFDM0IsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxDQUFDO1FBQzFELEtBQUssSUFBSSxLQUFLLElBQUksSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7WUFDMUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxLQUFZLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7UUFDMUUsQ0FBQztJQUNILENBQUM7SUFFTyx3QkFBd0I7UUFDOUIsTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQy9DLElBQUksZUFBZSxFQUFFLENBQUM7WUFDcEIsS0FBSyxJQUFJLEtBQUssSUFBSSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztnQkFDMUMsZUFBZSxDQUFDLEVBQUUsQ0FBQyxLQUFZLEVBQUUsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFDbkUsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRU8sdUJBQXVCO1FBQzdCLEtBQUssSUFBSSxLQUFLLElBQUksSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7WUFDNUMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUMsRUFBRSxDQUN6QixLQUFZLEVBQ1osSUFBSSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxDQUNqQyxDQUFDO1FBQ0osQ0FBQztJQUNILENBQUM7SUFFTywwQkFBMEI7UUFDaEMsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUNuRCxJQUFJLGlCQUFpQixFQUFFLENBQUM7WUFDdEIsS0FBSyxJQUFJLEtBQUssSUFBSSxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztnQkFDNUMsaUJBQWlCLENBQUMsRUFBRSxDQUFDLEtBQVksRUFBRSxJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUN2RSxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFZSxTQUFTO1FBQ3ZCLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxDQUFDO1FBQ2hDLElBQUksQ0FBQywwQkFBMEIsRUFBRSxDQUFDO0lBQ3BDLENBQUM7dUdBNVZVLHVDQUF1QyxrQkFtRTlCLFFBQVE7MkZBbkVqQix1Q0FBdUMscVhBUHZDO1lBQ1Q7Z0JBQ0UsT0FBTyxFQUFFLDRCQUE0QjtnQkFDckMsV0FBVyxFQUFFLHVDQUF1QzthQUNyRDtTQUNGLGlEQVRTLEVBQUU7OzJGQVdELHVDQUF1QztrQkFibkQsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsdUNBQXVDO29CQUNqRCxRQUFRLEVBQUUsRUFBRTtvQkFDWixVQUFVLEVBQUUsSUFBSTtvQkFDaEIsT0FBTyxFQUFFLEVBQUU7b0JBQ1gsZUFBZSxFQUFFLHVCQUF1QixDQUFDLE1BQU07b0JBQy9DLFNBQVMsRUFBRTt3QkFDVDs0QkFDRSxPQUFPLEVBQUUsNEJBQTRCOzRCQUNyQyxXQUFXLHlDQUF5Qzt5QkFDckQ7cUJBQ0Y7aUJBQ0Y7OzBCQW9FYyxNQUFNOzJCQUFDLFFBQVEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcbiAgQ29tcG9uZW50LFxuICBjb21wdXRlZCxcbiAgZWZmZWN0LFxuICBJbmplY3QsXG4gIGlucHV0LFxuICBzaWduYWwsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRmVhdHVyZSBhcyBPbEZlYXR1cmUgfSBmcm9tICdvbCc7XG5pbXBvcnQgeyBSR0JBIH0gZnJvbSAnb3JiaXRhbC11aS9jb3JlJztcbmltcG9ydCB7IGlzRnVuY3Rpb24gfSBmcm9tICdsb2Rhc2gtZXMnO1xuaW1wb3J0IHsgT3BlbmxheWVyc0Jhc2VMYXllckNvbXBvbmVudCB9IGZyb20gJy4vb3BlbmxheWVycy1iYXNlLWxheWVyLmNvbXBvbmVudCc7XG5pbXBvcnQgVmVjdG9yTGF5ZXIgZnJvbSAnb2wvbGF5ZXIvVmVjdG9yJztcbmltcG9ydCBWZWN0b3JTb3VyY2UgZnJvbSAnb2wvc291cmNlL1ZlY3Rvcic7XG5pbXBvcnQgeyBDaXJjbGUsIEZpbGwsIFN0cm9rZSwgU3R5bGUgfSBmcm9tICdvbC9zdHlsZSc7XG5pbXBvcnQgeyBGZWF0dXJlTGlrZSB9IGZyb20gJ29sL0ZlYXR1cmUnO1xuaW1wb3J0IHsgT3VpT3BlbkxheWVyc0VkaXRhYmxlR2VvSnNvbkxheWVyT3B0aW9ucyB9IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IE9wZW5sYXllcnNDb21wb25lbnQgfSBmcm9tICcuLi9vcGVubGF5ZXJzLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBEcmF3LCBNb2RpZnksIFNlbGVjdCwgU25hcCB9IGZyb20gJ29sL2ludGVyYWN0aW9uJztcbmltcG9ydCB7IGZyb21FdmVudCwgdGFrZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgRmVhdHVyZSB9IGZyb20gJ0B0dXJmL2hlbHBlcnMnO1xuaW1wb3J0IHsgR2VvSlNPTiB9IGZyb20gJ29sL2Zvcm1hdCc7XG5pbXBvcnQgeyBERUZBVUxUX0NPTU1PTl9PUFRJT05TIH0gZnJvbSAnLi4vY29uc3RhbnRzJztcbmltcG9ydCB7IE1hcCB9IGZyb20gJ29sJztcbmltcG9ydCB7IERyYXdFdmVudCB9IGZyb20gJ29sL2ludGVyYWN0aW9uL0RyYXcnO1xuaW1wb3J0IHsgTW9kaWZ5RXZlbnQgfSBmcm9tICdvbC9pbnRlcmFjdGlvbi9Nb2RpZnknO1xuaW1wb3J0IHsgRE9DVU1FTlQgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgdGFrZVVudGlsRGVzdHJveWVkLCB0b09ic2VydmFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlL3J4anMtaW50ZXJvcCc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1vcGVubGF5ZXJzLWVkaXRhYmxlLWdlb2pzb24tbGF5ZXInLFxuICB0ZW1wbGF0ZTogJycsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtdLFxuICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcbiAgcHJvdmlkZXJzOiBbXG4gICAge1xuICAgICAgcHJvdmlkZTogT3BlbmxheWVyc0Jhc2VMYXllckNvbXBvbmVudCxcbiAgICAgIHVzZUV4aXN0aW5nOiBPcGVubGF5ZXJzRWRpdGFibGVHZW9qc29uTGF5ZXJDb21wb25lbnQsXG4gICAgfSxcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgT3BlbmxheWVyc0VkaXRhYmxlR2VvanNvbkxheWVyQ29tcG9uZW50XG4gIGV4dGVuZHMgT3BlbmxheWVyc0Jhc2VMYXllckNvbXBvbmVudDxPdWlPcGVuTGF5ZXJzRWRpdGFibGVHZW9Kc29uTGF5ZXJPcHRpb25zPlxuICBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXRcbntcbiAgcHVibGljIG92ZXJyaWRlIG9wdGlvbnMgPVxuICAgIGlucHV0LnJlcXVpcmVkPE91aU9wZW5MYXllcnNFZGl0YWJsZUdlb0pzb25MYXllck9wdGlvbnM+KCk7XG5cbiAgcHVibGljIGlzRHJhd2luZ0VuYWJsZWQgPSBpbnB1dC5yZXF1aXJlZDxib29sZWFuPigpO1xuXG4gIHB1YmxpYyBzb3VyY2UgPSBzaWduYWw8VmVjdG9yU291cmNlPihuZXcgVmVjdG9yU291cmNlKCkpO1xuICBwdWJsaWMgbGF5ZXIgPSBzaWduYWw8VmVjdG9yTGF5ZXI8VmVjdG9yU291cmNlPj4oXG4gICAgbmV3IFZlY3RvckxheWVyKHtcbiAgICAgIHNvdXJjZTogdGhpcy5zb3VyY2UoKSxcbiAgICAgIHN0eWxlOiBmZWF0dXJlID0+IHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0U3R5bGVGb3JGZWF0dXJlKGZlYXR1cmUpO1xuICAgICAgfSxcbiAgICB9KVxuICApO1xuXG4gIHByaXZhdGUgc2VsZWN0SW50ZXJhY3Rpb24gPSBzaWduYWw8U2VsZWN0PihcbiAgICBuZXcgU2VsZWN0KHtcbiAgICAgIGZpbHRlcjogKGZlYXR1cmU6IE9sRmVhdHVyZSkgPT4ge1xuICAgICAgICBjb25zdCBpc0VkaXRhYmxlID0gdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5pc0ZlYXR1cmVFZGl0YWJsZTtcbiAgICAgICAgcmV0dXJuIGlzRWRpdGFibGUgPyBpc0VkaXRhYmxlKGZlYXR1cmUpIDogdHJ1ZTtcbiAgICAgIH0sXG4gICAgfSlcbiAgKTtcbiAgcHJpdmF0ZSBkcmF3SW50ZXJhY3Rpb24gPSBzaWduYWw8RHJhdz4oXG4gICAgbmV3IERyYXcoe1xuICAgICAgc291cmNlOiB0aGlzLnNvdXJjZSgpLFxuICAgICAgdHlwZTogJ1BvbHlnb24nLFxuICAgIH0pXG4gICk7XG4gIHByaXZhdGUgbW9kaWZ5SW50ZXJhY3Rpb24gPSBzaWduYWw8TW9kaWZ5PihcbiAgICBuZXcgTW9kaWZ5KHtcbiAgICAgIHNvdXJjZTogdGhpcy5zb3VyY2UoKSxcbiAgICAgIGZlYXR1cmVzOiB0aGlzLnNlbGVjdEludGVyYWN0aW9uKCkuZ2V0RmVhdHVyZXMoKSxcbiAgICB9KVxuICApO1xuICBwcml2YXRlIHNuYXBJbnRlcmFjdGlvbiA9IHNpZ25hbDxTbmFwPihuZXcgU25hcCh7IHNvdXJjZTogdGhpcy5zb3VyY2UoKSB9KSk7XG5cbiAgcHJpdmF0ZSBkcmF3RXZlbnRMaXN0ZW5lcnM6IHtcbiAgICBbeDogc3RyaW5nXTogKGRhdGE6IGFueSkgPT4gdm9pZDtcbiAgfSA9IHtcbiAgICBkcmF3c3RhcnQ6IHRoaXMub25EcmF3U3RhcnQuYmluZCh0aGlzKSxcbiAgICBkcmF3ZW5kOiB0aGlzLm9uRHJhd0VuZC5iaW5kKHRoaXMpLFxuICB9O1xuXG4gIHByaXZhdGUgbW9kaWZ5RXZlbnRMaXN0ZW5lcnM6IHtcbiAgICBbeDogc3RyaW5nXTogKGRhdGE6IGFueSkgPT4gdm9pZDtcbiAgfSA9IHtcbiAgICBtb2RpZnllbmQ6IHRoaXMub25Nb2RpZnlFbmQuYmluZCh0aGlzKSxcbiAgfTtcblxuICBwdWJsaWMgY29tYmluZWRPcHRpb25zID0gY29tcHV0ZWQ8T3VpT3BlbkxheWVyc0VkaXRhYmxlR2VvSnNvbkxheWVyT3B0aW9ucz4oXG4gICAgKCkgPT4ge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uREVGQVVMVF9DT01NT05fT1BUSU9OUyxcbiAgICAgICAgLi4ue1xuICAgICAgICAgIGdldEZpbGxDb2xvcjogWzI1NSwgMCwgMCwgMjU1XSxcbiAgICAgICAgICBnZXRTdHJva2VDb2xvcjogWzAsIDAsIDAsIDI1NV0sXG4gICAgICAgIH0sXG4gICAgICAgIC4uLnRoaXMub3B0aW9ucygpLFxuICAgICAgfTtcbiAgICB9XG4gICk7XG5cbiAgY29uc3RydWN0b3IoQEluamVjdChET0NVTUVOVCkgcHJpdmF0ZSBkb2N1bWVudDogRG9jdW1lbnQpIHtcbiAgICBzdXBlcigpO1xuXG4gICAgdG9PYnNlcnZhYmxlKHRoaXMuY29tYmluZWRPcHRpb25zKVxuICAgICAgLnBpcGUodGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZikpXG4gICAgICAuc3Vic2NyaWJlKG5ld09wdGlvbnMgPT4ge1xuICAgICAgICB0aGlzLnJlZnJlc2hEcmF3SW50ZXJhY3Rpb24oKTtcbiAgICAgIH0pO1xuXG4gICAgZWZmZWN0KCgpID0+IHtcbiAgICAgIGNvbnN0IG1hcCA9IHRoaXMubWFwKCkuc3RhdGUubWFwKCk7XG4gICAgICBpZiAobWFwKSB7XG4gICAgICAgIG1hcC5yZW1vdmVJbnRlcmFjdGlvbih0aGlzLmRyYXdJbnRlcmFjdGlvbigpKTtcbiAgICAgICAgbWFwLmFkZEludGVyYWN0aW9uKHRoaXMuZHJhd0ludGVyYWN0aW9uKCkpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgZWZmZWN0KCgpID0+IHtcbiAgICAgIHRoaXMudG9nZ2xlRHJhd2luZyh0aGlzLmlzRHJhd2luZ0VuYWJsZWQoKSk7XG4gICAgfSk7XG5cbiAgICBmcm9tRXZlbnQodGhpcy5kb2N1bWVudC5ib2R5LCAna2V5ZG93bicpXG4gICAgICAucGlwZSh0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSlcbiAgICAgIC5zdWJzY3JpYmUoKGV2dDogYW55KSA9PiB7XG4gICAgICAgIGlmIChldnQua2V5ID09PSAnRXNjYXBlJykge1xuICAgICAgICAgIGNvbnN0IGludGVyYWN0aW9uID0gdGhpcy5kcmF3SW50ZXJhY3Rpb24oKTtcbiAgICAgICAgICBpZiAoaW50ZXJhY3Rpb24pIHtcbiAgICAgICAgICAgIGludGVyYWN0aW9uLmFib3J0RHJhd2luZygpO1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RJbnRlcmFjdGlvbigpLnNldEFjdGl2ZSh0cnVlKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICB9XG5cbiAgcHVibGljIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICB0aGlzLmFkZERyYXdFdmVudExpc3RlbmVycygpO1xuICAgIHRoaXMuYWRkTW9kaWZ5RXZlbnRMaXN0ZW5lcnMoKTtcbiAgfVxuXG4gIHByaXZhdGUgZ2V0U3R5bGVGb3JGZWF0dXJlKGZlYXR1cmU6IEZlYXR1cmVMaWtlLCBpc0hpZ2hsaWdodGVkID0gZmFsc2UpIHtcbiAgICBjb25zdCBmaWxsQ29sb3JBY2Nlc3NvciA9IGlzSGlnaGxpZ2h0ZWRcbiAgICAgID8gdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5oaWdobGlnaHRDb2xvciA/P1xuICAgICAgICB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmdldEZpbGxDb2xvclxuICAgICAgOiB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmdldEZpbGxDb2xvcjtcbiAgICBjb25zdCBmaWxsQ29sb3IgPVxuICAgICAgZmlsbENvbG9yQWNjZXNzb3IgaW5zdGFuY2VvZiBGdW5jdGlvblxuICAgICAgICA/IChmaWxsQ29sb3JBY2Nlc3NvciBhcyBGdW5jdGlvbikoZmVhdHVyZSlcbiAgICAgICAgOiBbLi4uZmlsbENvbG9yQWNjZXNzb3JdO1xuICAgIGZpbGxDb2xvclszXSA9IGZpbGxDb2xvclszXSAvIDI1NTtcblxuICAgIGNvbnN0IHN0cm9rZUNvbG9yQWNjZXNzb3IgPSBpc0Z1bmN0aW9uKFxuICAgICAgdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5nZXRTdHJva2VDb2xvclxuICAgIClcbiAgICAgID8gKHRoaXMuY29tYmluZWRPcHRpb25zKCkuZ2V0U3Ryb2tlQ29sb3IgYXMgRnVuY3Rpb24pXG4gICAgICA6IHRoaXMuY29tYmluZWRPcHRpb25zKCkuZ2V0U3Ryb2tlQ29sb3I7XG4gICAgY29uc3Qgc3Ryb2tlQ29sb3IgPVxuICAgICAgc3Ryb2tlQ29sb3JBY2Nlc3NvciBpbnN0YW5jZW9mIEZ1bmN0aW9uXG4gICAgICAgID8gKHN0cm9rZUNvbG9yQWNjZXNzb3IgYXMgRnVuY3Rpb24pKGZlYXR1cmUpXG4gICAgICAgIDogWy4uLihzdHJva2VDb2xvckFjY2Vzc29yIGFzIFJHQkEpXTtcblxuICAgIHN0cm9rZUNvbG9yWzNdID0gc3Ryb2tlQ29sb3JbM10gLyAyNTU7XG4gICAgY29uc3QgbGluZVdpZHRoID0gaXNGdW5jdGlvbih0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmdldExpbmVXaWR0aClcbiAgICAgID8gKHRoaXMuY29tYmluZWRPcHRpb25zKCkuZ2V0TGluZVdpZHRoIGFzIEZ1bmN0aW9uKShmZWF0dXJlKVxuICAgICAgOiB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmdldExpbmVXaWR0aDtcbiAgICBjb25zdCB0eXBlID0gZmVhdHVyZS5nZXRHZW9tZXRyeSgpPy5nZXRUeXBlKCk7XG5cbiAgICBpZiAodHlwZSA9PT0gJ1BvaW50Jykge1xuICAgICAgcmV0dXJuIG5ldyBTdHlsZSh7XG4gICAgICAgIGltYWdlOiBuZXcgQ2lyY2xlKHtcbiAgICAgICAgICByYWRpdXM6IHRoaXMuY29tYmluZWRPcHRpb25zKCkucG9pbnRSYWRpdXMgPz8gNSxcbiAgICAgICAgICBmaWxsOiBuZXcgRmlsbCh7XG4gICAgICAgICAgICBjb2xvcjogYHJnYmEoJHtmaWxsQ29sb3Iuam9pbignLCcpfSlgLFxuICAgICAgICAgIH0pLFxuICAgICAgICAgIHN0cm9rZTogbmV3IFN0cm9rZSh7XG4gICAgICAgICAgICBjb2xvcjogYHJnYmEoJHtzdHJva2VDb2xvci5qb2luKCcsJyl9KWAsXG4gICAgICAgICAgICB3aWR0aDogbGluZVdpZHRoLFxuICAgICAgICAgIH0pLFxuICAgICAgICB9KSxcbiAgICAgIH0pO1xuICAgIH0gZWxzZSBpZiAodHlwZSA9PT0gJ0xpbmVTdHJpbmcnKSB7XG4gICAgICByZXR1cm4gbmV3IFN0eWxlKHtcbiAgICAgICAgc3Ryb2tlOiBuZXcgU3Ryb2tlKHtcbiAgICAgICAgICBjb2xvcjogYHJnYmEoJHtzdHJva2VDb2xvci5qb2luKCcsJyl9KWAsXG4gICAgICAgICAgd2lkdGg6IGxpbmVXaWR0aCxcbiAgICAgICAgfSksXG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKHR5cGUgPT09ICdQb2x5Z29uJykge1xuICAgICAgcmV0dXJuIG5ldyBTdHlsZSh7XG4gICAgICAgIGZpbGw6IG5ldyBGaWxsKHtcbiAgICAgICAgICBjb2xvcjogYHJnYmEoJHtmaWxsQ29sb3Iuam9pbignLCcpfSlgLFxuICAgICAgICB9KSxcbiAgICAgICAgc3Ryb2tlOiBuZXcgU3Ryb2tlKHtcbiAgICAgICAgICBjb2xvcjogYHJnYmEoJHtzdHJva2VDb2xvci5qb2luKCcsJyl9KWAsXG4gICAgICAgICAgd2lkdGg6IGxpbmVXaWR0aCxcbiAgICAgICAgfSksXG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKHR5cGUgPT09ICdNdWx0aVBvbHlnb24nKSB7XG4gICAgICByZXR1cm4gbmV3IFN0eWxlKHtcbiAgICAgICAgZmlsbDogbmV3IEZpbGwoe1xuICAgICAgICAgIGNvbG9yOiBgcmdiYSgke2ZpbGxDb2xvci5qb2luKCcsJyl9KWAsXG4gICAgICAgIH0pLFxuICAgICAgICBzdHJva2U6IG5ldyBTdHJva2Uoe1xuICAgICAgICAgIGNvbG9yOiBgcmdiYSgke3N0cm9rZUNvbG9yLmpvaW4oJywnKX0pYCxcbiAgICAgICAgICB3aWR0aDogbGluZVdpZHRoLFxuICAgICAgICB9KSxcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gbmV3IFN0eWxlKCk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG92ZXJyaWRlIG9uSG92ZXIoZmVhdHVyZTogT2xGZWF0dXJlKSB7XG4gICAgc3VwZXIub25Ib3ZlcihmZWF0dXJlKTtcbiAgICBpZiAodGhpcy5jb21iaW5lZE9wdGlvbnMoKS5hdXRvSGlnaGxpZ2h0KSB7XG4gICAgICBmZWF0dXJlLnNldFN0eWxlKHRoaXMuZ2V0U3R5bGVGb3JGZWF0dXJlKGZlYXR1cmUsIHRydWUpKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgb3ZlcnJpZGUgb25VbkhvdmVyKGZlYXR1cmU6IE9sRmVhdHVyZSkge1xuICAgIHN1cGVyLm9uVW5Ib3ZlcihmZWF0dXJlKTtcbiAgICBpZiAodGhpcy5jb21iaW5lZE9wdGlvbnMoKS5hdXRvSGlnaGxpZ2h0KSB7XG4gICAgICBmZWF0dXJlLnNldFN0eWxlKHRoaXMuZ2V0U3R5bGVGb3JGZWF0dXJlKGZlYXR1cmUpKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgdXBkYXRlTGF5ZXIoKSB7XG4gICAgY29uc3QgZGF0YVdpdGhMYXllciA9IHtcbiAgICAgIC4uLnRoaXMuY29tYmluZWRPcHRpb25zKCkuZGF0YSxcbiAgICAgIGZlYXR1cmVzOiB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmRhdGEuZmVhdHVyZXMubWFwKChmZWF0dXJlOiBGZWF0dXJlKSA9PiB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgLi4uZmVhdHVyZSxcbiAgICAgICAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgICAgICAuLi5mZWF0dXJlLnByb3BlcnRpZXMsXG4gICAgICAgICAgICBsYXllcjogdGhpcyxcbiAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgICAgfSksXG4gICAgfTtcblxuICAgIHRoaXMubGF5ZXIoKS5zZXRaSW5kZXgodGhpcy5jb21iaW5lZE9wdGlvbnMoKS5vcmRlciA/PyAwKTtcbiAgICB0aGlzLnNvdXJjZSgpLmNsZWFyKHRydWUpO1xuICAgIHRoaXMuc291cmNlKCkuYWRkRmVhdHVyZXMoXG4gICAgICBuZXcgR2VvSlNPTigpLnJlYWRGZWF0dXJlcyhkYXRhV2l0aExheWVyLCB7XG4gICAgICAgIGZlYXR1cmVQcm9qZWN0aW9uOiAnRVBTRzozODU3JywgLy8gRW5zdXJlIHRoZSBwcm9qZWN0aW9uIG1hdGNoZXMgeW91ciBtYXAncyBwcm9qZWN0aW9uXG4gICAgICB9KSBhcyBhbnlcbiAgICApO1xuICB9XG5cbiAgcHVibGljIG92ZXJyaWRlIG9uQWRkKG1hcDogT3BlbmxheWVyc0NvbXBvbmVudCkge1xuICAgIGNvbnN0IGFjdHVhbE1hcCA9IG1hcC5zdGF0ZS5tYXAoKTtcbiAgICBpZiAoIWFjdHVhbE1hcCkge1xuICAgICAgdGhpcy5tYXAoKVxuICAgICAgICAub25Mb2FkJC5waXBlKHRha2UoMSkpXG4gICAgICAgIC5zdWJzY3JpYmUobWFwID0+IHtcbiAgICAgICAgICBjb25zdCBhY3R1YWxNYXAgPSBtYXAuc3RhdGUubWFwKCk7XG4gICAgICAgICAgaWYgKGFjdHVhbE1hcCkge1xuICAgICAgICAgICAgdGhpcy5hZGRJbnRlcmFjdGlvbnMoYWN0dWFsTWFwKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLmFkZEludGVyYWN0aW9ucyhhY3R1YWxNYXApO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBvdmVycmlkZSBvblJlbW92ZShtYXA6IE9wZW5sYXllcnNDb21wb25lbnQpIHtcbiAgICBjb25zdCBhY3R1YWxNYXAgPSBtYXAuc3RhdGUubWFwKCk7XG4gICAgaWYgKCFhY3R1YWxNYXApIHtcbiAgICAgIHJldHVybjtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5yZW1vdmVJbnRlcmFjdGlvbnMoYWN0dWFsTWFwKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFkZEludGVyYWN0aW9ucyhtYXA6IE1hcCkge1xuICAgIC8vIE1PRElGWSArIERSQVdcblxuICAgIG1hcC5hZGRJbnRlcmFjdGlvbih0aGlzLm1vZGlmeUludGVyYWN0aW9uKCkpO1xuICAgIG1hcC5hZGRJbnRlcmFjdGlvbih0aGlzLmRyYXdJbnRlcmFjdGlvbigpKTtcblxuICAgIC8vIFNOQVBQSU5HIFRPIEZFQVRVUkVTXG4gICAgbWFwLmFkZEludGVyYWN0aW9uKHRoaXMuc25hcEludGVyYWN0aW9uKCkpO1xuXG4gICAgLy8gU0VMRUNUSU5HIEZFQVRVUkVTXG4gICAgbWFwLmFkZEludGVyYWN0aW9uKHRoaXMuc2VsZWN0SW50ZXJhY3Rpb24oKSk7XG4gIH1cblxuICBwcml2YXRlIHJlbW92ZUludGVyYWN0aW9ucyhtYXA6IE1hcCkge1xuICAgIG1hcC5yZW1vdmVJbnRlcmFjdGlvbih0aGlzLmRyYXdJbnRlcmFjdGlvbigpKTtcbiAgICBtYXAucmVtb3ZlSW50ZXJhY3Rpb24odGhpcy5tb2RpZnlJbnRlcmFjdGlvbigpKTtcbiAgICBtYXAucmVtb3ZlSW50ZXJhY3Rpb24odGhpcy5zbmFwSW50ZXJhY3Rpb24oKSk7XG4gICAgbWFwLnJlbW92ZUludGVyYWN0aW9uKHRoaXMuc2VsZWN0SW50ZXJhY3Rpb24oKSk7XG4gIH1cblxuICBwcml2YXRlIG9uRHJhd1N0YXJ0KGRhdGE6IERyYXdFdmVudCkge1xuICAgIGNvbnN0IG1hcCA9IHRoaXMubWFwKCkuc3RhdGUubWFwKCk7XG4gICAgaWYgKG1hcCkge1xuICAgICAgbWFwLnJlbW92ZUludGVyYWN0aW9uKHRoaXMuc2VsZWN0SW50ZXJhY3Rpb24oKSk7XG4gICAgfVxuICB9XG4gIHByaXZhdGUgb25EcmF3RW5kKGRhdGE6IERyYXdFdmVudCkge1xuICAgIGNvbnN0IG1hcCA9IHRoaXMubWFwKCkuc3RhdGUubWFwKCk7XG4gICAgdGhpcy5zZWxlY3RJbnRlcmFjdGlvbigpLnNldEFjdGl2ZSh0cnVlKTtcbiAgICBpZiAobWFwKSB7XG4gICAgICBtYXAuYWRkSW50ZXJhY3Rpb24odGhpcy5zZWxlY3RJbnRlcmFjdGlvbigpKTtcbiAgICB9XG4gICAgdGhpcy5kcmF3SW50ZXJhY3Rpb24oKS5zZXRBY3RpdmUoZmFsc2UpO1xuICAgIGNvbnN0IG9uQ3JlYXRlID0gdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5vbkNyZWF0ZTtcbiAgICBpZiAob25DcmVhdGUpIHtcbiAgICAgIG9uQ3JlYXRlKGRhdGEpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgb25Nb2RpZnlFbmQoZGF0YTogTW9kaWZ5RXZlbnQpIHtcbiAgICBjb25zdCBvbkVkaXQgPSB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLm9uRWRpdDtcbiAgICBpZiAob25FZGl0KSB7XG4gICAgICBvbkVkaXQoZGF0YSk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSB0b2dnbGVEcmF3aW5nKGlzRW5hYmxlZDogYm9vbGVhbikge1xuICAgIGNvbnN0IGRyYXdJbnRlcmFjdGlvbiA9IHRoaXMuZHJhd0ludGVyYWN0aW9uKCk7XG4gICAgaWYgKGRyYXdJbnRlcmFjdGlvbikge1xuICAgICAgZHJhd0ludGVyYWN0aW9uLnNldEFjdGl2ZShpc0VuYWJsZWQpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgcmVmcmVzaERyYXdJbnRlcmFjdGlvbigpIHtcbiAgICBjb25zdCBkcmF3TW9kZSA9IHRoaXMuY29tYmluZWRPcHRpb25zKCkubW9kZTtcbiAgICBjb25zdCBtYXAgPSB0aGlzLm1hcCgpLnN0YXRlLm1hcCgpO1xuICAgIHRoaXMucmVtb3ZlRHJhd0V2ZW50TGlzdGVuZXJzKCk7XG4gICAgaWYgKG1hcCkge1xuICAgICAgbWFwLnJlbW92ZUludGVyYWN0aW9uKHRoaXMuZHJhd0ludGVyYWN0aW9uKCkpO1xuICAgICAgdGhpcy5kcmF3SW50ZXJhY3Rpb24uc2V0KFxuICAgICAgICBuZXcgRHJhdyh7XG4gICAgICAgICAgc291cmNlOiB0aGlzLnNvdXJjZSgpLFxuICAgICAgICAgIHR5cGU6IGRyYXdNb2RlLFxuICAgICAgICB9KVxuICAgICAgKTtcbiAgICAgIG1hcC5hZGRJbnRlcmFjdGlvbih0aGlzLmRyYXdJbnRlcmFjdGlvbigpKTtcbiAgICB9XG4gICAgdGhpcy5hZGREcmF3RXZlbnRMaXN0ZW5lcnMoKTtcbiAgfVxuXG4gIHByaXZhdGUgYWRkRHJhd0V2ZW50TGlzdGVuZXJzKCkge1xuICAgIHRoaXMuZHJhd0ludGVyYWN0aW9uKCkuc2V0QWN0aXZlKHRoaXMuaXNEcmF3aW5nRW5hYmxlZCgpKTtcbiAgICBmb3IgKGxldCBldmVudCBpbiB0aGlzLmRyYXdFdmVudExpc3RlbmVycykge1xuICAgICAgdGhpcy5kcmF3SW50ZXJhY3Rpb24oKS5vbihldmVudCBhcyBhbnksIHRoaXMuZHJhd0V2ZW50TGlzdGVuZXJzW2V2ZW50XSk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSByZW1vdmVEcmF3RXZlbnRMaXN0ZW5lcnMoKSB7XG4gICAgY29uc3QgZHJhd0ludGVyYWN0aW9uID0gdGhpcy5kcmF3SW50ZXJhY3Rpb24oKTtcbiAgICBpZiAoZHJhd0ludGVyYWN0aW9uKSB7XG4gICAgICBmb3IgKGxldCBldmVudCBpbiB0aGlzLmRyYXdFdmVudExpc3RlbmVycykge1xuICAgICAgICBkcmF3SW50ZXJhY3Rpb24udW4oZXZlbnQgYXMgYW55LCB0aGlzLmRyYXdFdmVudExpc3RlbmVyc1tldmVudF0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYWRkTW9kaWZ5RXZlbnRMaXN0ZW5lcnMoKSB7XG4gICAgZm9yIChsZXQgZXZlbnQgaW4gdGhpcy5tb2RpZnlFdmVudExpc3RlbmVycykge1xuICAgICAgdGhpcy5tb2RpZnlJbnRlcmFjdGlvbigpLm9uKFxuICAgICAgICBldmVudCBhcyBhbnksXG4gICAgICAgIHRoaXMubW9kaWZ5RXZlbnRMaXN0ZW5lcnNbZXZlbnRdXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgcmVtb3ZlTW9kaWZ5RXZlbnRMaXN0ZW5lcnMoKSB7XG4gICAgY29uc3QgbW9kaWZ5SW50ZXJhY3Rpb24gPSB0aGlzLm1vZGlmeUludGVyYWN0aW9uKCk7XG4gICAgaWYgKG1vZGlmeUludGVyYWN0aW9uKSB7XG4gICAgICBmb3IgKGxldCBldmVudCBpbiB0aGlzLm1vZGlmeUV2ZW50TGlzdGVuZXJzKSB7XG4gICAgICAgIG1vZGlmeUludGVyYWN0aW9uLnVuKGV2ZW50IGFzIGFueSwgdGhpcy5tb2RpZnlFdmVudExpc3RlbmVyc1tldmVudF0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBvdmVycmlkZSBvbkRlc3Ryb3koKSB7XG4gICAgdGhpcy5yZW1vdmVEcmF3RXZlbnRMaXN0ZW5lcnMoKTtcbiAgICB0aGlzLnJlbW92ZU1vZGlmeUV2ZW50TGlzdGVuZXJzKCk7XG4gIH1cbn1cbiJdfQ==