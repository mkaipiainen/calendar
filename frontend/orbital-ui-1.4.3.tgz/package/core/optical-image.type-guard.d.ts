import { ImageBrokerOpticalImage, ImageBrokerWmsOpticalImage, ImageBrokerWmtsOpticalImage, S2Image } from './typings';
export declare function IsImageBrokerImage(image: any): image is ImageBrokerOpticalImage;
export declare function IsWmtsImageBrokerImage(image: any): image is ImageBrokerWmtsOpticalImage;
export declare function IsWmsImageBrokerImage(image: any): image is ImageBrokerWmsOpticalImage;
export declare function IsS2Image(image: any): image is S2Image;
//# sourceMappingURL=optical-image.type-guard.d.ts.map