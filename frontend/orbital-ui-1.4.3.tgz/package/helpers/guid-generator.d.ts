export declare function GUID(length?: number): string;
//# sourceMappingURL=guid-generator.d.ts.map