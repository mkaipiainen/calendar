import * as i0 from '@angular/core';
import { Injectable, Inject, inject, Component, Input } from '@angular/core';
import * as i1 from '@angular/router';
import { NavigationStart } from '@angular/router';
import { createPopper } from '@popperjs/core';
import { isNil } from 'lodash-es';
import { Subject, fromEvent, ReplaySubject, takeUntil } from 'rxjs';
import { DOCUMENT } from '@angular/common';
import { GUID, ComponentCreator } from 'orbital-ui/helpers';

// Create JDOC to describe this service
/**
 * Service to open popups. Uses popper.js under the hood.
 * You can create popups by passing any custom component together with options to the openPopup() method.
 *
 * The options object can contain the following properties:
 *
 * modifiers: Array of modifiers to be passed to popper.js. Optional and generally only necessary for edge-cases. See https://popper.js.org/docs/v2/modifiers/ for more info.
 * placement: Placement of the popup. Optional and defaults to 'bottom'. See https://popper.js.org/docs/v2/constructors/#placement for more info.
 * strategy: Positioning strategy. Optional and defaults to 'absolute'. Rarely needed. See https://popper.js.org/docs/v2/constructors/#strategy for more info.
 * onFirstUpdate: Callback to be called when the popup is first positioned. Optional. See https://popper.js.org/docs/v2/constructors/#onfirstupdate for more info.
 * id: Id of the popup. Optional. If not provided, a random id will be generated.
 * closeOnEscape: Whether the popup should be closed when the escape key is pressed.
 *
 * The last parameter takes an origin, which the popup will be positioned on. This can be either a DOM element or a virtual element.
 * A virtual element is an object with a getBoundingClientRect() method that returns a DOMRect object.
 * See https://popper.js.org/docs/v2/virtual-elements/ for more info.
 * If no origin is provided, the popup will be positioned on the document body.
 *
 * An arrow can be created automatically by passing in the arrow modifier. See https://popper.js.org/docs/v2/modifiers/arrow/ for more info.
 *
 * Some default modifiers are applied to each popup:
 * - PreventOverflow: prevents the popup from overflowing outside of the window. See https://popper.js.org/docs/v2/modifiers/prevent-overflow/ for more info.
 *
 *
 * An example usecase for a simple popup with an arrow, popup placed to the top left and closeOnEscape enabled.
 * The example popup uses a component called MyPopupComponent which has an input called myInput with a value 'myValue'.
 *
 * const popupOptions: IPopupOptions = {
 *    modifiers: [{
 *      name: 'arrow',
 *        options: {
 *          color: 'var(--color-background)',
 *        }
 *      }
 *    ],
 *    placement: 'top-start',
 *    closeOnEscape: true,
 *  }
 *
 *  this.popupService.openPopup(MyPopupComponent, {myInput: 'myValue'}, popupOptions);
 *
 */
class OuiPopupService {
    router;
    zone;
    appRef;
    injector;
    rendererFactory;
    document;
    openPopups = {};
    popupOpenSubject = new Subject();
    popupClosedSubject = new Subject();
    popupOpen$ = this.popupOpenSubject.asObservable();
    popupClosed$ = this.popupClosedSubject.asObservable();
    renderer;
    constructor(router, zone, appRef, injector, rendererFactory, document) {
        this.router = router;
        this.zone = zone;
        this.appRef = appRef;
        this.injector = injector;
        this.rendererFactory = rendererFactory;
        this.document = document;
        this.renderer = rendererFactory.createRenderer(null, null);
        this.router.events.subscribe(val => {
            if (val instanceof NavigationStart) {
                this.destroyPopups();
            }
        });
        fromEvent(document, 'keyup').subscribe((event) => {
            if (event.key === 'Escape') {
                this.onEscapePress();
            }
        });
        fromEvent(document.body, 'click').subscribe((event) => {
            this.onDocumentClick(event);
        });
    }
    onEscapePress() {
        for (const id in this.openPopups) {
            if (this.openPopups[id].options.closeOnEscape) {
                this.dispose(id);
            }
        }
    }
    onDocumentClick(event) {
        for (const id in this.openPopups) {
            if (this.openPopups[id].options.closeOnOutsideClick &&
                this.openPopups[id].isInitialised &&
                !this.openPopups[id].popupElement.contains(event.target)) {
                this.dispose(id);
            }
        }
    }
    destroyPopups() {
        for (const id in this.openPopups) {
            this.doDispose(id);
        }
    }
    openPopup(content, inputs, options = {}, origin) {
        const id = options.id ?? GUID();
        const popup = this.renderer.createElement('div');
        popup.id = id;
        this.renderer.addClass(popup, 'oui-popup');
        const createComponentOptions = {
            component: content,
            parentElement: popup,
            appRef: this.appRef,
            createComponentOptions: {
                environmentInjector: this.injector,
            },
            inputs: inputs,
        };
        const componentRef = ComponentCreator.createComponent(createComponentOptions);
        this.renderer.appendChild(this.document.body, popup);
        const arrowModifierIndex = options?.modifiers?.findIndex(modifier => modifier.name === 'arrow');
        if (!isNil(arrowModifierIndex) && arrowModifierIndex > -1) {
            const arrow = this.renderer.createElement('div');
            arrow.id = 'arrow';
            this.renderer.appendChild(popup, arrow);
            if (options.modifiers) {
                options.modifiers[arrowModifierIndex].options.element = arrow;
                this.renderer.setStyle(arrow, 'backgroundColor', options.modifiers[arrowModifierIndex].options.color);
                this.renderer.setStyle(arrow, 'color', options.modifiers[arrowModifierIndex].options.color);
                this.renderer.setAttribute(arrow, 'data-popper-arrow', '');
            }
        }
        const defaultModifiers = [
            {
                name: 'preventOverflow',
                options: {
                    altAxis: true,
                    padding: 5,
                },
            },
        ];
        const combinedModifiers = [
            ...defaultModifiers,
            ...(options.modifiers || []),
        ];
        options.modifiers = combinedModifiers;
        this.zone.runOutsideAngular(() => {
            const popperRef = createPopper(origin ?? this.document.body, popup, options);
            this.openPopups[id] = {
                popperRef,
                componentRef,
                popupElement: popup,
                id: id,
                options: options,
                isInitialised: false,
            };
            componentRef.instance.popup = this.openPopups[id];
        });
        this.popupOpenSubject.next(this.openPopups[id]);
        setTimeout(() => {
            if (this.openPopups[id]) {
                this.openPopups[id].isInitialised = true;
            }
        }, 300);
        setTimeout(() => {
            this.renderer.setStyle(popup, 'opacity', '1');
        }, 0);
        return this.openPopups[id];
    }
    dispose(id) {
        if (this.openPopups?.[id]) {
            this.doDispose(id);
        }
    }
    // TODO: Might cause memory-leaks, ensure it doesn't
    doDispose(id) {
        this.renderer.setStyle(this.openPopups[id].popupElement, 'opacity', '0');
        const popperRef = this.openPopups[id].popperRef;
        const componentRef = this.openPopups[id].componentRef;
        const popupElement = this.openPopups[id].popupElement;
        this.popupClosedSubject.next(this.openPopups[id]);
        delete this.openPopups[id];
        setTimeout(() => {
            popperRef.destroy();
            componentRef.destroy();
            this.renderer.removeChild(this.document.body, popupElement);
            this.appRef.detachView(componentRef.hostView);
        }, 300);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiPopupService, deps: [{ token: i1.Router }, { token: i0.NgZone }, { token: i0.ApplicationRef }, { token: i0.EnvironmentInjector }, { token: i0.RendererFactory2 }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiPopupService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiPopupService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.Router }, { type: i0.NgZone }, { type: i0.ApplicationRef }, { type: i0.EnvironmentInjector }, { type: i0.RendererFactory2 }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }] });

/**
 * This component should not be used directly, but instead extended in each popup component.
 * Popups can be opened with ouiPopupService.
 */
class OuiPopupComponent {
    ouiPopupService = inject(OuiPopupService);
    popup;
    constructor() { }
    close() {
        this.ouiPopupService.dispose(this.popup.id);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiPopupComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiPopupComponent, isStandalone: true, selector: "oui-popup", ngImport: i0, template: '', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiPopupComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-popup',
                    template: '',
                    standalone: true,
                }]
        }], ctorParameters: () => [] });

class BasicTextPopupComponent extends OuiPopupComponent {
    elementRef;
    content;
    destroyed$ = new ReplaySubject(1);
    constructor(elementRef) {
        super();
        this.elementRef = elementRef;
    }
    ngAfterViewInit() {
        fromEvent(this.elementRef.nativeElement, 'click')
            .pipe(takeUntil(this.destroyed$))
            .subscribe(() => {
            this.ouiPopupService.destroyPopups();
        });
    }
    ngOnDestroy() {
        this.destroyed$.next(true);
        this.destroyed$.complete();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: BasicTextPopupComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: BasicTextPopupComponent, isStandalone: true, selector: "example-popup", inputs: { content: "content" }, usesInheritance: true, ngImport: i0, template: '<div class="basic-text-popup flex p-4" [innerHTML]="this.content"></div>', isInline: true, styles: [":host{background-color:var(--color-primary);color:var(--color-primary-text)}:host .basic-text-popup{display:flex;justify-content:center;align-items:center}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: BasicTextPopupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'example-popup', template: '<div class="basic-text-popup flex p-4" [innerHTML]="this.content"></div>', standalone: true, imports: [], styles: [":host{background-color:var(--color-primary);color:var(--color-primary-text)}:host .basic-text-popup{display:flex;justify-content:center;align-items:center}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { content: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { BasicTextPopupComponent, OuiPopupComponent, OuiPopupService };
//# sourceMappingURL=orbital-ui-popup.mjs.map
