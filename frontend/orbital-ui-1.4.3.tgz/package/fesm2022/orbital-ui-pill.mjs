import * as i0 from '@angular/core';
import { EventEmitter, Component, ChangeDetectionStrategy, Input, Output } from '@angular/core';
import { OuiIconComponent } from 'orbital-ui/icon';

/**
 * Component to add a 'pill', or a simple bordered wrapper for a value with an x-button that can be clicked to close the pill.
 */
class OuiPillComponent {
    /**
     *   The label shown on the pill
     */
    label;
    /**
     *   A value to be shown on the pill. This can be for example used in case where you want to see the amount of items
     *   applying to a specific filter (which is named by 'label')
     */
    value;
    /**
     *   Triggered when x-button is clicked. You probably want to trigger an action from this that removes the pill from view.
     */
    closed = new EventEmitter();
    constructor() { }
    close() {
        this.closed.emit(true);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiPillComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiPillComponent, isStandalone: true, selector: "oui-pill", inputs: { label: "label", value: "value" }, outputs: { closed: "closed" }, ngImport: i0, template: "<div class=\"pill-container\">\n  @if (label) {\n    <span class=\"label\">{{ label }}</span>\n  }\n  @if (value) {\n    <span class=\"value\">{{ value }}</span>\n  }\n  <span class=\"close\" (click)=\"close()\">\n    <oui-icon\n      [options]=\"{\n        viewBox: '0 0 48 48',\n        width: '8px',\n        height: '8px',\n        fillColor: 'oui-pill-text-color',\n        strokeColor: 'oui-pill-text-color'\n      }\"\n      icon=\"assets/icons/close.svg\"\n    ></oui-icon>\n  </span>\n</div>\n", styles: [":host .pill-container{padding:var(--oui-pill-padding);display:flex;align-items:center;background-color:var(--oui-pill-background-color);border-radius:var(--oui-pill-border-radius);border:1px dashed var(--oui-pill-border-color);color:var(--oui-pill-text-color)}:host .pill-container .label{flex:1}:host .pill-container .value{flex:1}:host .pill-container .close{margin-left:10px;flex:0;border-radius:50%;display:flex;align-items:center;justify-content:center;min-height:14px;min-width:14px;transition:background-color .3s;background-color:var(--oui-pill-close-background-color)}:host .pill-container .close:hover{cursor:pointer}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiPillComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-pill', standalone: true, imports: [OuiIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"pill-container\">\n  @if (label) {\n    <span class=\"label\">{{ label }}</span>\n  }\n  @if (value) {\n    <span class=\"value\">{{ value }}</span>\n  }\n  <span class=\"close\" (click)=\"close()\">\n    <oui-icon\n      [options]=\"{\n        viewBox: '0 0 48 48',\n        width: '8px',\n        height: '8px',\n        fillColor: 'oui-pill-text-color',\n        strokeColor: 'oui-pill-text-color'\n      }\"\n      icon=\"assets/icons/close.svg\"\n    ></oui-icon>\n  </span>\n</div>\n", styles: [":host .pill-container{padding:var(--oui-pill-padding);display:flex;align-items:center;background-color:var(--oui-pill-background-color);border-radius:var(--oui-pill-border-radius);border:1px dashed var(--oui-pill-border-color);color:var(--oui-pill-text-color)}:host .pill-container .label{flex:1}:host .pill-container .value{flex:1}:host .pill-container .close{margin-left:10px;flex:0;border-radius:50%;display:flex;align-items:center;justify-content:center;min-height:14px;min-width:14px;transition:background-color .3s;background-color:var(--oui-pill-close-background-color)}:host .pill-container .close:hover{cursor:pointer}\n"] }]
        }], ctorParameters: () => [], propDecorators: { label: [{
                type: Input
            }], value: [{
                type: Input
            }], closed: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiPillComponent };
//# sourceMappingURL=orbital-ui-pill.mjs.map
