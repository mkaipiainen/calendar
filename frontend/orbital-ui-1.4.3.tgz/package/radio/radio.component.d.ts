import { AfterViewInit, ChangeDetectorRef, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Component to add radio-buttons.
 *
 *   example use:
 *
 *   <oui-radio group="radioButtons"[(model)]="radioModel" value="First value">The label for first radio-button</oui-radio>
 *   <oui-radio group="radioButtons" [(model)]="radioModel" value="Second value">The label for second radio-button</oui-radio>
 *
 */
export declare class OuiRadioComponent implements AfterViewInit, OnChanges {
    private cdr;
    /**
     *   Group that the radio-button belongs to.
     */
    group: string;
    /**
     *   The model attached to the input field value-changes
     */
    model: any;
    /**
     *   The value of the radio-button. When radio-button is selected, the attached model gets this value
     */
    value: any;
    /**
     *   The event emitted when model changes
     */
    modelChange: EventEmitter<any>;
    /**
     *  The property of the model to compare with the value
     */
    compareBy: string;
    isChecked: boolean;
    constructor(cdr: ChangeDetectorRef);
    ngAfterViewInit(): void;
    private doCheckIsChecked;
    private isSelected;
    setModel(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiRadioComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiRadioComponent, "oui-radio", never, { "group": { "alias": "group"; "required": false; }; "model": { "alias": "model"; "required": false; }; "value": { "alias": "value"; "required": false; }; "compareBy": { "alias": "compareBy"; "required": false; }; }, { "modelChange": "modelChange"; }, never, ["*"], true, never>;
}
//# sourceMappingURL=radio.component.d.ts.map