import { ChangeDetectionStrategy, Component, computed, input, signal, } from '@angular/core';
import { isFunction } from 'lodash-es';
import { OpenlayersBaseLayerComponent } from './openlayers-base-layer.component';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import { GeoJSON } from 'ol/format';
import { Stroke, Style } from 'ol/style';
import { DEFAULT_COMMON_OPTIONS } from '../constants';
import * as i0 from "@angular/core";
export class OpenlayersPathLayerComponent extends OpenlayersBaseLayerComponent {
    options = input.required();
    combinedOptions = computed(() => {
        return {
            ...DEFAULT_COMMON_OPTIONS,
            ...{
                getLineColor: [0, 0, 255, 255],
                getLineWidth: 2,
            },
            ...this.options(),
        };
    });
    source = signal(new VectorSource());
    layer = signal(new VectorLayer({
        source: this.source(),
        style: feature => {
            return this.getStyleForFeature(feature);
        },
    }));
    constructor() {
        super();
    }
    getStyleForFeature(feature, isHighlighted = false) {
        const lineColorAccessor = isHighlighted
            ? this.combinedOptions().highlightColor ??
                this.combinedOptions().getLineColor
            : this.combinedOptions().getLineColor;
        const lineColor = lineColorAccessor instanceof Function
            ? lineColorAccessor(feature)
            : [...lineColorAccessor];
        lineColor[3] = lineColor[3] / 255;
        const lineWidth = isFunction(this.combinedOptions().getLineWidth)
            ? this.combinedOptions().getLineWidth(feature)
            : this.combinedOptions().getLineWidth;
        return new Style({
            stroke: new Stroke({
                color: `rgba(${lineColor.join(',')})`,
                width: lineWidth,
            }),
        });
    }
    onHover(feature) {
        super.onHover(feature);
        if (this.combinedOptions().autoHighlight) {
            feature.setStyle(this.getStyleForFeature(feature, true));
        }
    }
    onUnHover(feature) {
        super.onUnHover(feature);
        if (this.combinedOptions().autoHighlight) {
            feature.setStyle(this.getStyleForFeature(feature));
        }
    }
    updateLayer() {
        const dataWithLayer = {
            type: 'FeatureCollection',
            features: this.combinedOptions().data.map((datum) => {
                return {
                    type: 'Feature',
                    geometry: {
                        type: 'LineString',
                        coordinates: this.combinedOptions().getPath(datum),
                    },
                    properties: {
                        ...(datum ?? {}),
                        layer: this,
                    },
                };
            }),
        };
        this.layer().setZIndex(this.combinedOptions().order ?? 0);
        this.source().clear(true);
        this.source().addFeatures(new GeoJSON().readFeatures(dataWithLayer, {
            featureProjection: 'EPSG:3857', // Ensure the projection matches your map's projection
        }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersPathLayerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "17.3.1", type: OpenlayersPathLayerComponent, isStandalone: true, selector: "oui-openlayers-path-layer", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, providers: [
            {
                provide: OpenlayersBaseLayerComponent,
                useExisting: OpenlayersPathLayerComponent,
            },
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersPathLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-openlayers-path-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [
                        {
                            provide: OpenlayersBaseLayerComponent,
                            useExisting: OpenlayersPathLayerComponent,
                        },
                    ],
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BlbmxheWVycy1wYXRoLWxheWVyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvb3BlbmxheWVycy9sYXllcnMvb3BlbmxheWVycy1wYXRoLWxheWVyLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBRUwsdUJBQXVCLEVBQ3ZCLFNBQVMsRUFDVCxRQUFRLEVBQ1IsS0FBSyxFQUNMLE1BQU0sR0FDUCxNQUFNLGVBQWUsQ0FBQztBQUl2QixPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sV0FBVyxDQUFDO0FBQ3ZDLE9BQU8sRUFBRSw0QkFBNEIsRUFBRSxNQUFNLG1DQUFtQyxDQUFDO0FBQ2pGLE9BQU8sV0FBVyxNQUFNLGlCQUFpQixDQUFDO0FBQzFDLE9BQU8sWUFBWSxNQUFNLGtCQUFrQixDQUFDO0FBQzVDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFDcEMsT0FBTyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxVQUFVLENBQUM7QUFHekMsT0FBTyxFQUFFLHNCQUFzQixFQUFFLE1BQU0sY0FBYyxDQUFDOztBQWV0RCxNQUFNLE9BQU8sNEJBQTZCLFNBQVEsNEJBQTJEO0lBQzNGLE9BQU8sR0FBRyxLQUFLLENBQUMsUUFBUSxFQUFpQyxDQUFDO0lBQ25FLGVBQWUsR0FBRyxRQUFRLENBQUMsR0FBRyxFQUFFO1FBQ3JDLE9BQU87WUFDTCxHQUFHLHNCQUFzQjtZQUN6QixHQUFHO2dCQUNELFlBQVksRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxFQUFFLEdBQUcsQ0FBUztnQkFDdEMsWUFBWSxFQUFFLENBQUM7YUFDaEI7WUFDRCxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUU7U0FDbEIsQ0FBQztJQUNKLENBQUMsQ0FBQyxDQUFDO0lBRUksTUFBTSxHQUFHLE1BQU0sQ0FBZSxJQUFJLFlBQVksRUFBRSxDQUFDLENBQUM7SUFDbEQsS0FBSyxHQUFHLE1BQU0sQ0FDbkIsSUFBSSxXQUFXLENBQUM7UUFDZCxNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRTtRQUNyQixLQUFLLEVBQUUsT0FBTyxDQUFDLEVBQUU7WUFDZixPQUFPLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUMxQyxDQUFDO0tBQ0YsQ0FBQyxDQUNILENBQUM7SUFFRjtRQUNFLEtBQUssRUFBRSxDQUFDO0lBQ1YsQ0FBQztJQUVPLGtCQUFrQixDQUFDLE9BQW9CLEVBQUUsYUFBYSxHQUFHLEtBQUs7UUFDcEUsTUFBTSxpQkFBaUIsR0FBRyxhQUFhO1lBQ3JDLENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsY0FBYztnQkFDckMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLFlBQVk7WUFDckMsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxZQUFZLENBQUM7UUFDeEMsTUFBTSxTQUFTLEdBQ2IsaUJBQWlCLFlBQVksUUFBUTtZQUNuQyxDQUFDLENBQUUsaUJBQThCLENBQUMsT0FBTyxDQUFDO1lBQzFDLENBQUMsQ0FBQyxDQUFDLEdBQUksaUJBQTBCLENBQUMsQ0FBQztRQUV2QyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztRQUNsQyxNQUFNLFNBQVMsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLFlBQVksQ0FBQztZQUMvRCxDQUFDLENBQUUsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLFlBQXlCLENBQUMsT0FBTyxDQUFDO1lBQzVELENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsWUFBWSxDQUFDO1FBRXhDLE9BQU8sSUFBSSxLQUFLLENBQUM7WUFDZixNQUFNLEVBQUUsSUFBSSxNQUFNLENBQUM7Z0JBQ2pCLEtBQUssRUFBRSxRQUFRLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUc7Z0JBQ3JDLEtBQUssRUFBRSxTQUFTO2FBQ2pCLENBQUM7U0FDSCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRWUsT0FBTyxDQUFDLE9BQWtCO1FBQ3hDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDdkIsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDekMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDM0QsQ0FBQztJQUNILENBQUM7SUFFZSxTQUFTLENBQUMsT0FBa0I7UUFDMUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN6QixJQUFJLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUN6QyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO1FBQ3JELENBQUM7SUFDSCxDQUFDO0lBRU0sV0FBVztRQUNoQixNQUFNLGFBQWEsR0FBRztZQUNwQixJQUFJLEVBQUUsbUJBQW1CO1lBQ3pCLFFBQVEsRUFBRSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFO2dCQUN2RCxPQUFPO29CQUNMLElBQUksRUFBRSxTQUFTO29CQUNmLFFBQVEsRUFBRTt3QkFDUixJQUFJLEVBQUUsWUFBWTt3QkFDbEIsV0FBVyxFQUFFLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO3FCQUNuRDtvQkFDRCxVQUFVLEVBQUU7d0JBQ1YsR0FBRyxDQUFDLEtBQUssSUFBSSxFQUFFLENBQUM7d0JBQ2hCLEtBQUssRUFBRSxJQUFJO3FCQUNaO2lCQUNGLENBQUM7WUFDSixDQUFDLENBQUM7U0FDa0IsQ0FBQztRQUN2QixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDMUQsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUMxQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsV0FBVyxDQUN2QixJQUFJLE9BQU8sRUFBRSxDQUFDLFlBQVksQ0FBQyxhQUFhLEVBQUU7WUFDeEMsaUJBQWlCLEVBQUUsV0FBVyxFQUFFLHNEQUFzRDtTQUN2RixDQUFRLENBQ1YsQ0FBQztJQUNKLENBQUM7dUdBeEZVLDRCQUE0QjsyRkFBNUIsNEJBQTRCLGlOQVA1QjtZQUNUO2dCQUNFLE9BQU8sRUFBRSw0QkFBNEI7Z0JBQ3JDLFdBQVcsRUFBRSw0QkFBNEI7YUFDMUM7U0FDRixpREFUUyxFQUFFOzsyRkFXRCw0QkFBNEI7a0JBYnhDLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLDJCQUEyQjtvQkFDckMsUUFBUSxFQUFFLEVBQUU7b0JBQ1osVUFBVSxFQUFFLElBQUk7b0JBQ2hCLE9BQU8sRUFBRSxFQUFFO29CQUNYLGVBQWUsRUFBRSx1QkFBdUIsQ0FBQyxNQUFNO29CQUMvQyxTQUFTLEVBQUU7d0JBQ1Q7NEJBQ0UsT0FBTyxFQUFFLDRCQUE0Qjs0QkFDckMsV0FBVyw4QkFBOEI7eUJBQzFDO3FCQUNGO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIENvbXBvbmVudCxcbiAgY29tcHV0ZWQsXG4gIGlucHV0LFxuICBzaWduYWwsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgRmVhdHVyZUNvbGxlY3Rpb24gfSBmcm9tICdAdHVyZi9oZWxwZXJzJztcbmltcG9ydCB7IEZlYXR1cmUgYXMgT2xGZWF0dXJlIH0gZnJvbSAnb2wnO1xuaW1wb3J0IHsgUkdCQSB9IGZyb20gJ29yYml0YWwtdWkvY29yZSc7XG5pbXBvcnQgeyBpc0Z1bmN0aW9uIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IE9wZW5sYXllcnNCYXNlTGF5ZXJDb21wb25lbnQgfSBmcm9tICcuL29wZW5sYXllcnMtYmFzZS1sYXllci5jb21wb25lbnQnO1xuaW1wb3J0IFZlY3RvckxheWVyIGZyb20gJ29sL2xheWVyL1ZlY3Rvcic7XG5pbXBvcnQgVmVjdG9yU291cmNlIGZyb20gJ29sL3NvdXJjZS9WZWN0b3InO1xuaW1wb3J0IHsgR2VvSlNPTiB9IGZyb20gJ29sL2Zvcm1hdCc7XG5pbXBvcnQgeyBTdHJva2UsIFN0eWxlIH0gZnJvbSAnb2wvc3R5bGUnO1xuaW1wb3J0IHsgRmVhdHVyZUxpa2UgfSBmcm9tICdvbC9GZWF0dXJlJztcbmltcG9ydCB7IE91aU9wZW5sYXllcnNQYXRoTGF5ZXJPcHRpb25zIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgREVGQVVMVF9DT01NT05fT1BUSU9OUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1vcGVubGF5ZXJzLXBhdGgtbGF5ZXInLFxuICB0ZW1wbGF0ZTogJycsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtdLFxuICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcbiAgcHJvdmlkZXJzOiBbXG4gICAge1xuICAgICAgcHJvdmlkZTogT3BlbmxheWVyc0Jhc2VMYXllckNvbXBvbmVudCxcbiAgICAgIHVzZUV4aXN0aW5nOiBPcGVubGF5ZXJzUGF0aExheWVyQ29tcG9uZW50LFxuICAgIH0sXG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIE9wZW5sYXllcnNQYXRoTGF5ZXJDb21wb25lbnQgZXh0ZW5kcyBPcGVubGF5ZXJzQmFzZUxheWVyQ29tcG9uZW50PE91aU9wZW5sYXllcnNQYXRoTGF5ZXJPcHRpb25zPiB7XG4gIHB1YmxpYyBvdmVycmlkZSBvcHRpb25zID0gaW5wdXQucmVxdWlyZWQ8T3VpT3BlbmxheWVyc1BhdGhMYXllck9wdGlvbnM+KCk7XG4gIHB1YmxpYyBjb21iaW5lZE9wdGlvbnMgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLkRFRkFVTFRfQ09NTU9OX09QVElPTlMsXG4gICAgICAuLi57XG4gICAgICAgIGdldExpbmVDb2xvcjogWzAsIDAsIDI1NSwgMjU1XSBhcyBSR0JBLFxuICAgICAgICBnZXRMaW5lV2lkdGg6IDIsXG4gICAgICB9LFxuICAgICAgLi4udGhpcy5vcHRpb25zKCksXG4gICAgfTtcbiAgfSk7XG5cbiAgcHVibGljIHNvdXJjZSA9IHNpZ25hbDxWZWN0b3JTb3VyY2U+KG5ldyBWZWN0b3JTb3VyY2UoKSk7XG4gIHB1YmxpYyBsYXllciA9IHNpZ25hbDxWZWN0b3JMYXllcjxWZWN0b3JTb3VyY2U+PihcbiAgICBuZXcgVmVjdG9yTGF5ZXIoe1xuICAgICAgc291cmNlOiB0aGlzLnNvdXJjZSgpLFxuICAgICAgc3R5bGU6IGZlYXR1cmUgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5nZXRTdHlsZUZvckZlYXR1cmUoZmVhdHVyZSk7XG4gICAgICB9LFxuICAgIH0pXG4gICk7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHByaXZhdGUgZ2V0U3R5bGVGb3JGZWF0dXJlKGZlYXR1cmU6IEZlYXR1cmVMaWtlLCBpc0hpZ2hsaWdodGVkID0gZmFsc2UpIHtcbiAgICBjb25zdCBsaW5lQ29sb3JBY2Nlc3NvciA9IGlzSGlnaGxpZ2h0ZWRcbiAgICAgID8gdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5oaWdobGlnaHRDb2xvciA/P1xuICAgICAgICB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmdldExpbmVDb2xvclxuICAgICAgOiB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmdldExpbmVDb2xvcjtcbiAgICBjb25zdCBsaW5lQ29sb3IgPVxuICAgICAgbGluZUNvbG9yQWNjZXNzb3IgaW5zdGFuY2VvZiBGdW5jdGlvblxuICAgICAgICA/IChsaW5lQ29sb3JBY2Nlc3NvciBhcyBGdW5jdGlvbikoZmVhdHVyZSlcbiAgICAgICAgOiBbLi4uKGxpbmVDb2xvckFjY2Vzc29yIGFzIFJHQkEpXTtcblxuICAgIGxpbmVDb2xvclszXSA9IGxpbmVDb2xvclszXSAvIDI1NTtcbiAgICBjb25zdCBsaW5lV2lkdGggPSBpc0Z1bmN0aW9uKHRoaXMuY29tYmluZWRPcHRpb25zKCkuZ2V0TGluZVdpZHRoKVxuICAgICAgPyAodGhpcy5jb21iaW5lZE9wdGlvbnMoKS5nZXRMaW5lV2lkdGggYXMgRnVuY3Rpb24pKGZlYXR1cmUpXG4gICAgICA6IHRoaXMuY29tYmluZWRPcHRpb25zKCkuZ2V0TGluZVdpZHRoO1xuXG4gICAgcmV0dXJuIG5ldyBTdHlsZSh7XG4gICAgICBzdHJva2U6IG5ldyBTdHJva2Uoe1xuICAgICAgICBjb2xvcjogYHJnYmEoJHtsaW5lQ29sb3Iuam9pbignLCcpfSlgLFxuICAgICAgICB3aWR0aDogbGluZVdpZHRoLFxuICAgICAgfSksXG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgb3ZlcnJpZGUgb25Ib3ZlcihmZWF0dXJlOiBPbEZlYXR1cmUpIHtcbiAgICBzdXBlci5vbkhvdmVyKGZlYXR1cmUpO1xuICAgIGlmICh0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmF1dG9IaWdobGlnaHQpIHtcbiAgICAgIGZlYXR1cmUuc2V0U3R5bGUodGhpcy5nZXRTdHlsZUZvckZlYXR1cmUoZmVhdHVyZSwgdHJ1ZSkpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBvdmVycmlkZSBvblVuSG92ZXIoZmVhdHVyZTogT2xGZWF0dXJlKSB7XG4gICAgc3VwZXIub25VbkhvdmVyKGZlYXR1cmUpO1xuICAgIGlmICh0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmF1dG9IaWdobGlnaHQpIHtcbiAgICAgIGZlYXR1cmUuc2V0U3R5bGUodGhpcy5nZXRTdHlsZUZvckZlYXR1cmUoZmVhdHVyZSkpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyB1cGRhdGVMYXllcigpIHtcbiAgICBjb25zdCBkYXRhV2l0aExheWVyID0ge1xuICAgICAgdHlwZTogJ0ZlYXR1cmVDb2xsZWN0aW9uJyxcbiAgICAgIGZlYXR1cmVzOiB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmRhdGEubWFwKChkYXR1bTogYW55KSA9PiB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgdHlwZTogJ0ZlYXR1cmUnLFxuICAgICAgICAgIGdlb21ldHJ5OiB7XG4gICAgICAgICAgICB0eXBlOiAnTGluZVN0cmluZycsXG4gICAgICAgICAgICBjb29yZGluYXRlczogdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5nZXRQYXRoKGRhdHVtKSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgICAgIC4uLihkYXR1bSA/PyB7fSksXG4gICAgICAgICAgICBsYXllcjogdGhpcyxcbiAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgICAgfSksXG4gICAgfSBhcyBGZWF0dXJlQ29sbGVjdGlvbjtcbiAgICB0aGlzLmxheWVyKCkuc2V0WkluZGV4KHRoaXMuY29tYmluZWRPcHRpb25zKCkub3JkZXIgPz8gMCk7XG4gICAgdGhpcy5zb3VyY2UoKS5jbGVhcih0cnVlKTtcbiAgICB0aGlzLnNvdXJjZSgpLmFkZEZlYXR1cmVzKFxuICAgICAgbmV3IEdlb0pTT04oKS5yZWFkRmVhdHVyZXMoZGF0YVdpdGhMYXllciwge1xuICAgICAgICBmZWF0dXJlUHJvamVjdGlvbjogJ0VQU0c6Mzg1NycsIC8vIEVuc3VyZSB0aGUgcHJvamVjdGlvbiBtYXRjaGVzIHlvdXIgbWFwJ3MgcHJvamVjdGlvblxuICAgICAgfSkgYXMgYW55XG4gICAgKTtcbiAgfVxufVxuIl19