import { AfterViewInit, ChangeDetectorRef, DestroyRef, ElementRef, OnChanges, QueryList, SimpleChanges } from '@angular/core';
import { IOuiTableColumn, IOuiTableCombinedOptions } from '../types';
import { TableService } from '../table.service';
import * as i0 from "@angular/core";
export declare class OuiTableRowComponent implements AfterViewInit, OnChanges {
    private elementRef;
    private destroyRef;
    private cdr;
    columnRefs: QueryList<ElementRef>;
    item: any;
    options: IOuiTableCombinedOptions;
    tableService: TableService;
    isClickable: boolean;
    isLoaded: import("@angular/core").WritableSignal<boolean>;
    columns: import("@angular/core").WritableSignal<IOuiTableColumn[]>;
    constructor(elementRef: ElementRef, destroyRef: DestroyRef, cdr: ChangeDetectorRef);
    ngAfterViewInit(): void;
    trackById(index: number, column: IOuiTableColumn): string;
    onItemClick(event: Event): void;
    private initColumnWidths;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiTableRowComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiTableRowComponent, "oui-table-row", never, { "item": { "alias": "item"; "required": true; }; "options": { "alias": "options"; "required": true; }; "tableService": { "alias": "tableService"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=oui-table-row.component.d.ts.map