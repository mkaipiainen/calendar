/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/skeleton" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-skeleton.d.ts.map