import { AfterViewInit, ChangeDetectorRef, ElementRef, EventEmitter, OnChanges, OnDestroy, Renderer2, SimpleChanges } from '@angular/core';
import { OuiInputService } from './input.service';
import { AbstractControl, ControlValueAccessor, ValidationErrors, Validator } from '@angular/forms';
import { IOuiIconOptions } from 'orbital-ui/icon';
import { AutofillMonitor } from '@angular/cdk/text-field';
import * as i0 from "@angular/core";
export type IOuiInputVariant = 'standard' | 'underlined';
export type IOuiInputOptions = Partial<IOuiInputCombinedOptions>;
export interface IOuiInputCombinedOptions {
    label: string | undefined;
    placeholder: string | undefined;
    variant: IOuiInputVariant;
    maxLength: number | undefined;
    type: 'text' | 'number' | 'password';
    fontSize: string;
    sizeToContent: boolean;
    noPadding: boolean;
    endIcon: {
        icon: string;
        options: IOuiIconOptions;
        onClick?: () => void;
    } | undefined;
}
/**
 * Component to add input-fields.
 *
 *   Example use:
 *   <oui-input variant="underlined" [(model)]="myInputValue" placeholder="Please write your input..."></oui-input>
 */
export declare class OuiInputComponent implements AfterViewInit, OnChanges, ControlValueAccessor, Validator, OnDestroy {
    #private;
    private ouiInputService;
    private cdr;
    private elementRef;
    private renderer;
    private autofillMonitor;
    inputElement: ElementRef;
    autosizeSpan: ElementRef;
    inputWrapperElement: ElementRef;
    /**
     *   The model that's bound to the input field
     */
    model: any;
    /**
     * Options of the input-field. See IOuiInputOptions for more information
     */
    set options(options: IOuiInputOptions);
    get options(): IOuiInputCombinedOptions;
    /**
     *   The event emitted when input field changes.
     */
    modelChange: EventEmitter<any>;
    /**
     *   The event emitted when the hasError-field changes
     */
    hasErrorChange: EventEmitter<boolean>;
    isFocused: boolean;
    isDisabled: boolean;
    isActive: boolean;
    id: string;
    isInitialized: boolean;
    sizeToContentModel: string;
    constructor(ouiInputService: OuiInputService, cdr: ChangeDetectorRef, elementRef: ElementRef, renderer: Renderer2, autofillMonitor: AutofillMonitor);
    onModelChange(data: string): void;
    private isAutoFilled;
    ngAfterViewInit(): void;
    setFocus(value: boolean): void;
    checkIsActive(): void;
    setError(value: boolean): void;
    onEndIconClick(): void;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    validate(control: AbstractControl): ValidationErrors | null;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiInputComponent, "oui-input", never, { "model": { "alias": "model"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, { "modelChange": "modelChange"; "hasErrorChange": "hasErrorChange"; }, never, never, true, never>;
}
//# sourceMappingURL=input.component.d.ts.map