import { PipeTransform } from '@angular/core';
import { IDateLabelTranslations } from '../date-picker/date-picker.component';
import * as i0 from "@angular/core";
export declare class MonthShortLabelPipe implements PipeTransform {
    transform(value: Date | undefined, translations: IDateLabelTranslations): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<MonthShortLabelPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<MonthShortLabelPipe, "monthShortLabel", true>;
}
//# sourceMappingURL=month-short-label.pipe.d.ts.map