export * from './textarea.component';
//# sourceMappingURL=public-api.d.ts.map