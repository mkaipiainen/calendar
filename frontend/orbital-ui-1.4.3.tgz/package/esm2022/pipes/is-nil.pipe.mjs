import { Pipe } from '@angular/core';
import { isNil } from 'lodash-es';
import * as i0 from "@angular/core";
/**
 * Pipe to check if a value is null or undefined
 * @param value value to check
 */
export class IsNilPipe {
    transform(value) {
        return isNil(value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsNilPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: IsNilPipe, isStandalone: true, name: "isNil" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsNilPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'isNil',
                    standalone: true,
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXMtbmlsLnBpcGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3BpcGVzL2lzLW5pbC5waXBlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxJQUFJLEVBQWlCLE1BQU0sZUFBZSxDQUFDO0FBQ3BELE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxXQUFXLENBQUM7O0FBRWxDOzs7R0FHRztBQUtILE1BQU0sT0FBTyxTQUFTO0lBQ3BCLFNBQVMsQ0FBQyxLQUFVO1FBQ2xCLE9BQU8sS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3RCLENBQUM7dUdBSFUsU0FBUztxR0FBVCxTQUFTOzsyRkFBVCxTQUFTO2tCQUpyQixJQUFJO21CQUFDO29CQUNKLElBQUksRUFBRSxPQUFPO29CQUNiLFVBQVUsRUFBRSxJQUFJO2lCQUNqQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFBpcGUsIFBpcGVUcmFuc2Zvcm0gfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGlzTmlsIH0gZnJvbSAnbG9kYXNoLWVzJztcblxuLyoqXG4gKiBQaXBlIHRvIGNoZWNrIGlmIGEgdmFsdWUgaXMgbnVsbCBvciB1bmRlZmluZWRcbiAqIEBwYXJhbSB2YWx1ZSB2YWx1ZSB0byBjaGVja1xuICovXG5AUGlwZSh7XG4gIG5hbWU6ICdpc05pbCcsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG59KVxuZXhwb3J0IGNsYXNzIElzTmlsUGlwZSBpbXBsZW1lbnRzIFBpcGVUcmFuc2Zvcm0ge1xuICB0cmFuc2Zvcm0odmFsdWU6IGFueSk6IGJvb2xlYW4ge1xuICAgIHJldHVybiBpc05pbCh2YWx1ZSk7XG4gIH1cbn1cbiJdfQ==