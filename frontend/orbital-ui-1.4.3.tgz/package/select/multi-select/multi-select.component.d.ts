import { AfterViewInit, ElementRef, EventEmitter, NgZone, OnChanges, SimpleChanges, TemplateRef, ViewContainerRef } from '@angular/core';
import { OuiSelectService } from '../select.service';
import * as i0 from "@angular/core";
interface IOuiMultiSelectResults {
    [x: string]: any[];
}
export interface IOuiMultiSelectOptions {
    sections?: IOuiMultiSelectSection[];
}
export interface IOuiMultiSelectSection {
    id: string;
    items: any[];
    title: string;
    labelKey: string;
    bindToKey?: string;
}
/**
 * This component should be used to select from groups of multiple different types of entities.
 * For a simple multi-select, use the oui-select component with the options `isMultiple` set to true.
 */
export declare class OuiMultiSelectComponent implements AfterViewInit, OnChanges {
    private vcr;
    private zone;
    private ouiSelectService;
    private document;
    options: IOuiMultiSelectOptions;
    model: any;
    template: TemplateRef<any> | null | undefined;
    bindValueToKey: string;
    modelChange: EventEmitter<any>;
    closed: EventEmitter<any>;
    dropdownContent: TemplateRef<any> | undefined;
    origin: ElementRef;
    internalModel: IOuiMultiSelectResults;
    view: any;
    popperRef: any;
    isOpen: boolean;
    id: string;
    results: IOuiMultiSelectResults;
    private originalResults;
    private originalInternalModel;
    constructor(vcr: ViewContainerRef, zone: NgZone, ouiSelectService: OuiSelectService, document: Document);
    ngAfterViewInit(): void;
    private initializePicker;
    open(): void;
    toggle(): void;
    close(): void;
    selectItem(item: any, selectedSection: IOuiMultiSelectSection): void;
    removeItem(item: any, sectionId: string): void;
    submit(): void;
    cancel(): void;
    getResultsForSection(section: IOuiMultiSelectSection): any[];
    getItemsForSection(section: IOuiMultiSelectSection): any[];
    getSelectedItems(): string;
    getSectionsWithItems(): IOuiMultiSelectSection[];
    getSectionsWithResults(): IOuiMultiSelectSection[];
    ngOnChanges(changes: SimpleChanges): void;
    onClick(event: MouseEvent, targetElement: HTMLElement): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiMultiSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiMultiSelectComponent, "oui-multi-select", never, { "options": { "alias": "options"; "required": false; }; "model": { "alias": "model"; "required": false; }; "template": { "alias": "template"; "required": false; }; "bindValueToKey": { "alias": "bindValueToKey"; "required": false; }; }, { "modelChange": "modelChange"; "closed": "closed"; }, never, never, true, never>;
}
export {};
//# sourceMappingURL=multi-select.component.d.ts.map