import { Injectable } from '@angular/core';
import { Subject, take } from 'rxjs';
import * as i0 from "@angular/core";
/**
 * Used to queue requests done by the Deck.GL tileLayer.
 * This is needed in cases where the token expires in the middle of loading tiles, in which case
 * requests go into a queue, and are then executed once the token has been refreshed.
 *
 * This is used by rasterLayerService, which should be used for handling optical layers for maps.
 */
export class RequestQueueService {
    refreshRequiredSubject = new Subject();
    refreshRequired$ = this.refreshRequiredSubject.asObservable();
    queue = [];
    isRefreshingToken = false;
    constructor() { }
    addToQueue(promise, signal, refreshedAccessToken$) {
        let promiseResolve;
        let promiseReject;
        const wrapperPromise = new Promise((resolve, reject) => {
            promiseResolve = resolve;
            promiseReject = reject;
        });
        promise
            .catch(error => {
            promiseReject(error);
        })
            .then((result) => {
            if (!result) {
                promiseReject(result);
                return;
            }
            if (result.status === 401 && !refreshedAccessToken$) {
                promiseReject(result);
            }
            else if (result.status === 401 && refreshedAccessToken$) {
                this.queue.push(result);
                if (!this.isRefreshingToken) {
                    this.isRefreshingToken = true;
                    this.refreshRequiredSubject.next();
                    refreshedAccessToken$.pipe(take(1)).subscribe(token => {
                        this.isRefreshingToken = false;
                        for (const singleResult of this.queue) {
                            fetch(singleResult.url, {
                                signal,
                                headers: {
                                    Authorization: `Bearer ${token}`,
                                },
                            })
                                .then(response => {
                                promiseResolve(response);
                            }, error => {
                                promiseReject(error);
                            })
                                .catch(error => {
                                console.log(error);
                            });
                        }
                        this.queue = [];
                    });
                }
            }
            else if (result.status !== 200) {
                promiseReject(result);
            }
            else {
                promiseResolve(result);
            }
        }, error => {
            promiseResolve(error);
        });
        return wrapperPromise;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: RequestQueueService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: RequestQueueService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: RequestQueueService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVxdWVzdC1xdWV1ZS5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9jb3JlL3JlcXVlc3QtcXVldWUuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBYyxPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0sTUFBTSxDQUFDOztBQUVqRDs7Ozs7O0dBTUc7QUFLSCxNQUFNLE9BQU8sbUJBQW1CO0lBQ3RCLHNCQUFzQixHQUFHLElBQUksT0FBTyxFQUFRLENBQUM7SUFDOUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFlBQVksRUFBRSxDQUFDO0lBRTlELEtBQUssR0FBVSxFQUFFLENBQUM7SUFDakIsaUJBQWlCLEdBQUcsS0FBSyxDQUFDO0lBRWxDLGdCQUFlLENBQUM7SUFFVCxVQUFVLENBQ2YsT0FBMEIsRUFDMUIsTUFBbUIsRUFDbkIscUJBQTBDO1FBRTFDLElBQUksY0FBaUUsQ0FBQztRQUN0RSxJQUFJLGFBQWdFLENBQUM7UUFDckUsTUFBTSxjQUFjLEdBQUcsSUFBSSxPQUFPLENBQVcsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDL0QsY0FBYyxHQUFHLE9BQU8sQ0FBQztZQUN6QixhQUFhLEdBQUcsTUFBTSxDQUFDO1FBQ3pCLENBQUMsQ0FBQyxDQUFDO1FBRUgsT0FBTzthQUNKLEtBQUssQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUNiLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN2QixDQUFDLENBQUM7YUFDRCxJQUFJLENBQ0gsQ0FBQyxNQUFXLEVBQUUsRUFBRTtZQUNkLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFDWixhQUFhLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3RCLE9BQU87WUFDVCxDQUFDO1lBQ0QsSUFBSSxNQUFNLENBQUMsTUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7Z0JBQ3BELGFBQWEsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN4QixDQUFDO2lCQUFNLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxHQUFHLElBQUkscUJBQXFCLEVBQUUsQ0FBQztnQkFDMUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3hCLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztvQkFDNUIsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQztvQkFDOUIsSUFBSSxDQUFDLHNCQUFzQixDQUFDLElBQUksRUFBRSxDQUFDO29CQUNuQyxxQkFBcUIsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFO3dCQUNwRCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFDO3dCQUMvQixLQUFLLE1BQU0sWUFBWSxJQUFJLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQzs0QkFDdEMsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFHLEVBQUU7Z0NBQ3RCLE1BQU07Z0NBQ04sT0FBTyxFQUFFO29DQUNQLGFBQWEsRUFBRSxVQUFVLEtBQUssRUFBRTtpQ0FDakM7NkJBQ0YsQ0FBQztpQ0FDQyxJQUFJLENBQ0gsUUFBUSxDQUFDLEVBQUU7Z0NBQ1QsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDOzRCQUMzQixDQUFDLEVBQ0QsS0FBSyxDQUFDLEVBQUU7Z0NBQ04sYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDOzRCQUN2QixDQUFDLENBQ0Y7aUNBQ0EsS0FBSyxDQUFDLEtBQUssQ0FBQyxFQUFFO2dDQUNiLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7NEJBQ3JCLENBQUMsQ0FBQyxDQUFDO3dCQUNQLENBQUM7d0JBQ0QsSUFBSSxDQUFDLEtBQUssR0FBRyxFQUFFLENBQUM7b0JBQ2xCLENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUM7WUFDSCxDQUFDO2lCQUFNLElBQUksTUFBTSxDQUFDLE1BQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQztnQkFDakMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3hCLENBQUM7aUJBQU0sQ0FBQztnQkFDTixjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDekIsQ0FBQztRQUNILENBQUMsRUFDRCxLQUFLLENBQUMsRUFBRTtZQUNOLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN4QixDQUFDLENBQ0YsQ0FBQztRQUVKLE9BQU8sY0FBYyxDQUFDO0lBQ3hCLENBQUM7dUdBMUVVLG1CQUFtQjsyR0FBbkIsbUJBQW1CLGNBRmxCLE1BQU07OzJGQUVQLG1CQUFtQjtrQkFIL0IsVUFBVTttQkFBQztvQkFDVixVQUFVLEVBQUUsTUFBTTtpQkFDbkIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBTdWJqZWN0LCB0YWtlIH0gZnJvbSAncnhqcyc7XG5cbi8qKlxuICogVXNlZCB0byBxdWV1ZSByZXF1ZXN0cyBkb25lIGJ5IHRoZSBEZWNrLkdMIHRpbGVMYXllci5cbiAqIFRoaXMgaXMgbmVlZGVkIGluIGNhc2VzIHdoZXJlIHRoZSB0b2tlbiBleHBpcmVzIGluIHRoZSBtaWRkbGUgb2YgbG9hZGluZyB0aWxlcywgaW4gd2hpY2ggY2FzZVxuICogcmVxdWVzdHMgZ28gaW50byBhIHF1ZXVlLCBhbmQgYXJlIHRoZW4gZXhlY3V0ZWQgb25jZSB0aGUgdG9rZW4gaGFzIGJlZW4gcmVmcmVzaGVkLlxuICpcbiAqIFRoaXMgaXMgdXNlZCBieSByYXN0ZXJMYXllclNlcnZpY2UsIHdoaWNoIHNob3VsZCBiZSB1c2VkIGZvciBoYW5kbGluZyBvcHRpY2FsIGxheWVycyBmb3IgbWFwcy5cbiAqL1xuXG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290Jyxcbn0pXG5leHBvcnQgY2xhc3MgUmVxdWVzdFF1ZXVlU2VydmljZSB7XG4gIHByaXZhdGUgcmVmcmVzaFJlcXVpcmVkU3ViamVjdCA9IG5ldyBTdWJqZWN0PHZvaWQ+KCk7XG4gIHB1YmxpYyByZWZyZXNoUmVxdWlyZWQkID0gdGhpcy5yZWZyZXNoUmVxdWlyZWRTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuXG4gIHB1YmxpYyBxdWV1ZTogYW55W10gPSBbXTtcbiAgcHJpdmF0ZSBpc1JlZnJlc2hpbmdUb2tlbiA9IGZhbHNlO1xuXG4gIGNvbnN0cnVjdG9yKCkge31cblxuICBwdWJsaWMgYWRkVG9RdWV1ZShcbiAgICBwcm9taXNlOiBQcm9taXNlPFJlc3BvbnNlPixcbiAgICBzaWduYWw6IEFib3J0U2lnbmFsLFxuICAgIHJlZnJlc2hlZEFjY2Vzc1Rva2VuJD86IE9ic2VydmFibGU8c3RyaW5nPlxuICApOiBQcm9taXNlPFJlc3BvbnNlPiB7XG4gICAgbGV0IHByb21pc2VSZXNvbHZlOiAodmFsdWU6IFJlc3BvbnNlIHwgUHJvbWlzZUxpa2U8UmVzcG9uc2U+KSA9PiB2b2lkO1xuICAgIGxldCBwcm9taXNlUmVqZWN0OiAodmFsdWU6IFJlc3BvbnNlIHwgUHJvbWlzZUxpa2U8UmVzcG9uc2U+KSA9PiB2b2lkO1xuICAgIGNvbnN0IHdyYXBwZXJQcm9taXNlID0gbmV3IFByb21pc2U8UmVzcG9uc2U+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHByb21pc2VSZXNvbHZlID0gcmVzb2x2ZTtcbiAgICAgIHByb21pc2VSZWplY3QgPSByZWplY3Q7XG4gICAgfSk7XG5cbiAgICBwcm9taXNlXG4gICAgICAuY2F0Y2goZXJyb3IgPT4ge1xuICAgICAgICBwcm9taXNlUmVqZWN0KGVycm9yKTtcbiAgICAgIH0pXG4gICAgICAudGhlbihcbiAgICAgICAgKHJlc3VsdDogYW55KSA9PiB7XG4gICAgICAgICAgaWYgKCFyZXN1bHQpIHtcbiAgICAgICAgICAgIHByb21pc2VSZWplY3QocmVzdWx0KTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKHJlc3VsdC5zdGF0dXMgPT09IDQwMSAmJiAhcmVmcmVzaGVkQWNjZXNzVG9rZW4kKSB7XG4gICAgICAgICAgICBwcm9taXNlUmVqZWN0KHJlc3VsdCk7XG4gICAgICAgICAgfSBlbHNlIGlmIChyZXN1bHQuc3RhdHVzID09PSA0MDEgJiYgcmVmcmVzaGVkQWNjZXNzVG9rZW4kKSB7XG4gICAgICAgICAgICB0aGlzLnF1ZXVlLnB1c2gocmVzdWx0KTtcbiAgICAgICAgICAgIGlmICghdGhpcy5pc1JlZnJlc2hpbmdUb2tlbikge1xuICAgICAgICAgICAgICB0aGlzLmlzUmVmcmVzaGluZ1Rva2VuID0gdHJ1ZTtcbiAgICAgICAgICAgICAgdGhpcy5yZWZyZXNoUmVxdWlyZWRTdWJqZWN0Lm5leHQoKTtcbiAgICAgICAgICAgICAgcmVmcmVzaGVkQWNjZXNzVG9rZW4kLnBpcGUodGFrZSgxKSkuc3Vic2NyaWJlKHRva2VuID0+IHtcbiAgICAgICAgICAgICAgICB0aGlzLmlzUmVmcmVzaGluZ1Rva2VuID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBzaW5nbGVSZXN1bHQgb2YgdGhpcy5xdWV1ZSkge1xuICAgICAgICAgICAgICAgICAgZmV0Y2goc2luZ2xlUmVzdWx0LnVybCwge1xuICAgICAgICAgICAgICAgICAgICBzaWduYWwsXG4gICAgICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCxcbiAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC50aGVuKFxuICAgICAgICAgICAgICAgICAgICAgIHJlc3BvbnNlID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb21pc2VSZXNvbHZlKHJlc3BvbnNlKTtcbiAgICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICAgIGVycm9yID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHByb21pc2VSZWplY3QoZXJyb3IpO1xuICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICAgICAgICAuY2F0Y2goZXJyb3IgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKGVycm9yKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHRoaXMucXVldWUgPSBbXTtcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIGlmIChyZXN1bHQuc3RhdHVzICE9PSAyMDApIHtcbiAgICAgICAgICAgIHByb21pc2VSZWplY3QocmVzdWx0KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcHJvbWlzZVJlc29sdmUocmVzdWx0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIGVycm9yID0+IHtcbiAgICAgICAgICBwcm9taXNlUmVzb2x2ZShlcnJvcik7XG4gICAgICAgIH1cbiAgICAgICk7XG5cbiAgICByZXR1cm4gd3JhcHBlclByb21pc2U7XG4gIH1cbn1cbiJdfQ==