/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/hover" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-hover.d.ts.map