import { createComponent } from '@angular/core';

// Converts hex string to byte-array
function hexToByte(hex) {
    if (!hex) {
        throw new Error('hexToByte: hex is undefined');
    }
    const key = '0123456789abcdef';
    const newBytes = [];
    let currentChar = 0;
    let currentByte = 0;
    for (let i = 0; i < hex.length; i++) {
        // Go over two 4-bit hex chars to convert into one 8-bit byte
        currentChar = key.indexOf(hex[i]);
        if (i % 2 === 0) {
            // First hex char
            currentByte = currentChar << 4; // Get 4-bits from first hex char
        }
        if (i % 2 === 1) {
            // Second hex char
            currentByte += currentChar; // Concat 4-bits from second hex char
            newBytes.push(currentByte); // Add byte
        }
    }
    return new Uint8Array(newBytes);
}
function byteToHex(byteArray) {
    return Array.from(byteArray, (byte) => {
        return ('0' + (byte & 0xff).toString(16)).slice(-2);
    }).join('');
}

function GUID(length) {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'
        .replace(/[xy]/g, function (c) {
        const r = (Math.random() * 16) | 0, v = c == 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
    })
        .substring(0, length ? length : 36);
}

class ComponentCreator {
    constructor() { }
    static createComponent(options) {
        let componentRef;
        if ('viewContainerRef' in options) {
            componentRef = options.viewContainerRef.createComponent(options.component, options.createComponentOptions ?? {});
        }
        else {
            componentRef = createComponent(options.component, options.createComponentOptions);
        }
        for (const input in options.inputs) {
            componentRef.instance[input] = options.inputs[input];
        }
        if (!('viewContainerRef' in options)) {
            options.parentElement.appendChild(componentRef.location.nativeElement);
            options.appRef.attachView(componentRef.hostView);
        }
        return componentRef;
    }
}

const BASE64_MARKER = ';base64,';
function base64ToByteArray(dataURI) {
    const base64Index = dataURI.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
    const base64 = dataURI.substring(base64Index);
    const raw = window.atob(base64);
    const rawLength = raw.length;
    const array = new Uint8Array(new ArrayBuffer(rawLength));
    for (let i = 0; i < rawLength; i++) {
        array[i] = raw.charCodeAt(i);
    }
    return array;
}

function IsTabletOrMobile() {
    return /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
}

function GetUrlWithQueryParams(baseUrl, params) {
    const urlParams = new URLSearchParams();
    const addParam = (key, value) => {
        if (Array.isArray(value)) {
            value.forEach(item => urlParams.append(key, item));
        }
        else {
            urlParams.append(key, value);
        }
    };
    Object.keys(params).forEach(key => {
        addParam(key, params[key]);
    });
    return `${baseUrl}?${urlParams.toString()}`;
}

/**
 * Generated bundle index. Do not edit.
 */

export { ComponentCreator, GUID, GetUrlWithQueryParams, IsTabletOrMobile, base64ToByteArray, byteToHex, hexToByte };
//# sourceMappingURL=orbital-ui-helpers.mjs.map
