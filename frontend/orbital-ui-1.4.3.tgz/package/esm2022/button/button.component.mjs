import { ChangeDetectionStrategy, Component, EventEmitter, Inject, Input, Output, ViewChild, } from '@angular/core';
import { OuiIconComponent } from 'orbital-ui/icon';
import { CommonModule, DOCUMENT } from '@angular/common';
import { OuiSpinnerComponent } from 'orbital-ui/spinner';
import { OuiRippleDirective } from 'orbital-ui/ripple';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
/**
 * A component that can be used to add simple buttons. The buttons are configurable by passing in a variant. You can also
 * add an icon to the button, and to show a loading-spinner in case some asynchronous operation is in progress and you want to show it.
 *
 * Example use:
 *
 * <oui-button variant="primary" (onClick)="onButtonClick($event)">Click me!</oui-button>
 *
 */
export class OuiButtonComponent {
    renderer;
    document;
    destroyRef;
    cdr;
    button;
    set options(options) {
        const spinnerOptions = options?.spinnerOptions ?? this.getSpinnerOptions(options);
        this.#combinedOptions = {
            ...this.#defaultOptions,
            ...{ spinnerOptions: spinnerOptions },
            ...options,
        };
        if (this.isLoadingSubscription) {
            this.isLoadingSubscription.unsubscribe();
        }
        this.subscribeToDisabledObservable();
    }
    get options() {
        return this.#combinedOptions;
    }
    /**
     *   Event emitted on buttons click. Usually you want to tie a function to this event.
     */
    // eslint-disable-next-line @angular-eslint/no-output-on-prefix
    onClick = new EventEmitter();
    innerContainerRef;
    #defaultOptions = {
        variant: 'primary',
        disabled: false,
        isLoading: false,
        isLoading$: undefined,
        submitOnEnter: false,
        type: 'button',
        spinnerOptions: {
            size: '15px',
            color: 'color-primary',
        },
    };
    #combinedOptions = {
        variant: 'primary',
        disabled: false,
        isLoading: false,
        isLoading$: undefined,
        type: 'submit',
        submitOnEnter: false,
        spinnerOptions: {
            size: '15px',
            color: 'color-primary',
        },
    };
    isLoadingSubscription;
    isInitialized = false;
    unlistener;
    constructor(renderer, document, destroyRef, cdr) {
        this.renderer = renderer;
        this.document = document;
        this.destroyRef = destroyRef;
        this.cdr = cdr;
    }
    ngAfterViewInit() {
        if (this.options.submitOnEnter) {
            this.unlistener = this.renderer.listen(this.document, 'keyup', (event) => {
                if (event.key === 'Enter') {
                    this.emitClick(event);
                }
            });
        }
        setTimeout(() => {
            this.isInitialized = true;
            this.cdr.detectChanges();
        }, 300);
    }
    onEnterClick(event) {
        if (event.key === 'Enter') {
            this.emitClick(event);
        }
    }
    emitClick(event) {
        if (this.options.isLoading$) {
            this.options.isLoading = true;
            this.cdr.detectChanges();
        }
        this.onClick.emit(event);
    }
    ngOnDestroy() {
        if (this.options.submitOnEnter) {
            this.unlistener();
        }
    }
    subscribeToDisabledObservable() {
        if (this.options.isLoading$) {
            this.isLoadingSubscription = this.options.isLoading$
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe(() => {
                this.options.isLoading = false;
                this.cdr.detectChanges();
            });
        }
    }
    getSpinnerOptions(options) {
        const variant = options.variant ?? 'primary';
        return {
            color: `color-${variant}-text`,
            size: '15px',
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiButtonComponent, deps: [{ token: i0.Renderer2 }, { token: DOCUMENT }, { token: i0.DestroyRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiButtonComponent, isStandalone: true, selector: "oui-button", inputs: { options: "options" }, outputs: { onClick: "onClick" }, viewQueries: [{ propertyName: "button", first: true, predicate: ["button"], descendants: true }, { propertyName: "innerContainerRef", first: true, predicate: ["innerContainer"], descendants: true }], ngImport: i0, template: "<button\n  #button\n  [type]=\"options.type\"\n  class=\"oui-button {{options.variant}} {{isInitialized ? 'initialized' : ''}}\"\n  [ngClass]=\"{ disabled: options.isLoading || options.disabled }\"\n  (click)=\"emitClick($event)\"\n  ouiRipple\n  >\n  <div class=\"oui-button-inner-container\" #innerContainer>\n    @if (!options.isLoading) {\n      <ng-content></ng-content>\n    }\n    @if (options.isLoading) {\n      <oui-spinner [size]=\"options.spinnerOptions.size\" [color]=\"options.spinnerOptions.color\"></oui-spinner>\n    }\n  </div>\n</button>\n", styles: [":host{position:relative;display:flex;flex:1 0 auto;height:3.5rem}:host button{background:none;color:inherit;border:none;padding:0;font:inherit;cursor:pointer;outline:inherit}:host *{transition:none}:host .oui-button{position:relative;display:flex;justify-content:center;align-items:center;flex:1;border-width:var(--oui-button-border-width);border-style:var(--oui-button-border-style);border-color:var(--oui-button-border-color);border-radius:var(--border-radius-default);background-color:var(--oui-button-background-color);box-shadow:var(--oui-button-box-shadow);color:var(--oui-button-text-color);cursor:pointer}:host .oui-button:hover{background-color:var(--oui-button-background-color-hover)}:host .oui-button .oui-button-inner-container{flex:1 0 auto;width:100%;padding:4px 12px;display:flex;justify-content:center;align-items:center}:host .oui-button.disabled{opacity:.7;pointer-events:none;cursor:default}:host .oui-button.initialized{transition:background-color .3s}:host .oui-button.initialized *{transition:background-color .3s}:host .oui-button.secondary{background-color:var(--color-secondary);color:var(--color-secondary-text);border:1px solid var(--color-secondary-dark)}:host .oui-button.secondary:hover{background-color:var(--color-secondary-hover)}:host .oui-button.text{background-color:transparent;border-color:transparent;box-shadow:none;color:var(--oui-button-text-color)}:host .oui-button.text:hover{background-color:#0000000d}:host .oui-button.dark{background-color:var(--color-dark);color:var(--text-light);border:1px solid var(--color-dark);display:flex}:host .oui-button.dark:hover{background-color:var(--color-dark-hover)}:host .oui-button.custom{background-color:var(--oui-button-background-color);color:var(--oui-button-text-color);border:var(--oui-button-border-width) var(--oui-button-border-style) var(--oui-button-border-color);display:flex}:host .oui-button.custom:hover{background-color:var(--oui-button-background-color-hover)}:host .oui-button.light{background-color:var(--color-light);color:var(--text-dark);border:1px solid var(--text-dark);display:flex}:host .oui-button.light:hover{background-color:var(--color-light-hover)}:host .oui-button.success{background-color:var(--color-success);color:var(--color-success-text);border:1px solid var(--color-success);display:flex}:host .oui-button.success:hover{background-color:var(--color-success-hover)}:host .oui-button.warning{background-color:var(--color-warning);color:var(--color-warning-text);border:1px solid var(--color-warning);display:flex}:host .oui-button.warning:hover{background-color:var(--color-warning-hover)}:host .oui-button.info{background-color:var(--color-info);color:var(--color-info-text);border:1px solid var(--color-info);display:flex}:host .oui-button.info:hover{background-color:var(--color-info-hover)}:host .oui-button.error{background-color:var(--color-danger);color:var(--color-danger-text);border:1px solid var(--color-danger);display:flex}:host .oui-button.error:hover{background-color:var(--color-danger-hover)}:host .oui-button.muted{background-color:var(--color-muted);color:var(--color-muted-text);border:1px solid var(--color-muted);display:flex}:host .oui-button.muted:hover{background-color:var(--color-muted-hover)}:host .oui-button.primary{background-color:var(--color-primary);border:1px solid var(--color-primary);color:var(--color-primary-text);display:flex}:host .oui-button.primary:hover{background-color:var(--color-primary-hover);border-color:var(--color-primary-hover)}\n"], dependencies: [{ kind: "component", type: OuiSpinnerComponent, selector: "oui-spinner", inputs: ["color", "size", "type"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: OuiRippleDirective, selector: "[ouiRipple]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-button', standalone: true, imports: [
                        OuiSpinnerComponent,
                        OuiIconComponent,
                        CommonModule,
                        OuiRippleDirective,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<button\n  #button\n  [type]=\"options.type\"\n  class=\"oui-button {{options.variant}} {{isInitialized ? 'initialized' : ''}}\"\n  [ngClass]=\"{ disabled: options.isLoading || options.disabled }\"\n  (click)=\"emitClick($event)\"\n  ouiRipple\n  >\n  <div class=\"oui-button-inner-container\" #innerContainer>\n    @if (!options.isLoading) {\n      <ng-content></ng-content>\n    }\n    @if (options.isLoading) {\n      <oui-spinner [size]=\"options.spinnerOptions.size\" [color]=\"options.spinnerOptions.color\"></oui-spinner>\n    }\n  </div>\n</button>\n", styles: [":host{position:relative;display:flex;flex:1 0 auto;height:3.5rem}:host button{background:none;color:inherit;border:none;padding:0;font:inherit;cursor:pointer;outline:inherit}:host *{transition:none}:host .oui-button{position:relative;display:flex;justify-content:center;align-items:center;flex:1;border-width:var(--oui-button-border-width);border-style:var(--oui-button-border-style);border-color:var(--oui-button-border-color);border-radius:var(--border-radius-default);background-color:var(--oui-button-background-color);box-shadow:var(--oui-button-box-shadow);color:var(--oui-button-text-color);cursor:pointer}:host .oui-button:hover{background-color:var(--oui-button-background-color-hover)}:host .oui-button .oui-button-inner-container{flex:1 0 auto;width:100%;padding:4px 12px;display:flex;justify-content:center;align-items:center}:host .oui-button.disabled{opacity:.7;pointer-events:none;cursor:default}:host .oui-button.initialized{transition:background-color .3s}:host .oui-button.initialized *{transition:background-color .3s}:host .oui-button.secondary{background-color:var(--color-secondary);color:var(--color-secondary-text);border:1px solid var(--color-secondary-dark)}:host .oui-button.secondary:hover{background-color:var(--color-secondary-hover)}:host .oui-button.text{background-color:transparent;border-color:transparent;box-shadow:none;color:var(--oui-button-text-color)}:host .oui-button.text:hover{background-color:#0000000d}:host .oui-button.dark{background-color:var(--color-dark);color:var(--text-light);border:1px solid var(--color-dark);display:flex}:host .oui-button.dark:hover{background-color:var(--color-dark-hover)}:host .oui-button.custom{background-color:var(--oui-button-background-color);color:var(--oui-button-text-color);border:var(--oui-button-border-width) var(--oui-button-border-style) var(--oui-button-border-color);display:flex}:host .oui-button.custom:hover{background-color:var(--oui-button-background-color-hover)}:host .oui-button.light{background-color:var(--color-light);color:var(--text-dark);border:1px solid var(--text-dark);display:flex}:host .oui-button.light:hover{background-color:var(--color-light-hover)}:host .oui-button.success{background-color:var(--color-success);color:var(--color-success-text);border:1px solid var(--color-success);display:flex}:host .oui-button.success:hover{background-color:var(--color-success-hover)}:host .oui-button.warning{background-color:var(--color-warning);color:var(--color-warning-text);border:1px solid var(--color-warning);display:flex}:host .oui-button.warning:hover{background-color:var(--color-warning-hover)}:host .oui-button.info{background-color:var(--color-info);color:var(--color-info-text);border:1px solid var(--color-info);display:flex}:host .oui-button.info:hover{background-color:var(--color-info-hover)}:host .oui-button.error{background-color:var(--color-danger);color:var(--color-danger-text);border:1px solid var(--color-danger);display:flex}:host .oui-button.error:hover{background-color:var(--color-danger-hover)}:host .oui-button.muted{background-color:var(--color-muted);color:var(--color-muted-text);border:1px solid var(--color-muted);display:flex}:host .oui-button.muted:hover{background-color:var(--color-muted-hover)}:host .oui-button.primary{background-color:var(--color-primary);border:1px solid var(--color-primary);color:var(--color-primary-text);display:flex}:host .oui-button.primary:hover{background-color:var(--color-primary-hover);border-color:var(--color-primary-hover)}\n"] }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.DestroyRef }, { type: i0.ChangeDetectorRef }], propDecorators: { button: [{
                type: ViewChild,
                args: ['button']
            }], options: [{
                type: Input
            }], 
        // eslint-disable-next-line @angular-eslint/no-output-on-prefix
        onClick: [{
                type: Output
            }], innerContainerRef: [{
                type: ViewChild,
                args: ['innerContainer']
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYnV0dG9uLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvYnV0dG9uL2J1dHRvbi5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL2J1dHRvbi9idXR0b24uY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUVMLHVCQUF1QixFQUV2QixTQUFTLEVBR1QsWUFBWSxFQUNaLE1BQU0sRUFDTixLQUFLLEVBRUwsTUFBTSxFQUVOLFNBQVMsR0FDVixNQUFNLGVBQWUsQ0FBQztBQUN2QixPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUNuRCxPQUFPLEVBQUUsWUFBWSxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3pELE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ3pELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBRXZELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDOzs7QUEyQ2hFOzs7Ozs7OztHQVFHO0FBY0gsTUFBTSxPQUFPLGtCQUFrQjtJQTJEbkI7SUFDa0I7SUFDbEI7SUFDQTtJQTdEa0IsTUFBTSxDQUFhO0lBRS9DLElBQWEsT0FBTyxDQUFDLE9BQTBCO1FBQzdDLE1BQU0sY0FBYyxHQUNsQixPQUFPLEVBQUUsY0FBYyxJQUFJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM3RCxJQUFJLENBQUMsZ0JBQWdCLEdBQUc7WUFDdEIsR0FBRyxJQUFJLENBQUMsZUFBZTtZQUN2QixHQUFHLEVBQUUsY0FBYyxFQUFFLGNBQWMsRUFBRTtZQUNyQyxHQUFHLE9BQU87U0FDWCxDQUFDO1FBQ0YsSUFBSSxJQUFJLENBQUMscUJBQXFCLEVBQUUsQ0FBQztZQUMvQixJQUFJLENBQUMscUJBQXFCLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDM0MsQ0FBQztRQUNELElBQUksQ0FBQyw2QkFBNkIsRUFBRSxDQUFDO0lBQ3ZDLENBQUM7SUFFRCxJQUFJLE9BQU87UUFDVCxPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztJQUMvQixDQUFDO0lBRUQ7O09BRUc7SUFFSCwrREFBK0Q7SUFDL0QsT0FBTyxHQUFHLElBQUksWUFBWSxFQUFPLENBQUM7SUFFTCxpQkFBaUIsQ0FBYTtJQUUzRCxlQUFlLEdBQThCO1FBQzNDLE9BQU8sRUFBRSxTQUFTO1FBQ2xCLFFBQVEsRUFBRSxLQUFLO1FBQ2YsU0FBUyxFQUFFLEtBQUs7UUFDaEIsVUFBVSxFQUFFLFNBQVM7UUFDckIsYUFBYSxFQUFFLEtBQUs7UUFDcEIsSUFBSSxFQUFFLFFBQVE7UUFDZCxjQUFjLEVBQUU7WUFDZCxJQUFJLEVBQUUsTUFBTTtZQUNaLEtBQUssRUFBRSxlQUFlO1NBQ3ZCO0tBQ0YsQ0FBQztJQUNGLGdCQUFnQixHQUE4QjtRQUM1QyxPQUFPLEVBQUUsU0FBUztRQUNsQixRQUFRLEVBQUUsS0FBSztRQUNmLFNBQVMsRUFBRSxLQUFLO1FBQ2hCLFVBQVUsRUFBRSxTQUFTO1FBQ3JCLElBQUksRUFBRSxRQUFRO1FBQ2QsYUFBYSxFQUFFLEtBQUs7UUFDcEIsY0FBYyxFQUFFO1lBQ2QsSUFBSSxFQUFFLE1BQU07WUFDWixLQUFLLEVBQUUsZUFBZTtTQUN2QjtLQUNGLENBQUM7SUFDTSxxQkFBcUIsQ0FBMkI7SUFDakQsYUFBYSxHQUFHLEtBQUssQ0FBQztJQUNyQixVQUFVLENBQWE7SUFFL0IsWUFDVSxRQUFtQixFQUNELFFBQWtCLEVBQ3BDLFVBQXNCLEVBQ3RCLEdBQXNCO1FBSHRCLGFBQVEsR0FBUixRQUFRLENBQVc7UUFDRCxhQUFRLEdBQVIsUUFBUSxDQUFVO1FBQ3BDLGVBQVUsR0FBVixVQUFVLENBQVk7UUFDdEIsUUFBRyxHQUFILEdBQUcsQ0FBbUI7SUFDN0IsQ0FBQztJQUVHLGVBQWU7UUFDcEIsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQy9CLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQ3BDLElBQUksQ0FBQyxRQUFRLEVBQ2IsT0FBTyxFQUNQLENBQUMsS0FBVSxFQUFFLEVBQUU7Z0JBQ2IsSUFBSSxLQUFLLENBQUMsR0FBRyxLQUFLLE9BQU8sRUFBRSxDQUFDO29CQUMxQixJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUN4QixDQUFDO1lBQ0gsQ0FBQyxDQUNGLENBQUM7UUFDSixDQUFDO1FBQ0QsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDO1lBQzFCLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDM0IsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0lBQ1YsQ0FBQztJQUVPLFlBQVksQ0FBQyxLQUFvQjtRQUN2QyxJQUFJLEtBQUssQ0FBQyxHQUFHLEtBQUssT0FBTyxFQUFFLENBQUM7WUFDMUIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN4QixDQUFDO0lBQ0gsQ0FBQztJQUVNLFNBQVMsQ0FBQyxLQUFVO1FBQ3pCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUM1QixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7WUFDOUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUMzQixDQUFDO1FBQ0QsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDM0IsQ0FBQztJQUVNLFdBQVc7UUFDaEIsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQy9CLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNwQixDQUFDO0lBQ0gsQ0FBQztJQUVPLDZCQUE2QjtRQUNuQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDNUIsSUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVTtpQkFDakQsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztpQkFDekMsU0FBUyxDQUFDLEdBQUcsRUFBRTtnQkFDZCxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUM7Z0JBQy9CLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDM0IsQ0FBQyxDQUFDLENBQUM7UUFDUCxDQUFDO0lBQ0gsQ0FBQztJQUVPLGlCQUFpQixDQUFDLE9BQTBCO1FBQ2xELE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLElBQUksU0FBUyxDQUFDO1FBQzdDLE9BQU87WUFDTCxLQUFLLEVBQUUsU0FBUyxPQUFPLE9BQU87WUFDOUIsSUFBSSxFQUFFLE1BQU07U0FDYixDQUFDO0lBQ0osQ0FBQzt1R0F4SFUsa0JBQWtCLDJDQTREbkIsUUFBUTsyRkE1RFAsa0JBQWtCLCtVQ3JGL0IsZ2pCQWlCQSw0K0dENkRJLG1CQUFtQiwwRkFFbkIsWUFBWSw2SEFDWixrQkFBa0I7OzJGQUlULGtCQUFrQjtrQkFiOUIsU0FBUzsrQkFDRSxZQUFZLGNBR1YsSUFBSSxXQUNQO3dCQUNQLG1CQUFtQjt3QkFDbkIsZ0JBQWdCO3dCQUNoQixZQUFZO3dCQUNaLGtCQUFrQjtxQkFDbkIsbUJBQ2dCLHVCQUF1QixDQUFDLE1BQU07OzBCQThENUMsTUFBTTsyQkFBQyxRQUFRO2tHQTNEVSxNQUFNO3NCQUFqQyxTQUFTO3VCQUFDLFFBQVE7Z0JBRU4sT0FBTztzQkFBbkIsS0FBSzs7UUFzQk4sK0RBQStEO1FBQy9ELE9BQU87c0JBRk4sTUFBTTtnQkFJc0IsaUJBQWlCO3NCQUE3QyxTQUFTO3VCQUFDLGdCQUFnQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFmdGVyVmlld0luaXQsXG4gIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LFxuICBDaGFuZ2VEZXRlY3RvclJlZixcbiAgQ29tcG9uZW50LFxuICBEZXN0cm95UmVmLFxuICBFbGVtZW50UmVmLFxuICBFdmVudEVtaXR0ZXIsXG4gIEluamVjdCxcbiAgSW5wdXQsXG4gIE9uRGVzdHJveSxcbiAgT3V0cHV0LFxuICBSZW5kZXJlcjIsXG4gIFZpZXdDaGlsZCxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPdWlJY29uQ29tcG9uZW50IH0gZnJvbSAnb3JiaXRhbC11aS9pY29uJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSwgRE9DVU1FTlQgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgT3VpU3Bpbm5lckNvbXBvbmVudCB9IGZyb20gJ29yYml0YWwtdWkvc3Bpbm5lcic7XG5pbXBvcnQgeyBPdWlSaXBwbGVEaXJlY3RpdmUgfSBmcm9tICdvcmJpdGFsLXVpL3JpcHBsZSc7XG5pbXBvcnQgeyBPYnNlcnZhYmxlLCBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcbmltcG9ydCB7IHRha2VVbnRpbERlc3Ryb3llZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUvcnhqcy1pbnRlcm9wJztcblxuZXhwb3J0IHR5cGUgT3VpQnV0dG9uVmFyaWFudCA9XG4gIHwgJ3ByaW1hcnknXG4gIHwgJ3NlY29uZGFyeSdcbiAgfCAnd2FybmluZydcbiAgfCAnaW5mbydcbiAgfCAndGVydGlhcnknXG4gIHwgJ2xpZ2h0J1xuICB8ICdkYXJrJ1xuICB8ICdlcnJvcidcbiAgfCAnc3VjY2VzcydcbiAgfCAnbXV0ZWQnXG4gIHwgJ3RyYW5zcGFyZW50J1xuICB8ICd0ZXh0J1xuICB8ICdjdXN0b20nO1xuXG5leHBvcnQgaW50ZXJmYWNlIElPdWlCdXR0b25PcHRpb25zIGV4dGVuZHMgUGFydGlhbDxJT3VpQnV0dG9uQ29tYmluZWRPcHRpb25zPiB7fVxuXG4vKipcbiAqIE9wdGlvbnMgdG8gcGFzcyB0byB0aGUgYnV0dG9uXG4gKiBAcHJvcGVydHkge2Jvb2xlYW59IGRpc2FibGVkIFdoZXRoZXIgdGhlIGJ1dHRvbiBzaG91bGQgYmUgZGlzYWJsZWRcbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbn0gaXNMb2FkaW5nIFdoZXRoZXIgdGhlIGJ1dHRvbiBzaG91bGQgYmUgaW4gYSBsb2FkaW5nIHN0YXRlXG4gKiBAcHJvcGVydHkge09ic2VydmFibGU8YW55Pn0gaXNMb2FkaW5nJCBJZiB0aGlzIG9wdGlvbiBpcyBwYXNzZWQsIGJ1dHRvbiBhdXRvbWF0aWNhbGx5IGdvZXMgaW50byBhIGxvYWRpbmcgc3RhdGUgd2hlbiBjbGlja2luZyBvbiBpdCxcbiAqIGFuZCBvbmx5IGV4aXRzIG9uY2UgdGhlIG9ic2VydmFibGUgZW1pdHMgYSB2YWx1ZS4gVXNlZnVsIGZvciBleGFtcGxlIHdoZW4gYSBidXR0b24tY2xpY2sgZG9lcyBhbiBBUEktY2FsbCwgZHVyaW5nXG4gKiB3aGljaCB0aGUgYnV0dG9uIG5lZWRzIHRvIGJlIGRpc2FibGVkLlxuICogQHByb3BlcnR5IHtPdWlCdXR0b25WYXJpYW50fSB2YXJpYW50IFRoZSB2YXJpYW50IG9mIHRoZSBidXR0b24uIEZvciBleGFtcGxlICdwcmltYXJ5JyBvciAnc2Vjb25kYXJ5JyBvciAnc3VjY2Vzcy4gV2lsbCBjaGFuZ2UgdGhlIHZpc3VhbCBsb29rIG9mIHRoZSBidXR0b24gYWNjb3JkaW5nIHRvIGRlZmluZWRcbiAqIGNzcy12YXJpYWJsZXNcbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbn0gc3VibWl0T25FbnRlciBXaGV0aGVyIG9yIG5vdCBidXR0b24gc2hvdWxkIGJlIGNsaWNrZWQgd2hlbiBoaXR0aW5nICdlbnRlcicuXG4gKiBAcHJvcGVydHkge29iamVjdH0gc3Bpbm5lck9wdGlvbnMgT3B0aW9ucyB0byBwYXNzIHRvIHRoZSBzcGlubmVyXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgSU91aUJ1dHRvbkNvbWJpbmVkT3B0aW9ucyB7XG4gIGRpc2FibGVkOiBib29sZWFuO1xuICBpc0xvYWRpbmc6IGJvb2xlYW47XG4gIGlzTG9hZGluZyQ6IE9ic2VydmFibGU8YW55PiB8IHVuZGVmaW5lZDtcbiAgdmFyaWFudDogT3VpQnV0dG9uVmFyaWFudDtcbiAgdHlwZTogJ2J1dHRvbicgfCAnc3VibWl0JyB8ICdyZXNldCc7XG4gIHN1Ym1pdE9uRW50ZXI6IGJvb2xlYW47XG4gIHNwaW5uZXJPcHRpb25zOiB7XG4gICAgc2l6ZTogc3RyaW5nO1xuICAgIGNvbG9yOiBzdHJpbmc7XG4gIH07XG59XG4vKipcbiAqIEEgY29tcG9uZW50IHRoYXQgY2FuIGJlIHVzZWQgdG8gYWRkIHNpbXBsZSBidXR0b25zLiBUaGUgYnV0dG9ucyBhcmUgY29uZmlndXJhYmxlIGJ5IHBhc3NpbmcgaW4gYSB2YXJpYW50LiBZb3UgY2FuIGFsc29cbiAqIGFkZCBhbiBpY29uIHRvIHRoZSBidXR0b24sIGFuZCB0byBzaG93IGEgbG9hZGluZy1zcGlubmVyIGluIGNhc2Ugc29tZSBhc3luY2hyb25vdXMgb3BlcmF0aW9uIGlzIGluIHByb2dyZXNzIGFuZCB5b3Ugd2FudCB0byBzaG93IGl0LlxuICpcbiAqIEV4YW1wbGUgdXNlOlxuICpcbiAqIDxvdWktYnV0dG9uIHZhcmlhbnQ9XCJwcmltYXJ5XCIgKG9uQ2xpY2spPVwib25CdXR0b25DbGljaygkZXZlbnQpXCI+Q2xpY2sgbWUhPC9vdWktYnV0dG9uPlxuICpcbiAqL1xuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLWJ1dHRvbicsXG4gIHRlbXBsYXRlVXJsOiAnLi9idXR0b24uY29tcG9uZW50Lmh0bWwnLFxuICBzdHlsZVVybHM6IFsnLi9idXR0b24uY29tcG9uZW50LnNjc3MnXSxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW1xuICAgIE91aVNwaW5uZXJDb21wb25lbnQsXG4gICAgT3VpSWNvbkNvbXBvbmVudCxcbiAgICBDb21tb25Nb2R1bGUsXG4gICAgT3VpUmlwcGxlRGlyZWN0aXZlLFxuICBdLFxuICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcbn0pXG5leHBvcnQgY2xhc3MgT3VpQnV0dG9uQ29tcG9uZW50IGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95IHtcbiAgQFZpZXdDaGlsZCgnYnV0dG9uJykgcHVibGljIGJ1dHRvbjogRWxlbWVudFJlZjtcblxuICBASW5wdXQoKSBzZXQgb3B0aW9ucyhvcHRpb25zOiBJT3VpQnV0dG9uT3B0aW9ucykge1xuICAgIGNvbnN0IHNwaW5uZXJPcHRpb25zID1cbiAgICAgIG9wdGlvbnM/LnNwaW5uZXJPcHRpb25zID8/IHRoaXMuZ2V0U3Bpbm5lck9wdGlvbnMob3B0aW9ucyk7XG4gICAgdGhpcy4jY29tYmluZWRPcHRpb25zID0ge1xuICAgICAgLi4udGhpcy4jZGVmYXVsdE9wdGlvbnMsXG4gICAgICAuLi57IHNwaW5uZXJPcHRpb25zOiBzcGlubmVyT3B0aW9ucyB9LFxuICAgICAgLi4ub3B0aW9ucyxcbiAgICB9O1xuICAgIGlmICh0aGlzLmlzTG9hZGluZ1N1YnNjcmlwdGlvbikge1xuICAgICAgdGhpcy5pc0xvYWRpbmdTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcbiAgICB9XG4gICAgdGhpcy5zdWJzY3JpYmVUb0Rpc2FibGVkT2JzZXJ2YWJsZSgpO1xuICB9XG5cbiAgZ2V0IG9wdGlvbnMoKTogSU91aUJ1dHRvbkNvbWJpbmVkT3B0aW9ucyB7XG4gICAgcmV0dXJuIHRoaXMuI2NvbWJpbmVkT3B0aW9ucztcbiAgfVxuXG4gIC8qKlxuICAgKiAgIEV2ZW50IGVtaXR0ZWQgb24gYnV0dG9ucyBjbGljay4gVXN1YWxseSB5b3Ugd2FudCB0byB0aWUgYSBmdW5jdGlvbiB0byB0aGlzIGV2ZW50LlxuICAgKi9cbiAgQE91dHB1dCgpXG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAYW5ndWxhci1lc2xpbnQvbm8tb3V0cHV0LW9uLXByZWZpeFxuICBvbkNsaWNrID0gbmV3IEV2ZW50RW1pdHRlcjxhbnk+KCk7XG5cbiAgQFZpZXdDaGlsZCgnaW5uZXJDb250YWluZXInKSBpbm5lckNvbnRhaW5lclJlZjogRWxlbWVudFJlZjtcblxuICAjZGVmYXVsdE9wdGlvbnM6IElPdWlCdXR0b25Db21iaW5lZE9wdGlvbnMgPSB7XG4gICAgdmFyaWFudDogJ3ByaW1hcnknLFxuICAgIGRpc2FibGVkOiBmYWxzZSxcbiAgICBpc0xvYWRpbmc6IGZhbHNlLFxuICAgIGlzTG9hZGluZyQ6IHVuZGVmaW5lZCxcbiAgICBzdWJtaXRPbkVudGVyOiBmYWxzZSxcbiAgICB0eXBlOiAnYnV0dG9uJyxcbiAgICBzcGlubmVyT3B0aW9uczoge1xuICAgICAgc2l6ZTogJzE1cHgnLFxuICAgICAgY29sb3I6ICdjb2xvci1wcmltYXJ5JyxcbiAgICB9LFxuICB9O1xuICAjY29tYmluZWRPcHRpb25zOiBJT3VpQnV0dG9uQ29tYmluZWRPcHRpb25zID0ge1xuICAgIHZhcmlhbnQ6ICdwcmltYXJ5JyxcbiAgICBkaXNhYmxlZDogZmFsc2UsXG4gICAgaXNMb2FkaW5nOiBmYWxzZSxcbiAgICBpc0xvYWRpbmckOiB1bmRlZmluZWQsXG4gICAgdHlwZTogJ3N1Ym1pdCcsXG4gICAgc3VibWl0T25FbnRlcjogZmFsc2UsXG4gICAgc3Bpbm5lck9wdGlvbnM6IHtcbiAgICAgIHNpemU6ICcxNXB4JyxcbiAgICAgIGNvbG9yOiAnY29sb3ItcHJpbWFyeScsXG4gICAgfSxcbiAgfTtcbiAgcHJpdmF0ZSBpc0xvYWRpbmdTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbiB8IHVuZGVmaW5lZDtcbiAgcHVibGljIGlzSW5pdGlhbGl6ZWQgPSBmYWxzZTtcbiAgcHJpdmF0ZSB1bmxpc3RlbmVyOiAoKSA9PiB2b2lkO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgcmVuZGVyZXI6IFJlbmRlcmVyMixcbiAgICBASW5qZWN0KERPQ1VNRU5UKSBwcml2YXRlIGRvY3VtZW50OiBEb2N1bWVudCxcbiAgICBwcml2YXRlIGRlc3Ryb3lSZWY6IERlc3Ryb3lSZWYsXG4gICAgcHJpdmF0ZSBjZHI6IENoYW5nZURldGVjdG9yUmVmXG4gICkge31cblxuICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCkge1xuICAgIGlmICh0aGlzLm9wdGlvbnMuc3VibWl0T25FbnRlcikge1xuICAgICAgdGhpcy51bmxpc3RlbmVyID0gdGhpcy5yZW5kZXJlci5saXN0ZW4oXG4gICAgICAgIHRoaXMuZG9jdW1lbnQsXG4gICAgICAgICdrZXl1cCcsXG4gICAgICAgIChldmVudDogYW55KSA9PiB7XG4gICAgICAgICAgaWYgKGV2ZW50LmtleSA9PT0gJ0VudGVyJykge1xuICAgICAgICAgICAgdGhpcy5lbWl0Q2xpY2soZXZlbnQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgKTtcbiAgICB9XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICB0aGlzLmlzSW5pdGlhbGl6ZWQgPSB0cnVlO1xuICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xuICAgIH0sIDMwMCk7XG4gIH1cblxuICBwcml2YXRlIG9uRW50ZXJDbGljayhldmVudDogS2V5Ym9hcmRFdmVudCkge1xuICAgIGlmIChldmVudC5rZXkgPT09ICdFbnRlcicpIHtcbiAgICAgIHRoaXMuZW1pdENsaWNrKGV2ZW50KTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgZW1pdENsaWNrKGV2ZW50OiBhbnkpIHtcbiAgICBpZiAodGhpcy5vcHRpb25zLmlzTG9hZGluZyQpIHtcbiAgICAgIHRoaXMub3B0aW9ucy5pc0xvYWRpbmcgPSB0cnVlO1xuICAgICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xuICAgIH1cbiAgICB0aGlzLm9uQ2xpY2suZW1pdChldmVudCk7XG4gIH1cblxuICBwdWJsaWMgbmdPbkRlc3Ryb3koKSB7XG4gICAgaWYgKHRoaXMub3B0aW9ucy5zdWJtaXRPbkVudGVyKSB7XG4gICAgICB0aGlzLnVubGlzdGVuZXIoKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHN1YnNjcmliZVRvRGlzYWJsZWRPYnNlcnZhYmxlKCkge1xuICAgIGlmICh0aGlzLm9wdGlvbnMuaXNMb2FkaW5nJCkge1xuICAgICAgdGhpcy5pc0xvYWRpbmdTdWJzY3JpcHRpb24gPSB0aGlzLm9wdGlvbnMuaXNMb2FkaW5nJFxuICAgICAgICAucGlwZSh0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSlcbiAgICAgICAgLnN1YnNjcmliZSgoKSA9PiB7XG4gICAgICAgICAgdGhpcy5vcHRpb25zLmlzTG9hZGluZyA9IGZhbHNlO1xuICAgICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBnZXRTcGlubmVyT3B0aW9ucyhvcHRpb25zOiBJT3VpQnV0dG9uT3B0aW9ucykge1xuICAgIGNvbnN0IHZhcmlhbnQgPSBvcHRpb25zLnZhcmlhbnQgPz8gJ3ByaW1hcnknO1xuICAgIHJldHVybiB7XG4gICAgICBjb2xvcjogYGNvbG9yLSR7dmFyaWFudH0tdGV4dGAsXG4gICAgICBzaXplOiAnMTVweCcsXG4gICAgfTtcbiAgfVxufVxuIiwiPGJ1dHRvblxuICAjYnV0dG9uXG4gIFt0eXBlXT1cIm9wdGlvbnMudHlwZVwiXG4gIGNsYXNzPVwib3VpLWJ1dHRvbiB7e29wdGlvbnMudmFyaWFudH19IHt7aXNJbml0aWFsaXplZCA/ICdpbml0aWFsaXplZCcgOiAnJ319XCJcbiAgW25nQ2xhc3NdPVwieyBkaXNhYmxlZDogb3B0aW9ucy5pc0xvYWRpbmcgfHwgb3B0aW9ucy5kaXNhYmxlZCB9XCJcbiAgKGNsaWNrKT1cImVtaXRDbGljaygkZXZlbnQpXCJcbiAgb3VpUmlwcGxlXG4gID5cbiAgPGRpdiBjbGFzcz1cIm91aS1idXR0b24taW5uZXItY29udGFpbmVyXCIgI2lubmVyQ29udGFpbmVyPlxuICAgIEBpZiAoIW9wdGlvbnMuaXNMb2FkaW5nKSB7XG4gICAgICA8bmctY29udGVudD48L25nLWNvbnRlbnQ+XG4gICAgfVxuICAgIEBpZiAob3B0aW9ucy5pc0xvYWRpbmcpIHtcbiAgICAgIDxvdWktc3Bpbm5lciBbc2l6ZV09XCJvcHRpb25zLnNwaW5uZXJPcHRpb25zLnNpemVcIiBbY29sb3JdPVwib3B0aW9ucy5zcGlubmVyT3B0aW9ucy5jb2xvclwiPjwvb3VpLXNwaW5uZXI+XG4gICAgfVxuICA8L2Rpdj5cbjwvYnV0dG9uPlxuIl19