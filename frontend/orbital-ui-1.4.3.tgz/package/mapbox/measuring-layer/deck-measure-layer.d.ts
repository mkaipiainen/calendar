import { IDeckMeasureLayerOptions } from '../typings';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { EditableGeoJsonLayer } from '@nebula.gl/layers';
import * as i0 from "@angular/core";
export declare class DeckMeasureLayer extends BaseDeckLayer<any> {
    options: IDeckMeasureLayerOptions;
    constructor();
    getLayer(): EditableGeoJsonLayer;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeckMeasureLayer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeckMeasureLayer, "oui-deck-measure-layer", never, { "options": { "alias": "options"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=deck-measure-layer.d.ts.map