import { OuiPopupComponent } from 'orbital-ui/popup';
import * as i0 from "@angular/core";
export declare class OuiDefaultTooltipComponent extends OuiPopupComponent {
    content: string;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiDefaultTooltipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiDefaultTooltipComponent, "oui-default-tooltip", never, { "content": { "alias": "content"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=default-tooltip.component.d.ts.map