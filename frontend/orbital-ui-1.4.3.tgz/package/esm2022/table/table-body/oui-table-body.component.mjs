import { ChangeDetectionStrategy, Component, Input, signal, ViewChild, ViewContainerRef, } from '@angular/core';
import { NgTemplateOutlet, SlicePipe } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { OuiTableRowComponent } from '../table-row/oui-table-row.component';
import { debounce } from 'lodash-es';
import * as i0 from "@angular/core";
export class OuiTableBodyComponent {
    destroyRef;
    cdr;
    elementRef;
    renderer;
    bodyWrapper;
    rowVCR;
    tableService;
    options;
    unlisteners = [];
    throttledSetScrollTop = debounce(this.setScrollTop.bind(this), 0);
    items = signal([]);
    indexTo = signal(0);
    constructor(destroyRef, cdr, elementRef, renderer) {
        this.destroyRef = destroyRef;
        this.cdr = cdr;
        this.elementRef = elementRef;
        this.renderer = renderer;
    }
    ngAfterViewInit() {
        this.destroyRef.onDestroy(() => {
            for (const unlistener of this.unlisteners) {
                if (unlistener) {
                    unlistener();
                }
            }
        });
        const unlistener = this.renderer.listen(this.elementRef.nativeElement, 'scroll', event => {
            this.throttledSetScrollTop({
                value: event.target.scrollTop,
                stringValue: `${event.target.scrollTop}px`,
            });
        });
        this.unlisteners.push(unlistener);
        this.elementRef.nativeElement.classList.add('oui-scrollbar');
        this.elementRef.nativeElement.classList.add('scroll-y');
        this.tableService.items$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(visibleItems => {
            this.items.set([...visibleItems]);
        });
        this.tableService.indexTo$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(index => {
            this.indexTo.set(index);
        });
    }
    trackItem = (index, item) => {
        return item.item[this.options.trackBy];
    };
    setScrollTop(scrollTop) {
        this.tableService.setScrollTop(scrollTop);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTableBodyComponent, deps: [{ token: i0.DestroyRef }, { token: i0.ChangeDetectorRef }, { token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiTableBodyComponent, isStandalone: true, selector: "oui-table-body", inputs: { tableService: "tableService", options: "options" }, viewQueries: [{ propertyName: "bodyWrapper", first: true, predicate: ["bodyWrapper"], descendants: true }, { propertyName: "rowVCR", first: true, predicate: ["rowVCR"], descendants: true, read: ViewContainerRef }], ngImport: i0, template: "@if (options) {\n  <div class=\"oui-table-body\" #bodyWrapper>\n    <!--  <ng-container class=\"row-parent\" id=\"x\" #rowVCR></ng-container>-->\n    @for (item of (items() | slice: 0:indexTo()); track trackItem($index, item)) {\n      <oui-table-row [item]=\"item.item\" [options]=\"options\" [tableService]=\"tableService\"></oui-table-row>\n    }\n  </div>\n}\n", styles: [":host{flex:1;border-width:0 var(--oui-table-column-border-width-right) 0 var(--oui-table-column-border-width-left);border-style:var(--oui-table-column-border-style);border-color:var(--oui-table-column-border-color)}:host .oui-table-column-wrapper{display:flex;flex-direction:column;overflow:hidden}:host .oui-table-body{position:relative;display:flex;flex-direction:column}\n"], dependencies: [{ kind: "component", type: OuiTableRowComponent, selector: "oui-table-row", inputs: ["item", "options", "tableService"] }, { kind: "pipe", type: SlicePipe, name: "slice" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTableBodyComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-table-body', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgTemplateOutlet, OuiTableRowComponent, SlicePipe], template: "@if (options) {\n  <div class=\"oui-table-body\" #bodyWrapper>\n    <!--  <ng-container class=\"row-parent\" id=\"x\" #rowVCR></ng-container>-->\n    @for (item of (items() | slice: 0:indexTo()); track trackItem($index, item)) {\n      <oui-table-row [item]=\"item.item\" [options]=\"options\" [tableService]=\"tableService\"></oui-table-row>\n    }\n  </div>\n}\n", styles: [":host{flex:1;border-width:0 var(--oui-table-column-border-width-right) 0 var(--oui-table-column-border-width-left);border-style:var(--oui-table-column-border-style);border-color:var(--oui-table-column-border-color)}:host .oui-table-column-wrapper{display:flex;flex-direction:column;overflow:hidden}:host .oui-table-body{position:relative;display:flex;flex-direction:column}\n"] }]
        }], ctorParameters: () => [{ type: i0.DestroyRef }, { type: i0.ChangeDetectorRef }, { type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { bodyWrapper: [{
                type: ViewChild,
                args: ['bodyWrapper']
            }], rowVCR: [{
                type: ViewChild,
                args: ['rowVCR', { read: ViewContainerRef }]
            }], tableService: [{
                type: Input,
                args: [{ required: true }]
            }], options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3VpLXRhYmxlLWJvZHkuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS90YWJsZS90YWJsZS1ib2R5L291aS10YWJsZS1ib2R5LmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvdGFibGUvdGFibGUtYm9keS9vdWktdGFibGUtYm9keS5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBRUwsdUJBQXVCLEVBRXZCLFNBQVMsRUFHVCxLQUFLLEVBRUwsTUFBTSxFQUNOLFNBQVMsRUFDVCxnQkFBZ0IsR0FDakIsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLGdCQUFnQixFQUFFLFNBQVMsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBRTlELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBR2hFLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLHNDQUFzQyxDQUFDO0FBQzVFLE9BQU8sRUFBRSxRQUFRLEVBQVMsTUFBTSxXQUFXLENBQUM7O0FBVTVDLE1BQU0sT0FBTyxxQkFBcUI7SUFhdEI7SUFDQTtJQUNBO0lBQ0E7SUFmZ0IsV0FBVyxDQUFhO0lBRWxELE1BQU0sQ0FBbUI7SUFFRSxZQUFZLENBQWU7SUFDM0IsT0FBTyxDQUEyQjtJQUVyRCxXQUFXLEdBQVUsRUFBRSxDQUFDO0lBQ3hCLHFCQUFxQixHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNuRSxLQUFLLEdBQUcsTUFBTSxDQUEwQixFQUFFLENBQUMsQ0FBQztJQUM1QyxPQUFPLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQzNCLFlBQ1UsVUFBc0IsRUFDdEIsR0FBc0IsRUFDdEIsVUFBc0IsRUFDdEIsUUFBbUI7UUFIbkIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtRQUN0QixRQUFHLEdBQUgsR0FBRyxDQUFtQjtRQUN0QixlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQ3RCLGFBQVEsR0FBUixRQUFRLENBQVc7SUFDMUIsQ0FBQztJQUVHLGVBQWU7UUFDcEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFO1lBQzdCLEtBQUssTUFBTSxVQUFVLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUMxQyxJQUFJLFVBQVUsRUFBRSxDQUFDO29CQUNmLFVBQVUsRUFBRSxDQUFDO2dCQUNmLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7UUFFSCxNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FDckMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQzdCLFFBQVEsRUFDUixLQUFLLENBQUMsRUFBRTtZQUNOLElBQUksQ0FBQyxxQkFBcUIsQ0FBQztnQkFDekIsS0FBSyxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsU0FBUztnQkFDN0IsV0FBVyxFQUFFLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQyxTQUFTLElBQUk7YUFDM0MsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUNGLENBQUM7UUFDRixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUVsQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQyxDQUFDO1FBQzdELElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7UUFFeEQsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNO2FBQ3JCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDekMsU0FBUyxDQUFDLFlBQVksQ0FBQyxFQUFFO1lBQ3hCLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBQ3BDLENBQUMsQ0FBQyxDQUFDO1FBRUwsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRO2FBQ3ZCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDekMsU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ2pCLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzFCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVNLFNBQVMsR0FBRyxDQUFDLEtBQWEsRUFBRSxJQUEyQixFQUFFLEVBQUU7UUFDaEUsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDekMsQ0FBQyxDQUFDO0lBQ00sWUFBWSxDQUFDLFNBQWlEO1FBQ3BFLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxDQUFDO0lBQzVDLENBQUM7dUdBN0RVLHFCQUFxQjsyRkFBckIscUJBQXFCLGtUQUVILGdCQUFnQiw2QkMvQi9DLDhXQVFBLGliRG1COEIsb0JBQW9CLGtHQUFFLFNBQVM7OzJGQUVoRCxxQkFBcUI7a0JBUmpDLFNBQVM7K0JBQ0UsZ0JBQWdCLGNBR2QsSUFBSSxtQkFDQyx1QkFBdUIsQ0FBQyxNQUFNLFdBQ3RDLENBQUMsZ0JBQWdCLEVBQUUsb0JBQW9CLEVBQUUsU0FBUyxDQUFDO2dLQUdsQyxXQUFXO3NCQUFwQyxTQUFTO3VCQUFDLGFBQWE7Z0JBRXhCLE1BQU07c0JBREwsU0FBUzt1QkFBQyxRQUFRLEVBQUUsRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUU7Z0JBR3BCLFlBQVk7c0JBQXRDLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFO2dCQUNFLE9BQU87c0JBQWpDLEtBQUs7dUJBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIENoYW5nZURldGVjdG9yUmVmLFxuICBDb21wb25lbnQsXG4gIERlc3Ryb3lSZWYsXG4gIEVsZW1lbnRSZWYsXG4gIElucHV0LFxuICBSZW5kZXJlcjIsXG4gIHNpZ25hbCxcbiAgVmlld0NoaWxkLFxuICBWaWV3Q29udGFpbmVyUmVmLFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE5nVGVtcGxhdGVPdXRsZXQsIFNsaWNlUGlwZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBUYWJsZVNlcnZpY2UgfSBmcm9tICcuLi90YWJsZS5zZXJ2aWNlJztcbmltcG9ydCB7IHRha2VVbnRpbERlc3Ryb3llZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUvcnhqcy1pbnRlcm9wJztcbmltcG9ydCB7IENvbXBvbmVudENyZWF0b3IgfSBmcm9tICdvcmJpdGFsLXVpL2hlbHBlcnMnO1xuaW1wb3J0IHsgSU91aVRhYmxlQ29tYmluZWRPcHRpb25zLCBJT3VpVGFibGVJbnRlcm5hbEl0ZW0gfSBmcm9tICcuLi90eXBlcyc7XG5pbXBvcnQgeyBPdWlUYWJsZVJvd0NvbXBvbmVudCB9IGZyb20gJy4uL3RhYmxlLXJvdy9vdWktdGFibGUtcm93LmNvbXBvbmVudCc7XG5pbXBvcnQgeyBkZWJvdW5jZSwgc2xpY2UgfSBmcm9tICdsb2Rhc2gtZXMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdvdWktdGFibGUtYm9keScsXG4gIHRlbXBsYXRlVXJsOiAnLi9vdWktdGFibGUtYm9keS5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL291aS10YWJsZS1ib2R5LmNvbXBvbmVudC5zY3NzJ10sXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxuICBpbXBvcnRzOiBbTmdUZW1wbGF0ZU91dGxldCwgT3VpVGFibGVSb3dDb21wb25lbnQsIFNsaWNlUGlwZV0sXG59KVxuZXhwb3J0IGNsYXNzIE91aVRhYmxlQm9keUNvbXBvbmVudCBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQge1xuICBAVmlld0NoaWxkKCdib2R5V3JhcHBlcicpIGJvZHlXcmFwcGVyOiBFbGVtZW50UmVmO1xuICBAVmlld0NoaWxkKCdyb3dWQ1InLCB7IHJlYWQ6IFZpZXdDb250YWluZXJSZWYgfSlcbiAgcm93VkNSOiBWaWV3Q29udGFpbmVyUmVmO1xuXG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pIHRhYmxlU2VydmljZTogVGFibGVTZXJ2aWNlO1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KSBvcHRpb25zOiBJT3VpVGFibGVDb21iaW5lZE9wdGlvbnM7XG5cbiAgcHJpdmF0ZSB1bmxpc3RlbmVyczogYW55W10gPSBbXTtcbiAgcHJpdmF0ZSB0aHJvdHRsZWRTZXRTY3JvbGxUb3AgPSBkZWJvdW5jZSh0aGlzLnNldFNjcm9sbFRvcC5iaW5kKHRoaXMpLCAwKTtcbiAgcHVibGljIGl0ZW1zID0gc2lnbmFsPElPdWlUYWJsZUludGVybmFsSXRlbVtdPihbXSk7XG4gIHB1YmxpYyBpbmRleFRvID0gc2lnbmFsKDApO1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIGRlc3Ryb3lSZWY6IERlc3Ryb3lSZWYsXG4gICAgcHJpdmF0ZSBjZHI6IENoYW5nZURldGVjdG9yUmVmLFxuICAgIHByaXZhdGUgZWxlbWVudFJlZjogRWxlbWVudFJlZixcbiAgICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjJcbiAgKSB7fVxuXG4gIHB1YmxpYyBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgdGhpcy5kZXN0cm95UmVmLm9uRGVzdHJveSgoKSA9PiB7XG4gICAgICBmb3IgKGNvbnN0IHVubGlzdGVuZXIgb2YgdGhpcy51bmxpc3RlbmVycykge1xuICAgICAgICBpZiAodW5saXN0ZW5lcikge1xuICAgICAgICAgIHVubGlzdGVuZXIoKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuXG4gICAgY29uc3QgdW5saXN0ZW5lciA9IHRoaXMucmVuZGVyZXIubGlzdGVuKFxuICAgICAgdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQsXG4gICAgICAnc2Nyb2xsJyxcbiAgICAgIGV2ZW50ID0+IHtcbiAgICAgICAgdGhpcy50aHJvdHRsZWRTZXRTY3JvbGxUb3Aoe1xuICAgICAgICAgIHZhbHVlOiBldmVudC50YXJnZXQuc2Nyb2xsVG9wLFxuICAgICAgICAgIHN0cmluZ1ZhbHVlOiBgJHtldmVudC50YXJnZXQuc2Nyb2xsVG9wfXB4YCxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgKTtcbiAgICB0aGlzLnVubGlzdGVuZXJzLnB1c2godW5saXN0ZW5lcik7XG5cbiAgICB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5jbGFzc0xpc3QuYWRkKCdvdWktc2Nyb2xsYmFyJyk7XG4gICAgdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnc2Nyb2xsLXknKTtcblxuICAgIHRoaXMudGFibGVTZXJ2aWNlLml0ZW1zJFxuICAgICAgLnBpcGUodGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZikpXG4gICAgICAuc3Vic2NyaWJlKHZpc2libGVJdGVtcyA9PiB7XG4gICAgICAgIHRoaXMuaXRlbXMuc2V0KFsuLi52aXNpYmxlSXRlbXNdKTtcbiAgICAgIH0pO1xuXG4gICAgdGhpcy50YWJsZVNlcnZpY2UuaW5kZXhUbyRcbiAgICAgIC5waXBlKHRha2VVbnRpbERlc3Ryb3llZCh0aGlzLmRlc3Ryb3lSZWYpKVxuICAgICAgLnN1YnNjcmliZShpbmRleCA9PiB7XG4gICAgICAgIHRoaXMuaW5kZXhUby5zZXQoaW5kZXgpO1xuICAgICAgfSk7XG4gIH1cblxuICBwdWJsaWMgdHJhY2tJdGVtID0gKGluZGV4OiBudW1iZXIsIGl0ZW06IElPdWlUYWJsZUludGVybmFsSXRlbSkgPT4ge1xuICAgIHJldHVybiBpdGVtLml0ZW1bdGhpcy5vcHRpb25zLnRyYWNrQnldO1xuICB9O1xuICBwcml2YXRlIHNldFNjcm9sbFRvcChzY3JvbGxUb3A6IHsgdmFsdWU6IG51bWJlcjsgc3RyaW5nVmFsdWU6IHN0cmluZyB9KSB7XG4gICAgdGhpcy50YWJsZVNlcnZpY2Uuc2V0U2Nyb2xsVG9wKHNjcm9sbFRvcCk7XG4gIH1cbn1cbiIsIkBpZiAob3B0aW9ucykge1xuICA8ZGl2IGNsYXNzPVwib3VpLXRhYmxlLWJvZHlcIiAjYm9keVdyYXBwZXI+XG4gICAgPCEtLSAgPG5nLWNvbnRhaW5lciBjbGFzcz1cInJvdy1wYXJlbnRcIiBpZD1cInhcIiAjcm93VkNSPjwvbmctY29udGFpbmVyPi0tPlxuICAgIEBmb3IgKGl0ZW0gb2YgKGl0ZW1zKCkgfCBzbGljZTogMDppbmRleFRvKCkpOyB0cmFjayB0cmFja0l0ZW0oJGluZGV4LCBpdGVtKSkge1xuICAgICAgPG91aS10YWJsZS1yb3cgW2l0ZW1dPVwiaXRlbS5pdGVtXCIgW29wdGlvbnNdPVwib3B0aW9uc1wiIFt0YWJsZVNlcnZpY2VdPVwidGFibGVTZXJ2aWNlXCI+PC9vdWktdGFibGUtcm93PlxuICAgIH1cbiAgPC9kaXY+XG59XG4iXX0=