import { AfterViewInit, DestroyRef, ElementRef, EventEmitter, Renderer2 } from '@angular/core';
import { IPoint } from 'orbital-ui/core';
import { IContainerConstraintOptions, IDragMoveHookFunction, IOuiSnapEvent, IOuiDragMoveEvent, IDefaultBehaviorOptions } from './typings';
import { BehaviorBase } from './behavior-default';
import { IInertiaBehaviorOptions, InertiaBehavior, ISnapBehaviorOptions } from './behavior-inertia';
import { SnapBehavior } from './behavior-snap';
import { OuiDraggableService } from './draggable.service';
import { IRubberbandBehaviorOptions, RubberbandBehavior } from './behavior-rubberband';
import * as i0 from "@angular/core";
/**
 * Axis: Defines an axis by which dragging is restricted. By default dragging works on all axis.
 * constraint: A custom constraint by which dragging is restricted. This function is triggered on every dragMove. If returning false, dragging won't work.
 * container: An element inside of which dragging is restricted.
 * containerAnchor: Whether or not elements should be restricted inside the container by their edge or by their center
 * positionHook: This hook can be used to manually adjust how the object is dragged. The parameter is where the object WOULD ordinarily be dragged,
 *               and the return-value is where it will be dragged instead.
 */
/**
 * Directive that can be used to add functionality to any element that enables them to be dragged around.
 * NOTE: EXCERCISE GREAT CARE WHEN ADJUSTING THIS COMPONENT, AS OTHER COMPONENTS LIKE oui-SLIDER DEPEND ON IT
 *
 * @Input() ouiDraggableOptions: IOuiDraggableOptions
 *   Options passed to the directive
 *
 * @Output() dragMove: EventEmitter<IDragMove>
 *   Event triggered when dragged object is moved
 * @Output() dragStart: EventEmitter<MouseEvent|TouchEvent>
 *   Event triggered when dragging starts
 * @Output() dragEnd: EventEmitter<MouseEvent|TouchEvent>
 *   Event triggered when dragging ends
 */
export declare class OuiDraggableDirective implements AfterViewInit {
    elementRef: ElementRef;
    document: Document;
    destroyRef: DestroyRef;
    renderer: Renderer2;
    ouiDraggableService: OuiDraggableService;
    dragMove: EventEmitter<IOuiSnapEvent | IOuiDragMoveEvent>;
    dragStart: EventEmitter<MouseEvent | TouchEvent>;
    dragEnd: EventEmitter<MouseEvent | TouchEvent | undefined>;
    private element;
    behavior: BehaviorBase | SnapBehavior | InertiaBehavior | RubberbandBehavior | undefined;
    currentTransform: IPoint;
    id: string;
    dragMoveHooks: IDragMoveHookFunction[];
    constructor(elementRef: ElementRef, document: Document, destroyRef: DestroyRef, renderer: Renderer2, ouiDraggableService: OuiDraggableService);
    ngAfterViewInit(): void;
    updateTransform(value: IPoint): void;
    addInertiaBehavior(options: IInertiaBehaviorOptions): BehaviorBase | InertiaBehavior;
    addRubberbandBehavior(options: IRubberbandBehaviorOptions): BehaviorBase | RubberbandBehavior;
    addDefaultBehavior(options?: IDefaultBehaviorOptions): BehaviorBase;
    addSnapBehavior(options: ISnapBehaviorOptions): SnapBehavior;
    addContainerConstraint(options: IContainerConstraintOptions): void;
    addAxisConstraint(axis: 'x' | 'y'): void;
    addCustomConstraint(constraint: IDragMoveHookFunction): void;
    getBbox(): any;
    click(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiDraggableDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OuiDraggableDirective, "[oui-draggable]", ["OuiDraggableDirective"], {}, { "dragMove": "dragMove"; "dragStart": "dragStart"; "dragEnd": "dragEnd"; }, never, never, true, never>;
}
//# sourceMappingURL=draggable.directive.d.ts.map