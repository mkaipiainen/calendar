import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Pipe to output either a caret up or down depending on value
 */
export declare class SelectItemLabelPipe implements PipeTransform {
    transform(item: any, labelKey: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectItemLabelPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<SelectItemLabelPipe, "selectItemLabel", true>;
}
//# sourceMappingURL=select-item-label.pipe.d.ts.map