import { Injectable } from '@angular/core';
import { ReplaySubject } from 'rxjs';
import * as i0 from "@angular/core";
export class OuiTabsService {
    tabSelectedSubject = new ReplaySubject(1);
    tabSelected$ = this.tabSelectedSubject.asObservable();
    tabs = {};
    constructor() { }
    registerTabs(tabs) {
        this.tabs[tabs.id] = tabs;
    }
    selectTab(givenTab) {
        if (typeof givenTab === 'string') {
            for (const key in this.tabs) {
                const tabs = this.tabs[key];
                for (const tab of tabs.tabs.toArray()) {
                    if (tab.id === givenTab) {
                        this.tabSelectedSubject.next(tab);
                        return;
                    }
                }
            }
        }
        else {
            this.tabSelectedSubject.next(givenTab);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTabsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTabsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTabsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGFicy5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS90YWJzL3RhYnMuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBRzNDLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSxNQUFNLENBQUM7O0FBSXJDLE1BQU0sT0FBTyxjQUFjO0lBQ2pCLGtCQUFrQixHQUFHLElBQUksYUFBYSxDQUFrQixDQUFDLENBQUMsQ0FBQztJQUU1RCxZQUFZLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksRUFBRSxDQUFDO0lBRXRELElBQUksR0FFUCxFQUFFLENBQUM7SUFFUCxnQkFBZSxDQUFDO0lBRVQsWUFBWSxDQUFDLElBQXNCO1FBQ3hDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQztJQUM1QixDQUFDO0lBRU0sU0FBUyxDQUFDLFFBQWtDO1FBQ2pELElBQUksT0FBTyxRQUFRLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDakMsS0FBSyxNQUFNLEdBQUcsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQzVCLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQzVCLEtBQUssTUFBTSxHQUFHLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDO29CQUN0QyxJQUFJLEdBQUcsQ0FBQyxFQUFFLEtBQUssUUFBUSxFQUFFLENBQUM7d0JBQ3hCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQ2xDLE9BQU87b0JBQ1QsQ0FBQztnQkFDSCxDQUFDO1lBQ0gsQ0FBQztRQUNILENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUN6QyxDQUFDO0lBQ0gsQ0FBQzt1R0E3QlUsY0FBYzsyR0FBZCxjQUFjLGNBRmIsTUFBTTs7MkZBRVAsY0FBYztrQkFIMUIsVUFBVTttQkFBQztvQkFDVixVQUFVLEVBQUUsTUFBTTtpQkFDbkIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPdWlUYWJzQ29tcG9uZW50IH0gZnJvbSAnLi90YWJzLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBPdWlUYWJDb21wb25lbnQgfSBmcm9tICcuL3RhYi5jb21wb25lbnQnO1xuaW1wb3J0IHsgUmVwbGF5U3ViamVjdCB9IGZyb20gJ3J4anMnO1xuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCcsXG59KVxuZXhwb3J0IGNsYXNzIE91aVRhYnNTZXJ2aWNlIHtcbiAgcHJpdmF0ZSB0YWJTZWxlY3RlZFN1YmplY3QgPSBuZXcgUmVwbGF5U3ViamVjdDxPdWlUYWJDb21wb25lbnQ+KDEpO1xuXG4gIHB1YmxpYyB0YWJTZWxlY3RlZCQgPSB0aGlzLnRhYlNlbGVjdGVkU3ViamVjdC5hc09ic2VydmFibGUoKTtcblxuICBwdWJsaWMgdGFiczoge1xuICAgIFtpZDogc3RyaW5nXTogT3VpVGFic0NvbXBvbmVudDtcbiAgfSA9IHt9O1xuXG4gIGNvbnN0cnVjdG9yKCkge31cblxuICBwdWJsaWMgcmVnaXN0ZXJUYWJzKHRhYnM6IE91aVRhYnNDb21wb25lbnQpIHtcbiAgICB0aGlzLnRhYnNbdGFicy5pZF0gPSB0YWJzO1xuICB9XG5cbiAgcHVibGljIHNlbGVjdFRhYihnaXZlblRhYjogT3VpVGFiQ29tcG9uZW50IHwgc3RyaW5nKSB7XG4gICAgaWYgKHR5cGVvZiBnaXZlblRhYiA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGZvciAoY29uc3Qga2V5IGluIHRoaXMudGFicykge1xuICAgICAgICBjb25zdCB0YWJzID0gdGhpcy50YWJzW2tleV07XG4gICAgICAgIGZvciAoY29uc3QgdGFiIG9mIHRhYnMudGFicy50b0FycmF5KCkpIHtcbiAgICAgICAgICBpZiAodGFiLmlkID09PSBnaXZlblRhYikge1xuICAgICAgICAgICAgdGhpcy50YWJTZWxlY3RlZFN1YmplY3QubmV4dCh0YWIpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLnRhYlNlbGVjdGVkU3ViamVjdC5uZXh0KGdpdmVuVGFiKTtcbiAgICB9XG4gIH1cbn1cbiJdfQ==