export * from './file-dropzone.component';
//# sourceMappingURL=public-api.d.ts.map