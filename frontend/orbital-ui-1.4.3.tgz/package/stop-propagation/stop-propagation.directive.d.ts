import * as i0 from "@angular/core";
/**
 * Can be used to make all click-events on the element stop propagation.
 */
export declare class ClickStopPropagationDirective {
    onClick(event: any): void;
    click(event: any): void;
    hover(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ClickStopPropagationDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ClickStopPropagationDirective, "[oui-stop-propagation]", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=stop-propagation.directive.d.ts.map