import * as i0 from '@angular/core';
import { Pipe, Injectable, Inject, EventEmitter, Component, ChangeDetectionStrategy, ViewChild, Input, Output } from '@angular/core';
import * as i3 from '@angular/forms';
import { NG_VALUE_ACCESSOR, NG_VALIDATORS, FormsModule } from '@angular/forms';
import { DOCUMENT, NgClass } from '@angular/common';
import { OuiIconComponent } from 'orbital-ui/icon';
import { GUID } from 'orbital-ui/helpers';
import anime from 'animejs';
import { IsNilPipe } from 'orbital-ui/pipes';
import { merge } from 'lodash-es';
import { fromEvent } from 'rxjs';
import * as i2 from '@angular/cdk/text-field';

/**
 * Pipe to check if a value is null or undefined
 * @param value value to check
 */
class InputClassPipe {
    transform(model, variant, isInitialized, isActive) {
        const isActiveCombined = !!model || isActive;
        return `oui-input ${variant} ${isActiveCombined ? 'focused' : ''} ${isInitialized ? 'initialized' : ''}`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: InputClassPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: InputClassPipe, isStandalone: true, name: "inputClass" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: InputClassPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'inputClass',
                    standalone: true,
                }]
        }] });

/**
 * Service used to control inputs.
 * Mainly used right now just to keep track of them and to set focus to inputs when clicking on them.
 */
class OuiInputService {
    document;
    inputs = [];
    constructor(document) {
        this.document = document;
        fromEvent(this.document.body, 'click').subscribe((event) => {
            if ((window.TouchEvent && event instanceof TouchEvent) ||
                event instanceof MouseEvent) {
                for (const input of this.inputs) {
                    if (input.isFocused &&
                        !input.inputWrapperElement.nativeElement.contains(event.target)) {
                        input.setFocus(false);
                    }
                }
            }
        });
    }
    defocusAll() {
        for (const input of this.inputs) {
            input.setFocus(false);
        }
    }
    register(input) {
        this.inputs.push(input);
    }
    deregister(input) {
        this.inputs = this.inputs.filter(i => i !== input);
    }
    setFocus(input, isFocused) {
        input.setFocus(isFocused);
    }
    setError(input, hasError) {
        input.setError(hasError);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiInputService, deps: [{ token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiInputService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiInputService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }] });

/**
 * Component to add input-fields.
 *
 *   Example use:
 *   <oui-input variant="underlined" [(model)]="myInputValue" placeholder="Please write your input..."></oui-input>
 */
class OuiInputComponent {
    ouiInputService;
    cdr;
    elementRef;
    renderer;
    autofillMonitor;
    inputElement;
    autosizeSpan;
    inputWrapperElement;
    /**
     *   The model that's bound to the input field
     */
    model;
    /**
     * Options of the input-field. See IOuiInputOptions for more information
     */
    set options(options) {
        this.#combinedOptions = merge({
            ...this.#defaultOptions,
            ...options,
        });
    }
    get options() {
        return this.#combinedOptions;
    }
    /**
     *   The event emitted when input field changes.
     */
    modelChange = new EventEmitter();
    /**
     *   The event emitted when the hasError-field changes
     */
    hasErrorChange = new EventEmitter();
    #formOnChange = () => { };
    #formOnTouched = () => { };
    #isTouched = false;
    #defaultOptions = {
        type: 'text',
        placeholder: '',
        label: '',
        variant: 'standard',
        fontSize: '1.5rem',
        sizeToContent: false,
        maxLength: undefined,
        noPadding: false,
        endIcon: undefined,
    };
    #combinedOptions = {
        type: 'text',
        placeholder: '',
        label: '',
        variant: 'standard',
        fontSize: '1.5rem',
        sizeToContent: false,
        maxLength: undefined,
        noPadding: false,
        endIcon: undefined,
    };
    isFocused = false;
    isDisabled = false;
    isActive = false;
    id = GUID();
    isInitialized = false;
    sizeToContentModel = '';
    constructor(ouiInputService, cdr, elementRef, renderer, autofillMonitor) {
        this.ouiInputService = ouiInputService;
        this.cdr = cdr;
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.autofillMonitor = autofillMonitor;
        this.ouiInputService.register(this);
    }
    onModelChange(data) {
        if (this.options.maxLength && data.length > this.options.maxLength) {
            this.model = data.substring(0, this.options.maxLength);
            this.inputElement.nativeElement.value = this.model;
            anime({
                targets: this.elementRef.nativeElement,
                translateX: [
                    {
                        value: 0.5,
                    },
                    {
                        value: -0.5,
                    },
                ],
                loop: 5,
                direction: 'alternate',
                duration: 50,
                scale: 1,
            });
        }
        else {
            this.model = data;
        }
        // Hack to prevent angular from stripping whitespaces
        if (typeof this.model === 'string') {
            this.sizeToContentModel = this.model.replace(/ /g, '.');
        }
        this.#formOnChange(this.model);
        this.modelChange.emit(this.model);
        this.checkIsActive();
    }
    isAutoFilled() {
        const content = `"${String.fromCharCode(0xfeff)}"`;
        const style = window.getComputedStyle(this.inputElement.nativeElement);
        return this.inputElement.nativeElement.value
            ? false
            : content === style.content;
    }
    ngAfterViewInit() {
        const interval = setInterval(() => {
            const isAutoFilled = this.isAutoFilled();
            if (isAutoFilled) {
                this.isFocused = true;
                this.cdr.detectChanges();
                clearInterval(interval);
            }
        }, 200);
        setTimeout(() => {
            clearInterval(interval);
        }, 3000);
        this.checkIsActive();
        this.inputElement.nativeElement.style.fontSize = this.options.fontSize;
        if (this.options.sizeToContent) {
            this.autosizeSpan.nativeElement.style.fontSize = this.options.fontSize;
        }
        if (this.options.type === 'password' && !this.options.endIcon) {
            this.options.endIcon = {
                icon: 'assets/icons/visibility_off.svg',
                options: {
                    strokeColor: 'color-light',
                    size: '20px',
                },
                onClick: () => {
                    if (this.options.type === 'password') {
                        this.options.type = 'text';
                        if (this.options.endIcon) {
                            this.options.endIcon.icon = 'assets/icons/visibility_on.svg';
                        }
                    }
                    else {
                        this.options.type = 'password';
                        if (this.options.endIcon) {
                            this.options.endIcon.icon = 'assets/icons/visibility_off.svg';
                        }
                    }
                },
            };
            this.cdr.detectChanges();
        }
        // Hack to firstly make sure input is active if browser autofills it, and secondly
        // to make it so that the input doesn't flash due to initial content load
        setTimeout(() => {
            this.isInitialized = true;
            this.checkIsActive();
        }, 400);
    }
    setFocus(value) {
        this.isFocused = value;
        if (this.isFocused) {
            this.setError(false);
        }
        if (!this.#isTouched) {
            this.#isTouched = true;
            this.#formOnTouched();
        }
        this.checkIsActive();
    }
    checkIsActive() {
        this.isActive = this.isFocused || !!this.model;
        this.cdr.detectChanges();
    }
    setError(value) {
        // this.options.hasError = value;
        this.hasErrorChange.emit(value);
        this.cdr.detectChanges();
    }
    onEndIconClick() {
        if (this.options.endIcon?.onClick) {
            this.options.endIcon.onClick();
        }
    }
    writeValue(value) {
        this.model = value;
        this.#formOnChange(this.model);
        this.cdr.detectChanges();
    }
    registerOnChange(fn) {
        this.#formOnChange = fn;
    }
    registerOnTouched(fn) {
        this.#formOnTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabled = isDisabled;
        this.renderer.setAttribute(this.elementRef.nativeElement, 'disabled', `${isDisabled}`);
        this.cdr.detectChanges();
    }
    validate(control) {
        if (this.options.maxLength) {
            if (control.value.length > this.options.maxLength) {
                return {
                    maxLength: {
                        requiredLength: this.options.maxLength,
                        actualLength: control.value.length,
                    },
                };
            }
        }
        return null;
    }
    ngOnChanges(changes) {
        if ('model' in changes) {
            this.model = changes.model.currentValue;
            this.checkIsActive();
        }
    }
    ngOnDestroy() {
        this.ouiInputService.deregister(this);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiInputComponent, deps: [{ token: OuiInputService }, { token: i0.ChangeDetectorRef }, { token: i0.ElementRef }, { token: i0.Renderer2 }, { token: i2.AutofillMonitor }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiInputComponent, isStandalone: true, selector: "oui-input", inputs: { model: "model", options: "options" }, outputs: { modelChange: "modelChange", hasErrorChange: "hasErrorChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                multi: true,
                useExisting: OuiInputComponent,
            },
            {
                provide: NG_VALIDATORS,
                multi: true,
                useExisting: OuiInputComponent,
            },
        ], viewQueries: [{ propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true }, { propertyName: "autosizeSpan", first: true, predicate: ["autosizeSpan"], descendants: true }, { propertyName: "inputWrapperElement", first: true, predicate: ["inputWrapperElement"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"{{ model | inputClass: options.variant:isInitialized:isFocused }}\" (click)=\"setFocus(true)\" #inputWrapperElement>\n  @if (options.label) {\n    <div class=\"oui-input-label\">\n      {{ options.label }}\n    </div>\n  }\n  @if (options.maxLength && !(model | isNil)) {\n    <div class=\"oui-input-max-length\">\n      {{ model.length }}/{{ options.maxLength }}\n    </div>\n  }\n  <div class=\"input-wrapper\">\n    @if (options.sizeToContent) {\n      <span #autosizeSpan class=\"autosize\">{{\n        sizeToContentModel\n      }}</span>\n    }\n    <input\n      [ngClass]=\"{\n        autosize: options.sizeToContent,\n        'no-padding': options.noPadding\n      }\"\n      class=\"input\"\n      [placeholder]=\"options.placeholder ?? ''\"\n      (focus)=\"setFocus(true)\"\n      (blur)=\"setFocus(false)\"\n      #inputElement\n      [type]=\"options.type\"\n      [ngModel]=\"model\"\n      (ngModelChange)=\"onModelChange($event)\"\n      />\n    @if (options.endIcon) {\n      <oui-icon\n        class=\"end-icon\"\n        [ngClass]=\"{ 'has-click': options.endIcon.onClick }\"\n        (click)=\"onEndIconClick()\"\n        [icon]=\"options.endIcon.icon\"\n        [options]=\"options.endIcon.options\"\n      ></oui-icon>\n    }\n  </div>\n\n  @if (options.variant === 'underlined') {\n    <div\n      class=\"oui-input-underline-wrapper\"\n      >\n      <div class=\"oui-input-underline-content\"></div>\n    </div>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";:host{flex:1;display:flex;flex-direction:column;position:relative;border-radius:var(--oui-input-border-radius)}:host ::placeholder{color:var(--oui-input-placeholder-color)}:host.ng-invalid.ng-touched .oui-input{border-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input .oui-input-underline-wrapper{background-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input .oui-input-label{color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused{border-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-label{top:-1.5rem;left:0rem;font-size:var(--oui-input-label-focused-font-size);color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-max-length{color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-underline-wrapper .oui-input-underline-content{background-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-label{color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input .oui-input-max-length{color:var(--color-danger)}:host[disabled=true]{opacity:.5;pointer-events:none}:host .oui-input-max-length{font-size:.8rem;position:absolute;top:var(--oui-input-max-length-top);right:var(--oui-input-max-length-right);z-index:1;color:var(--oui-input-max-length-color);transition:color .3s}:host .oui-input{border-radius:var(--oui-input-border-radius);border-color:var(--oui-input-border-color);border-width:var(--oui-input-border-width);border-style:var(--oui-input-border-style);flex:1;position:relative;display:flex;padding:2px;height:100%;transition:border-color .3s;color:var(--oui-input-text-color);background-color:var(--oui-input-background-color)}:host .oui-input.focused{border-color:var(--oui-input-border-active-color)}:host .oui-input.focused .oui-input-label{top:-1.5rem;left:0rem;font-size:var(--oui-input-label-focused-font-size);color:var(--oui-input-label-color-focused)}:host .oui-input.focused .oui-input-max-length{color:var(--oui-input-max-length-color)}:host .oui-input.focused .oui-input-underline-wrapper{height:var(--oui-input-underline-active-height)}:host .oui-input.focused .oui-input-underline-wrapper .oui-input-underline-content{transform:scaleX(1);background-color:var(--oui-input-underline-active-color);transition:transform .4s}:host .oui-input.focused .oui-input-label{color:var(--oui-input-label-color-focused)}:host .oui-input input:-webkit-autofill,:host .oui-input input:-webkit-autofill:hover,:host .oui-input input:-webkit-autofill:focus,:host .oui-input input:-webkit-autofill:active{transition:background-color 9999s ease-in-out 0s!important;transition-delay:9999s!important;-webkit-text-fill-color:var(--oui-input-standard-text-color)!important}:host .oui-input .oui-input-label{color:var(--oui-input-label-color)}:host .oui-input input{width:100%;max-width:100%;color:var(--oui-input-text-color);background-color:var(--oui-input-background-color)}:host .oui-input .input-wrapper .end-icon{margin-right:1rem}:host .oui-input *{transition:none}:host .oui-input.initialized{transition:background-color .3s}:host .oui-input.initialized *{transition:background-color .3s}:host .oui-input .oui-input-underline-wrapper{display:none}:host .oui-input.underlined{background-color:transparent;border:none}:host .oui-input.underlined input{background-color:transparent;padding:0}:host .oui-input .oui-input-underline-wrapper{width:100%;height:var(--oui-input-underline-height);position:absolute;bottom:-1px;left:0;display:flex;justify-content:center;align-items:center;background-color:var(--oui-input-underline-color)}:host .oui-input .oui-input-underline-wrapper .oui-input-underline-content{width:100%;transform:scaleX(0);height:100%;transition:transform .2s;transform-origin:center}:host .oui-input .oui-input-label{position:absolute;top:0;left:.5rem;color:var(--oui-input-text-color);transition:top .2s,left .2s,font-size .2s,color .2s;font-size:var(--oui-input-label-font-size);pointer-events:none;font-family:var(--font-primary);z-index:1}:host .oui-input .input-wrapper{display:flex;align-items:center;position:relative;flex:1}:host .oui-input .input-wrapper input{outline:none;border:none;flex:1;height:100%;font-family:var(--font-primary);font-size:13px;padding:0 1rem}:host .oui-input .input-wrapper input.no-padding{padding:0}:host .oui-input .input-wrapper input.autosize{position:absolute;width:100%}:host .oui-input .input-wrapper span{width:100%;height:100%;padding:0 1rem}:host .oui-input .input-wrapper span.autosize{font-family:var(--font-primary);font-size:13px;opacity:0;pointer-events:none}:host .oui-input .input-wrapper oui-icon.has-click:hover{cursor:pointer}:host input:-webkit-autofill{content:\"\\feff\"}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "pipe", type: IsNilPipe, name: "isNil" }, { kind: "pipe", type: InputClassPipe, name: "inputClass" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-input', standalone: true, imports: [
                        OuiIconComponent,
                        FormsModule,
                        NgClass,
                        IsNilPipe,
                        InputClassPipe
                    ], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            multi: true,
                            useExisting: OuiInputComponent,
                        },
                        {
                            provide: NG_VALIDATORS,
                            multi: true,
                            useExisting: OuiInputComponent,
                        },
                    ], template: "<div class=\"{{ model | inputClass: options.variant:isInitialized:isFocused }}\" (click)=\"setFocus(true)\" #inputWrapperElement>\n  @if (options.label) {\n    <div class=\"oui-input-label\">\n      {{ options.label }}\n    </div>\n  }\n  @if (options.maxLength && !(model | isNil)) {\n    <div class=\"oui-input-max-length\">\n      {{ model.length }}/{{ options.maxLength }}\n    </div>\n  }\n  <div class=\"input-wrapper\">\n    @if (options.sizeToContent) {\n      <span #autosizeSpan class=\"autosize\">{{\n        sizeToContentModel\n      }}</span>\n    }\n    <input\n      [ngClass]=\"{\n        autosize: options.sizeToContent,\n        'no-padding': options.noPadding\n      }\"\n      class=\"input\"\n      [placeholder]=\"options.placeholder ?? ''\"\n      (focus)=\"setFocus(true)\"\n      (blur)=\"setFocus(false)\"\n      #inputElement\n      [type]=\"options.type\"\n      [ngModel]=\"model\"\n      (ngModelChange)=\"onModelChange($event)\"\n      />\n    @if (options.endIcon) {\n      <oui-icon\n        class=\"end-icon\"\n        [ngClass]=\"{ 'has-click': options.endIcon.onClick }\"\n        (click)=\"onEndIconClick()\"\n        [icon]=\"options.endIcon.icon\"\n        [options]=\"options.endIcon.options\"\n      ></oui-icon>\n    }\n  </div>\n\n  @if (options.variant === 'underlined') {\n    <div\n      class=\"oui-input-underline-wrapper\"\n      >\n      <div class=\"oui-input-underline-content\"></div>\n    </div>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";:host{flex:1;display:flex;flex-direction:column;position:relative;border-radius:var(--oui-input-border-radius)}:host ::placeholder{color:var(--oui-input-placeholder-color)}:host.ng-invalid.ng-touched .oui-input{border-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input .oui-input-underline-wrapper{background-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input .oui-input-label{color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused{border-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-label{top:-1.5rem;left:0rem;font-size:var(--oui-input-label-focused-font-size);color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-max-length{color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-underline-wrapper .oui-input-underline-content{background-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-label{color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input .oui-input-max-length{color:var(--color-danger)}:host[disabled=true]{opacity:.5;pointer-events:none}:host .oui-input-max-length{font-size:.8rem;position:absolute;top:var(--oui-input-max-length-top);right:var(--oui-input-max-length-right);z-index:1;color:var(--oui-input-max-length-color);transition:color .3s}:host .oui-input{border-radius:var(--oui-input-border-radius);border-color:var(--oui-input-border-color);border-width:var(--oui-input-border-width);border-style:var(--oui-input-border-style);flex:1;position:relative;display:flex;padding:2px;height:100%;transition:border-color .3s;color:var(--oui-input-text-color);background-color:var(--oui-input-background-color)}:host .oui-input.focused{border-color:var(--oui-input-border-active-color)}:host .oui-input.focused .oui-input-label{top:-1.5rem;left:0rem;font-size:var(--oui-input-label-focused-font-size);color:var(--oui-input-label-color-focused)}:host .oui-input.focused .oui-input-max-length{color:var(--oui-input-max-length-color)}:host .oui-input.focused .oui-input-underline-wrapper{height:var(--oui-input-underline-active-height)}:host .oui-input.focused .oui-input-underline-wrapper .oui-input-underline-content{transform:scaleX(1);background-color:var(--oui-input-underline-active-color);transition:transform .4s}:host .oui-input.focused .oui-input-label{color:var(--oui-input-label-color-focused)}:host .oui-input input:-webkit-autofill,:host .oui-input input:-webkit-autofill:hover,:host .oui-input input:-webkit-autofill:focus,:host .oui-input input:-webkit-autofill:active{transition:background-color 9999s ease-in-out 0s!important;transition-delay:9999s!important;-webkit-text-fill-color:var(--oui-input-standard-text-color)!important}:host .oui-input .oui-input-label{color:var(--oui-input-label-color)}:host .oui-input input{width:100%;max-width:100%;color:var(--oui-input-text-color);background-color:var(--oui-input-background-color)}:host .oui-input .input-wrapper .end-icon{margin-right:1rem}:host .oui-input *{transition:none}:host .oui-input.initialized{transition:background-color .3s}:host .oui-input.initialized *{transition:background-color .3s}:host .oui-input .oui-input-underline-wrapper{display:none}:host .oui-input.underlined{background-color:transparent;border:none}:host .oui-input.underlined input{background-color:transparent;padding:0}:host .oui-input .oui-input-underline-wrapper{width:100%;height:var(--oui-input-underline-height);position:absolute;bottom:-1px;left:0;display:flex;justify-content:center;align-items:center;background-color:var(--oui-input-underline-color)}:host .oui-input .oui-input-underline-wrapper .oui-input-underline-content{width:100%;transform:scaleX(0);height:100%;transition:transform .2s;transform-origin:center}:host .oui-input .oui-input-label{position:absolute;top:0;left:.5rem;color:var(--oui-input-text-color);transition:top .2s,left .2s,font-size .2s,color .2s;font-size:var(--oui-input-label-font-size);pointer-events:none;font-family:var(--font-primary);z-index:1}:host .oui-input .input-wrapper{display:flex;align-items:center;position:relative;flex:1}:host .oui-input .input-wrapper input{outline:none;border:none;flex:1;height:100%;font-family:var(--font-primary);font-size:13px;padding:0 1rem}:host .oui-input .input-wrapper input.no-padding{padding:0}:host .oui-input .input-wrapper input.autosize{position:absolute;width:100%}:host .oui-input .input-wrapper span{width:100%;height:100%;padding:0 1rem}:host .oui-input .input-wrapper span.autosize{font-family:var(--font-primary);font-size:13px;opacity:0;pointer-events:none}:host .oui-input .input-wrapper oui-icon.has-click:hover{cursor:pointer}:host input:-webkit-autofill{content:\"\\feff\"}\n"] }]
        }], ctorParameters: () => [{ type: OuiInputService }, { type: i0.ChangeDetectorRef }, { type: i0.ElementRef }, { type: i0.Renderer2 }, { type: i2.AutofillMonitor }], propDecorators: { inputElement: [{
                type: ViewChild,
                args: ['inputElement']
            }], autosizeSpan: [{
                type: ViewChild,
                args: ['autosizeSpan']
            }], inputWrapperElement: [{
                type: ViewChild,
                args: ['inputWrapperElement']
            }], model: [{
                type: Input
            }], options: [{
                type: Input
            }], modelChange: [{
                type: Output
            }], hasErrorChange: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiInputComponent, OuiInputService };
//# sourceMappingURL=orbital-ui-input.mjs.map
