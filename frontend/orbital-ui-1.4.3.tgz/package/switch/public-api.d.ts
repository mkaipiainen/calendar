export * from './switch.component';
//# sourceMappingURL=public-api.d.ts.map