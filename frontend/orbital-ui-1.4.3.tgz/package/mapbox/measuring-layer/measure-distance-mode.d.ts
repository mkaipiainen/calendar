import { MeasureDistanceMode } from '@nebula.gl/edit-modes';
import { ClickEvent, ModeProps } from '@nebula.gl/edit-modes/src/types';
import { FeatureCollection } from '@nebula.gl/edit-modes/src/geojson-types';
export declare class OuiMeasureDistanceMode extends MeasureDistanceMode {
    constructor();
    handleClick(event: ClickEvent, props: ModeProps<FeatureCollection>): void;
}
//# sourceMappingURL=measure-distance-mode.d.ts.map