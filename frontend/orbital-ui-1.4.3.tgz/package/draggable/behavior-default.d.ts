import { OuiDraggableDirective } from './draggable.directive';
import { IPoint } from 'orbital-ui/core';
import { ReplaySubject, Subject } from 'rxjs';
import { ICombinedDefaultBehaviorOptions, IDefaultBehaviorOptions } from './typings';
export declare abstract class BehaviorBase {
    protected draggable: OuiDraggableDirective;
    protected dragMoveSubject: Subject<MouseEvent | TouchEvent>;
    protected dragEndSubject: Subject<void>;
    protected dragEnd$: import("rxjs").Observable<void>;
    protected destroyed$: ReplaySubject<boolean>;
    protected dragStartPosition: IPoint;
    protected isPreventingClicks: boolean;
    protected dragStartTransform: IPoint;
    protected readonly defaultOptions: ICombinedDefaultBehaviorOptions;
    protected combinedOptions: ICombinedDefaultBehaviorOptions;
    protected preventClickListener: (event: MouseEvent) => void;
    constructor(draggable: OuiDraggableDirective, options?: IDefaultBehaviorOptions);
    protected onDragStart(event: MouseEvent | TouchEvent): void;
    updateTransform(value: IPoint): void;
    protected onDragMove(event: MouseEvent | TouchEvent): void;
    protected moveToTarget(target: DOMRect): void;
    protected onDragEnd(event: MouseEvent | TouchEvent): void;
    protected runHooks(event: MouseEvent | TouchEvent | undefined, targetRectangle: DOMRect): DOMRect;
    protected cleanUp(): void;
    protected clickPreventer(event: MouseEvent): void;
}
export declare class DefaultBehavior extends BehaviorBase {
    constructor(draggable: OuiDraggableDirective, options?: IDefaultBehaviorOptions);
}
//# sourceMappingURL=behavior-default.d.ts.map