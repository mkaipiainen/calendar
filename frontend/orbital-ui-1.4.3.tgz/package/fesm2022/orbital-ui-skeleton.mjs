import * as i0 from '@angular/core';
import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { NgStyle } from '@angular/common';

/**
 * This component streamlines creation of skeleton loading-sections. Has a few different modes you can choose from, although
 * right now the table-mode is probably the most useful one.
 *
 * Example use:
 *
 *  <oui-skeleton [options]="loadingSkeletonOptions" *ngIf="isLoading && loadingSkeletonOptions.rows.count">
 *  </oui-skeleton>
 *
 *  Where loadingSkeletonOptions are
 *
 *  public loadingSkeletonOptions: ISkeletonTableOptions = {
 *    type: 'table',
 *    rows: {
 *      count: 0,
 *      verticalSpacing: '10px',
 *      height: '25px',
 *    },
 *    columns: {
 *      count: 4,
 *    },
 *    cells: {
 *      inset: '4px',
 *      horizontalSpacing: '4px',
 *    },
 *    header: {
 *      margin: '14px',
 *      height: '30px',
 *    }
 *  }
 */
class OuiSkeletonComponent {
    /**
     *   The options that define the skeleton. Currently suggested to use only the table-mode until further modes have been implemented.
     */
    options;
    columns = [];
    rows = [];
    constructor() { }
    combineOptions() {
        if (this.options.type === 'grid' || this.options.type === 'table') {
            const gridOptions = this
                .options;
            if (Array.isArray(gridOptions.columns)) {
                this.columns = gridOptions.columns;
            }
            else {
                this.columns = Array(gridOptions.columns.count)
                    .fill(0)
                    .map(() => {
                    return {
                        width: '10px',
                        margin: gridOptions.columns.margin,
                    };
                });
            }
            if (Array.isArray(gridOptions.rows)) {
                this.rows = gridOptions.rows;
            }
            else {
                this.rows = Array(gridOptions.rows.count)
                    .fill(0)
                    .map(() => {
                    return {
                        height: '10px',
                        margin: gridOptions.rows.margin,
                    };
                });
            }
        }
    }
    getRowStyle(row) {
        return {
            height: row.height,
            margin: `${row.margin} 0`,
        };
    }
    getColumnStyle(column) {
        return {
            width: column.width,
            margin: `0 ${column.margin}`,
        };
    }
    getTableRowStyle(type) {
        const tableOptions = this.options;
        const height = type === 'head'
            ? tableOptions.header?.height ?? tableOptions.rows.height
            : tableOptions.rows.height;
        return {
            height: height,
            margin: `${tableOptions.rows.verticalSpacing} 0`,
        };
    }
    getTableCellStyle() {
        const tableOptions = this.options;
        const style = {
            // 'padding': tableOptions.cells.inset,
            // 'border-width': tableOptions.borderWidth,
            margin: `0 ${tableOptions.cells.horizontalSpacing}`,
        };
        return style;
    }
    getTableInnerCellStyle() {
        const tableOptions = this.options;
        const style = {
            padding: tableOptions.cells.inset,
            // 'margin': `0 ${tableOptions.cells.horizontalSpacing}`
        };
        return style;
    }
    getSingleStyle() {
        const style = {};
        if (this.options.type === 'single' && this.options.backgroundImageOptions) {
            style['background-image'] = `url(${this.options.backgroundImageOptions.backgroundImage})`;
            style['background-repeat'] = 'no-repeat';
            style['background-position'] =
                this.options.backgroundImageOptions.backgroundPosition ?? 'center';
            style['background-size'] =
                this.options.backgroundImageOptions.backgroundSize ?? 'cover';
        }
        return style;
    }
    ngOnInit() {
        this.combineOptions();
    }
    ngOnChanges(changes) {
        if ('options' in changes) {
            this.combineOptions();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSkeletonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiSkeletonComponent, isStandalone: true, selector: "oui-skeleton", inputs: { options: "options" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"skeleton-container\">\n  @if (options.type === 'grid') {\n    <div class=\"skeleton-grid-container\">\n      @for (column of columns; track column) {\n        <div\n          class=\"skeleton-column\"\n          [ngStyle]=\"{ width: column.width, margin: '0 ' + column.margin }\"\n          >\n          @for (row of rows; track row) {\n            <div\n              class=\"skeleton-row\"\n              [ngStyle]=\"{ height: row.height, margin: row.margin + ' 0' }\"\n            ></div>\n          }\n        </div>\n      }\n    </div>\n  }\n  @if (options.type === 'single') {\n    <div class=\"skeleton-single-container\">\n      <div class=\"skeleton-single\" [ngStyle]=\"getSingleStyle()\"></div>\n    </div>\n  }\n  @if (options.type === 'table') {\n    <div class=\"skeleton-table-container\">\n      <div class=\"skeleton-table\">\n        @if (options.header) {\n          <div\n            class=\"skeleton-table-head\"\n            [ngStyle]=\"getTableRowStyle('head')\"\n            >\n            @for (column of columns; track column) {\n              <div\n                class=\"skeleton-table-head-cell cell\"\n                [ngStyle]=\"getTableCellStyle()\"\n                >\n                <div class=\"cell-inner\" [ngStyle]=\"getTableInnerCellStyle()\"></div>\n              </div>\n            }\n          </div>\n        }\n        @for (row of rows; track row) {\n          <div\n            class=\"skeleton-table-row\"\n            [ngStyle]=\"getTableRowStyle('body')\"\n            >\n            @for (column of columns; track column) {\n              <div\n                class=\"skeleton-table-row-cell cell\"\n                [ngStyle]=\"getTableCellStyle()\"\n                >\n                <div class=\"cell-inner\" [ngStyle]=\"getTableInnerCellStyle()\"></div>\n              </div>\n            }\n          </div>\n        }\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{display:flex;flex:1}:host .skeleton-container{display:flex;flex:1}:host .skeleton-container .skeleton-table-container{flex:1}:host .skeleton-container .skeleton-table-container .skeleton-table{width:100%;background-color:transparent;display:flex;flex-direction:column}:host .skeleton-container .skeleton-table-container .skeleton-table .skeleton-table-head{display:flex}:host .skeleton-container .skeleton-table-container .skeleton-table .skeleton-table-row{display:flex}:host .skeleton-container .skeleton-table-container .skeleton-table .cell{border-color:transparent;flex:1;display:flex;box-sizing:border-box}:host .skeleton-container .skeleton-table-container .skeleton-table .cell .cell-inner{flex:1;background-color:var(--oui-skeleton-background);position:relative;overflow:hidden;border:1px solid transparent;border-radius:4px}:host .skeleton-container .skeleton-table-container .skeleton-table .cell .cell-inner:after{content:\"\";display:block;width:100%;height:100%;position:absolute;top:0;left:0;transform:translate(-100%);animation:skeleton-animation 2s infinite;animation-timing-function:linear;z-index:1;background-image:linear-gradient(90deg,rgba(255,255,255,0),var(--oui-skeleton-active),rgba(255,255,255,0))}:host .skeleton-container .skeleton-grid-container{flex:1;display:flex}:host .skeleton-container .skeleton-grid-container .skeleton-column{display:flex;flex-direction:column;flex:1}:host .skeleton-container .skeleton-grid-container .skeleton-column .skeleton-row{background-color:#bbb;flex:1}@keyframes skeleton-animation{0%{transform:translate(-100%)}to{transform:translate(100%)}}\n"], dependencies: [{ kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSkeletonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-skeleton', standalone: true, imports: [NgStyle], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"skeleton-container\">\n  @if (options.type === 'grid') {\n    <div class=\"skeleton-grid-container\">\n      @for (column of columns; track column) {\n        <div\n          class=\"skeleton-column\"\n          [ngStyle]=\"{ width: column.width, margin: '0 ' + column.margin }\"\n          >\n          @for (row of rows; track row) {\n            <div\n              class=\"skeleton-row\"\n              [ngStyle]=\"{ height: row.height, margin: row.margin + ' 0' }\"\n            ></div>\n          }\n        </div>\n      }\n    </div>\n  }\n  @if (options.type === 'single') {\n    <div class=\"skeleton-single-container\">\n      <div class=\"skeleton-single\" [ngStyle]=\"getSingleStyle()\"></div>\n    </div>\n  }\n  @if (options.type === 'table') {\n    <div class=\"skeleton-table-container\">\n      <div class=\"skeleton-table\">\n        @if (options.header) {\n          <div\n            class=\"skeleton-table-head\"\n            [ngStyle]=\"getTableRowStyle('head')\"\n            >\n            @for (column of columns; track column) {\n              <div\n                class=\"skeleton-table-head-cell cell\"\n                [ngStyle]=\"getTableCellStyle()\"\n                >\n                <div class=\"cell-inner\" [ngStyle]=\"getTableInnerCellStyle()\"></div>\n              </div>\n            }\n          </div>\n        }\n        @for (row of rows; track row) {\n          <div\n            class=\"skeleton-table-row\"\n            [ngStyle]=\"getTableRowStyle('body')\"\n            >\n            @for (column of columns; track column) {\n              <div\n                class=\"skeleton-table-row-cell cell\"\n                [ngStyle]=\"getTableCellStyle()\"\n                >\n                <div class=\"cell-inner\" [ngStyle]=\"getTableInnerCellStyle()\"></div>\n              </div>\n            }\n          </div>\n        }\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{display:flex;flex:1}:host .skeleton-container{display:flex;flex:1}:host .skeleton-container .skeleton-table-container{flex:1}:host .skeleton-container .skeleton-table-container .skeleton-table{width:100%;background-color:transparent;display:flex;flex-direction:column}:host .skeleton-container .skeleton-table-container .skeleton-table .skeleton-table-head{display:flex}:host .skeleton-container .skeleton-table-container .skeleton-table .skeleton-table-row{display:flex}:host .skeleton-container .skeleton-table-container .skeleton-table .cell{border-color:transparent;flex:1;display:flex;box-sizing:border-box}:host .skeleton-container .skeleton-table-container .skeleton-table .cell .cell-inner{flex:1;background-color:var(--oui-skeleton-background);position:relative;overflow:hidden;border:1px solid transparent;border-radius:4px}:host .skeleton-container .skeleton-table-container .skeleton-table .cell .cell-inner:after{content:\"\";display:block;width:100%;height:100%;position:absolute;top:0;left:0;transform:translate(-100%);animation:skeleton-animation 2s infinite;animation-timing-function:linear;z-index:1;background-image:linear-gradient(90deg,rgba(255,255,255,0),var(--oui-skeleton-active),rgba(255,255,255,0))}:host .skeleton-container .skeleton-grid-container{flex:1;display:flex}:host .skeleton-container .skeleton-grid-container .skeleton-column{display:flex;flex-direction:column;flex:1}:host .skeleton-container .skeleton-grid-container .skeleton-column .skeleton-row{background-color:#bbb;flex:1}@keyframes skeleton-animation{0%{transform:translate(-100%)}to{transform:translate(100%)}}\n"] }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiSkeletonComponent };
//# sourceMappingURL=orbital-ui-skeleton.mjs.map
