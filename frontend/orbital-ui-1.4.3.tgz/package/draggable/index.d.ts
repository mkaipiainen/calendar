/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/draggable" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-draggable.d.ts.map