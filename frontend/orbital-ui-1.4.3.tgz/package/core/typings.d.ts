export type RGB = [number, number, number];
export type RGBA = [number, number, number, number];
export interface IPoint {
    x: number;
    y: number;
}
export interface IVirtualElement {
    getBoundingClientRect(): {
        left: number;
        top: number;
        width: number;
        height: number;
        bottom: number;
        right: number;
        x: number;
        y: number;
    };
}
export interface ILatLng {
    lat: number;
    lng: number;
}
export interface ImageBrokerOpticalImageBaseFromApi {
    capture_timestamp: string;
    pixel_resolution_x: number;
    pixel_resolution_y: number;
    buffer_factor: number | null;
    source: string;
    downloader: string;
    service_type: string;
    visualization_type: number | string;
}
export type ImageBrokerOpticalImageBase = Omit<ImageBrokerOpticalImageBaseFromApi, 'capture_timestamp'> & {
    capture_timestamp: Date;
};
export interface ImageBrokerWmtsOpticalImageFromApi extends ImageBrokerOpticalImageBaseFromApi {
    wmts_data: {
        url: string;
        layer: string;
        tile_matrix_set: string;
        image_format: string;
        min_zoom: number;
        max_zoom: number;
    };
    wms_data: {
        image_url: string;
        wms_layer_name: string;
    };
}
export type ImageBrokerOpticalImageFromApi = ImageBrokerWmtsOpticalImageFromApi | ImageBrokerWmsOpticalImageFromApi;
export type ImageBrokerWmsOpticalImageFromApi = ImageBrokerOpticalImageBaseFromApi & {
    wms_data: {
        image_url: string;
        wms_layer_name: string;
    };
    wmts_data: null;
};
export type ImageBrokerWmsOpticalImage = ImageBrokerOpticalImageBase & {
    wms_data: {
        image_url: string;
        wms_layer_name: string;
    };
    wmts_data: null;
};
export type ImageBrokerWmtsOpticalImage = ImageBrokerOpticalImageBase & {
    wms_data: null;
    wmts_data: {
        url: string;
        layer: string;
    };
};
export type ImageBrokerOpticalImage = ImageBrokerWmsOpticalImage | ImageBrokerWmtsOpticalImage;
export type S2Image = {
    capture_timestamp: Date;
    pixel_resolution_x: number;
    pixel_resolution_y: number;
    image_url: string;
    base_url: string;
    wms_layer_name: string;
    wms_layer: string;
    buffer_factor: number;
    downloader: string;
    service_type: string;
    bounds: [number, number, number, number];
};
//# sourceMappingURL=typings.d.ts.map