import { PathLayer } from '@deck.gl/layers/typed';
import { ICommonDeckLayerOptions, IDeckPathLayerOptions } from '../typings';
import { BaseDeckLayer } from '../base-deck-layer.component';
import * as i0 from "@angular/core";
export declare class DeckPathLayer extends BaseDeckLayer<ICommonDeckLayerOptions> {
    options: IDeckPathLayerOptions;
    constructor();
    getLayer(): PathLayer<any, {
        data: any[];
        getWidth: number | ((d: any) => number);
        widthMinPixels: number;
        widthMaxPixels: number;
        getColor: import("orbital-ui/core").RGBA | ((d: any) => import("orbital-ui/core").RGBA);
        getPath: any;
        widthUnits: "meters" | "common" | "pixels";
        jointRounded: boolean;
        id: string;
        autoHighlight: boolean;
        transitions: {
            [x: string]: number | {
                duration: number;
                easing: any;
            };
        };
        highlightColor: import("orbital-ui/core").RGBA | ((d: any) => import("orbital-ui/core").RGBA);
        isEnabled: boolean;
        _dataDiff: (oldData: any, newData: any) => [{
            startRow: number;
            endRow: number;
        }];
        onClick: (object: any, event: any) => void;
        onHover: (event: any) => boolean;
        updateTriggers: any;
        dataComparator: (<LayerDataT = import("@deck.gl/core/typed").LayerData<unknown>>(newData: LayerDataT, oldData?: LayerDataT | undefined) => boolean) | null;
        getCursor: (data: {
            isHovering: boolean;
            isDragging: boolean;
        }) => string;
        order: number;
        loadOptions: any;
        visible: boolean;
        opacity: number;
        extensions: any[];
        pickable: boolean;
        getDashArray: [number, number];
        dashJustified: boolean;
        dashGapPickable: boolean;
        getOffset: number | (() => number);
        clipBounds: [number, number, number, number];
        maskId: string;
        maskByInstance: boolean;
        maskInverted: boolean;
        operation: "mask";
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeckPathLayer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeckPathLayer, "oui-deck-path-layer", never, { "options": { "alias": "options"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=deck-path-layer.d.ts.map