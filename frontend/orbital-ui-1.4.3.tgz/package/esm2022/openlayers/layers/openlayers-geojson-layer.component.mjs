import { ChangeDetectionStrategy, Component, computed, input, signal, } from '@angular/core';
import { isFunction } from 'lodash-es';
import { OpenlayersBaseLayerComponent } from './openlayers-base-layer.component';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import { GeoJSON } from 'ol/format';
import { Circle, Fill, Stroke, Style } from 'ol/style';
import { mixRgbaColors } from '../color-mixer';
import { DEFAULT_COMMON_OPTIONS } from '../constants';
import * as i0 from "@angular/core";
export class OpenlayersGeoJsonLayerComponent extends OpenlayersBaseLayerComponent {
    options = input.required();
    combinedOptions = computed(() => {
        return {
            ...DEFAULT_COMMON_OPTIONS,
            ...{
                getFillColor: [255, 0, 0, 255],
                getStrokeColor: [0, 0, 0, 255],
                filled: true,
                stroked: true,
                autoHighlight: true,
                highlightColor: [255, 255, 255, 255],
            },
            ...this.options(),
        };
    });
    source = signal(new VectorSource());
    layer = signal(new VectorLayer({
        source: this.source(),
        style: feature => {
            return this.getStyleForFeature(feature);
        },
    }));
    constructor() {
        super();
    }
    getStyleForFeature(feature, isHighlighted = false) {
        const fillColor = this.combinedOptions().getFillColor;
        let actualFillColor = fillColor instanceof Function
            ? [...fillColor(feature)]
            : [...fillColor];
        actualFillColor[3] = actualFillColor[3] / 255;
        const highlightColor = this.combinedOptions().highlightColor;
        if (isHighlighted && highlightColor) {
            actualFillColor = mixRgbaColors(actualFillColor, highlightColor);
        }
        const strokeColorAccessor = isFunction(this.combinedOptions().getStrokeColor)
            ? this.combinedOptions().getStrokeColor
            : this.combinedOptions().getStrokeColor;
        const strokeColor = strokeColorAccessor instanceof Function
            ? strokeColorAccessor(feature)
            : [...strokeColorAccessor];
        strokeColor[3] = strokeColor[3] / 255;
        const lineWidth = isFunction(this.combinedOptions().getLineWidth)
            ? this.combinedOptions().getLineWidth(feature)
            : this.combinedOptions().getLineWidth;
        const type = feature.getGeometry()?.getType();
        if (type === 'Point') {
            return new Style({
                image: new Circle({
                    radius: this.combinedOptions().pointRadius ?? 5,
                    fill: new Fill({
                        color: `rgba(${actualFillColor.join(',')})`,
                    }),
                    stroke: new Stroke({
                        color: `rgba(${strokeColor.join(',')})`,
                        width: lineWidth,
                    }),
                }),
            });
        }
        else if (type === 'LineString') {
            return new Style({
                stroke: new Stroke({
                    color: `rgba(${strokeColor.join(',')})`,
                    width: lineWidth,
                }),
            });
        }
        else if (type === 'Polygon') {
            return new Style({
                fill: new Fill({
                    color: `rgba(${actualFillColor.join(',')})`,
                }),
                stroke: new Stroke({
                    color: `rgba(${strokeColor.join(',')})`,
                    width: lineWidth,
                }),
            });
        }
        else if (type === 'MultiPolygon') {
            return new Style({
                fill: new Fill({
                    color: `rgba(${actualFillColor.join(',')})`,
                }),
                stroke: new Stroke({
                    color: `rgba(${strokeColor.join(',')})`,
                    width: lineWidth,
                }),
            });
        }
        else {
            return new Style();
        }
    }
    onHover(feature) {
        super.onHover(feature);
        if (this.combinedOptions().autoHighlight) {
            feature.setStyle(this.getStyleForFeature(feature, true));
        }
    }
    onUnHover(feature) {
        super.onUnHover(feature);
        if (this.combinedOptions().autoHighlight) {
            feature.setStyle(this.getStyleForFeature(feature));
        }
    }
    updateLayer() {
        const dataWithLayer = {
            ...this.combinedOptions().data,
            features: this.combinedOptions().data.features.map((feature) => {
                return {
                    ...feature,
                    properties: {
                        ...feature.properties,
                        layer: this,
                    },
                };
            }),
        };
        this.layer().setZIndex(this.combinedOptions().order ?? 0);
        this.source().clear(true);
        this.source().addFeatures(new GeoJSON().readFeatures(dataWithLayer, {
            featureProjection: 'EPSG:3857', // Ensure the projection matches your map's projection
        }));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersGeoJsonLayerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "17.3.1", type: OpenlayersGeoJsonLayerComponent, isStandalone: true, selector: "oui-openlayers-geojson-layer", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, providers: [
            {
                provide: OpenlayersBaseLayerComponent,
                useExisting: OpenlayersGeoJsonLayerComponent,
            },
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersGeoJsonLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-openlayers-geojson-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [
                        {
                            provide: OpenlayersBaseLayerComponent,
                            useExisting: OpenlayersGeoJsonLayerComponent,
                        },
                    ],
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BlbmxheWVycy1nZW9qc29uLWxheWVyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvb3BlbmxheWVycy9sYXllcnMvb3BlbmxheWVycy1nZW9qc29uLWxheWVyLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ0wsdUJBQXVCLEVBQ3ZCLFNBQVMsRUFDVCxRQUFRLEVBQ1IsS0FBSyxFQUNMLE1BQU0sR0FDUCxNQUFNLGVBQWUsQ0FBQztBQUl2QixPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sV0FBVyxDQUFDO0FBQ3ZDLE9BQU8sRUFBRSw0QkFBNEIsRUFBRSxNQUFNLG1DQUFtQyxDQUFDO0FBQ2pGLE9BQU8sV0FBVyxNQUFNLGlCQUFpQixDQUFDO0FBQzFDLE9BQU8sWUFBWSxNQUFNLGtCQUFrQixDQUFDO0FBQzVDLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFDcEMsT0FBTyxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEtBQUssRUFBRSxNQUFNLFVBQVUsQ0FBQztBQUd2RCxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sZ0JBQWdCLENBQUM7QUFDL0MsT0FBTyxFQUFFLHNCQUFzQixFQUFFLE1BQU0sY0FBYyxDQUFDOztBQWV0RCxNQUFNLE9BQU8sK0JBQWdDLFNBQVEsNEJBQThEO0lBQ2pHLE9BQU8sR0FBRyxLQUFLLENBQUMsUUFBUSxFQUFvQyxDQUFDO0lBQ3RFLGVBQWUsR0FBRyxRQUFRLENBQUMsR0FBRyxFQUFFO1FBQ3JDLE9BQU87WUFDTCxHQUFHLHNCQUFzQjtZQUN6QixHQUFHO2dCQUNELFlBQVksRUFBRSxDQUFDLEdBQUcsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBUztnQkFDdEMsY0FBYyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsR0FBRyxDQUFTO2dCQUN0QyxNQUFNLEVBQUUsSUFBSTtnQkFDWixPQUFPLEVBQUUsSUFBSTtnQkFDYixhQUFhLEVBQUUsSUFBSTtnQkFDbkIsY0FBYyxFQUFFLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxDQUFTO2FBQzdDO1lBQ0QsR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFO1NBQ2xCLENBQUM7SUFDSixDQUFDLENBQUMsQ0FBQztJQUVJLE1BQU0sR0FBRyxNQUFNLENBQWUsSUFBSSxZQUFZLEVBQUUsQ0FBQyxDQUFDO0lBQ2xELEtBQUssR0FBRyxNQUFNLENBQ25CLElBQUksV0FBVyxDQUFDO1FBQ2QsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUU7UUFDckIsS0FBSyxFQUFFLE9BQU8sQ0FBQyxFQUFFO1lBQ2YsT0FBTyxJQUFJLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDMUMsQ0FBQztLQUNGLENBQUMsQ0FDSCxDQUFDO0lBRUY7UUFDRSxLQUFLLEVBQUUsQ0FBQztJQUNWLENBQUM7SUFFTyxrQkFBa0IsQ0FBQyxPQUFvQixFQUFFLGFBQWEsR0FBRyxLQUFLO1FBQ3BFLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxZQUFZLENBQUM7UUFDdEQsSUFBSSxlQUFlLEdBQ2pCLFNBQVMsWUFBWSxRQUFRO1lBQzNCLENBQUMsQ0FBRSxDQUFDLEdBQUksU0FBc0IsQ0FBQyxPQUFPLENBQUMsQ0FBVTtZQUNqRCxDQUFDLENBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBVSxDQUFDO1FBQy9CLGVBQWUsQ0FBQyxDQUFDLENBQUMsR0FBRyxlQUFlLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1FBQzlDLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxjQUFjLENBQUM7UUFDN0QsSUFBSSxhQUFhLElBQUksY0FBYyxFQUFFLENBQUM7WUFDcEMsZUFBZSxHQUFHLGFBQWEsQ0FBQyxlQUFlLEVBQUUsY0FBYyxDQUFDLENBQUM7UUFDbkUsQ0FBQztRQUVELE1BQU0sbUJBQW1CLEdBQUcsVUFBVSxDQUNwQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsY0FBYyxDQUN0QztZQUNDLENBQUMsQ0FBRSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsY0FBMkI7WUFDckQsQ0FBQyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxjQUFjLENBQUM7UUFDMUMsTUFBTSxXQUFXLEdBQ2YsbUJBQW1CLFlBQVksUUFBUTtZQUNyQyxDQUFDLENBQUUsbUJBQWdDLENBQUMsT0FBTyxDQUFDO1lBQzVDLENBQUMsQ0FBQyxDQUFDLEdBQUksbUJBQTRCLENBQUMsQ0FBQztRQUV6QyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztRQUN0QyxNQUFNLFNBQVMsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLFlBQVksQ0FBQztZQUMvRCxDQUFDLENBQUUsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLFlBQXlCLENBQUMsT0FBTyxDQUFDO1lBQzVELENBQUMsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsWUFBWSxDQUFDO1FBQ3hDLE1BQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxXQUFXLEVBQUUsRUFBRSxPQUFPLEVBQUUsQ0FBQztRQUU5QyxJQUFJLElBQUksS0FBSyxPQUFPLEVBQUUsQ0FBQztZQUNyQixPQUFPLElBQUksS0FBSyxDQUFDO2dCQUNmLEtBQUssRUFBRSxJQUFJLE1BQU0sQ0FBQztvQkFDaEIsTUFBTSxFQUFFLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxXQUFXLElBQUksQ0FBQztvQkFDL0MsSUFBSSxFQUFFLElBQUksSUFBSSxDQUFDO3dCQUNiLEtBQUssRUFBRSxRQUFRLGVBQWUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUc7cUJBQzVDLENBQUM7b0JBQ0YsTUFBTSxFQUFFLElBQUksTUFBTSxDQUFDO3dCQUNqQixLQUFLLEVBQUUsUUFBUSxXQUFXLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHO3dCQUN2QyxLQUFLLEVBQUUsU0FBUztxQkFDakIsQ0FBQztpQkFDSCxDQUFDO2FBQ0gsQ0FBQyxDQUFDO1FBQ0wsQ0FBQzthQUFNLElBQUksSUFBSSxLQUFLLFlBQVksRUFBRSxDQUFDO1lBQ2pDLE9BQU8sSUFBSSxLQUFLLENBQUM7Z0JBQ2YsTUFBTSxFQUFFLElBQUksTUFBTSxDQUFDO29CQUNqQixLQUFLLEVBQUUsUUFBUSxXQUFXLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHO29CQUN2QyxLQUFLLEVBQUUsU0FBUztpQkFDakIsQ0FBQzthQUNILENBQUMsQ0FBQztRQUNMLENBQUM7YUFBTSxJQUFJLElBQUksS0FBSyxTQUFTLEVBQUUsQ0FBQztZQUM5QixPQUFPLElBQUksS0FBSyxDQUFDO2dCQUNmLElBQUksRUFBRSxJQUFJLElBQUksQ0FBQztvQkFDYixLQUFLLEVBQUUsUUFBUSxlQUFlLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHO2lCQUM1QyxDQUFDO2dCQUNGLE1BQU0sRUFBRSxJQUFJLE1BQU0sQ0FBQztvQkFDakIsS0FBSyxFQUFFLFFBQVEsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRztvQkFDdkMsS0FBSyxFQUFFLFNBQVM7aUJBQ2pCLENBQUM7YUFDSCxDQUFDLENBQUM7UUFDTCxDQUFDO2FBQU0sSUFBSSxJQUFJLEtBQUssY0FBYyxFQUFFLENBQUM7WUFDbkMsT0FBTyxJQUFJLEtBQUssQ0FBQztnQkFDZixJQUFJLEVBQUUsSUFBSSxJQUFJLENBQUM7b0JBQ2IsS0FBSyxFQUFFLFFBQVEsZUFBZSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRztpQkFDNUMsQ0FBQztnQkFDRixNQUFNLEVBQUUsSUFBSSxNQUFNLENBQUM7b0JBQ2pCLEtBQUssRUFBRSxRQUFRLFdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUc7b0JBQ3ZDLEtBQUssRUFBRSxTQUFTO2lCQUNqQixDQUFDO2FBQ0gsQ0FBQyxDQUFDO1FBQ0wsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLElBQUksS0FBSyxFQUFFLENBQUM7UUFDckIsQ0FBQztJQUNILENBQUM7SUFFZSxPQUFPLENBQUMsT0FBa0I7UUFDeEMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN2QixJQUFJLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUN6QyxPQUFPLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUMzRCxDQUFDO0lBQ0gsQ0FBQztJQUVlLFNBQVMsQ0FBQyxPQUFrQjtRQUMxQyxLQUFLLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3pCLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3pDLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7UUFDckQsQ0FBQztJQUNILENBQUM7SUFFTSxXQUFXO1FBQ2hCLE1BQU0sYUFBYSxHQUFHO1lBQ3BCLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDLElBQUk7WUFDOUIsUUFBUSxFQUFFLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQWdCLEVBQUUsRUFBRTtnQkFDdEUsT0FBTztvQkFDTCxHQUFHLE9BQU87b0JBQ1YsVUFBVSxFQUFFO3dCQUNWLEdBQUcsT0FBTyxDQUFDLFVBQVU7d0JBQ3JCLEtBQUssRUFBRSxJQUFJO3FCQUNaO2lCQUNGLENBQUM7WUFDSixDQUFDLENBQUM7U0FDSCxDQUFDO1FBQ0YsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO1FBQzFELElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDMUIsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLFdBQVcsQ0FDdkIsSUFBSSxPQUFPLEVBQUUsQ0FBQyxZQUFZLENBQUMsYUFBYSxFQUFFO1lBQ3hDLGlCQUFpQixFQUFFLFdBQVcsRUFBRSxzREFBc0Q7U0FDdkYsQ0FBUSxDQUNWLENBQUM7SUFDSixDQUFDO3VHQTFJVSwrQkFBK0I7MkZBQS9CLCtCQUErQixvTkFQL0I7WUFDVDtnQkFDRSxPQUFPLEVBQUUsNEJBQTRCO2dCQUNyQyxXQUFXLEVBQUUsK0JBQStCO2FBQzdDO1NBQ0YsaURBVFMsRUFBRTs7MkZBV0QsK0JBQStCO2tCQWIzQyxTQUFTO21CQUFDO29CQUNULFFBQVEsRUFBRSw4QkFBOEI7b0JBQ3hDLFFBQVEsRUFBRSxFQUFFO29CQUNaLFVBQVUsRUFBRSxJQUFJO29CQUNoQixPQUFPLEVBQUUsRUFBRTtvQkFDWCxlQUFlLEVBQUUsdUJBQXVCLENBQUMsTUFBTTtvQkFDL0MsU0FBUyxFQUFFO3dCQUNUOzRCQUNFLE9BQU8sRUFBRSw0QkFBNEI7NEJBQ3JDLFdBQVcsaUNBQWlDO3lCQUM3QztxQkFDRjtpQkFDRiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LFxuICBDb21wb25lbnQsXG4gIGNvbXB1dGVkLFxuICBpbnB1dCxcbiAgc2lnbmFsLFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZlYXR1cmUsIEZlYXR1cmVDb2xsZWN0aW9uIH0gZnJvbSAnQHR1cmYvaGVscGVycyc7XG5pbXBvcnQgeyBGZWF0dXJlIGFzIE9sRmVhdHVyZSB9IGZyb20gJ29sJztcbmltcG9ydCB7IFJHQkEgfSBmcm9tICdvcmJpdGFsLXVpL2NvcmUnO1xuaW1wb3J0IHsgaXNGdW5jdGlvbiB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBPcGVubGF5ZXJzQmFzZUxheWVyQ29tcG9uZW50IH0gZnJvbSAnLi9vcGVubGF5ZXJzLWJhc2UtbGF5ZXIuY29tcG9uZW50JztcbmltcG9ydCBWZWN0b3JMYXllciBmcm9tICdvbC9sYXllci9WZWN0b3InO1xuaW1wb3J0IFZlY3RvclNvdXJjZSBmcm9tICdvbC9zb3VyY2UvVmVjdG9yJztcbmltcG9ydCB7IEdlb0pTT04gfSBmcm9tICdvbC9mb3JtYXQnO1xuaW1wb3J0IHsgQ2lyY2xlLCBGaWxsLCBTdHJva2UsIFN0eWxlIH0gZnJvbSAnb2wvc3R5bGUnO1xuaW1wb3J0IHsgRmVhdHVyZUxpa2UgfSBmcm9tICdvbC9GZWF0dXJlJztcbmltcG9ydCB7IE91aU9wZW5sYXllcnNHZW9Kc29uTGF5ZXJPcHRpb25zIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgbWl4UmdiYUNvbG9ycyB9IGZyb20gJy4uL2NvbG9yLW1peGVyJztcbmltcG9ydCB7IERFRkFVTFRfQ09NTU9OX09QVElPTlMgfSBmcm9tICcuLi9jb25zdGFudHMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdvdWktb3BlbmxheWVycy1nZW9qc29uLWxheWVyJyxcbiAgdGVtcGxhdGU6ICcnLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG4gIHByb3ZpZGVyczogW1xuICAgIHtcbiAgICAgIHByb3ZpZGU6IE9wZW5sYXllcnNCYXNlTGF5ZXJDb21wb25lbnQsXG4gICAgICB1c2VFeGlzdGluZzogT3BlbmxheWVyc0dlb0pzb25MYXllckNvbXBvbmVudCxcbiAgICB9LFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBPcGVubGF5ZXJzR2VvSnNvbkxheWVyQ29tcG9uZW50IGV4dGVuZHMgT3BlbmxheWVyc0Jhc2VMYXllckNvbXBvbmVudDxPdWlPcGVubGF5ZXJzR2VvSnNvbkxheWVyT3B0aW9ucz4ge1xuICBwdWJsaWMgb3ZlcnJpZGUgb3B0aW9ucyA9IGlucHV0LnJlcXVpcmVkPE91aU9wZW5sYXllcnNHZW9Kc29uTGF5ZXJPcHRpb25zPigpO1xuICBwdWJsaWMgY29tYmluZWRPcHRpb25zID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5ERUZBVUxUX0NPTU1PTl9PUFRJT05TLFxuICAgICAgLi4ue1xuICAgICAgICBnZXRGaWxsQ29sb3I6IFsyNTUsIDAsIDAsIDI1NV0gYXMgUkdCQSxcbiAgICAgICAgZ2V0U3Ryb2tlQ29sb3I6IFswLCAwLCAwLCAyNTVdIGFzIFJHQkEsXG4gICAgICAgIGZpbGxlZDogdHJ1ZSxcbiAgICAgICAgc3Ryb2tlZDogdHJ1ZSxcbiAgICAgICAgYXV0b0hpZ2hsaWdodDogdHJ1ZSxcbiAgICAgICAgaGlnaGxpZ2h0Q29sb3I6IFsyNTUsIDI1NSwgMjU1LCAyNTVdIGFzIFJHQkEsXG4gICAgICB9LFxuICAgICAgLi4udGhpcy5vcHRpb25zKCksXG4gICAgfTtcbiAgfSk7XG5cbiAgcHVibGljIHNvdXJjZSA9IHNpZ25hbDxWZWN0b3JTb3VyY2U+KG5ldyBWZWN0b3JTb3VyY2UoKSk7XG4gIHB1YmxpYyBsYXllciA9IHNpZ25hbDxWZWN0b3JMYXllcjxWZWN0b3JTb3VyY2U+PihcbiAgICBuZXcgVmVjdG9yTGF5ZXIoe1xuICAgICAgc291cmNlOiB0aGlzLnNvdXJjZSgpLFxuICAgICAgc3R5bGU6IGZlYXR1cmUgPT4ge1xuICAgICAgICByZXR1cm4gdGhpcy5nZXRTdHlsZUZvckZlYXR1cmUoZmVhdHVyZSk7XG4gICAgICB9LFxuICAgIH0pXG4gICk7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHByaXZhdGUgZ2V0U3R5bGVGb3JGZWF0dXJlKGZlYXR1cmU6IEZlYXR1cmVMaWtlLCBpc0hpZ2hsaWdodGVkID0gZmFsc2UpIHtcbiAgICBjb25zdCBmaWxsQ29sb3IgPSB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmdldEZpbGxDb2xvcjtcbiAgICBsZXQgYWN0dWFsRmlsbENvbG9yID1cbiAgICAgIGZpbGxDb2xvciBpbnN0YW5jZW9mIEZ1bmN0aW9uXG4gICAgICAgID8gKFsuLi4oZmlsbENvbG9yIGFzIEZ1bmN0aW9uKShmZWF0dXJlKV0gYXMgUkdCQSlcbiAgICAgICAgOiAoWy4uLmZpbGxDb2xvcl0gYXMgUkdCQSk7XG4gICAgYWN0dWFsRmlsbENvbG9yWzNdID0gYWN0dWFsRmlsbENvbG9yWzNdIC8gMjU1O1xuICAgIGNvbnN0IGhpZ2hsaWdodENvbG9yID0gdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5oaWdobGlnaHRDb2xvcjtcbiAgICBpZiAoaXNIaWdobGlnaHRlZCAmJiBoaWdobGlnaHRDb2xvcikge1xuICAgICAgYWN0dWFsRmlsbENvbG9yID0gbWl4UmdiYUNvbG9ycyhhY3R1YWxGaWxsQ29sb3IsIGhpZ2hsaWdodENvbG9yKTtcbiAgICB9XG5cbiAgICBjb25zdCBzdHJva2VDb2xvckFjY2Vzc29yID0gaXNGdW5jdGlvbihcbiAgICAgIHRoaXMuY29tYmluZWRPcHRpb25zKCkuZ2V0U3Ryb2tlQ29sb3JcbiAgICApXG4gICAgICA/ICh0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmdldFN0cm9rZUNvbG9yIGFzIEZ1bmN0aW9uKVxuICAgICAgOiB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmdldFN0cm9rZUNvbG9yO1xuICAgIGNvbnN0IHN0cm9rZUNvbG9yID1cbiAgICAgIHN0cm9rZUNvbG9yQWNjZXNzb3IgaW5zdGFuY2VvZiBGdW5jdGlvblxuICAgICAgICA/IChzdHJva2VDb2xvckFjY2Vzc29yIGFzIEZ1bmN0aW9uKShmZWF0dXJlKVxuICAgICAgICA6IFsuLi4oc3Ryb2tlQ29sb3JBY2Nlc3NvciBhcyBSR0JBKV07XG5cbiAgICBzdHJva2VDb2xvclszXSA9IHN0cm9rZUNvbG9yWzNdIC8gMjU1O1xuICAgIGNvbnN0IGxpbmVXaWR0aCA9IGlzRnVuY3Rpb24odGhpcy5jb21iaW5lZE9wdGlvbnMoKS5nZXRMaW5lV2lkdGgpXG4gICAgICA/ICh0aGlzLmNvbWJpbmVkT3B0aW9ucygpLmdldExpbmVXaWR0aCBhcyBGdW5jdGlvbikoZmVhdHVyZSlcbiAgICAgIDogdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5nZXRMaW5lV2lkdGg7XG4gICAgY29uc3QgdHlwZSA9IGZlYXR1cmUuZ2V0R2VvbWV0cnkoKT8uZ2V0VHlwZSgpO1xuXG4gICAgaWYgKHR5cGUgPT09ICdQb2ludCcpIHtcbiAgICAgIHJldHVybiBuZXcgU3R5bGUoe1xuICAgICAgICBpbWFnZTogbmV3IENpcmNsZSh7XG4gICAgICAgICAgcmFkaXVzOiB0aGlzLmNvbWJpbmVkT3B0aW9ucygpLnBvaW50UmFkaXVzID8/IDUsXG4gICAgICAgICAgZmlsbDogbmV3IEZpbGwoe1xuICAgICAgICAgICAgY29sb3I6IGByZ2JhKCR7YWN0dWFsRmlsbENvbG9yLmpvaW4oJywnKX0pYCxcbiAgICAgICAgICB9KSxcbiAgICAgICAgICBzdHJva2U6IG5ldyBTdHJva2Uoe1xuICAgICAgICAgICAgY29sb3I6IGByZ2JhKCR7c3Ryb2tlQ29sb3Iuam9pbignLCcpfSlgLFxuICAgICAgICAgICAgd2lkdGg6IGxpbmVXaWR0aCxcbiAgICAgICAgICB9KSxcbiAgICAgICAgfSksXG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKHR5cGUgPT09ICdMaW5lU3RyaW5nJykge1xuICAgICAgcmV0dXJuIG5ldyBTdHlsZSh7XG4gICAgICAgIHN0cm9rZTogbmV3IFN0cm9rZSh7XG4gICAgICAgICAgY29sb3I6IGByZ2JhKCR7c3Ryb2tlQ29sb3Iuam9pbignLCcpfSlgLFxuICAgICAgICAgIHdpZHRoOiBsaW5lV2lkdGgsXG4gICAgICAgIH0pLFxuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmICh0eXBlID09PSAnUG9seWdvbicpIHtcbiAgICAgIHJldHVybiBuZXcgU3R5bGUoe1xuICAgICAgICBmaWxsOiBuZXcgRmlsbCh7XG4gICAgICAgICAgY29sb3I6IGByZ2JhKCR7YWN0dWFsRmlsbENvbG9yLmpvaW4oJywnKX0pYCxcbiAgICAgICAgfSksXG4gICAgICAgIHN0cm9rZTogbmV3IFN0cm9rZSh7XG4gICAgICAgICAgY29sb3I6IGByZ2JhKCR7c3Ryb2tlQ29sb3Iuam9pbignLCcpfSlgLFxuICAgICAgICAgIHdpZHRoOiBsaW5lV2lkdGgsXG4gICAgICAgIH0pLFxuICAgICAgfSk7XG4gICAgfSBlbHNlIGlmICh0eXBlID09PSAnTXVsdGlQb2x5Z29uJykge1xuICAgICAgcmV0dXJuIG5ldyBTdHlsZSh7XG4gICAgICAgIGZpbGw6IG5ldyBGaWxsKHtcbiAgICAgICAgICBjb2xvcjogYHJnYmEoJHthY3R1YWxGaWxsQ29sb3Iuam9pbignLCcpfSlgLFxuICAgICAgICB9KSxcbiAgICAgICAgc3Ryb2tlOiBuZXcgU3Ryb2tlKHtcbiAgICAgICAgICBjb2xvcjogYHJnYmEoJHtzdHJva2VDb2xvci5qb2luKCcsJyl9KWAsXG4gICAgICAgICAgd2lkdGg6IGxpbmVXaWR0aCxcbiAgICAgICAgfSksXG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIG5ldyBTdHlsZSgpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBvdmVycmlkZSBvbkhvdmVyKGZlYXR1cmU6IE9sRmVhdHVyZSkge1xuICAgIHN1cGVyLm9uSG92ZXIoZmVhdHVyZSk7XG4gICAgaWYgKHRoaXMuY29tYmluZWRPcHRpb25zKCkuYXV0b0hpZ2hsaWdodCkge1xuICAgICAgZmVhdHVyZS5zZXRTdHlsZSh0aGlzLmdldFN0eWxlRm9yRmVhdHVyZShmZWF0dXJlLCB0cnVlKSk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG92ZXJyaWRlIG9uVW5Ib3ZlcihmZWF0dXJlOiBPbEZlYXR1cmUpIHtcbiAgICBzdXBlci5vblVuSG92ZXIoZmVhdHVyZSk7XG4gICAgaWYgKHRoaXMuY29tYmluZWRPcHRpb25zKCkuYXV0b0hpZ2hsaWdodCkge1xuICAgICAgZmVhdHVyZS5zZXRTdHlsZSh0aGlzLmdldFN0eWxlRm9yRmVhdHVyZShmZWF0dXJlKSk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIHVwZGF0ZUxheWVyKCkge1xuICAgIGNvbnN0IGRhdGFXaXRoTGF5ZXIgPSB7XG4gICAgICAuLi50aGlzLmNvbWJpbmVkT3B0aW9ucygpLmRhdGEsXG4gICAgICBmZWF0dXJlczogdGhpcy5jb21iaW5lZE9wdGlvbnMoKS5kYXRhLmZlYXR1cmVzLm1hcCgoZmVhdHVyZTogRmVhdHVyZSkgPT4ge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIC4uLmZlYXR1cmUsXG4gICAgICAgICAgcHJvcGVydGllczoge1xuICAgICAgICAgICAgLi4uZmVhdHVyZS5wcm9wZXJ0aWVzLFxuICAgICAgICAgICAgbGF5ZXI6IHRoaXMsXG4gICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICAgIH0pLFxuICAgIH07XG4gICAgdGhpcy5sYXllcigpLnNldFpJbmRleCh0aGlzLmNvbWJpbmVkT3B0aW9ucygpLm9yZGVyID8/IDApO1xuICAgIHRoaXMuc291cmNlKCkuY2xlYXIodHJ1ZSk7XG4gICAgdGhpcy5zb3VyY2UoKS5hZGRGZWF0dXJlcyhcbiAgICAgIG5ldyBHZW9KU09OKCkucmVhZEZlYXR1cmVzKGRhdGFXaXRoTGF5ZXIsIHtcbiAgICAgICAgZmVhdHVyZVByb2plY3Rpb246ICdFUFNHOjM4NTcnLCAvLyBFbnN1cmUgdGhlIHByb2plY3Rpb24gbWF0Y2hlcyB5b3VyIG1hcCdzIHByb2plY3Rpb25cbiAgICAgIH0pIGFzIGFueVxuICAgICk7XG4gIH1cbn1cbiJdfQ==