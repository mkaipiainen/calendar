import * as i0 from '@angular/core';
import { ViewContainerRef, Component, ViewChild, Injectable, Inject } from '@angular/core';
import { ComponentCreator, GUID } from 'orbital-ui/helpers';
import { OuiIconComponent } from 'orbital-ui/icon';
import { DOCUMENT } from '@angular/common';

/**
 * Not used directly, only triggered through ouiToastService. A component to display toast-messages to the user.
 */
class OuiToastComponent {
    toastService;
    cdr;
    options;
    contentRef;
    contentVCR;
    show = true;
    toastIcon;
    toastIconOptions = {
        size: '14px',
        viewBox: '0 0 48 48',
    };
    constructor(toastService, cdr) {
        this.toastService = toastService;
        this.cdr = cdr;
    }
    ngAfterViewInit() {
        if (typeof this.options.content === 'string') {
            this.contentRef.nativeElement.innerHTML = this.options.content;
            if (this.options.type === 'success') {
                this.toastIcon = 'assets/icons/check.svg';
                this.toastIconOptions.fillColor = 'color-success-text';
                this.toastIconOptions.strokeColor = 'color-success-text';
            }
            else if (this.options.type === 'warning') {
                this.toastIcon = 'assets/icons/exclamation.svg';
                this.toastIconOptions.fillColor = 'color-warning-text';
                this.toastIconOptions.strokeColor = 'color-warning-text';
            }
            else if (this.options.type === 'info') {
                this.toastIcon = 'assets/icons/info_no_circle.svg';
                this.toastIconOptions.fillColor = 'color-info-text';
                this.toastIconOptions.strokeColor = 'color-info-text';
                this.toastIconOptions.viewBox = '0 0 192 512';
            }
            else if (this.options.type === 'error') {
                this.toastIcon = 'assets/icons/exclamation.svg';
                this.toastIconOptions.fillColor = 'color-danger-text';
                this.toastIconOptions.strokeColor = 'color-danger-text';
            }
        }
        else {
            const createComponentOptions = {
                component: this.options.content,
                viewContainerRef: this.contentVCR,
            };
            const componentRef = ComponentCreator.createComponent(createComponentOptions);
            if (this.options.inputs) {
                for (const input in this.options.inputs) {
                    componentRef.setInput(input, this.options.inputs[input]);
                }
            }
        }
        this.cdr.detectChanges();
    }
    disable() {
        if (this.options.hideOnClick) {
            this.toastService.disable(this.options.id);
        }
    }
    close() {
        this.toastService.disable(this.options.id);
    }
    getType() {
        switch (this.options.type) {
            case 'success':
                return 'bg-color-success';
            case 'error':
                return 'bg-color-danger';
            case 'warning':
                return 'bg-color-warning';
            case 'info':
                return 'bg-color-info';
            default:
                return 'bg-color-transparent';
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiToastComponent, deps: [{ token: OuiToastService }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiToastComponent, isStandalone: true, selector: "oui-toast", viewQueries: [{ propertyName: "contentRef", first: true, predicate: ["contentRef"], descendants: true }, { propertyName: "contentVCR", first: true, predicate: ["contentRef"], descendants: true, read: ViewContainerRef }], ngImport: i0, template: "<div class=\"toast {{ options.type }}\" (click)=\"disable()\" id=\"Toast\">\n  <div class=\"main-toast\">\n    <div class=\"toast-icon\">\n      <div class=\"icon-wrapper\">\n        @if (toastIcon) {\n          <oui-icon\n            [icon]=\"toastIcon\"\n            [options]=\"toastIconOptions\"\n          ></oui-icon>\n        }\n      </div>\n    </div>\n    <div class=\"content\" #contentRef></div>\n    @if (options.xToClose) {\n      <oui-icon\n        class=\"close-icon\"\n        icon=\"assets/icons/close.svg\"\n        [options]=\"toastIconOptions\"\n        (click)=\"close()\"\n      ></oui-icon>\n    }\n  </div>\n</div>\n", styles: [":host{transition:opacity 1s,transform .5s;transition-timing-function:ease-in-elastic;opacity:0;min-height:5rem;display:flex;min-width:35rem;box-shadow:0 0 4px #0000004d;margin-bottom:10px}:host .toast{flex:1;padding:6px;border-radius:4px;display:flex;width:80%}:host .toast .main-toast{padding:1rem;width:100%;display:flex;border-radius:var(--border-radius-default);background-color:var(--color-background)}:host .toast .main-toast .content{overflow-wrap:break-word}:host .toast .main-toast .toast-icon{display:flex;justify-content:center;align-items:center}:host .toast .main-toast .toast-icon .icon-wrapper{border-radius:50%;display:flex;justify-content:center;align-items:center;margin-right:1rem;width:2rem;height:2rem}:host .toast .main-toast .close-icon{position:absolute;top:0;right:0;padding:1rem}:host .toast .main-toast .close-icon:hover{cursor:pointer}:host .toast.error{background-color:var(--color-danger)}:host .toast.error .toast-icon .icon-wrapper{background-color:var(--color-danger)}:host .toast.error .main-toast{background-color:var(--color-danger);color:var(--color-danger-text)}:host .toast.info{background-color:var(--color-info)}:host .toast.info .toast-icon .icon-wrapper{background-color:var(--color-info)}:host .toast.info .main-toast{background-color:var(--color-info);color:var(--color-info-text)}:host .toast.success{background-color:var(--color-success)}:host .toast.success .toast-icon .icon-wrapper{background-color:var(--color-success)}:host .toast.success .main-toast{background-color:var(--color-success);color:var(--color-success-text)}:host .toast.warning{background-color:var(--color-warning)}:host .toast.warning .toast-icon .icon-wrapper{background-color:var(--color-warning)}:host .toast.warning .main-toast{background-color:var(--color-warning);color:var(--color-warning-text)}:host .toast .main-toast{display:flex;align-items:center;color:var(--color-light)}:host.show{opacity:1}:host.remove-to-right{transition:opacity 2s,transform 1s cubic-bezier(.62,-.33,.17,1.03);transform:translate(200%)}:host.remove-to-left{transition:opacity 2s,transform 1s cubic-bezier(.62,-.33,.17,1.03);transform:translate(-200%)}:host.remove-to-top{transition:opacity 2s,transform 1s cubic-bezier(.62,-.33,.17,1.03);transform:translateY(-400px)}:host.remove-to-bottom{transition:opacity 2s,transform 1s cubic-bezier(.62,-.33,.17,1.03);transform:translateY(400px)}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiToastComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-toast', standalone: true, imports: [OuiIconComponent], template: "<div class=\"toast {{ options.type }}\" (click)=\"disable()\" id=\"Toast\">\n  <div class=\"main-toast\">\n    <div class=\"toast-icon\">\n      <div class=\"icon-wrapper\">\n        @if (toastIcon) {\n          <oui-icon\n            [icon]=\"toastIcon\"\n            [options]=\"toastIconOptions\"\n          ></oui-icon>\n        }\n      </div>\n    </div>\n    <div class=\"content\" #contentRef></div>\n    @if (options.xToClose) {\n      <oui-icon\n        class=\"close-icon\"\n        icon=\"assets/icons/close.svg\"\n        [options]=\"toastIconOptions\"\n        (click)=\"close()\"\n      ></oui-icon>\n    }\n  </div>\n</div>\n", styles: [":host{transition:opacity 1s,transform .5s;transition-timing-function:ease-in-elastic;opacity:0;min-height:5rem;display:flex;min-width:35rem;box-shadow:0 0 4px #0000004d;margin-bottom:10px}:host .toast{flex:1;padding:6px;border-radius:4px;display:flex;width:80%}:host .toast .main-toast{padding:1rem;width:100%;display:flex;border-radius:var(--border-radius-default);background-color:var(--color-background)}:host .toast .main-toast .content{overflow-wrap:break-word}:host .toast .main-toast .toast-icon{display:flex;justify-content:center;align-items:center}:host .toast .main-toast .toast-icon .icon-wrapper{border-radius:50%;display:flex;justify-content:center;align-items:center;margin-right:1rem;width:2rem;height:2rem}:host .toast .main-toast .close-icon{position:absolute;top:0;right:0;padding:1rem}:host .toast .main-toast .close-icon:hover{cursor:pointer}:host .toast.error{background-color:var(--color-danger)}:host .toast.error .toast-icon .icon-wrapper{background-color:var(--color-danger)}:host .toast.error .main-toast{background-color:var(--color-danger);color:var(--color-danger-text)}:host .toast.info{background-color:var(--color-info)}:host .toast.info .toast-icon .icon-wrapper{background-color:var(--color-info)}:host .toast.info .main-toast{background-color:var(--color-info);color:var(--color-info-text)}:host .toast.success{background-color:var(--color-success)}:host .toast.success .toast-icon .icon-wrapper{background-color:var(--color-success)}:host .toast.success .main-toast{background-color:var(--color-success);color:var(--color-success-text)}:host .toast.warning{background-color:var(--color-warning)}:host .toast.warning .toast-icon .icon-wrapper{background-color:var(--color-warning)}:host .toast.warning .main-toast{background-color:var(--color-warning);color:var(--color-warning-text)}:host .toast .main-toast{display:flex;align-items:center;color:var(--color-light)}:host.show{opacity:1}:host.remove-to-right{transition:opacity 2s,transform 1s cubic-bezier(.62,-.33,.17,1.03);transform:translate(200%)}:host.remove-to-left{transition:opacity 2s,transform 1s cubic-bezier(.62,-.33,.17,1.03);transform:translate(-200%)}:host.remove-to-top{transition:opacity 2s,transform 1s cubic-bezier(.62,-.33,.17,1.03);transform:translateY(-400px)}:host.remove-to-bottom{transition:opacity 2s,transform 1s cubic-bezier(.62,-.33,.17,1.03);transform:translateY(400px)}\n"] }]
        }], ctorParameters: () => [{ type: OuiToastService }, { type: i0.ChangeDetectorRef }], propDecorators: { contentRef: [{
                type: ViewChild,
                args: ['contentRef']
            }], contentVCR: [{
                type: ViewChild,
                args: ['contentRef', { read: ViewContainerRef }]
            }] } });

/**
 * Service used to display toast-messages to the user. These are messages that usually happen in response to a user-action,
 * for example saving an entity, or creating a new one, or deleting an existign one, etc.
 *
 * You can decide which corner the toast appears in, as well as things like the duration, the type of the toast, and the content.
 * Generally you only want to pass in strings as the content, but in cases where you need something totally unique, you can pass in a
 * component as well.
 *
 * Usage-example:
 *
 * this.ouiToastService.open({
 *   type: 'success',
 *   content: 'Succesfully saved the entity!',
 *   duration: 5000
 * });
 */
class OuiToastService {
    injector;
    appRef;
    rendererFactory;
    document;
    defaultOptions = {
        duration: 3000,
        hideOnClick: true,
        xToClose: false,
        position: 'top-right',
    };
    currentToasts = new Map();
    currentToastWrappers = new Map();
    renderer;
    constructor(injector, appRef, rendererFactory, document) {
        this.injector = injector;
        this.appRef = appRef;
        this.rendererFactory = rendererFactory;
        this.document = document;
        this.renderer = rendererFactory.createRenderer(null, null);
    }
    open(options, inputs, parent) {
        const combinedOptions = {
            id: GUID(),
            ...this.defaultOptions,
            ...options,
        };
        if (typeof combinedOptions.position == 'string') {
            if (!this.currentToastWrappers.has(combinedOptions.position)) {
                this.currentToastWrappers.set(combinedOptions.position, this.createWrapper(combinedOptions.position));
            }
            this.createToast(this.currentToastWrappers.get(combinedOptions.position), combinedOptions, inputs);
        }
        else if (parent) {
            this.createToast(parent.nativeElement, combinedOptions, inputs);
        }
        else {
            this.createToast(this.document.body, combinedOptions, inputs);
        }
    }
    createWrapper(position) {
        const TOASTR_DISTANCE = '5rem';
        const wrapper = this.renderer.createElement('div');
        this.renderer.addClass(wrapper, 'toastr-wrapper');
        this.renderer.setStyle(wrapper, 'display', 'flex');
        this.renderer.setStyle(wrapper, 'flexDirection', 'column');
        this.renderer.setStyle(wrapper, 'position', 'fixed');
        this.renderer.setStyle(wrapper, 'zIndex', '9999');
        switch (position) {
            case 'top':
                this.renderer.setStyle(wrapper, 'top', TOASTR_DISTANCE);
                this.renderer.setStyle(wrapper, 'left', this.document.body.getBoundingClientRect().width / 2 + 'px');
                this.renderer.setStyle(wrapper, 'transform', 'translateX(-50%)');
                break;
            case 'top-right':
                this.renderer.setStyle(wrapper, 'top', TOASTR_DISTANCE);
                this.renderer.setStyle(wrapper, 'right', TOASTR_DISTANCE);
                break;
            case 'top-left':
                this.renderer.setStyle(wrapper, 'top', TOASTR_DISTANCE);
                this.renderer.setStyle(wrapper, 'left', TOASTR_DISTANCE);
                break;
            case 'bottom':
                this.renderer.setStyle(wrapper, 'bottom', TOASTR_DISTANCE);
                this.renderer.setStyle(wrapper, 'left', this.document.body.getBoundingClientRect().width / 2 + 'px');
                this.renderer.setStyle(wrapper, 'transform', 'translateX(-50%)');
                break;
            case 'bottom-right':
                this.renderer.setStyle(wrapper, 'bottom', TOASTR_DISTANCE);
                this.renderer.setStyle(wrapper, 'right', TOASTR_DISTANCE);
                break;
            case 'bottom-left':
                this.renderer.setStyle(wrapper, 'bottom', TOASTR_DISTANCE);
                this.renderer.setStyle(wrapper, 'left', TOASTR_DISTANCE);
                break;
            case 'center':
                this.renderer.setStyle(wrapper, 'top', this.document.body.getBoundingClientRect().height / 2 -
                    wrapper.getBoundingClientRect().height / 2 +
                    'px');
                this.renderer.setStyle(wrapper, 'left', this.document.body.getBoundingClientRect().width / 2 + 'px');
                this.renderer.setStyle(wrapper, 'transform', 'translateX(-50%)');
                break;
            default:
                console.log('invalid position given for toast');
        }
        this.renderer.appendChild(this.document.body, wrapper);
        return wrapper;
    }
    createToast(wrapper, combinedOptions, inputs) {
        if (inputs) {
            combinedOptions.inputs = inputs;
        }
        const createComponentOptions = {
            component: OuiToastComponent,
            parentElement: wrapper,
            appRef: this.appRef,
            createComponentOptions: {
                environmentInjector: this.injector,
            },
            inputs: {
                options: combinedOptions,
            },
        };
        const componentRef = ComponentCreator.createComponent(createComponentOptions);
        if (typeof combinedOptions.position != 'string') {
            this.renderer.setStyle(componentRef.location.nativeElement, 'left', `${combinedOptions.position.x}px`);
            this.renderer.setStyle(componentRef.location.nativeElement, 'top', `${combinedOptions.position.y}px`);
            this.renderer.setStyle(componentRef.location.nativeElement, 'position', 'fixed');
        }
        setTimeout(() => {
            this.renderer.addClass(componentRef.location.nativeElement, 'show');
        });
        this.currentToasts.set(combinedOptions.id, componentRef);
        componentRef.changeDetectorRef.detectChanges();
        setTimeout(() => this.disable(combinedOptions.id), combinedOptions.duration);
    }
    disable(id) {
        const toast = this.currentToasts.get(id);
        if (!toast) {
            return;
        }
        const options = toast.instance.options;
        if (options.position === 'top-right' ||
            options.position === 'bottom-right') {
            this.renderer.addClass(toast.location.nativeElement, 'remove-to-right');
        }
        else if (options.position === 'top') {
            this.renderer.addClass(toast.location.nativeElement, 'remove-to-top');
        }
        else if (options.position === 'top-left' ||
            options.position === 'bottom-left') {
            this.renderer.addClass(toast.location.nativeElement, 'remove-to-left');
        }
        else if (options.position === 'bottom') {
            this.renderer.addClass(toast.location.nativeElement, 'remove-to-bottom');
        }
        this.renderer.removeClass(toast.location.nativeElement, 'show');
        setTimeout(() => {
            if (!this.currentToasts.has(id)) {
                return;
            }
            toast.destroy();
            this.currentToasts.delete(id);
        }, 1000);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiToastService, deps: [{ token: i0.EnvironmentInjector }, { token: i0.ApplicationRef }, { token: i0.RendererFactory2 }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiToastService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiToastService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i0.EnvironmentInjector }, { type: i0.ApplicationRef }, { type: i0.RendererFactory2 }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }] });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiToastComponent, OuiToastService };
//# sourceMappingURL=orbital-ui-toast.mjs.map
