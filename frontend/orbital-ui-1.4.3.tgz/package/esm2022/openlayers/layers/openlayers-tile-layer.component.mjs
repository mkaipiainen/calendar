import { ChangeDetectionStrategy, Component, computed, input, signal, } from '@angular/core';
import { OpenlayersBaseLayerComponent } from './openlayers-base-layer.component';
import { IsWmtsLayerOptions } from '../type-guards';
import TileLayer from 'ol/layer/Tile';
import { TileWMS, WMTS } from 'ol/source';
import { get, transformExtent } from 'ol/proj';
import { getTopLeft, getWidth } from 'ol/extent';
import WMTSTileGrid from 'ol/tilegrid/WMTS';
import { DEFAULT_COMMON_OPTIONS } from '../constants';
import * as i0 from "@angular/core";
export class OpenlayersTileLayerComponent extends OpenlayersBaseLayerComponent {
    options = input.required();
    olLayer = signal(undefined);
    combinedOptions = computed(() => {
        const options = this.options();
        if (IsWmtsLayerOptions(options)) {
            return {
                ...DEFAULT_COMMON_OPTIONS,
                ...{
                    pickable: false,
                    format: 'image/png',
                    style: 'default',
                    wrapX: true,
                    matrixSet: 'GoogleMapsCompatible',
                    maxZoom: 19,
                    projection: 'EPSG:3857',
                },
                ...options,
            };
        }
        else {
            return {
                ...DEFAULT_COMMON_OPTIONS,
                ...{
                    pickable: false,
                    tiled: true,
                    serverType: 'geoserver',
                    transition: 300,
                    projection: 'EPSG:3857',
                },
                ...options,
            };
        }
    });
    sourceWMS = signal(undefined);
    sourceWMTS = signal(undefined);
    activeSource = computed(() => {
        const wmsSource = this.sourceWMS();
        const wmtsSource = this.sourceWMTS();
        if (wmsSource) {
            return {
                id: 'wms',
                source: wmsSource,
            };
        }
        else if (wmtsSource) {
            return {
                id: 'wmts',
                source: wmtsSource,
            };
        }
        else {
            return undefined;
        }
    });
    source = signal(undefined);
    layer = signal(new TileLayer({}));
    constructor() {
        super();
    }
    onHover(feature) {
        super.onHover(feature);
    }
    onUnHover(feature) {
        super.onUnHover(feature);
    }
    onAdd() {
        const activeSource = this.source();
        if (!activeSource) {
            throw 'No active source detected, failed to add tile-layer';
        }
        this.layer().setSource(activeSource);
    }
    updateLayer() {
        const newOptions = this.combinedOptions();
        const projection = get(this.combinedOptions().projection);
        if (!projection) {
            throw new Error('Projection not found');
        }
        const projectionExtent = projection.getExtent();
        if (IsWmtsLayerOptions(newOptions)) {
            const size = getWidth(projectionExtent) / 256;
            const resolutions = new Array(newOptions.maxZoom);
            const matrixIds = new Array(newOptions.maxZoom);
            for (let z = 0; z < 19; ++z) {
                // generate resolutions and matrixIds arrays for this WMTS
                resolutions[z] = size / Math.pow(2, z);
                matrixIds[z] = z;
            }
            const source = new WMTS({
                url: newOptions.url,
                layer: newOptions.layer,
                matrixSet: 'GoogleMapsCompatible',
                format: newOptions.format,
                projection: projection,
                tileGrid: new WMTSTileGrid({
                    origin: getTopLeft(projectionExtent),
                    resolutions: resolutions,
                    matrixIds: matrixIds,
                }),
                tileLoadFunction: newOptions.getTileData,
                style: newOptions.style ?? 'default',
                wrapX: newOptions.wrapX,
            });
            this.source.set(source);
            this.layer().setSource(source);
        }
        else {
            const extent = newOptions.bounds
                ? transformExtent(newOptions.bounds, projection, 'EPSG:3857')
                : undefined;
            const source = new TileWMS({
                url: newOptions.url,
                params: {
                    LAYERS: newOptions.layers.join(':'),
                    TILED: newOptions.tiled ?? true,
                },
                serverType: newOptions.serverType,
                transition: newOptions.transition,
                tileLoadFunction: newOptions.getTileData,
                projection: projection,
            });
            this.source.set(source);
            if (extent) {
                this.layer().setExtent(extent);
            }
            this.layer().setSource(source);
        }
        this.layer().setZIndex(this.combinedOptions().order ?? 0);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersTileLayerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "17.3.1", type: OpenlayersTileLayerComponent, isStandalone: true, selector: "oui-openlayers-tile-layer", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, providers: [
            {
                provide: OpenlayersBaseLayerComponent,
                useExisting: OpenlayersTileLayerComponent,
            },
        ], usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OpenlayersTileLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-openlayers-tile-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    providers: [
                        {
                            provide: OpenlayersBaseLayerComponent,
                            useExisting: OpenlayersTileLayerComponent,
                        },
                    ],
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BlbmxheWVycy10aWxlLWxheWVyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvb3BlbmxheWVycy9sYXllcnMvb3BlbmxheWVycy10aWxlLWxheWVyLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQ0wsdUJBQXVCLEVBQ3ZCLFNBQVMsRUFDVCxRQUFRLEVBQ1IsS0FBSyxFQUNMLE1BQU0sR0FDUCxNQUFNLGVBQWUsQ0FBQztBQUV2QixPQUFPLEVBQUUsNEJBQTRCLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQztBQU1qRixPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUNwRCxPQUFPLFNBQVMsTUFBTSxlQUFlLENBQUM7QUFDdEMsT0FBTyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFDMUMsT0FBTyxFQUFFLEdBQUcsRUFBRSxlQUFlLEVBQUUsTUFBTSxTQUFTLENBQUM7QUFDL0MsT0FBTyxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFDakQsT0FBTyxZQUFZLE1BQU0sa0JBQWtCLENBQUM7QUFDNUMsT0FBTyxFQUFFLHNCQUFzQixFQUFFLE1BQU0sY0FBYyxDQUFDOztBQWN0RCxNQUFNLE9BQU8sNEJBQTZCLFNBQVEsNEJBQTJEO0lBQzNGLE9BQU8sR0FBRyxLQUFLLENBQUMsUUFBUSxFQUFpQyxDQUFDO0lBRW5FLE9BQU8sR0FBRyxNQUFNLENBQXdDLFNBQVMsQ0FBQyxDQUFDO0lBQ25FLGVBQWUsR0FBRyxRQUFRLENBQWdDLEdBQUcsRUFBRTtRQUNwRSxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDL0IsSUFBSSxrQkFBa0IsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDO1lBQ2hDLE9BQU87Z0JBQ0wsR0FBRyxzQkFBc0I7Z0JBQ3pCLEdBQUc7b0JBQ0QsUUFBUSxFQUFFLEtBQUs7b0JBQ2YsTUFBTSxFQUFFLFdBQVc7b0JBQ25CLEtBQUssRUFBRSxTQUFTO29CQUNoQixLQUFLLEVBQUUsSUFBSTtvQkFDWCxTQUFTLEVBQUUsc0JBQXNCO29CQUNqQyxPQUFPLEVBQUUsRUFBRTtvQkFDWCxVQUFVLEVBQUUsV0FBVztpQkFDeEI7Z0JBQ0QsR0FBRyxPQUFPO2FBQzBCLENBQUM7UUFDekMsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPO2dCQUNMLEdBQUcsc0JBQXNCO2dCQUN6QixHQUFHO29CQUNELFFBQVEsRUFBRSxLQUFLO29CQUNmLEtBQUssRUFBRSxJQUFJO29CQUNYLFVBQVUsRUFBRSxXQUFXO29CQUN2QixVQUFVLEVBQUUsR0FBRztvQkFDZixVQUFVLEVBQUUsV0FBVztpQkFDeEI7Z0JBQ0QsR0FBSSxPQUE0QzthQUNiLENBQUM7UUFDeEMsQ0FBQztJQUNILENBQUMsQ0FBQyxDQUFDO0lBRUksU0FBUyxHQUFHLE1BQU0sQ0FBc0IsU0FBUyxDQUFDLENBQUM7SUFDbkQsVUFBVSxHQUFHLE1BQU0sQ0FBbUIsU0FBUyxDQUFDLENBQUM7SUFDakQsWUFBWSxHQUFHLFFBQVEsQ0FBQyxHQUFHLEVBQUU7UUFDbEMsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBQ25DLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztRQUNyQyxJQUFJLFNBQVMsRUFBRSxDQUFDO1lBQ2QsT0FBTztnQkFDTCxFQUFFLEVBQUUsS0FBSztnQkFDVCxNQUFNLEVBQUUsU0FBUzthQUNsQixDQUFDO1FBQ0osQ0FBQzthQUFNLElBQUksVUFBVSxFQUFFLENBQUM7WUFDdEIsT0FBTztnQkFDTCxFQUFFLEVBQUUsTUFBTTtnQkFDVixNQUFNLEVBQUUsVUFBVTthQUNuQixDQUFDO1FBQ0osQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLFNBQVMsQ0FBQztRQUNuQixDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDSSxNQUFNLEdBQUcsTUFBTSxDQUE2QixTQUFTLENBQUMsQ0FBQztJQUN2RCxLQUFLLEdBQUcsTUFBTSxDQUE0QixJQUFJLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBRXBFO1FBQ0UsS0FBSyxFQUFFLENBQUM7SUFDVixDQUFDO0lBRWUsT0FBTyxDQUFDLE9BQWtCO1FBQ3hDLEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDekIsQ0FBQztJQUVlLFNBQVMsQ0FBQyxPQUFrQjtRQUMxQyxLQUFLLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQzNCLENBQUM7SUFFZSxLQUFLO1FBQ25CLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztRQUNuQyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDbEIsTUFBTSxxREFBcUQsQ0FBQztRQUM5RCxDQUFDO1FBQ0QsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRU0sV0FBVztRQUNoQixNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7UUFDMUMsTUFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMxRCxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDaEIsTUFBTSxJQUFJLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO1FBQzFDLENBQUM7UUFDRCxNQUFNLGdCQUFnQixHQUFHLFVBQVUsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUVoRCxJQUFJLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUM7WUFDbkMsTUFBTSxJQUFJLEdBQUcsUUFBUSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsR0FBRyxDQUFDO1lBQzlDLE1BQU0sV0FBVyxHQUFHLElBQUksS0FBSyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNsRCxNQUFNLFNBQVMsR0FBRyxJQUFJLEtBQUssQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDaEQsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDO2dCQUM1QiwwREFBMEQ7Z0JBQzFELFdBQVcsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZDLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDbkIsQ0FBQztZQUNELE1BQU0sTUFBTSxHQUFHLElBQUksSUFBSSxDQUFDO2dCQUN0QixHQUFHLEVBQUUsVUFBVSxDQUFDLEdBQUc7Z0JBQ25CLEtBQUssRUFBRSxVQUFVLENBQUMsS0FBSztnQkFDdkIsU0FBUyxFQUFFLHNCQUFzQjtnQkFDakMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxNQUFNO2dCQUN6QixVQUFVLEVBQUUsVUFBVTtnQkFDdEIsUUFBUSxFQUFFLElBQUksWUFBWSxDQUFDO29CQUN6QixNQUFNLEVBQUUsVUFBVSxDQUFDLGdCQUFnQixDQUFDO29CQUNwQyxXQUFXLEVBQUUsV0FBVztvQkFDeEIsU0FBUyxFQUFFLFNBQVM7aUJBQ3JCLENBQUM7Z0JBQ0YsZ0JBQWdCLEVBQUUsVUFBVSxDQUFDLFdBQVc7Z0JBQ3hDLEtBQUssRUFBRSxVQUFVLENBQUMsS0FBSyxJQUFJLFNBQVM7Z0JBQ3BDLEtBQUssRUFBRSxVQUFVLENBQUMsS0FBSzthQUN4QixDQUFDLENBQUM7WUFFSCxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN4QixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pDLENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxNQUFNLEdBQUcsVUFBVSxDQUFDLE1BQU07Z0JBQzlCLENBQUMsQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxVQUFVLEVBQUUsV0FBVyxDQUFDO2dCQUM3RCxDQUFDLENBQUMsU0FBUyxDQUFDO1lBQ2QsTUFBTSxNQUFNLEdBQUcsSUFBSSxPQUFPLENBQUM7Z0JBQ3pCLEdBQUcsRUFBRSxVQUFVLENBQUMsR0FBRztnQkFDbkIsTUFBTSxFQUFFO29CQUNOLE1BQU0sRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7b0JBQ25DLEtBQUssRUFBRSxVQUFVLENBQUMsS0FBSyxJQUFJLElBQUk7aUJBQ2hDO2dCQUNELFVBQVUsRUFBRSxVQUFVLENBQUMsVUFBVTtnQkFDakMsVUFBVSxFQUFFLFVBQVUsQ0FBQyxVQUFVO2dCQUNqQyxnQkFBZ0IsRUFBRSxVQUFVLENBQUMsV0FBVztnQkFDeEMsVUFBVSxFQUFFLFVBQVU7YUFDdkIsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDeEIsSUFBSSxNQUFNLEVBQUUsQ0FBQztnQkFDWCxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ2pDLENBQUM7WUFDRCxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ2pDLENBQUM7UUFDRCxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDNUQsQ0FBQzt1R0F2SVUsNEJBQTRCOzJGQUE1Qiw0QkFBNEIsaU5BUDVCO1lBQ1Q7Z0JBQ0UsT0FBTyxFQUFFLDRCQUE0QjtnQkFDckMsV0FBVyxFQUFFLDRCQUE0QjthQUMxQztTQUNGLGlEQVRTLEVBQUU7OzJGQVdELDRCQUE0QjtrQkFieEMsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsMkJBQTJCO29CQUNyQyxRQUFRLEVBQUUsRUFBRTtvQkFDWixVQUFVLEVBQUUsSUFBSTtvQkFDaEIsT0FBTyxFQUFFLEVBQUU7b0JBQ1gsZUFBZSxFQUFFLHVCQUF1QixDQUFDLE1BQU07b0JBQy9DLFNBQVMsRUFBRTt3QkFDVDs0QkFDRSxPQUFPLEVBQUUsNEJBQTRCOzRCQUNyQyxXQUFXLDhCQUE4Qjt5QkFDMUM7cUJBQ0Y7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcbiAgQ29tcG9uZW50LFxuICBjb21wdXRlZCxcbiAgaW5wdXQsXG4gIHNpZ25hbCxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBGZWF0dXJlIGFzIE9sRmVhdHVyZSB9IGZyb20gJ29sJztcbmltcG9ydCB7IE9wZW5sYXllcnNCYXNlTGF5ZXJDb21wb25lbnQgfSBmcm9tICcuL29wZW5sYXllcnMtYmFzZS1sYXllci5jb21wb25lbnQnO1xuaW1wb3J0IHtcbiAgT3VpT3BlbmxheWVyc1RpbGVMYXllck9wdGlvbnMsXG4gIE91aU9wZW5sYXllcnNUaWxlTGF5ZXJXbXNPcHRpb25zLFxuICBPdWlPcGVubGF5ZXJzVGlsZUxheWVyV210c09wdGlvbnMsXG59IGZyb20gJy4uL3R5cGVzJztcbmltcG9ydCB7IElzV210c0xheWVyT3B0aW9ucyB9IGZyb20gJy4uL3R5cGUtZ3VhcmRzJztcbmltcG9ydCBUaWxlTGF5ZXIgZnJvbSAnb2wvbGF5ZXIvVGlsZSc7XG5pbXBvcnQgeyBUaWxlV01TLCBXTVRTIH0gZnJvbSAnb2wvc291cmNlJztcbmltcG9ydCB7IGdldCwgdHJhbnNmb3JtRXh0ZW50IH0gZnJvbSAnb2wvcHJvaic7XG5pbXBvcnQgeyBnZXRUb3BMZWZ0LCBnZXRXaWR0aCB9IGZyb20gJ29sL2V4dGVudCc7XG5pbXBvcnQgV01UU1RpbGVHcmlkIGZyb20gJ29sL3RpbGVncmlkL1dNVFMnO1xuaW1wb3J0IHsgREVGQVVMVF9DT01NT05fT1BUSU9OUyB9IGZyb20gJy4uL2NvbnN0YW50cyc7XG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdvdWktb3BlbmxheWVycy10aWxlLWxheWVyJyxcbiAgdGVtcGxhdGU6ICcnLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG4gIHByb3ZpZGVyczogW1xuICAgIHtcbiAgICAgIHByb3ZpZGU6IE9wZW5sYXllcnNCYXNlTGF5ZXJDb21wb25lbnQsXG4gICAgICB1c2VFeGlzdGluZzogT3BlbmxheWVyc1RpbGVMYXllckNvbXBvbmVudCxcbiAgICB9LFxuICBdLFxufSlcbmV4cG9ydCBjbGFzcyBPcGVubGF5ZXJzVGlsZUxheWVyQ29tcG9uZW50IGV4dGVuZHMgT3BlbmxheWVyc0Jhc2VMYXllckNvbXBvbmVudDxPdWlPcGVubGF5ZXJzVGlsZUxheWVyT3B0aW9ucz4ge1xuICBwdWJsaWMgb3ZlcnJpZGUgb3B0aW9ucyA9IGlucHV0LnJlcXVpcmVkPE91aU9wZW5sYXllcnNUaWxlTGF5ZXJPcHRpb25zPigpO1xuXG4gIHB1YmxpYyBvbExheWVyID0gc2lnbmFsPHVuZGVmaW5lZCB8IFRpbGVMYXllcjxXTVRTIHwgVGlsZVdNUz4+KHVuZGVmaW5lZCk7XG4gIHB1YmxpYyBjb21iaW5lZE9wdGlvbnMgPSBjb21wdXRlZDxPdWlPcGVubGF5ZXJzVGlsZUxheWVyT3B0aW9ucz4oKCkgPT4ge1xuICAgIGNvbnN0IG9wdGlvbnMgPSB0aGlzLm9wdGlvbnMoKTtcbiAgICBpZiAoSXNXbXRzTGF5ZXJPcHRpb25zKG9wdGlvbnMpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICAuLi5ERUZBVUxUX0NPTU1PTl9PUFRJT05TLFxuICAgICAgICAuLi57XG4gICAgICAgICAgcGlja2FibGU6IGZhbHNlLFxuICAgICAgICAgIGZvcm1hdDogJ2ltYWdlL3BuZycsXG4gICAgICAgICAgc3R5bGU6ICdkZWZhdWx0JyxcbiAgICAgICAgICB3cmFwWDogdHJ1ZSxcbiAgICAgICAgICBtYXRyaXhTZXQ6ICdHb29nbGVNYXBzQ29tcGF0aWJsZScsXG4gICAgICAgICAgbWF4Wm9vbTogMTksXG4gICAgICAgICAgcHJvamVjdGlvbjogJ0VQU0c6Mzg1NycsXG4gICAgICAgIH0sXG4gICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICB9IGFzIE91aU9wZW5sYXllcnNUaWxlTGF5ZXJXbXRzT3B0aW9ucztcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgLi4uREVGQVVMVF9DT01NT05fT1BUSU9OUyxcbiAgICAgICAgLi4ue1xuICAgICAgICAgIHBpY2thYmxlOiBmYWxzZSxcbiAgICAgICAgICB0aWxlZDogdHJ1ZSxcbiAgICAgICAgICBzZXJ2ZXJUeXBlOiAnZ2Vvc2VydmVyJyxcbiAgICAgICAgICB0cmFuc2l0aW9uOiAzMDAsXG4gICAgICAgICAgcHJvamVjdGlvbjogJ0VQU0c6Mzg1NycsXG4gICAgICAgIH0sXG4gICAgICAgIC4uLihvcHRpb25zIGFzIE91aU9wZW5sYXllcnNUaWxlTGF5ZXJXbXNPcHRpb25zKSxcbiAgICAgIH0gYXMgT3VpT3BlbmxheWVyc1RpbGVMYXllcldtc09wdGlvbnM7XG4gICAgfVxuICB9KTtcblxuICBwdWJsaWMgc291cmNlV01TID0gc2lnbmFsPFRpbGVXTVMgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG4gIHB1YmxpYyBzb3VyY2VXTVRTID0gc2lnbmFsPFdNVFMgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG4gIHB1YmxpYyBhY3RpdmVTb3VyY2UgPSBjb21wdXRlZCgoKSA9PiB7XG4gICAgY29uc3Qgd21zU291cmNlID0gdGhpcy5zb3VyY2VXTVMoKTtcbiAgICBjb25zdCB3bXRzU291cmNlID0gdGhpcy5zb3VyY2VXTVRTKCk7XG4gICAgaWYgKHdtc1NvdXJjZSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgaWQ6ICd3bXMnLFxuICAgICAgICBzb3VyY2U6IHdtc1NvdXJjZSxcbiAgICAgIH07XG4gICAgfSBlbHNlIGlmICh3bXRzU291cmNlKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBpZDogJ3dtdHMnLFxuICAgICAgICBzb3VyY2U6IHdtdHNTb3VyY2UsXG4gICAgICB9O1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgfSk7XG4gIHB1YmxpYyBzb3VyY2UgPSBzaWduYWw8V01UUyB8IFRpbGVXTVMgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG4gIHB1YmxpYyBsYXllciA9IHNpZ25hbDxUaWxlTGF5ZXI8V01UUyB8IFRpbGVXTVM+PihuZXcgVGlsZUxheWVyKHt9KSk7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHB1YmxpYyBvdmVycmlkZSBvbkhvdmVyKGZlYXR1cmU6IE9sRmVhdHVyZSkge1xuICAgIHN1cGVyLm9uSG92ZXIoZmVhdHVyZSk7XG4gIH1cblxuICBwdWJsaWMgb3ZlcnJpZGUgb25VbkhvdmVyKGZlYXR1cmU6IE9sRmVhdHVyZSkge1xuICAgIHN1cGVyLm9uVW5Ib3ZlcihmZWF0dXJlKTtcbiAgfVxuXG4gIHB1YmxpYyBvdmVycmlkZSBvbkFkZCgpIHtcbiAgICBjb25zdCBhY3RpdmVTb3VyY2UgPSB0aGlzLnNvdXJjZSgpO1xuICAgIGlmICghYWN0aXZlU291cmNlKSB7XG4gICAgICB0aHJvdyAnTm8gYWN0aXZlIHNvdXJjZSBkZXRlY3RlZCwgZmFpbGVkIHRvIGFkZCB0aWxlLWxheWVyJztcbiAgICB9XG4gICAgdGhpcy5sYXllcigpLnNldFNvdXJjZShhY3RpdmVTb3VyY2UpO1xuICB9XG5cbiAgcHVibGljIHVwZGF0ZUxheWVyKCkge1xuICAgIGNvbnN0IG5ld09wdGlvbnMgPSB0aGlzLmNvbWJpbmVkT3B0aW9ucygpO1xuICAgIGNvbnN0IHByb2plY3Rpb24gPSBnZXQodGhpcy5jb21iaW5lZE9wdGlvbnMoKS5wcm9qZWN0aW9uKTtcbiAgICBpZiAoIXByb2plY3Rpb24pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignUHJvamVjdGlvbiBub3QgZm91bmQnKTtcbiAgICB9XG4gICAgY29uc3QgcHJvamVjdGlvbkV4dGVudCA9IHByb2plY3Rpb24uZ2V0RXh0ZW50KCk7XG5cbiAgICBpZiAoSXNXbXRzTGF5ZXJPcHRpb25zKG5ld09wdGlvbnMpKSB7XG4gICAgICBjb25zdCBzaXplID0gZ2V0V2lkdGgocHJvamVjdGlvbkV4dGVudCkgLyAyNTY7XG4gICAgICBjb25zdCByZXNvbHV0aW9ucyA9IG5ldyBBcnJheShuZXdPcHRpb25zLm1heFpvb20pO1xuICAgICAgY29uc3QgbWF0cml4SWRzID0gbmV3IEFycmF5KG5ld09wdGlvbnMubWF4Wm9vbSk7XG4gICAgICBmb3IgKGxldCB6ID0gMDsgeiA8IDE5OyArK3opIHtcbiAgICAgICAgLy8gZ2VuZXJhdGUgcmVzb2x1dGlvbnMgYW5kIG1hdHJpeElkcyBhcnJheXMgZm9yIHRoaXMgV01UU1xuICAgICAgICByZXNvbHV0aW9uc1t6XSA9IHNpemUgLyBNYXRoLnBvdygyLCB6KTtcbiAgICAgICAgbWF0cml4SWRzW3pdID0gejtcbiAgICAgIH1cbiAgICAgIGNvbnN0IHNvdXJjZSA9IG5ldyBXTVRTKHtcbiAgICAgICAgdXJsOiBuZXdPcHRpb25zLnVybCxcbiAgICAgICAgbGF5ZXI6IG5ld09wdGlvbnMubGF5ZXIsXG4gICAgICAgIG1hdHJpeFNldDogJ0dvb2dsZU1hcHNDb21wYXRpYmxlJyxcbiAgICAgICAgZm9ybWF0OiBuZXdPcHRpb25zLmZvcm1hdCxcbiAgICAgICAgcHJvamVjdGlvbjogcHJvamVjdGlvbixcbiAgICAgICAgdGlsZUdyaWQ6IG5ldyBXTVRTVGlsZUdyaWQoe1xuICAgICAgICAgIG9yaWdpbjogZ2V0VG9wTGVmdChwcm9qZWN0aW9uRXh0ZW50KSxcbiAgICAgICAgICByZXNvbHV0aW9uczogcmVzb2x1dGlvbnMsXG4gICAgICAgICAgbWF0cml4SWRzOiBtYXRyaXhJZHMsXG4gICAgICAgIH0pLFxuICAgICAgICB0aWxlTG9hZEZ1bmN0aW9uOiBuZXdPcHRpb25zLmdldFRpbGVEYXRhLFxuICAgICAgICBzdHlsZTogbmV3T3B0aW9ucy5zdHlsZSA/PyAnZGVmYXVsdCcsXG4gICAgICAgIHdyYXBYOiBuZXdPcHRpb25zLndyYXBYLFxuICAgICAgfSk7XG5cbiAgICAgIHRoaXMuc291cmNlLnNldChzb3VyY2UpO1xuICAgICAgdGhpcy5sYXllcigpLnNldFNvdXJjZShzb3VyY2UpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBleHRlbnQgPSBuZXdPcHRpb25zLmJvdW5kc1xuICAgICAgICA/IHRyYW5zZm9ybUV4dGVudChuZXdPcHRpb25zLmJvdW5kcywgcHJvamVjdGlvbiwgJ0VQU0c6Mzg1NycpXG4gICAgICAgIDogdW5kZWZpbmVkO1xuICAgICAgY29uc3Qgc291cmNlID0gbmV3IFRpbGVXTVMoe1xuICAgICAgICB1cmw6IG5ld09wdGlvbnMudXJsLFxuICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICBMQVlFUlM6IG5ld09wdGlvbnMubGF5ZXJzLmpvaW4oJzonKSxcbiAgICAgICAgICBUSUxFRDogbmV3T3B0aW9ucy50aWxlZCA/PyB0cnVlLFxuICAgICAgICB9LFxuICAgICAgICBzZXJ2ZXJUeXBlOiBuZXdPcHRpb25zLnNlcnZlclR5cGUsXG4gICAgICAgIHRyYW5zaXRpb246IG5ld09wdGlvbnMudHJhbnNpdGlvbixcbiAgICAgICAgdGlsZUxvYWRGdW5jdGlvbjogbmV3T3B0aW9ucy5nZXRUaWxlRGF0YSxcbiAgICAgICAgcHJvamVjdGlvbjogcHJvamVjdGlvbixcbiAgICAgIH0pO1xuXG4gICAgICB0aGlzLnNvdXJjZS5zZXQoc291cmNlKTtcbiAgICAgIGlmIChleHRlbnQpIHtcbiAgICAgICAgdGhpcy5sYXllcigpLnNldEV4dGVudChleHRlbnQpO1xuICAgICAgfVxuICAgICAgdGhpcy5sYXllcigpLnNldFNvdXJjZShzb3VyY2UpO1xuICAgIH1cbiAgICB0aGlzLmxheWVyKCkuc2V0WkluZGV4KHRoaXMuY29tYmluZWRPcHRpb25zKCkub3JkZXIgPz8gMCk7XG4gIH1cbn1cbiJdfQ==