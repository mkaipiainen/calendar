import * as i0 from "@angular/core";
/**
 * Service to streamline access to sessionStorage a bit, especially with JSON-objects.
 * When using this service, you don't need to manually stringify and parse javascript-objects, but it's handled automatically.
 */
export declare class OuiSessionStorageService {
    constructor();
    setItem(key: string, value: any): void;
    getItem(key: string): any;
    removeItem(key: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiSessionStorageService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiSessionStorageService>;
}
//# sourceMappingURL=session-storage.service.d.ts.map