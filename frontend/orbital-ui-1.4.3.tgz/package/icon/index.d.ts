/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/icon" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-icon.d.ts.map