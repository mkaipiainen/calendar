import { Component, EventEmitter, Inject, Input, Output, signal, ViewChild, } from '@angular/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { OuiIconComponent } from 'orbital-ui/icon';
import { take } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { OuiSliderComponent } from 'orbital-ui/slider';
import { OuiDraggableDirective, } from 'orbital-ui/draggable';
import { debounce } from 'lodash-es';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
export class DeckSideBySideComponent {
    renderer;
    document;
    destroyRef;
    cdr;
    elementRef;
    leftLabelTemplate;
    rightLabelTemplate;
    mapContainer;
    map;
    clipChange = new EventEmitter();
    dragged = new EventEmitter();
    clicked = new EventEmitter();
    released = new EventEmitter();
    dragContainer;
    drag;
    imageLabelRight;
    imageLabelLeft;
    thumbIconTemplate;
    mapContent;
    draggable;
    mapsWrapper;
    gammaMaskRight;
    gammaMaskLeft;
    currentDragPosition = {
        x: 0,
        y: 0,
    };
    resizeObserver;
    dragLeftRatio = 0;
    isInitialisationStarted = false;
    refreshInterval;
    debouncedEndClip = debounce(this.getClipAndEmit.bind(this), 50);
    unlisteners = [];
    mapListeners = {
        movestart: this.startClipping.bind(this),
        move: this.storeBounds.bind(this),
        moveend: this.endClipping.bind(this),
    };
    isInitialised = false;
    isVertical = true;
    beforeGamma = signal(1);
    afterGamma = signal(1);
    gammaSliderOptions = signal({
        min: 0.01,
        max: 2,
        minLabel: '',
        maxLabel: '',
    });
    currentBounds;
    constructor(renderer, document, destroyRef, cdr, elementRef) {
        this.renderer = renderer;
        this.document = document;
        this.destroyRef = destroyRef;
        this.cdr = cdr;
        this.elementRef = elementRef;
    }
    ngAfterViewInit() {
        this.gammaSliderOptions.set({
            min: 0.01,
            max: 2,
            minLabel: '',
            maxLabel: '',
            thumbContentTemplate: this.thumbIconTemplate,
        });
        if (this.map) {
            if (!this.isInitialisationStarted) {
                this.subscribeToMapLoad();
            }
        }
        this.cdr.detectChanges();
    }
    initDraggable() {
        this.draggable.addDefaultBehavior();
        this.draggable.addContainerConstraint({
            container: this.mapsWrapper.nativeElement,
            anchor: 'edge',
        });
        this.currentDragPosition = {
            x: this.getMapContainerWidth() / 2 - this.getDragContainerWidthOffset(),
            y: 0,
        };
        this.draggable.updateTransform(this.currentDragPosition);
        this.dragLeftRatio =
            this.currentDragPosition.x / this.getMapContainerWidth();
    }
    subscribeToMapLoad() {
        this.isInitialisationStarted = true;
        this.map.onLoad$
            .pipe(takeUntilDestroyed(this.destroyRef), take(1))
            .subscribe(() => {
            this.initialiseComponent();
            setTimeout(() => {
                this.isInitialised = true;
                this.cdr.detectChanges();
            });
        });
    }
    initialiseComponent() {
        this.mapContent.nativeElement.style.filter = `url('#gammaFilter')`;
        setTimeout(() => {
            this.initDraggable();
            this.initializeEventListeners();
        });
        this.initializeResizeObserver();
    }
    getMapContainerWidth() {
        return this.mapContainer.getBoundingClientRect().width;
    }
    getMapContainerHeight() {
        return this.mapContainer.getBoundingClientRect().height;
    }
    getDragWidthOffset() {
        return this.drag.nativeElement.offsetWidth / 2;
    }
    getDragHeightOffset() {
        return this.drag.nativeElement.offsetHeight / 2;
    }
    getDragContainerWidthOffset() {
        return this.dragContainer.nativeElement.offsetWidth / 2;
    }
    getDragContainerHeightOffset() {
        return this.dragContainer.nativeElement.offsetHeight / 2;
    }
    getClip() {
        if (!this.map.map) {
            return;
        }
        if (!this.currentBounds) {
            this.currentBounds = this.map.map?.getBounds();
        }
        const left = this.dragContainer.nativeElement.getBoundingClientRect().left -
            this.mapsWrapper.nativeElement.getBoundingClientRect().left +
            this.getDragContainerWidthOffset();
        const dragLongitude = this.map.projectXyToLngLat([left, 0]).lng;
        const topLatitude = Math.min(this.currentBounds._ne.lat + 0.1, 85);
        const bottomLatitude = Math.max(this.currentBounds._sw.lat - 0.1, -85);
        return {
            left: {
                type: 'FeatureCollection',
                features: [
                    {
                        type: 'Feature',
                        properties: {},
                        geometry: {
                            coordinates: [
                                [
                                    [dragLongitude, bottomLatitude],
                                    [dragLongitude, topLatitude],
                                    [this.currentBounds._sw.lng - 0.1, topLatitude],
                                    [this.currentBounds._sw.lng - 0.1, bottomLatitude],
                                    [dragLongitude, bottomLatitude],
                                ],
                            ],
                            type: 'Polygon',
                        },
                    },
                ],
            },
            right: {
                type: 'FeatureCollection',
                features: [
                    {
                        type: 'Feature',
                        properties: {},
                        geometry: {
                            coordinates: [
                                [
                                    [dragLongitude, bottomLatitude],
                                    [dragLongitude, topLatitude],
                                    [this.currentBounds._ne.lng + 0.1, topLatitude],
                                    [this.currentBounds._ne.lng + 0.1, bottomLatitude],
                                    [dragLongitude, bottomLatitude],
                                ],
                            ],
                            type: 'Polygon',
                        },
                    },
                ],
            },
        };
    }
    initializeEventListeners() {
        this.currentBounds = this.map.map.getBounds();
        if (this.map.deck.isInterleaved && this.map.map) {
            this.map.map.on('movestart', this.mapListeners['movestart']);
            this.map.map.on('moveend', this.mapListeners['moveend']);
            this.map.map.on('move', this.mapListeners['move']);
        }
        else {
            this.map.deck.viewStateChange$
                .pipe(takeUntilDestroyed(this.destroyRef))
                .subscribe(data => {
                this.currentBounds = data.viewState.bounds;
                this.clipChange.emit(this.getClip());
                this.debouncedEndClip();
            });
        }
    }
    storeBounds(event) {
        this.currentBounds = this.map.map.getBounds();
    }
    getClipAndEmit() {
        this.clipChange.emit(this.getClip());
    }
    onDragMove(event) {
        if ('currentTranslate' in event) {
            const wrapperBbox = this.mapsWrapper.nativeElement.getBoundingClientRect();
            const width = wrapperBbox.width;
            const leftWidth = ((event.currentTranslate.x + this.getDragContainerWidthOffset()) /
                width) *
                100;
            const rightWidth = 100 - leftWidth;
            const rightLeft = event.currentTranslate.x + this.getDragContainerWidthOffset();
            this.renderer.setAttribute(this.gammaMaskLeft.nativeElement, 'width', `${leftWidth}%`);
            this.renderer.setAttribute(this.gammaMaskRight.nativeElement, 'width', `${rightWidth}%`);
            this.renderer.setAttribute(this.gammaMaskRight.nativeElement, 'x', `${(rightLeft / width) * 100}%`);
            this.clipChange.emit(this.getClip());
            this.currentDragPosition = {
                x: event.currentTranslate.x,
                y: event.currentTranslate.y,
            };
            this.dragLeftRatio =
                this.currentDragPosition.x / this.getMapContainerWidth();
            this.debouncedEndClip();
        }
    }
    onDragEnd() {
        this.debouncedEndClip();
    }
    setLeftLabelPosition() {
        if (!this.imageLabelLeft) {
            return;
        }
        const left = this.currentDragPosition.x -
            this.imageLabelLeft.nativeElement.getBoundingClientRect().width +
            this.getDragContainerWidthOffset() -
            this.getDragWidthOffset();
        this.renderer.setStyle(this.imageLabelLeft.nativeElement, 'transform', `translate(${left}px, ${0}px)`);
    }
    resizeSideBySide() {
        const mapContainerWidth = this.getMapContainerWidth();
        let newLeft = mapContainerWidth * this.dragLeftRatio;
        const leftEdge = this.getDragContainerWidthOffset();
        const rightEdge = mapContainerWidth - this.getDragContainerWidthOffset();
        if (newLeft < leftEdge) {
            newLeft = leftEdge;
        }
        else if (newLeft > rightEdge) {
            newLeft = rightEdge;
        }
        this.currentDragPosition = {
            x: newLeft,
            y: this.currentDragPosition.y,
        };
        this.draggable.updateTransform(this.currentDragPosition);
        this.clipChange.emit(this.getClip());
    }
    initializeResizeObserver() {
        this.resizeObserver = new ResizeObserver(() => {
            this.resizeSideBySide();
        });
        this.resizeObserver.observe(this.mapContainer);
    }
    startClipping() {
        if (this.refreshInterval) {
            return;
        }
        this.refreshInterval = setInterval(() => {
            this.clipChange.emit(this.getClip());
        }, 20);
    }
    endClipping() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
            this.refreshInterval = undefined;
            setTimeout(() => {
                this.clipChange.emit(this.getClip());
            });
        }
    }
    onBeforeGammaChange(value) {
        this.beforeGamma.set(value);
        const filters = this.elementRef.nativeElement.querySelectorAll('.beforeGammaElement');
        for (const filter of filters) {
            filter.setAttribute('amplitude', `${value}`);
            filter.setAttribute('exponent', `${1 / value}`);
            // filter.setAttribute('offset', `${(value - 1) / 5}`);
        }
    }
    onAfterGammaChange(value) {
        this.afterGamma.set(value);
        const filters = this.elementRef.nativeElement.querySelectorAll('.afterGammaElement');
        for (const filter of filters) {
            // filter.setAttribute('amplitude', `${value}`);
            filter.setAttribute('exponent', `${1 / value}`);
            // filter.setAttribute('offset', `${(value - 1) / 5}`);
        }
    }
    ngOnDestroy() {
        for (const unlistener of this.unlisteners) {
            unlistener();
        }
        if (this.resizeObserver) {
            this.resizeObserver.unobserve(this.mapContainer);
        }
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }
        if (this.map?.map) {
            for (let listener in this.mapListeners) {
                this.map.map.off(listener, this.mapListeners[listener]);
                this.map.map.off(listener, this.mapListeners[listener]);
            }
        }
    }
    ngOnChanges(changes) {
        if ('map' in changes) {
            this.map = changes['map'].currentValue;
            if (this.map && !this.isInitialisationStarted && this.mapContent) {
                this.subscribeToMapLoad();
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckSideBySideComponent, deps: [{ token: i0.Renderer2 }, { token: DOCUMENT }, { token: i0.DestroyRef }, { token: i0.ChangeDetectorRef }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckSideBySideComponent, isStandalone: true, selector: "oui-deck-side-by-side", inputs: { leftLabelTemplate: "leftLabelTemplate", rightLabelTemplate: "rightLabelTemplate", mapContainer: "mapContainer", map: "map" }, outputs: { clipChange: "clipChange", dragged: "dragged", clicked: "clicked", released: "released" }, viewQueries: [{ propertyName: "dragContainer", first: true, predicate: ["dragContainer"], descendants: true }, { propertyName: "drag", first: true, predicate: ["drag"], descendants: true }, { propertyName: "imageLabelRight", first: true, predicate: ["imageLabelRight"], descendants: true }, { propertyName: "imageLabelLeft", first: true, predicate: ["imageLabelLeft"], descendants: true }, { propertyName: "thumbIconTemplate", first: true, predicate: ["thumbIconTemplate"], descendants: true }, { propertyName: "mapContent", first: true, predicate: ["mapContent"], descendants: true }, { propertyName: "draggable", first: true, predicate: ["draggable"], descendants: true }, { propertyName: "mapsWrapper", first: true, predicate: ["mapsWrapper"], descendants: true }, { propertyName: "gammaMaskRight", first: true, predicate: ["gammaMaskRight"], descendants: true }, { propertyName: "gammaMaskLeft", first: true, predicate: ["gammaMaskLeft"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"side-by-side-wrapper\" [ngClass]=\"{'initialised': isInitialised}\">\n  <div class=\"maps-wrapper\" #mapsWrapper>\n    <div\n        oui-draggable\n        (dragMove)=\"onDragMove($event)\"\n        (dragEnd)=\"onDragEnd()\"\n        #draggable=\"OuiDraggableDirective\"\n        class=\"drag-container\"\n        #dragContainer\n        [ngClass]=\"{ vertical: isVertical, horizontal: !isVertical }\"\n    >\n      <div class=\"drag shadow\" #drag></div>\n      <div class=\"drag-caret-container\">\n        <oui-icon\n            icon=\"assets/icons/caret-left.svg\"\n            [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n            class=\"drag-caret-left\"\n        ></oui-icon>\n        <oui-icon\n            icon=\"assets/icons/caret-right.svg\"\n            [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n            class=\"drag-caret-right\"\n        ></oui-icon>\n      </div>\n    </div>\n    <div class=\"map-content\" #mapContent>\n      <svg class=\"gamma-mask-svg\">\n        <filter id=\"gammaFilter\" primitiveUnits=\"objectBoundingBox\" width=\"100%\" height=\"100%\" x=\"0\" y=\"0\">\n          <feColorMatrix result=\"CURRENT\"></feColorMatrix>\n          <feComponentTransfer #gammaMaskLeft result=\"LEFT\" x=\"0%\" width=\"50%\" height=\"100%\" y=\"0%\">\n            <feFuncR\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n            <feFuncG\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n            <feFuncB\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n          </feComponentTransfer>\n          <feComposite in2=\"CURRENT\" in=\"LEFT\" operator=\"over\" result=\"CURRENT\"></feComposite>\n          <feComponentTransfer #gammaMaskRight result=\"RIGHT\" x=\"50%\" width=\"50%\" height=\"100%\" y=\"0%\">\n            <feFuncR\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n            <feFuncG\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n            <feFuncB\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n          </feComponentTransfer>\n\n          <feComposite in2=\"CURRENT\" in=\"RIGHT\" operator=\"over\" result=\"COMPOSITE\">\n\n          </feComposite>\n<!--          <feComposite in2=\"SourceGraphic\" in=\"FIRST_COMPOSITE\" operator=\"over\" result=\"FIRST_COMBINED_COMPOSITE\">-->\n\n<!--          </feComposite>-->\n<!--          <feComposite in2=\"FIRST_COMBINED_COMPOSITE\" in=\"SECOND\" operator=\"over\" result=\"SECOND_COMPOSITE\">-->\n\n<!--          </feComposite>-->\n<!--          <feComposite in2=\"FIRST_COMBINED_COMPOSITE\" in=\"SECOND_COMPOSITE\" operator=\"in\"></feComposite>-->\n        </filter>\n      </svg>\n\n      <ng-content>\n\n      </ng-content>\n    </div>\n\n\n<!--    <div class=\"side-by-side-label-wrapper left\" *ngIf=\"leftLabelTemplate\">-->\n<!--      <ng-content *ngTemplateOutlet=\"leftLabelTemplate\"></ng-content>-->\n<!--    </div>-->\n\n<!--    <div class=\"side-by-side-label-wrapper right\" [ngClass]=\"{'has-geolocate': map?.options?.geoLocateControl}\" *ngIf=\"rightLabelTemplate\">-->\n<!--      <ng-content *ngTemplateOutlet=\"rightLabelTemplate\"></ng-content>-->\n<!--    </div>-->\n\n  </div>\n  <div class=\"gamma-slider-wrapper\">\n    <div class=\"gamma-slider left\">\n      <oui-slider [options]=\"gammaSliderOptions()\" [value]=\"beforeGamma()\" (valueChange)=\"onBeforeGammaChange($event)\"\n      ></oui-slider>\n    </div>\n    <div class=\"gamma-slider right\">\n      <oui-slider\n          [options]=\"gammaSliderOptions()\"\n          [value]=\"afterGamma()\"\n          (valueChange)=\"onAfterGammaChange($event)\"\n      ></oui-slider>\n    </div>\n\n    <ng-template #thumbIconTemplate>\n      <oui-icon  [icon]=\"'assets/icons/brightness.svg'\"\n                 [options]=\"{\n    viewBox: '0 0 48 48',\n    size: '13px',\n    fillColor: 'color-background-primary-text',\n    strokeColor: 'color-background-primary-text',\n    }\">\n\n      </oui-icon>\n    </ng-template>\n  </div>\n\n\n</div>\n", styles: [":host{width:100%;height:100%;position:absolute;top:0;left:0;z-index:1;pointer-events:none}:host .gamma-mask-svg{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:-9999}:host .side-by-side-wrapper{width:100%;height:100%;opacity:0;transition:opacity .3s;pointer-events:none;display:flex;flex-direction:column}:host .side-by-side-wrapper .gamma-slider-wrapper{display:flex;height:5rem;justify-content:space-around;pointer-events:all;--oui-slider-thumb-color-primary: var(--color-background-primary);--oui-slider-thumb-border-radius: 50%;--oui-slider-thumb-width: 20px;--oui-slider-thumb-height: 20px;--oui-slider-thumb-color-primary-hover: var(--color-background-primary-hover)}:host .side-by-side-wrapper .gamma-slider-wrapper .gamma-slider{width:25%;height:100%}:host .side-by-side-wrapper .maps-wrapper{height:100%;width:100%;flex:1;position:relative;overflow:hidden}:host .side-by-side-wrapper .maps-wrapper .map-content{height:100%;width:100%;position:relative}:host .side-by-side-wrapper .maps-wrapper .drag-container{position:absolute;width:var(--mapbox-side-by-side-caret-container-width);pointer-events:all;z-index:2;cursor:col-resize}:host .side-by-side-wrapper .maps-wrapper .drag-container .drag-caret-container{display:flex;justify-content:space-between;align-items:center;position:absolute;border-width:var(--oui-mapbox-side-by-side-caret-container-border-width);border-style:var(--oui-mapbox-side-by-side-caret-container-border-style);border-color:var(--oui-mapbox-side-by-side-caret-container-border-color);height:var(--mapbox-side-by-side-caret-container-height);width:var(--mapbox-side-by-side-caret-container-width);background-color:var(--mapbox-side-by-side-caret-container-background-color);border-radius:var(--mapbox-side-by-side-caret-container-border-radius)}:host .side-by-side-wrapper .maps-wrapper .drag-container .drag-caret-container oui-icon{filter:var(--oui-mapbox-side-by-side-caret-icon-filter)}:host .side-by-side-wrapper .maps-wrapper .drag-container:hover{cursor:col-resize}:host .side-by-side-wrapper .maps-wrapper .drag-container.vertical{height:100%;width:40px;display:flex;justify-content:center;align-items:center}:host .side-by-side-wrapper .maps-wrapper .drag-container.vertical .drag{width:var(--mapbox-side-by-side-drag-width);background-color:var(--mapbox-side-by-side-drag-background-color);border:solid var(--border-color-primary);border-width:0 1px;height:100%}:host .side-by-side-wrapper .maps-wrapper .drag-container.horizontal{width:100%;height:40px;display:flex;justify-content:center}:host .side-by-side-wrapper .maps-wrapper .drag-container.horizontal .drag{height:4px;background-color:#fff;width:100%}:host .side-by-side-wrapper.initialised{opacity:1}:host .side-by-side-wrapper .side-by-side-label-wrapper{display:flex;align-items:center;position:absolute;top:2rem;flex:0;min-height:3rem;-webkit-user-select:none;user-select:none;font-size:var(--font-size-body-smaller);border-radius:var(--border-radius-default);color:var(--color-dark)}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-content{line-height:1px}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-icon{margin-right:10px}:host .side-by-side-wrapper .side-by-side-label-wrapper.left{z-index:1;left:1rem}:host .side-by-side-wrapper .side-by-side-label-wrapper.right{z-index:0;right:1rem}:host .side-by-side-wrapper .side-by-side-label-wrapper.right.has-geolocate{right:5rem;margin-right:1rem}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: OuiSliderComponent, selector: "oui-slider", inputs: ["value", "valueTo", "options"], outputs: ["valueChange", "valueToChange", "debouncedvalueChange", "debouncedValueToChange"] }, { kind: "directive", type: OuiDraggableDirective, selector: "[oui-draggable]", outputs: ["dragMove", "dragStart", "dragEnd"], exportAs: ["OuiDraggableDirective"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckSideBySideComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-deck-side-by-side', standalone: true, imports: [
                        OuiIconComponent,
                        CommonModule,
                        OuiSliderComponent,
                        OuiDraggableDirective,
                    ], template: "<div class=\"side-by-side-wrapper\" [ngClass]=\"{'initialised': isInitialised}\">\n  <div class=\"maps-wrapper\" #mapsWrapper>\n    <div\n        oui-draggable\n        (dragMove)=\"onDragMove($event)\"\n        (dragEnd)=\"onDragEnd()\"\n        #draggable=\"OuiDraggableDirective\"\n        class=\"drag-container\"\n        #dragContainer\n        [ngClass]=\"{ vertical: isVertical, horizontal: !isVertical }\"\n    >\n      <div class=\"drag shadow\" #drag></div>\n      <div class=\"drag-caret-container\">\n        <oui-icon\n            icon=\"assets/icons/caret-left.svg\"\n            [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n            class=\"drag-caret-left\"\n        ></oui-icon>\n        <oui-icon\n            icon=\"assets/icons/caret-right.svg\"\n            [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n            class=\"drag-caret-right\"\n        ></oui-icon>\n      </div>\n    </div>\n    <div class=\"map-content\" #mapContent>\n      <svg class=\"gamma-mask-svg\">\n        <filter id=\"gammaFilter\" primitiveUnits=\"objectBoundingBox\" width=\"100%\" height=\"100%\" x=\"0\" y=\"0\">\n          <feColorMatrix result=\"CURRENT\"></feColorMatrix>\n          <feComponentTransfer #gammaMaskLeft result=\"LEFT\" x=\"0%\" width=\"50%\" height=\"100%\" y=\"0%\">\n            <feFuncR\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n            <feFuncG\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n            <feFuncB\n                class=\"beforeGammaElement\"\n                type=\"gamma\"\n                amplitude=\"0\"\n                exponent=\"1\"\n                offset=\"0\"\n            />\n          </feComponentTransfer>\n          <feComposite in2=\"CURRENT\" in=\"LEFT\" operator=\"over\" result=\"CURRENT\"></feComposite>\n          <feComponentTransfer #gammaMaskRight result=\"RIGHT\" x=\"50%\" width=\"50%\" height=\"100%\" y=\"0%\">\n            <feFuncR\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n            <feFuncG\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n            <feFuncB\n                class=\"afterGammaElement\"\n                type=\"gamma\"\n                amplitude=\"1\"\n                exponent=\"0\"\n                offset=\"0\"\n            />\n          </feComponentTransfer>\n\n          <feComposite in2=\"CURRENT\" in=\"RIGHT\" operator=\"over\" result=\"COMPOSITE\">\n\n          </feComposite>\n<!--          <feComposite in2=\"SourceGraphic\" in=\"FIRST_COMPOSITE\" operator=\"over\" result=\"FIRST_COMBINED_COMPOSITE\">-->\n\n<!--          </feComposite>-->\n<!--          <feComposite in2=\"FIRST_COMBINED_COMPOSITE\" in=\"SECOND\" operator=\"over\" result=\"SECOND_COMPOSITE\">-->\n\n<!--          </feComposite>-->\n<!--          <feComposite in2=\"FIRST_COMBINED_COMPOSITE\" in=\"SECOND_COMPOSITE\" operator=\"in\"></feComposite>-->\n        </filter>\n      </svg>\n\n      <ng-content>\n\n      </ng-content>\n    </div>\n\n\n<!--    <div class=\"side-by-side-label-wrapper left\" *ngIf=\"leftLabelTemplate\">-->\n<!--      <ng-content *ngTemplateOutlet=\"leftLabelTemplate\"></ng-content>-->\n<!--    </div>-->\n\n<!--    <div class=\"side-by-side-label-wrapper right\" [ngClass]=\"{'has-geolocate': map?.options?.geoLocateControl}\" *ngIf=\"rightLabelTemplate\">-->\n<!--      <ng-content *ngTemplateOutlet=\"rightLabelTemplate\"></ng-content>-->\n<!--    </div>-->\n\n  </div>\n  <div class=\"gamma-slider-wrapper\">\n    <div class=\"gamma-slider left\">\n      <oui-slider [options]=\"gammaSliderOptions()\" [value]=\"beforeGamma()\" (valueChange)=\"onBeforeGammaChange($event)\"\n      ></oui-slider>\n    </div>\n    <div class=\"gamma-slider right\">\n      <oui-slider\n          [options]=\"gammaSliderOptions()\"\n          [value]=\"afterGamma()\"\n          (valueChange)=\"onAfterGammaChange($event)\"\n      ></oui-slider>\n    </div>\n\n    <ng-template #thumbIconTemplate>\n      <oui-icon  [icon]=\"'assets/icons/brightness.svg'\"\n                 [options]=\"{\n    viewBox: '0 0 48 48',\n    size: '13px',\n    fillColor: 'color-background-primary-text',\n    strokeColor: 'color-background-primary-text',\n    }\">\n\n      </oui-icon>\n    </ng-template>\n  </div>\n\n\n</div>\n", styles: [":host{width:100%;height:100%;position:absolute;top:0;left:0;z-index:1;pointer-events:none}:host .gamma-mask-svg{position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:-9999}:host .side-by-side-wrapper{width:100%;height:100%;opacity:0;transition:opacity .3s;pointer-events:none;display:flex;flex-direction:column}:host .side-by-side-wrapper .gamma-slider-wrapper{display:flex;height:5rem;justify-content:space-around;pointer-events:all;--oui-slider-thumb-color-primary: var(--color-background-primary);--oui-slider-thumb-border-radius: 50%;--oui-slider-thumb-width: 20px;--oui-slider-thumb-height: 20px;--oui-slider-thumb-color-primary-hover: var(--color-background-primary-hover)}:host .side-by-side-wrapper .gamma-slider-wrapper .gamma-slider{width:25%;height:100%}:host .side-by-side-wrapper .maps-wrapper{height:100%;width:100%;flex:1;position:relative;overflow:hidden}:host .side-by-side-wrapper .maps-wrapper .map-content{height:100%;width:100%;position:relative}:host .side-by-side-wrapper .maps-wrapper .drag-container{position:absolute;width:var(--mapbox-side-by-side-caret-container-width);pointer-events:all;z-index:2;cursor:col-resize}:host .side-by-side-wrapper .maps-wrapper .drag-container .drag-caret-container{display:flex;justify-content:space-between;align-items:center;position:absolute;border-width:var(--oui-mapbox-side-by-side-caret-container-border-width);border-style:var(--oui-mapbox-side-by-side-caret-container-border-style);border-color:var(--oui-mapbox-side-by-side-caret-container-border-color);height:var(--mapbox-side-by-side-caret-container-height);width:var(--mapbox-side-by-side-caret-container-width);background-color:var(--mapbox-side-by-side-caret-container-background-color);border-radius:var(--mapbox-side-by-side-caret-container-border-radius)}:host .side-by-side-wrapper .maps-wrapper .drag-container .drag-caret-container oui-icon{filter:var(--oui-mapbox-side-by-side-caret-icon-filter)}:host .side-by-side-wrapper .maps-wrapper .drag-container:hover{cursor:col-resize}:host .side-by-side-wrapper .maps-wrapper .drag-container.vertical{height:100%;width:40px;display:flex;justify-content:center;align-items:center}:host .side-by-side-wrapper .maps-wrapper .drag-container.vertical .drag{width:var(--mapbox-side-by-side-drag-width);background-color:var(--mapbox-side-by-side-drag-background-color);border:solid var(--border-color-primary);border-width:0 1px;height:100%}:host .side-by-side-wrapper .maps-wrapper .drag-container.horizontal{width:100%;height:40px;display:flex;justify-content:center}:host .side-by-side-wrapper .maps-wrapper .drag-container.horizontal .drag{height:4px;background-color:#fff;width:100%}:host .side-by-side-wrapper.initialised{opacity:1}:host .side-by-side-wrapper .side-by-side-label-wrapper{display:flex;align-items:center;position:absolute;top:2rem;flex:0;min-height:3rem;-webkit-user-select:none;user-select:none;font-size:var(--font-size-body-smaller);border-radius:var(--border-radius-default);color:var(--color-dark)}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-content{line-height:1px}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-icon{margin-right:10px}:host .side-by-side-wrapper .side-by-side-label-wrapper.left{z-index:1;left:1rem}:host .side-by-side-wrapper .side-by-side-label-wrapper.right{z-index:0;right:1rem}:host .side-by-side-wrapper .side-by-side-label-wrapper.right.has-geolocate{right:5rem;margin-right:1rem}\n"] }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.DestroyRef }, { type: i0.ChangeDetectorRef }, { type: i0.ElementRef }], propDecorators: { leftLabelTemplate: [{
                type: Input
            }], rightLabelTemplate: [{
                type: Input
            }], mapContainer: [{
                type: Input
            }], map: [{
                type: Input
            }], clipChange: [{
                type: Output
            }], dragged: [{
                type: Output
            }], clicked: [{
                type: Output
            }], released: [{
                type: Output
            }], dragContainer: [{
                type: ViewChild,
                args: ['dragContainer']
            }], drag: [{
                type: ViewChild,
                args: ['drag']
            }], imageLabelRight: [{
                type: ViewChild,
                args: ['imageLabelRight']
            }], imageLabelLeft: [{
                type: ViewChild,
                args: ['imageLabelLeft']
            }], thumbIconTemplate: [{
                type: ViewChild,
                args: ['thumbIconTemplate']
            }], mapContent: [{
                type: ViewChild,
                args: ['mapContent']
            }], draggable: [{
                type: ViewChild,
                args: ['draggable']
            }], mapsWrapper: [{
                type: ViewChild,
                args: ['mapsWrapper']
            }], gammaMaskRight: [{
                type: ViewChild,
                args: ['gammaMaskRight']
            }], gammaMaskLeft: [{
                type: ViewChild,
                args: ['gammaMaskLeft']
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay1zaWRlLWJ5LXNpZGUuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9tYXBib3gvc2lkZS1ieS1zaWRlL2RlY2stc2lkZS1ieS1zaWRlL2RlY2stc2lkZS1ieS1zaWRlLmNvbXBvbmVudC50cyIsIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvbWFwYm94L3NpZGUtYnktc2lkZS9kZWNrLXNpZGUtYnktc2lkZS9kZWNrLXNpZGUtYnktc2lkZS5jb21wb25lbnQuaHRtbCJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBR0wsU0FBUyxFQUdULFlBQVksRUFDWixNQUFNLEVBQ04sS0FBSyxFQUdMLE1BQU0sRUFFTixNQUFNLEVBR04sU0FBUyxHQUNWLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDekQsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDbkQsT0FBTyxFQUFFLElBQUksRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUM1QixPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQztBQUNoRSxPQUFPLEVBQXFCLGtCQUFrQixFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFDMUUsT0FBTyxFQUdMLHFCQUFxQixHQUN0QixNQUFNLHNCQUFzQixDQUFDO0FBQzlCLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxXQUFXLENBQUM7OztBQTJCckMsTUFBTSxPQUFPLHVCQUF1QjtJQXNEeEI7SUFDa0I7SUFDbEI7SUFDQTtJQUNBO0lBdkRNLGlCQUFpQixDQUFtQjtJQUNwQyxrQkFBa0IsQ0FBbUI7SUFDckMsWUFBWSxDQUFjO0lBQzFCLEdBQUcsQ0FBcUI7SUFFOUIsVUFBVSxHQUFHLElBQUksWUFBWSxFQUFlLENBQUM7SUFDN0MsT0FBTyxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7SUFDN0IsT0FBTyxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7SUFDN0IsUUFBUSxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7SUFFSixhQUFhLENBQWE7SUFDbkMsSUFBSSxDQUFhO0lBQ04sZUFBZSxDQUFhO0lBQzdCLGNBQWMsQ0FBYTtJQUNoQyxpQkFBaUIsQ0FBbUI7SUFDM0MsVUFBVSxDQUFhO0lBQ3hCLFNBQVMsQ0FBd0I7SUFDL0IsV0FBVyxDQUFhO0lBQ3JCLGNBQWMsQ0FBYTtJQUM1QixhQUFhLENBQWE7SUFFOUMsbUJBQW1CLEdBQWtCO1FBQzNDLENBQUMsRUFBRSxDQUFDO1FBQ0osQ0FBQyxFQUFFLENBQUM7S0FDTCxDQUFDO0lBQ00sY0FBYyxDQUFpQjtJQUMvQixhQUFhLEdBQUcsQ0FBQyxDQUFDO0lBQ2xCLHVCQUF1QixHQUFHLEtBQUssQ0FBQztJQUNoQyxlQUFlLENBQU07SUFDckIsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBRWhFLFdBQVcsR0FBbUIsRUFBRSxDQUFDO0lBQ2pDLFlBQVksR0FFaEI7UUFDRixTQUFTLEVBQUUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1FBQ3hDLElBQUksRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDakMsT0FBTyxFQUFFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztLQUNyQyxDQUFDO0lBQ0ssYUFBYSxHQUFHLEtBQUssQ0FBQztJQUN0QixVQUFVLEdBQUcsSUFBSSxDQUFDO0lBQ2xCLFdBQVcsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDeEIsVUFBVSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUN2QixrQkFBa0IsR0FBRyxNQUFNLENBQW9CO1FBQ3BELEdBQUcsRUFBRSxJQUFJO1FBQ1QsR0FBRyxFQUFFLENBQUM7UUFDTixRQUFRLEVBQUUsRUFBRTtRQUNaLFFBQVEsRUFBRSxFQUFFO0tBQ2IsQ0FBQyxDQUFDO0lBQ0ksYUFBYSxDQUFlO0lBQ25DLFlBQ1UsUUFBbUIsRUFDRCxRQUFrQixFQUNwQyxVQUFzQixFQUN0QixHQUFzQixFQUN0QixVQUFzQjtRQUp0QixhQUFRLEdBQVIsUUFBUSxDQUFXO1FBQ0QsYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUNwQyxlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQ3RCLFFBQUcsR0FBSCxHQUFHLENBQW1CO1FBQ3RCLGVBQVUsR0FBVixVQUFVLENBQVk7SUFDN0IsQ0FBQztJQUVKLGVBQWU7UUFDYixJQUFJLENBQUMsa0JBQWtCLENBQUMsR0FBRyxDQUFDO1lBQzFCLEdBQUcsRUFBRSxJQUFJO1lBQ1QsR0FBRyxFQUFFLENBQUM7WUFDTixRQUFRLEVBQUUsRUFBRTtZQUNaLFFBQVEsRUFBRSxFQUFFO1lBQ1osb0JBQW9CLEVBQUUsSUFBSSxDQUFDLGlCQUFpQjtTQUM3QyxDQUFDLENBQUM7UUFFSCxJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNiLElBQUksQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztnQkFDbEMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7WUFDNUIsQ0FBQztRQUNILENBQUM7UUFDRCxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFTyxhQUFhO1FBQ25CLElBQUksQ0FBQyxTQUFTLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUNwQyxJQUFJLENBQUMsU0FBUyxDQUFDLHNCQUFzQixDQUFDO1lBQ3BDLFNBQVMsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWE7WUFDekMsTUFBTSxFQUFFLE1BQU07U0FDZixDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsbUJBQW1CLEdBQUc7WUFDekIsQ0FBQyxFQUFFLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsMkJBQTJCLEVBQUU7WUFDdkUsQ0FBQyxFQUFFLENBQUM7U0FDTCxDQUFDO1FBQ0YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDekQsSUFBSSxDQUFDLGFBQWE7WUFDaEIsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztJQUM3RCxDQUFDO0lBRU8sa0JBQWtCO1FBQ3hCLElBQUksQ0FBQyx1QkFBdUIsR0FBRyxJQUFJLENBQUM7UUFDcEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPO2FBQ2IsSUFBSSxDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDbEQsU0FBUyxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1lBQzNCLFVBQVUsQ0FBQyxHQUFHLEVBQUU7Z0JBQ2QsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQzFCLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDM0IsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxtQkFBbUI7UUFDekIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxxQkFBcUIsQ0FBQztRQUNuRSxVQUFVLENBQUMsR0FBRyxFQUFFO1lBQ2QsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxDQUFDO1FBQ2xDLENBQUMsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUM7SUFDbEMsQ0FBQztJQUVPLG9CQUFvQjtRQUMxQixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7SUFDekQsQ0FBQztJQUVPLHFCQUFxQjtRQUMzQixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUM7SUFDMUQsQ0FBQztJQUVPLGtCQUFrQjtRQUN4QixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUVPLG1CQUFtQjtRQUN6QixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksR0FBRyxDQUFDLENBQUM7SUFDbEQsQ0FBQztJQUVPLDJCQUEyQjtRQUNqQyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUM7SUFDMUQsQ0FBQztJQUVPLDRCQUE0QjtRQUNsQyxPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLFlBQVksR0FBRyxDQUFDLENBQUM7SUFDM0QsQ0FBQztJQUVPLE9BQU87UUFDYixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNsQixPQUFPO1FBQ1QsQ0FBQztRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxTQUFTLEVBQUUsQ0FBQztRQUNqRCxDQUFDO1FBQ0QsTUFBTSxJQUFJLEdBQ1IsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxJQUFJO1lBQzdELElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLHFCQUFxQixFQUFFLENBQUMsSUFBSTtZQUMzRCxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztRQUNyQyxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQ2hFLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUNuRSxNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUN2RSxPQUFPO1lBQ0wsSUFBSSxFQUFFO2dCQUNKLElBQUksRUFBRSxtQkFBbUI7Z0JBQ3pCLFFBQVEsRUFBRTtvQkFDUjt3QkFDRSxJQUFJLEVBQUUsU0FBUzt3QkFDZixVQUFVLEVBQUUsRUFBRTt3QkFDZCxRQUFRLEVBQUU7NEJBQ1IsV0FBVyxFQUFFO2dDQUNYO29DQUNFLENBQUMsYUFBYSxFQUFFLGNBQWMsQ0FBQztvQ0FDL0IsQ0FBQyxhQUFhLEVBQUUsV0FBVyxDQUFDO29DQUM1QixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLEVBQUUsV0FBVyxDQUFDO29DQUMvQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLEVBQUUsY0FBYyxDQUFDO29DQUNsRCxDQUFDLGFBQWEsRUFBRSxjQUFjLENBQUM7aUNBQ2hDOzZCQUNGOzRCQUNELElBQUksRUFBRSxTQUFTO3lCQUNoQjtxQkFDRjtpQkFDRjthQUNGO1lBQ0QsS0FBSyxFQUFFO2dCQUNMLElBQUksRUFBRSxtQkFBbUI7Z0JBQ3pCLFFBQVEsRUFBRTtvQkFDUjt3QkFDRSxJQUFJLEVBQUUsU0FBUzt3QkFDZixVQUFVLEVBQUUsRUFBRTt3QkFDZCxRQUFRLEVBQUU7NEJBQ1IsV0FBVyxFQUFFO2dDQUNYO29DQUNFLENBQUMsYUFBYSxFQUFFLGNBQWMsQ0FBQztvQ0FDL0IsQ0FBQyxhQUFhLEVBQUUsV0FBVyxDQUFDO29DQUM1QixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLEVBQUUsV0FBVyxDQUFDO29DQUMvQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLEVBQUUsY0FBYyxDQUFDO29DQUNsRCxDQUFDLGFBQWEsRUFBRSxjQUFjLENBQUM7aUNBQ2hDOzZCQUNGOzRCQUNELElBQUksRUFBRSxTQUFTO3lCQUNoQjtxQkFDRjtpQkFDRjthQUNGO1NBQ0YsQ0FBQztJQUNKLENBQUM7SUFFTyx3QkFBd0I7UUFDOUIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUUvQyxJQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGFBQWEsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ2hELElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDO1lBRTdELElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1lBQ3pELElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQ3JELENBQUM7YUFBTSxDQUFDO1lBQ04sSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCO2lCQUMzQixJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2lCQUN6QyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUU7Z0JBQ2hCLElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7Z0JBQzNDLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO2dCQUNyQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUMxQixDQUFDLENBQUMsQ0FBQztRQUNQLENBQUM7SUFDSCxDQUFDO0lBRU8sV0FBVyxDQUFDLEtBQVU7UUFDNUIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztJQUNqRCxDQUFDO0lBRU8sY0FBYztRQUNwQixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRU0sVUFBVSxDQUFDLEtBQW1CO1FBQ25DLElBQUksa0JBQWtCLElBQUksS0FBSyxFQUFFLENBQUM7WUFDaEMsTUFBTSxXQUFXLEdBQ2YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMscUJBQXFCLEVBQUUsQ0FBQztZQUN6RCxNQUFNLEtBQUssR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDO1lBQ2hDLE1BQU0sU0FBUyxHQUNiLENBQUMsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQywyQkFBMkIsRUFBRSxDQUFDO2dCQUM5RCxLQUFLLENBQUM7Z0JBQ1IsR0FBRyxDQUFDO1lBQ04sTUFBTSxVQUFVLEdBQUcsR0FBRyxHQUFHLFNBQVMsQ0FBQztZQUNuQyxNQUFNLFNBQVMsR0FDYixLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQywyQkFBMkIsRUFBRSxDQUFDO1lBQ2hFLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUN4QixJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFDaEMsT0FBTyxFQUNQLEdBQUcsU0FBUyxHQUFHLENBQ2hCLENBQUM7WUFDRixJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FDeEIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxhQUFhLEVBQ2pDLE9BQU8sRUFDUCxHQUFHLFVBQVUsR0FBRyxDQUNqQixDQUFDO1lBQ0YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQ3hCLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxFQUNqQyxHQUFHLEVBQ0gsR0FBRyxDQUFDLFNBQVMsR0FBRyxLQUFLLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FDaEMsQ0FBQztZQUNGLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQ3JDLElBQUksQ0FBQyxtQkFBbUIsR0FBRztnQkFDekIsQ0FBQyxFQUFFLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO2dCQUMzQixDQUFDLEVBQUUsS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUM7YUFDNUIsQ0FBQztZQUNGLElBQUksQ0FBQyxhQUFhO2dCQUNoQixJQUFJLENBQUMsbUJBQW1CLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1lBQzNELElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQzFCLENBQUM7SUFDSCxDQUFDO0lBRU0sU0FBUztRQUNkLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQzFCLENBQUM7SUFFTyxvQkFBb0I7UUFDMUIsSUFBSSxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUN6QixPQUFPO1FBQ1QsQ0FBQztRQUNELE1BQU0sSUFBSSxHQUNSLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBQzFCLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLHFCQUFxQixFQUFFLENBQUMsS0FBSztZQUMvRCxJQUFJLENBQUMsMkJBQTJCLEVBQUU7WUFDbEMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDNUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQ3BCLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxFQUNqQyxXQUFXLEVBQ1gsYUFBYSxJQUFJLE9BQU8sQ0FBQyxLQUFLLENBQy9CLENBQUM7SUFDSixDQUFDO0lBRU8sZ0JBQWdCO1FBQ3RCLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7UUFDdEQsSUFBSSxPQUFPLEdBQUcsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUNyRCxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztRQUNwRCxNQUFNLFNBQVMsR0FBRyxpQkFBaUIsR0FBRyxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztRQUN6RSxJQUFJLE9BQU8sR0FBRyxRQUFRLEVBQUUsQ0FBQztZQUN2QixPQUFPLEdBQUcsUUFBUSxDQUFDO1FBQ3JCLENBQUM7YUFBTSxJQUFJLE9BQU8sR0FBRyxTQUFTLEVBQUUsQ0FBQztZQUMvQixPQUFPLEdBQUcsU0FBUyxDQUFDO1FBQ3RCLENBQUM7UUFDRCxJQUFJLENBQUMsbUJBQW1CLEdBQUc7WUFDekIsQ0FBQyxFQUFFLE9BQU87WUFDVixDQUFDLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixDQUFDLENBQUM7U0FDOUIsQ0FBQztRQUNGLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQ3pELElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFTyx3QkFBd0I7UUFDOUIsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLGNBQWMsQ0FBQyxHQUFHLEVBQUU7WUFDNUMsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFDMUIsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7SUFDakQsQ0FBQztJQUVPLGFBQWE7UUFDbkIsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDekIsT0FBTztRQUNULENBQUM7UUFDRCxJQUFJLENBQUMsZUFBZSxHQUFHLFdBQVcsQ0FBQyxHQUFHLEVBQUU7WUFDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDdkMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0lBQ1QsQ0FBQztJQUVPLFdBQVc7UUFDakIsSUFBSSxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7WUFDekIsYUFBYSxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztZQUNwQyxJQUFJLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQztZQUNqQyxVQUFVLENBQUMsR0FBRyxFQUFFO2dCQUNkLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQ3ZDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztJQUNILENBQUM7SUFFTSxtQkFBbUIsQ0FBQyxLQUFhO1FBQ3RDLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBRTVCLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUM1RCxxQkFBcUIsQ0FDdEIsQ0FBQztRQUNGLEtBQUssTUFBTSxNQUFNLElBQUksT0FBTyxFQUFFLENBQUM7WUFDN0IsTUFBTSxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUUsR0FBRyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1lBQzdDLE1BQU0sQ0FBQyxZQUFZLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLENBQUM7WUFDaEQsdURBQXVEO1FBQ3pELENBQUM7SUFDSCxDQUFDO0lBRU0sa0JBQWtCLENBQUMsS0FBYTtRQUNyQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUUzQixNQUFNLE9BQU8sR0FDWCxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1FBQ3ZFLEtBQUssTUFBTSxNQUFNLElBQUksT0FBTyxFQUFFLENBQUM7WUFDN0IsZ0RBQWdEO1lBQ2hELE1BQU0sQ0FBQyxZQUFZLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEtBQUssRUFBRSxDQUFDLENBQUM7WUFDaEQsdURBQXVEO1FBQ3pELENBQUM7SUFDSCxDQUFDO0lBRU0sV0FBVztRQUNoQixLQUFLLE1BQU0sVUFBVSxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUMxQyxVQUFVLEVBQUUsQ0FBQztRQUNmLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUN4QixJQUFJLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDbkQsQ0FBQztRQUVELElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3pCLGFBQWEsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7UUFDdEMsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQztZQUNsQixLQUFLLElBQUksUUFBUSxJQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDdkMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0JBQ3hELElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1lBQzFELENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVNLFdBQVcsQ0FBQyxPQUFzQjtRQUN2QyxJQUFJLEtBQUssSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUNyQixJQUFJLENBQUMsR0FBRyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZLENBQUM7WUFDdkMsSUFBSSxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLHVCQUF1QixJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDakUsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7WUFDNUIsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO3VHQTVYVSx1QkFBdUIsMkNBdUR4QixRQUFROzJGQXZEUCx1QkFBdUIsd3hDQ3ZEcEMsaThKQTZJQSwrOUdENUZJLGdCQUFnQixpRkFDaEIsWUFBWSw2SEFDWixrQkFBa0IsNkxBQ2xCLHFCQUFxQjs7MkZBR1osdUJBQXVCO2tCQVpuQyxTQUFTOytCQUNFLHVCQUF1QixjQUdyQixJQUFJLFdBQ1A7d0JBQ1AsZ0JBQWdCO3dCQUNoQixZQUFZO3dCQUNaLGtCQUFrQjt3QkFDbEIscUJBQXFCO3FCQUN0Qjs7MEJBeURFLE1BQU07MkJBQUMsUUFBUTsySEFwREYsaUJBQWlCO3NCQUFoQyxLQUFLO2dCQUNVLGtCQUFrQjtzQkFBakMsS0FBSztnQkFDVSxZQUFZO3NCQUEzQixLQUFLO2dCQUNVLEdBQUc7c0JBQWxCLEtBQUs7Z0JBRUksVUFBVTtzQkFBbkIsTUFBTTtnQkFDRyxPQUFPO3NCQUFoQixNQUFNO2dCQUNHLE9BQU87c0JBQWhCLE1BQU07Z0JBQ0csUUFBUTtzQkFBakIsTUFBTTtnQkFFNkIsYUFBYTtzQkFBaEQsU0FBUzt1QkFBQyxlQUFlO2dCQUNDLElBQUk7c0JBQTlCLFNBQVM7dUJBQUMsTUFBTTtnQkFDcUIsZUFBZTtzQkFBcEQsU0FBUzt1QkFBQyxpQkFBaUI7Z0JBQ1MsY0FBYztzQkFBbEQsU0FBUzt1QkFBQyxnQkFBZ0I7Z0JBQ0ssaUJBQWlCO3NCQUFoRCxTQUFTO3VCQUFDLG1CQUFtQjtnQkFDTCxVQUFVO3NCQUFsQyxTQUFTO3VCQUFDLFlBQVk7Z0JBQ0MsU0FBUztzQkFBaEMsU0FBUzt1QkFBQyxXQUFXO2dCQUNJLFdBQVc7c0JBQXBDLFNBQVM7dUJBQUMsYUFBYTtnQkFDSyxjQUFjO3NCQUExQyxTQUFTO3VCQUFDLGdCQUFnQjtnQkFDQyxhQUFhO3NCQUF4QyxTQUFTO3VCQUFDLGVBQWUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBDaGFuZ2VEZXRlY3RvclJlZixcbiAgQ29tcG9uZW50LFxuICBEZXN0cm95UmVmLFxuICBFbGVtZW50UmVmLFxuICBFdmVudEVtaXR0ZXIsXG4gIEluamVjdCxcbiAgSW5wdXQsXG4gIE9uQ2hhbmdlcyxcbiAgT25EZXN0cm95LFxuICBPdXRwdXQsXG4gIFJlbmRlcmVyMixcbiAgc2lnbmFsLFxuICBTaW1wbGVDaGFuZ2VzLFxuICBUZW1wbGF0ZVJlZixcbiAgVmlld0NoaWxkLFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSwgRE9DVU1FTlQgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgT3VpSWNvbkNvbXBvbmVudCB9IGZyb20gJ29yYml0YWwtdWkvaWNvbic7XG5pbXBvcnQgeyB0YWtlIH0gZnJvbSAncnhqcyc7XG5pbXBvcnQgeyB0YWtlVW50aWxEZXN0cm95ZWQgfSBmcm9tICdAYW5ndWxhci9jb3JlL3J4anMtaW50ZXJvcCc7XG5pbXBvcnQgeyBJT3VpU2xpZGVyT3B0aW9ucywgT3VpU2xpZGVyQ29tcG9uZW50IH0gZnJvbSAnb3JiaXRhbC11aS9zbGlkZXInO1xuaW1wb3J0IHtcbiAgSU91aURyYWdFbmQsXG4gIElPdWlEcmFnTW92ZSxcbiAgT3VpRHJhZ2dhYmxlRGlyZWN0aXZlLFxufSBmcm9tICdvcmJpdGFsLXVpL2RyYWdnYWJsZSc7XG5pbXBvcnQgeyBkZWJvdW5jZSB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBPdWlNYXBib3hDb21wb25lbnQgfSBmcm9tICcuLi8uLi9tYXBib3guY29tcG9uZW50JztcbmltcG9ydCB7IExuZ0xhdEJvdW5kcyB9IGZyb20gJ21hcGJveC1nbCc7XG5pbXBvcnQgeyBGZWF0dXJlQ29sbGVjdGlvbiB9IGZyb20gJ0B0dXJmL2hlbHBlcnMnO1xuXG5pbnRlcmZhY2UgSURyYWdQb3NpdGlvbiB7XG4gIHg6IG51bWJlcjtcbiAgeTogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIElDbGlwQ2hhbmdlIHtcbiAgbGVmdDogRmVhdHVyZUNvbGxlY3Rpb247XG4gIHJpZ2h0OiBGZWF0dXJlQ29sbGVjdGlvbjtcbn1cblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLWRlY2stc2lkZS1ieS1zaWRlJyxcbiAgdGVtcGxhdGVVcmw6ICcuL2RlY2stc2lkZS1ieS1zaWRlLmNvbXBvbmVudC5odG1sJyxcbiAgc3R5bGVVcmxzOiBbJy4vZGVjay1zaWRlLWJ5LXNpZGUuY29tcG9uZW50LnNjc3MnXSxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW1xuICAgIE91aUljb25Db21wb25lbnQsXG4gICAgQ29tbW9uTW9kdWxlLFxuICAgIE91aVNsaWRlckNvbXBvbmVudCxcbiAgICBPdWlEcmFnZ2FibGVEaXJlY3RpdmUsXG4gIF0sXG59KVxuZXhwb3J0IGNsYXNzIERlY2tTaWRlQnlTaWRlQ29tcG9uZW50XG4gIGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95LCBPbkNoYW5nZXNcbntcbiAgQElucHV0KCkgcHVibGljIGxlZnRMYWJlbFRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xuICBASW5wdXQoKSBwdWJsaWMgcmlnaHRMYWJlbFRlbXBsYXRlOiBUZW1wbGF0ZVJlZjxhbnk+O1xuICBASW5wdXQoKSBwdWJsaWMgbWFwQ29udGFpbmVyOiBIVE1MRWxlbWVudDtcbiAgQElucHV0KCkgcHVibGljIG1hcDogT3VpTWFwYm94Q29tcG9uZW50O1xuXG4gIEBPdXRwdXQoKSBjbGlwQ2hhbmdlID0gbmV3IEV2ZW50RW1pdHRlcjxJQ2xpcENoYW5nZT4oKTtcbiAgQE91dHB1dCgpIGRyYWdnZWQgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gIEBPdXRwdXQoKSBjbGlja2VkID0gbmV3IEV2ZW50RW1pdHRlcigpO1xuICBAT3V0cHV0KCkgcmVsZWFzZWQgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG5cbiAgQFZpZXdDaGlsZCgnZHJhZ0NvbnRhaW5lcicpIHByaXZhdGUgZHJhZ0NvbnRhaW5lcjogRWxlbWVudFJlZjtcbiAgQFZpZXdDaGlsZCgnZHJhZycpIHByaXZhdGUgZHJhZzogRWxlbWVudFJlZjtcbiAgQFZpZXdDaGlsZCgnaW1hZ2VMYWJlbFJpZ2h0JykgcHJpdmF0ZSBpbWFnZUxhYmVsUmlnaHQ6IEVsZW1lbnRSZWY7XG4gIEBWaWV3Q2hpbGQoJ2ltYWdlTGFiZWxMZWZ0JykgcHJpdmF0ZSBpbWFnZUxhYmVsTGVmdDogRWxlbWVudFJlZjtcbiAgQFZpZXdDaGlsZCgndGh1bWJJY29uVGVtcGxhdGUnKSB0aHVtYkljb25UZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PjtcbiAgQFZpZXdDaGlsZCgnbWFwQ29udGVudCcpIG1hcENvbnRlbnQ6IEVsZW1lbnRSZWY7XG4gIEBWaWV3Q2hpbGQoJ2RyYWdnYWJsZScpIGRyYWdnYWJsZTogT3VpRHJhZ2dhYmxlRGlyZWN0aXZlO1xuICBAVmlld0NoaWxkKCdtYXBzV3JhcHBlcicpIG1hcHNXcmFwcGVyOiBFbGVtZW50UmVmO1xuICBAVmlld0NoaWxkKCdnYW1tYU1hc2tSaWdodCcpIGdhbW1hTWFza1JpZ2h0OiBFbGVtZW50UmVmO1xuICBAVmlld0NoaWxkKCdnYW1tYU1hc2tMZWZ0JykgZ2FtbWFNYXNrTGVmdDogRWxlbWVudFJlZjtcblxuICBwcml2YXRlIGN1cnJlbnREcmFnUG9zaXRpb246IElEcmFnUG9zaXRpb24gPSB7XG4gICAgeDogMCxcbiAgICB5OiAwLFxuICB9O1xuICBwcml2YXRlIHJlc2l6ZU9ic2VydmVyOiBSZXNpemVPYnNlcnZlcjtcbiAgcHJpdmF0ZSBkcmFnTGVmdFJhdGlvID0gMDtcbiAgcHJpdmF0ZSBpc0luaXRpYWxpc2F0aW9uU3RhcnRlZCA9IGZhbHNlO1xuICBwcml2YXRlIHJlZnJlc2hJbnRlcnZhbDogYW55O1xuICBwcml2YXRlIGRlYm91bmNlZEVuZENsaXAgPSBkZWJvdW5jZSh0aGlzLmdldENsaXBBbmRFbWl0LmJpbmQodGhpcyksIDUwKTtcblxuICBwcml2YXRlIHVubGlzdGVuZXJzOiAoKCkgPT4gdm9pZClbXSA9IFtdO1xuICBwcml2YXRlIG1hcExpc3RlbmVyczoge1xuICAgIFtldmVudE5hbWU6IHN0cmluZ106IChldmVudDogRXZlbnQpID0+IHZvaWQ7XG4gIH0gPSB7XG4gICAgbW92ZXN0YXJ0OiB0aGlzLnN0YXJ0Q2xpcHBpbmcuYmluZCh0aGlzKSxcbiAgICBtb3ZlOiB0aGlzLnN0b3JlQm91bmRzLmJpbmQodGhpcyksXG4gICAgbW92ZWVuZDogdGhpcy5lbmRDbGlwcGluZy5iaW5kKHRoaXMpLFxuICB9O1xuICBwdWJsaWMgaXNJbml0aWFsaXNlZCA9IGZhbHNlO1xuICBwdWJsaWMgaXNWZXJ0aWNhbCA9IHRydWU7XG4gIHB1YmxpYyBiZWZvcmVHYW1tYSA9IHNpZ25hbCgxKTtcbiAgcHVibGljIGFmdGVyR2FtbWEgPSBzaWduYWwoMSk7XG4gIHB1YmxpYyBnYW1tYVNsaWRlck9wdGlvbnMgPSBzaWduYWw8SU91aVNsaWRlck9wdGlvbnM+KHtcbiAgICBtaW46IDAuMDEsXG4gICAgbWF4OiAyLFxuICAgIG1pbkxhYmVsOiAnJyxcbiAgICBtYXhMYWJlbDogJycsXG4gIH0pO1xuICBwdWJsaWMgY3VycmVudEJvdW5kczogTG5nTGF0Qm91bmRzO1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJlbmRlcmVyOiBSZW5kZXJlcjIsXG4gICAgQEluamVjdChET0NVTUVOVCkgcHJpdmF0ZSBkb2N1bWVudDogRG9jdW1lbnQsXG4gICAgcHJpdmF0ZSBkZXN0cm95UmVmOiBEZXN0cm95UmVmLFxuICAgIHByaXZhdGUgY2RyOiBDaGFuZ2VEZXRlY3RvclJlZixcbiAgICBwcml2YXRlIGVsZW1lbnRSZWY6IEVsZW1lbnRSZWZcbiAgKSB7fVxuXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICB0aGlzLmdhbW1hU2xpZGVyT3B0aW9ucy5zZXQoe1xuICAgICAgbWluOiAwLjAxLFxuICAgICAgbWF4OiAyLFxuICAgICAgbWluTGFiZWw6ICcnLFxuICAgICAgbWF4TGFiZWw6ICcnLFxuICAgICAgdGh1bWJDb250ZW50VGVtcGxhdGU6IHRoaXMudGh1bWJJY29uVGVtcGxhdGUsXG4gICAgfSk7XG5cbiAgICBpZiAodGhpcy5tYXApIHtcbiAgICAgIGlmICghdGhpcy5pc0luaXRpYWxpc2F0aW9uU3RhcnRlZCkge1xuICAgICAgICB0aGlzLnN1YnNjcmliZVRvTWFwTG9hZCgpO1xuICAgICAgfVxuICAgIH1cbiAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XG4gIH1cblxuICBwcml2YXRlIGluaXREcmFnZ2FibGUoKSB7XG4gICAgdGhpcy5kcmFnZ2FibGUuYWRkRGVmYXVsdEJlaGF2aW9yKCk7XG4gICAgdGhpcy5kcmFnZ2FibGUuYWRkQ29udGFpbmVyQ29uc3RyYWludCh7XG4gICAgICBjb250YWluZXI6IHRoaXMubWFwc1dyYXBwZXIubmF0aXZlRWxlbWVudCxcbiAgICAgIGFuY2hvcjogJ2VkZ2UnLFxuICAgIH0pO1xuICAgIHRoaXMuY3VycmVudERyYWdQb3NpdGlvbiA9IHtcbiAgICAgIHg6IHRoaXMuZ2V0TWFwQ29udGFpbmVyV2lkdGgoKSAvIDIgLSB0aGlzLmdldERyYWdDb250YWluZXJXaWR0aE9mZnNldCgpLFxuICAgICAgeTogMCxcbiAgICB9O1xuICAgIHRoaXMuZHJhZ2dhYmxlLnVwZGF0ZVRyYW5zZm9ybSh0aGlzLmN1cnJlbnREcmFnUG9zaXRpb24pO1xuICAgIHRoaXMuZHJhZ0xlZnRSYXRpbyA9XG4gICAgICB0aGlzLmN1cnJlbnREcmFnUG9zaXRpb24ueCAvIHRoaXMuZ2V0TWFwQ29udGFpbmVyV2lkdGgoKTtcbiAgfVxuXG4gIHByaXZhdGUgc3Vic2NyaWJlVG9NYXBMb2FkKCkge1xuICAgIHRoaXMuaXNJbml0aWFsaXNhdGlvblN0YXJ0ZWQgPSB0cnVlO1xuICAgIHRoaXMubWFwLm9uTG9hZCRcbiAgICAgIC5waXBlKHRha2VVbnRpbERlc3Ryb3llZCh0aGlzLmRlc3Ryb3lSZWYpLCB0YWtlKDEpKVxuICAgICAgLnN1YnNjcmliZSgoKSA9PiB7XG4gICAgICAgIHRoaXMuaW5pdGlhbGlzZUNvbXBvbmVudCgpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICB0aGlzLmlzSW5pdGlhbGlzZWQgPSB0cnVlO1xuICAgICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgaW5pdGlhbGlzZUNvbXBvbmVudCgpIHtcbiAgICB0aGlzLm1hcENvbnRlbnQubmF0aXZlRWxlbWVudC5zdHlsZS5maWx0ZXIgPSBgdXJsKCcjZ2FtbWFGaWx0ZXInKWA7XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICB0aGlzLmluaXREcmFnZ2FibGUoKTtcbiAgICAgIHRoaXMuaW5pdGlhbGl6ZUV2ZW50TGlzdGVuZXJzKCk7XG4gICAgfSk7XG4gICAgdGhpcy5pbml0aWFsaXplUmVzaXplT2JzZXJ2ZXIoKTtcbiAgfVxuXG4gIHByaXZhdGUgZ2V0TWFwQ29udGFpbmVyV2lkdGgoKSB7XG4gICAgcmV0dXJuIHRoaXMubWFwQ29udGFpbmVyLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRNYXBDb250YWluZXJIZWlnaHQoKSB7XG4gICAgcmV0dXJuIHRoaXMubWFwQ29udGFpbmVyLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmhlaWdodDtcbiAgfVxuXG4gIHByaXZhdGUgZ2V0RHJhZ1dpZHRoT2Zmc2V0KCkge1xuICAgIHJldHVybiB0aGlzLmRyYWcubmF0aXZlRWxlbWVudC5vZmZzZXRXaWR0aCAvIDI7XG4gIH1cblxuICBwcml2YXRlIGdldERyYWdIZWlnaHRPZmZzZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZHJhZy5uYXRpdmVFbGVtZW50Lm9mZnNldEhlaWdodCAvIDI7XG4gIH1cblxuICBwcml2YXRlIGdldERyYWdDb250YWluZXJXaWR0aE9mZnNldCgpIHtcbiAgICByZXR1cm4gdGhpcy5kcmFnQ29udGFpbmVyLm5hdGl2ZUVsZW1lbnQub2Zmc2V0V2lkdGggLyAyO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXREcmFnQ29udGFpbmVySGVpZ2h0T2Zmc2V0KCkge1xuICAgIHJldHVybiB0aGlzLmRyYWdDb250YWluZXIubmF0aXZlRWxlbWVudC5vZmZzZXRIZWlnaHQgLyAyO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRDbGlwKCk6IElDbGlwQ2hhbmdlIHwgdW5kZWZpbmVkIHtcbiAgICBpZiAoIXRoaXMubWFwLm1hcCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoIXRoaXMuY3VycmVudEJvdW5kcykge1xuICAgICAgdGhpcy5jdXJyZW50Qm91bmRzID0gdGhpcy5tYXAubWFwPy5nZXRCb3VuZHMoKTtcbiAgICB9XG4gICAgY29uc3QgbGVmdCA9XG4gICAgICB0aGlzLmRyYWdDb250YWluZXIubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5sZWZ0IC1cbiAgICAgIHRoaXMubWFwc1dyYXBwZXIubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS5sZWZ0ICtcbiAgICAgIHRoaXMuZ2V0RHJhZ0NvbnRhaW5lcldpZHRoT2Zmc2V0KCk7XG4gICAgY29uc3QgZHJhZ0xvbmdpdHVkZSA9IHRoaXMubWFwLnByb2plY3RYeVRvTG5nTGF0KFtsZWZ0LCAwXSkubG5nO1xuICAgIGNvbnN0IHRvcExhdGl0dWRlID0gTWF0aC5taW4odGhpcy5jdXJyZW50Qm91bmRzLl9uZS5sYXQgKyAwLjEsIDg1KTtcbiAgICBjb25zdCBib3R0b21MYXRpdHVkZSA9IE1hdGgubWF4KHRoaXMuY3VycmVudEJvdW5kcy5fc3cubGF0IC0gMC4xLCAtODUpO1xuICAgIHJldHVybiB7XG4gICAgICBsZWZ0OiB7XG4gICAgICAgIHR5cGU6ICdGZWF0dXJlQ29sbGVjdGlvbicsXG4gICAgICAgIGZlYXR1cmVzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgdHlwZTogJ0ZlYXR1cmUnLFxuICAgICAgICAgICAgcHJvcGVydGllczoge30sXG4gICAgICAgICAgICBnZW9tZXRyeToge1xuICAgICAgICAgICAgICBjb29yZGluYXRlczogW1xuICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgIFtkcmFnTG9uZ2l0dWRlLCBib3R0b21MYXRpdHVkZV0sXG4gICAgICAgICAgICAgICAgICBbZHJhZ0xvbmdpdHVkZSwgdG9wTGF0aXR1ZGVdLFxuICAgICAgICAgICAgICAgICAgW3RoaXMuY3VycmVudEJvdW5kcy5fc3cubG5nIC0gMC4xLCB0b3BMYXRpdHVkZV0sXG4gICAgICAgICAgICAgICAgICBbdGhpcy5jdXJyZW50Qm91bmRzLl9zdy5sbmcgLSAwLjEsIGJvdHRvbUxhdGl0dWRlXSxcbiAgICAgICAgICAgICAgICAgIFtkcmFnTG9uZ2l0dWRlLCBib3R0b21MYXRpdHVkZV0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgdHlwZTogJ1BvbHlnb24nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSxcbiAgICAgIHJpZ2h0OiB7XG4gICAgICAgIHR5cGU6ICdGZWF0dXJlQ29sbGVjdGlvbicsXG4gICAgICAgIGZlYXR1cmVzOiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgdHlwZTogJ0ZlYXR1cmUnLFxuICAgICAgICAgICAgcHJvcGVydGllczoge30sXG4gICAgICAgICAgICBnZW9tZXRyeToge1xuICAgICAgICAgICAgICBjb29yZGluYXRlczogW1xuICAgICAgICAgICAgICAgIFtcbiAgICAgICAgICAgICAgICAgIFtkcmFnTG9uZ2l0dWRlLCBib3R0b21MYXRpdHVkZV0sXG4gICAgICAgICAgICAgICAgICBbZHJhZ0xvbmdpdHVkZSwgdG9wTGF0aXR1ZGVdLFxuICAgICAgICAgICAgICAgICAgW3RoaXMuY3VycmVudEJvdW5kcy5fbmUubG5nICsgMC4xLCB0b3BMYXRpdHVkZV0sXG4gICAgICAgICAgICAgICAgICBbdGhpcy5jdXJyZW50Qm91bmRzLl9uZS5sbmcgKyAwLjEsIGJvdHRvbUxhdGl0dWRlXSxcbiAgICAgICAgICAgICAgICAgIFtkcmFnTG9uZ2l0dWRlLCBib3R0b21MYXRpdHVkZV0sXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgdHlwZTogJ1BvbHlnb24nLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgfSxcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSBpbml0aWFsaXplRXZlbnRMaXN0ZW5lcnMoKSB7XG4gICAgdGhpcy5jdXJyZW50Qm91bmRzID0gdGhpcy5tYXAubWFwIS5nZXRCb3VuZHMoKTtcblxuICAgIGlmICh0aGlzLm1hcC5kZWNrLmlzSW50ZXJsZWF2ZWQgJiYgdGhpcy5tYXAubWFwKSB7XG4gICAgICB0aGlzLm1hcC5tYXAub24oJ21vdmVzdGFydCcsIHRoaXMubWFwTGlzdGVuZXJzWydtb3Zlc3RhcnQnXSk7XG5cbiAgICAgIHRoaXMubWFwLm1hcC5vbignbW92ZWVuZCcsIHRoaXMubWFwTGlzdGVuZXJzWydtb3ZlZW5kJ10pO1xuICAgICAgdGhpcy5tYXAubWFwLm9uKCdtb3ZlJywgdGhpcy5tYXBMaXN0ZW5lcnNbJ21vdmUnXSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMubWFwLmRlY2sudmlld1N0YXRlQ2hhbmdlJFxuICAgICAgICAucGlwZSh0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSlcbiAgICAgICAgLnN1YnNjcmliZShkYXRhID0+IHtcbiAgICAgICAgICB0aGlzLmN1cnJlbnRCb3VuZHMgPSBkYXRhLnZpZXdTdGF0ZS5ib3VuZHM7XG4gICAgICAgICAgdGhpcy5jbGlwQ2hhbmdlLmVtaXQodGhpcy5nZXRDbGlwKCkpO1xuICAgICAgICAgIHRoaXMuZGVib3VuY2VkRW5kQ2xpcCgpO1xuICAgICAgICB9KTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHN0b3JlQm91bmRzKGV2ZW50OiBhbnkpIHtcbiAgICB0aGlzLmN1cnJlbnRCb3VuZHMgPSB0aGlzLm1hcC5tYXAhLmdldEJvdW5kcygpO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRDbGlwQW5kRW1pdCgpIHtcbiAgICB0aGlzLmNsaXBDaGFuZ2UuZW1pdCh0aGlzLmdldENsaXAoKSk7XG4gIH1cblxuICBwdWJsaWMgb25EcmFnTW92ZShldmVudDogSU91aURyYWdNb3ZlKSB7XG4gICAgaWYgKCdjdXJyZW50VHJhbnNsYXRlJyBpbiBldmVudCkge1xuICAgICAgY29uc3Qgd3JhcHBlckJib3ggPVxuICAgICAgICB0aGlzLm1hcHNXcmFwcGVyLm5hdGl2ZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICBjb25zdCB3aWR0aCA9IHdyYXBwZXJCYm94LndpZHRoO1xuICAgICAgY29uc3QgbGVmdFdpZHRoID1cbiAgICAgICAgKChldmVudC5jdXJyZW50VHJhbnNsYXRlLnggKyB0aGlzLmdldERyYWdDb250YWluZXJXaWR0aE9mZnNldCgpKSAvXG4gICAgICAgICAgd2lkdGgpICpcbiAgICAgICAgMTAwO1xuICAgICAgY29uc3QgcmlnaHRXaWR0aCA9IDEwMCAtIGxlZnRXaWR0aDtcbiAgICAgIGNvbnN0IHJpZ2h0TGVmdCA9XG4gICAgICAgIGV2ZW50LmN1cnJlbnRUcmFuc2xhdGUueCArIHRoaXMuZ2V0RHJhZ0NvbnRhaW5lcldpZHRoT2Zmc2V0KCk7XG4gICAgICB0aGlzLnJlbmRlcmVyLnNldEF0dHJpYnV0ZShcbiAgICAgICAgdGhpcy5nYW1tYU1hc2tMZWZ0Lm5hdGl2ZUVsZW1lbnQsXG4gICAgICAgICd3aWR0aCcsXG4gICAgICAgIGAke2xlZnRXaWR0aH0lYFxuICAgICAgKTtcbiAgICAgIHRoaXMucmVuZGVyZXIuc2V0QXR0cmlidXRlKFxuICAgICAgICB0aGlzLmdhbW1hTWFza1JpZ2h0Lm5hdGl2ZUVsZW1lbnQsXG4gICAgICAgICd3aWR0aCcsXG4gICAgICAgIGAke3JpZ2h0V2lkdGh9JWBcbiAgICAgICk7XG4gICAgICB0aGlzLnJlbmRlcmVyLnNldEF0dHJpYnV0ZShcbiAgICAgICAgdGhpcy5nYW1tYU1hc2tSaWdodC5uYXRpdmVFbGVtZW50LFxuICAgICAgICAneCcsXG4gICAgICAgIGAkeyhyaWdodExlZnQgLyB3aWR0aCkgKiAxMDB9JWBcbiAgICAgICk7XG4gICAgICB0aGlzLmNsaXBDaGFuZ2UuZW1pdCh0aGlzLmdldENsaXAoKSk7XG4gICAgICB0aGlzLmN1cnJlbnREcmFnUG9zaXRpb24gPSB7XG4gICAgICAgIHg6IGV2ZW50LmN1cnJlbnRUcmFuc2xhdGUueCxcbiAgICAgICAgeTogZXZlbnQuY3VycmVudFRyYW5zbGF0ZS55LFxuICAgICAgfTtcbiAgICAgIHRoaXMuZHJhZ0xlZnRSYXRpbyA9XG4gICAgICAgIHRoaXMuY3VycmVudERyYWdQb3NpdGlvbi54IC8gdGhpcy5nZXRNYXBDb250YWluZXJXaWR0aCgpO1xuICAgICAgdGhpcy5kZWJvdW5jZWRFbmRDbGlwKCk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG9uRHJhZ0VuZCgpIHtcbiAgICB0aGlzLmRlYm91bmNlZEVuZENsaXAoKTtcbiAgfVxuXG4gIHByaXZhdGUgc2V0TGVmdExhYmVsUG9zaXRpb24oKSB7XG4gICAgaWYgKCF0aGlzLmltYWdlTGFiZWxMZWZ0KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGxlZnQgPVxuICAgICAgdGhpcy5jdXJyZW50RHJhZ1Bvc2l0aW9uLnggLVxuICAgICAgdGhpcy5pbWFnZUxhYmVsTGVmdC5uYXRpdmVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoICtcbiAgICAgIHRoaXMuZ2V0RHJhZ0NvbnRhaW5lcldpZHRoT2Zmc2V0KCkgLVxuICAgICAgdGhpcy5nZXREcmFnV2lkdGhPZmZzZXQoKTtcbiAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKFxuICAgICAgdGhpcy5pbWFnZUxhYmVsTGVmdC5uYXRpdmVFbGVtZW50LFxuICAgICAgJ3RyYW5zZm9ybScsXG4gICAgICBgdHJhbnNsYXRlKCR7bGVmdH1weCwgJHswfXB4KWBcbiAgICApO1xuICB9XG5cbiAgcHJpdmF0ZSByZXNpemVTaWRlQnlTaWRlKCkge1xuICAgIGNvbnN0IG1hcENvbnRhaW5lcldpZHRoID0gdGhpcy5nZXRNYXBDb250YWluZXJXaWR0aCgpO1xuICAgIGxldCBuZXdMZWZ0ID0gbWFwQ29udGFpbmVyV2lkdGggKiB0aGlzLmRyYWdMZWZ0UmF0aW87XG4gICAgY29uc3QgbGVmdEVkZ2UgPSB0aGlzLmdldERyYWdDb250YWluZXJXaWR0aE9mZnNldCgpO1xuICAgIGNvbnN0IHJpZ2h0RWRnZSA9IG1hcENvbnRhaW5lcldpZHRoIC0gdGhpcy5nZXREcmFnQ29udGFpbmVyV2lkdGhPZmZzZXQoKTtcbiAgICBpZiAobmV3TGVmdCA8IGxlZnRFZGdlKSB7XG4gICAgICBuZXdMZWZ0ID0gbGVmdEVkZ2U7XG4gICAgfSBlbHNlIGlmIChuZXdMZWZ0ID4gcmlnaHRFZGdlKSB7XG4gICAgICBuZXdMZWZ0ID0gcmlnaHRFZGdlO1xuICAgIH1cbiAgICB0aGlzLmN1cnJlbnREcmFnUG9zaXRpb24gPSB7XG4gICAgICB4OiBuZXdMZWZ0LFxuICAgICAgeTogdGhpcy5jdXJyZW50RHJhZ1Bvc2l0aW9uLnksXG4gICAgfTtcbiAgICB0aGlzLmRyYWdnYWJsZS51cGRhdGVUcmFuc2Zvcm0odGhpcy5jdXJyZW50RHJhZ1Bvc2l0aW9uKTtcbiAgICB0aGlzLmNsaXBDaGFuZ2UuZW1pdCh0aGlzLmdldENsaXAoKSk7XG4gIH1cblxuICBwcml2YXRlIGluaXRpYWxpemVSZXNpemVPYnNlcnZlcigpIHtcbiAgICB0aGlzLnJlc2l6ZU9ic2VydmVyID0gbmV3IFJlc2l6ZU9ic2VydmVyKCgpID0+IHtcbiAgICAgIHRoaXMucmVzaXplU2lkZUJ5U2lkZSgpO1xuICAgIH0pO1xuXG4gICAgdGhpcy5yZXNpemVPYnNlcnZlci5vYnNlcnZlKHRoaXMubWFwQ29udGFpbmVyKTtcbiAgfVxuXG4gIHByaXZhdGUgc3RhcnRDbGlwcGluZygpIHtcbiAgICBpZiAodGhpcy5yZWZyZXNoSW50ZXJ2YWwpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdGhpcy5yZWZyZXNoSW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICB0aGlzLmNsaXBDaGFuZ2UuZW1pdCh0aGlzLmdldENsaXAoKSk7XG4gICAgfSwgMjApO1xuICB9XG5cbiAgcHJpdmF0ZSBlbmRDbGlwcGluZygpIHtcbiAgICBpZiAodGhpcy5yZWZyZXNoSW50ZXJ2YWwpIHtcbiAgICAgIGNsZWFySW50ZXJ2YWwodGhpcy5yZWZyZXNoSW50ZXJ2YWwpO1xuICAgICAgdGhpcy5yZWZyZXNoSW50ZXJ2YWwgPSB1bmRlZmluZWQ7XG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdGhpcy5jbGlwQ2hhbmdlLmVtaXQodGhpcy5nZXRDbGlwKCkpO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG9uQmVmb3JlR2FtbWFDaGFuZ2UodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuYmVmb3JlR2FtbWEuc2V0KHZhbHVlKTtcblxuICAgIGNvbnN0IGZpbHRlcnMgPSB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yQWxsKFxuICAgICAgJy5iZWZvcmVHYW1tYUVsZW1lbnQnXG4gICAgKTtcbiAgICBmb3IgKGNvbnN0IGZpbHRlciBvZiBmaWx0ZXJzKSB7XG4gICAgICBmaWx0ZXIuc2V0QXR0cmlidXRlKCdhbXBsaXR1ZGUnLCBgJHt2YWx1ZX1gKTtcbiAgICAgIGZpbHRlci5zZXRBdHRyaWJ1dGUoJ2V4cG9uZW50JywgYCR7MSAvIHZhbHVlfWApO1xuICAgICAgLy8gZmlsdGVyLnNldEF0dHJpYnV0ZSgnb2Zmc2V0JywgYCR7KHZhbHVlIC0gMSkgLyA1fWApO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBvbkFmdGVyR2FtbWFDaGFuZ2UodmFsdWU6IG51bWJlcikge1xuICAgIHRoaXMuYWZ0ZXJHYW1tYS5zZXQodmFsdWUpO1xuXG4gICAgY29uc3QgZmlsdGVycyA9XG4gICAgICB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuYWZ0ZXJHYW1tYUVsZW1lbnQnKTtcbiAgICBmb3IgKGNvbnN0IGZpbHRlciBvZiBmaWx0ZXJzKSB7XG4gICAgICAvLyBmaWx0ZXIuc2V0QXR0cmlidXRlKCdhbXBsaXR1ZGUnLCBgJHt2YWx1ZX1gKTtcbiAgICAgIGZpbHRlci5zZXRBdHRyaWJ1dGUoJ2V4cG9uZW50JywgYCR7MSAvIHZhbHVlfWApO1xuICAgICAgLy8gZmlsdGVyLnNldEF0dHJpYnV0ZSgnb2Zmc2V0JywgYCR7KHZhbHVlIC0gMSkgLyA1fWApO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBuZ09uRGVzdHJveSgpIHtcbiAgICBmb3IgKGNvbnN0IHVubGlzdGVuZXIgb2YgdGhpcy51bmxpc3RlbmVycykge1xuICAgICAgdW5saXN0ZW5lcigpO1xuICAgIH1cbiAgICBpZiAodGhpcy5yZXNpemVPYnNlcnZlcikge1xuICAgICAgdGhpcy5yZXNpemVPYnNlcnZlci51bm9ic2VydmUodGhpcy5tYXBDb250YWluZXIpO1xuICAgIH1cblxuICAgIGlmICh0aGlzLnJlZnJlc2hJbnRlcnZhbCkge1xuICAgICAgY2xlYXJJbnRlcnZhbCh0aGlzLnJlZnJlc2hJbnRlcnZhbCk7XG4gICAgfVxuICAgIGlmICh0aGlzLm1hcD8ubWFwKSB7XG4gICAgICBmb3IgKGxldCBsaXN0ZW5lciBpbiB0aGlzLm1hcExpc3RlbmVycykge1xuICAgICAgICB0aGlzLm1hcC5tYXAub2ZmKGxpc3RlbmVyLCB0aGlzLm1hcExpc3RlbmVyc1tsaXN0ZW5lcl0pO1xuICAgICAgICB0aGlzLm1hcC5tYXAub2ZmKGxpc3RlbmVyLCB0aGlzLm1hcExpc3RlbmVyc1tsaXN0ZW5lcl0pO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XG4gICAgaWYgKCdtYXAnIGluIGNoYW5nZXMpIHtcbiAgICAgIHRoaXMubWFwID0gY2hhbmdlc1snbWFwJ10uY3VycmVudFZhbHVlO1xuICAgICAgaWYgKHRoaXMubWFwICYmICF0aGlzLmlzSW5pdGlhbGlzYXRpb25TdGFydGVkICYmIHRoaXMubWFwQ29udGVudCkge1xuICAgICAgICB0aGlzLnN1YnNjcmliZVRvTWFwTG9hZCgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuIiwiPGRpdiBjbGFzcz1cInNpZGUtYnktc2lkZS13cmFwcGVyXCIgW25nQ2xhc3NdPVwieydpbml0aWFsaXNlZCc6IGlzSW5pdGlhbGlzZWR9XCI+XG4gIDxkaXYgY2xhc3M9XCJtYXBzLXdyYXBwZXJcIiAjbWFwc1dyYXBwZXI+XG4gICAgPGRpdlxuICAgICAgICBvdWktZHJhZ2dhYmxlXG4gICAgICAgIChkcmFnTW92ZSk9XCJvbkRyYWdNb3ZlKCRldmVudClcIlxuICAgICAgICAoZHJhZ0VuZCk9XCJvbkRyYWdFbmQoKVwiXG4gICAgICAgICNkcmFnZ2FibGU9XCJPdWlEcmFnZ2FibGVEaXJlY3RpdmVcIlxuICAgICAgICBjbGFzcz1cImRyYWctY29udGFpbmVyXCJcbiAgICAgICAgI2RyYWdDb250YWluZXJcbiAgICAgICAgW25nQ2xhc3NdPVwieyB2ZXJ0aWNhbDogaXNWZXJ0aWNhbCwgaG9yaXpvbnRhbDogIWlzVmVydGljYWwgfVwiXG4gICAgPlxuICAgICAgPGRpdiBjbGFzcz1cImRyYWcgc2hhZG93XCIgI2RyYWc+PC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzPVwiZHJhZy1jYXJldC1jb250YWluZXJcIj5cbiAgICAgICAgPG91aS1pY29uXG4gICAgICAgICAgICBpY29uPVwiYXNzZXRzL2ljb25zL2NhcmV0LWxlZnQuc3ZnXCJcbiAgICAgICAgICAgIFtvcHRpb25zXT1cIntcbiAgICAgICAgICBzdHJva2VDb2xvcjogJ291aS1tYXBib3gtc2lkZS1ieS1zaWRlLWljb24tY29sb3InLFxuICAgICAgICAgIGZpbGxDb2xvcjogJ291aS1tYXBib3gtc2lkZS1ieS1zaWRlLWljb24tY29sb3InLFxuICAgICAgICAgIHZpZXdCb3g6ICcwIDAgNDggNDgnXG4gICAgICAgIH1cIlxuICAgICAgICAgICAgY2xhc3M9XCJkcmFnLWNhcmV0LWxlZnRcIlxuICAgICAgICA+PC9vdWktaWNvbj5cbiAgICAgICAgPG91aS1pY29uXG4gICAgICAgICAgICBpY29uPVwiYXNzZXRzL2ljb25zL2NhcmV0LXJpZ2h0LnN2Z1wiXG4gICAgICAgICAgICBbb3B0aW9uc109XCJ7XG4gICAgICAgICAgc3Ryb2tlQ29sb3I6ICdvdWktbWFwYm94LXNpZGUtYnktc2lkZS1pY29uLWNvbG9yJyxcbiAgICAgICAgICBmaWxsQ29sb3I6ICdvdWktbWFwYm94LXNpZGUtYnktc2lkZS1pY29uLWNvbG9yJyxcbiAgICAgICAgICB2aWV3Qm94OiAnMCAwIDQ4IDQ4J1xuICAgICAgICB9XCJcbiAgICAgICAgICAgIGNsYXNzPVwiZHJhZy1jYXJldC1yaWdodFwiXG4gICAgICAgID48L291aS1pY29uPlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICAgPGRpdiBjbGFzcz1cIm1hcC1jb250ZW50XCIgI21hcENvbnRlbnQ+XG4gICAgICA8c3ZnIGNsYXNzPVwiZ2FtbWEtbWFzay1zdmdcIj5cbiAgICAgICAgPGZpbHRlciBpZD1cImdhbW1hRmlsdGVyXCIgcHJpbWl0aXZlVW5pdHM9XCJvYmplY3RCb3VuZGluZ0JveFwiIHdpZHRoPVwiMTAwJVwiIGhlaWdodD1cIjEwMCVcIiB4PVwiMFwiIHk9XCIwXCI+XG4gICAgICAgICAgPGZlQ29sb3JNYXRyaXggcmVzdWx0PVwiQ1VSUkVOVFwiPjwvZmVDb2xvck1hdHJpeD5cbiAgICAgICAgICA8ZmVDb21wb25lbnRUcmFuc2ZlciAjZ2FtbWFNYXNrTGVmdCByZXN1bHQ9XCJMRUZUXCIgeD1cIjAlXCIgd2lkdGg9XCI1MCVcIiBoZWlnaHQ9XCIxMDAlXCIgeT1cIjAlXCI+XG4gICAgICAgICAgICA8ZmVGdW5jUlxuICAgICAgICAgICAgICAgIGNsYXNzPVwiYmVmb3JlR2FtbWFFbGVtZW50XCJcbiAgICAgICAgICAgICAgICB0eXBlPVwiZ2FtbWFcIlxuICAgICAgICAgICAgICAgIGFtcGxpdHVkZT1cIjBcIlxuICAgICAgICAgICAgICAgIGV4cG9uZW50PVwiMVwiXG4gICAgICAgICAgICAgICAgb2Zmc2V0PVwiMFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGZlRnVuY0dcbiAgICAgICAgICAgICAgICBjbGFzcz1cImJlZm9yZUdhbW1hRWxlbWVudFwiXG4gICAgICAgICAgICAgICAgdHlwZT1cImdhbW1hXCJcbiAgICAgICAgICAgICAgICBhbXBsaXR1ZGU9XCIwXCJcbiAgICAgICAgICAgICAgICBleHBvbmVudD1cIjFcIlxuICAgICAgICAgICAgICAgIG9mZnNldD1cIjBcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxmZUZ1bmNCXG4gICAgICAgICAgICAgICAgY2xhc3M9XCJiZWZvcmVHYW1tYUVsZW1lbnRcIlxuICAgICAgICAgICAgICAgIHR5cGU9XCJnYW1tYVwiXG4gICAgICAgICAgICAgICAgYW1wbGl0dWRlPVwiMFwiXG4gICAgICAgICAgICAgICAgZXhwb25lbnQ9XCIxXCJcbiAgICAgICAgICAgICAgICBvZmZzZXQ9XCIwXCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9mZUNvbXBvbmVudFRyYW5zZmVyPlxuICAgICAgICAgIDxmZUNvbXBvc2l0ZSBpbjI9XCJDVVJSRU5UXCIgaW49XCJMRUZUXCIgb3BlcmF0b3I9XCJvdmVyXCIgcmVzdWx0PVwiQ1VSUkVOVFwiPjwvZmVDb21wb3NpdGU+XG4gICAgICAgICAgPGZlQ29tcG9uZW50VHJhbnNmZXIgI2dhbW1hTWFza1JpZ2h0IHJlc3VsdD1cIlJJR0hUXCIgeD1cIjUwJVwiIHdpZHRoPVwiNTAlXCIgaGVpZ2h0PVwiMTAwJVwiIHk9XCIwJVwiPlxuICAgICAgICAgICAgPGZlRnVuY1JcbiAgICAgICAgICAgICAgICBjbGFzcz1cImFmdGVyR2FtbWFFbGVtZW50XCJcbiAgICAgICAgICAgICAgICB0eXBlPVwiZ2FtbWFcIlxuICAgICAgICAgICAgICAgIGFtcGxpdHVkZT1cIjFcIlxuICAgICAgICAgICAgICAgIGV4cG9uZW50PVwiMFwiXG4gICAgICAgICAgICAgICAgb2Zmc2V0PVwiMFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGZlRnVuY0dcbiAgICAgICAgICAgICAgICBjbGFzcz1cImFmdGVyR2FtbWFFbGVtZW50XCJcbiAgICAgICAgICAgICAgICB0eXBlPVwiZ2FtbWFcIlxuICAgICAgICAgICAgICAgIGFtcGxpdHVkZT1cIjFcIlxuICAgICAgICAgICAgICAgIGV4cG9uZW50PVwiMFwiXG4gICAgICAgICAgICAgICAgb2Zmc2V0PVwiMFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGZlRnVuY0JcbiAgICAgICAgICAgICAgICBjbGFzcz1cImFmdGVyR2FtbWFFbGVtZW50XCJcbiAgICAgICAgICAgICAgICB0eXBlPVwiZ2FtbWFcIlxuICAgICAgICAgICAgICAgIGFtcGxpdHVkZT1cIjFcIlxuICAgICAgICAgICAgICAgIGV4cG9uZW50PVwiMFwiXG4gICAgICAgICAgICAgICAgb2Zmc2V0PVwiMFwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZmVDb21wb25lbnRUcmFuc2Zlcj5cblxuICAgICAgICAgIDxmZUNvbXBvc2l0ZSBpbjI9XCJDVVJSRU5UXCIgaW49XCJSSUdIVFwiIG9wZXJhdG9yPVwib3ZlclwiIHJlc3VsdD1cIkNPTVBPU0lURVwiPlxuXG4gICAgICAgICAgPC9mZUNvbXBvc2l0ZT5cbjwhLS0gICAgICAgICAgPGZlQ29tcG9zaXRlIGluMj1cIlNvdXJjZUdyYXBoaWNcIiBpbj1cIkZJUlNUX0NPTVBPU0lURVwiIG9wZXJhdG9yPVwib3ZlclwiIHJlc3VsdD1cIkZJUlNUX0NPTUJJTkVEX0NPTVBPU0lURVwiPi0tPlxuXG48IS0tICAgICAgICAgIDwvZmVDb21wb3NpdGU+LS0+XG48IS0tICAgICAgICAgIDxmZUNvbXBvc2l0ZSBpbjI9XCJGSVJTVF9DT01CSU5FRF9DT01QT1NJVEVcIiBpbj1cIlNFQ09ORFwiIG9wZXJhdG9yPVwib3ZlclwiIHJlc3VsdD1cIlNFQ09ORF9DT01QT1NJVEVcIj4tLT5cblxuPCEtLSAgICAgICAgICA8L2ZlQ29tcG9zaXRlPi0tPlxuPCEtLSAgICAgICAgICA8ZmVDb21wb3NpdGUgaW4yPVwiRklSU1RfQ09NQklORURfQ09NUE9TSVRFXCIgaW49XCJTRUNPTkRfQ09NUE9TSVRFXCIgb3BlcmF0b3I9XCJpblwiPjwvZmVDb21wb3NpdGU+LS0+XG4gICAgICAgIDwvZmlsdGVyPlxuICAgICAgPC9zdmc+XG5cbiAgICAgIDxuZy1jb250ZW50PlxuXG4gICAgICA8L25nLWNvbnRlbnQ+XG4gICAgPC9kaXY+XG5cblxuPCEtLSAgICA8ZGl2IGNsYXNzPVwic2lkZS1ieS1zaWRlLWxhYmVsLXdyYXBwZXIgbGVmdFwiICpuZ0lmPVwibGVmdExhYmVsVGVtcGxhdGVcIj4tLT5cbjwhLS0gICAgICA8bmctY29udGVudCAqbmdUZW1wbGF0ZU91dGxldD1cImxlZnRMYWJlbFRlbXBsYXRlXCI+PC9uZy1jb250ZW50Pi0tPlxuPCEtLSAgICA8L2Rpdj4tLT5cblxuPCEtLSAgICA8ZGl2IGNsYXNzPVwic2lkZS1ieS1zaWRlLWxhYmVsLXdyYXBwZXIgcmlnaHRcIiBbbmdDbGFzc109XCJ7J2hhcy1nZW9sb2NhdGUnOiBtYXA/Lm9wdGlvbnM/Lmdlb0xvY2F0ZUNvbnRyb2x9XCIgKm5nSWY9XCJyaWdodExhYmVsVGVtcGxhdGVcIj4tLT5cbjwhLS0gICAgICA8bmctY29udGVudCAqbmdUZW1wbGF0ZU91dGxldD1cInJpZ2h0TGFiZWxUZW1wbGF0ZVwiPjwvbmctY29udGVudD4tLT5cbjwhLS0gICAgPC9kaXY+LS0+XG5cbiAgPC9kaXY+XG4gIDxkaXYgY2xhc3M9XCJnYW1tYS1zbGlkZXItd3JhcHBlclwiPlxuICAgIDxkaXYgY2xhc3M9XCJnYW1tYS1zbGlkZXIgbGVmdFwiPlxuICAgICAgPG91aS1zbGlkZXIgW29wdGlvbnNdPVwiZ2FtbWFTbGlkZXJPcHRpb25zKClcIiBbdmFsdWVdPVwiYmVmb3JlR2FtbWEoKVwiICh2YWx1ZUNoYW5nZSk9XCJvbkJlZm9yZUdhbW1hQ2hhbmdlKCRldmVudClcIlxuICAgICAgPjwvb3VpLXNsaWRlcj5cbiAgICA8L2Rpdj5cbiAgICA8ZGl2IGNsYXNzPVwiZ2FtbWEtc2xpZGVyIHJpZ2h0XCI+XG4gICAgICA8b3VpLXNsaWRlclxuICAgICAgICAgIFtvcHRpb25zXT1cImdhbW1hU2xpZGVyT3B0aW9ucygpXCJcbiAgICAgICAgICBbdmFsdWVdPVwiYWZ0ZXJHYW1tYSgpXCJcbiAgICAgICAgICAodmFsdWVDaGFuZ2UpPVwib25BZnRlckdhbW1hQ2hhbmdlKCRldmVudClcIlxuICAgICAgPjwvb3VpLXNsaWRlcj5cbiAgICA8L2Rpdj5cblxuICAgIDxuZy10ZW1wbGF0ZSAjdGh1bWJJY29uVGVtcGxhdGU+XG4gICAgICA8b3VpLWljb24gIFtpY29uXT1cIidhc3NldHMvaWNvbnMvYnJpZ2h0bmVzcy5zdmcnXCJcbiAgICAgICAgICAgICAgICAgW29wdGlvbnNdPVwie1xuICAgIHZpZXdCb3g6ICcwIDAgNDggNDgnLFxuICAgIHNpemU6ICcxM3B4JyxcbiAgICBmaWxsQ29sb3I6ICdjb2xvci1iYWNrZ3JvdW5kLXByaW1hcnktdGV4dCcsXG4gICAgc3Ryb2tlQ29sb3I6ICdjb2xvci1iYWNrZ3JvdW5kLXByaW1hcnktdGV4dCcsXG4gICAgfVwiPlxuXG4gICAgICA8L291aS1pY29uPlxuICAgIDwvbmctdGVtcGxhdGU+XG4gIDwvZGl2PlxuXG5cbjwvZGl2PlxuIl19