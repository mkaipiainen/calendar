import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, ViewChild, } from '@angular/core';
import { filter } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i0 from "@angular/core";
import * as i1 from "../collapsible.service";
/**
 * A component part of a group of components that can be used to create collapsible content-blocks.
 * This component is used to toggle the content of the collapsible block. Use this in conjunction with oui-collapsible-content.
 *
 * @Input() group: string -               The group of the collapsible component. This needs to match the toggle that you want to use to
 *                                        toggle the content.
 * @Input() isOpen: boolean -             You can use this input to control whether or not the collapsible content should be open
 *                                        For example if you want it to be initially toggled open, then you can pass true to this input
 * @Input() disableClickToggle: boolean - This can be used to disable toggling the collapsible content by clicking on the toggle
 *                                        In this case, it can only be toggled programmatically.
 *
 * @Output() isOpenChange: boolean - Emitted when the toggle is opened/closed
 * Example usage:
 *
 * <oui-collapsible-toggle [isOpen]="isFirstGroupOpen" group="first-group"></oui-collapsible-toggle>
 * <oui-collapsible-content group=first-group">
 *   <div class="content">You can put any content here that you desire</div>
 * </oui-collapsible-content>
 */
export class OuiCollapsibleToggleComponent {
    ouiCollapsibleService;
    destroyRef;
    group;
    isOpen = false;
    disableClickToggle = false;
    toggleContainer;
    toggle;
    isOpenChange = new EventEmitter();
    isInitialOpenSet = false;
    constructor(ouiCollapsibleService, destroyRef) {
        this.ouiCollapsibleService = ouiCollapsibleService;
        this.destroyRef = destroyRef;
    }
    ngAfterViewInit() {
        this.ouiCollapsibleService.registerToggle(this.group, this);
        this.ouiCollapsibleService.collapsibleToggled$
            .pipe(filter((data) => {
            return data.group === this.group;
        }), takeUntilDestroyed(this.destroyRef))
            .subscribe((data) => {
            this.isOpen = data.isOpen;
            if (this.isInitialOpenSet) {
                this.isOpenChange.emit(this.isOpen);
            }
        });
        if (this.isOpen) {
            this.ouiCollapsibleService.toggle(this.group, true);
        }
        this.isInitialOpenSet = true;
    }
    onClick() {
        if (!this.disableClickToggle) {
            this.doToggle();
        }
    }
    doToggle() {
        this.ouiCollapsibleService.toggle(this.group);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCollapsibleToggleComponent, deps: [{ token: i1.OuiCollapsibleService }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiCollapsibleToggleComponent, isStandalone: true, selector: "oui-collapsible-toggle", inputs: { group: "group", isOpen: "isOpen", disableClickToggle: "disableClickToggle" }, outputs: { isOpenChange: "isOpenChange" }, viewQueries: [{ propertyName: "toggleContainer", first: true, predicate: ["toggleContainer"], descendants: true }, { propertyName: "toggle", first: true, predicate: ["toggle"], descendants: true }], ngImport: i0, template: "<div\n  class=\"oui-collapsible-toggle-container\"\n  #toggleContainer\n  (click)=\"onClick()\"\n>\n  <ng-content #toggle></ng-content>\n</div>\n", styles: [":host{width:100%;position:relative}:host .oui-collapsible-toggle-container{width:100%}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCollapsibleToggleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-collapsible-toggle', standalone: true, imports: [], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"oui-collapsible-toggle-container\"\n  #toggleContainer\n  (click)=\"onClick()\"\n>\n  <ng-content #toggle></ng-content>\n</div>\n", styles: [":host{width:100%;position:relative}:host .oui-collapsible-toggle-container{width:100%}\n"] }]
        }], ctorParameters: () => [{ type: i1.OuiCollapsibleService }, { type: i0.DestroyRef }], propDecorators: { group: [{
                type: Input
            }], isOpen: [{
                type: Input
            }], disableClickToggle: [{
                type: Input
            }], toggleContainer: [{
                type: ViewChild,
                args: ['toggleContainer']
            }], toggle: [{
                type: ViewChild,
                args: ['toggle']
            }], isOpenChange: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29sbGFwc2libGUtdG9nZ2xlLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvY29sbGFwc2libGUvY29sbGFwc2libGUtdG9nZ2xlL2NvbGxhcHNpYmxlLXRvZ2dsZS5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL2NvbGxhcHNpYmxlL2NvbGxhcHNpYmxlLXRvZ2dsZS9jb2xsYXBzaWJsZS10b2dnbGUuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUVMLHVCQUF1QixFQUN2QixTQUFTLEVBR1QsWUFBWSxFQUNaLEtBQUssRUFDTCxNQUFNLEVBQ04sU0FBUyxHQUNWLE1BQU0sZUFBZSxDQUFDO0FBS3ZCLE9BQU8sRUFBRSxNQUFNLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDOUIsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7OztBQUVoRTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBa0JHO0FBU0gsTUFBTSxPQUFPLDZCQUE2QjtJQWM5QjtJQUNBO0lBZEQsS0FBSyxDQUFTO0lBQ2QsTUFBTSxHQUFHLEtBQUssQ0FBQztJQUNmLGtCQUFrQixHQUFHLEtBQUssQ0FBQztJQUVOLGVBQWUsQ0FBYTtJQUNyQyxNQUFNLENBQWE7SUFHeEMsWUFBWSxHQUFHLElBQUksWUFBWSxFQUFXLENBQUM7SUFFbkMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO0lBRWpDLFlBQ1UscUJBQTRDLEVBQzVDLFVBQXNCO1FBRHRCLDBCQUFxQixHQUFyQixxQkFBcUIsQ0FBdUI7UUFDNUMsZUFBVSxHQUFWLFVBQVUsQ0FBWTtJQUM3QixDQUFDO0lBRUosZUFBZTtRQUNiLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQztRQUM1RCxJQUFJLENBQUMscUJBQXFCLENBQUMsbUJBQW1CO2FBQzNDLElBQUksQ0FDSCxNQUFNLENBQUMsQ0FBQyxJQUF5QixFQUFFLEVBQUU7WUFDbkMsT0FBTyxJQUFJLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDbkMsQ0FBQyxDQUFDLEVBQ0Ysa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUNwQzthQUNBLFNBQVMsQ0FBQyxDQUFDLElBQXlCLEVBQUUsRUFBRTtZQUN2QyxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUM7WUFDMUIsSUFBSSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDMUIsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3RDLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVMLElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2hCLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN0RCxDQUFDO1FBQ0QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQztJQUMvQixDQUFDO0lBRU0sT0FBTztRQUNaLElBQUksQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztZQUM3QixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDbEIsQ0FBQztJQUNILENBQUM7SUFFTSxRQUFRO1FBQ2IsSUFBSSxDQUFDLHFCQUFxQixDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDaEQsQ0FBQzt1R0FoRFUsNkJBQTZCOzJGQUE3Qiw2QkFBNkIsNFpDN0MxQyxtSkFPQTs7MkZEc0NhLDZCQUE2QjtrQkFSekMsU0FBUzsrQkFDRSx3QkFBd0IsY0FHdEIsSUFBSSxXQUNQLEVBQUUsbUJBQ00sdUJBQXVCLENBQUMsTUFBTTttSEFHdEMsS0FBSztzQkFBYixLQUFLO2dCQUNHLE1BQU07c0JBQWQsS0FBSztnQkFDRyxrQkFBa0I7c0JBQTFCLEtBQUs7Z0JBRXdCLGVBQWU7c0JBQTVDLFNBQVM7dUJBQUMsaUJBQWlCO2dCQUNQLE1BQU07c0JBQTFCLFNBQVM7dUJBQUMsUUFBUTtnQkFHbkIsWUFBWTtzQkFEWCxNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIENvbXBvbmVudCxcbiAgRGVzdHJveVJlZixcbiAgRWxlbWVudFJlZixcbiAgRXZlbnRFbWl0dGVyLFxuICBJbnB1dCxcbiAgT3V0cHV0LFxuICBWaWV3Q2hpbGQsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtcbiAgT3VpQ29sbGFwc2libGVTZXJ2aWNlLFxuICBJQ29sbGFwc2libGVUb2dnbGVkLFxufSBmcm9tICcuLi9jb2xsYXBzaWJsZS5zZXJ2aWNlJztcbmltcG9ydCB7IGZpbHRlciB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgdGFrZVVudGlsRGVzdHJveWVkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZS9yeGpzLWludGVyb3AnO1xuXG4vKipcbiAqIEEgY29tcG9uZW50IHBhcnQgb2YgYSBncm91cCBvZiBjb21wb25lbnRzIHRoYXQgY2FuIGJlIHVzZWQgdG8gY3JlYXRlIGNvbGxhcHNpYmxlIGNvbnRlbnQtYmxvY2tzLlxuICogVGhpcyBjb21wb25lbnQgaXMgdXNlZCB0byB0b2dnbGUgdGhlIGNvbnRlbnQgb2YgdGhlIGNvbGxhcHNpYmxlIGJsb2NrLiBVc2UgdGhpcyBpbiBjb25qdW5jdGlvbiB3aXRoIG91aS1jb2xsYXBzaWJsZS1jb250ZW50LlxuICpcbiAqIEBJbnB1dCgpIGdyb3VwOiBzdHJpbmcgLSAgICAgICAgICAgICAgIFRoZSBncm91cCBvZiB0aGUgY29sbGFwc2libGUgY29tcG9uZW50LiBUaGlzIG5lZWRzIHRvIG1hdGNoIHRoZSB0b2dnbGUgdGhhdCB5b3Ugd2FudCB0byB1c2UgdG9cbiAqICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvZ2dsZSB0aGUgY29udGVudC5cbiAqIEBJbnB1dCgpIGlzT3BlbjogYm9vbGVhbiAtICAgICAgICAgICAgIFlvdSBjYW4gdXNlIHRoaXMgaW5wdXQgdG8gY29udHJvbCB3aGV0aGVyIG9yIG5vdCB0aGUgY29sbGFwc2libGUgY29udGVudCBzaG91bGQgYmUgb3BlblxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRm9yIGV4YW1wbGUgaWYgeW91IHdhbnQgaXQgdG8gYmUgaW5pdGlhbGx5IHRvZ2dsZWQgb3BlbiwgdGhlbiB5b3UgY2FuIHBhc3MgdHJ1ZSB0byB0aGlzIGlucHV0XG4gKiBASW5wdXQoKSBkaXNhYmxlQ2xpY2tUb2dnbGU6IGJvb2xlYW4gLSBUaGlzIGNhbiBiZSB1c2VkIHRvIGRpc2FibGUgdG9nZ2xpbmcgdGhlIGNvbGxhcHNpYmxlIGNvbnRlbnQgYnkgY2xpY2tpbmcgb24gdGhlIHRvZ2dsZVxuICogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSW4gdGhpcyBjYXNlLCBpdCBjYW4gb25seSBiZSB0b2dnbGVkIHByb2dyYW1tYXRpY2FsbHkuXG4gKlxuICogQE91dHB1dCgpIGlzT3BlbkNoYW5nZTogYm9vbGVhbiAtIEVtaXR0ZWQgd2hlbiB0aGUgdG9nZ2xlIGlzIG9wZW5lZC9jbG9zZWRcbiAqIEV4YW1wbGUgdXNhZ2U6XG4gKlxuICogPG91aS1jb2xsYXBzaWJsZS10b2dnbGUgW2lzT3Blbl09XCJpc0ZpcnN0R3JvdXBPcGVuXCIgZ3JvdXA9XCJmaXJzdC1ncm91cFwiPjwvb3VpLWNvbGxhcHNpYmxlLXRvZ2dsZT5cbiAqIDxvdWktY29sbGFwc2libGUtY29udGVudCBncm91cD1maXJzdC1ncm91cFwiPlxuICogICA8ZGl2IGNsYXNzPVwiY29udGVudFwiPllvdSBjYW4gcHV0IGFueSBjb250ZW50IGhlcmUgdGhhdCB5b3UgZGVzaXJlPC9kaXY+XG4gKiA8L291aS1jb2xsYXBzaWJsZS1jb250ZW50PlxuICovXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdvdWktY29sbGFwc2libGUtdG9nZ2xlJyxcbiAgdGVtcGxhdGVVcmw6ICcuL2NvbGxhcHNpYmxlLXRvZ2dsZS5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL2NvbGxhcHNpYmxlLXRvZ2dsZS5jb21wb25lbnQuc2NzcyddLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIE91aUNvbGxhcHNpYmxlVG9nZ2xlQ29tcG9uZW50IGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCB7XG4gIEBJbnB1dCgpIGdyb3VwOiBzdHJpbmc7XG4gIEBJbnB1dCgpIGlzT3BlbiA9IGZhbHNlO1xuICBASW5wdXQoKSBkaXNhYmxlQ2xpY2tUb2dnbGUgPSBmYWxzZTtcblxuICBAVmlld0NoaWxkKCd0b2dnbGVDb250YWluZXInKSB0b2dnbGVDb250YWluZXI6IEVsZW1lbnRSZWY7XG4gIEBWaWV3Q2hpbGQoJ3RvZ2dsZScpIHRvZ2dsZTogRWxlbWVudFJlZjtcblxuICBAT3V0cHV0KClcbiAgaXNPcGVuQ2hhbmdlID0gbmV3IEV2ZW50RW1pdHRlcjxib29sZWFuPigpO1xuXG4gIHByaXZhdGUgaXNJbml0aWFsT3BlblNldCA9IGZhbHNlO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgb3VpQ29sbGFwc2libGVTZXJ2aWNlOiBPdWlDb2xsYXBzaWJsZVNlcnZpY2UsXG4gICAgcHJpdmF0ZSBkZXN0cm95UmVmOiBEZXN0cm95UmVmXG4gICkge31cblxuICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XG4gICAgdGhpcy5vdWlDb2xsYXBzaWJsZVNlcnZpY2UucmVnaXN0ZXJUb2dnbGUodGhpcy5ncm91cCwgdGhpcyk7XG4gICAgdGhpcy5vdWlDb2xsYXBzaWJsZVNlcnZpY2UuY29sbGFwc2libGVUb2dnbGVkJFxuICAgICAgLnBpcGUoXG4gICAgICAgIGZpbHRlcigoZGF0YTogSUNvbGxhcHNpYmxlVG9nZ2xlZCkgPT4ge1xuICAgICAgICAgIHJldHVybiBkYXRhLmdyb3VwID09PSB0aGlzLmdyb3VwO1xuICAgICAgICB9KSxcbiAgICAgICAgdGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZilcbiAgICAgIClcbiAgICAgIC5zdWJzY3JpYmUoKGRhdGE6IElDb2xsYXBzaWJsZVRvZ2dsZWQpID0+IHtcbiAgICAgICAgdGhpcy5pc09wZW4gPSBkYXRhLmlzT3BlbjtcbiAgICAgICAgaWYgKHRoaXMuaXNJbml0aWFsT3BlblNldCkge1xuICAgICAgICAgIHRoaXMuaXNPcGVuQ2hhbmdlLmVtaXQodGhpcy5pc09wZW4pO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgIGlmICh0aGlzLmlzT3Blbikge1xuICAgICAgdGhpcy5vdWlDb2xsYXBzaWJsZVNlcnZpY2UudG9nZ2xlKHRoaXMuZ3JvdXAsIHRydWUpO1xuICAgIH1cbiAgICB0aGlzLmlzSW5pdGlhbE9wZW5TZXQgPSB0cnVlO1xuICB9XG5cbiAgcHVibGljIG9uQ2xpY2soKSB7XG4gICAgaWYgKCF0aGlzLmRpc2FibGVDbGlja1RvZ2dsZSkge1xuICAgICAgdGhpcy5kb1RvZ2dsZSgpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBkb1RvZ2dsZSgpIHtcbiAgICB0aGlzLm91aUNvbGxhcHNpYmxlU2VydmljZS50b2dnbGUodGhpcy5ncm91cCk7XG4gIH1cbn1cbiIsIjxkaXZcbiAgY2xhc3M9XCJvdWktY29sbGFwc2libGUtdG9nZ2xlLWNvbnRhaW5lclwiXG4gICN0b2dnbGVDb250YWluZXJcbiAgKGNsaWNrKT1cIm9uQ2xpY2soKVwiXG4+XG4gIDxuZy1jb250ZW50ICN0b2dnbGU+PC9uZy1jb250ZW50PlxuPC9kaXY+XG4iXX0=