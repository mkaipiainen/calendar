import { Directive, EventEmitter, HostListener, Inject, Output, } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { ContainerConstraint } from './container-constraint';
import { GUID } from 'orbital-ui/helpers';
import { DefaultBehavior } from './behavior-default';
import { InertiaBehavior, } from './behavior-inertia';
import { SnapBehavior } from './behavior-snap';
import { RubberbandBehavior, } from './behavior-rubberband';
import { CopyBbox, GetTranslateXY } from './helpers';
import * as i0 from "@angular/core";
import * as i1 from "./draggable.service";
/**
 * Axis: Defines an axis by which dragging is restricted. By default dragging works on all axis.
 * constraint: A custom constraint by which dragging is restricted. This function is triggered on every dragMove. If returning false, dragging won't work.
 * container: An element inside of which dragging is restricted.
 * containerAnchor: Whether or not elements should be restricted inside the container by their edge or by their center
 * positionHook: This hook can be used to manually adjust how the object is dragged. The parameter is where the object WOULD ordinarily be dragged,
 *               and the return-value is where it will be dragged instead.
 */
// TODO: Remove dependency to this component from oui-slider. Duplicate code if needed, as long as side-effects don't propagate
/**
 * Directive that can be used to add functionality to any element that enables them to be dragged around.
 * NOTE: EXCERCISE GREAT CARE WHEN ADJUSTING THIS COMPONENT, AS OTHER COMPONENTS LIKE oui-SLIDER DEPEND ON IT
 *
 * @Input() ouiDraggableOptions: IOuiDraggableOptions
 *   Options passed to the directive
 *
 * @Output() dragMove: EventEmitter<IDragMove>
 *   Event triggered when dragged object is moved
 * @Output() dragStart: EventEmitter<MouseEvent|TouchEvent>
 *   Event triggered when dragging starts
 * @Output() dragEnd: EventEmitter<MouseEvent|TouchEvent>
 *   Event triggered when dragging ends
 */
// TODO: Change to work so that moved distance is taken from how much the mouse has moved between last move and now
//  This will make it so that it's possible to hook into that difference, making it possible to adjust the rate of dragging etc. Now this would be basically impossible
export class OuiDraggableDirective {
    elementRef;
    document;
    destroyRef;
    renderer;
    ouiDraggableService;
    dragMove = new EventEmitter();
    dragStart = new EventEmitter();
    dragEnd = new EventEmitter();
    element;
    behavior = undefined;
    currentTransform = {
        x: 0,
        y: 0,
    };
    id = GUID();
    dragMoveHooks = [];
    constructor(elementRef, document, destroyRef, renderer, ouiDraggableService) {
        this.elementRef = elementRef;
        this.document = document;
        this.destroyRef = destroyRef;
        this.renderer = renderer;
        this.ouiDraggableService = ouiDraggableService;
    }
    ngAfterViewInit() {
        const currentPosition = this.elementRef.nativeElement.style.position;
        this.elementRef.nativeElement.style.position =
            currentPosition === 'fixed' ? 'fixed' : 'absolute';
        const currentTranslate = GetTranslateXY(this.elementRef.nativeElement);
        this.elementRef.nativeElement.style.transform = `translateX(${currentTranslate.x}px) translateY(${currentTranslate.y}px)`;
        this.currentTransform = currentTranslate;
        this.element = this.elementRef.nativeElement;
        this.element.style.touchAction = 'none';
    }
    updateTransform(value) {
        if (this.behavior) {
            this.behavior.updateTransform(value);
        }
    }
    addInertiaBehavior(options) {
        this.behavior = new InertiaBehavior(this, options);
        return this.behavior;
    }
    addRubberbandBehavior(options) {
        this.behavior = new RubberbandBehavior(this, options);
        return this.behavior;
    }
    addDefaultBehavior(options) {
        this.behavior = new DefaultBehavior(this, options);
        return this.behavior;
    }
    addSnapBehavior(options) {
        this.behavior = new SnapBehavior(this, options, this.ouiDraggableService);
        return this.behavior;
    }
    addContainerConstraint(options) {
        this.dragMoveHooks.push((draggable, targetRect) => {
            return ContainerConstraint(options.container, targetRect, options.anchor);
        });
    }
    addAxisConstraint(axis) {
        this.dragMoveHooks.push((draggable, targetRect, event) => {
            const x = axis === 'x' ? targetRect.x : draggable.getBbox().x;
            const y = axis === 'y' ? targetRect.y : draggable.getBbox().y;
            return {
                ...CopyBbox(targetRect),
                x,
                y,
                left: x,
                top: y,
            };
        });
    }
    addCustomConstraint(constraint) {
        this.dragMoveHooks.push(constraint);
    }
    getBbox() {
        return this.elementRef.nativeElement.getBoundingClientRect();
    }
    click(event) {
        event.stopPropagation();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDraggableDirective, deps: [{ token: i0.ElementRef }, { token: DOCUMENT }, { token: i0.DestroyRef }, { token: i0.Renderer2 }, { token: i1.OuiDraggableService }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.1", type: OuiDraggableDirective, isStandalone: true, selector: "[oui-draggable]", outputs: { dragMove: "dragMove", dragStart: "dragStart", dragEnd: "dragEnd" }, host: { listeners: { "click": "click($event)" } }, exportAs: ["OuiDraggableDirective"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDraggableDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[oui-draggable]',
                    standalone: true,
                    exportAs: 'OuiDraggableDirective',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.DestroyRef }, { type: i0.Renderer2 }, { type: i1.OuiDraggableService }], propDecorators: { dragMove: [{
                type: Output
            }], dragStart: [{
                type: Output
            }], dragEnd: [{
                type: Output
            }], click: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHJhZ2dhYmxlLmRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvZHJhZ2dhYmxlL2RyYWdnYWJsZS5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUdMLFNBQVMsRUFFVCxZQUFZLEVBQ1osWUFBWSxFQUNaLE1BQU0sRUFDTixNQUFNLEdBRVAsTUFBTSxlQUFlLENBQUM7QUFDdkIsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzNDLE9BQU8sRUFBRSxtQkFBbUIsRUFBRSxNQUFNLHdCQUF3QixDQUFDO0FBRTdELE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQVExQyxPQUFPLEVBQWdCLGVBQWUsRUFBRSxNQUFNLG9CQUFvQixDQUFDO0FBQ25FLE9BQU8sRUFFTCxlQUFlLEdBRWhCLE1BQU0sb0JBQW9CLENBQUM7QUFDNUIsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBRS9DLE9BQU8sRUFFTCxrQkFBa0IsR0FDbkIsTUFBTSx1QkFBdUIsQ0FBQztBQUMvQixPQUFPLEVBQUUsUUFBUSxFQUFFLGNBQWMsRUFBRSxNQUFNLFdBQVcsQ0FBQzs7O0FBRXJEOzs7Ozs7O0dBT0c7QUFFSCwrSEFBK0g7QUFDL0g7Ozs7Ozs7Ozs7Ozs7R0FhRztBQUNILG1IQUFtSDtBQUNuSCx1S0FBdUs7QUFPdkssTUFBTSxPQUFPLHFCQUFxQjtJQW1CdkI7SUFDa0I7SUFDbEI7SUFDQTtJQUNBO0lBdEJDLFFBQVEsR0FBRyxJQUFJLFlBQVksRUFBcUMsQ0FBQztJQUNqRSxTQUFTLEdBQUcsSUFBSSxZQUFZLEVBQTJCLENBQUM7SUFDeEQsT0FBTyxHQUFHLElBQUksWUFBWSxFQUF1QyxDQUFDO0lBRXBFLE9BQU8sQ0FBYztJQUN0QixRQUFRLEdBS0MsU0FBUyxDQUFDO0lBQ25CLGdCQUFnQixHQUFXO1FBQ2hDLENBQUMsRUFBRSxDQUFDO1FBQ0osQ0FBQyxFQUFFLENBQUM7S0FDTCxDQUFDO0lBQ0ssRUFBRSxHQUFHLElBQUksRUFBRSxDQUFDO0lBQ1osYUFBYSxHQUE0QixFQUFFLENBQUM7SUFDbkQsWUFDUyxVQUFzQixFQUNKLFFBQWtCLEVBQ3BDLFVBQXNCLEVBQ3RCLFFBQW1CLEVBQ25CLG1CQUF3QztRQUp4QyxlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQ0osYUFBUSxHQUFSLFFBQVEsQ0FBVTtRQUNwQyxlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQ3RCLGFBQVEsR0FBUixRQUFRLENBQVc7UUFDbkIsd0JBQW1CLEdBQW5CLG1CQUFtQixDQUFxQjtJQUM5QyxDQUFDO0lBQ0csZUFBZTtRQUNwQixNQUFNLGVBQWUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDO1FBQ3JFLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxRQUFRO1lBQzFDLGVBQWUsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDO1FBQ3JELE1BQU0sZ0JBQWdCLEdBQUcsY0FBYyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDdkUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLFNBQVMsR0FBRyxjQUFjLGdCQUFnQixDQUFDLENBQUMsa0JBQWtCLGdCQUFnQixDQUFDLENBQUMsS0FBSyxDQUFDO1FBQzFILElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxnQkFBZ0IsQ0FBQztRQUN6QyxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDO1FBQzdDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLFdBQVcsR0FBRyxNQUFNLENBQUM7SUFDMUMsQ0FBQztJQUVNLGVBQWUsQ0FBQyxLQUFhO1FBQ2xDLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ2xCLElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZDLENBQUM7SUFDSCxDQUFDO0lBRU0sa0JBQWtCLENBQUMsT0FBZ0M7UUFDeEQsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLGVBQWUsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDbkQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3ZCLENBQUM7SUFFTSxxQkFBcUIsQ0FBQyxPQUFtQztRQUM5RCxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksa0JBQWtCLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQ3RELE9BQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQztJQUN2QixDQUFDO0lBRU0sa0JBQWtCLENBQUMsT0FBaUM7UUFDekQsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLGVBQWUsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDbkQsT0FBTyxJQUFJLENBQUMsUUFBUSxDQUFDO0lBQ3ZCLENBQUM7SUFFTSxlQUFlLENBQUMsT0FBNkI7UUFDbEQsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLFlBQVksQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQzFFLE9BQU8sSUFBSSxDQUFDLFFBQXdCLENBQUM7SUFDdkMsQ0FBQztJQUVNLHNCQUFzQixDQUFDLE9BQW9DO1FBQ2hFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsU0FBUyxFQUFFLFVBQVUsRUFBRSxFQUFFO1lBQ2hELE9BQU8sbUJBQW1CLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxVQUFVLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQzVFLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLGlCQUFpQixDQUFDLElBQWU7UUFDdEMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxFQUFFO1lBQ3ZELE1BQU0sQ0FBQyxHQUFHLElBQUksS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDOUQsTUFBTSxDQUFDLEdBQUcsSUFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUMsQ0FBQztZQUM5RCxPQUFPO2dCQUNMLEdBQUcsUUFBUSxDQUFDLFVBQVUsQ0FBQztnQkFDdkIsQ0FBQztnQkFDRCxDQUFDO2dCQUNELElBQUksRUFBRSxDQUFDO2dCQUNQLEdBQUcsRUFBRSxDQUFDO2FBQ1AsQ0FBQztRQUNKLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLG1CQUFtQixDQUFDLFVBQWlDO1FBQzFELElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ3RDLENBQUM7SUFFTSxPQUFPO1FBQ1osT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO0lBQy9ELENBQUM7SUFHTSxLQUFLLENBQUMsS0FBVTtRQUNyQixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDMUIsQ0FBQzt1R0E3RlUscUJBQXFCLDRDQW9CdEIsUUFBUTsyRkFwQlAscUJBQXFCOzsyRkFBckIscUJBQXFCO2tCQUxqQyxTQUFTO21CQUFDO29CQUNULFFBQVEsRUFBRSxpQkFBaUI7b0JBQzNCLFVBQVUsRUFBRSxJQUFJO29CQUNoQixRQUFRLEVBQUUsdUJBQXVCO2lCQUNsQzs7MEJBcUJJLE1BQU07MkJBQUMsUUFBUTs0SEFuQlIsUUFBUTtzQkFBakIsTUFBTTtnQkFDRyxTQUFTO3NCQUFsQixNQUFNO2dCQUNHLE9BQU87c0JBQWhCLE1BQU07Z0JBd0ZBLEtBQUs7c0JBRFgsWUFBWTt1QkFBQyxPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBEZXN0cm95UmVmLFxuICBEaXJlY3RpdmUsXG4gIEVsZW1lbnRSZWYsXG4gIEV2ZW50RW1pdHRlcixcbiAgSG9zdExpc3RlbmVyLFxuICBJbmplY3QsXG4gIE91dHB1dCxcbiAgUmVuZGVyZXIyLFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IERPQ1VNRU5UIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IENvbnRhaW5lckNvbnN0cmFpbnQgfSBmcm9tICcuL2NvbnRhaW5lci1jb25zdHJhaW50JztcbmltcG9ydCB7IElQb2ludCB9IGZyb20gJ29yYml0YWwtdWkvY29yZSc7XG5pbXBvcnQgeyBHVUlEIH0gZnJvbSAnb3JiaXRhbC11aS9oZWxwZXJzJztcbmltcG9ydCB7XG4gIElDb250YWluZXJDb25zdHJhaW50T3B0aW9ucyxcbiAgSURyYWdNb3ZlSG9va0Z1bmN0aW9uLFxuICBJT3VpU25hcEV2ZW50LFxuICBJT3VpRHJhZ01vdmVFdmVudCxcbiAgSURlZmF1bHRCZWhhdmlvck9wdGlvbnMsXG59IGZyb20gJy4vdHlwaW5ncyc7XG5pbXBvcnQgeyBCZWhhdmlvckJhc2UsIERlZmF1bHRCZWhhdmlvciB9IGZyb20gJy4vYmVoYXZpb3ItZGVmYXVsdCc7XG5pbXBvcnQge1xuICBJSW5lcnRpYUJlaGF2aW9yT3B0aW9ucyxcbiAgSW5lcnRpYUJlaGF2aW9yLFxuICBJU25hcEJlaGF2aW9yT3B0aW9ucyxcbn0gZnJvbSAnLi9iZWhhdmlvci1pbmVydGlhJztcbmltcG9ydCB7IFNuYXBCZWhhdmlvciB9IGZyb20gJy4vYmVoYXZpb3Itc25hcCc7XG5pbXBvcnQgeyBPdWlEcmFnZ2FibGVTZXJ2aWNlIH0gZnJvbSAnLi9kcmFnZ2FibGUuc2VydmljZSc7XG5pbXBvcnQge1xuICBJUnViYmVyYmFuZEJlaGF2aW9yT3B0aW9ucyxcbiAgUnViYmVyYmFuZEJlaGF2aW9yLFxufSBmcm9tICcuL2JlaGF2aW9yLXJ1YmJlcmJhbmQnO1xuaW1wb3J0IHsgQ29weUJib3gsIEdldFRyYW5zbGF0ZVhZIH0gZnJvbSAnLi9oZWxwZXJzJztcblxuLyoqXG4gKiBBeGlzOiBEZWZpbmVzIGFuIGF4aXMgYnkgd2hpY2ggZHJhZ2dpbmcgaXMgcmVzdHJpY3RlZC4gQnkgZGVmYXVsdCBkcmFnZ2luZyB3b3JrcyBvbiBhbGwgYXhpcy5cbiAqIGNvbnN0cmFpbnQ6IEEgY3VzdG9tIGNvbnN0cmFpbnQgYnkgd2hpY2ggZHJhZ2dpbmcgaXMgcmVzdHJpY3RlZC4gVGhpcyBmdW5jdGlvbiBpcyB0cmlnZ2VyZWQgb24gZXZlcnkgZHJhZ01vdmUuIElmIHJldHVybmluZyBmYWxzZSwgZHJhZ2dpbmcgd29uJ3Qgd29yay5cbiAqIGNvbnRhaW5lcjogQW4gZWxlbWVudCBpbnNpZGUgb2Ygd2hpY2ggZHJhZ2dpbmcgaXMgcmVzdHJpY3RlZC5cbiAqIGNvbnRhaW5lckFuY2hvcjogV2hldGhlciBvciBub3QgZWxlbWVudHMgc2hvdWxkIGJlIHJlc3RyaWN0ZWQgaW5zaWRlIHRoZSBjb250YWluZXIgYnkgdGhlaXIgZWRnZSBvciBieSB0aGVpciBjZW50ZXJcbiAqIHBvc2l0aW9uSG9vazogVGhpcyBob29rIGNhbiBiZSB1c2VkIHRvIG1hbnVhbGx5IGFkanVzdCBob3cgdGhlIG9iamVjdCBpcyBkcmFnZ2VkLiBUaGUgcGFyYW1ldGVyIGlzIHdoZXJlIHRoZSBvYmplY3QgV09VTEQgb3JkaW5hcmlseSBiZSBkcmFnZ2VkLFxuICogICAgICAgICAgICAgICBhbmQgdGhlIHJldHVybi12YWx1ZSBpcyB3aGVyZSBpdCB3aWxsIGJlIGRyYWdnZWQgaW5zdGVhZC5cbiAqL1xuXG4vLyBUT0RPOiBSZW1vdmUgZGVwZW5kZW5jeSB0byB0aGlzIGNvbXBvbmVudCBmcm9tIG91aS1zbGlkZXIuIER1cGxpY2F0ZSBjb2RlIGlmIG5lZWRlZCwgYXMgbG9uZyBhcyBzaWRlLWVmZmVjdHMgZG9uJ3QgcHJvcGFnYXRlXG4vKipcbiAqIERpcmVjdGl2ZSB0aGF0IGNhbiBiZSB1c2VkIHRvIGFkZCBmdW5jdGlvbmFsaXR5IHRvIGFueSBlbGVtZW50IHRoYXQgZW5hYmxlcyB0aGVtIHRvIGJlIGRyYWdnZWQgYXJvdW5kLlxuICogTk9URTogRVhDRVJDSVNFIEdSRUFUIENBUkUgV0hFTiBBREpVU1RJTkcgVEhJUyBDT01QT05FTlQsIEFTIE9USEVSIENPTVBPTkVOVFMgTElLRSBvdWktU0xJREVSIERFUEVORCBPTiBJVFxuICpcbiAqIEBJbnB1dCgpIG91aURyYWdnYWJsZU9wdGlvbnM6IElPdWlEcmFnZ2FibGVPcHRpb25zXG4gKiAgIE9wdGlvbnMgcGFzc2VkIHRvIHRoZSBkaXJlY3RpdmVcbiAqXG4gKiBAT3V0cHV0KCkgZHJhZ01vdmU6IEV2ZW50RW1pdHRlcjxJRHJhZ01vdmU+XG4gKiAgIEV2ZW50IHRyaWdnZXJlZCB3aGVuIGRyYWdnZWQgb2JqZWN0IGlzIG1vdmVkXG4gKiBAT3V0cHV0KCkgZHJhZ1N0YXJ0OiBFdmVudEVtaXR0ZXI8TW91c2VFdmVudHxUb3VjaEV2ZW50PlxuICogICBFdmVudCB0cmlnZ2VyZWQgd2hlbiBkcmFnZ2luZyBzdGFydHNcbiAqIEBPdXRwdXQoKSBkcmFnRW5kOiBFdmVudEVtaXR0ZXI8TW91c2VFdmVudHxUb3VjaEV2ZW50PlxuICogICBFdmVudCB0cmlnZ2VyZWQgd2hlbiBkcmFnZ2luZyBlbmRzXG4gKi9cbi8vIFRPRE86IENoYW5nZSB0byB3b3JrIHNvIHRoYXQgbW92ZWQgZGlzdGFuY2UgaXMgdGFrZW4gZnJvbSBob3cgbXVjaCB0aGUgbW91c2UgaGFzIG1vdmVkIGJldHdlZW4gbGFzdCBtb3ZlIGFuZCBub3dcbi8vICBUaGlzIHdpbGwgbWFrZSBpdCBzbyB0aGF0IGl0J3MgcG9zc2libGUgdG8gaG9vayBpbnRvIHRoYXQgZGlmZmVyZW5jZSwgbWFraW5nIGl0IHBvc3NpYmxlIHRvIGFkanVzdCB0aGUgcmF0ZSBvZiBkcmFnZ2luZyBldGMuIE5vdyB0aGlzIHdvdWxkIGJlIGJhc2ljYWxseSBpbXBvc3NpYmxlXG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ1tvdWktZHJhZ2dhYmxlXScsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGV4cG9ydEFzOiAnT3VpRHJhZ2dhYmxlRGlyZWN0aXZlJyxcbn0pXG5leHBvcnQgY2xhc3MgT3VpRHJhZ2dhYmxlRGlyZWN0aXZlIGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCB7XG4gIEBPdXRwdXQoKSBkcmFnTW92ZSA9IG5ldyBFdmVudEVtaXR0ZXI8SU91aVNuYXBFdmVudCB8IElPdWlEcmFnTW92ZUV2ZW50PigpO1xuICBAT3V0cHV0KCkgZHJhZ1N0YXJ0ID0gbmV3IEV2ZW50RW1pdHRlcjxNb3VzZUV2ZW50IHwgVG91Y2hFdmVudD4oKTtcbiAgQE91dHB1dCgpIGRyYWdFbmQgPSBuZXcgRXZlbnRFbWl0dGVyPE1vdXNlRXZlbnQgfCBUb3VjaEV2ZW50IHwgdW5kZWZpbmVkPigpO1xuXG4gIHByaXZhdGUgZWxlbWVudDogSFRNTEVsZW1lbnQ7XG4gIHB1YmxpYyBiZWhhdmlvcjpcbiAgICB8IEJlaGF2aW9yQmFzZVxuICAgIHwgU25hcEJlaGF2aW9yXG4gICAgfCBJbmVydGlhQmVoYXZpb3JcbiAgICB8IFJ1YmJlcmJhbmRCZWhhdmlvclxuICAgIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuICBwdWJsaWMgY3VycmVudFRyYW5zZm9ybTogSVBvaW50ID0ge1xuICAgIHg6IDAsXG4gICAgeTogMCxcbiAgfTtcbiAgcHVibGljIGlkID0gR1VJRCgpO1xuICBwdWJsaWMgZHJhZ01vdmVIb29rczogSURyYWdNb3ZlSG9va0Z1bmN0aW9uW10gPSBbXTtcbiAgY29uc3RydWN0b3IoXG4gICAgcHVibGljIGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsXG4gICAgQEluamVjdChET0NVTUVOVCkgcHVibGljIGRvY3VtZW50OiBEb2N1bWVudCxcbiAgICBwdWJsaWMgZGVzdHJveVJlZjogRGVzdHJveVJlZixcbiAgICBwdWJsaWMgcmVuZGVyZXI6IFJlbmRlcmVyMixcbiAgICBwdWJsaWMgb3VpRHJhZ2dhYmxlU2VydmljZTogT3VpRHJhZ2dhYmxlU2VydmljZVxuICApIHt9XG4gIHB1YmxpYyBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgY29uc3QgY3VycmVudFBvc2l0aW9uID0gdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuc3R5bGUucG9zaXRpb247XG4gICAgdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuc3R5bGUucG9zaXRpb24gPVxuICAgICAgY3VycmVudFBvc2l0aW9uID09PSAnZml4ZWQnID8gJ2ZpeGVkJyA6ICdhYnNvbHV0ZSc7XG4gICAgY29uc3QgY3VycmVudFRyYW5zbGF0ZSA9IEdldFRyYW5zbGF0ZVhZKHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50KTtcbiAgICB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5zdHlsZS50cmFuc2Zvcm0gPSBgdHJhbnNsYXRlWCgke2N1cnJlbnRUcmFuc2xhdGUueH1weCkgdHJhbnNsYXRlWSgke2N1cnJlbnRUcmFuc2xhdGUueX1weClgO1xuICAgIHRoaXMuY3VycmVudFRyYW5zZm9ybSA9IGN1cnJlbnRUcmFuc2xhdGU7XG4gICAgdGhpcy5lbGVtZW50ID0gdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQ7XG4gICAgdGhpcy5lbGVtZW50LnN0eWxlLnRvdWNoQWN0aW9uID0gJ25vbmUnO1xuICB9XG5cbiAgcHVibGljIHVwZGF0ZVRyYW5zZm9ybSh2YWx1ZTogSVBvaW50KSB7XG4gICAgaWYgKHRoaXMuYmVoYXZpb3IpIHtcbiAgICAgIHRoaXMuYmVoYXZpb3IudXBkYXRlVHJhbnNmb3JtKHZhbHVlKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgYWRkSW5lcnRpYUJlaGF2aW9yKG9wdGlvbnM6IElJbmVydGlhQmVoYXZpb3JPcHRpb25zKSB7XG4gICAgdGhpcy5iZWhhdmlvciA9IG5ldyBJbmVydGlhQmVoYXZpb3IodGhpcywgb3B0aW9ucyk7XG4gICAgcmV0dXJuIHRoaXMuYmVoYXZpb3I7XG4gIH1cblxuICBwdWJsaWMgYWRkUnViYmVyYmFuZEJlaGF2aW9yKG9wdGlvbnM6IElSdWJiZXJiYW5kQmVoYXZpb3JPcHRpb25zKSB7XG4gICAgdGhpcy5iZWhhdmlvciA9IG5ldyBSdWJiZXJiYW5kQmVoYXZpb3IodGhpcywgb3B0aW9ucyk7XG4gICAgcmV0dXJuIHRoaXMuYmVoYXZpb3I7XG4gIH1cblxuICBwdWJsaWMgYWRkRGVmYXVsdEJlaGF2aW9yKG9wdGlvbnM/OiBJRGVmYXVsdEJlaGF2aW9yT3B0aW9ucykge1xuICAgIHRoaXMuYmVoYXZpb3IgPSBuZXcgRGVmYXVsdEJlaGF2aW9yKHRoaXMsIG9wdGlvbnMpO1xuICAgIHJldHVybiB0aGlzLmJlaGF2aW9yO1xuICB9XG5cbiAgcHVibGljIGFkZFNuYXBCZWhhdmlvcihvcHRpb25zOiBJU25hcEJlaGF2aW9yT3B0aW9ucyk6IFNuYXBCZWhhdmlvciB7XG4gICAgdGhpcy5iZWhhdmlvciA9IG5ldyBTbmFwQmVoYXZpb3IodGhpcywgb3B0aW9ucywgdGhpcy5vdWlEcmFnZ2FibGVTZXJ2aWNlKTtcbiAgICByZXR1cm4gdGhpcy5iZWhhdmlvciBhcyBTbmFwQmVoYXZpb3I7XG4gIH1cblxuICBwdWJsaWMgYWRkQ29udGFpbmVyQ29uc3RyYWludChvcHRpb25zOiBJQ29udGFpbmVyQ29uc3RyYWludE9wdGlvbnMpIHtcbiAgICB0aGlzLmRyYWdNb3ZlSG9va3MucHVzaCgoZHJhZ2dhYmxlLCB0YXJnZXRSZWN0KSA9PiB7XG4gICAgICByZXR1cm4gQ29udGFpbmVyQ29uc3RyYWludChvcHRpb25zLmNvbnRhaW5lciwgdGFyZ2V0UmVjdCwgb3B0aW9ucy5hbmNob3IpO1xuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIGFkZEF4aXNDb25zdHJhaW50KGF4aXM6ICd4JyB8ICd5Jykge1xuICAgIHRoaXMuZHJhZ01vdmVIb29rcy5wdXNoKChkcmFnZ2FibGUsIHRhcmdldFJlY3QsIGV2ZW50KSA9PiB7XG4gICAgICBjb25zdCB4ID0gYXhpcyA9PT0gJ3gnID8gdGFyZ2V0UmVjdC54IDogZHJhZ2dhYmxlLmdldEJib3goKS54O1xuICAgICAgY29uc3QgeSA9IGF4aXMgPT09ICd5JyA/IHRhcmdldFJlY3QueSA6IGRyYWdnYWJsZS5nZXRCYm94KCkueTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIC4uLkNvcHlCYm94KHRhcmdldFJlY3QpLFxuICAgICAgICB4LFxuICAgICAgICB5LFxuICAgICAgICBsZWZ0OiB4LFxuICAgICAgICB0b3A6IHksXG4gICAgICB9O1xuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIGFkZEN1c3RvbUNvbnN0cmFpbnQoY29uc3RyYWludDogSURyYWdNb3ZlSG9va0Z1bmN0aW9uKSB7XG4gICAgdGhpcy5kcmFnTW92ZUhvb2tzLnB1c2goY29uc3RyYWludCk7XG4gIH1cblxuICBwdWJsaWMgZ2V0QmJveCgpIHtcbiAgICByZXR1cm4gdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gIH1cblxuICBASG9zdExpc3RlbmVyKCdjbGljaycsIFsnJGV2ZW50J10pXG4gIHB1YmxpYyBjbGljayhldmVudDogYW55KTogdm9pZCB7XG4gICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gIH1cbn1cbiJdfQ==