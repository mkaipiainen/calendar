import { AfterViewInit } from '@angular/core';
import { ComponentType } from '@angular/cdk/overlay';
import { IPopupOptions } from 'orbital-ui/popup';
import * as i0 from "@angular/core";
export type OuiTooltipOptions = {
    mode?: 'hover' | 'click' | 'manual';
    popupOptions?: IPopupOptions;
    isDisabled?: boolean;
};
export declare class OuiTooltipDirective implements AfterViewInit {
    private elementRef;
    private renderer;
    private popupService;
    private destroyRef;
    component: ComponentType<any>;
    inputs: {
        [x: string]: any;
    };
    isTooltipDisabled: import("@angular/core").InputSignal<boolean>;
    tooltip: import("@angular/core").InputSignal<string>;
    tooltipOptions: import("@angular/core").InputSignal<OuiTooltipOptions | undefined>;
    combinedOptions: import("@angular/core").Signal<{
        mode: string;
        popupOptions: {
            placement: string;
            modifiers: ({
                name: string;
                options: {
                    color: string;
                    padding: number;
                    offset?: undefined;
                };
            } | {
                name: string;
                options: {
                    offset: number[];
                    color?: undefined;
                    padding?: undefined;
                };
            })[];
        };
    } & {
        mode?: "hover" | "click" | "manual" | undefined;
        popupOptions?: IPopupOptions | undefined;
        isDisabled?: boolean | undefined;
    }>;
    private popup;
    private isHoveringOnPopup;
    private isHoveringOnOrigin;
    private handleDebouncedMouseLeave;
    constructor();
    ngAfterViewInit(): void;
    createTooltip(): void;
    handleMouseLeave(): void;
    destroyTooltip(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiTooltipDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OuiTooltipDirective, "[ouiTooltip]", never, { "component": { "alias": "component"; "required": false; }; "inputs": { "alias": "inputs"; "required": false; }; "isTooltipDisabled": { "alias": "isTooltipDisabled"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "tooltipOptions": { "alias": "tooltipOptions"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=tooltip.directive.d.ts.map