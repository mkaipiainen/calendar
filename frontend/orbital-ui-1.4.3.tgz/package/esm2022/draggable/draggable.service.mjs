import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import * as i0 from "@angular/core";
export class OuiDraggableService {
    snappables = {};
    snappablesSubject = new BehaviorSubject({});
    snappables$ = this.snappablesSubject.asObservable();
    constructor() { }
    addSnappable(elementRef, id) {
        if (this.snappables[id]) {
            this.snappables[id].add(elementRef);
        }
        else {
            this.snappables[id] = new Set([elementRef]);
        }
        this.snappablesSubject.next(this.snappables);
    }
    removeSnappable(elementRef, id) {
        if (this.snappables[id]) {
            this.snappables[id].delete(elementRef);
        }
        if (this.snappables[id].size === 0) {
            delete this.snappables[id];
        }
        this.snappablesSubject.next(this.snappables);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDraggableService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDraggableService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDraggableService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHJhZ2dhYmxlLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL2RyYWdnYWJsZS9kcmFnZ2FibGUuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQWMsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQ3ZELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxNQUFNLENBQUM7O0FBS3ZDLE1BQU0sT0FBTyxtQkFBbUI7SUFDdEIsVUFBVSxHQUVkLEVBQUUsQ0FBQztJQUNDLGlCQUFpQixHQUFHLElBQUksZUFBZSxDQUU1QyxFQUFFLENBQUMsQ0FBQztJQUVBLFdBQVcsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxFQUFFLENBQUM7SUFFM0QsZ0JBQWUsQ0FBQztJQUVULFlBQVksQ0FBQyxVQUFzQixFQUFFLEVBQVU7UUFDcEQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDdEMsQ0FBQzthQUFNLENBQUM7WUFDTixJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQztRQUM5QyxDQUFDO1FBQ0QsSUFBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVNLGVBQWUsQ0FBQyxVQUFzQixFQUFFLEVBQVU7UUFDdkQsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDekMsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDbkMsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQzdCLENBQUM7UUFDRCxJQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUMvQyxDQUFDO3VHQTdCVSxtQkFBbUI7MkdBQW5CLG1CQUFtQixjQUZsQixNQUFNOzsyRkFFUCxtQkFBbUI7a0JBSC9CLFVBQVU7bUJBQUM7b0JBQ1YsVUFBVSxFQUFFLE1BQU07aUJBQ25CIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRWxlbWVudFJlZiwgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQmVoYXZpb3JTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5cbkBJbmplY3RhYmxlKHtcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlEcmFnZ2FibGVTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBzbmFwcGFibGVzOiB7XG4gICAgW2dyb3VwSWQ6IHN0cmluZ106IFNldDxFbGVtZW50UmVmPjtcbiAgfSA9IHt9O1xuICBwcml2YXRlIHNuYXBwYWJsZXNTdWJqZWN0ID0gbmV3IEJlaGF2aW9yU3ViamVjdDx7XG4gICAgW2dyb3VwSWQ6IHN0cmluZ106IFNldDxFbGVtZW50UmVmPjtcbiAgfT4oe30pO1xuXG4gIHB1YmxpYyBzbmFwcGFibGVzJCA9IHRoaXMuc25hcHBhYmxlc1N1YmplY3QuYXNPYnNlcnZhYmxlKCk7XG5cbiAgY29uc3RydWN0b3IoKSB7fVxuXG4gIHB1YmxpYyBhZGRTbmFwcGFibGUoZWxlbWVudFJlZjogRWxlbWVudFJlZiwgaWQ6IHN0cmluZykge1xuICAgIGlmICh0aGlzLnNuYXBwYWJsZXNbaWRdKSB7XG4gICAgICB0aGlzLnNuYXBwYWJsZXNbaWRdLmFkZChlbGVtZW50UmVmKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5zbmFwcGFibGVzW2lkXSA9IG5ldyBTZXQoW2VsZW1lbnRSZWZdKTtcbiAgICB9XG4gICAgdGhpcy5zbmFwcGFibGVzU3ViamVjdC5uZXh0KHRoaXMuc25hcHBhYmxlcyk7XG4gIH1cblxuICBwdWJsaWMgcmVtb3ZlU25hcHBhYmxlKGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsIGlkOiBzdHJpbmcpIHtcbiAgICBpZiAodGhpcy5zbmFwcGFibGVzW2lkXSkge1xuICAgICAgdGhpcy5zbmFwcGFibGVzW2lkXS5kZWxldGUoZWxlbWVudFJlZik7XG4gICAgfVxuICAgIGlmICh0aGlzLnNuYXBwYWJsZXNbaWRdLnNpemUgPT09IDApIHtcbiAgICAgIGRlbGV0ZSB0aGlzLnNuYXBwYWJsZXNbaWRdO1xuICAgIH1cbiAgICB0aGlzLnNuYXBwYWJsZXNTdWJqZWN0Lm5leHQodGhpcy5zbmFwcGFibGVzKTtcbiAgfVxufVxuIl19