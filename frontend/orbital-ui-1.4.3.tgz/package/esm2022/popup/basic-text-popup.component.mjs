import { Component, Input, } from '@angular/core';
import { OuiPopupComponent } from './popup.component';
import { fromEvent, ReplaySubject, takeUntil } from 'rxjs';
import * as i0 from "@angular/core";
export class BasicTextPopupComponent extends OuiPopupComponent {
    elementRef;
    content;
    destroyed$ = new ReplaySubject(1);
    constructor(elementRef) {
        super();
        this.elementRef = elementRef;
    }
    ngAfterViewInit() {
        fromEvent(this.elementRef.nativeElement, 'click')
            .pipe(takeUntil(this.destroyed$))
            .subscribe(() => {
            this.ouiPopupService.destroyPopups();
        });
    }
    ngOnDestroy() {
        this.destroyed$.next(true);
        this.destroyed$.complete();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: BasicTextPopupComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: BasicTextPopupComponent, isStandalone: true, selector: "example-popup", inputs: { content: "content" }, usesInheritance: true, ngImport: i0, template: '<div class="basic-text-popup flex p-4" [innerHTML]="this.content"></div>', isInline: true, styles: [":host{background-color:var(--color-primary);color:var(--color-primary-text)}:host .basic-text-popup{display:flex;justify-content:center;align-items:center}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: BasicTextPopupComponent, decorators: [{
            type: Component,
            args: [{ selector: 'example-popup', template: '<div class="basic-text-popup flex p-4" [innerHTML]="this.content"></div>', standalone: true, imports: [], styles: [":host{background-color:var(--color-primary);color:var(--color-primary-text)}:host .basic-text-popup{display:flex;justify-content:center;align-items:center}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { content: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzaWMtdGV4dC1wb3B1cC5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3BvcHVwL2Jhc2ljLXRleHQtcG9wdXAuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFFTCxTQUFTLEVBRVQsS0FBSyxHQUVOLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLG1CQUFtQixDQUFDO0FBRXRELE9BQU8sRUFBRSxTQUFTLEVBQUUsYUFBYSxFQUFFLFNBQVMsRUFBRSxNQUFNLE1BQU0sQ0FBQzs7QUFVM0QsTUFBTSxPQUFPLHVCQUNYLFNBQVEsaUJBQWlCO0lBTUw7SUFIWCxPQUFPLENBQVM7SUFDakIsVUFBVSxHQUFHLElBQUksYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBRTFDLFlBQW9CLFVBQXNCO1FBQ3hDLEtBQUssRUFBRSxDQUFDO1FBRFUsZUFBVSxHQUFWLFVBQVUsQ0FBWTtJQUUxQyxDQUFDO0lBRU0sZUFBZTtRQUNwQixTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsT0FBTyxDQUFDO2FBQzlDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ2hDLFNBQVMsQ0FBQyxHQUFHLEVBQUU7WUFDZCxJQUFJLENBQUMsZUFBZSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3ZDLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUVNLFdBQVc7UUFDaEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQztJQUM3QixDQUFDO3VHQXRCVSx1QkFBdUI7MkZBQXZCLHVCQUF1QixnSUFMaEMsMEVBQTBFOzsyRkFLakUsdUJBQXVCO2tCQVJuQyxTQUFTOytCQUNFLGVBQWUsWUFFdkIsMEVBQTBFLGNBRWhFLElBQUksV0FDUCxFQUFFOytFQU1GLE9BQU87c0JBQWYsS0FBSyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFmdGVyVmlld0luaXQsXG4gIENvbXBvbmVudCxcbiAgRWxlbWVudFJlZixcbiAgSW5wdXQsXG4gIE9uRGVzdHJveSxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBPdWlQb3B1cENvbXBvbmVudCB9IGZyb20gJy4vcG9wdXAuY29tcG9uZW50JztcbmltcG9ydCB7IE91aVBvcHVwU2VydmljZSB9IGZyb20gJy4vcG9wdXAuc2VydmljZSc7XG5pbXBvcnQgeyBmcm9tRXZlbnQsIFJlcGxheVN1YmplY3QsIHRha2VVbnRpbCB9IGZyb20gJ3J4anMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdleGFtcGxlLXBvcHVwJyxcbiAgdGVtcGxhdGU6XG4gICAgJzxkaXYgY2xhc3M9XCJiYXNpYy10ZXh0LXBvcHVwIGZsZXggcC00XCIgW2lubmVySFRNTF09XCJ0aGlzLmNvbnRlbnRcIj48L2Rpdj4nLFxuICBzdHlsZVVybHM6IFsnLi9iYXNpYy10ZXh0LXBvcHVwLmNvbXBvbmVudC5zY3NzJ10sXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtdLFxufSlcbmV4cG9ydCBjbGFzcyBCYXNpY1RleHRQb3B1cENvbXBvbmVudFxuICBleHRlbmRzIE91aVBvcHVwQ29tcG9uZW50XG4gIGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95XG57XG4gIEBJbnB1dCgpIGNvbnRlbnQ6IHN0cmluZztcbiAgcHJpdmF0ZSBkZXN0cm95ZWQkID0gbmV3IFJlcGxheVN1YmplY3QoMSk7XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBlbGVtZW50UmVmOiBFbGVtZW50UmVmKSB7XG4gICAgc3VwZXIoKTtcbiAgfVxuXG4gIHB1YmxpYyBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgZnJvbUV2ZW50KHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LCAnY2xpY2snKVxuICAgICAgLnBpcGUodGFrZVVudGlsKHRoaXMuZGVzdHJveWVkJCkpXG4gICAgICAuc3Vic2NyaWJlKCgpID0+IHtcbiAgICAgICAgdGhpcy5vdWlQb3B1cFNlcnZpY2UuZGVzdHJveVBvcHVwcygpO1xuICAgICAgfSk7XG4gIH1cblxuICBwdWJsaWMgbmdPbkRlc3Ryb3koKSB7XG4gICAgdGhpcy5kZXN0cm95ZWQkLm5leHQodHJ1ZSk7XG4gICAgdGhpcy5kZXN0cm95ZWQkLmNvbXBsZXRlKCk7XG4gIH1cbn1cbiJdfQ==