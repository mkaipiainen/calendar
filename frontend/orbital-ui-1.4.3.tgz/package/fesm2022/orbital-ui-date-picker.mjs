import * as i0 from '@angular/core';
import { Pipe, model, TemplateRef, Component, ChangeDetectionStrategy, ViewChild, Input, EventEmitter, Output } from '@angular/core';
import { OuiDropdownComponent } from 'orbital-ui/dropdown';
import * as i1 from '@angular/common';
import { CommonModule, NgTemplateOutlet } from '@angular/common';
import { format, getMonth, addYears, addMonths, subYears, subMonths, startOfWeek, endOfWeek, eachDayOfInterval, addDays, startOfYear, endOfYear, eachMonthOfInterval, eachYearOfInterval, isSameMonth, isSameDay, isSameYear, startOfMonth, isAfter, isBefore, getYear } from 'date-fns';
import { OuiHoverDirective } from 'orbital-ui/hover';
import { OuiIconComponent } from 'orbital-ui/icon';
import { OuiRadioComponent } from 'orbital-ui/radio';
import { OuiInputComponent } from 'orbital-ui/input';
import { OuiRippleDirective } from 'orbital-ui/ripple';
import { OuiSwitchComponent } from 'orbital-ui/switch';
import { OuiIconButtonComponent } from 'orbital-ui/icon-button';

class ParentDateLabelPipe {
    transform(value, mode, translations) {
        if (!value) {
            return '';
        }
        if (mode === 'month') {
            return format(value, 'yyyy');
        }
        else if (mode === 'day') {
            const month = getMonth(value);
            return translations.months[month] + ' ' + format(value, 'yyyy');
        }
        else {
            return format(value, 'yyyy');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: ParentDateLabelPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: ParentDateLabelPipe, isStandalone: true, name: "parentDateLabel" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: ParentDateLabelPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'parentDateLabel',
                    standalone: true,
                }]
        }] });

function goForward(date, mode) {
    if (mode === 'month') {
        return addYears(date, 1);
    }
    else if (mode === 'day') {
        return addMonths(date, 1);
    }
    else {
        return addYears(date, 10);
    }
}
const DEFAULT_TRANSLATIONS = {
    months: [
        'January',
        'February',
        'March',
        'April',
        'May',
        'June',
        'July',
        'August',
        'September',
        'October',
        'November',
        'December',
    ],
    days: ['M', 'Tu', 'W', 'Th', 'F', 'Sa', 'Su'],
};
function goBackwards(date, mode) {
    if (mode === 'month') {
        return subYears(date, 1);
    }
    else if (mode === 'day') {
        return subMonths(date, 1);
    }
    else {
        return subYears(date, 10);
    }
}
function generateWeeks(startDate) {
    let start = startOfWeek(startDate, {
        weekStartsOn: 1,
    });
    let end = endOfWeek(startDate, {
        weekStartsOn: 1,
    });
    const weeks = [];
    for (let i = 0; i < 5; i++) {
        weeks.push(eachDayOfInterval({ start, end }));
        start = addDays(start, 7);
        end = addDays(end, 7);
    }
    return weeks;
}
function generateMonths(currentDate) {
    const start = startOfYear(currentDate);
    const end = endOfYear(currentDate);
    const monthsSplitIntoGroupsOf3 = [];
    const months = eachMonthOfInterval({ start, end });
    for (let i = 0; i < months.length; i++) {
        if (i % 3 === 0) {
            monthsSplitIntoGroupsOf3.push([]);
        }
        monthsSplitIntoGroupsOf3[monthsSplitIntoGroupsOf3.length - 1].push(months[i]);
    }
    return monthsSplitIntoGroupsOf3;
}
function generateYears(currentDate) {
    const start = subYears(currentDate, 5);
    const end = addYears(currentDate, 5);
    const years = eachYearOfInterval({ start, end });
    const yearsSplitIntoGroupsOf3 = [];
    for (let i = 0; i < years.length; i++) {
        if (i % 3 === 0) {
            yearsSplitIntoGroupsOf3.push([]);
        }
        yearsSplitIntoGroupsOf3[yearsSplitIntoGroupsOf3.length - 1].push(years[i]);
    }
    return yearsSplitIntoGroupsOf3;
}

class MonthShortLabelPipe {
    transform(value, translations) {
        if (!value) {
            return '';
        }
        const month = getMonth(value);
        return translations.months[month].substring(0, 3);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: MonthShortLabelPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: MonthShortLabelPipe, isStandalone: true, name: "monthShortLabel" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: MonthShortLabelPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'monthShortLabel',
                    standalone: true,
                }]
        }] });

/**
 * Component for a calendar date-picker.
 *
 */
class OuiDatePickerComponent {
    cdr;
    dayTemplate;
    monthTemplate;
    yearTemplate;
    /**
     *   The selected date in the datepicker
     */
    date = model.required();
    /**
     *   The options to pass to the calendar. getDateClass let's you assign custom classes to specific dates. The only input parameter
     *   to the function is a date, and the return value is the entire classname to be added to the date.
     *   getHoverClass works the same, except adds classes to specific dates when hovering over them.
     */
    options = {};
    dateSelectionOptions = [];
    mode = 'day';
    selectedCalendarDate = new Date();
    currentTemplate;
    defaultOptions = {
        translations: DEFAULT_TRANSLATIONS,
        isDateUnsetEnabled: false,
        getDateClass: (date) => {
            const selectedDate = this.date();
            const isInSameMonth = selectedDate
                ? isSameMonth(date, selectedDate)
                : true;
            const isSelectedDate = selectedDate
                ? isSameDay(date, selectedDate)
                : false;
            const isInSameYear = selectedDate ? isSameYear(date, selectedDate) : true;
            const classes = [];
            if (this.mode === 'day') {
                if (isSelectedDate) {
                    classes.push('start-date');
                }
                if (!isInSameMonth) {
                    classes.push('muted');
                }
            }
            else if (this.mode === 'month') {
                if (!isInSameMonth) {
                    classes.push('muted');
                }
            }
            else if (this.mode === 'year') {
                if (!isInSameYear) {
                    classes.push('muted');
                }
            }
            return classes.join(' ');
        },
        getHoverClass: () => {
            return 'hover';
        },
    };
    combinedOptions;
    constructor(cdr) {
        this.cdr = cdr;
    }
    ngAfterViewInit() {
        this.combineOptions();
        this.currentTemplate = this.dayTemplate;
        this.selectedCalendarDate = this.date() ?? new Date();
        this.generateDateSelection();
        this.cdr.detectChanges();
    }
    select() {
        this.selectedCalendarDate = this.date() ?? new Date();
        this.generateDateSelection();
    }
    changeModeSelection() {
        if (this.mode === 'day') {
            this.mode = 'month';
            this.currentTemplate = this.monthTemplate;
        }
        else if (this.mode === 'month') {
            this.mode = 'year';
            this.currentTemplate = this.yearTemplate;
        }
        else {
            return;
        }
        this.generateDateSelection();
    }
    generateDateSelection() {
        let dates = [];
        if (this.mode === 'year') {
            dates = generateYears(this.selectedCalendarDate);
        }
        else if (this.mode === 'month') {
            dates = generateMonths(this.selectedCalendarDate);
        }
        else {
            dates = generateWeeks(startOfMonth(this.selectedCalendarDate));
        }
        this.dateSelectionOptions = dates;
    }
    selectDay(date) {
        const selectedDate = this.date();
        if (selectedDate && isSameDay(date, selectedDate)) {
            if (this.combinedOptions.isDateUnsetEnabled) {
                this.date.set(undefined);
            }
        }
        else {
            this.date.set(date);
        }
    }
    selectMonth(date) {
        this.selectedCalendarDate = date;
        this.mode = 'day';
        this.currentTemplate = this.dayTemplate;
        this.generateDateSelection();
    }
    selectYear(date) {
        this.selectedCalendarDate = date;
        this.mode = 'month';
        this.currentTemplate = this.monthTemplate;
        this.generateDateSelection();
    }
    goBackParent() {
        this.selectedCalendarDate = goBackwards(this.selectedCalendarDate, this.mode);
        this.generateDateSelection();
    }
    goForwardParent() {
        this.selectedCalendarDate = goForward(this.selectedCalendarDate, this.mode);
        this.generateDateSelection();
    }
    getDateClass(date) {
        if (this.combinedOptions.getDateClass) {
            return this.combinedOptions.getDateClass(date, this.mode);
        }
        else {
            return '';
        }
    }
    onDateHover(date, element) {
        const classes = this.combinedOptions.getHoverClass
            ? this.combinedOptions.getHoverClass(date, this.mode)
            : '';
        if (classes) {
            element.classList.add(classes ?? '');
        }
    }
    onDateUnhover(date, element) {
        const classes = this.combinedOptions.getHoverClass
            ? this.combinedOptions.getHoverClass(date, this.mode)
            : '';
        if (classes) {
            element.classList.remove(classes ?? '');
        }
    }
    combineOptions() {
        this.combinedOptions = {
            translations: this.options.translations ?? this.defaultOptions.translations,
            getDateClass: (date) => {
                let classes = this.defaultOptions.getDateClass(date, this.mode);
                if (this.options.getDateClass) {
                    classes += ' ' + this.options.getDateClass(date, this.mode);
                }
                return classes;
            },
            getHoverClass: (date) => {
                let classes = this.defaultOptions.getHoverClass(date, this.mode);
                if (this.options.getHoverClass) {
                    classes += ' ' + this.options.getHoverClass(date, this.mode);
                }
                return classes;
            },
            isDateUnsetEnabled: this.options.isDateUnsetEnabled ??
                this.defaultOptions.isDateUnsetEnabled,
        };
        this.cdr.detectChanges();
    }
    ngOnChanges(changes) {
        if ('options' in changes) {
            this.options = changes['options'].currentValue;
            this.combineOptions();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDatePickerComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiDatePickerComponent, isStandalone: true, selector: "oui-date-picker", inputs: { date: { classPropertyName: "date", publicName: "date", isSignal: true, isRequired: true, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: false, isRequired: false, transformFunction: null } }, outputs: { date: "dateChange" }, viewQueries: [{ propertyName: "dayTemplate", first: true, predicate: ["dayTemplate"], descendants: true, read: TemplateRef }, { propertyName: "monthTemplate", first: true, predicate: ["monthTemplate"], descendants: true, read: TemplateRef }, { propertyName: "yearTemplate", first: true, predicate: ["yearTemplate"], descendants: true, read: TemplateRef }], usesOnChanges: true, ngImport: i0, template: "@if (combinedOptions) {\n  <div class=\"oui-date-picker\">\n    <div class=\"calendar-container\">\n      <div class=\"calendar\">\n        <div class=\"mode-selector\">\n          <div class=\"mode-selector-caret left\" (click)=\"goBackParent()\">\n            <oui-icon\n            [options]=\"{\n              size: '28px',\n              fillColor: 'oui-date-picker-icons-color',\n              strokeColor: 'oui-date-picker-icons-color',\n              viewBox: '0 0 48 48'\n            }\"\n              [icon]=\"'assets/icons/caret-left.svg'\"\n            ></oui-icon>\n          </div>\n          <div class=\"mode-selector-current\" (click)=\"changeModeSelection()\">\n            {{ selectedCalendarDate | parentDateLabel: mode: combinedOptions.translations }}\n          </div>\n          <div class=\"mode-selector-caret right\" (click)=\"goForwardParent()\">\n            <oui-icon\n            [options]=\"{\n              size: '28px',\n              fillColor: 'oui-date-picker-icons-color',\n              strokeColor: 'oui-date-picker-icons-color',\n              viewBox: '0 0 48 48'\n            }\"\n              [icon]=\"'assets/icons/caret-right.svg'\"\n            ></oui-icon>\n          </div>\n        </div>\n        <ng-container [ngTemplateOutlet]=\"currentTemplate\"> </ng-container>\n      </div>\n    </div>\n  </div>\n}\n\n<ng-template #dayTemplate>\n  <table class=\"calendar-table\">\n    <thead>\n      <tr>\n        @for (day of combinedOptions.translations.days; track day) {\n          <th>\n            <span class=\"header-inner-container\">\n              {{ day }}\n            </span>\n          </th>\n        }\n      </tr>\n    </thead>\n    <tbody>\n      @for (week of dateSelectionOptions; track week) {\n        <tr>\n          @for (day of week; track day) {\n            <td\n              ouiHover\n              (click)=\"selectDay(day)\"\n              [ngClass]=\"getDateClass(day)\"\n              (hovered)=\"onDateHover(day, singleDate)\"\n              (unhovered)=\"onDateUnhover(day, singleDate)\"\n              #singleDate\n              >\n              <div class=\"inner-option-container\">\n                <div class=\"innermost-option-container\">\n                  {{ day | date: 'dd' }}\n                </div>\n              </div>\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n</ng-template>\n\n<ng-template #monthTemplate>\n  <table class=\"calendar-table\">\n    <tbody>\n      @for (row of dateSelectionOptions; track row) {\n        <tr>\n          @for (month of row; track month) {\n            <td\n              ouiHover\n              (click)=\"selectMonth(month)\"\n              [ngClass]=\"getDateClass(month)\"\n              (hovered)=\"onDateHover(month, singleDate)\"\n              (unhovered)=\"onDateUnhover(month, singleDate)\"\n              #singleDate\n              >\n              <div class=\"inner-option-container\">\n                <div class=\"innermost-option-container\">\n                  {{ month | monthShortLabel: combinedOptions.translations }}\n                </div>\n              </div>\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n</ng-template>\n\n<ng-template #yearTemplate>\n  <table class=\"calendar-table\">\n    <tbody>\n      @for (row of dateSelectionOptions; track row) {\n        <tr>\n          @for (year of row; track year) {\n            <td\n              ouiHover\n              (click)=\"selectYear(year)\"\n              [ngClass]=\"getDateClass(year)\"\n              (hovered)=\"onDateHover(year, singleDate)\"\n              (unhovered)=\"onDateUnhover(year, singleDate)\"\n              #singleDate\n              >\n              <div class=\"inner-option-container\">\n                <div class=\"innermost-option-container\">\n                  {{ year | date: 'yyyy' }}\n                </div>\n              </div>\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n</ng-template>\n", styles: [":host{width:100%;height:100%;position:relative;min-width:35rem;display:flex}:host .oui-date-picker{display:flex;flex-direction:column;padding:var(--oui-date-picker-padding);background-color:var(--oui-date-picker-background);flex:1;color:var(--oui-date-picker-primary-text)}:host .oui-date-picker .label-container{display:flex;flex-direction:row;align-items:center}:host .oui-date-picker .label-container .quick-date-container{display:flex;align-items:center;justify-content:space-between;font-size:var(--font-size-body-small)}:host .oui-date-picker .label-container .quick-date-container .quick-date-label{align-self:flex-end}:host .oui-date-picker .label-container .label{flex:0 1 48%;color:var(--oui-date-picker-primary-text)}:host .oui-date-picker .label-container .label .label-title{display:flex;align-items:center;margin-bottom:8px}:host .oui-date-picker .label-container .label .quick-date-container{border-radius:var(--border-radius-default) var(--border-radius-default) 0 0;border:1px solid transparent;position:relative;padding:8px}:host .oui-date-picker .label-container .label .quick-date-container:after{content:\"\";position:absolute;bottom:-7px;height:7px;left:-1px;width:100%;background-color:var(--color-background-tertiary);border:1px solid var(--color-background-tertiary)}:host .oui-date-picker .label-container .label .quick-date-container:hover{cursor:pointer;background-color:var(--color-background-tertiary-hover)}:host .oui-date-picker .label-container .fill{flex:1}:host .oui-date-picker .calendar-container{display:flex;flex-direction:column;flex:1;border-radius:var(--border-radius-default);background-color:var(--oui-date-picker-calendar-background)}:host .oui-date-picker .calendar-container .calendar{flex:1;display:flex;flex-direction:column;padding:2px}:host .oui-date-picker .calendar-container .calendar .mode-selector{display:flex;justify-content:center;align-items:center;margin:1rem 0}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-current{display:flex;align-items:center;justify-content:center;flex:1;-webkit-user-select:none;user-select:none}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-current:hover{cursor:pointer}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-caret{flex:0;display:flex;align-items:center;justify-content:center;-webkit-user-select:none;user-select:none;border-radius:50%;transition:background-color .3s,border .3s;border:1px solid transparent}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-caret:hover{border:1px solid var(--oui-date-picker-icons-border-color);background-color:var(--oui-date-picker-icons-hover-color);cursor:pointer}:host .oui-date-picker .calendar-container .calendar .day-label-row{display:flex;align-items:center}:host .oui-date-picker .calendar-container .calendar .day-label-row .date-picker-day-label{display:flex;align-items:center;justify-content:center;flex:1;color:var(--color-quaternary-text)}:host .oui-date-picker .calendar-container .calendar-table{border-spacing:0;border-collapse:collapse;width:100%}:host .oui-date-picker .calendar-container .calendar-table thead{display:table-header-group}:host .oui-date-picker .calendar-container .calendar-table thead th{vertical-align:center}:host .oui-date-picker .calendar-container .calendar-table thead th .header-inner-container{display:flex;justify-content:center;align-items:center;color:var(--oui-date-picker-icons-color)}:host .oui-date-picker .calendar-container .calendar-table tbody{display:table-row-group}:host .oui-date-picker .calendar-container .calendar-table tbody td{vertical-align:center;color:var(--oui-date-picker-icons-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td .inner-option-container{display:flex;justify-content:center;align-items:center;min-width:4rem;height:4rem;padding:2px}:host .oui-date-picker .calendar-container .calendar-table tbody td .inner-option-container .innermost-option-container{border:1px solid transparent;box-sizing:border-box;flex:1 0 auto;display:flex;justify-content:center;align-items:center;height:100%}:host .oui-date-picker .calendar-container .calendar-table tbody td.muted{opacity:.7}:host .oui-date-picker .calendar-container .calendar-table tbody td.disabled{pointer-events:none;opacity:.3}:host .oui-date-picker .calendar-container .calendar-table tbody td.selected{background-color:var(--oui-date-picker-selected-date-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.start-date{background-color:var(--oui-date-picker-start-date-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.start-date .inner-option-container{background-color:var(--oui-date-picker-start-date-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.start-date .inner-option-container .innermost-option-container{background-color:var(--oui-date-picker-start-date-inner-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td:hover{cursor:pointer}:host .oui-date-picker .calendar-container .calendar-table tbody td:hover .inner-option-container .innermost-option-container{background-color:var(--oui-date-picker-calendar-background-hover);border:1px solid var(--oui-date-picker-calendar-background-border);box-shadow:var(--box-shadow-bottom-large)}:host .oui-date-picker .calendar-container .calendar-table tr{display:table-row}:host .oui-date-picker .presets-container{display:flex;flex-direction:column;padding:8px 0;color:var(--color-background-secondary-text)}:host .oui-date-picker .presets-container .presets-row{display:flex;align-items:center;justify-content:space-between;margin:4px 0}:host .oui-date-picker .presets-container .presets-row .preset{flex:1}:host .oui-date-picker .presets-container .presets-row .preset .preset-last-days-weeks{display:flex;align-items:center}:host .oui-date-picker .presets-container .presets-row .preset .preset-last-days-weeks .preset-last-days-weeks-input-container{width:20px;margin:0 4px 0 8px}:host .oui-date-picker .presets-container .presets-row .preset .preset-last-days-weeks .preset-last-days-weeks-input-container oui-input .oui-input{border-radius:5px}:host .oui-date-picker .presets-container .presets-row .preset .preset-last-days-weeks .preset-last-days-weeks-switch-container{height:30px;width:120px;flex:1;position:relative;margin-left:8px}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: i1.DatePipe, name: "date" }, { kind: "directive", type: OuiHoverDirective, selector: "[ouiHover]", outputs: ["hovered", "unhovered"] }, { kind: "pipe", type: ParentDateLabelPipe, name: "parentDateLabel" }, { kind: "pipe", type: MonthShortLabelPipe, name: "monthShortLabel" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDatePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-date-picker', standalone: true, imports: [
                        OuiIconComponent,
                        OuiDropdownComponent,
                        CommonModule,
                        NgTemplateOutlet,
                        OuiHoverDirective,
                        OuiRadioComponent,
                        OuiInputComponent,
                        ParentDateLabelPipe,
                        MonthShortLabelPipe,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (combinedOptions) {\n  <div class=\"oui-date-picker\">\n    <div class=\"calendar-container\">\n      <div class=\"calendar\">\n        <div class=\"mode-selector\">\n          <div class=\"mode-selector-caret left\" (click)=\"goBackParent()\">\n            <oui-icon\n            [options]=\"{\n              size: '28px',\n              fillColor: 'oui-date-picker-icons-color',\n              strokeColor: 'oui-date-picker-icons-color',\n              viewBox: '0 0 48 48'\n            }\"\n              [icon]=\"'assets/icons/caret-left.svg'\"\n            ></oui-icon>\n          </div>\n          <div class=\"mode-selector-current\" (click)=\"changeModeSelection()\">\n            {{ selectedCalendarDate | parentDateLabel: mode: combinedOptions.translations }}\n          </div>\n          <div class=\"mode-selector-caret right\" (click)=\"goForwardParent()\">\n            <oui-icon\n            [options]=\"{\n              size: '28px',\n              fillColor: 'oui-date-picker-icons-color',\n              strokeColor: 'oui-date-picker-icons-color',\n              viewBox: '0 0 48 48'\n            }\"\n              [icon]=\"'assets/icons/caret-right.svg'\"\n            ></oui-icon>\n          </div>\n        </div>\n        <ng-container [ngTemplateOutlet]=\"currentTemplate\"> </ng-container>\n      </div>\n    </div>\n  </div>\n}\n\n<ng-template #dayTemplate>\n  <table class=\"calendar-table\">\n    <thead>\n      <tr>\n        @for (day of combinedOptions.translations.days; track day) {\n          <th>\n            <span class=\"header-inner-container\">\n              {{ day }}\n            </span>\n          </th>\n        }\n      </tr>\n    </thead>\n    <tbody>\n      @for (week of dateSelectionOptions; track week) {\n        <tr>\n          @for (day of week; track day) {\n            <td\n              ouiHover\n              (click)=\"selectDay(day)\"\n              [ngClass]=\"getDateClass(day)\"\n              (hovered)=\"onDateHover(day, singleDate)\"\n              (unhovered)=\"onDateUnhover(day, singleDate)\"\n              #singleDate\n              >\n              <div class=\"inner-option-container\">\n                <div class=\"innermost-option-container\">\n                  {{ day | date: 'dd' }}\n                </div>\n              </div>\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n</ng-template>\n\n<ng-template #monthTemplate>\n  <table class=\"calendar-table\">\n    <tbody>\n      @for (row of dateSelectionOptions; track row) {\n        <tr>\n          @for (month of row; track month) {\n            <td\n              ouiHover\n              (click)=\"selectMonth(month)\"\n              [ngClass]=\"getDateClass(month)\"\n              (hovered)=\"onDateHover(month, singleDate)\"\n              (unhovered)=\"onDateUnhover(month, singleDate)\"\n              #singleDate\n              >\n              <div class=\"inner-option-container\">\n                <div class=\"innermost-option-container\">\n                  {{ month | monthShortLabel: combinedOptions.translations }}\n                </div>\n              </div>\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n</ng-template>\n\n<ng-template #yearTemplate>\n  <table class=\"calendar-table\">\n    <tbody>\n      @for (row of dateSelectionOptions; track row) {\n        <tr>\n          @for (year of row; track year) {\n            <td\n              ouiHover\n              (click)=\"selectYear(year)\"\n              [ngClass]=\"getDateClass(year)\"\n              (hovered)=\"onDateHover(year, singleDate)\"\n              (unhovered)=\"onDateUnhover(year, singleDate)\"\n              #singleDate\n              >\n              <div class=\"inner-option-container\">\n                <div class=\"innermost-option-container\">\n                  {{ year | date: 'yyyy' }}\n                </div>\n              </div>\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n</ng-template>\n", styles: [":host{width:100%;height:100%;position:relative;min-width:35rem;display:flex}:host .oui-date-picker{display:flex;flex-direction:column;padding:var(--oui-date-picker-padding);background-color:var(--oui-date-picker-background);flex:1;color:var(--oui-date-picker-primary-text)}:host .oui-date-picker .label-container{display:flex;flex-direction:row;align-items:center}:host .oui-date-picker .label-container .quick-date-container{display:flex;align-items:center;justify-content:space-between;font-size:var(--font-size-body-small)}:host .oui-date-picker .label-container .quick-date-container .quick-date-label{align-self:flex-end}:host .oui-date-picker .label-container .label{flex:0 1 48%;color:var(--oui-date-picker-primary-text)}:host .oui-date-picker .label-container .label .label-title{display:flex;align-items:center;margin-bottom:8px}:host .oui-date-picker .label-container .label .quick-date-container{border-radius:var(--border-radius-default) var(--border-radius-default) 0 0;border:1px solid transparent;position:relative;padding:8px}:host .oui-date-picker .label-container .label .quick-date-container:after{content:\"\";position:absolute;bottom:-7px;height:7px;left:-1px;width:100%;background-color:var(--color-background-tertiary);border:1px solid var(--color-background-tertiary)}:host .oui-date-picker .label-container .label .quick-date-container:hover{cursor:pointer;background-color:var(--color-background-tertiary-hover)}:host .oui-date-picker .label-container .fill{flex:1}:host .oui-date-picker .calendar-container{display:flex;flex-direction:column;flex:1;border-radius:var(--border-radius-default);background-color:var(--oui-date-picker-calendar-background)}:host .oui-date-picker .calendar-container .calendar{flex:1;display:flex;flex-direction:column;padding:2px}:host .oui-date-picker .calendar-container .calendar .mode-selector{display:flex;justify-content:center;align-items:center;margin:1rem 0}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-current{display:flex;align-items:center;justify-content:center;flex:1;-webkit-user-select:none;user-select:none}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-current:hover{cursor:pointer}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-caret{flex:0;display:flex;align-items:center;justify-content:center;-webkit-user-select:none;user-select:none;border-radius:50%;transition:background-color .3s,border .3s;border:1px solid transparent}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-caret:hover{border:1px solid var(--oui-date-picker-icons-border-color);background-color:var(--oui-date-picker-icons-hover-color);cursor:pointer}:host .oui-date-picker .calendar-container .calendar .day-label-row{display:flex;align-items:center}:host .oui-date-picker .calendar-container .calendar .day-label-row .date-picker-day-label{display:flex;align-items:center;justify-content:center;flex:1;color:var(--color-quaternary-text)}:host .oui-date-picker .calendar-container .calendar-table{border-spacing:0;border-collapse:collapse;width:100%}:host .oui-date-picker .calendar-container .calendar-table thead{display:table-header-group}:host .oui-date-picker .calendar-container .calendar-table thead th{vertical-align:center}:host .oui-date-picker .calendar-container .calendar-table thead th .header-inner-container{display:flex;justify-content:center;align-items:center;color:var(--oui-date-picker-icons-color)}:host .oui-date-picker .calendar-container .calendar-table tbody{display:table-row-group}:host .oui-date-picker .calendar-container .calendar-table tbody td{vertical-align:center;color:var(--oui-date-picker-icons-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td .inner-option-container{display:flex;justify-content:center;align-items:center;min-width:4rem;height:4rem;padding:2px}:host .oui-date-picker .calendar-container .calendar-table tbody td .inner-option-container .innermost-option-container{border:1px solid transparent;box-sizing:border-box;flex:1 0 auto;display:flex;justify-content:center;align-items:center;height:100%}:host .oui-date-picker .calendar-container .calendar-table tbody td.muted{opacity:.7}:host .oui-date-picker .calendar-container .calendar-table tbody td.disabled{pointer-events:none;opacity:.3}:host .oui-date-picker .calendar-container .calendar-table tbody td.selected{background-color:var(--oui-date-picker-selected-date-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.start-date{background-color:var(--oui-date-picker-start-date-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.start-date .inner-option-container{background-color:var(--oui-date-picker-start-date-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.start-date .inner-option-container .innermost-option-container{background-color:var(--oui-date-picker-start-date-inner-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td:hover{cursor:pointer}:host .oui-date-picker .calendar-container .calendar-table tbody td:hover .inner-option-container .innermost-option-container{background-color:var(--oui-date-picker-calendar-background-hover);border:1px solid var(--oui-date-picker-calendar-background-border);box-shadow:var(--box-shadow-bottom-large)}:host .oui-date-picker .calendar-container .calendar-table tr{display:table-row}:host .oui-date-picker .presets-container{display:flex;flex-direction:column;padding:8px 0;color:var(--color-background-secondary-text)}:host .oui-date-picker .presets-container .presets-row{display:flex;align-items:center;justify-content:space-between;margin:4px 0}:host .oui-date-picker .presets-container .presets-row .preset{flex:1}:host .oui-date-picker .presets-container .presets-row .preset .preset-last-days-weeks{display:flex;align-items:center}:host .oui-date-picker .presets-container .presets-row .preset .preset-last-days-weeks .preset-last-days-weeks-input-container{width:20px;margin:0 4px 0 8px}:host .oui-date-picker .presets-container .presets-row .preset .preset-last-days-weeks .preset-last-days-weeks-input-container oui-input .oui-input{border-radius:5px}:host .oui-date-picker .presets-container .presets-row .preset .preset-last-days-weeks .preset-last-days-weeks-switch-container{height:30px;width:120px;flex:1;position:relative;margin-left:8px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { dayTemplate: [{
                type: ViewChild,
                args: ['dayTemplate', { read: TemplateRef }]
            }], monthTemplate: [{
                type: ViewChild,
                args: ['monthTemplate', { read: TemplateRef }]
            }], yearTemplate: [{
                type: ViewChild,
                args: ['yearTemplate', { read: TemplateRef }]
            }], options: [{
                type: Input
            }] } });

class QuickDatePipe {
    transform(value, translations) {
        if (!value) {
            return '';
        }
        const month = getMonth(value);
        return (translations.months[month].substring(0, 3) +
            ' ' +
            format(value, 'dd') +
            ', ' +
            format(value, 'yyyy'));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: QuickDatePipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: QuickDatePipe, isStandalone: true, name: "quickDate" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: QuickDatePipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'quickDate',
                    standalone: true,
                }]
        }] });

/**
 * Component that adds a dropdown with an oui-datepicker inside it
 *
 */
class OuiDatePickerDropdownComponent {
    cdr;
    /**
     *   The date selected in the datepicker
     */
    date = model.required();
    /**
     *   The options to be passed to the datepicker
     */
    options = {
        datePickerOptions: {},
    };
    /**
     *   The event emitted when the date in the datepicker changes
     */
    dateChange = new EventEmitter();
    dropdown;
    isOpen = false;
    translations = DEFAULT_TRANSLATIONS;
    constructor(cdr) {
        this.cdr = cdr;
    }
    onDateChange(date) {
        this.date.set(date);
        this.dateChange.emit(this.date());
        this.dropdown.close();
    }
    ngOnChanges(changes) {
        if ('options' in changes) {
            this.options = changes.options.currentValue;
            this.translations =
                changes.options.currentValue.datePickerOptions.translations ??
                    this.translations;
            this.cdr.detectChanges();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDatePickerDropdownComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiDatePickerDropdownComponent, isStandalone: true, selector: "oui-date-picker-dropdown", inputs: { date: { classPropertyName: "date", publicName: "date", isSignal: true, isRequired: true, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: false, isRequired: false, transformFunction: null } }, outputs: { date: "dateChange", dateChange: "dateChange" }, viewQueries: [{ propertyName: "dropdown", first: true, predicate: ["dropdown"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"oui-date-picker-dropdown-container\">\n  <oui-dropdown\n    [disableCloseOnWindowResize]=\"true\"\n    [(isOpen)]=\"isOpen\"\n    [toggle]=\"toggle\"\n    [content]=\"content\"\n    #dropdown\n    >\n    <ng-template #toggle>\n      <div class=\"date-picker-toggle-container\">\n        <div class=\"date-picker-toggle-icon\">\n          <oui-icon\n            [options]=\"{\n              size: '18px',\n              fillColor: 'oui-date-picker-icons-color',\n              strokeColor: 'oui-date-picker-icons-color'\n            }\"\n            icon=\"assets/icons/calendar.svg\"\n            >\n          </oui-icon>\n        </div>\n        <div class=\"date-picker-date from\">\n          {{ date() | quickDate: translations }}\n        </div>\n        <div class=\"date-picker-toggle-caret\">\n          @if (!isOpen) {\n            <oui-icon\n              icon=\"assets/icons/caret_down.svg\"\n            [options]=\"{\n              fillColor: 'oui-date-picker-icons-color',\n              strokeColor: 'oui-date-picker-icons-color'\n            }\"\n            ></oui-icon>\n          }\n          @if (isOpen) {\n            <oui-icon\n              icon=\"assets/icons/caret_up.svg\"\n            [options]=\"{\n              fillColor: 'oui-date-picker-icons-color',\n              strokeColor: 'oui-date-picker-icons-color'\n            }\"\n            ></oui-icon>\n          }\n        </div>\n      </div>\n    </ng-template>\n    <ng-template #content>\n      <div\n        class=\"date-picker-content-container {{\n          options.dropdownOptions?.className ?? ''\n        }}\"\n        >\n        <oui-date-picker\n          [options]=\"options.datePickerOptions\"\n          (dateChange)=\"onDateChange($event)\"\n          [date]=\"date()\"\n        ></oui-date-picker>\n      </div>\n    </ng-template>\n  </oui-dropdown>\n</div>\n", styles: [":host{height:100%;position:relative;display:flex;width:100%;background-color:var(--oui-date-picker-toggle-background);border-radius:var(--oui-date-picker-toggle-border-radius);border-width:var(--oui-date-picker-toggle-border-width);border-style:var(--oui-date-picker-toggle-border-style);border-color:var(--oui-date-picker-toggle-border-color)}:host .oui-date-picker-dropdown-container{height:100%;border-radius:var(--oui-date-picker-toggle-border-radius);color:var(--oui-date-picker-toggle-primary-text);transition:background-color .3s;width:100%;background-color:var(--oui-date-picker-toggle-background)}:host .oui-date-picker-dropdown-container:hover{background-color:var(--oui-date-picker-toggle-background-hover)}:host .oui-date-picker-dropdown-container .date-picker-toggle-container{border-radius:var(--oui-date-picker-toggle-border-radius);display:flex;align-items:center;justify-content:space-between;box-shadow:var(--oui-date-picker-toggle-box-shadow);padding:var(--oui-date-picker-dropdown-toggle-padding);flex:1}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-toggle-icon{margin-right:8px}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-date{white-space:nowrap}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-date :hover{cursor:pointer}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-divider-icon{margin:0 12px}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "component", type: OuiDropdownComponent, selector: "oui-dropdown", inputs: ["disableCloseOnWindowResize", "content", "toggle", "isOpen", "disabled"], outputs: ["isOpenChange"] }, { kind: "component", type: OuiDatePickerComponent, selector: "oui-date-picker", inputs: ["date", "options"], outputs: ["dateChange"] }, { kind: "pipe", type: QuickDatePipe, name: "quickDate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDatePickerDropdownComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-date-picker-dropdown', standalone: true, imports: [
                        OuiIconComponent,
                        OuiDropdownComponent,
                        OuiDatePickerComponent,
                        OuiRippleDirective,
                        QuickDatePipe,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"oui-date-picker-dropdown-container\">\n  <oui-dropdown\n    [disableCloseOnWindowResize]=\"true\"\n    [(isOpen)]=\"isOpen\"\n    [toggle]=\"toggle\"\n    [content]=\"content\"\n    #dropdown\n    >\n    <ng-template #toggle>\n      <div class=\"date-picker-toggle-container\">\n        <div class=\"date-picker-toggle-icon\">\n          <oui-icon\n            [options]=\"{\n              size: '18px',\n              fillColor: 'oui-date-picker-icons-color',\n              strokeColor: 'oui-date-picker-icons-color'\n            }\"\n            icon=\"assets/icons/calendar.svg\"\n            >\n          </oui-icon>\n        </div>\n        <div class=\"date-picker-date from\">\n          {{ date() | quickDate: translations }}\n        </div>\n        <div class=\"date-picker-toggle-caret\">\n          @if (!isOpen) {\n            <oui-icon\n              icon=\"assets/icons/caret_down.svg\"\n            [options]=\"{\n              fillColor: 'oui-date-picker-icons-color',\n              strokeColor: 'oui-date-picker-icons-color'\n            }\"\n            ></oui-icon>\n          }\n          @if (isOpen) {\n            <oui-icon\n              icon=\"assets/icons/caret_up.svg\"\n            [options]=\"{\n              fillColor: 'oui-date-picker-icons-color',\n              strokeColor: 'oui-date-picker-icons-color'\n            }\"\n            ></oui-icon>\n          }\n        </div>\n      </div>\n    </ng-template>\n    <ng-template #content>\n      <div\n        class=\"date-picker-content-container {{\n          options.dropdownOptions?.className ?? ''\n        }}\"\n        >\n        <oui-date-picker\n          [options]=\"options.datePickerOptions\"\n          (dateChange)=\"onDateChange($event)\"\n          [date]=\"date()\"\n        ></oui-date-picker>\n      </div>\n    </ng-template>\n  </oui-dropdown>\n</div>\n", styles: [":host{height:100%;position:relative;display:flex;width:100%;background-color:var(--oui-date-picker-toggle-background);border-radius:var(--oui-date-picker-toggle-border-radius);border-width:var(--oui-date-picker-toggle-border-width);border-style:var(--oui-date-picker-toggle-border-style);border-color:var(--oui-date-picker-toggle-border-color)}:host .oui-date-picker-dropdown-container{height:100%;border-radius:var(--oui-date-picker-toggle-border-radius);color:var(--oui-date-picker-toggle-primary-text);transition:background-color .3s;width:100%;background-color:var(--oui-date-picker-toggle-background)}:host .oui-date-picker-dropdown-container:hover{background-color:var(--oui-date-picker-toggle-background-hover)}:host .oui-date-picker-dropdown-container .date-picker-toggle-container{border-radius:var(--oui-date-picker-toggle-border-radius);display:flex;align-items:center;justify-content:space-between;box-shadow:var(--oui-date-picker-toggle-box-shadow);padding:var(--oui-date-picker-dropdown-toggle-padding);flex:1}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-toggle-icon{margin-right:8px}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-date{white-space:nowrap}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-date :hover{cursor:pointer}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-divider-icon{margin:0 12px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { options: [{
                type: Input
            }], dateChange: [{
                type: Output
            }], dropdown: [{
                type: ViewChild,
                args: ['dropdown']
            }] } });

// TODO: Extract presets out and instead let user pass in custom-presets
/**
 * A component for a date-range -picker. Enables to pick a from-date and a to-date.
 */
class OuiDateRangePickerComponent {
    cdr;
    dayTemplate;
    monthTemplate;
    yearTemplate;
    /**
     *   The first selected date of the date-range
     */
    dateFrom = model.required();
    /**
     * The second selected date of the date-range
     */
    dateTo = model.required();
    presetsTemplate;
    /**
     *  The options to pass to the calendar. getDateClass lets you assign custom classes to specific dates. The only input parameter
     *  to the function is a date, and the return value is the entire classname to be added to the date.
     *  getHoverClass works the same, except adds classes to specific dates when hovering over them.
     */
    options = {};
    /**
     *   The event emitted when the dateFrom-value changes
     */
    defaultOptions = {
        translations: {
            months: [
                'January',
                'February',
                'March',
                'April',
                'May',
                'June',
                'July',
                'August',
                'September',
                'October',
                'November',
                'December',
            ],
            days: ['M', 'Tu', 'W', 'Th', 'F', 'Sa', 'Su'],
        },
        labels: {
            endDate: 'End date',
            startDate: 'Start date',
        },
        getDateClass: (date, mode, selectingFor) => {
            const dateFrom = this.dateFrom();
            const dateTo = this.dateTo();
            const isInSameMonth = (dateFrom && dateTo && isSameMonth(date, dateFrom)) ||
                (dateTo && isSameMonth(date, dateTo));
            const isInSameYear = (dateFrom && dateTo && isSameYear(date, dateFrom)) ||
                (dateTo && isSameYear(date, dateTo));
            const isWithinDateRange = dateFrom && date >= dateFrom && dateTo && date <= dateTo;
            const isStartDate = dateFrom && isSameDay(date, dateFrom);
            const isEndDate = dateTo && dateTo && isSameDay(date, dateTo);
            const classes = [];
            if (selectingFor === 'from' && dateTo) {
                if (isAfter(date, dateTo)) {
                    classes.push('disabled');
                }
            }
            if (selectingFor === 'to' && dateFrom) {
                if (mode === 'day') {
                    if (isBefore(date, dateFrom)) {
                        classes.push('disabled');
                    }
                }
                else if (mode === 'month') {
                    if (isBefore(date, subMonths(dateFrom, 1))) {
                        classes.push('disabled');
                    }
                }
                else {
                    if (isBefore(date, subYears(dateFrom, 1))) {
                        classes.push('disabled');
                    }
                }
            }
            if (mode === 'day') {
                if (isWithinDateRange || isStartDate || isEndDate) {
                    classes.push('selected');
                }
                if (isStartDate) {
                    classes.push('start-date');
                }
                if (isEndDate) {
                    classes.push('end-date');
                }
                if (!isInSameMonth && !isWithinDateRange) {
                    classes.push('muted');
                }
            }
            else if (mode === 'month') {
                if (!isInSameMonth && !isWithinDateRange) {
                    classes.push('muted');
                }
            }
            else if (mode === 'year') {
                if (!isInSameYear && !isWithinDateRange) {
                    classes.push('muted');
                }
            }
            return classes.join(' ');
        },
        getHoverClass: (date, mode, selectingFor) => {
            if (selectingFor === 'from') {
                return 'hover';
            }
            else {
                return 'range-end';
            }
        },
    };
    combinedOptions;
    dateSelectionOptions = [];
    mode = 'day';
    selectingFor = 'from';
    selectedCalendarDate = new Date();
    currentTemplate;
    constructor(cdr) {
        this.cdr = cdr;
        this.generateDateSelection();
    }
    ngOnInit() {
        this.combineOptions();
    }
    ngAfterViewInit() {
        this.currentTemplate = this.dayTemplate;
        this.cdr.detectChanges();
    }
    selectTo() {
        this.selectingFor = 'to';
        const dateTo = this.dateTo();
        if (dateTo) {
            this.selectedCalendarDate = dateTo;
        }
        this.generateDateSelection();
    }
    selectFrom() {
        this.selectingFor = 'from';
        this.selectedCalendarDate = this.dateFrom() || new Date();
        this.generateDateSelection();
    }
    generateDateSelection() {
        let dates = [];
        if (this.mode === 'year') {
            dates = generateYears(this.selectedCalendarDate);
        }
        else if (this.mode === 'month') {
            dates = generateMonths(this.selectedCalendarDate);
        }
        else {
            dates = generateWeeks(startOfMonth(this.selectedCalendarDate));
        }
        this.dateSelectionOptions = dates;
    }
    getOption(date) {
        if (this.mode === 'year') {
            return getYear(date);
        }
        else if (this.mode === 'month') {
            return getMonth(date);
        }
        else {
            return date.getDate();
        }
    }
    selectDay(date) {
        if (this.selectingFor === 'from') {
            this.dateFrom.set(date);
            this.selectingFor = 'to';
        }
        else {
            this.dateTo.set(date);
        }
    }
    selectMonth(date) {
        this.selectedCalendarDate = date;
        this.mode = 'day';
        this.currentTemplate = this.dayTemplate;
        this.generateDateSelection();
    }
    selectYear(date) {
        this.selectedCalendarDate = date;
        this.mode = 'month';
        this.currentTemplate = this.monthTemplate;
        this.generateDateSelection();
    }
    goBackParent() {
        this.selectedCalendarDate = goBackwards(this.selectedCalendarDate, this.mode);
        this.generateDateSelection();
    }
    changeModeSelection() {
        if (this.mode === 'day') {
            this.mode = 'month';
            this.currentTemplate = this.monthTemplate;
        }
        else if (this.mode === 'month') {
            this.mode = 'year';
            this.currentTemplate = this.yearTemplate;
        }
        else {
            return;
        }
        this.generateDateSelection();
    }
    goForwardParent() {
        this.selectedCalendarDate = goForward(this.selectedCalendarDate, this.mode);
        this.generateDateSelection();
    }
    clearDateTo() {
        this.dateTo.set(undefined);
    }
    getDateClass(date) {
        if (this.combinedOptions.getDateClass) {
            return this.combinedOptions.getDateClass(date, this.mode, this.selectingFor);
        }
        else {
            return '';
        }
    }
    onDateHover(date, element) {
        const classes = this.combinedOptions.getHoverClass
            ? this.combinedOptions.getHoverClass(date, this.mode, this.selectingFor)
            : '';
        element.classList.add(classes);
    }
    onDateUnhover(date, element) {
        const classes = this.combinedOptions.getHoverClass
            ? this.combinedOptions.getHoverClass(date, this.mode, this.selectingFor)
            : '';
        element.classList.remove(classes);
    }
    combineOptions() {
        this.combinedOptions = {
            labels: {
                ...this.defaultOptions.labels,
                ...(this.options.labels ?? {}),
            },
            translations: this.options.translations ?? this.defaultOptions.translations,
            getDateClass: (date, mode, selectingFor) => {
                let classes = this.defaultOptions.getDateClass(date, mode, selectingFor);
                if (this.options.getDateClass) {
                    classes += ' ' + this.options.getDateClass(date, mode, selectingFor);
                }
                return classes;
            },
            getHoverClass: (date, mode, selectingFor) => {
                let classes = this.defaultOptions.getHoverClass(date, mode, selectingFor);
                if (this.options.getHoverClass) {
                    classes += ' ' + this.options.getHoverClass(date, mode, selectingFor);
                }
                return classes;
            },
        };
    }
    ngOnChanges(changes) {
        if ('options' in changes) {
            this.options = changes['options'].currentValue;
            this.combineOptions();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDateRangePickerComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiDateRangePickerComponent, isStandalone: true, selector: "oui-date-range-picker", inputs: { dateFrom: { classPropertyName: "dateFrom", publicName: "dateFrom", isSignal: true, isRequired: true, transformFunction: null }, dateTo: { classPropertyName: "dateTo", publicName: "dateTo", isSignal: true, isRequired: true, transformFunction: null }, presetsTemplate: { classPropertyName: "presetsTemplate", publicName: "presetsTemplate", isSignal: false, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: false, isRequired: false, transformFunction: null } }, outputs: { dateFrom: "dateFromChange", dateTo: "dateToChange" }, viewQueries: [{ propertyName: "dayTemplate", first: true, predicate: ["dayTemplate"], descendants: true, read: TemplateRef }, { propertyName: "monthTemplate", first: true, predicate: ["monthTemplate"], descendants: true, read: TemplateRef }, { propertyName: "yearTemplate", first: true, predicate: ["yearTemplate"], descendants: true, read: TemplateRef }], usesOnChanges: true, ngImport: i0, template: "<div class=\"oui-date-picker\">\n  <div class=\"label-container\">\n    <div class=\"label from\" (click)=\"selectFrom()\">\n      <div class=\"label-title\">{{combinedOptions.labels.startDate}}</div>\n      <div\n        class=\"transition-all duration-300 quick-date-container\"\n        [ngClass]=\"{ active: selectingFor === 'from' }\"\n        >\n        <div class=\"quick-date-icon\">\n          <oui-icon\n            icon=\"assets/icons/calendar.svg\"\n            [options]=\"{\n              size: '16px',\n              strokeColor: 'oui-date-picker-icons-color',\n              fillColor: 'oui-date-picker-icons-color'\n            }\"\n          ></oui-icon>\n        </div>\n        <div class=\"quick-date-label\">\n          {{ dateFrom() | quickDate: combinedOptions.translations }}\n        </div>\n      </div>\n    </div>\n    <div class=\"fill\"></div>\n    <div class=\"label to\" (click)=\"selectTo()\">\n      <div class=\"label-title\">{{combinedOptions.labels.endDate}}</div>\n      <div\n        class=\"transition-all duration-300 quick-date-container\"\n        [ngClass]=\"{ active: selectingFor === 'to' }\"\n        >\n        <div class=\"quick-date-icon\">\n          <oui-icon\n            icon=\"assets/icons/calendar.svg\"\n            [options]=\"{\n              size: '16px',\n              fillColor: 'oui-date-picker-icons-color'\n            }\"\n          ></oui-icon>\n        </div>\n        <div class=\"quick-date-label\">\n          {{ dateTo() | quickDate: combinedOptions.translations }}\n        </div>\n        @if (dateTo()) {\n          <div class=\"quick-date-remove\" (click)=\"clearDateTo()\">\n            <oui-icon-button\n              color=\"transparent\"\n              icon=\"assets/icons/close.svg\"\n            [options]=\"{\n              size: '16px',\n              strokeColor: 'oui-date-picker-icons-color',\n              fillColor: 'oui-date-picker-icons-color'\n            }\"\n            ></oui-icon-button>\n          </div>\n        }\n      </div>\n    </div>\n  </div>\n  <div class=\"calendar-container rounded-default {{ selectingFor }}\">\n    <div class=\"calendar\">\n      <div class=\"mode-selector\">\n        <div class=\"mode-selector-caret left\" (click)=\"goBackParent()\">\n          <oui-icon\n            [options]=\"{\n              size: '28px',\n              strokeColor: 'oui-date-picker-icons-color',\n              fillColor: 'oui-date-picker-icons-color',\n              viewBox: '0 0 48 48'\n            }\"\n            [icon]=\"'assets/icons/caret-left.svg'\"\n          ></oui-icon>\n        </div>\n        <div class=\"mode-selector-current\" (click)=\"changeModeSelection()\">\n          {{ selectedCalendarDate | parentDateLabel: mode: combinedOptions.translations }}\n        </div>\n        <div class=\"mode-selector-caret right\" (click)=\"goForwardParent()\">\n          <oui-icon\n            [options]=\"{\n              size: '28px',\n              strokeColor: 'oui-date-picker-icons-color',\n              fillColor: 'oui-date-picker-icons-color',\n              viewBox: '0 0 48 48'\n            }\"\n            [icon]=\"'assets/icons/caret-right.svg'\"\n          ></oui-icon>\n        </div>\n      </div>\n      <ng-container [ngTemplateOutlet]=\"currentTemplate\"> </ng-container>\n    </div>\n  </div>\n\n  @if (presetsTemplate) {\n    <div class=\"presets-container\">\n      <ng-container [ngTemplateOutlet]=\"presetsTemplate\"> </ng-container>\n    </div>\n  }\n</div>\n\n<ng-template #dayTemplate>\n  <table class=\"calendar-table\">\n    <thead>\n      <tr>\n        @for (day of combinedOptions.translations.days; track day) {\n          <th>\n            <span class=\"header-inner-container\">\n              {{ day }}\n            </span>\n          </th>\n        }\n      </tr>\n    </thead>\n    <tbody>\n      @for (week of dateSelectionOptions; track week) {\n        <tr>\n          @for (day of week; track day) {\n            <td\n              ouiHover\n              (click)=\"selectDay(day)\"\n              [ngClass]=\"getDateClass(day)\"\n              (hovered)=\"onDateHover(day, singleDate)\"\n              (unhovered)=\"onDateUnhover(day, singleDate)\"\n              #singleDate\n              >\n              <div class=\"inner-option-container\">\n                <div class=\"innermost-option-container\">\n                  {{ getOption(day) }}\n                </div>\n              </div>\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n</ng-template>\n\n<ng-template #monthTemplate>\n  <table class=\"calendar-table\">\n    <tbody>\n      @for (row of dateSelectionOptions; track row) {\n        <tr>\n          @for (month of row; track month) {\n            <td\n              ouiHover\n              (click)=\"selectMonth(month)\"\n              [ngClass]=\"getDateClass(month)\"\n              (hovered)=\"onDateHover(month, singleDate)\"\n              (unhovered)=\"onDateUnhover(month, singleDate)\"\n              #singleDate\n              >\n              <div class=\"inner-option-container\">\n                <div class=\"innermost-option-container\">\n                  {{ month | monthShortLabel: combinedOptions.translations }}\n                </div>\n              </div>\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n</ng-template>\n\n<ng-template #yearTemplate>\n  <table class=\"calendar-table\">\n    <tbody>\n      @for (row of dateSelectionOptions; track row) {\n        <tr>\n          @for (year of row; track year) {\n            <td\n              ouiHover\n              (click)=\"selectYear(year)\"\n              [ngClass]=\"getDateClass(year)\"\n              (hovered)=\"onDateHover(year, singleDate)\"\n              (unhovered)=\"onDateUnhover(year, singleDate)\"\n              #singleDate\n              >\n              <div class=\"inner-option-container\">\n                <div class=\"innermost-option-container\">\n                  {{ year | date: 'yyyy' }}\n                </div>\n              </div>\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n</ng-template>\n", styles: [":host{width:100%;height:100%;position:relative;padding:var(--oui-date-picker-padding);background-color:var(--oui-date-picker-background);display:inline-block}:host .oui-date-picker{display:flex;flex-direction:column;background-color:var(--oui-date-picker-background);color:var(--oui-date-picker-primary-text)}:host .oui-date-picker .label-container{display:flex;flex-direction:row;align-items:center;justify-content:center;margin-bottom:1rem;padding-bottom:1rem;border-bottom:1px solid var(--oui-date-picker-selected-date-display-border-color)}:host .oui-date-picker .label-container .quick-date-container{display:flex;align-items:center;justify-content:space-between;font-size:var(--font-size-body-small);border-radius:var(--oui-date-picker-selected-date-display-border-radius)}:host .oui-date-picker .label-container .label{flex:0 1 48%}:host .oui-date-picker .label-container .label .label-title{display:flex;align-items:center;margin-bottom:8px}:host .oui-date-picker .label-container .label .quick-date-filler{width:100%;position:absolute;bottom:-7px;height:7px;left:0;background-color:var(--oui-date-picker-background)}:host .oui-date-picker .label-container .label .quick-date-container{position:relative;padding:8px;min-height:4rem}:host .oui-date-picker .label-container .label .quick-date-container.active{background-color:var(--oui-date-picker-selected-date-display-background-color);outline:1px solid var(--oui-date-picker-selected-date-display-border-color)}:host .oui-date-picker .label-container .label .quick-date-container:hover{cursor:pointer;background-color:var(--oui-date-picker-selected-date-display-background-hover-color)}:host .oui-date-picker .label-container .fill{flex:1}:host .oui-date-picker .calendar-container{display:flex;flex-direction:column;flex:1;background-color:var(--oui-date-picker-calendar-background)}:host .oui-date-picker .calendar-container .calendar-table{border-spacing:0;border-collapse:collapse;width:100%}:host .oui-date-picker .calendar-container .calendar-table thead{display:table-header-group}:host .oui-date-picker .calendar-container .calendar-table thead th{vertical-align:center}:host .oui-date-picker .calendar-container .calendar-table thead th .header-inner-container{display:flex;justify-content:center;align-items:center}:host .oui-date-picker .calendar-container .calendar-table tbody{display:table-row-group}:host .oui-date-picker .calendar-container .calendar-table tbody td{vertical-align:center}:host .oui-date-picker .calendar-container .calendar-table tbody td .inner-option-container{display:flex;justify-content:center;align-items:center;min-width:4rem;height:4rem;padding:2px}:host .oui-date-picker .calendar-container .calendar-table tbody td .inner-option-container .innermost-option-container{border:1px solid transparent;box-sizing:border-box;flex:1 0 auto;display:flex;justify-content:center;align-items:center;height:100%}:host .oui-date-picker .calendar-container .calendar-table tbody td.muted{opacity:.7}:host .oui-date-picker .calendar-container .calendar-table tbody td.disabled{opacity:.3;pointer-events:none}:host .oui-date-picker .calendar-container .calendar-table tbody td.selected{background-color:var(--oui-date-picker-selected-date-background-color);color:var(--oui-date-picker-selected-date-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.start-date{background-color:var(--oui-date-picker-start-date-background-color);color:var(--oui-date-picker-start-date-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.start-date .inner-option-container{background-color:var(--oui-date-picker-start-date-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.start-date .inner-option-container .innermost-option-container{background-color:var(--oui-date-picker-start-date-inner-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.end-date{background-color:var(--oui-date-picker-end-date-background-color);color:var(--oui-date-picker-end-date-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.end-date .inner-option-container{background-color:var(--oui-date-picker-end-date-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.end-date .inner-option-container .innermost-option-container{background-color:var(--oui-date-picker-end-date-inner-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td:hover{cursor:pointer}:host .oui-date-picker .calendar-container .calendar-table tbody td:hover .inner-option-container .innermost-option-container{background-color:var(--oui-date-picker-calendar-background-hover);border:1px solid var(--oui-date-picker-calendar-background-border);box-shadow:var(--box-shadow-bottom-large)}:host .oui-date-picker .calendar-container .calendar-table tr{display:table-row}:host .oui-date-picker .calendar-container.from{border-radius:var(--border-radius-default)}:host .oui-date-picker .calendar-container.from .option:hover{background-color:var(--color-accent-secondary-lighter)}:host .oui-date-picker .calendar-container.from .option:hover .inner-option-container{background-color:var(--color-accent-secondary-lighter)}:host .oui-date-picker .calendar-container.from .option:hover .inner-option-container .innermost-option-container{background-color:var(--color-accent-secondary-lighter)}:host .oui-date-picker .calendar-container.to{border-radius:var(--border-radius-default)}:host .oui-date-picker .calendar-container.to .option:hover{background-color:var(--color-accent-lighter)}:host .oui-date-picker .calendar-container.to .option:hover .inner-option-container{background-color:var(--color-accent-lighter)}:host .oui-date-picker .calendar-container.to .option:hover .inner-option-container .innermost-option-container{background-color:var(--color-accent-lighter)}:host .oui-date-picker .calendar-container .calendar{flex:1;display:flex;flex-direction:column;padding:2px}:host .oui-date-picker .calendar-container .calendar .mode-selector{display:flex;justify-content:center;align-items:center;margin:1rem 0}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-current{display:flex;align-items:center;justify-content:center;flex:1;-webkit-user-select:none;user-select:none}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-current:hover{cursor:pointer}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-caret{flex:0;display:flex;align-items:center;justify-content:center;-webkit-user-select:none;user-select:none;border-radius:50%;transition:background-color .3s,border .3s;border:1px solid transparent}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-caret:hover{border:1px solid var(--oui-date-picker-icons-border-color);background-color:var(--oui-date-picker-icons-hover-color);cursor:pointer}:host .oui-date-picker .calendar-container .calendar .day-label-row{display:flex;align-items:center}:host .oui-date-picker .calendar-container .calendar .day-label-row .date-picker-day-label{display:flex;align-items:center;justify-content:center;flex:1;color:var(--color-primary-text)}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: i1.DatePipe, name: "date" }, { kind: "directive", type: OuiHoverDirective, selector: "[ouiHover]", outputs: ["hovered", "unhovered"] }, { kind: "pipe", type: ParentDateLabelPipe, name: "parentDateLabel" }, { kind: "component", type: OuiIconButtonComponent, selector: "oui-icon-button", inputs: ["icon", "isLoading", "options"], outputs: ["onClick"] }, { kind: "pipe", type: QuickDatePipe, name: "quickDate" }, { kind: "pipe", type: MonthShortLabelPipe, name: "monthShortLabel" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDateRangePickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-date-range-picker', standalone: true, imports: [
                        OuiIconComponent,
                        OuiDropdownComponent,
                        CommonModule,
                        OuiHoverDirective,
                        OuiRadioComponent,
                        OuiSwitchComponent,
                        OuiInputComponent,
                        ParentDateLabelPipe,
                        OuiIconButtonComponent,
                        QuickDatePipe,
                        MonthShortLabelPipe,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"oui-date-picker\">\n  <div class=\"label-container\">\n    <div class=\"label from\" (click)=\"selectFrom()\">\n      <div class=\"label-title\">{{combinedOptions.labels.startDate}}</div>\n      <div\n        class=\"transition-all duration-300 quick-date-container\"\n        [ngClass]=\"{ active: selectingFor === 'from' }\"\n        >\n        <div class=\"quick-date-icon\">\n          <oui-icon\n            icon=\"assets/icons/calendar.svg\"\n            [options]=\"{\n              size: '16px',\n              strokeColor: 'oui-date-picker-icons-color',\n              fillColor: 'oui-date-picker-icons-color'\n            }\"\n          ></oui-icon>\n        </div>\n        <div class=\"quick-date-label\">\n          {{ dateFrom() | quickDate: combinedOptions.translations }}\n        </div>\n      </div>\n    </div>\n    <div class=\"fill\"></div>\n    <div class=\"label to\" (click)=\"selectTo()\">\n      <div class=\"label-title\">{{combinedOptions.labels.endDate}}</div>\n      <div\n        class=\"transition-all duration-300 quick-date-container\"\n        [ngClass]=\"{ active: selectingFor === 'to' }\"\n        >\n        <div class=\"quick-date-icon\">\n          <oui-icon\n            icon=\"assets/icons/calendar.svg\"\n            [options]=\"{\n              size: '16px',\n              fillColor: 'oui-date-picker-icons-color'\n            }\"\n          ></oui-icon>\n        </div>\n        <div class=\"quick-date-label\">\n          {{ dateTo() | quickDate: combinedOptions.translations }}\n        </div>\n        @if (dateTo()) {\n          <div class=\"quick-date-remove\" (click)=\"clearDateTo()\">\n            <oui-icon-button\n              color=\"transparent\"\n              icon=\"assets/icons/close.svg\"\n            [options]=\"{\n              size: '16px',\n              strokeColor: 'oui-date-picker-icons-color',\n              fillColor: 'oui-date-picker-icons-color'\n            }\"\n            ></oui-icon-button>\n          </div>\n        }\n      </div>\n    </div>\n  </div>\n  <div class=\"calendar-container rounded-default {{ selectingFor }}\">\n    <div class=\"calendar\">\n      <div class=\"mode-selector\">\n        <div class=\"mode-selector-caret left\" (click)=\"goBackParent()\">\n          <oui-icon\n            [options]=\"{\n              size: '28px',\n              strokeColor: 'oui-date-picker-icons-color',\n              fillColor: 'oui-date-picker-icons-color',\n              viewBox: '0 0 48 48'\n            }\"\n            [icon]=\"'assets/icons/caret-left.svg'\"\n          ></oui-icon>\n        </div>\n        <div class=\"mode-selector-current\" (click)=\"changeModeSelection()\">\n          {{ selectedCalendarDate | parentDateLabel: mode: combinedOptions.translations }}\n        </div>\n        <div class=\"mode-selector-caret right\" (click)=\"goForwardParent()\">\n          <oui-icon\n            [options]=\"{\n              size: '28px',\n              strokeColor: 'oui-date-picker-icons-color',\n              fillColor: 'oui-date-picker-icons-color',\n              viewBox: '0 0 48 48'\n            }\"\n            [icon]=\"'assets/icons/caret-right.svg'\"\n          ></oui-icon>\n        </div>\n      </div>\n      <ng-container [ngTemplateOutlet]=\"currentTemplate\"> </ng-container>\n    </div>\n  </div>\n\n  @if (presetsTemplate) {\n    <div class=\"presets-container\">\n      <ng-container [ngTemplateOutlet]=\"presetsTemplate\"> </ng-container>\n    </div>\n  }\n</div>\n\n<ng-template #dayTemplate>\n  <table class=\"calendar-table\">\n    <thead>\n      <tr>\n        @for (day of combinedOptions.translations.days; track day) {\n          <th>\n            <span class=\"header-inner-container\">\n              {{ day }}\n            </span>\n          </th>\n        }\n      </tr>\n    </thead>\n    <tbody>\n      @for (week of dateSelectionOptions; track week) {\n        <tr>\n          @for (day of week; track day) {\n            <td\n              ouiHover\n              (click)=\"selectDay(day)\"\n              [ngClass]=\"getDateClass(day)\"\n              (hovered)=\"onDateHover(day, singleDate)\"\n              (unhovered)=\"onDateUnhover(day, singleDate)\"\n              #singleDate\n              >\n              <div class=\"inner-option-container\">\n                <div class=\"innermost-option-container\">\n                  {{ getOption(day) }}\n                </div>\n              </div>\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n</ng-template>\n\n<ng-template #monthTemplate>\n  <table class=\"calendar-table\">\n    <tbody>\n      @for (row of dateSelectionOptions; track row) {\n        <tr>\n          @for (month of row; track month) {\n            <td\n              ouiHover\n              (click)=\"selectMonth(month)\"\n              [ngClass]=\"getDateClass(month)\"\n              (hovered)=\"onDateHover(month, singleDate)\"\n              (unhovered)=\"onDateUnhover(month, singleDate)\"\n              #singleDate\n              >\n              <div class=\"inner-option-container\">\n                <div class=\"innermost-option-container\">\n                  {{ month | monthShortLabel: combinedOptions.translations }}\n                </div>\n              </div>\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n</ng-template>\n\n<ng-template #yearTemplate>\n  <table class=\"calendar-table\">\n    <tbody>\n      @for (row of dateSelectionOptions; track row) {\n        <tr>\n          @for (year of row; track year) {\n            <td\n              ouiHover\n              (click)=\"selectYear(year)\"\n              [ngClass]=\"getDateClass(year)\"\n              (hovered)=\"onDateHover(year, singleDate)\"\n              (unhovered)=\"onDateUnhover(year, singleDate)\"\n              #singleDate\n              >\n              <div class=\"inner-option-container\">\n                <div class=\"innermost-option-container\">\n                  {{ year | date: 'yyyy' }}\n                </div>\n              </div>\n            </td>\n          }\n        </tr>\n      }\n    </tbody>\n  </table>\n</ng-template>\n", styles: [":host{width:100%;height:100%;position:relative;padding:var(--oui-date-picker-padding);background-color:var(--oui-date-picker-background);display:inline-block}:host .oui-date-picker{display:flex;flex-direction:column;background-color:var(--oui-date-picker-background);color:var(--oui-date-picker-primary-text)}:host .oui-date-picker .label-container{display:flex;flex-direction:row;align-items:center;justify-content:center;margin-bottom:1rem;padding-bottom:1rem;border-bottom:1px solid var(--oui-date-picker-selected-date-display-border-color)}:host .oui-date-picker .label-container .quick-date-container{display:flex;align-items:center;justify-content:space-between;font-size:var(--font-size-body-small);border-radius:var(--oui-date-picker-selected-date-display-border-radius)}:host .oui-date-picker .label-container .label{flex:0 1 48%}:host .oui-date-picker .label-container .label .label-title{display:flex;align-items:center;margin-bottom:8px}:host .oui-date-picker .label-container .label .quick-date-filler{width:100%;position:absolute;bottom:-7px;height:7px;left:0;background-color:var(--oui-date-picker-background)}:host .oui-date-picker .label-container .label .quick-date-container{position:relative;padding:8px;min-height:4rem}:host .oui-date-picker .label-container .label .quick-date-container.active{background-color:var(--oui-date-picker-selected-date-display-background-color);outline:1px solid var(--oui-date-picker-selected-date-display-border-color)}:host .oui-date-picker .label-container .label .quick-date-container:hover{cursor:pointer;background-color:var(--oui-date-picker-selected-date-display-background-hover-color)}:host .oui-date-picker .label-container .fill{flex:1}:host .oui-date-picker .calendar-container{display:flex;flex-direction:column;flex:1;background-color:var(--oui-date-picker-calendar-background)}:host .oui-date-picker .calendar-container .calendar-table{border-spacing:0;border-collapse:collapse;width:100%}:host .oui-date-picker .calendar-container .calendar-table thead{display:table-header-group}:host .oui-date-picker .calendar-container .calendar-table thead th{vertical-align:center}:host .oui-date-picker .calendar-container .calendar-table thead th .header-inner-container{display:flex;justify-content:center;align-items:center}:host .oui-date-picker .calendar-container .calendar-table tbody{display:table-row-group}:host .oui-date-picker .calendar-container .calendar-table tbody td{vertical-align:center}:host .oui-date-picker .calendar-container .calendar-table tbody td .inner-option-container{display:flex;justify-content:center;align-items:center;min-width:4rem;height:4rem;padding:2px}:host .oui-date-picker .calendar-container .calendar-table tbody td .inner-option-container .innermost-option-container{border:1px solid transparent;box-sizing:border-box;flex:1 0 auto;display:flex;justify-content:center;align-items:center;height:100%}:host .oui-date-picker .calendar-container .calendar-table tbody td.muted{opacity:.7}:host .oui-date-picker .calendar-container .calendar-table tbody td.disabled{opacity:.3;pointer-events:none}:host .oui-date-picker .calendar-container .calendar-table tbody td.selected{background-color:var(--oui-date-picker-selected-date-background-color);color:var(--oui-date-picker-selected-date-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.start-date{background-color:var(--oui-date-picker-start-date-background-color);color:var(--oui-date-picker-start-date-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.start-date .inner-option-container{background-color:var(--oui-date-picker-start-date-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.start-date .inner-option-container .innermost-option-container{background-color:var(--oui-date-picker-start-date-inner-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.end-date{background-color:var(--oui-date-picker-end-date-background-color);color:var(--oui-date-picker-end-date-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.end-date .inner-option-container{background-color:var(--oui-date-picker-end-date-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td.end-date .inner-option-container .innermost-option-container{background-color:var(--oui-date-picker-end-date-inner-background-color)}:host .oui-date-picker .calendar-container .calendar-table tbody td:hover{cursor:pointer}:host .oui-date-picker .calendar-container .calendar-table tbody td:hover .inner-option-container .innermost-option-container{background-color:var(--oui-date-picker-calendar-background-hover);border:1px solid var(--oui-date-picker-calendar-background-border);box-shadow:var(--box-shadow-bottom-large)}:host .oui-date-picker .calendar-container .calendar-table tr{display:table-row}:host .oui-date-picker .calendar-container.from{border-radius:var(--border-radius-default)}:host .oui-date-picker .calendar-container.from .option:hover{background-color:var(--color-accent-secondary-lighter)}:host .oui-date-picker .calendar-container.from .option:hover .inner-option-container{background-color:var(--color-accent-secondary-lighter)}:host .oui-date-picker .calendar-container.from .option:hover .inner-option-container .innermost-option-container{background-color:var(--color-accent-secondary-lighter)}:host .oui-date-picker .calendar-container.to{border-radius:var(--border-radius-default)}:host .oui-date-picker .calendar-container.to .option:hover{background-color:var(--color-accent-lighter)}:host .oui-date-picker .calendar-container.to .option:hover .inner-option-container{background-color:var(--color-accent-lighter)}:host .oui-date-picker .calendar-container.to .option:hover .inner-option-container .innermost-option-container{background-color:var(--color-accent-lighter)}:host .oui-date-picker .calendar-container .calendar{flex:1;display:flex;flex-direction:column;padding:2px}:host .oui-date-picker .calendar-container .calendar .mode-selector{display:flex;justify-content:center;align-items:center;margin:1rem 0}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-current{display:flex;align-items:center;justify-content:center;flex:1;-webkit-user-select:none;user-select:none}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-current:hover{cursor:pointer}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-caret{flex:0;display:flex;align-items:center;justify-content:center;-webkit-user-select:none;user-select:none;border-radius:50%;transition:background-color .3s,border .3s;border:1px solid transparent}:host .oui-date-picker .calendar-container .calendar .mode-selector .mode-selector-caret:hover{border:1px solid var(--oui-date-picker-icons-border-color);background-color:var(--oui-date-picker-icons-hover-color);cursor:pointer}:host .oui-date-picker .calendar-container .calendar .day-label-row{display:flex;align-items:center}:host .oui-date-picker .calendar-container .calendar .day-label-row .date-picker-day-label{display:flex;align-items:center;justify-content:center;flex:1;color:var(--color-primary-text)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { dayTemplate: [{
                type: ViewChild,
                args: ['dayTemplate', { read: TemplateRef }]
            }], monthTemplate: [{
                type: ViewChild,
                args: ['monthTemplate', { read: TemplateRef }]
            }], yearTemplate: [{
                type: ViewChild,
                args: ['yearTemplate', { read: TemplateRef }]
            }], presetsTemplate: [{
                type: Input
            }], options: [{
                type: Input
            }] } });

class OuiDateRangePickerDropdownComponent {
    cdr;
    /**
     *   The first selected date of the date-range
     */
    dateFrom = model.required();
    /**
     *   The second selected date of the date-range
     */
    dateTo = model.required();
    /**
     * A template consisting of presets you can pass to the calendar
     */
    presetsTemplate;
    /**
     * Options to be passed to the datepicker
     */
    options = {
        datePickerOptions: {},
    };
    translations = DEFAULT_TRANSLATIONS;
    constructor(cdr) {
        this.cdr = cdr;
    }
    onDateFromChange(date) {
        this.dateFrom.set(date);
    }
    onDateToChange(date) {
        this.dateTo.set(date);
    }
    ngOnChanges(changes) {
        if ('options' in changes) {
            this.options = changes.options.currentValue;
            this.translations =
                changes.options.currentValue.datePickerOptions.translations ??
                    this.translations;
            this.cdr.detectChanges();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDateRangePickerDropdownComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "17.3.1", type: OuiDateRangePickerDropdownComponent, isStandalone: true, selector: "oui-date-range-picker-dropdown", inputs: { dateFrom: { classPropertyName: "dateFrom", publicName: "dateFrom", isSignal: true, isRequired: true, transformFunction: null }, dateTo: { classPropertyName: "dateTo", publicName: "dateTo", isSignal: true, isRequired: true, transformFunction: null }, presetsTemplate: { classPropertyName: "presetsTemplate", publicName: "presetsTemplate", isSignal: false, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: false, isRequired: false, transformFunction: null } }, outputs: { dateFrom: "dateFromChange", dateTo: "dateToChange" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"oui-date-picker-dropdown-container\">\n  <oui-dropdown [toggle]=\"toggle\" [content]=\"content\">\n    <ng-template #toggle>\n      <div class=\"date-picker-toggle-container\">\n        <div class=\"date-picker-toggle-icon\">\n          <oui-icon\n            [options]=\"{\n              size: '18px',\n              fillColor: 'oui-date-picker-icons-color',\n              strokeColor: 'oui-date-picker-icons-color'\n            }\"\n            icon=\"assets/icons/calendar.svg\"\n          >\n          </oui-icon>\n        </div>\n        <div class=\"date-picker-date from\">\n          {{ dateFrom() | quickDate: translations }}\n        </div>\n        <div class=\"date-picker-divider-icon\">\n          <oui-icon\n            [options]=\"{\n              strokeColor: 'oui-date-picker-icons-color',\n              fillColor: 'oui-date-picker-icons-color',\n              viewBox: '0 0 16 11',\n              width: '18px',\n              height: '12px'\n            }\"\n            icon=\"assets/icons/arrow_long_right.svg\"\n          >\n          </oui-icon>\n        </div>\n        <div class=\"date-picker-date to\">\n          {{ dateTo() | quickDate: translations }}\n        </div>\n      </div>\n    </ng-template>\n    <ng-template #content>\n      <div\n        class=\"date-picker-content-container {{\n          options.dropdownOptions?.className ?? ''\n        }}\"\n      >\n        <oui-date-range-picker\n          [presetsTemplate]=\"presetsTemplate\"\n          [options]=\"options.datePickerOptions\"\n          (dateFromChange)=\"onDateFromChange($event)\"\n          (dateToChange)=\"onDateToChange($event)\"\n          [dateTo]=\"dateTo()\"\n          [dateFrom]=\"dateFrom()\"\n        ></oui-date-range-picker>\n      </div>\n    </ng-template>\n  </oui-dropdown>\n</div>\n", styles: [":host{height:100%;position:relative;display:flex;width:100%;border-radius:var(--oui-date-picker-toggle-border-radius);border-width:var(--oui-date-picker-toggle-border-width);border-style:var(--oui-date-picker-toggle-border-style);border-color:var(--oui-date-picker-toggle-border-color)}:host .oui-date-picker-dropdown-container{height:100%;border-radius:var(--oui-date-picker-toggle-border-radius);color:var(--oui-date-picker-toggle-primary-text);transition:background-color .3s;width:100%}:host .oui-date-picker-dropdown-container:hover{background-color:var(--oui-date-picker-toggle-background-hover)}:host .oui-date-picker-dropdown-container .date-picker-toggle-container{border-radius:var(--oui-date-picker-toggle-border-radius);display:flex;align-items:center;justify-content:space-between;font-size:16px;box-shadow:var(--oui-date-picker-toggle-box-shadow);padding:var(--oui-date-picker-dropdown-toggle-padding);background-color:var(--oui-date-picker-toggle-background);flex:1}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-toggle-icon{margin-right:8px}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-date{flex:0 1 40%;white-space:nowrap}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-date :hover{cursor:pointer}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-divider-icon{margin:0 12px}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "component", type: OuiDropdownComponent, selector: "oui-dropdown", inputs: ["disableCloseOnWindowResize", "content", "toggle", "isOpen", "disabled"], outputs: ["isOpenChange"] }, { kind: "component", type: OuiDateRangePickerComponent, selector: "oui-date-range-picker", inputs: ["dateFrom", "dateTo", "presetsTemplate", "options"], outputs: ["dateFromChange", "dateToChange"] }, { kind: "pipe", type: QuickDatePipe, name: "quickDate" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDateRangePickerDropdownComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-date-range-picker-dropdown', standalone: true, imports: [
                        OuiIconComponent,
                        OuiDropdownComponent,
                        OuiDateRangePickerComponent,
                        OuiRippleDirective,
                        QuickDatePipe,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"oui-date-picker-dropdown-container\">\n  <oui-dropdown [toggle]=\"toggle\" [content]=\"content\">\n    <ng-template #toggle>\n      <div class=\"date-picker-toggle-container\">\n        <div class=\"date-picker-toggle-icon\">\n          <oui-icon\n            [options]=\"{\n              size: '18px',\n              fillColor: 'oui-date-picker-icons-color',\n              strokeColor: 'oui-date-picker-icons-color'\n            }\"\n            icon=\"assets/icons/calendar.svg\"\n          >\n          </oui-icon>\n        </div>\n        <div class=\"date-picker-date from\">\n          {{ dateFrom() | quickDate: translations }}\n        </div>\n        <div class=\"date-picker-divider-icon\">\n          <oui-icon\n            [options]=\"{\n              strokeColor: 'oui-date-picker-icons-color',\n              fillColor: 'oui-date-picker-icons-color',\n              viewBox: '0 0 16 11',\n              width: '18px',\n              height: '12px'\n            }\"\n            icon=\"assets/icons/arrow_long_right.svg\"\n          >\n          </oui-icon>\n        </div>\n        <div class=\"date-picker-date to\">\n          {{ dateTo() | quickDate: translations }}\n        </div>\n      </div>\n    </ng-template>\n    <ng-template #content>\n      <div\n        class=\"date-picker-content-container {{\n          options.dropdownOptions?.className ?? ''\n        }}\"\n      >\n        <oui-date-range-picker\n          [presetsTemplate]=\"presetsTemplate\"\n          [options]=\"options.datePickerOptions\"\n          (dateFromChange)=\"onDateFromChange($event)\"\n          (dateToChange)=\"onDateToChange($event)\"\n          [dateTo]=\"dateTo()\"\n          [dateFrom]=\"dateFrom()\"\n        ></oui-date-range-picker>\n      </div>\n    </ng-template>\n  </oui-dropdown>\n</div>\n", styles: [":host{height:100%;position:relative;display:flex;width:100%;border-radius:var(--oui-date-picker-toggle-border-radius);border-width:var(--oui-date-picker-toggle-border-width);border-style:var(--oui-date-picker-toggle-border-style);border-color:var(--oui-date-picker-toggle-border-color)}:host .oui-date-picker-dropdown-container{height:100%;border-radius:var(--oui-date-picker-toggle-border-radius);color:var(--oui-date-picker-toggle-primary-text);transition:background-color .3s;width:100%}:host .oui-date-picker-dropdown-container:hover{background-color:var(--oui-date-picker-toggle-background-hover)}:host .oui-date-picker-dropdown-container .date-picker-toggle-container{border-radius:var(--oui-date-picker-toggle-border-radius);display:flex;align-items:center;justify-content:space-between;font-size:16px;box-shadow:var(--oui-date-picker-toggle-box-shadow);padding:var(--oui-date-picker-dropdown-toggle-padding);background-color:var(--oui-date-picker-toggle-background);flex:1}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-toggle-icon{margin-right:8px}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-date{flex:0 1 40%;white-space:nowrap}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-date :hover{cursor:pointer}:host .oui-date-picker-dropdown-container .date-picker-toggle-container .date-picker-divider-icon{margin:0 12px}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { presetsTemplate: [{
                type: Input
            }], options: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiDatePickerComponent, OuiDatePickerDropdownComponent, OuiDateRangePickerComponent, OuiDateRangePickerDropdownComponent };
//# sourceMappingURL=orbital-ui-date-picker.mjs.map
