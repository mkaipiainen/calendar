/// <reference types="./global" />
import Supercluster from 'supercluster';
import { CompositeLayer } from '@deck.gl/core/typed';
import { CursorState, IDeckClusterLayerOptions, ISlimCommonDeckLayerOptions } from '../typings';
import { BaseDeckLayer } from '../base-deck-layer.component';
import * as i0 from "@angular/core";
export declare class DeckClusterLayerComponent extends BaseDeckLayer<ISlimCommonDeckLayerOptions> {
    isHovering: boolean;
    options: IDeckClusterLayerOptions;
    constructor();
    getCursor(state: CursorState): string;
    getLayer(): IconClusterLayer;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeckClusterLayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeckClusterLayerComponent, "oui-deck-cluster-layer", never, { "options": { "alias": "options"; "required": true; }; }, {}, never, never, true, never>;
}
declare class IconClusterLayer extends CompositeLayer<any> {
    private options;
    supercluster: Supercluster;
    constructor(props: any);
    shouldUpdateState({ changeFlags }: any): any;
    updateState({ props, oldProps, changeFlags }: any): void;
    renderLayers(): any[];
}
export {};
//# sourceMappingURL=deck-cluster-layer.d.ts.map