/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/carousel" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-carousel.d.ts.map