import { ElementRef, OnInit } from '@angular/core';
import * as i0 from "@angular/core";
export declare class AutofocusDirective implements OnInit {
    private host;
    isAutofocusEnabled: import("@angular/core").InputSignal<boolean>;
    constructor(host: ElementRef);
    ngOnInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AutofocusDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AutofocusDirective, "[ouiAutofocus]", never, { "isAutofocusEnabled": { "alias": "isAutofocusEnabled"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=autofocus.directive.d.ts.map