import { ICommonDeckLayerOptions, IDeckGeolocateLayerOptions } from '../typings';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { CompositeLayer, Layer, LayersList } from '@deck.gl/core/typed';
import * as i0 from "@angular/core";
type ILocation = [number, number];
type IAccuracy = {
    position: [number, number];
    radius: number;
};
type IPingState = {
    isInProgress: boolean;
    isDone: boolean;
};
type IGeolocateLayerOptions = {
    options: IDeckGeolocateLayerOptions;
    location: ILocation;
    accuracy: IAccuracy;
    pingState: IPingState;
    heading: number | null;
};
export declare class DeckGeolocateLayer extends BaseDeckLayer<ICommonDeckLayerOptions> {
    options: IDeckGeolocateLayerOptions;
    private isGeolocateStarted;
    private location;
    private accuracy;
    private heading;
    private pingState;
    private interval;
    constructor();
    private onGeolocateEvent;
    locateUser(): void;
    getLayer(): GeolocateLayer;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeckGeolocateLayer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeckGeolocateLayer, "oui-deck-geolocate-layer", never, { "options": { "alias": "options"; "required": true; }; }, {}, never, never, true, never>;
}
declare class GeolocateLayer extends CompositeLayer<any> {
    private options;
    private location;
    private accuracy;
    private heading;
    private pingState;
    constructor(props: IGeolocateLayerOptions);
    shouldUpdateState({ changeFlags }: any): any;
    renderLayers(): Layer | LayersList | null;
}
export {};
//# sourceMappingURL=deck-geolocate-layer.d.ts.map