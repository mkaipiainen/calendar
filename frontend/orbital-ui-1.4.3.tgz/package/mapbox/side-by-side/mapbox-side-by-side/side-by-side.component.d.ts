import { AfterViewInit, ChangeDetectorRef, DestroyRef, EventEmitter, OnChanges, OnDestroy, Renderer2, SimpleChanges, TemplateRef } from '@angular/core';
import { OuiMapboxComponent } from '../../mapbox.component';
import * as i0 from "@angular/core";
export interface ISideBySideOptions {
    orientation?: 'vertical' | 'horizontal';
}
/**
 * Component to display two maps side-by-side with a comparison slider
 * Requires the maps inside the parent container to have position absolute, and full width + height.
 */
export declare class MapboxSideBySideComponent implements AfterViewInit, OnDestroy, OnChanges {
    #private;
    private renderer;
    private document;
    private destroyRef;
    private cdr;
    private defaultOptions;
    private usedOptions;
    private currentDragPosition;
    private isDragging;
    private offsetAtDragStart;
    private resizeObserver;
    private dragLeftRatio;
    private isInitialisationStarted;
    isVertical: boolean;
    leftMap: OuiMapboxComponent;
    rightMap: OuiMapboxComponent;
    mapContainer: HTMLDivElement;
    options: ISideBySideOptions;
    leftLabelTemplate: TemplateRef<any>;
    rightLabelTemplate: TemplateRef<any>;
    dragged: EventEmitter<any>;
    clicked: EventEmitter<any>;
    released: EventEmitter<any>;
    private dragContainer;
    private drag;
    private imageLabelRight;
    private imageLabelLeft;
    private unlisteners;
    isInitialised: boolean;
    constructor(renderer: Renderer2, document: Document, destroyRef: DestroyRef, cdr: ChangeDetectorRef);
    ngAfterViewInit(): void;
    private subscribeToMapLoad;
    private initialiseComponent;
    private initializeSideBySide;
    private calculateDragRatio;
    private getMapContainerWidth;
    private getMapContainerHeight;
    private getWidthMidpoint;
    private getHeightMidpoint;
    private getDragWidthOffset;
    private getDragHeightOffset;
    private getDragContainerWidthOffset;
    private getDragContainerHeightOffset;
    private setDragPositionAndClip;
    private setTransform;
    private getLeftMapClip;
    private getRightMapClip;
    private initializeEventListeners;
    private onMouseDown;
    private onMouseUp;
    private onMouseMove;
    private setLeftLabelPosition;
    private resizeSideBySide;
    private initializeResizeObserver;
    ngOnDestroy(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MapboxSideBySideComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MapboxSideBySideComponent, "mapbox-side-by-side", never, { "leftMap": { "alias": "leftMap"; "required": true; }; "rightMap": { "alias": "rightMap"; "required": true; }; "mapContainer": { "alias": "mapContainer"; "required": true; }; "options": { "alias": "options"; "required": false; }; "leftLabelTemplate": { "alias": "leftLabelTemplate"; "required": false; }; "rightLabelTemplate": { "alias": "rightLabelTemplate"; "required": false; }; }, { "dragged": "dragged"; "clicked": "clicked"; "released": "released"; }, never, ["*", "*"], true, never>;
}
//# sourceMappingURL=side-by-side.component.d.ts.map