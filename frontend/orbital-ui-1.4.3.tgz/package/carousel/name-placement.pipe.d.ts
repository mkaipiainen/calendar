import { PipeTransform } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Pipe to output either a caret up or down depending on value
 */
export declare class CarouselNamePlacementPipe implements PipeTransform {
    transform(placement: string): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<CarouselNamePlacementPipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<CarouselNamePlacementPipe, "carouselNamePlacement", true>;
}
//# sourceMappingURL=name-placement.pipe.d.ts.map