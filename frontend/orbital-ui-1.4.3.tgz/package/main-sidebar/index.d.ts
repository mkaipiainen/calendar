/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/main-sidebar" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-main-sidebar.d.ts.map