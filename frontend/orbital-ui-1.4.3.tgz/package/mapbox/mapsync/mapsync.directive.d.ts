import { AfterViewInit, OnDestroy, OnInit } from '@angular/core';
import { OuiMapSyncService } from './mapsync.service';
import { OuiMapboxComponent } from '../mapbox.component';
import * as i0 from "@angular/core";
export declare class OuiMapSyncDirective implements OnInit, AfterViewInit, OnDestroy {
    private mapSyncService;
    private map;
    /** simple directive that syncs the maps with the given group */
    mapSyncGroup: string;
    constructor(mapSyncService: OuiMapSyncService, map: OuiMapboxComponent);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiMapSyncDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OuiMapSyncDirective, "[oui-map-sync]", never, { "mapSyncGroup": { "alias": "mapSyncGroup"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=mapsync.directive.d.ts.map