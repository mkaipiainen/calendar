import { OuiDraggableDirective } from './draggable.directive';
import { BehaviorBase } from './behavior-default';
export interface IInertiaBehaviorOptions {
    inertia?: number;
    velocityMultiplier?: number;
}
export interface ISnapBehaviorOptions {
    groupId: string;
}
export declare class InertiaBehavior extends BehaviorBase {
    private options?;
    private previousTimeStamp;
    private lastVelocities;
    private isDragging;
    constructor(draggable: OuiDraggableDirective, options?: IInertiaBehaviorOptions | undefined);
    onDragStart(event: MouseEvent | TouchEvent): void;
    onDragEnd(event: MouseEvent | TouchEvent): void;
    private fireInertiaMovement;
    private calculateVelocity;
    cleanUp(): void;
}
//# sourceMappingURL=behavior-inertia.d.ts.map