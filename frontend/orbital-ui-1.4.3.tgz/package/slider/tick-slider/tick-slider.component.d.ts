import { AfterViewInit, DestroyRef, ElementRef, EventEmitter, QueryList, TemplateRef } from '@angular/core';
import { OuiDraggableDirective } from 'orbital-ui/draggable';
import { IOuiIconOptions, OuiIconComponent } from 'orbital-ui/icon';
import { IOuiDragMove } from 'orbital-ui/draggable';
import * as i0 from "@angular/core";
export type Tick = {
    value: any;
    label: string;
    index: number;
};
export type OuiTickSliderOptions = Partial<OuiTickSliderCombinedOptions> & {
    ticks: Tick[];
};
type OuiTickSliderCombinedOptions = {
    ticks: Tick[];
    areTicksClickable?: boolean;
    compareBy: (currentValue: any, b: Tick) => boolean;
    alignment: 'horizontal' | 'vertical';
    tickLabelTemplate?: TemplateRef<any>;
    thumbContentTemplate?: TemplateRef<any>;
    thumbToContentTemplate?: TemplateRef<any>;
    iconBetweenTicks?: {
        fromIndex: number;
        toIndex: number;
        icon: string;
        iconOptions: IOuiIconOptions;
    };
};
export declare class OuiTickSliderComponent implements AfterViewInit {
    private document;
    private destroyRef;
    sliderBar: ElementRef;
    fill: ElementRef;
    thumbFromContainer: ElementRef;
    thumbFromDraggable: OuiDraggableDirective;
    thumbToContainer: ElementRef;
    thumbToDraggable: OuiDraggableDirective;
    iconBetweenTicks: OuiIconComponent;
    tickContainer: ElementRef;
    ticks: QueryList<ElementRef>;
    options: import("@angular/core").InputSignal<OuiTickSliderOptions>;
    combinedOptions: import("@angular/core").Signal<{
        ticks: Tick[];
        areTicksClickable?: boolean | undefined;
        compareBy: (currentValue: any, b: Tick) => boolean;
        alignment: "horizontal" | "vertical";
        tickLabelTemplate?: TemplateRef<any> | undefined;
        thumbContentTemplate?: TemplateRef<any> | undefined;
        thumbToContentTemplate?: TemplateRef<any> | undefined;
        iconBetweenTicks?: {
            fromIndex: number;
            toIndex: number;
            icon: string;
            iconOptions: IOuiIconOptions;
        } | undefined;
    } & {
        ticks: Tick[];
        areTicksClickable?: boolean | undefined;
        compareBy?: ((currentValue: any, b: Tick) => boolean) | undefined;
        alignment?: "horizontal" | "vertical" | undefined;
        tickLabelTemplate?: TemplateRef<any> | undefined;
        thumbContentTemplate?: TemplateRef<any> | undefined;
        thumbToContentTemplate?: TemplateRef<any> | undefined;
        iconBetweenTicks?: {
            fromIndex: number;
            toIndex: number;
            icon: string;
            iconOptions: IOuiIconOptions;
        } | undefined;
    }>;
    /**
     * The model for 'smaller' value. Use this alone if you want just a single-thumb mode.
     */
    value: import("@angular/core").ModelSignal<any>;
    /**
     * The model for the 'larger' value. Can be only used together with value-input
     */
    valueTo: import("@angular/core").ModelSignal<any>;
    debouncedValueToChange: EventEmitter<any>;
    debouncedValueChange: EventEmitter<any>;
    private previousXPosition;
    private readonly defaultOptions;
    private resizeObserver;
    private _debouncedValueToChange;
    private _debouncedValueChange;
    private indexFrom;
    private indexTo;
    tickFrom: import("@angular/core").Signal<Tick>;
    tickTo: import("@angular/core").Signal<Tick>;
    id: string;
    activeTicks: Set<Tick>;
    constructor(document: Document, destroyRef: DestroyRef);
    onDragMove(type: 'from' | 'to', event: IOuiDragMove): void;
    private updateActiveTicks;
    private updateBarFill;
    private updateBarFillHorizontal;
    private getIndex;
    onTickClick(tick: Tick): void;
    private updateBarFillVertical;
    ngAfterViewInit(): void;
    private initThumbToDraggable;
    private getTickIndex;
    private initResizeObserver;
    private positionTicks;
    private reSnapDraggables;
    private positionIconBetweenTicks;
    trackByValue(index: number, item: Tick): any;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiTickSliderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiTickSliderComponent, "oui-tick-slider", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; "value": { "alias": "value"; "required": true; "isSignal": true; }; "valueTo": { "alias": "valueTo"; "required": false; "isSignal": true; }; }, { "value": "valueChange"; "valueTo": "valueToChange"; "debouncedValueToChange": "debouncedValueToChange"; "debouncedValueChange": "debouncedValueChange"; }, never, never, true, never>;
}
export {};
//# sourceMappingURL=tick-slider.component.d.ts.map