/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/tabs" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-tabs.d.ts.map