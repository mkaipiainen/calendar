import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "orbital-ui/routing";
/**
 * Service used to control dropdowns in the application. Tracks all dropdowns, and has a public method to close all dropdowns.
 */
// TODO: Add a method to close a single dropdown
export class OuiDropdownService {
    ouiRoutingService;
    dropdowns = [];
    constructor(ouiRoutingService) {
        this.ouiRoutingService = ouiRoutingService;
        this.ouiRoutingService.navigationStart$.subscribe(event => {
            if (event.previousUrl !== event.currentUrl) {
                this.closeAll();
            }
        });
    }
    register(dropdown) {
        this.dropdowns.push(dropdown);
    }
    closeAll() {
        for (const dropdown of this.dropdowns) {
            dropdown.close();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDropdownService, deps: [{ token: i1.OuiRoutingService }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDropdownService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDropdownService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.OuiRoutingService }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHJvcGRvd24uc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvZHJvcGRvd24vZHJvcGRvd24uc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDOzs7QUFLM0M7O0dBRUc7QUFDSCxnREFBZ0Q7QUFJaEQsTUFBTSxPQUFPLGtCQUFrQjtJQUdUO0lBRmIsU0FBUyxHQUEyQixFQUFFLENBQUM7SUFFOUMsWUFBb0IsaUJBQW9DO1FBQXBDLHNCQUFpQixHQUFqQixpQkFBaUIsQ0FBbUI7UUFDdEQsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBRTtZQUN4RCxJQUFJLEtBQUssQ0FBQyxXQUFXLEtBQUssS0FBSyxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUMzQyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDbEIsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLFFBQVEsQ0FBQyxRQUE4QjtRQUM1QyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBRU0sUUFBUTtRQUNiLEtBQUssTUFBTSxRQUFRLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ3RDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNuQixDQUFDO0lBQ0gsQ0FBQzt1R0FuQlUsa0JBQWtCOzJHQUFsQixrQkFBa0IsY0FGakIsTUFBTTs7MkZBRVAsa0JBQWtCO2tCQUg5QixVQUFVO21CQUFDO29CQUNWLFVBQVUsRUFBRSxNQUFNO2lCQUNuQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE91aURyb3Bkb3duQ29tcG9uZW50IH0gZnJvbSAnLi9kcm9wZG93bi5jb21wb25lbnQnO1xuaW1wb3J0IHsgTmF2aWdhdGlvblN0YXJ0LCBSb3V0ZXIgfSBmcm9tICdAYW5ndWxhci9yb3V0ZXInO1xuaW1wb3J0IHsgT3VpUm91dGluZ1NlcnZpY2UgfSBmcm9tICdvcmJpdGFsLXVpL3JvdXRpbmcnO1xuXG4vKipcbiAqIFNlcnZpY2UgdXNlZCB0byBjb250cm9sIGRyb3Bkb3ducyBpbiB0aGUgYXBwbGljYXRpb24uIFRyYWNrcyBhbGwgZHJvcGRvd25zLCBhbmQgaGFzIGEgcHVibGljIG1ldGhvZCB0byBjbG9zZSBhbGwgZHJvcGRvd25zLlxuICovXG4vLyBUT0RPOiBBZGQgYSBtZXRob2QgdG8gY2xvc2UgYSBzaW5nbGUgZHJvcGRvd25cbkBJbmplY3RhYmxlKHtcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlEcm9wZG93blNlcnZpY2Uge1xuICBwdWJsaWMgZHJvcGRvd25zOiBPdWlEcm9wZG93bkNvbXBvbmVudFtdID0gW107XG5cbiAgY29uc3RydWN0b3IocHJpdmF0ZSBvdWlSb3V0aW5nU2VydmljZTogT3VpUm91dGluZ1NlcnZpY2UpIHtcbiAgICB0aGlzLm91aVJvdXRpbmdTZXJ2aWNlLm5hdmlnYXRpb25TdGFydCQuc3Vic2NyaWJlKGV2ZW50ID0+IHtcbiAgICAgIGlmIChldmVudC5wcmV2aW91c1VybCAhPT0gZXZlbnQuY3VycmVudFVybCkge1xuICAgICAgICB0aGlzLmNsb3NlQWxsKCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgcmVnaXN0ZXIoZHJvcGRvd246IE91aURyb3Bkb3duQ29tcG9uZW50KSB7XG4gICAgdGhpcy5kcm9wZG93bnMucHVzaChkcm9wZG93bik7XG4gIH1cblxuICBwdWJsaWMgY2xvc2VBbGwoKSB7XG4gICAgZm9yIChjb25zdCBkcm9wZG93biBvZiB0aGlzLmRyb3Bkb3ducykge1xuICAgICAgZHJvcGRvd24uY2xvc2UoKTtcbiAgICB9XG4gIH1cbn1cbiJdfQ==