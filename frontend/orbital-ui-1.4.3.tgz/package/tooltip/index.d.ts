/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/tooltip" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-tooltip.d.ts.map