import * as i0 from '@angular/core';
import { Injectable, Inject, inject, Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { fromEvent, Subject } from 'rxjs';
import * as i1 from '@angular/router';
import { NavigationStart } from '@angular/router';
import { DOCUMENT } from '@angular/common';
import { GUID, ComponentCreator } from 'orbital-ui/helpers';
import { OuiButtonComponent } from 'orbital-ui/button';

/**
 * This service can be used to open dialogs. You can pass in a custom dialog, which will be inserted
 * into the DOM and opened. You can call dialogService.submitDialog or dialogService.cancelDialog to easily close or open the dialog.
 * Alternatively, you can pass the option closeOnEscape to automatically close the dialog when the escape key is pressed.
 *
 * When creating new components, the workflow is as follows:
 *  - Create a component extended from OuiDialogComponent
 *  - Open the component using the openDialog() method
 *  - The openDialog returns an observable you can subscribe to in order to get the result of the dialog
 *
 *
 * Example:
 *
 * ouiDialogService.openDialog(StConfirmDialogComponent, {title: 'This is an example title'}, {closeOnEscape: true}).subscribe((result) => {
 *   if(result.confirm) {
 *     // User confirmed the dialog, do something
 *   } else {
 *     // User canceled the dialog, do something else
 *   }
 * });
 */
class OuiDialogService {
    router;
    zone;
    appRef;
    injector;
    rendererFactory;
    document;
    overlay;
    wrapper;
    openDialogs = {};
    renderer;
    constructor(router, zone, appRef, injector, rendererFactory, document) {
        this.router = router;
        this.zone = zone;
        this.appRef = appRef;
        this.injector = injector;
        this.rendererFactory = rendererFactory;
        this.document = document;
        this.renderer = rendererFactory.createRenderer(null, null);
        this.wrapper = this.renderer.createElement('div');
        this.overlay = this.renderer.createElement('div');
        this.renderer.addClass(this.wrapper, 'oui-dialog-wrapper');
        this.renderer.addClass(this.wrapper, 'hide');
        this.renderer.addClass(this.overlay, 'oui-dialog-overlay');
        this.renderer.appendChild(this.wrapper, this.overlay);
        this.renderer.appendChild(this.document.body, this.wrapper);
        fromEvent(this.overlay, 'click').subscribe((event) => {
            for (let dialog of Object.values(this.openDialogs)) {
                if (dialog.options.closeOnOutsideClick) {
                    this.cancelDialog(dialog.id, {});
                }
            }
        });
        this.router.events.subscribe(val => {
            if (val instanceof NavigationStart) {
                this.destroyDialogs();
            }
        });
        fromEvent(this.document, 'keyup').subscribe((event) => {
            if (event.key === 'Escape') {
                this.onEscapePress();
            }
        });
    }
    onEscapePress() {
        for (const id in this.openDialogs) {
            if (this.openDialogs[id].options.closeOnEscape) {
                this.cancelDialog(id, {});
            }
        }
    }
    destroyDialogs() {
        for (const id in this.openDialogs) {
            this.doDispose(id);
        }
    }
    /**
     * Opens a dialog with the given content and options. The content can be any component, which will be inserted into the DOM.
     * @param content The component to be used for the dialog
     * @param inputs A javascript object of inputs to be passed to the component
     * @param options Options for the dialog. See IDialogOptions for more information.
     */
    openDialog(content, inputs, options = {}) {
        const id = options.id ?? GUID();
        const subject = new Subject();
        const dialog = this.renderer.createElement('div');
        dialog.id = id;
        this.renderer.addClass(dialog, 'oui-dialog');
        if (options.classList?.length) {
            for (const className of options.classList) {
                this.renderer.addClass(dialog, className);
            }
        }
        const createComponentOptions = {
            component: content,
            parentElement: dialog,
            appRef: this.appRef,
            createComponentOptions: {
                environmentInjector: this.injector,
            },
            inputs: inputs,
        };
        const componentRef = ComponentCreator.createComponent(createComponentOptions);
        this.renderer.appendChild(this.wrapper, dialog);
        this.openDialogs[id] = {
            dialogElement: dialog,
            componentRef: componentRef,
            id: id,
            options: options,
            subject,
        };
        componentRef.instance.id = id;
        setTimeout(() => {
            this.renderer.removeClass(this.wrapper, 'hide');
            this.renderer.addClass(dialog, 'open');
            setTimeout(() => {
                this.renderer.addClass(this.wrapper, 'open');
                this.renderer.addClass(dialog, 'open');
            }, 50);
        });
        return subject.asObservable();
    }
    submitDialog(id, data) {
        if (this.openDialogs[id]) {
            this.openDialogs[id].subject.next({
                confirm: true,
                data: data ?? {},
            });
            this.dispose(id);
        }
    }
    cancelDialog(id, data) {
        if (this.openDialogs[id]) {
            this.openDialogs[id].subject.next({
                confirm: false,
                data: data ?? {},
            });
            this.dispose(id);
        }
    }
    dispose(id) {
        if (this.openDialogs?.[id]) {
            this.doDispose(id);
        }
    }
    doDispose(id) {
        this.renderer.removeClass(this.openDialogs[id].dialogElement, 'open');
        const componentRef = this.openDialogs[id].componentRef;
        this.openDialogs[id].subject.complete();
        delete this.openDialogs[id];
        if (Object.keys(this.openDialogs).length === 0) {
            this.renderer.removeClass(this.wrapper, 'open');
            setTimeout(() => {
                this.renderer.addClass(this.wrapper, 'hide');
            }, 300);
        }
        setTimeout(() => {
            componentRef.destroy();
            this.appRef.detachView(componentRef.hostView);
        }, 300);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDialogService, deps: [{ token: i1.Router }, { token: i0.NgZone }, { token: i0.ApplicationRef }, { token: i0.EnvironmentInjector }, { token: i0.RendererFactory2 }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDialogService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDialogService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.Router }, { type: i0.NgZone }, { type: i0.ApplicationRef }, { type: i0.EnvironmentInjector }, { type: i0.RendererFactory2 }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }] });

// This component should not be used directly, but instead extended in each dialog component.
/**
 * A parent-component for dialogs. Not meant to be used directly, only inherited.
 */
class OuiDialogComponent {
    ouiDialogService = inject(OuiDialogService);
    id;
    constructor() { }
    submit(data) {
        this.ouiDialogService.submitDialog(this.id, data);
    }
    cancel(data) {
        this.ouiDialogService.cancelDialog(this.id, data);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiDialogComponent, isStandalone: true, selector: "oui-dialog", ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDialogComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-dialog',
                    template: '',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [] });

/**
 * Represents a confirmation dialog component that extends OuiDialogComponent.
 * Displays a dialog box with a message asking the user to confirm or cancel an action.
 *
 */
class OuiConfirmDialogComponent extends OuiDialogComponent {
    /**
     * The title of the confirmation dialog. Default is 'Are you sure?'.
     */
    title = 'Are you sure?';
    /**
     * The message to display in the confirmation dialog. Default is 'Please either confirm or cancel.'.
     */
    content = 'Please either confirm or cancel.';
    /**
     * The label for the submit button. Default is 'Submit'.
     */
    submitLabel = 'Submit';
    /**
     * The label for the cancel button. Default is 'Cancel'.
     */
    cancelLabel = 'Cancel';
    /**
     * The variant of the submit button
     */
    submitVariant = 'primary';
    /**
     * The variant of the cancel button
     */
    cancelVariant = 'muted';
    constructor() {
        super();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiConfirmDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiConfirmDialogComponent, isStandalone: true, selector: "oui-confirm-dialog", inputs: { title: "title", content: "content", submitLabel: "submitLabel", cancelLabel: "cancelLabel", submitVariant: "submitVariant", cancelVariant: "cancelVariant" }, usesInheritance: true, ngImport: i0, template: "<div class=\"confirm-dialog\">\n  <div class=\"confirm-dialog-inner\">\n    <div class=\"dialog-head\" [innerHTML]=\"title\"></div>\n    <div class=\"dialog-content\" [innerHTML]=\"content\"></div>\n    <div class=\"dialog-actions\">\n      <oui-button\n        class=\"cancel-button\"\n        [options]=\"{\n          variant: cancelVariant\n        }\"\n        (onClick)=\"cancel()\"\n        >{{ cancelLabel }}</oui-button\n      >\n      <oui-button [options]=\"{variant: submitVariant}\" (onClick)=\"submit()\">{{\n        submitLabel\n      }}</oui-button>\n    </div>\n  </div>\n</div>\n", styles: [":host{min-width:35rem;min-height:20rem;width:35rem;height:20rem;display:flex;position:relative;border-radius:5px}:host .confirm-dialog{flex:1;display:flex;background-image:var(--oui-confirm-dialog-background-image);background-repeat:no-repeat;background-position:center;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover}:host .confirm-dialog .confirm-dialog-inner{flex:1;display:flex;flex-direction:column}:host .confirm-dialog .confirm-dialog-inner .dialog-head{border-bottom:1px solid var(--border-color-primary);background-color:var(--oui-confirm-dialog-title-background-color);color:var(--oui-confirm-dialog-title-text-color);padding:1rem;display:flex;align-items:center}:host .confirm-dialog .confirm-dialog-inner .dialog-content{flex:1;background-color:var(--oui-confirm-dialog-content-background-color);color:var(--oui-confirm-dialog-content-text-color);padding:1rem}:host .confirm-dialog .confirm-dialog-inner .dialog-actions{background-color:var(--oui-confirm-dialog-actions-background-color);padding:1rem;display:flex;justify-content:flex-end;align-items:center}:host .confirm-dialog .confirm-dialog-inner .dialog-actions .cancel-button{margin-right:1rem}:host .confirm-dialog .confirm-dialog-inner .dialog-actions oui-button{flex:0 1 auto;width:10rem;height:4rem}\n"], dependencies: [{ kind: "component", type: OuiButtonComponent, selector: "oui-button", inputs: ["options"], outputs: ["onClick"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiConfirmDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-confirm-dialog', standalone: true, imports: [OuiButtonComponent], template: "<div class=\"confirm-dialog\">\n  <div class=\"confirm-dialog-inner\">\n    <div class=\"dialog-head\" [innerHTML]=\"title\"></div>\n    <div class=\"dialog-content\" [innerHTML]=\"content\"></div>\n    <div class=\"dialog-actions\">\n      <oui-button\n        class=\"cancel-button\"\n        [options]=\"{\n          variant: cancelVariant\n        }\"\n        (onClick)=\"cancel()\"\n        >{{ cancelLabel }}</oui-button\n      >\n      <oui-button [options]=\"{variant: submitVariant}\" (onClick)=\"submit()\">{{\n        submitLabel\n      }}</oui-button>\n    </div>\n  </div>\n</div>\n", styles: [":host{min-width:35rem;min-height:20rem;width:35rem;height:20rem;display:flex;position:relative;border-radius:5px}:host .confirm-dialog{flex:1;display:flex;background-image:var(--oui-confirm-dialog-background-image);background-repeat:no-repeat;background-position:center;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover}:host .confirm-dialog .confirm-dialog-inner{flex:1;display:flex;flex-direction:column}:host .confirm-dialog .confirm-dialog-inner .dialog-head{border-bottom:1px solid var(--border-color-primary);background-color:var(--oui-confirm-dialog-title-background-color);color:var(--oui-confirm-dialog-title-text-color);padding:1rem;display:flex;align-items:center}:host .confirm-dialog .confirm-dialog-inner .dialog-content{flex:1;background-color:var(--oui-confirm-dialog-content-background-color);color:var(--oui-confirm-dialog-content-text-color);padding:1rem}:host .confirm-dialog .confirm-dialog-inner .dialog-actions{background-color:var(--oui-confirm-dialog-actions-background-color);padding:1rem;display:flex;justify-content:flex-end;align-items:center}:host .confirm-dialog .confirm-dialog-inner .dialog-actions .cancel-button{margin-right:1rem}:host .confirm-dialog .confirm-dialog-inner .dialog-actions oui-button{flex:0 1 auto;width:10rem;height:4rem}\n"] }]
        }], ctorParameters: () => [], propDecorators: { title: [{
                type: Input
            }], content: [{
                type: Input
            }], submitLabel: [{
                type: Input
            }], cancelLabel: [{
                type: Input
            }], submitVariant: [{
                type: Input
            }], cancelVariant: [{
                type: Input
            }] } });

/**
 * Represents a confirmation dialog component that extends OuiDialogComponent.
 * Displays a dialog box with a message asking the user to confirm or cancel an action.
 *
 */
class OuiSimpleDialogComponent extends OuiDialogComponent {
    /**
     * The message to display in the confirmation dialog. Default is 'Please either confirm or cancel.'.
     */
    content = 'Please either confirm or cancel.';
    /**
     * The label for the submit button. Default is 'Submit'.
     */
    submitLabel = 'Ok';
    /**
     * The variant of the submit button
     */
    submitVariant = 'primary';
    constructor() {
        super();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSimpleDialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiSimpleDialogComponent, isStandalone: true, selector: "oui-simple-dialog", inputs: { content: "content", submitLabel: "submitLabel", submitVariant: "submitVariant" }, usesInheritance: true, ngImport: i0, template: "<div class=\"confirm-dialog\">\n  <div class=\"confirm-dialog-inner\">\n    <div class=\"dialog-content\" [innerHTML]=\"content\"></div>\n    <div class=\"dialog-actions\">\n      <oui-button [options]=\"{variant: submitVariant}\" (onClick)=\"submit()\">{{\n        submitLabel\n      }}</oui-button>\n    </div>\n  </div>\n</div>\n", styles: [":host{width:35rem;display:flex;position:relative;border-radius:var(--border-radius-default)}:host .confirm-dialog{flex:1;display:flex;background-image:var(--oui-simple-dialog-background-image);background-repeat:no-repeat;background-position:center;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding:1rem;background-color:var(--oui-simple-dialog-background-color);color:var(--oui-simple-dialog-text-color)}:host .confirm-dialog .confirm-dialog-inner{flex:1;display:flex;flex-direction:column}:host .confirm-dialog .confirm-dialog-inner .dialog-content{flex:1;font-weight:var(--oui-simple-dialog-text-weight);display:flex;align-items:var(--oui-simple-dialog-text-vertical-alignment);text-align:var(--oui-simple-dialog-text-horizontal-alignment);padding:1rem}:host .confirm-dialog .confirm-dialog-inner .dialog-actions{padding:1rem;display:flex;justify-content:center;align-items:center}:host .confirm-dialog .confirm-dialog-inner .dialog-actions .cancel-button{margin-right:1rem}:host .confirm-dialog .confirm-dialog-inner .dialog-actions oui-button{flex:0 1 auto;width:10rem;height:4rem}\n"], dependencies: [{ kind: "component", type: OuiButtonComponent, selector: "oui-button", inputs: ["options"], outputs: ["onClick"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSimpleDialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-simple-dialog', standalone: true, imports: [OuiButtonComponent], template: "<div class=\"confirm-dialog\">\n  <div class=\"confirm-dialog-inner\">\n    <div class=\"dialog-content\" [innerHTML]=\"content\"></div>\n    <div class=\"dialog-actions\">\n      <oui-button [options]=\"{variant: submitVariant}\" (onClick)=\"submit()\">{{\n        submitLabel\n      }}</oui-button>\n    </div>\n  </div>\n</div>\n", styles: [":host{width:35rem;display:flex;position:relative;border-radius:var(--border-radius-default)}:host .confirm-dialog{flex:1;display:flex;background-image:var(--oui-simple-dialog-background-image);background-repeat:no-repeat;background-position:center;-webkit-background-size:cover;-moz-background-size:cover;-o-background-size:cover;background-size:cover;padding:1rem;background-color:var(--oui-simple-dialog-background-color);color:var(--oui-simple-dialog-text-color)}:host .confirm-dialog .confirm-dialog-inner{flex:1;display:flex;flex-direction:column}:host .confirm-dialog .confirm-dialog-inner .dialog-content{flex:1;font-weight:var(--oui-simple-dialog-text-weight);display:flex;align-items:var(--oui-simple-dialog-text-vertical-alignment);text-align:var(--oui-simple-dialog-text-horizontal-alignment);padding:1rem}:host .confirm-dialog .confirm-dialog-inner .dialog-actions{padding:1rem;display:flex;justify-content:center;align-items:center}:host .confirm-dialog .confirm-dialog-inner .dialog-actions .cancel-button{margin-right:1rem}:host .confirm-dialog .confirm-dialog-inner .dialog-actions oui-button{flex:0 1 auto;width:10rem;height:4rem}\n"] }]
        }], ctorParameters: () => [], propDecorators: { content: [{
                type: Input
            }], submitLabel: [{
                type: Input
            }], submitVariant: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiConfirmDialogComponent, OuiDialogComponent, OuiDialogService, OuiSimpleDialogComponent };
//# sourceMappingURL=orbital-ui-dialog.mjs.map
