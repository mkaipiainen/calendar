import { AfterViewInit, ChangeDetectorRef, OnChanges, OnInit, SimpleChanges, TemplateRef } from '@angular/core';
import { IDateLabelTranslations } from '../date-picker/date-picker.component';
import * as i0 from "@angular/core";
export interface IOuiDateRangePickerOptions {
    labels?: {
        endDate: string;
        startDate: string;
    };
    translations?: IDateLabelTranslations;
    getDateClass?: (date: Date, mode: 'day' | 'month' | 'year', selectingFor: 'from' | 'to') => string;
    getHoverClass?: (date: Date, mode: 'day' | 'month' | 'year', selectingFor: 'from' | 'to') => string;
}
export interface IOuiDateRangePickerCombinedOptions {
    labels: {
        endDate: string;
        startDate: string;
    };
    translations: IDateLabelTranslations;
    getDateClass: (date: Date, mode: 'day' | 'month' | 'year', selectingFor: 'from' | 'to') => string;
    getHoverClass: (date: Date, mode: 'day' | 'month' | 'year', selectingFor: 'from' | 'to') => string;
}
/**
 * A component for a date-range -picker. Enables to pick a from-date and a to-date.
 */
export declare class OuiDateRangePickerComponent implements OnInit, AfterViewInit, OnChanges {
    private cdr;
    dayTemplate: TemplateRef<any>;
    monthTemplate: TemplateRef<any>;
    yearTemplate: TemplateRef<any>;
    /**
     *   The first selected date of the date-range
     */
    dateFrom: import("@angular/core").ModelSignal<Date | undefined>;
    /**
     * The second selected date of the date-range
     */
    dateTo: import("@angular/core").ModelSignal<Date | undefined>;
    presetsTemplate: TemplateRef<any>;
    /**
     *  The options to pass to the calendar. getDateClass lets you assign custom classes to specific dates. The only input parameter
     *  to the function is a date, and the return value is the entire classname to be added to the date.
     *  getHoverClass works the same, except adds classes to specific dates when hovering over them.
     */
    options: IOuiDateRangePickerOptions;
    /**
     *   The event emitted when the dateFrom-value changes
     */
    private defaultOptions;
    combinedOptions: IOuiDateRangePickerCombinedOptions;
    dateSelectionOptions: Date[][];
    mode: 'year' | 'month' | 'day';
    selectingFor: 'from' | 'to';
    selectedCalendarDate: Date;
    currentTemplate: TemplateRef<any>;
    constructor(cdr: ChangeDetectorRef);
    ngOnInit(): void;
    ngAfterViewInit(): void;
    selectTo(): void;
    selectFrom(): void;
    private generateDateSelection;
    getOption(date: Date): number;
    selectDay(date: Date): void;
    selectMonth(date: Date): void;
    selectYear(date: Date): void;
    goBackParent(): void;
    changeModeSelection(): void;
    goForwardParent(): void;
    clearDateTo(): void;
    getDateClass(date: Date): string;
    onDateHover(date: Date, element: HTMLElement): void;
    onDateUnhover(date: Date, element: HTMLElement): void;
    private combineOptions;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiDateRangePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiDateRangePickerComponent, "oui-date-range-picker", never, { "dateFrom": { "alias": "dateFrom"; "required": true; "isSignal": true; }; "dateTo": { "alias": "dateTo"; "required": true; "isSignal": true; }; "presetsTemplate": { "alias": "presetsTemplate"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, { "dateFrom": "dateFromChange"; "dateTo": "dateToChange"; }, never, never, true, never>;
}
//# sourceMappingURL=date-range-picker.component.d.ts.map