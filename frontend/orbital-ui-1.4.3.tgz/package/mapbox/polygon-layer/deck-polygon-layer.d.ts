import { PolygonLayer } from '@deck.gl/layers/typed';
import { ICommonDeckLayerOptions, IDeckPolygonLayerOptions } from '../typings';
import { BaseDeckLayer } from '../base-deck-layer.component';
import * as i0 from "@angular/core";
export declare class DeckPolygonLayer extends BaseDeckLayer<ICommonDeckLayerOptions> {
    options: IDeckPolygonLayerOptions;
    constructor();
    getLayer(): PolygonLayer<any, {
        data: any[];
        stroked: boolean;
        filled: boolean;
        wireframe: boolean;
        lineWidthMinPixels: number;
        getFillColor: import("orbital-ui/core").RGBA | ((d: any) => import("orbital-ui/core").RGBA);
        getLineColor: import("orbital-ui/core").RGBA | ((d: any) => import("orbital-ui/core").RGBA);
        getLineWidth: number | ((d: any) => number);
        getElevation: number | ((d: any) => number);
        getPolygon: (x: any) => import("@turf/helpers").Position[] | import("@turf/helpers").Position[][];
        id: string;
        autoHighlight: boolean;
        transitions: {
            [x: string]: number | {
                duration: number;
                easing: any;
            };
        };
        highlightColor: import("orbital-ui/core").RGBA | ((d: any) => import("orbital-ui/core").RGBA);
        isEnabled: boolean;
        _dataDiff: (oldData: any, newData: any) => [{
            startRow: number;
            endRow: number;
        }];
        onClick: (object: any, event: any) => void;
        onHover: (event: any) => boolean;
        updateTriggers: any;
        dataComparator: (<LayerDataT = import("@deck.gl/core/typed").LayerData<unknown>>(newData: LayerDataT, oldData?: LayerDataT | undefined) => boolean) | null;
        getCursor: (data: {
            isHovering: boolean;
            isDragging: boolean;
        }) => string;
        order: number;
        loadOptions: any;
        visible: boolean;
        opacity: number;
        extensions: any[];
        pickable: boolean;
        getDashArray: [number, number];
        dashJustified: boolean;
        dashGapPickable: boolean;
        getOffset: number | (() => number);
        clipBounds: [number, number, number, number];
        maskId: string;
        maskByInstance: boolean;
        maskInverted: boolean;
        operation: "mask";
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeckPolygonLayer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeckPolygonLayer, "oui-deck-polygon-layer", never, { "options": { "alias": "options"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=deck-polygon-layer.d.ts.map