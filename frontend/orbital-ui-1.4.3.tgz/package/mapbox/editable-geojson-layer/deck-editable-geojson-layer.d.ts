import { EditableGeoJsonLayer } from '@nebula.gl/layers';
import { ICommonDeckLayerOptions, IDeckEditableGeoJsonLayerOptions } from '../typings';
import { ModifyMode } from '@nebula.gl/edit-modes';
import { ViewMode } from '@nebula.gl/edit-modes';
import { DrawPolygonMode } from '@nebula.gl/edit-modes';
import { MeasureDistanceMode } from '@nebula.gl/edit-modes';
import { DrawRectangleMode } from '@nebula.gl/edit-modes';
import { DrawPointMode } from '@nebula.gl/edit-modes';
import { DrawLineStringMode } from '@nebula.gl/edit-modes';
import { BaseDeckLayer } from '../base-deck-layer.component';
import * as i0 from "@angular/core";
export declare const EDITABLE_GEOJSON_LAYER_MODES: {
    MODIFY: typeof ModifyMode;
    VIEW: typeof ViewMode;
    DRAW: typeof DrawPolygonMode;
    MEASURE_DISTANCE: typeof MeasureDistanceMode;
    DRAW_RECTANGLE: typeof DrawRectangleMode;
    DRAW_POINT: typeof DrawPointMode;
    DRAW_LINESTRING: typeof DrawLineStringMode;
};
export declare class DeckEditableGeoJsonlayer extends BaseDeckLayer<ICommonDeckLayerOptions> {
    options: IDeckEditableGeoJsonLayerOptions;
    constructor();
    getLayer(): EditableGeoJsonLayer;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeckEditableGeoJsonlayer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeckEditableGeoJsonlayer, "oui-deck-editable-geojson-layer", never, { "options": { "alias": "options"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=deck-editable-geojson-layer.d.ts.map