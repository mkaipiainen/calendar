import * as i0 from '@angular/core';
import { EventEmitter, Directive, Output } from '@angular/core';
import { fromEvent } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

/**
 * Can be used to add a callback on any element that's triggered by hovering on the element
 *
 * @Output() hovered: EventEmitter<any>
 *   Triggered when hovering over the object
 *
 * @Output unhovered: EventEmitter<any>
 *   Triggered when unhovering object
 */
class OuiHoverDirective {
    elementRef;
    destroyRef;
    hovered = new EventEmitter();
    unhovered = new EventEmitter();
    constructor(elementRef, destroyRef) {
        this.elementRef = elementRef;
        this.destroyRef = destroyRef;
    }
    ngAfterViewInit() {
        fromEvent(this.elementRef.nativeElement, 'mouseenter')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            this.hovered.emit(event);
        });
        fromEvent(this.elementRef.nativeElement, 'touchenter')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            this.hovered.emit(event);
        });
        fromEvent(this.elementRef.nativeElement, 'mouseleave')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            this.unhovered.emit(event);
        });
        fromEvent(this.elementRef.nativeElement, 'touchleave')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            this.unhovered.emit(event);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiHoverDirective, deps: [{ token: i0.ElementRef }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.1", type: OuiHoverDirective, isStandalone: true, selector: "[ouiHover]", outputs: { hovered: "hovered", unhovered: "unhovered" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiHoverDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ouiHover]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.DestroyRef }], propDecorators: { hovered: [{
                type: Output
            }], unhovered: [{
                type: Output
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiHoverDirective };
//# sourceMappingURL=orbital-ui-hover.mjs.map
