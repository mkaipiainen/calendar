import { ChangeDetectionStrategy, Component, signal, ViewChild, ViewContainerRef, } from '@angular/core';
import { delay, filter } from 'rxjs';
import { OuiMainSidebarSubSectionComponent } from '../main-sidebar-sub-section/main-sidebar-sub-section.component';
import { CommonModule } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i0 from "@angular/core";
import * as i1 from "../main-sidebar.service";
import * as i2 from "@angular/common";
/**
 * A bit of a special-usecase component to be used in conjunction with the oui-main-sidebar and oui-main-sidebar-service.
 * This can be positioned anywhere in the application, and when a subSectionComponent on the main sidebar is clicked,
 * the dynamic content defined by that subsection gets injected here, and this component expands to the width/height of the dynamic content.
 * Right now only works properly horizontally. Not super well generalized, so will probably need some tweaking to get working.
 */
export class OuiMainSidebarExtensionComponent {
    ouiMainSidebarService;
    elementRef;
    cdr;
    destroyRef;
    content;
    isOpen = signal(false);
    innerComponentRef = null;
    constructor(ouiMainSidebarService, elementRef, cdr, destroyRef) {
        this.ouiMainSidebarService = ouiMainSidebarService;
        this.elementRef = elementRef;
        this.cdr = cdr;
        this.destroyRef = destroyRef;
    }
    ngAfterViewInit() {
        this.ouiMainSidebarService.extensionWidth$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(data => {
            if (this.innerComponentRef) {
                this.elementRef.nativeElement.style.width = data.width;
            }
        });
        this.ouiMainSidebarService.sectionClosed$
            .pipe(filter((section) => {
            return section instanceof OuiMainSidebarSubSectionComponent;
        }), takeUntilDestroyed(this.destroyRef))
            .subscribe(() => {
            this.close();
        });
        this.ouiMainSidebarService.openSubSection$
            .pipe(delay(1), takeUntilDestroyed(this.destroyRef))
            .subscribe((section) => {
            if (section) {
                if (this.innerComponentRef) {
                    this.innerComponentRef?.destroy();
                }
                this.elementRef.nativeElement.classList.add('open');
                this.elementRef.nativeElement.style.opacity = '1';
                this.isOpen.set(true);
                const component = section.options().component;
                this.innerComponentRef = this.content.createComponent(section.options().component);
                for (const input in section.options().inputs) {
                    this.innerComponentRef.instance[input] =
                        section.options().inputs[input];
                }
                // TODO: For now works, but if content takes longer to load this will break. Need to implement a way to signal when a content is loaded.
                setTimeout(() => {
                    if (this.innerComponentRef) {
                        // const innerWidth = getComputedStyle(this.innerComponentRef.location.nativeElement).width ?? (this.innerComponentRef.location.nativeElement.offsetWidth);
                        // this.elementRef.nativeElement.style.width = innerWidth;
                        // this.elementRef.nativeElement.style.transform = `scaleX(1)`;
                    }
                });
                this.cdr.detectChanges();
            }
            else {
                this.close();
            }
        });
    }
    close() {
        // this.elementRef.nativeElement.style.transform = 'scaleX(0)';
        this.elementRef.nativeElement.style.width = '0';
        this.elementRef.nativeElement.style.opacity = '0';
        this.isOpen.set(false);
        setTimeout(() => {
            if (!this.isOpen()) {
                this.elementRef.nativeElement.classList.remove('open');
                this.innerComponentRef?.destroy();
                this.innerComponentRef = null;
            }
        }, 300);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarExtensionComponent, deps: [{ token: i1.OuiMainSidebarService }, { token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiMainSidebarExtensionComponent, isStandalone: true, selector: "oui-main-sidebar-extension", viewQueries: [{ propertyName: "content", first: true, predicate: ["content"], descendants: true, read: ViewContainerRef }], ngImport: i0, template: "<div\n  class=\"oui-main-sidebar-extension-container\"\n  [ngClass]=\"{ 'is-open': isOpen() }\"\n>\n  <ng-container #content></ng-container>\n</div>\n", styles: [":host{transition:max-width 2s,width .3s,transform .3s,opacity .5s;overflow:hidden;position:absolute;top:0;left:0;height:100%;transform-origin:left;width:0;will-change:width}:host.open{margin-right:10px}:host .oui-main-sidebar-extension-container{flex:1;height:100%;padding:var(--oui-main-sidebar-extension-padding);background-color:var(--oui-main-sidebar-extension-background-color)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarExtensionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-main-sidebar-extension', standalone: true, imports: [OuiMainSidebarSubSectionComponent, CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"oui-main-sidebar-extension-container\"\n  [ngClass]=\"{ 'is-open': isOpen() }\"\n>\n  <ng-container #content></ng-container>\n</div>\n", styles: [":host{transition:max-width 2s,width .3s,transform .3s,opacity .5s;overflow:hidden;position:absolute;top:0;left:0;height:100%;transform-origin:left;width:0;will-change:width}:host.open{margin-right:10px}:host .oui-main-sidebar-extension-container{flex:1;height:100%;padding:var(--oui-main-sidebar-extension-padding);background-color:var(--oui-main-sidebar-extension-background-color)}\n"] }]
        }], ctorParameters: () => [{ type: i1.OuiMainSidebarService }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i0.DestroyRef }], propDecorators: { content: [{
                type: ViewChild,
                args: ['content', {
                        read: ViewContainerRef,
                    }]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFpbi1zaWRlYmFyLWV4dGVuc2lvbi5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL21haW4tc2lkZWJhci9tYWluLXNpZGViYXItZXh0ZW5zaW9uL21haW4tc2lkZWJhci1leHRlbnNpb24uY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9tYWluLXNpZGViYXIvbWFpbi1zaWRlYmFyLWV4dGVuc2lvbi9tYWluLXNpZGViYXItZXh0ZW5zaW9uLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFFTCx1QkFBdUIsRUFFdkIsU0FBUyxFQUlULE1BQU0sRUFDTixTQUFTLEVBQ1QsZ0JBQWdCLEdBQ2pCLE1BQU0sZUFBZSxDQUFDO0FBS3ZCLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQ3JDLE9BQU8sRUFBRSxpQ0FBaUMsRUFBRSxNQUFNLGdFQUFnRSxDQUFDO0FBQ25ILE9BQU8sRUFBRSxZQUFZLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUMvQyxPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQzs7OztBQUVoRTs7Ozs7R0FLRztBQVNILE1BQU0sT0FBTyxnQ0FBZ0M7SUFXakM7SUFDRDtJQUNDO0lBQ0E7SUFWVixPQUFPLENBQW1CO0lBRW5CLE1BQU0sR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7SUFFdkIsaUJBQWlCLEdBQTZCLElBQUksQ0FBQztJQUUxRCxZQUNVLHFCQUE0QyxFQUM3QyxVQUFzQixFQUNyQixHQUFzQixFQUN0QixVQUFzQjtRQUh0QiwwQkFBcUIsR0FBckIscUJBQXFCLENBQXVCO1FBQzdDLGVBQVUsR0FBVixVQUFVLENBQVk7UUFDckIsUUFBRyxHQUFILEdBQUcsQ0FBbUI7UUFDdEIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtJQUM3QixDQUFDO0lBRUcsZUFBZTtRQUNwQixJQUFJLENBQUMscUJBQXFCLENBQUMsZUFBZTthQUN2QyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ3pDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRTtZQUNoQixJQUFJLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO2dCQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7WUFDekQsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO1FBRUwsSUFBSSxDQUFDLHFCQUFxQixDQUFDLGNBQWM7YUFDdEMsSUFBSSxDQUNILE1BQU0sQ0FBQyxDQUFDLE9BQXVDLEVBQUUsRUFBRTtZQUNqRCxPQUFPLE9BQU8sWUFBWSxpQ0FBaUMsQ0FBQztRQUM5RCxDQUFDLENBQUMsRUFDRixrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQ3BDO2FBQ0EsU0FBUyxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztRQUNmLENBQUMsQ0FBQyxDQUFDO1FBRUwsSUFBSSxDQUFDLHFCQUFxQixDQUFDLGVBQWU7YUFDdkMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDbkQsU0FBUyxDQUFDLENBQUMsT0FBc0QsRUFBRSxFQUFFO1lBQ3BFLElBQUksT0FBTyxFQUFFLENBQUM7Z0JBQ1osSUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztvQkFDM0IsSUFBSSxDQUFDLGlCQUFpQixFQUFFLE9BQU8sRUFBRSxDQUFDO2dCQUNwQyxDQUFDO2dCQUVELElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3BELElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsR0FBRyxDQUFDO2dCQUNsRCxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDdEIsTUFBTSxTQUFTLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLFNBQVMsQ0FBQztnQkFDOUMsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUVuRCxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQy9CLEtBQUssTUFBTSxLQUFLLElBQUksT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLE1BQU0sRUFBRSxDQUFDO29CQUM3QyxJQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQzt3QkFDcEMsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDcEMsQ0FBQztnQkFFRCx3SUFBd0k7Z0JBQ3hJLFVBQVUsQ0FBQyxHQUFHLEVBQUU7b0JBQ2QsSUFBSSxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQzt3QkFDM0IsMkpBQTJKO3dCQUMzSiwwREFBMEQ7d0JBQzFELCtEQUErRDtvQkFDakUsQ0FBQztnQkFDSCxDQUFDLENBQUMsQ0FBQztnQkFDSCxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO1lBQzNCLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7WUFDZixDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDO0lBRU8sS0FBSztRQUNYLCtEQUErRDtRQUMvRCxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUNoRCxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQztRQUNsRCxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN2QixVQUFVLENBQUMsR0FBRyxFQUFFO1lBQ2QsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDO2dCQUNuQixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUN2RCxJQUFJLENBQUMsaUJBQWlCLEVBQUUsT0FBTyxFQUFFLENBQUM7Z0JBQ2xDLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUM7WUFDaEMsQ0FBQztRQUNILENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNWLENBQUM7dUdBcEZVLGdDQUFnQzsyRkFBaEMsZ0NBQWdDLHFLQUVuQyxnQkFBZ0IsNkJDckMxQix3SkFNQSwwYkQwQitDLFlBQVk7OzJGQUc5QyxnQ0FBZ0M7a0JBUjVDLFNBQVM7K0JBQ0UsNEJBQTRCLGNBRzFCLElBQUksV0FDUCxDQUFDLGlDQUFpQyxFQUFFLFlBQVksQ0FBQyxtQkFDekMsdUJBQXVCLENBQUMsTUFBTTs0S0FNL0MsT0FBTztzQkFITixTQUFTO3VCQUFDLFNBQVMsRUFBRTt3QkFDcEIsSUFBSSxFQUFFLGdCQUFnQjtxQkFDdkIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcbiAgQ2hhbmdlRGV0ZWN0b3JSZWYsXG4gIENvbXBvbmVudCxcbiAgQ29tcG9uZW50UmVmLFxuICBEZXN0cm95UmVmLFxuICBFbGVtZW50UmVmLFxuICBzaWduYWwsXG4gIFZpZXdDaGlsZCxcbiAgVmlld0NvbnRhaW5lclJlZixcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQge1xuICBPdWlNYWluU2lkZWJhclNlY3Rpb25Db21wb25lbnQsXG4gIE91aU1haW5TaWRlYmFyU2VydmljZSxcbn0gZnJvbSAnLi4vbWFpbi1zaWRlYmFyLnNlcnZpY2UnO1xuaW1wb3J0IHsgZGVsYXksIGZpbHRlciB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgT3VpTWFpblNpZGViYXJTdWJTZWN0aW9uQ29tcG9uZW50IH0gZnJvbSAnLi4vbWFpbi1zaWRlYmFyLXN1Yi1zZWN0aW9uL21haW4tc2lkZWJhci1zdWItc2VjdGlvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IHRha2VVbnRpbERlc3Ryb3llZCB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUvcnhqcy1pbnRlcm9wJztcblxuLyoqXG4gKiBBIGJpdCBvZiBhIHNwZWNpYWwtdXNlY2FzZSBjb21wb25lbnQgdG8gYmUgdXNlZCBpbiBjb25qdW5jdGlvbiB3aXRoIHRoZSBvdWktbWFpbi1zaWRlYmFyIGFuZCBvdWktbWFpbi1zaWRlYmFyLXNlcnZpY2UuXG4gKiBUaGlzIGNhbiBiZSBwb3NpdGlvbmVkIGFueXdoZXJlIGluIHRoZSBhcHBsaWNhdGlvbiwgYW5kIHdoZW4gYSBzdWJTZWN0aW9uQ29tcG9uZW50IG9uIHRoZSBtYWluIHNpZGViYXIgaXMgY2xpY2tlZCxcbiAqIHRoZSBkeW5hbWljIGNvbnRlbnQgZGVmaW5lZCBieSB0aGF0IHN1YnNlY3Rpb24gZ2V0cyBpbmplY3RlZCBoZXJlLCBhbmQgdGhpcyBjb21wb25lbnQgZXhwYW5kcyB0byB0aGUgd2lkdGgvaGVpZ2h0IG9mIHRoZSBkeW5hbWljIGNvbnRlbnQuXG4gKiBSaWdodCBub3cgb25seSB3b3JrcyBwcm9wZXJseSBob3Jpem9udGFsbHkuIE5vdCBzdXBlciB3ZWxsIGdlbmVyYWxpemVkLCBzbyB3aWxsIHByb2JhYmx5IG5lZWQgc29tZSB0d2Vha2luZyB0byBnZXQgd29ya2luZy5cbiAqL1xuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLW1haW4tc2lkZWJhci1leHRlbnNpb24nLFxuICB0ZW1wbGF0ZVVybDogJy4vbWFpbi1zaWRlYmFyLWV4dGVuc2lvbi5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL21haW4tc2lkZWJhci1leHRlbnNpb24uY29tcG9uZW50LnNjc3MnXSxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW091aU1haW5TaWRlYmFyU3ViU2VjdGlvbkNvbXBvbmVudCwgQ29tbW9uTW9kdWxlXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG59KVxuZXhwb3J0IGNsYXNzIE91aU1haW5TaWRlYmFyRXh0ZW5zaW9uQ29tcG9uZW50IGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCB7XG4gIEBWaWV3Q2hpbGQoJ2NvbnRlbnQnLCB7XG4gICAgcmVhZDogVmlld0NvbnRhaW5lclJlZixcbiAgfSlcbiAgY29udGVudDogVmlld0NvbnRhaW5lclJlZjtcblxuICBwdWJsaWMgaXNPcGVuID0gc2lnbmFsKGZhbHNlKTtcblxuICBwdWJsaWMgaW5uZXJDb21wb25lbnRSZWY6IENvbXBvbmVudFJlZjxhbnk+IHwgbnVsbCA9IG51bGw7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSBvdWlNYWluU2lkZWJhclNlcnZpY2U6IE91aU1haW5TaWRlYmFyU2VydmljZSxcbiAgICBwdWJsaWMgZWxlbWVudFJlZjogRWxlbWVudFJlZixcbiAgICBwcml2YXRlIGNkcjogQ2hhbmdlRGV0ZWN0b3JSZWYsXG4gICAgcHJpdmF0ZSBkZXN0cm95UmVmOiBEZXN0cm95UmVmXG4gICkge31cblxuICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCkge1xuICAgIHRoaXMub3VpTWFpblNpZGViYXJTZXJ2aWNlLmV4dGVuc2lvbldpZHRoJFxuICAgICAgLnBpcGUodGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZikpXG4gICAgICAuc3Vic2NyaWJlKGRhdGEgPT4ge1xuICAgICAgICBpZiAodGhpcy5pbm5lckNvbXBvbmVudFJlZikge1xuICAgICAgICAgIHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LnN0eWxlLndpZHRoID0gZGF0YS53aWR0aDtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICB0aGlzLm91aU1haW5TaWRlYmFyU2VydmljZS5zZWN0aW9uQ2xvc2VkJFxuICAgICAgLnBpcGUoXG4gICAgICAgIGZpbHRlcigoc2VjdGlvbjogT3VpTWFpblNpZGViYXJTZWN0aW9uQ29tcG9uZW50KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHNlY3Rpb24gaW5zdGFuY2VvZiBPdWlNYWluU2lkZWJhclN1YlNlY3Rpb25Db21wb25lbnQ7XG4gICAgICAgIH0pLFxuICAgICAgICB0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKVxuICAgICAgKVxuICAgICAgLnN1YnNjcmliZSgoKSA9PiB7XG4gICAgICAgIHRoaXMuY2xvc2UoKTtcbiAgICAgIH0pO1xuXG4gICAgdGhpcy5vdWlNYWluU2lkZWJhclNlcnZpY2Uub3BlblN1YlNlY3Rpb24kXG4gICAgICAucGlwZShkZWxheSgxKSwgdGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZikpXG4gICAgICAuc3Vic2NyaWJlKChzZWN0aW9uOiBPdWlNYWluU2lkZWJhclN1YlNlY3Rpb25Db21wb25lbnQgfCB1bmRlZmluZWQpID0+IHtcbiAgICAgICAgaWYgKHNlY3Rpb24pIHtcbiAgICAgICAgICBpZiAodGhpcy5pbm5lckNvbXBvbmVudFJlZikge1xuICAgICAgICAgICAgdGhpcy5pbm5lckNvbXBvbmVudFJlZj8uZGVzdHJveSgpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmNsYXNzTGlzdC5hZGQoJ29wZW4nKTtcbiAgICAgICAgICB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5zdHlsZS5vcGFjaXR5ID0gJzEnO1xuICAgICAgICAgIHRoaXMuaXNPcGVuLnNldCh0cnVlKTtcbiAgICAgICAgICBjb25zdCBjb21wb25lbnQgPSBzZWN0aW9uLm9wdGlvbnMoKS5jb21wb25lbnQ7XG4gICAgICAgICAgdGhpcy5pbm5lckNvbXBvbmVudFJlZiA9IHRoaXMuY29udGVudC5jcmVhdGVDb21wb25lbnQ8XG4gICAgICAgICAgICB0eXBlb2YgY29tcG9uZW50XG4gICAgICAgICAgPihzZWN0aW9uLm9wdGlvbnMoKS5jb21wb25lbnQpO1xuICAgICAgICAgIGZvciAoY29uc3QgaW5wdXQgaW4gc2VjdGlvbi5vcHRpb25zKCkuaW5wdXRzKSB7XG4gICAgICAgICAgICB0aGlzLmlubmVyQ29tcG9uZW50UmVmLmluc3RhbmNlW2lucHV0XSA9XG4gICAgICAgICAgICAgIHNlY3Rpb24ub3B0aW9ucygpLmlucHV0c1tpbnB1dF07XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgLy8gVE9ETzogRm9yIG5vdyB3b3JrcywgYnV0IGlmIGNvbnRlbnQgdGFrZXMgbG9uZ2VyIHRvIGxvYWQgdGhpcyB3aWxsIGJyZWFrLiBOZWVkIHRvIGltcGxlbWVudCBhIHdheSB0byBzaWduYWwgd2hlbiBhIGNvbnRlbnQgaXMgbG9hZGVkLlxuICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgICAgaWYgKHRoaXMuaW5uZXJDb21wb25lbnRSZWYpIHtcbiAgICAgICAgICAgICAgLy8gY29uc3QgaW5uZXJXaWR0aCA9IGdldENvbXB1dGVkU3R5bGUodGhpcy5pbm5lckNvbXBvbmVudFJlZi5sb2NhdGlvbi5uYXRpdmVFbGVtZW50KS53aWR0aCA/PyAodGhpcy5pbm5lckNvbXBvbmVudFJlZi5sb2NhdGlvbi5uYXRpdmVFbGVtZW50Lm9mZnNldFdpZHRoKTtcbiAgICAgICAgICAgICAgLy8gdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuc3R5bGUud2lkdGggPSBpbm5lcldpZHRoO1xuICAgICAgICAgICAgICAvLyB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudC5zdHlsZS50cmFuc2Zvcm0gPSBgc2NhbGVYKDEpYDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy5jbG9zZSgpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgY2xvc2UoKSB7XG4gICAgLy8gdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuc3R5bGUudHJhbnNmb3JtID0gJ3NjYWxlWCgwKSc7XG4gICAgdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuc3R5bGUud2lkdGggPSAnMCc7XG4gICAgdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuc3R5bGUub3BhY2l0eSA9ICcwJztcbiAgICB0aGlzLmlzT3Blbi5zZXQoZmFsc2UpO1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgaWYgKCF0aGlzLmlzT3BlbigpKSB7XG4gICAgICAgIHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ29wZW4nKTtcbiAgICAgICAgdGhpcy5pbm5lckNvbXBvbmVudFJlZj8uZGVzdHJveSgpO1xuICAgICAgICB0aGlzLmlubmVyQ29tcG9uZW50UmVmID0gbnVsbDtcbiAgICAgIH1cbiAgICB9LCAzMDApO1xuICB9XG59XG4iLCI8ZGl2XG4gIGNsYXNzPVwib3VpLW1haW4tc2lkZWJhci1leHRlbnNpb24tY29udGFpbmVyXCJcbiAgW25nQ2xhc3NdPVwieyAnaXMtb3Blbic6IGlzT3BlbigpIH1cIlxuPlxuICA8bmctY29udGFpbmVyICNjb250ZW50PjwvbmctY29udGFpbmVyPlxuPC9kaXY+XG4iXX0=