import * as i0 from '@angular/core';
import { EventEmitter, Component, ChangeDetectionStrategy, Input, Output } from '@angular/core';
import { NgClass } from '@angular/common';
import { isNil } from 'lodash-es';
import { OuiIconComponent } from 'orbital-ui/icon';

/**
 * A component used to display checkboxes. Can either work as a simple boolean on/off switch, or as a way to selectively
 * add/remove values from an array. If the passed in model is an array, then when turned on, the value of the checkbox will be
 * added to the array/vice versa. If the pasesd in model is a boolean, then checkbox functions as a on/off switch.
 *
 * Example-usage:
 *
 * Boolean mode:
 *
 * <oui-checkbox [(model)]="isEnabled">Check this if you want the item to be enabled</oui-checkbox>
 *
 * Array mode:
 *
 * <oui-checkbox [(model)]="selectedItems" value="'first_item'">First item</oui-checkbox>
 * <oui-checkbox [(model)]="selectedItems" value="'second_item'">Second item</oui-checkbox>
 * <oui-checkbox [(model)]="selectedItems" value="'third_item'">Third item</oui-checkbox>
 */
class OuiCheckboxComponent {
    cdr;
    /**
     *  either a boolean or an array. If an array is given, then the value of the checkbox will either be
     *  removed or added to the model when checked/unchecked.
     */
    model = false;
    /**
     * if model is an array, then this value will be added to the array if checkbox is checked.
     * If using boolean mode, then this field is ignored.
     */
    value;
    /**
     * whether or not a faint 'ghost'-checkmark should appear on the checkbox.
     */
    ghostSelect = false;
    /**
     * Used together with array-mode if passing in an array of objects. This is the key that will be used to figure out
     * whether a given checkbox is selected.
     */
    idKey;
    /**
     * emitted when model changes (with the current model)
     */
    modelChange = new EventEmitter();
    disabled = false;
    internalModel = false;
    constructor(cdr) {
        this.cdr = cdr;
    }
    ngAfterViewInit() {
        if (Array.isArray(this.model)) {
            this.internalModel = this.idKey
                ? this.model.findIndex(item => {
                    return item[this.idKey] === this.value[this.idKey];
                }) > -1
                : this.model.includes(this.value);
        }
        else {
            this.internalModel = this.model;
        }
    }
    emitChange(value) {
        this.internalModel = value;
        if (Array.isArray(this.model)) {
            if (this.internalModel) {
                this.model.push(this.value);
            }
            else {
                this.model.splice(this.model.indexOf(this.value), 1);
            }
        }
        else {
            this.model = value;
        }
        this.modelChange.emit(this.model);
        this.setIsChecked();
    }
    setIsChecked() {
        if (Array.isArray(this.model)) {
            this.internalModel = this.model.includes(this.value);
        }
        else {
            this.internalModel = this.model;
        }
        this.cdr.detectChanges();
    }
    ngOnChanges(changes) {
        if (!isNil(changes['model'])) {
            this.model = changes['model'].currentValue;
            this.setIsChecked();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCheckboxComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiCheckboxComponent, isStandalone: true, selector: "oui-checkbox", inputs: { model: "model", value: "value", ghostSelect: "ghostSelect", idKey: "idKey", disabled: "disabled" }, outputs: { modelChange: "modelChange" }, usesOnChanges: true, ngImport: i0, template: "<div class=\"oui-checkbox-container\" [ngClass]=\"{ disabled: disabled }\">\n  <div class=\"checkbox-wrapper\" (click)=\"emitChange(!internalModel)\">\n    <div class=\"checkbox\">\n      <input [checked]=\"internalModel\" class=\"checkbox-input\" type=\"checkbox\" />\n      @if (internalModel) {\n        <div class=\"checkbox-icon\">\n          <oui-icon\n            [options]=\"{ size: '12px' }\"\n            icon=\"assets/icons/check.svg\"\n          ></oui-icon>\n        </div>\n      }\n      @if (ghostSelect) {\n        <div class=\"checkbox-icon ghost\">\n          <oui-icon\n            [options]=\"{ strokeColor: 'white', fillColor: 'grey', size: '12px' }\"\n            icon=\"assets/icons/check.svg\"\n          ></oui-icon>\n        </div>\n      }\n    </div>\n    <span class=\"checkbox-label\"><ng-content></ng-content></span>\n  </div>\n</div>\n", styles: [":host .oui-checkbox-container{display:flex}:host .oui-checkbox-container.disabled{pointer-events:none;opacity:.8}:host .oui-checkbox-container .checkbox-wrapper{display:flex;align-items:center}:host .oui-checkbox-container .checkbox-wrapper:hover{cursor:pointer}:host .oui-checkbox-container .checkbox-wrapper .checkbox-label{color:var(--oui-checkbox-text-color)}:host .oui-checkbox-container .checkbox-wrapper .checkbox{margin-right:10px;display:flex;justify-content:center;align-items:center;position:relative}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-icon{position:absolute;pointer-events:none;width:80%;height:80%;display:flex;justify-content:center;align-items:center}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-input{margin:0;appearance:none;border:1px solid var(--border-color-primary);background-color:var(--oui-checkbox-background-color);width:var(--oui-checkbox-size);height:var(--oui-checkbox-size);border-radius:3px;box-shadow:var(--box-shadow-bottom);outline:none;transition:background-color .3s}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-input:hover{cursor:pointer}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-input:checked{background-color:var(--oui-checkbox-check-color)}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-checkbox', standalone: true, imports: [NgClass, OuiIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"oui-checkbox-container\" [ngClass]=\"{ disabled: disabled }\">\n  <div class=\"checkbox-wrapper\" (click)=\"emitChange(!internalModel)\">\n    <div class=\"checkbox\">\n      <input [checked]=\"internalModel\" class=\"checkbox-input\" type=\"checkbox\" />\n      @if (internalModel) {\n        <div class=\"checkbox-icon\">\n          <oui-icon\n            [options]=\"{ size: '12px' }\"\n            icon=\"assets/icons/check.svg\"\n          ></oui-icon>\n        </div>\n      }\n      @if (ghostSelect) {\n        <div class=\"checkbox-icon ghost\">\n          <oui-icon\n            [options]=\"{ strokeColor: 'white', fillColor: 'grey', size: '12px' }\"\n            icon=\"assets/icons/check.svg\"\n          ></oui-icon>\n        </div>\n      }\n    </div>\n    <span class=\"checkbox-label\"><ng-content></ng-content></span>\n  </div>\n</div>\n", styles: [":host .oui-checkbox-container{display:flex}:host .oui-checkbox-container.disabled{pointer-events:none;opacity:.8}:host .oui-checkbox-container .checkbox-wrapper{display:flex;align-items:center}:host .oui-checkbox-container .checkbox-wrapper:hover{cursor:pointer}:host .oui-checkbox-container .checkbox-wrapper .checkbox-label{color:var(--oui-checkbox-text-color)}:host .oui-checkbox-container .checkbox-wrapper .checkbox{margin-right:10px;display:flex;justify-content:center;align-items:center;position:relative}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-icon{position:absolute;pointer-events:none;width:80%;height:80%;display:flex;justify-content:center;align-items:center}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-input{margin:0;appearance:none;border:1px solid var(--border-color-primary);background-color:var(--oui-checkbox-background-color);width:var(--oui-checkbox-size);height:var(--oui-checkbox-size);border-radius:3px;box-shadow:var(--box-shadow-bottom);outline:none;transition:background-color .3s}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-input:hover{cursor:pointer}:host .oui-checkbox-container .checkbox-wrapper .checkbox .checkbox-input:checked{background-color:var(--oui-checkbox-check-color)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { model: [{
                type: Input
            }], value: [{
                type: Input
            }], ghostSelect: [{
                type: Input
            }], idKey: [{
                type: Input
            }], modelChange: [{
                type: Output
            }], disabled: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiCheckboxComponent };
//# sourceMappingURL=orbital-ui-checkbox.mjs.map
