import Supercluster from 'supercluster';
import { CompositeLayer } from '@deck.gl/core/typed';
import { IconLayer, TextLayer } from '@deck.gl/layers/typed';
import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { BaseDeckLayer } from '../base-deck-layer.component';
import { BindCommonDeckOptions } from '../deck/bind-default-deck-options';
import * as i0 from "@angular/core";
export class DeckClusterLayerComponent extends BaseDeckLayer {
    isHovering = false;
    options;
    constructor() {
        super();
    }
    getCursor(state) {
        return state.isHovering
            ? 'pointer'
            : state.isDragging
                ? 'grabbing'
                : 'grab';
    }
    getLayer() {
        return new IconClusterLayer({
            ...BindCommonDeckOptions(this),
            data: this.options.data,
            getPosition: this.options.getPosition
                ? this.options.getPosition
                : (d) => {
                    const coords = d.geometry;
                    return coords;
                },
            onClick: (info, event) => {
                if (this.options.onClick) {
                    let nextZoomLevel = null;
                    if (info.object.properties.cluster_id) {
                        nextZoomLevel = info.layer.state.index.getClusterExpansionZoom(info.object.properties.cluster_id);
                    }
                    this.options.onClick(info, nextZoomLevel, event);
                }
            },
            pickable: false,
            getColor: this.options.getColor ? this.options.getColor : [0, 0, 0, 180],
            getSize: this.options.getClusterSize,
            getIconName: this.options.getIconName,
            iconAtlas: this.options.iconAtlas,
            mask: this.options.mask ?? false,
            iconMapping: this.options.iconMapping,
            sizeScale: this.options.sizeScale ?? 1,
            reduceProps: this.options.reduceProps,
            mapProps: this.options.mapProps,
            clusterProps: this.options.clusterProps,
            textLayerProps: this.options.textLayerProps,
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckClusterLayerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: DeckClusterLayerComponent, isStandalone: true, selector: "oui-deck-cluster-layer", inputs: { options: "options" }, usesInheritance: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: DeckClusterLayerComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-deck-cluster-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }] } });
class IconClusterLayer extends CompositeLayer {
    options;
    supercluster;
    constructor(props) {
        super(props);
        this.options = props;
    }
    shouldUpdateState({ changeFlags }) {
        if (this.options.shouldUpdateState) {
            return this.options.shouldUpdateState(changeFlags);
        }
        else {
            return changeFlags.dataChanged || changeFlags.viewportChanged;
        }
    }
    updateState({ props, oldProps, changeFlags }) {
        const rebuildIndex = changeFlags.dataChanged || props.sizeScale !== oldProps.sizeScale;
        if (rebuildIndex) {
            const transformedData = [];
            for (const data of props.data) {
                if (!props.getPosition(data)) {
                    continue;
                }
                const singleItem = {
                    geometry: { coordinates: props.getPosition(data) },
                    properties: data,
                };
                transformedData.push(singleItem);
            }
            this.supercluster = new Supercluster({
                maxZoom: 20,
                radius: props.sizeScale,
                map: this.props.mapProps
                    ? this.props.mapProps
                    : (props) => {
                        return props;
                    },
                reduce: this.props.reduceProps ? this.props.reduceProps : () => { },
            });
            try {
                // @ts-ignore
                this.supercluster.load(transformedData);
            }
            catch (e) {
                console.error('Error encountered when loading index of cluster', e);
            }
            this.setState({ index: this.supercluster });
        }
        const z = Math.floor(this.context.viewport.zoom);
        if (rebuildIndex || z !== this.state['z']) {
            this.setState({
                data: this.state['index'].getClusters([-180, -85, 180, 85], z),
            });
        }
    }
    renderLayers() {
        const { data } = this.state;
        const { iconAtlas, iconMapping } = this.props;
        const layers = [
            new IconLayer(this.getSubLayerProps({
                data,
                iconAtlas,
                iconMapping,
                isHovering: this.props.isHovering,
                sizeScale: this.props.sizeScale,
                getPosition: (d) => {
                    return d.geometry.coordinates;
                },
                visible: this.props.visible,
                getSize: this.props.getSize,
                getColor: this.props.getColor,
                pickable: true,
                updateTriggers: this.props.updateTriggers ?? [],
                getIcon: this.props.getIconName,
            })),
        ];
        if (this.props.textLayerProps) {
            // TODO: Spreading the textLayerProps for some reason causes errors. Need to investigate why and fix.
            layers.push(new TextLayer({
                getPosition: this.props.textLayerProps.getPosition,
                getSize: () => 12,
                visible: this.props.visible,
                getColor: () => [0, 0, 0, 255],
                getText: this.props.textLayerProps.getText,
                data,
            }));
        }
        return layers;
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay1jbHVzdGVyLWxheWVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9tYXBib3gvY2x1c3Rlci1sYXllci9kZWNrLWNsdXN0ZXItbGF5ZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxZQUFZLE1BQU0sY0FBYyxDQUFDO0FBQ3hDLE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSxxQkFBcUIsQ0FBQztBQUNyRCxPQUFPLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxNQUFNLHVCQUF1QixDQUFDO0FBTzdELE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSw4QkFBOEIsQ0FBQztBQUM3RCxPQUFPLEVBQUUscUJBQXFCLEVBQUUsTUFBTSxtQ0FBbUMsQ0FBQzs7QUFTMUUsTUFBTSxPQUFPLHlCQUEwQixTQUFRLGFBQTBDO0lBQ2hGLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFFUyxPQUFPLENBQTJCO0lBQ3JFO1FBQ0UsS0FBSyxFQUFFLENBQUM7SUFDVixDQUFDO0lBRWUsU0FBUyxDQUFDLEtBQWtCO1FBQzFDLE9BQU8sS0FBSyxDQUFDLFVBQVU7WUFDckIsQ0FBQyxDQUFDLFNBQVM7WUFDWCxDQUFDLENBQUMsS0FBSyxDQUFDLFVBQVU7Z0JBQ2xCLENBQUMsQ0FBQyxVQUFVO2dCQUNaLENBQUMsQ0FBQyxNQUFNLENBQUM7SUFDYixDQUFDO0lBRU0sUUFBUTtRQUNiLE9BQU8sSUFBSSxnQkFBZ0IsQ0FBQztZQUMxQixHQUFHLHFCQUFxQixDQUFDLElBQUksQ0FBQztZQUM5QixJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJO1lBQ3ZCLFdBQVcsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVc7Z0JBQ25DLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVc7Z0JBQzFCLENBQUMsQ0FBQyxDQUFDLENBQU0sRUFBRSxFQUFFO29CQUNULE1BQU0sTUFBTSxHQUFHLENBQUMsQ0FBQyxRQUFRLENBQUM7b0JBQzFCLE9BQU8sTUFBTSxDQUFDO2dCQUNoQixDQUFDO1lBQ0wsT0FBTyxFQUFFLENBQUMsSUFBMkIsRUFBRSxLQUFVLEVBQUUsRUFBRTtnQkFDbkQsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO29CQUN6QixJQUFJLGFBQWEsR0FBRyxJQUFJLENBQUM7b0JBQ3pCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLENBQUM7d0JBQ3RDLGFBQWEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsdUJBQXVCLENBQzVELElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FDbEMsQ0FBQztvQkFDSixDQUFDO29CQUVELElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxhQUFhLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQ25ELENBQUM7WUFDSCxDQUFDO1lBQ0QsUUFBUSxFQUFFLEtBQUs7WUFDZixRQUFRLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQztZQUN4RSxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjO1lBQ3BDLFdBQVcsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVc7WUFDckMsU0FBUyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUztZQUNqQyxJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLElBQUksS0FBSztZQUNoQyxXQUFXLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXO1lBQ3JDLFNBQVMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsSUFBSSxDQUFDO1lBQ3RDLFdBQVcsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVc7WUFDckMsUUFBUSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUTtZQUMvQixZQUFZLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZO1lBQ3ZDLGNBQWMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWM7U0FDNUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQzt1R0FuRFUseUJBQXlCOzJGQUF6Qix5QkFBeUIseUlBTDFCLEVBQUU7OzJGQUtELHlCQUF5QjtrQkFQckMsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsd0JBQXdCO29CQUNsQyxRQUFRLEVBQUUsRUFBRTtvQkFDWixVQUFVLEVBQUUsSUFBSTtvQkFDaEIsT0FBTyxFQUFFLEVBQUU7b0JBQ1gsZUFBZSxFQUFFLHVCQUF1QixDQUFDLE1BQU07aUJBQ2hEO3dEQUlvQyxPQUFPO3NCQUF6QyxLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTs7QUFtRDNCLE1BQU0sZ0JBQWlCLFNBQVEsY0FBbUI7SUFDeEMsT0FBTyxDQUEyQjtJQUNuQyxZQUFZLENBQWU7SUFDbEMsWUFBWSxLQUFVO1FBQ3BCLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUNiLElBQUksQ0FBQyxPQUFPLEdBQUcsS0FBSyxDQUFDO0lBQ3ZCLENBQUM7SUFFUSxpQkFBaUIsQ0FBQyxFQUFFLFdBQVcsRUFBTztRQUM3QyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztZQUNuQyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDckQsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLFdBQVcsQ0FBQyxXQUFXLElBQUksV0FBVyxDQUFDLGVBQWUsQ0FBQztRQUNoRSxDQUFDO0lBQ0gsQ0FBQztJQUVRLFdBQVcsQ0FBQyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFPO1FBQ3hELE1BQU0sWUFBWSxHQUNoQixXQUFXLENBQUMsV0FBVyxJQUFJLEtBQUssQ0FBQyxTQUFTLEtBQUssUUFBUSxDQUFDLFNBQVMsQ0FBQztRQUNwRSxJQUFJLFlBQVksRUFBRSxDQUFDO1lBQ2pCLE1BQU0sZUFBZSxHQUFHLEVBQUUsQ0FBQztZQUMzQixLQUFLLE1BQU0sSUFBSSxJQUFJLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDOUIsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztvQkFDN0IsU0FBUztnQkFDWCxDQUFDO2dCQUNELE1BQU0sVUFBVSxHQUFHO29CQUNqQixRQUFRLEVBQUUsRUFBRSxXQUFXLEVBQUUsS0FBSyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsRUFBRTtvQkFDbEQsVUFBVSxFQUFFLElBQUk7aUJBQ2pCLENBQUM7Z0JBQ0YsZUFBZSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUNuQyxDQUFDO1lBQ0QsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLFlBQVksQ0FBQztnQkFDbkMsT0FBTyxFQUFFLEVBQUU7Z0JBQ1gsTUFBTSxFQUFFLEtBQUssQ0FBQyxTQUFTO2dCQUN2QixHQUFHLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRO29CQUN0QixDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRO29CQUNyQixDQUFDLENBQUMsQ0FBQyxLQUFVLEVBQUUsRUFBRTt3QkFDYixPQUFPLEtBQUssQ0FBQztvQkFDZixDQUFDO2dCQUNMLE1BQU0sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFFLENBQUM7YUFDbkUsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDO2dCQUNILGFBQWE7Z0JBQ2IsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7WUFDMUMsQ0FBQztZQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7Z0JBQ1gsT0FBTyxDQUFDLEtBQUssQ0FBQyxpREFBaUQsRUFBRSxDQUFDLENBQUMsQ0FBQztZQUN0RSxDQUFDO1lBRUQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLEtBQUssRUFBRSxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQztRQUM5QyxDQUFDO1FBRUQsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUNqRCxJQUFJLFlBQVksSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQzFDLElBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQ1osSUFBSSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQzthQUMvRCxDQUFDLENBQUM7UUFDTCxDQUFDO0lBQ0gsQ0FBQztJQUVRLFlBQVk7UUFDbkIsTUFBTSxFQUFFLElBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDNUIsTUFBTSxFQUFFLFNBQVMsRUFBRSxXQUFXLEVBQUUsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQzlDLE1BQU0sTUFBTSxHQUFVO1lBQ3BCLElBQUksU0FBUyxDQUNYLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDcEIsSUFBSTtnQkFDSixTQUFTO2dCQUNULFdBQVc7Z0JBQ1gsVUFBVSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVTtnQkFDakMsU0FBUyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUztnQkFDL0IsV0FBVyxFQUFFLENBQUMsQ0FBTSxFQUFFLEVBQUU7b0JBQ3RCLE9BQU8sQ0FBQyxDQUFDLFFBQVEsQ0FBQyxXQUFXLENBQUM7Z0JBQ2hDLENBQUM7Z0JBQ0QsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTztnQkFDM0IsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTztnQkFDM0IsUUFBUSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUTtnQkFDN0IsUUFBUSxFQUFFLElBQUk7Z0JBQ2QsY0FBYyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxJQUFJLEVBQUU7Z0JBQy9DLE9BQU8sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVc7YUFDaEMsQ0FBQyxDQUNIO1NBQ0YsQ0FBQztRQUNGLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUM5QixxR0FBcUc7WUFDckcsTUFBTSxDQUFDLElBQUksQ0FDVCxJQUFJLFNBQVMsQ0FBQztnQkFDWixXQUFXLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsV0FBVztnQkFDbEQsT0FBTyxFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUU7Z0JBQ2pCLE9BQU8sRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU87Z0JBQzNCLFFBQVEsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLEdBQUcsQ0FBQztnQkFDOUIsT0FBTyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLE9BQU87Z0JBQzFDLElBQUk7YUFDTCxDQUFDLENBQ0gsQ0FBQztRQUNKLENBQUM7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0NBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgU3VwZXJjbHVzdGVyIGZyb20gJ3N1cGVyY2x1c3Rlcic7XG5pbXBvcnQgeyBDb21wb3NpdGVMYXllciB9IGZyb20gJ0BkZWNrLmdsL2NvcmUvdHlwZWQnO1xuaW1wb3J0IHsgSWNvbkxheWVyLCBUZXh0TGF5ZXIgfSBmcm9tICdAZGVjay5nbC9sYXllcnMvdHlwZWQnO1xuaW1wb3J0IHtcbiAgQ3Vyc29yU3RhdGUsXG4gIElEZWNrQ2x1c3RlckNsaWNrSW5mbyxcbiAgSURlY2tDbHVzdGVyTGF5ZXJPcHRpb25zLFxuICBJU2xpbUNvbW1vbkRlY2tMYXllck9wdGlvbnMsXG59IGZyb20gJy4uL3R5cGluZ3MnO1xuaW1wb3J0IHsgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksIENvbXBvbmVudCwgSW5wdXQgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEJhc2VEZWNrTGF5ZXIgfSBmcm9tICcuLi9iYXNlLWRlY2stbGF5ZXIuY29tcG9uZW50JztcbmltcG9ydCB7IEJpbmRDb21tb25EZWNrT3B0aW9ucyB9IGZyb20gJy4uL2RlY2svYmluZC1kZWZhdWx0LWRlY2stb3B0aW9ucyc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1kZWNrLWNsdXN0ZXItbGF5ZXInLFxuICB0ZW1wbGF0ZTogJycsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtdLFxuICBjaGFuZ2VEZXRlY3Rpb246IENoYW5nZURldGVjdGlvblN0cmF0ZWd5Lk9uUHVzaCxcbn0pXG5leHBvcnQgY2xhc3MgRGVja0NsdXN0ZXJMYXllckNvbXBvbmVudCBleHRlbmRzIEJhc2VEZWNrTGF5ZXI8SVNsaW1Db21tb25EZWNrTGF5ZXJPcHRpb25zPiB7XG4gIHB1YmxpYyBpc0hvdmVyaW5nID0gZmFsc2U7XG5cbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSkgZGVjbGFyZSBvcHRpb25zOiBJRGVja0NsdXN0ZXJMYXllck9wdGlvbnM7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHN1cGVyKCk7XG4gIH1cblxuICBwdWJsaWMgb3ZlcnJpZGUgZ2V0Q3Vyc29yKHN0YXRlOiBDdXJzb3JTdGF0ZSk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHN0YXRlLmlzSG92ZXJpbmdcbiAgICAgID8gJ3BvaW50ZXInXG4gICAgICA6IHN0YXRlLmlzRHJhZ2dpbmdcbiAgICAgID8gJ2dyYWJiaW5nJ1xuICAgICAgOiAnZ3JhYic7XG4gIH1cblxuICBwdWJsaWMgZ2V0TGF5ZXIoKSB7XG4gICAgcmV0dXJuIG5ldyBJY29uQ2x1c3RlckxheWVyKHtcbiAgICAgIC4uLkJpbmRDb21tb25EZWNrT3B0aW9ucyh0aGlzKSxcbiAgICAgIGRhdGE6IHRoaXMub3B0aW9ucy5kYXRhLFxuICAgICAgZ2V0UG9zaXRpb246IHRoaXMub3B0aW9ucy5nZXRQb3NpdGlvblxuICAgICAgICA/IHRoaXMub3B0aW9ucy5nZXRQb3NpdGlvblxuICAgICAgICA6IChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNvb3JkcyA9IGQuZ2VvbWV0cnk7XG4gICAgICAgICAgICByZXR1cm4gY29vcmRzO1xuICAgICAgICAgIH0sXG4gICAgICBvbkNsaWNrOiAoaW5mbzogSURlY2tDbHVzdGVyQ2xpY2tJbmZvLCBldmVudDogYW55KSA9PiB7XG4gICAgICAgIGlmICh0aGlzLm9wdGlvbnMub25DbGljaykge1xuICAgICAgICAgIGxldCBuZXh0Wm9vbUxldmVsID0gbnVsbDtcbiAgICAgICAgICBpZiAoaW5mby5vYmplY3QucHJvcGVydGllcy5jbHVzdGVyX2lkKSB7XG4gICAgICAgICAgICBuZXh0Wm9vbUxldmVsID0gaW5mby5sYXllci5zdGF0ZS5pbmRleC5nZXRDbHVzdGVyRXhwYW5zaW9uWm9vbShcbiAgICAgICAgICAgICAgaW5mby5vYmplY3QucHJvcGVydGllcy5jbHVzdGVyX2lkXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHRoaXMub3B0aW9ucy5vbkNsaWNrKGluZm8sIG5leHRab29tTGV2ZWwsIGV2ZW50KTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIHBpY2thYmxlOiBmYWxzZSxcbiAgICAgIGdldENvbG9yOiB0aGlzLm9wdGlvbnMuZ2V0Q29sb3IgPyB0aGlzLm9wdGlvbnMuZ2V0Q29sb3IgOiBbMCwgMCwgMCwgMTgwXSxcbiAgICAgIGdldFNpemU6IHRoaXMub3B0aW9ucy5nZXRDbHVzdGVyU2l6ZSxcbiAgICAgIGdldEljb25OYW1lOiB0aGlzLm9wdGlvbnMuZ2V0SWNvbk5hbWUsXG4gICAgICBpY29uQXRsYXM6IHRoaXMub3B0aW9ucy5pY29uQXRsYXMsXG4gICAgICBtYXNrOiB0aGlzLm9wdGlvbnMubWFzayA/PyBmYWxzZSxcbiAgICAgIGljb25NYXBwaW5nOiB0aGlzLm9wdGlvbnMuaWNvbk1hcHBpbmcsXG4gICAgICBzaXplU2NhbGU6IHRoaXMub3B0aW9ucy5zaXplU2NhbGUgPz8gMSxcbiAgICAgIHJlZHVjZVByb3BzOiB0aGlzLm9wdGlvbnMucmVkdWNlUHJvcHMsXG4gICAgICBtYXBQcm9wczogdGhpcy5vcHRpb25zLm1hcFByb3BzLFxuICAgICAgY2x1c3RlclByb3BzOiB0aGlzLm9wdGlvbnMuY2x1c3RlclByb3BzLFxuICAgICAgdGV4dExheWVyUHJvcHM6IHRoaXMub3B0aW9ucy50ZXh0TGF5ZXJQcm9wcyxcbiAgICB9KTtcbiAgfVxufVxuXG5jbGFzcyBJY29uQ2x1c3RlckxheWVyIGV4dGVuZHMgQ29tcG9zaXRlTGF5ZXI8YW55PiB7XG4gIHByaXZhdGUgb3B0aW9uczogSURlY2tDbHVzdGVyTGF5ZXJPcHRpb25zO1xuICBwdWJsaWMgc3VwZXJjbHVzdGVyOiBTdXBlcmNsdXN0ZXI7XG4gIGNvbnN0cnVjdG9yKHByb3BzOiBhbnkpIHtcbiAgICBzdXBlcihwcm9wcyk7XG4gICAgdGhpcy5vcHRpb25zID0gcHJvcHM7XG4gIH1cblxuICBvdmVycmlkZSBzaG91bGRVcGRhdGVTdGF0ZSh7IGNoYW5nZUZsYWdzIH06IGFueSkge1xuICAgIGlmICh0aGlzLm9wdGlvbnMuc2hvdWxkVXBkYXRlU3RhdGUpIHtcbiAgICAgIHJldHVybiB0aGlzLm9wdGlvbnMuc2hvdWxkVXBkYXRlU3RhdGUoY2hhbmdlRmxhZ3MpO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gY2hhbmdlRmxhZ3MuZGF0YUNoYW5nZWQgfHwgY2hhbmdlRmxhZ3Mudmlld3BvcnRDaGFuZ2VkO1xuICAgIH1cbiAgfVxuXG4gIG92ZXJyaWRlIHVwZGF0ZVN0YXRlKHsgcHJvcHMsIG9sZFByb3BzLCBjaGFuZ2VGbGFncyB9OiBhbnkpIHtcbiAgICBjb25zdCByZWJ1aWxkSW5kZXggPVxuICAgICAgY2hhbmdlRmxhZ3MuZGF0YUNoYW5nZWQgfHwgcHJvcHMuc2l6ZVNjYWxlICE9PSBvbGRQcm9wcy5zaXplU2NhbGU7XG4gICAgaWYgKHJlYnVpbGRJbmRleCkge1xuICAgICAgY29uc3QgdHJhbnNmb3JtZWREYXRhID0gW107XG4gICAgICBmb3IgKGNvbnN0IGRhdGEgb2YgcHJvcHMuZGF0YSkge1xuICAgICAgICBpZiAoIXByb3BzLmdldFBvc2l0aW9uKGRhdGEpKSB7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc2luZ2xlSXRlbSA9IHtcbiAgICAgICAgICBnZW9tZXRyeTogeyBjb29yZGluYXRlczogcHJvcHMuZ2V0UG9zaXRpb24oZGF0YSkgfSxcbiAgICAgICAgICBwcm9wZXJ0aWVzOiBkYXRhLFxuICAgICAgICB9O1xuICAgICAgICB0cmFuc2Zvcm1lZERhdGEucHVzaChzaW5nbGVJdGVtKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuc3VwZXJjbHVzdGVyID0gbmV3IFN1cGVyY2x1c3Rlcih7XG4gICAgICAgIG1heFpvb206IDIwLFxuICAgICAgICByYWRpdXM6IHByb3BzLnNpemVTY2FsZSxcbiAgICAgICAgbWFwOiB0aGlzLnByb3BzLm1hcFByb3BzXG4gICAgICAgICAgPyB0aGlzLnByb3BzLm1hcFByb3BzXG4gICAgICAgICAgOiAocHJvcHM6IGFueSkgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gcHJvcHM7XG4gICAgICAgICAgICB9LFxuICAgICAgICByZWR1Y2U6IHRoaXMucHJvcHMucmVkdWNlUHJvcHMgPyB0aGlzLnByb3BzLnJlZHVjZVByb3BzIDogKCkgPT4ge30sXG4gICAgICB9KTtcbiAgICAgIHRyeSB7XG4gICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgdGhpcy5zdXBlcmNsdXN0ZXIubG9hZCh0cmFuc2Zvcm1lZERhdGEpO1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBlbmNvdW50ZXJlZCB3aGVuIGxvYWRpbmcgaW5kZXggb2YgY2x1c3RlcicsIGUpO1xuICAgICAgfVxuXG4gICAgICB0aGlzLnNldFN0YXRlKHsgaW5kZXg6IHRoaXMuc3VwZXJjbHVzdGVyIH0pO1xuICAgIH1cblxuICAgIGNvbnN0IHogPSBNYXRoLmZsb29yKHRoaXMuY29udGV4dC52aWV3cG9ydC56b29tKTtcbiAgICBpZiAocmVidWlsZEluZGV4IHx8IHogIT09IHRoaXMuc3RhdGVbJ3onXSkge1xuICAgICAgdGhpcy5zZXRTdGF0ZSh7XG4gICAgICAgIGRhdGE6IHRoaXMuc3RhdGVbJ2luZGV4J10uZ2V0Q2x1c3RlcnMoWy0xODAsIC04NSwgMTgwLCA4NV0sIHopLFxuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgb3ZlcnJpZGUgcmVuZGVyTGF5ZXJzKCkge1xuICAgIGNvbnN0IHsgZGF0YSB9ID0gdGhpcy5zdGF0ZTtcbiAgICBjb25zdCB7IGljb25BdGxhcywgaWNvbk1hcHBpbmcgfSA9IHRoaXMucHJvcHM7XG4gICAgY29uc3QgbGF5ZXJzOiBhbnlbXSA9IFtcbiAgICAgIG5ldyBJY29uTGF5ZXIoXG4gICAgICAgIHRoaXMuZ2V0U3ViTGF5ZXJQcm9wcyh7XG4gICAgICAgICAgZGF0YSxcbiAgICAgICAgICBpY29uQXRsYXMsXG4gICAgICAgICAgaWNvbk1hcHBpbmcsXG4gICAgICAgICAgaXNIb3ZlcmluZzogdGhpcy5wcm9wcy5pc0hvdmVyaW5nLFxuICAgICAgICAgIHNpemVTY2FsZTogdGhpcy5wcm9wcy5zaXplU2NhbGUsXG4gICAgICAgICAgZ2V0UG9zaXRpb246IChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBkLmdlb21ldHJ5LmNvb3JkaW5hdGVzO1xuICAgICAgICAgIH0sXG4gICAgICAgICAgdmlzaWJsZTogdGhpcy5wcm9wcy52aXNpYmxlLFxuICAgICAgICAgIGdldFNpemU6IHRoaXMucHJvcHMuZ2V0U2l6ZSxcbiAgICAgICAgICBnZXRDb2xvcjogdGhpcy5wcm9wcy5nZXRDb2xvcixcbiAgICAgICAgICBwaWNrYWJsZTogdHJ1ZSxcbiAgICAgICAgICB1cGRhdGVUcmlnZ2VyczogdGhpcy5wcm9wcy51cGRhdGVUcmlnZ2VycyA/PyBbXSxcbiAgICAgICAgICBnZXRJY29uOiB0aGlzLnByb3BzLmdldEljb25OYW1lLFxuICAgICAgICB9KVxuICAgICAgKSxcbiAgICBdO1xuICAgIGlmICh0aGlzLnByb3BzLnRleHRMYXllclByb3BzKSB7XG4gICAgICAvLyBUT0RPOiBTcHJlYWRpbmcgdGhlIHRleHRMYXllclByb3BzIGZvciBzb21lIHJlYXNvbiBjYXVzZXMgZXJyb3JzLiBOZWVkIHRvIGludmVzdGlnYXRlIHdoeSBhbmQgZml4LlxuICAgICAgbGF5ZXJzLnB1c2goXG4gICAgICAgIG5ldyBUZXh0TGF5ZXIoe1xuICAgICAgICAgIGdldFBvc2l0aW9uOiB0aGlzLnByb3BzLnRleHRMYXllclByb3BzLmdldFBvc2l0aW9uLFxuICAgICAgICAgIGdldFNpemU6ICgpID0+IDEyLFxuICAgICAgICAgIHZpc2libGU6IHRoaXMucHJvcHMudmlzaWJsZSxcbiAgICAgICAgICBnZXRDb2xvcjogKCkgPT4gWzAsIDAsIDAsIDI1NV0sXG4gICAgICAgICAgZ2V0VGV4dDogdGhpcy5wcm9wcy50ZXh0TGF5ZXJQcm9wcy5nZXRUZXh0LFxuICAgICAgICAgIGRhdGEsXG4gICAgICAgIH0pXG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiBsYXllcnM7XG4gIH1cbn1cbiJdfQ==