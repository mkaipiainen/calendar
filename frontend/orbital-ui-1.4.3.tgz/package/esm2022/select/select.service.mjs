import { Injectable } from '@angular/core';
import { fromEvent } from 'rxjs';
import * as i0 from "@angular/core";
/**
 * Service that keeps tracks and manages select-components.
 * Has a public method closeAll() that can be used to close all open select-components
 */
export class OuiSelectService {
    clickObservable;
    dropdowns = [];
    constructor() {
        this.clickObservable = fromEvent(document, 'click');
    }
    register(dropdown) {
        this.dropdowns.push(dropdown);
    }
    closeAll() {
        for (const dropdown of this.dropdowns) {
            if ('cancel' in dropdown) {
                dropdown.cancel();
            }
            else {
                dropdown.close();
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSelectService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSelectService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSelectService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VsZWN0LnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3NlbGVjdC9zZWxlY3Quc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzNDLE9BQU8sRUFBRSxTQUFTLEVBQWMsTUFBTSxNQUFNLENBQUM7O0FBSTdDOzs7R0FHRztBQUlILE1BQU0sT0FBTyxnQkFBZ0I7SUFDcEIsZUFBZSxDQUEyQjtJQUMxQyxTQUFTLEdBQXFELEVBQUUsQ0FBQztJQUV4RTtRQUNFLElBQUksQ0FBQyxlQUFlLEdBQUcsU0FBUyxDQUFlLFFBQVEsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUNwRSxDQUFDO0lBRU0sUUFBUSxDQUFDLFFBQXNEO1FBQ3BFLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFFTSxRQUFRO1FBQ2IsS0FBSyxNQUFNLFFBQVEsSUFBSSxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDdEMsSUFBSSxRQUFRLElBQUksUUFBUSxFQUFFLENBQUM7Z0JBQ3hCLFFBQW9DLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDakQsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLFFBQVEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNuQixDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7dUdBcEJVLGdCQUFnQjsyR0FBaEIsZ0JBQWdCLGNBRmYsTUFBTTs7MkZBRVAsZ0JBQWdCO2tCQUg1QixVQUFVO21CQUFDO29CQUNWLFVBQVUsRUFBRSxNQUFNO2lCQUNuQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGZyb21FdmVudCwgT2JzZXJ2YWJsZSB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgT3VpTXVsdGlTZWxlY3RDb21wb25lbnQgfSBmcm9tICcuL211bHRpLXNlbGVjdC9tdWx0aS1zZWxlY3QuY29tcG9uZW50JztcbmltcG9ydCB7IE91aVNlbGVjdENvbXBvbmVudCB9IGZyb20gJy4vc2VsZWN0LWNvbXBvbmVudC9zZWxlY3QuY29tcG9uZW50JztcblxuLyoqXG4gKiBTZXJ2aWNlIHRoYXQga2VlcHMgdHJhY2tzIGFuZCBtYW5hZ2VzIHNlbGVjdC1jb21wb25lbnRzLlxuICogSGFzIGEgcHVibGljIG1ldGhvZCBjbG9zZUFsbCgpIHRoYXQgY2FuIGJlIHVzZWQgdG8gY2xvc2UgYWxsIG9wZW4gc2VsZWN0LWNvbXBvbmVudHNcbiAqL1xuQEluamVjdGFibGUoe1xuICBwcm92aWRlZEluOiAncm9vdCcsXG59KVxuZXhwb3J0IGNsYXNzIE91aVNlbGVjdFNlcnZpY2Uge1xuICBwdWJsaWMgY2xpY2tPYnNlcnZhYmxlOiBPYnNlcnZhYmxlPFBvaW50ZXJFdmVudD47XG4gIHB1YmxpYyBkcm9wZG93bnM6IChPdWlTZWxlY3RDb21wb25lbnQgfCBPdWlNdWx0aVNlbGVjdENvbXBvbmVudClbXSA9IFtdO1xuXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMuY2xpY2tPYnNlcnZhYmxlID0gZnJvbUV2ZW50PFBvaW50ZXJFdmVudD4oZG9jdW1lbnQsICdjbGljaycpO1xuICB9XG5cbiAgcHVibGljIHJlZ2lzdGVyKGRyb3Bkb3duOiBPdWlTZWxlY3RDb21wb25lbnQgfCBPdWlNdWx0aVNlbGVjdENvbXBvbmVudCkge1xuICAgIHRoaXMuZHJvcGRvd25zLnB1c2goZHJvcGRvd24pO1xuICB9XG5cbiAgcHVibGljIGNsb3NlQWxsKCkge1xuICAgIGZvciAoY29uc3QgZHJvcGRvd24gb2YgdGhpcy5kcm9wZG93bnMpIHtcbiAgICAgIGlmICgnY2FuY2VsJyBpbiBkcm9wZG93bikge1xuICAgICAgICAoZHJvcGRvd24gYXMgT3VpTXVsdGlTZWxlY3RDb21wb25lbnQpLmNhbmNlbCgpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZHJvcGRvd24uY2xvc2UoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdfQ==