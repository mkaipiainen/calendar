import { AfterViewInit } from '@angular/core';
import { OuiMainSidebarRouteSectionOptions } from '../main-sidebar-route-section/main-sidebar-route-section.component';
import { OuiMainSidebarCombinedOptions } from '../main-sidebar.component';
import * as i0 from "@angular/core";
export declare class MainSidebarSubMenuComponent implements AfterViewInit {
    private elementRef;
    private router;
    private destroyRef;
    activeParentRoute: import("@angular/core").InputSignal<OuiMainSidebarRouteSectionOptions>;
    sidebarOptions: import("@angular/core").InputSignal<OuiMainSidebarCombinedOptions>;
    activeChildRoute: import("@angular/core").WritableSignal<OuiMainSidebarRouteSectionOptions | undefined>;
    constructor();
    ngAfterViewInit(): void;
    private setActiveRoute;
    static ɵfac: i0.ɵɵFactoryDeclaration<MainSidebarSubMenuComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MainSidebarSubMenuComponent, "oui-main-sidebar-sub-menu", never, { "activeParentRoute": { "alias": "activeParentRoute"; "required": true; "isSignal": true; }; "sidebarOptions": { "alias": "sidebarOptions"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=main-sidebar-sub-menu.component.d.ts.map