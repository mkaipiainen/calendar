import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
/**
 * Used to queue requests done by the Deck.GL tileLayer.
 * This is needed in cases where the token expires in the middle of loading tiles, in which case
 * requests go into a queue, and are then executed once the token has been refreshed.
 *
 * This is used by rasterLayerService, which should be used for handling optical layers for maps.
 */
export declare class RequestQueueService {
    private refreshRequiredSubject;
    refreshRequired$: Observable<void>;
    queue: any[];
    private isRefreshingToken;
    constructor();
    addToQueue(promise: Promise<Response>, signal: AbortSignal, refreshedAccessToken$?: Observable<string>): Promise<Response>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RequestQueueService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<RequestQueueService>;
}
//# sourceMappingURL=request-queue.service.d.ts.map