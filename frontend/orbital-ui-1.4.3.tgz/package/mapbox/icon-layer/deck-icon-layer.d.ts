import { IconLayer } from '@deck.gl/layers/typed';
import { ICommonDeckLayerOptions, IDeckIconLayerOptions } from '../typings';
import { BaseDeckLayer } from '../base-deck-layer.component';
import * as i0 from "@angular/core";
export declare class DeckIconLayer extends BaseDeckLayer<ICommonDeckLayerOptions> {
    options: IDeckIconLayerOptions;
    constructor();
    getLayer(): IconLayer<any, {
        data: any[];
        getIcon: (d: any) => string;
        iconAtlas: string;
        iconMapping: any;
        getPosition: (d: any) => [number, number];
        pickable: boolean;
        sizeScale: number;
        getSize: number | ((d: any) => number);
        getPixelOffset: any;
        onDrag: (info: any) => void;
        onDragStart: (info: any) => void;
        onDragEnd: (info: any) => void;
        id: string;
        autoHighlight: boolean;
        transitions: {
            [x: string]: number | {
                duration: number;
                easing: any;
            };
        };
        highlightColor: import("orbital-ui/core").RGBA | ((d: any) => import("orbital-ui/core").RGBA);
        isEnabled: boolean;
        _dataDiff: (oldData: any, newData: any) => [{
            startRow: number;
            endRow: number;
        }];
        onClick: (object: any, event: any) => void;
        onHover: (event: any) => boolean;
        updateTriggers: any;
        dataComparator: (<LayerDataT = import("@deck.gl/core/typed").LayerData<unknown>>(newData: LayerDataT, oldData?: LayerDataT | undefined) => boolean) | null;
        getCursor: (data: {
            isHovering: boolean;
            isDragging: boolean;
        }) => string;
        order: number;
        loadOptions: any;
        visible: boolean;
        opacity: number;
        extensions: any[];
        getDashArray: [number, number];
        dashJustified: boolean;
        dashGapPickable: boolean;
        getOffset: number | (() => number);
        clipBounds: [number, number, number, number];
        maskId: string;
        maskByInstance: boolean;
        maskInverted: boolean;
        operation: "mask";
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<DeckIconLayer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DeckIconLayer, "oui-deck-icon-layer", never, { "options": { "alias": "options"; "required": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=deck-icon-layer.d.ts.map