import { ApplicationRef, ComponentRef, EnvironmentInjector, Injector, NgModuleRef, ViewContainerRef } from '@angular/core';
import { ComponentType } from '@angular/cdk/overlay';
export type ICreateComponentOptions<T> = ICreateComponentOptionsWithVCR<T> | ICreateComponentOptionsWithParentElement<T>;
export interface ICreateComponentOptionsWithVCR<T> {
    viewContainerRef: ViewContainerRef;
    component: ComponentType<T>;
    createComponentOptions?: {
        index?: number;
        injector?: Injector;
        ngModuleRef?: NgModuleRef<unknown>;
        environmentInjector?: EnvironmentInjector | NgModuleRef<unknown>;
        projectableNodes?: Node[][];
    };
    inputs?: {
        [key: string]: any;
    };
    outputs?: {
        [key: string]: (...args: any[]) => any;
    };
}
export interface ICreateComponentOptionsWithParentElement<T> {
    parentElement: HTMLElement;
    appRef: ApplicationRef;
    component: ComponentType<T>;
    createComponentOptions: {
        environmentInjector: EnvironmentInjector;
        hostElement?: Element;
        elementInjector?: Injector;
        projectableNodes?: Node[][];
    };
    inputs?: {
        [key: string]: any;
    };
    outputs?: {
        [key: string]: (...args: any[]) => any;
    };
}
export declare class ComponentCreator {
    constructor();
    static createComponent<T>(options: ICreateComponentOptions<T>): ComponentRef<T>;
}
//# sourceMappingURL=component-creator.d.ts.map