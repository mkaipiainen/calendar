import * as i0 from '@angular/core';
import { signal, Injectable, input, Component, ChangeDetectionStrategy, inject, DestroyRef, ElementRef, computed, ViewChild, ViewContainerRef, Pipe, effect, model } from '@angular/core';
import { BehaviorSubject, Subject, filter, delay } from 'rxjs';
import { merge } from 'lodash-es';
import * as i1 from '@angular/common';
import { NgClass, NgStyle, CommonModule } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { OuiButtonComponent } from 'orbital-ui/button';
import { OuiIconComponent } from 'orbital-ui/icon';
import { RouterLink, RouterLinkActive, Router, NavigationEnd } from '@angular/router';
import { OuiTooltipDirective } from 'orbital-ui/tooltip';
import { OuiIconButtonComponent } from 'orbital-ui/icon-button';
import { OuiRippleDirective } from 'orbital-ui/ripple';
import { OuiGesturesDirective } from 'orbital-ui/gestures';
import { IsTabletOrMobile } from 'orbital-ui/helpers';

const MAIN_SIDEBAR_SECTION_TYPES = {
    ROUTE: 'route',
    SUBROUTE: 'subroute',
    ACTION: 'action',
    SUBSECTION: 'subsection',
};
class OuiMainSidebarService {
    isOpenSubject = new BehaviorSubject(false);
    openSubSectionSubject = new BehaviorSubject(undefined);
    sectionClosedSubject = new Subject();
    sectionActiveSubject = new Subject();
    // width contains the actual property, value contains just the number-value (so for example width might be '250px' and value would be 250)
    extensionWidthSubject = new BehaviorSubject({
        width: '0px',
        value: 0,
    });
    isOpen = signal(false);
    activeSection = signal(undefined);
    isOpen$ = this.isOpenSubject.asObservable();
    openSubSection$ = this.openSubSectionSubject.asObservable();
    sectionClosed$ = this.sectionClosedSubject.asObservable();
    extensionWidth$ = this.extensionWidthSubject.asObservable();
    sectionActive$ = this.sectionActiveSubject.asObservable();
    constructor() { }
    setExtensionWidth(width) {
        const parsedValue = parseFloat(width.match(/\d*/g)?.[0] ?? width);
        this.extensionWidthSubject.next({
            width,
            value: parsedValue,
        });
    }
    closeExtension() {
        this.openSubSection(undefined);
    }
    openSubSection(subsection) {
        this.openSubSectionSubject.next(subsection);
        if (!subsection) {
            this.setExtensionWidth('0px');
        }
    }
    open() {
        this.isOpen.set(true);
        this.isOpenSubject.next(this.isOpen());
    }
    close() {
        this.isOpen.set(false);
        this.isOpenSubject.next(this.isOpen());
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

class OuiMainSidebarSubSectionComponent {
    ouiMainSidebarService;
    destroyRef;
    isSidebarOpen = signal(false);
    isOpen = signal(false);
    options = input.required();
    constructor(ouiMainSidebarService, destroyRef) {
        this.ouiMainSidebarService = ouiMainSidebarService;
        this.destroyRef = destroyRef;
    }
    onClick() {
        if (this.isOpen()) {
            this.ouiMainSidebarService.openSubSection(undefined);
        }
        else {
            this.ouiMainSidebarService.openSubSection(this);
        }
    }
    ngAfterViewInit() {
        this.ouiMainSidebarService.isOpen$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((isOpen) => {
            this.isSidebarOpen.set(isOpen);
        });
        this.ouiMainSidebarService.openSubSection$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(subSection => {
            if (subSection?.options().id === this.options().id) {
                this.isOpen.set(true);
            }
            else {
                this.isOpen.set(false);
            }
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarSubSectionComponent, deps: [{ token: OuiMainSidebarService }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiMainSidebarSubSectionComponent, isStandalone: true, selector: "oui-main-sidebar-sub-section", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<div (click)=\"onClick()\" class=\"main-sidebar-sub-section-container\" [ngClass]=\"{ open: isOpen() }\">\n  <div class=\"icon\">\n    <oui-icon\n      [options]=\"options().iconOptions ?? {}\"\n      [icon]=\"options().icon\"\n    ></oui-icon>\n  </div>\n  @if (isSidebarOpen() && options().label) {\n    <div class=\"label whitespace-nowrap\">\n      {{ options().label }}\n    </div>\n  }\n</div>\n", styles: [":host{width:100%;height:var(--oui-main-sidebar-section-height);position:relative;display:flex;justify-content:center;align-items:center;color:var(--color-primary-text);background-color:var(--oui-main-sidebar-section-background);transition:background-color .3s;margin:4px 0;white-space:nowrap}:host:hover{cursor:pointer;filter:brightness(1.25) contrast(.9)}:host:hover.active{filter:brightness(1.2) contrast(.9)}:host.active{filter:brightness(1.2) contrast(.9)}:host .main-sidebar-sub-section-container{width:100%;height:100%;display:flex;align-items:center}:host .main-sidebar-sub-section-container .label{white-space:nowrap}:host .main-sidebar-sub-section-container .icon{width:var(--oui-main-sidebar-section-width);height:var(--oui-main-sidebar-section-height);display:flex;justify-content:center;align-items:center;flex:0 0 auto}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarSubSectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-main-sidebar-sub-section', standalone: true, imports: [NgClass, OuiButtonComponent, OuiIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div (click)=\"onClick()\" class=\"main-sidebar-sub-section-container\" [ngClass]=\"{ open: isOpen() }\">\n  <div class=\"icon\">\n    <oui-icon\n      [options]=\"options().iconOptions ?? {}\"\n      [icon]=\"options().icon\"\n    ></oui-icon>\n  </div>\n  @if (isSidebarOpen() && options().label) {\n    <div class=\"label whitespace-nowrap\">\n      {{ options().label }}\n    </div>\n  }\n</div>\n", styles: [":host{width:100%;height:var(--oui-main-sidebar-section-height);position:relative;display:flex;justify-content:center;align-items:center;color:var(--color-primary-text);background-color:var(--oui-main-sidebar-section-background);transition:background-color .3s;margin:4px 0;white-space:nowrap}:host:hover{cursor:pointer;filter:brightness(1.25) contrast(.9)}:host:hover.active{filter:brightness(1.2) contrast(.9)}:host.active{filter:brightness(1.2) contrast(.9)}:host .main-sidebar-sub-section-container{width:100%;height:100%;display:flex;align-items:center}:host .main-sidebar-sub-section-container .label{white-space:nowrap}:host .main-sidebar-sub-section-container .icon{width:var(--oui-main-sidebar-section-width);height:var(--oui-main-sidebar-section-height);display:flex;justify-content:center;align-items:center;flex:0 0 auto}\n"] }]
        }], ctorParameters: () => [{ type: OuiMainSidebarService }, { type: i0.DestroyRef }] });

/**
 * Route-button for the main sidebar. Not used manually, only instantiated dynamically by the oui-main-sidebar-service
 * Options can be passed via the addRouteSection-method of the oui-main-sidebar-service.
 *
 * @Input() options: IOuiMainSidebarRouteSectionOptions
 */
class OuiMainSidebarRouteSectionComponent {
    ouiMainSidebarService = inject(OuiMainSidebarService);
    destroyRef = inject(DestroyRef);
    elementRef = inject(ElementRef);
    routerLinkActive;
    isSidebarOpen = signal(false);
    sidebarOptions = input.required();
    options = input.required();
    isDisabled = computed(() => {
        return this.options().isDisabled ?? false;
    });
    constructor() { }
    ngAfterViewInit() {
        this.updateActiveClass(this.routerLinkActive.isActive);
        this.routerLinkActive.isActiveChange.pipe(takeUntilDestroyed(this.destroyRef)).subscribe((isActive) => {
            this.updateActiveClass(isActive);
        });
        this.ouiMainSidebarService.isOpen$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((isOpen) => {
            this.isSidebarOpen.set(isOpen);
        });
    }
    onClick() {
        const optionsOnClick = this.options().onClick;
        if (optionsOnClick) {
            optionsOnClick();
        }
    }
    updateActiveClass(isActive) {
        if (isActive) {
            this.elementRef.nativeElement.classList.add('active');
        }
        else {
            this.elementRef.nativeElement.classList.remove('active');
        }
    }
    MAIN_SIDEBAR_SECTION_TYPES = MAIN_SIDEBAR_SECTION_TYPES;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarRouteSectionComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiMainSidebarRouteSectionComponent, isStandalone: true, selector: "oui-main-sidebar-route-section", inputs: { sidebarOptions: { classPropertyName: "sidebarOptions", publicName: "sidebarOptions", isSignal: true, isRequired: true, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, viewQueries: [{ propertyName: "routerLinkActive", first: true, predicate: ["routerLinkActive"], descendants: true }], ngImport: i0, template: "<a [tooltipOptions]=\"{popupOptions: {placement: 'right'}}\" ouiTooltip [tooltip]=\"options().label ?? ''\" [isTooltipDisabled]=\"!options().label || !sidebarOptions().hasTooltip || (isSidebarOpen() && options().type === MAIN_SIDEBAR_SECTION_TYPES.ROUTE)\" (click)=\"onClick()\" [routerLinkActive]=\"'active'\" [routerLink]=\"options().routeOptions.commands\" #routerLinkActive=\"routerLinkActive\" [queryParamsHandling]=\"options().routeOptions.queryParamsHandling ?? 'merge'\" [queryParams]=\"options().routeOptions.queryParams ?? {}\" class=\"main-sidebar-route-section-container\" [ngClass]=\"{ open: isSidebarOpen(), disabled: isDisabled() }\">\n  <div class=\"icon\">\n    <oui-icon\n      [options]=\"options().iconOptions ?? {}\"\n      [icon]=\"options().icon\"\n    ></oui-icon>\n  </div>\n  @if (isSidebarOpen() && options().type === MAIN_SIDEBAR_SECTION_TYPES.ROUTE) {\n    @if(options().label) {\n      <div class=\"label\">\n        {{ options().label }}\n      </div>\n    } @else {\n      <div class=\"label\"></div>\n    }\n  }\n</a>\n", styles: [":host{width:100%;height:var(--oui-main-sidebar-section-height);position:relative;display:flex;justify-content:center;align-items:center;color:var(--color-primary-text);margin:4px 0;white-space:nowrap;border-radius:var(--border-radius-default)}:host:hover{cursor:pointer;filter:brightness(1.25) contrast(.9)}:host:hover.active{filter:brightness(1.2) contrast(.9)}:host.active{filter:brightness(1.2) contrast(.9)}:host .main-sidebar-route-section-container{width:100%;height:100%;display:flex;align-items:center;justify-content:flex-start;border-radius:var(--border-radius-default);background-color:var(--oui-main-sidebar-section-background);transition:background-color .3s}:host .main-sidebar-route-section-container.disabled{opacity:.6;pointer-events:none;touch-action:none;cursor:default}:host .main-sidebar-route-section-container.disabled:hover{cursor:default}:host .main-sidebar-route-section-container .icon{width:var(--oui-main-sidebar-section-width);height:var(--oui-main-sidebar-section-height);display:flex;justify-content:center;align-items:center;flex:0 0 auto}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "directive", type: RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }, { kind: "directive", type: RouterLinkActive, selector: "[routerLinkActive]", inputs: ["routerLinkActiveOptions", "ariaCurrentWhenActive", "routerLinkActive"], outputs: ["isActiveChange"], exportAs: ["routerLinkActive"] }, { kind: "directive", type: OuiTooltipDirective, selector: "[ouiTooltip]", inputs: ["component", "inputs", "isTooltipDisabled", "tooltip", "tooltipOptions"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarRouteSectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-main-sidebar-route-section', standalone: true, imports: [
                        NgClass,
                        OuiIconComponent,
                        RouterLink,
                        RouterLinkActive,
                        OuiTooltipDirective,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<a [tooltipOptions]=\"{popupOptions: {placement: 'right'}}\" ouiTooltip [tooltip]=\"options().label ?? ''\" [isTooltipDisabled]=\"!options().label || !sidebarOptions().hasTooltip || (isSidebarOpen() && options().type === MAIN_SIDEBAR_SECTION_TYPES.ROUTE)\" (click)=\"onClick()\" [routerLinkActive]=\"'active'\" [routerLink]=\"options().routeOptions.commands\" #routerLinkActive=\"routerLinkActive\" [queryParamsHandling]=\"options().routeOptions.queryParamsHandling ?? 'merge'\" [queryParams]=\"options().routeOptions.queryParams ?? {}\" class=\"main-sidebar-route-section-container\" [ngClass]=\"{ open: isSidebarOpen(), disabled: isDisabled() }\">\n  <div class=\"icon\">\n    <oui-icon\n      [options]=\"options().iconOptions ?? {}\"\n      [icon]=\"options().icon\"\n    ></oui-icon>\n  </div>\n  @if (isSidebarOpen() && options().type === MAIN_SIDEBAR_SECTION_TYPES.ROUTE) {\n    @if(options().label) {\n      <div class=\"label\">\n        {{ options().label }}\n      </div>\n    } @else {\n      <div class=\"label\"></div>\n    }\n  }\n</a>\n", styles: [":host{width:100%;height:var(--oui-main-sidebar-section-height);position:relative;display:flex;justify-content:center;align-items:center;color:var(--color-primary-text);margin:4px 0;white-space:nowrap;border-radius:var(--border-radius-default)}:host:hover{cursor:pointer;filter:brightness(1.25) contrast(.9)}:host:hover.active{filter:brightness(1.2) contrast(.9)}:host.active{filter:brightness(1.2) contrast(.9)}:host .main-sidebar-route-section-container{width:100%;height:100%;display:flex;align-items:center;justify-content:flex-start;border-radius:var(--border-radius-default);background-color:var(--oui-main-sidebar-section-background);transition:background-color .3s}:host .main-sidebar-route-section-container.disabled{opacity:.6;pointer-events:none;touch-action:none;cursor:default}:host .main-sidebar-route-section-container.disabled:hover{cursor:default}:host .main-sidebar-route-section-container .icon{width:var(--oui-main-sidebar-section-width);height:var(--oui-main-sidebar-section-height);display:flex;justify-content:center;align-items:center;flex:0 0 auto}\n"] }]
        }], ctorParameters: () => [], propDecorators: { routerLinkActive: [{
                type: ViewChild,
                args: ['routerLinkActive']
            }] } });

/**
 * Action-section for the main sidebar. Not used manually, only instantiated dynamically by the oui-main-sidebar-service
 * Options can be passed via the addActionSection-method of the oui-main-sidebar-service.
 *
 * @Input() options: IOuiMainSidebarActionSectionOptions
 */
class OuiMainSidebarActionSectionComponent {
    ouiMainSidebarService;
    destroyRef;
    subSubSection;
    componentContainerVCR;
    options = input.required();
    isOpen = signal(false);
    constructor(ouiMainSidebarService, destroyRef) {
        this.ouiMainSidebarService = ouiMainSidebarService;
        this.destroyRef = destroyRef;
    }
    onClick() {
        this.options().onClick();
    }
    ngAfterViewInit() {
        this.ouiMainSidebarService.isOpen$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((isOpen) => {
            this.isOpen.set(isOpen);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarActionSectionComponent, deps: [{ token: OuiMainSidebarService }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiMainSidebarActionSectionComponent, isStandalone: true, selector: "oui-main-sidebar-action-section", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null } }, viewQueries: [{ propertyName: "subSubSection", first: true, predicate: ["subSubSection"], descendants: true }, { propertyName: "componentContainerVCR", first: true, predicate: ["componentContainer"], descendants: true, read: ViewContainerRef }], ngImport: i0, template: "<div class=\"main-sidebar-sub-section-container\" (click)=onClick() [ngClass]=\"{ open: isOpen(), active: options().isActive }\">\n  <div class=\"icon\">\n    <oui-icon\n      [options]=\"options().iconOptions ?? {}\"\n      [icon]=\"options().icon\"\n    ></oui-icon>\n  </div>\n  @if (isOpen()) {\n    <div class=\"label\">\n      {{ options().label }}\n    </div>\n  }\n</div>\n", styles: [":host{width:100%;height:var(--oui-main-sidebar-section-height);position:relative;display:flex;justify-content:center;align-items:center;color:var(--color-primary-text);margin:4px 0;white-space:nowrap;border-radius:var(--border-radius-default)}:host:hover{cursor:pointer;filter:brightness(1.25) contrast(.9)}:host:hover.active{filter:brightness(1.2) contrast(.9)}:host.active{filter:brightness(1.2) contrast(.9)}:host .main-sidebar-sub-section-container{width:100%;height:100%;display:flex;align-items:center;background-color:var(--oui-main-sidebar-section-background);transition:background-color .3s}:host .main-sidebar-sub-section-container .label{white-space:nowrap}:host .main-sidebar-sub-section-container .icon{width:var(--oui-main-sidebar-section-width);height:var(--oui-main-sidebar-section-height);display:flex;justify-content:center;align-items:center;flex:0 0 auto}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarActionSectionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-main-sidebar-action-section', standalone: true, imports: [NgClass, OuiIconComponent], template: "<div class=\"main-sidebar-sub-section-container\" (click)=onClick() [ngClass]=\"{ open: isOpen(), active: options().isActive }\">\n  <div class=\"icon\">\n    <oui-icon\n      [options]=\"options().iconOptions ?? {}\"\n      [icon]=\"options().icon\"\n    ></oui-icon>\n  </div>\n  @if (isOpen()) {\n    <div class=\"label\">\n      {{ options().label }}\n    </div>\n  }\n</div>\n", styles: [":host{width:100%;height:var(--oui-main-sidebar-section-height);position:relative;display:flex;justify-content:center;align-items:center;color:var(--color-primary-text);margin:4px 0;white-space:nowrap;border-radius:var(--border-radius-default)}:host:hover{cursor:pointer;filter:brightness(1.25) contrast(.9)}:host:hover.active{filter:brightness(1.2) contrast(.9)}:host.active{filter:brightness(1.2) contrast(.9)}:host .main-sidebar-sub-section-container{width:100%;height:100%;display:flex;align-items:center;background-color:var(--oui-main-sidebar-section-background);transition:background-color .3s}:host .main-sidebar-sub-section-container .label{white-space:nowrap}:host .main-sidebar-sub-section-container .icon{width:var(--oui-main-sidebar-section-width);height:var(--oui-main-sidebar-section-height);display:flex;justify-content:center;align-items:center;flex:0 0 auto}\n"] }]
        }], ctorParameters: () => [{ type: OuiMainSidebarService }, { type: i0.DestroyRef }], propDecorators: { subSubSection: [{
                type: ViewChild,
                args: ['subSubSection']
            }], componentContainerVCR: [{
                type: ViewChild,
                args: ['componentContainer', {
                        read: ViewContainerRef,
                    }]
            }] } });

class IsRouteSectionOptionsPipe {
    transform(value) {
        return (value.type === MAIN_SIDEBAR_SECTION_TYPES.ROUTE ||
            value.type === MAIN_SIDEBAR_SECTION_TYPES.SUBROUTE);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsRouteSectionOptionsPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: IsRouteSectionOptionsPipe, isStandalone: true, name: "isRouteSectionOptions" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsRouteSectionOptionsPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'isRouteSectionOptions',
                    standalone: true,
                }]
        }] });
class IsActionSectionOptionsPipe {
    transform(value) {
        return value.type === MAIN_SIDEBAR_SECTION_TYPES.ACTION;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsActionSectionOptionsPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: IsActionSectionOptionsPipe, isStandalone: true, name: "isActionSectionOptions" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsActionSectionOptionsPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'isActionSectionOptions',
                    standalone: true,
                }]
        }] });
class IsSubSectionOptionsPipe {
    transform(value) {
        return value.type === MAIN_SIDEBAR_SECTION_TYPES.SUBSECTION;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsSubSectionOptionsPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: IsSubSectionOptionsPipe, isStandalone: true, name: "isSubsectionOptions" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsSubSectionOptionsPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'isSubsectionOptions',
                    standalone: true,
                }]
        }] });

class MainSidebarSubMenuComponent {
    elementRef = inject(ElementRef);
    router = inject(Router);
    destroyRef = inject(DestroyRef);
    activeParentRoute = input.required();
    sidebarOptions = input.required();
    activeChildRoute = signal(undefined);
    constructor() {
        effect(() => {
            const hasChildren = !!this.activeParentRoute().children?.routes?.length;
            if (hasChildren) {
                this.elementRef.nativeElement.classList.add('active');
            }
            else {
                this.elementRef.nativeElement.classList.remove('active');
            }
        });
        this.router.events
            .pipe(filter((event) => event instanceof NavigationEnd), takeUntilDestroyed(this.destroyRef))
            .subscribe(navigationEndEvent => {
            console.log(navigationEndEvent);
            this.setActiveRoute(navigationEndEvent.url);
        });
    }
    ngAfterViewInit() {
        this.setActiveRoute(this.router.url);
    }
    setActiveRoute(currentUrl) {
        const children = this.activeParentRoute().children;
        if (children?.routes) {
            this.activeChildRoute.set(children?.routes.find(sectionOptions => {
                return currentUrl.includes(sectionOptions.routeOptions?.commands.join('/'));
            }));
            console.log(this.activeChildRoute());
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: MainSidebarSubMenuComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: MainSidebarSubMenuComponent, isStandalone: true, selector: "oui-main-sidebar-sub-menu", inputs: { activeParentRoute: { classPropertyName: "activeParentRoute", publicName: "activeParentRoute", isSignal: true, isRequired: true, transformFunction: null }, sidebarOptions: { classPropertyName: "sidebarOptions", publicName: "sidebarOptions", isSignal: true, isRequired: true, transformFunction: null } }, ngImport: i0, template: "<div class=\"main-sidebar-route-extension-inner-container\" [ngClass]=\"activeParentRoute().children?.options?.className ?? ''\" [ngStyle]=\"{backgroundColor: activeParentRoute().children?.options?.backgroundColor ?? 'var(--color-background-primary)'}\">\n  <div class=\"route-container\">\n    @for(childOption of activeParentRoute().children?.routes; track childOption.id) {\n      <oui-main-sidebar-route-section [ngStyle]=\"{backgroundColor: activeParentRoute().children?.options?.backgroundColor ?? 'var(--color-background-primary)'}\" [sidebarOptions]=\"sidebarOptions()\" [options]=\"childOption\"></oui-main-sidebar-route-section>\n    }\n  </div>\n\n  @if(activeChildRoute(); as activeChildRoute) {\n    @if(activeChildRoute.children?.routes) {\n      <oui-main-sidebar-sub-menu [sidebarOptions]=\"sidebarOptions()\" [activeParentRoute]=\"activeChildRoute\"></oui-main-sidebar-sub-menu>\n    }\n  }\n</div>\n", styles: [":host{position:absolute;left:0;bottom:0;z-index:2;pointer-events:none;min-width:0;transition:width .3s,left .3s;box-sizing:border-box;display:flex}:host .main-sidebar-route-extension-inner-container{display:flex}:host .main-sidebar-route-extension-inner-container .route-container{display:flex;flex-direction:column;padding:20px 12px 0;border-right:1px solid rgba(80,80,80,.3)}:host.active{position:relative;min-width:var(--oui-main-sidebar-width);pointer-events:all}\n"], dependencies: [{ kind: "component", type: MainSidebarSubMenuComponent, selector: "oui-main-sidebar-sub-menu", inputs: ["activeParentRoute", "sidebarOptions"] }, { kind: "component", type: OuiMainSidebarRouteSectionComponent, selector: "oui-main-sidebar-route-section", inputs: ["sidebarOptions", "options"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: MainSidebarSubMenuComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-main-sidebar-sub-menu', imports: [
                        OuiMainSidebarRouteSectionComponent,
                        NgStyle,
                        NgClass,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, standalone: true, template: "<div class=\"main-sidebar-route-extension-inner-container\" [ngClass]=\"activeParentRoute().children?.options?.className ?? ''\" [ngStyle]=\"{backgroundColor: activeParentRoute().children?.options?.backgroundColor ?? 'var(--color-background-primary)'}\">\n  <div class=\"route-container\">\n    @for(childOption of activeParentRoute().children?.routes; track childOption.id) {\n      <oui-main-sidebar-route-section [ngStyle]=\"{backgroundColor: activeParentRoute().children?.options?.backgroundColor ?? 'var(--color-background-primary)'}\" [sidebarOptions]=\"sidebarOptions()\" [options]=\"childOption\"></oui-main-sidebar-route-section>\n    }\n  </div>\n\n  @if(activeChildRoute(); as activeChildRoute) {\n    @if(activeChildRoute.children?.routes) {\n      <oui-main-sidebar-sub-menu [sidebarOptions]=\"sidebarOptions()\" [activeParentRoute]=\"activeChildRoute\"></oui-main-sidebar-sub-menu>\n    }\n  }\n</div>\n", styles: [":host{position:absolute;left:0;bottom:0;z-index:2;pointer-events:none;min-width:0;transition:width .3s,left .3s;box-sizing:border-box;display:flex}:host .main-sidebar-route-extension-inner-container{display:flex}:host .main-sidebar-route-extension-inner-container .route-container{display:flex;flex-direction:column;padding:20px 12px 0;border-right:1px solid rgba(80,80,80,.3)}:host.active{position:relative;min-width:var(--oui-main-sidebar-width);pointer-events:all}\n"] }]
        }], ctorParameters: () => [] });

/**
 * Component to create a main-sidebar for an application. Essentially an abstraction to create a sidebar that can contain
 * other predefined components inside of it. These include either buttons that trigger routing (so links to subpages),
 * buttons that trigger simple actions, buttons that trigger an extension to the sidebar with custom content inside of it, or
 * if really desired, an entire custom component. Sidebar is currently only functional as a left-attached sidebar.
 *
 * This component really only functions as a wrapper, and actual content is added via OuiMainSidebarService.
 * In other words, this component should be only be initialised with options, and the content should be entirely managed
 * via the service. By default the sidebar is left-attached with a relative positioning and a width of 250px;
 *
 * @Input() options: IOuiMainSidebarOptions
 *
 * Example use:
 *
 *  <div class="main-container">
 *    <oui-main-header></oui-main-header>
 *    <oui-main-sidebar></oui-main-sidebar>
 *    <router-outlet></router-outlet>
 *  </div>
 */
class OuiMainSidebarComponent {
    ouiMainSidebarService = inject(OuiMainSidebarService);
    elementRef = inject(ElementRef);
    destroyRef = inject(DestroyRef);
    router = inject(Router);
    sidebarContainer;
    sidebarSubsectionContainer;
    componentContainerVCR;
    gestureOptions = {
        swipe: {
            velocityThreshold: 0,
            onSwipe: event => {
                if (this.options().swipeToClose && IsTabletOrMobile()) {
                    if (this.options().side === 'left' && event.type === 'left') {
                        this.ouiMainSidebarService.close();
                    }
                }
            },
        },
    };
    options = input.required();
    sections = input.required();
    isOpen = model(false);
    defaultOptions = {
        width: '250px',
        positioning: 'relative',
        side: 'left',
        hasTooltip: true,
    };
    combinedOptions = computed(() => {
        return merge({
            ...this.defaultOptions,
            ...this.options(),
        });
    });
    activeRouteSectionOptions = signal(undefined);
    activeRouteSectionChildren = computed(() => {
        return this.activeRouteSectionOptions()?.children?.routes ?? [];
    });
    constructor() { }
    toggle() {
        if (this.isOpen()) {
            this.ouiMainSidebarService.close();
        }
        else {
            this.ouiMainSidebarService.open();
        }
    }
    ngAfterViewInit() {
        if (this.isOpen()) {
            this.ouiMainSidebarService.open();
        }
        this.setActiveRoute(this.router.url);
        this.router.events
            .pipe(filter((event) => event instanceof NavigationEnd), takeUntilDestroyed(this.destroyRef))
            .subscribe(navigationEndEvent => {
            this.setActiveRoute(navigationEndEvent.url);
        });
        this.ouiMainSidebarService.isOpen$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((isOpen) => {
            this.isOpen.set(isOpen);
            if (this.isOpen()) {
                this.elementRef.nativeElement.classList.add('open');
            }
            else {
                this.elementRef.nativeElement.classList.remove('open');
            }
        });
    }
    setActiveRoute(currentUrl) {
        const routeSectionOptions = this.sections().filter(section => section.type === MAIN_SIDEBAR_SECTION_TYPES.ROUTE);
        if (routeSectionOptions.length) {
            this.activeRouteSectionOptions.set(routeSectionOptions.find(sectionOptions => {
                return currentUrl.includes(sectionOptions.routeOptions?.commands.join('/'));
            }));
        }
    }
    MAIN_SIDEBAR_SECTION_TYPES = MAIN_SIDEBAR_SECTION_TYPES;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiMainSidebarComponent, isStandalone: true, selector: "oui-main-sidebar", inputs: { options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: true, transformFunction: null }, sections: { classPropertyName: "sections", publicName: "sections", isSignal: true, isRequired: true, transformFunction: null }, isOpen: { classPropertyName: "isOpen", publicName: "isOpen", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { isOpen: "isOpenChange" }, viewQueries: [{ propertyName: "sidebarContainer", first: true, predicate: ["sidebarContainer"], descendants: true }, { propertyName: "sidebarSubsectionContainer", first: true, predicate: ["sidebarSubsectionContainer"], descendants: true }, { propertyName: "componentContainerVCR", first: true, predicate: ["componentContainer"], descendants: true, read: ViewContainerRef }], ngImport: i0, template: "<div class=\"main-sidebar-container\" #sidebarContainer oui-gestures [gestureOptions]=\"gestureOptions\">\n  <div class=\"main-sidebar-inner-container\" [ngClass]=\"{routeExtensionActive: activeRouteSectionChildren().length}\">\n    <div class=\"main-sidebar-content-container\">\n      <div class=\"main-sidebar-content-section-container\">\n        @for(option of sections(); track option.id) {\n          @if(option | isRouteSectionOptions) {\n            <oui-main-sidebar-route-section [ngStyle]=\"{backgroundColor: 'var(--oui-main-sidebar-background)'}\" [sidebarOptions]=\"combinedOptions()\" [options]=\"option\"></oui-main-sidebar-route-section>\n          } @else if (option | isSubsectionOptions) {\n            <oui-main-sidebar-sub-section [ngStyle]=\"{backgroundColor: 'var(--oui-main-sidebar-background)'}\" [options]=\"option\"></oui-main-sidebar-sub-section>\n          } @else if (option | isActionSectionOptions) {\n            <oui-main-sidebar-action-section [ngStyle]=\"{backgroundColor: 'var(--oui-main-sidebar-background)'}\" [options]=\"option\"></oui-main-sidebar-action-section>\n          }\n        }\n        <ng-container #componentContainer></ng-container>\n      </div>\n    </div>\n    @if (!combinedOptions().disableToggle) {\n      <div\n        (click)=\"toggle()\"\n        class=\"main-sidebar-bottom-container\"\n        [ngClass]=\"{ 'is-open': this.isOpen() }\"\n        >\n        <oui-icon\n        [options]=\"{\n          viewBox: '0 0 48 48',\n          fillColor: 'oui-main-sidebar-text-color',\n          strokeColor: 'oui-main-sidebar-text-color',\n          size: '24px'\n        }\"\n          [icon]=\"'assets/icons/double_caret_right.svg'\"\n        ></oui-icon>\n      </div>\n    }\n  </div >\n  @if(activeRouteSectionOptions(); as activeRouteOptions) {\n    <oui-main-sidebar-sub-menu [sidebarOptions]=\"combinedOptions()\" [activeParentRoute]=\"activeRouteOptions\"></oui-main-sidebar-sub-menu>\n  }\n\n</div>\n", styles: [":host{position:relative;height:100%;z-index:999;overflow-x:hidden;transition:width .3s;display:block}:host.open .main-sidebar-container .main-sidebar-inner-container{width:var(--oui-main-sidebar-open-width)}:host .main-sidebar-container{position:relative;width:100%;transition:width .3s,padding .3s;box-shadow:var(--box-shadow-right);height:100%;z-index:999;background:var(--oui-main-sidebar-background);display:flex}:host .main-sidebar-container .main-sidebar-route-extension-container{transition:width .3s,padding .3s;will-change:width;width:0;background-color:var(--color-background-primary);display:flex;flex-direction:column;align-items:center;box-sizing:border-box;padding:0}:host .main-sidebar-container .main-sidebar-route-extension-container.active{padding:2rem;width:var(--oui-main-sidebar-width)}:host .main-sidebar-container .main-sidebar-inner-container{display:flex;flex-direction:column;position:relative;padding:20px 12px 0;flex:1;width:var(--oui-main-sidebar-width);box-sizing:border-box;transition:width .3s;will-change:width;box-shadow:var(--box-shadow-right)}:host .main-sidebar-container .main-sidebar-inner-container.routeExtensionActive{box-shadow:var(--box-shadow-right)}:host .main-sidebar-container .main-sidebar-inner-container .main-sidebar-content-container{z-index:2;display:flex}:host .main-sidebar-container .main-sidebar-inner-container .main-sidebar-content-container .main-sidebar-content-section-container{flex:1;display:flex;flex-direction:column;overflow-x:hidden}:host .main-sidebar-container .main-sidebar-inner-container .main-sidebar-header-container{z-index:2;background:var(--oui-main-sidebar-background)}:host .main-sidebar-container .main-sidebar-inner-container .main-sidebar-bottom-container{flex:0 0 60px;z-index:2;background:var(--oui-main-sidebar-toggle-background);display:flex;margin:0 -12px;justify-content:center;align-items:center;border-top:1px solid var(--border-color-background-light);transition:background-color .3s}:host .main-sidebar-container .main-sidebar-inner-container .main-sidebar-bottom-container oui-icon{transform:rotate(0);transition:transform .4s}:host .main-sidebar-container .main-sidebar-inner-container .main-sidebar-bottom-container.is-open oui-icon{transform:rotate(180deg)}:host .main-sidebar-container .main-sidebar-inner-container .main-sidebar-bottom-container:hover{cursor:pointer;background-color:var(--oui-main-sidebar-section-background-hover)}:host .main-sidebar-container .main-sidebar-subsections-container{position:absolute;height:100%;left:0;width:0;z-index:1;pointer-events:none;transition:width .3s,left .3s;background-color:var(--color-background)}:host .main-sidebar-container .main-sidebar-header-container{flex:0 0 10%}:host .main-sidebar-container .main-sidebar-content-container{flex:1}:host .main-sidebar-container .main-sidebar-content-container .main-sidebar-content-section-content{height:50px;width:50px;display:flex;justify-content:center;align-items:center}:host .main-sidebar-container .main-sidebar-content-container .main-sidebar-content-section-content:hover{cursor:pointer}\n"], dependencies: [{ kind: "component", type: OuiMainSidebarSubSectionComponent, selector: "oui-main-sidebar-sub-section", inputs: ["options"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "directive", type: OuiGesturesDirective, selector: "[oui-gestures]", inputs: ["gestureOptions"] }, { kind: "component", type: OuiMainSidebarRouteSectionComponent, selector: "oui-main-sidebar-route-section", inputs: ["sidebarOptions", "options"] }, { kind: "pipe", type: IsRouteSectionOptionsPipe, name: "isRouteSectionOptions" }, { kind: "pipe", type: IsActionSectionOptionsPipe, name: "isActionSectionOptions" }, { kind: "pipe", type: IsSubSectionOptionsPipe, name: "isSubsectionOptions" }, { kind: "component", type: OuiMainSidebarActionSectionComponent, selector: "oui-main-sidebar-action-section", inputs: ["options"] }, { kind: "component", type: MainSidebarSubMenuComponent, selector: "oui-main-sidebar-sub-menu", inputs: ["activeParentRoute", "sidebarOptions"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-main-sidebar', standalone: true, imports: [
                        OuiMainSidebarSubSectionComponent,
                        CommonModule,
                        OuiButtonComponent,
                        OuiIconComponent,
                        OuiIconButtonComponent,
                        OuiRippleDirective,
                        OuiGesturesDirective,
                        OuiMainSidebarRouteSectionComponent,
                        IsRouteSectionOptionsPipe,
                        IsActionSectionOptionsPipe,
                        IsSubSectionOptionsPipe,
                        OuiMainSidebarActionSectionComponent,
                        MainSidebarSubMenuComponent,
                    ], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"main-sidebar-container\" #sidebarContainer oui-gestures [gestureOptions]=\"gestureOptions\">\n  <div class=\"main-sidebar-inner-container\" [ngClass]=\"{routeExtensionActive: activeRouteSectionChildren().length}\">\n    <div class=\"main-sidebar-content-container\">\n      <div class=\"main-sidebar-content-section-container\">\n        @for(option of sections(); track option.id) {\n          @if(option | isRouteSectionOptions) {\n            <oui-main-sidebar-route-section [ngStyle]=\"{backgroundColor: 'var(--oui-main-sidebar-background)'}\" [sidebarOptions]=\"combinedOptions()\" [options]=\"option\"></oui-main-sidebar-route-section>\n          } @else if (option | isSubsectionOptions) {\n            <oui-main-sidebar-sub-section [ngStyle]=\"{backgroundColor: 'var(--oui-main-sidebar-background)'}\" [options]=\"option\"></oui-main-sidebar-sub-section>\n          } @else if (option | isActionSectionOptions) {\n            <oui-main-sidebar-action-section [ngStyle]=\"{backgroundColor: 'var(--oui-main-sidebar-background)'}\" [options]=\"option\"></oui-main-sidebar-action-section>\n          }\n        }\n        <ng-container #componentContainer></ng-container>\n      </div>\n    </div>\n    @if (!combinedOptions().disableToggle) {\n      <div\n        (click)=\"toggle()\"\n        class=\"main-sidebar-bottom-container\"\n        [ngClass]=\"{ 'is-open': this.isOpen() }\"\n        >\n        <oui-icon\n        [options]=\"{\n          viewBox: '0 0 48 48',\n          fillColor: 'oui-main-sidebar-text-color',\n          strokeColor: 'oui-main-sidebar-text-color',\n          size: '24px'\n        }\"\n          [icon]=\"'assets/icons/double_caret_right.svg'\"\n        ></oui-icon>\n      </div>\n    }\n  </div >\n  @if(activeRouteSectionOptions(); as activeRouteOptions) {\n    <oui-main-sidebar-sub-menu [sidebarOptions]=\"combinedOptions()\" [activeParentRoute]=\"activeRouteOptions\"></oui-main-sidebar-sub-menu>\n  }\n\n</div>\n", styles: [":host{position:relative;height:100%;z-index:999;overflow-x:hidden;transition:width .3s;display:block}:host.open .main-sidebar-container .main-sidebar-inner-container{width:var(--oui-main-sidebar-open-width)}:host .main-sidebar-container{position:relative;width:100%;transition:width .3s,padding .3s;box-shadow:var(--box-shadow-right);height:100%;z-index:999;background:var(--oui-main-sidebar-background);display:flex}:host .main-sidebar-container .main-sidebar-route-extension-container{transition:width .3s,padding .3s;will-change:width;width:0;background-color:var(--color-background-primary);display:flex;flex-direction:column;align-items:center;box-sizing:border-box;padding:0}:host .main-sidebar-container .main-sidebar-route-extension-container.active{padding:2rem;width:var(--oui-main-sidebar-width)}:host .main-sidebar-container .main-sidebar-inner-container{display:flex;flex-direction:column;position:relative;padding:20px 12px 0;flex:1;width:var(--oui-main-sidebar-width);box-sizing:border-box;transition:width .3s;will-change:width;box-shadow:var(--box-shadow-right)}:host .main-sidebar-container .main-sidebar-inner-container.routeExtensionActive{box-shadow:var(--box-shadow-right)}:host .main-sidebar-container .main-sidebar-inner-container .main-sidebar-content-container{z-index:2;display:flex}:host .main-sidebar-container .main-sidebar-inner-container .main-sidebar-content-container .main-sidebar-content-section-container{flex:1;display:flex;flex-direction:column;overflow-x:hidden}:host .main-sidebar-container .main-sidebar-inner-container .main-sidebar-header-container{z-index:2;background:var(--oui-main-sidebar-background)}:host .main-sidebar-container .main-sidebar-inner-container .main-sidebar-bottom-container{flex:0 0 60px;z-index:2;background:var(--oui-main-sidebar-toggle-background);display:flex;margin:0 -12px;justify-content:center;align-items:center;border-top:1px solid var(--border-color-background-light);transition:background-color .3s}:host .main-sidebar-container .main-sidebar-inner-container .main-sidebar-bottom-container oui-icon{transform:rotate(0);transition:transform .4s}:host .main-sidebar-container .main-sidebar-inner-container .main-sidebar-bottom-container.is-open oui-icon{transform:rotate(180deg)}:host .main-sidebar-container .main-sidebar-inner-container .main-sidebar-bottom-container:hover{cursor:pointer;background-color:var(--oui-main-sidebar-section-background-hover)}:host .main-sidebar-container .main-sidebar-subsections-container{position:absolute;height:100%;left:0;width:0;z-index:1;pointer-events:none;transition:width .3s,left .3s;background-color:var(--color-background)}:host .main-sidebar-container .main-sidebar-header-container{flex:0 0 10%}:host .main-sidebar-container .main-sidebar-content-container{flex:1}:host .main-sidebar-container .main-sidebar-content-container .main-sidebar-content-section-content{height:50px;width:50px;display:flex;justify-content:center;align-items:center}:host .main-sidebar-container .main-sidebar-content-container .main-sidebar-content-section-content:hover{cursor:pointer}\n"] }]
        }], ctorParameters: () => [], propDecorators: { sidebarContainer: [{
                type: ViewChild,
                args: ['sidebarContainer']
            }], sidebarSubsectionContainer: [{
                type: ViewChild,
                args: ['sidebarSubsectionContainer']
            }], componentContainerVCR: [{
                type: ViewChild,
                args: ['componentContainer', {
                        read: ViewContainerRef,
                    }]
            }] } });

/**
 * A bit of a special-usecase component to be used in conjunction with the oui-main-sidebar and oui-main-sidebar-service.
 * This can be positioned anywhere in the application, and when a subSectionComponent on the main sidebar is clicked,
 * the dynamic content defined by that subsection gets injected here, and this component expands to the width/height of the dynamic content.
 * Right now only works properly horizontally. Not super well generalized, so will probably need some tweaking to get working.
 */
class OuiMainSidebarExtensionComponent {
    ouiMainSidebarService;
    elementRef;
    cdr;
    destroyRef;
    content;
    isOpen = signal(false);
    innerComponentRef = null;
    constructor(ouiMainSidebarService, elementRef, cdr, destroyRef) {
        this.ouiMainSidebarService = ouiMainSidebarService;
        this.elementRef = elementRef;
        this.cdr = cdr;
        this.destroyRef = destroyRef;
    }
    ngAfterViewInit() {
        this.ouiMainSidebarService.extensionWidth$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(data => {
            if (this.innerComponentRef) {
                this.elementRef.nativeElement.style.width = data.width;
            }
        });
        this.ouiMainSidebarService.sectionClosed$
            .pipe(filter((section) => {
            return section instanceof OuiMainSidebarSubSectionComponent;
        }), takeUntilDestroyed(this.destroyRef))
            .subscribe(() => {
            this.close();
        });
        this.ouiMainSidebarService.openSubSection$
            .pipe(delay(1), takeUntilDestroyed(this.destroyRef))
            .subscribe((section) => {
            if (section) {
                if (this.innerComponentRef) {
                    this.innerComponentRef?.destroy();
                }
                this.elementRef.nativeElement.classList.add('open');
                this.elementRef.nativeElement.style.opacity = '1';
                this.isOpen.set(true);
                const component = section.options().component;
                this.innerComponentRef = this.content.createComponent(section.options().component);
                for (const input in section.options().inputs) {
                    this.innerComponentRef.instance[input] =
                        section.options().inputs[input];
                }
                // TODO: For now works, but if content takes longer to load this will break. Need to implement a way to signal when a content is loaded.
                setTimeout(() => {
                    if (this.innerComponentRef) {
                        // const innerWidth = getComputedStyle(this.innerComponentRef.location.nativeElement).width ?? (this.innerComponentRef.location.nativeElement.offsetWidth);
                        // this.elementRef.nativeElement.style.width = innerWidth;
                        // this.elementRef.nativeElement.style.transform = `scaleX(1)`;
                    }
                });
                this.cdr.detectChanges();
            }
            else {
                this.close();
            }
        });
    }
    close() {
        // this.elementRef.nativeElement.style.transform = 'scaleX(0)';
        this.elementRef.nativeElement.style.width = '0';
        this.elementRef.nativeElement.style.opacity = '0';
        this.isOpen.set(false);
        setTimeout(() => {
            if (!this.isOpen()) {
                this.elementRef.nativeElement.classList.remove('open');
                this.innerComponentRef?.destroy();
                this.innerComponentRef = null;
            }
        }, 300);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarExtensionComponent, deps: [{ token: OuiMainSidebarService }, { token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiMainSidebarExtensionComponent, isStandalone: true, selector: "oui-main-sidebar-extension", viewQueries: [{ propertyName: "content", first: true, predicate: ["content"], descendants: true, read: ViewContainerRef }], ngImport: i0, template: "<div\n  class=\"oui-main-sidebar-extension-container\"\n  [ngClass]=\"{ 'is-open': isOpen() }\"\n>\n  <ng-container #content></ng-container>\n</div>\n", styles: [":host{transition:max-width 2s,width .3s,transform .3s,opacity .5s;overflow:hidden;position:absolute;top:0;left:0;height:100%;transform-origin:left;width:0;will-change:width}:host.open{margin-right:10px}:host .oui-main-sidebar-extension-container{flex:1;height:100%;padding:var(--oui-main-sidebar-extension-padding);background-color:var(--oui-main-sidebar-extension-background-color)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiMainSidebarExtensionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-main-sidebar-extension', standalone: true, imports: [OuiMainSidebarSubSectionComponent, CommonModule], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div\n  class=\"oui-main-sidebar-extension-container\"\n  [ngClass]=\"{ 'is-open': isOpen() }\"\n>\n  <ng-container #content></ng-container>\n</div>\n", styles: [":host{transition:max-width 2s,width .3s,transform .3s,opacity .5s;overflow:hidden;position:absolute;top:0;left:0;height:100%;transform-origin:left;width:0;will-change:width}:host.open{margin-right:10px}:host .oui-main-sidebar-extension-container{flex:1;height:100%;padding:var(--oui-main-sidebar-extension-padding);background-color:var(--oui-main-sidebar-extension-background-color)}\n"] }]
        }], ctorParameters: () => [{ type: OuiMainSidebarService }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i0.DestroyRef }], propDecorators: { content: [{
                type: ViewChild,
                args: ['content', {
                        read: ViewContainerRef,
                    }]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { MAIN_SIDEBAR_SECTION_TYPES, OuiMainSidebarActionSectionComponent, OuiMainSidebarComponent, OuiMainSidebarExtensionComponent, OuiMainSidebarRouteSectionComponent, OuiMainSidebarService, OuiMainSidebarSubSectionComponent };
//# sourceMappingURL=orbital-ui-main-sidebar.mjs.map
