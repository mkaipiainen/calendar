import * as i0 from '@angular/core';
import { Injectable, Component, ViewChild, Input, input, computed, signal, effect, ChangeDetectionStrategy, ContentChildren } from '@angular/core';
import { GUID } from 'orbital-ui/helpers';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { NgClass, NgTemplateOutlet } from '@angular/common';
import { ReplaySubject, filter } from 'rxjs';
import * as i2 from '@angular/router';
import { merge } from 'lodash-es';

class OuiTabsService {
    tabSelectedSubject = new ReplaySubject(1);
    tabSelected$ = this.tabSelectedSubject.asObservable();
    tabs = {};
    constructor() { }
    registerTabs(tabs) {
        this.tabs[tabs.id] = tabs;
    }
    selectTab(givenTab) {
        if (typeof givenTab === 'string') {
            for (const key in this.tabs) {
                const tabs = this.tabs[key];
                for (const tab of tabs.tabs.toArray()) {
                    if (tab.id === givenTab) {
                        this.tabSelectedSubject.next(tab);
                        return;
                    }
                }
            }
        }
        else {
            this.tabSelectedSubject.next(givenTab);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTabsService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTabsService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTabsService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

class OuiTabComponent {
    tabService;
    elementRef;
    cdr;
    destroyRef;
    router;
    titleTemplate;
    tabContentTemplate;
    title;
    tabTitleTemplate;
    parentId;
    id = GUID();
    disabled = false;
    isActive = false;
    options;
    constructor(tabService, elementRef, cdr, destroyRef, router) {
        this.tabService = tabService;
        this.elementRef = elementRef;
        this.cdr = cdr;
        this.destroyRef = destroyRef;
        this.router = router;
    }
    ngAfterViewInit() {
        this.tabService.tabSelected$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(tab => {
            this.isActive = tab.id === this.id;
            this.cdr.detectChanges();
        });
    }
    setOptions(options) {
        this.options = options;
        this.cdr.detectChanges();
    }
    selectTab() {
        this.tabService.selectTab(this);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTabComponent, deps: [{ token: OuiTabsService }, { token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i0.DestroyRef }, { token: i2.Router }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiTabComponent, isStandalone: true, selector: "oui-tab", inputs: { title: "title", tabTitleTemplate: "tabTitleTemplate", parentId: "parentId", id: "id", disabled: "disabled" }, viewQueries: [{ propertyName: "titleTemplate", first: true, predicate: ["titleTemplate"], descendants: true }, { propertyName: "tabContentTemplate", first: true, predicate: ["tabContentTemplate"], descendants: true }], ngImport: i0, template: ` <div
        class="tab-title {{ options?.variant }}"
        [ngClass]="{ active: isActive, disabled: disabled }"
        (click)="selectTab()"
        >
        @if (tabTitleTemplate) {
          <ng-container
            [ngTemplateOutlet]="tabTitleTemplate"
            >
          </ng-container>
        }
        @if (!tabTitleTemplate) {
          <span>
            {{ title }}
          </span>
        }
      </div>
      <ng-template #tabContentTemplate>
        <ng-content></ng-content>
      </ng-template>`, isInline: true, styles: [":host{min-width:var(--oui-tab-width);min-height:var(--oui-tab-height);width:var(--oui-tab-width);height:var(--oui-tab-height);display:flex;align-items:center;background-color:transparent;position:relative}:host .tab-title{width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:var(--oui-tab-text-color);transition:color .3s;border-radius:var(--oui-tab-border-radius)}:host .tab-title:hover{cursor:pointer;background-color:var(--oui-tab-background-color-hover)}:host .tab-title.disabled{opacity:.7;pointer-events:none}:host .tab-title.active{color:var(--oui-tab-text-color-active)}:host .tab-title:hover{color:var(--oui-tab-text-color-hover)}:host .tab-title.bordered{border:1px solid #ccc;padding:1rem}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTabComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-tab', template: ` <div
        class="tab-title {{ options?.variant }}"
        [ngClass]="{ active: isActive, disabled: disabled }"
        (click)="selectTab()"
        >
        @if (tabTitleTemplate) {
          <ng-container
            [ngTemplateOutlet]="tabTitleTemplate"
            >
          </ng-container>
        }
        @if (!tabTitleTemplate) {
          <span>
            {{ title }}
          </span>
        }
      </div>
      <ng-template #tabContentTemplate>
        <ng-content></ng-content>
      </ng-template>`, standalone: true, imports: [NgClass, NgTemplateOutlet], styles: [":host{min-width:var(--oui-tab-width);min-height:var(--oui-tab-height);width:var(--oui-tab-width);height:var(--oui-tab-height);display:flex;align-items:center;background-color:transparent;position:relative}:host .tab-title{width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:var(--oui-tab-text-color);transition:color .3s;border-radius:var(--oui-tab-border-radius)}:host .tab-title:hover{cursor:pointer;background-color:var(--oui-tab-background-color-hover)}:host .tab-title.disabled{opacity:.7;pointer-events:none}:host .tab-title.active{color:var(--oui-tab-text-color-active)}:host .tab-title:hover{color:var(--oui-tab-text-color-hover)}:host .tab-title.bordered{border:1px solid #ccc;padding:1rem}\n"] }]
        }], ctorParameters: () => [{ type: OuiTabsService }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i0.DestroyRef }, { type: i2.Router }], propDecorators: { titleTemplate: [{
                type: ViewChild,
                args: ['titleTemplate']
            }], tabContentTemplate: [{
                type: ViewChild,
                args: ['tabContentTemplate']
            }], title: [{
                type: Input
            }], tabTitleTemplate: [{
                type: Input
            }], parentId: [{
                type: Input
            }], id: [{
                type: Input
            }], disabled: [{
                type: Input
            }] } });

class OuiTabsComponent {
    tabService;
    elementRef;
    destroyRef;
    tabs;
    underline;
    id = GUID();
    options = input();
    defaultOptions = {
        variant: 'underlined',
        mode: 'standard',
    };
    combinedOptions = computed(() => {
        return merge({ ...this.defaultOptions }, this.options());
    });
    selectedTab = signal(undefined);
    constructor(tabService, elementRef, destroyRef) {
        this.tabService = tabService;
        this.elementRef = elementRef;
        this.destroyRef = destroyRef;
        this.tabService.registerTabs(this);
        effect(() => {
            if (this.tabs?.length) {
                for (const tab of this.tabs) {
                    tab.setOptions(this.combinedOptions());
                }
            }
        });
    }
    ngAfterViewInit() {
        this.tabs.changes
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(tabs => {
            const selectedTabIndex = tabs._results.findIndex((tab) => {
                return tab.id === this.selectedTab()?.id;
            });
            if (selectedTabIndex === -1) {
                this.tabService.selectTab(tabs.first);
            }
            this.setChildParentIds();
        });
        this.tabService.tabSelected$
            .pipe(takeUntilDestroyed(this.destroyRef), filter(tab => tab.parentId === this.id))
            .subscribe(tab => {
            this.selectedTab.set(tab);
            const tabRect = tab.elementRef.nativeElement.getBoundingClientRect();
            const parentRect = this.elementRef.nativeElement.getBoundingClientRect();
            const leftPercentage = (tabRect.left - parentRect.left) / parentRect.width;
            const widthPercentage = tabRect.width / 100;
            const translateXPixels = leftPercentage * parentRect.width;
            this.underline.nativeElement.style.transform = `translateX(${translateXPixels}px) scaleX(${widthPercentage})`;
        });
        for (const tab of this.tabs) {
            tab.parentId = this.id;
            tab.setOptions(this.combinedOptions());
        }
        this.tabService.selectTab(this.tabs.first);
    }
    setChildParentIds() {
        for (const tab of this.tabs) {
            tab.parentId = this.id;
            tab.setOptions(this.combinedOptions());
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTabsComponent, deps: [{ token: OuiTabsService }, { token: i0.ElementRef }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiTabsComponent, isStandalone: true, selector: "oui-tabs", inputs: { id: { classPropertyName: "id", publicName: "id", isSignal: false, isRequired: false, transformFunction: null }, options: { classPropertyName: "options", publicName: "options", isSignal: true, isRequired: false, transformFunction: null } }, queries: [{ propertyName: "tabs", predicate: OuiTabComponent, descendants: true }], viewQueries: [{ propertyName: "underline", first: true, predicate: ["underline"], descendants: true }], ngImport: i0, template: "<div class=\"tabs-container\">\n  <div class=\"tabs\">\n    <ng-content></ng-content>\n    @if (combinedOptions().variant === 'underlined') {\n      <div\n        class=\"tab-underline\"\n        >\n        <div class=\"tab-underline-bar\" #underline></div>\n      </div>\n    }\n  </div>\n  @if(selectedTab(); as tab) {\n    @if (combinedOptions().mode === 'standard') {\n      <div\n        class=\"content-area\"\n      >\n        <ng-container\n          *ngTemplateOutlet=\"tab.tabContentTemplate\"\n        ></ng-container>\n      </div>\n    }\n  }\n\n</div>\n", styles: [":host{position:relative}:host .tabs{position:relative;margin-bottom:var(--oui-tab-margin-bottom);display:flex}:host .tabs .tab-underline{flex:1;position:absolute;bottom:2px;left:0;height:2px;width:100%}:host .tabs .tab-underline .tab-underline-bar{position:absolute;left:0;top:0;width:100px;transition:transform .3s;height:100%;background-color:var(--color-accent);transform-origin:left}:host .content-area{max-height:max(100%,1000px)}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTabsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-tabs', standalone: true, imports: [NgTemplateOutlet], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"tabs-container\">\n  <div class=\"tabs\">\n    <ng-content></ng-content>\n    @if (combinedOptions().variant === 'underlined') {\n      <div\n        class=\"tab-underline\"\n        >\n        <div class=\"tab-underline-bar\" #underline></div>\n      </div>\n    }\n  </div>\n  @if(selectedTab(); as tab) {\n    @if (combinedOptions().mode === 'standard') {\n      <div\n        class=\"content-area\"\n      >\n        <ng-container\n          *ngTemplateOutlet=\"tab.tabContentTemplate\"\n        ></ng-container>\n      </div>\n    }\n  }\n\n</div>\n", styles: [":host{position:relative}:host .tabs{position:relative;margin-bottom:var(--oui-tab-margin-bottom);display:flex}:host .tabs .tab-underline{flex:1;position:absolute;bottom:2px;left:0;height:2px;width:100%}:host .tabs .tab-underline .tab-underline-bar{position:absolute;left:0;top:0;width:100px;transition:transform .3s;height:100%;background-color:var(--color-accent);transform-origin:left}:host .content-area{max-height:max(100%,1000px)}\n"] }]
        }], ctorParameters: () => [{ type: OuiTabsService }, { type: i0.ElementRef }, { type: i0.DestroyRef }], propDecorators: { tabs: [{
                type: ContentChildren,
                args: [OuiTabComponent, { descendants: true }]
            }], underline: [{
                type: ViewChild,
                args: ['underline']
            }], id: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiTabComponent, OuiTabsComponent, OuiTabsService };
//# sourceMappingURL=orbital-ui-tabs.mjs.map
