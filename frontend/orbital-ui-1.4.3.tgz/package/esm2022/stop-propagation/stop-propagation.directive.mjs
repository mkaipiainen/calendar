import { Directive, HostListener } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Can be used to make all click-events on the element stop propagation.
 */
export class ClickStopPropagationDirective {
    onClick(event) {
        event.stopPropagation();
    }
    click(event) {
        event.stopPropagation();
    }
    hover(event) {
        event.stopPropagation();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: ClickStopPropagationDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.1", type: ClickStopPropagationDirective, isStandalone: true, selector: "[oui-stop-propagation]", host: { listeners: { "onClick": "onClick($event)", "click": "click($event)", "mouseover": "hover($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: ClickStopPropagationDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[oui-stop-propagation]',
                    standalone: true,
                }]
        }], propDecorators: { onClick: [{
                type: HostListener,
                args: ['onClick', ['$event']]
            }], click: [{
                type: HostListener,
                args: ['click', ['$event']]
            }], hover: [{
                type: HostListener,
                args: ['mouseover', ['$event']]
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RvcC1wcm9wYWdhdGlvbi5kaXJlY3RpdmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3N0b3AtcHJvcGFnYXRpb24vc3RvcC1wcm9wYWdhdGlvbi5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBRXhEOztHQUVHO0FBS0gsTUFBTSxPQUFPLDZCQUE2QjtJQUVqQyxPQUFPLENBQUMsS0FBVTtRQUN2QixLQUFLLENBQUMsZUFBZSxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUdNLEtBQUssQ0FBQyxLQUFVO1FBQ3JCLEtBQUssQ0FBQyxlQUFlLEVBQUUsQ0FBQztJQUMxQixDQUFDO0lBR00sS0FBSyxDQUFDLEtBQVU7UUFDckIsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQzFCLENBQUM7dUdBZFUsNkJBQTZCOzJGQUE3Qiw2QkFBNkI7OzJGQUE3Qiw2QkFBNkI7a0JBSnpDLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLHdCQUF3QjtvQkFDbEMsVUFBVSxFQUFFLElBQUk7aUJBQ2pCOzhCQUdRLE9BQU87c0JBRGIsWUFBWTt1QkFBQyxTQUFTLEVBQUUsQ0FBQyxRQUFRLENBQUM7Z0JBTTVCLEtBQUs7c0JBRFgsWUFBWTt1QkFBQyxPQUFPLEVBQUUsQ0FBQyxRQUFRLENBQUM7Z0JBTTFCLEtBQUs7c0JBRFgsWUFBWTt1QkFBQyxXQUFXLEVBQUUsQ0FBQyxRQUFRLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaXJlY3RpdmUsIEhvc3RMaXN0ZW5lciB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG4vKipcbiAqIENhbiBiZSB1c2VkIHRvIG1ha2UgYWxsIGNsaWNrLWV2ZW50cyBvbiB0aGUgZWxlbWVudCBzdG9wIHByb3BhZ2F0aW9uLlxuICovXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6ICdbb3VpLXN0b3AtcHJvcGFnYXRpb25dJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbn0pXG5leHBvcnQgY2xhc3MgQ2xpY2tTdG9wUHJvcGFnYXRpb25EaXJlY3RpdmUge1xuICBASG9zdExpc3RlbmVyKCdvbkNsaWNrJywgWyckZXZlbnQnXSlcbiAgcHVibGljIG9uQ2xpY2soZXZlbnQ6IGFueSk6IHZvaWQge1xuICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICB9XG5cbiAgQEhvc3RMaXN0ZW5lcignY2xpY2snLCBbJyRldmVudCddKVxuICBwdWJsaWMgY2xpY2soZXZlbnQ6IGFueSk6IHZvaWQge1xuICAgIGV2ZW50LnN0b3BQcm9wYWdhdGlvbigpO1xuICB9XG5cbiAgQEhvc3RMaXN0ZW5lcignbW91c2VvdmVyJywgWyckZXZlbnQnXSlcbiAgcHVibGljIGhvdmVyKGV2ZW50OiBhbnkpOiB2b2lkIHtcbiAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgfVxufVxuIl19