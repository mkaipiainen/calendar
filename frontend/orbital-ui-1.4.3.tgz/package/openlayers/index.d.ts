/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/openlayers" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-openlayers.d.ts.map