export declare function base64ToByteArray(dataURI: string): Uint8Array;
//# sourceMappingURL=base64-byte-helper.d.ts.map