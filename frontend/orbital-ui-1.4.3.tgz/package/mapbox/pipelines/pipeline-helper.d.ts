import { OuiMapboxComponent } from '../mapbox.component';
import { Position } from '@turf/helpers';
export declare class PipelineHelper {
    private map;
    private state;
    private pipelineSubject;
    pipeline$: import("rxjs").Observable<{
        dpp: number;
        bounds: Position[];
    }>;
    constructor(map: OuiMapboxComponent);
    startPipelineSubscription(): void;
    private getBoundingBoxDimensions;
}
//# sourceMappingURL=pipeline-helper.d.ts.map