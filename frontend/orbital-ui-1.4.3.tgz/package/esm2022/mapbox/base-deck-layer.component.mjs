import { ChangeDetectionStrategy, Component, DestroyRef, EventEmitter, inject, Input, Output, } from '@angular/core';
import { isNil } from 'lodash-es';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { combineLatest, ReplaySubject } from 'rxjs';
import * as i0 from "@angular/core";
export class BaseDeckLayer {
    options;
    deck;
    onOptionsChange = new EventEmitter();
    isAdded = false;
    options$ = new ReplaySubject(1);
    destroyRef = inject(DestroyRef);
    constructor() { }
    onHover(info) {
        if (this.options.onHover) {
            this.options.onHover(info);
        }
        this.deck.setHoveredLayer(this);
    }
    onClick(item, event) {
        if (item.object && 'onClick' in this.options && this.options.onClick) {
            this.options.onClick(item.object, event);
        }
    }
    getCursor(state) {
        return state.isHovering
            ? 'pointer'
            : state.isDragging
                ? 'grabbing'
                : 'grab';
    }
    ngAfterViewInit() {
        combineLatest([this.deck.onLoad$, this.options$])
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(([_, options]) => {
            if (!this.isAdded) {
                this.deck.addLayer(this);
                this.isAdded = true;
            }
            else {
                this.deck.refreshLayer(this);
            }
        });
    }
    ngOnChanges(changes) {
        if ('options' in changes && changes.options.currentValue) {
            const options = {
                ...changes.options.currentValue,
                isEnabled: isNil(changes.options.currentValue?.isEnabled)
                    ? !!changes.options.currentValue
                    : changes.options.currentValue.isEnabled,
            };
            this.options = options;
            this.options$.next(this.options);
        }
    }
    ngOnDestroy() {
        if (this.deck) {
            this.deck.removeLayer(this);
        }
        if (this.options$) {
            this.options$.complete();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: BaseDeckLayer, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: BaseDeckLayer, isStandalone: true, selector: "oui-base-deck-layer", inputs: { options: "options", deck: "deck" }, outputs: { onOptionsChange: "onOptionsChange" }, usesOnChanges: true, ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: BaseDeckLayer, decorators: [{
            type: Component,
            args: [{
                    selector: 'oui-base-deck-layer',
                    template: '',
                    standalone: true,
                    imports: [],
                    changeDetection: ChangeDetectionStrategy.OnPush,
                }]
        }], ctorParameters: () => [], propDecorators: { options: [{
                type: Input,
                args: [{ required: true }]
            }], deck: [{
                type: Input,
                args: [{ required: true }]
            }], onOptionsChange: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS1kZWNrLWxheWVyLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvbWFwYm94L2Jhc2UtZGVjay1sYXllci5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUVMLHVCQUF1QixFQUN2QixTQUFTLEVBQ1QsVUFBVSxFQUNWLFlBQVksRUFDWixNQUFNLEVBQ04sS0FBSyxFQUdMLE1BQU0sR0FFUCxNQUFNLGVBQWUsQ0FBQztBQU92QixPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sV0FBVyxDQUFDO0FBQ2xDLE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxhQUFhLEVBQUUsYUFBYSxFQUFhLE1BQU0sTUFBTSxDQUFDOztBQVMvRCxNQUFNLE9BQWdCLGFBQWE7SUFLTixPQUFPLENBQUk7SUFDWCxJQUFJLENBQW1CO0lBQ3hDLGVBQWUsR0FBRyxJQUFJLFlBQVksRUFBTyxDQUFDO0lBRTVDLE9BQU8sR0FBRyxLQUFLLENBQUM7SUFDaEIsUUFBUSxHQUFHLElBQUksYUFBYSxDQUEwQixDQUFDLENBQUMsQ0FBQztJQUN2RCxVQUFVLEdBQUcsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQzFDLGdCQUFlLENBQUM7SUFFVCxPQUFPLENBQUMsSUFBUztRQUN0QixJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDN0IsQ0FBQztRQUNELElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFJLElBQUksQ0FBQyxDQUFDO0lBQ3JDLENBQUM7SUFFTSxPQUFPLENBQUMsSUFBUyxFQUFFLEtBQVU7UUFDbEMsSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLFNBQVMsSUFBSSxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDckUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztRQUMzQyxDQUFDO0lBQ0gsQ0FBQztJQUlNLFNBQVMsQ0FBQyxLQUFrQjtRQUNqQyxPQUFPLEtBQUssQ0FBQyxVQUFVO1lBQ3JCLENBQUMsQ0FBQyxTQUFTO1lBQ1gsQ0FBQyxDQUFDLEtBQUssQ0FBQyxVQUFVO2dCQUNsQixDQUFDLENBQUMsVUFBVTtnQkFDWixDQUFDLENBQUMsTUFBTSxDQUFDO0lBQ2IsQ0FBQztJQUVNLGVBQWU7UUFDcEIsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQzlDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDekMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLEVBQUUsRUFBRTtZQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUNsQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDekIsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7WUFDdEIsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQy9CLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTSxXQUFXLENBQUMsT0FBc0I7UUFDdkMsSUFBSSxTQUFTLElBQUksT0FBTyxJQUFJLE9BQU8sQ0FBQyxPQUFPLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDekQsTUFBTSxPQUFPLEdBQUc7Z0JBQ2QsR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDLFlBQVk7Z0JBQy9CLFNBQVMsRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsU0FBUyxDQUFDO29CQUN2RCxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsWUFBWTtvQkFDaEMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLFNBQVM7YUFDM0MsQ0FBQztZQUNGLElBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNuQyxDQUFDO0lBQ0gsQ0FBQztJQUVNLFdBQVc7UUFDaEIsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7WUFDZCxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUM5QixDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDbEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQztRQUMzQixDQUFDO0lBQ0gsQ0FBQzt1R0F0RW1CLGFBQWE7MkZBQWIsYUFBYSxtTUFMdkIsRUFBRTs7MkZBS1EsYUFBYTtrQkFQbEMsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUscUJBQXFCO29CQUMvQixRQUFRLEVBQUUsRUFBRTtvQkFDWixVQUFVLEVBQUUsSUFBSTtvQkFDaEIsT0FBTyxFQUFFLEVBQUU7b0JBQ1gsZUFBZSxFQUFFLHVCQUF1QixDQUFDLE1BQU07aUJBQ2hEO3dEQU00QixPQUFPO3NCQUFqQyxLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFDRSxJQUFJO3NCQUE5QixLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFDZixlQUFlO3NCQUF4QixNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIENvbXBvbmVudCxcbiAgRGVzdHJveVJlZixcbiAgRXZlbnRFbWl0dGVyLFxuICBpbmplY3QsXG4gIElucHV0LFxuICBPbkNoYW5nZXMsXG4gIE9uRGVzdHJveSxcbiAgT3V0cHV0LFxuICBTaW1wbGVDaGFuZ2VzLFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7XG4gIEN1cnNvclN0YXRlLFxuICBJQ29tbW9uRGVja0xheWVyT3B0aW9ucyxcbiAgSVNsaW1Db21tb25EZWNrTGF5ZXJPcHRpb25zLFxufSBmcm9tICcuL3R5cGluZ3MnO1xuaW1wb3J0IHsgT3VpRGVja0NvbXBvbmVudCB9IGZyb20gJy4vZGVjay9kZWNrLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBpc05pbCB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyB0YWtlVW50aWxEZXN0cm95ZWQgfSBmcm9tICdAYW5ndWxhci9jb3JlL3J4anMtaW50ZXJvcCc7XG5pbXBvcnQgeyBjb21iaW5lTGF0ZXN0LCBSZXBsYXlTdWJqZWN0LCB0YWtlLCB6aXAgfSBmcm9tICdyeGpzJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnb3VpLWJhc2UtZGVjay1sYXllcicsXG4gIHRlbXBsYXRlOiAnJyxcbiAgc3RhbmRhbG9uZTogdHJ1ZSxcbiAgaW1wb3J0czogW10sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBCYXNlRGVja0xheWVyPFxuICAgIFQgZXh0ZW5kcyBJU2xpbUNvbW1vbkRlY2tMYXllck9wdGlvbnMgfCBJQ29tbW9uRGVja0xheWVyT3B0aW9ucyxcbiAgPlxuICBpbXBsZW1lbnRzIE9uQ2hhbmdlcywgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95XG57XG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pIG9wdGlvbnM6IFQ7XG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pIGRlY2s6IE91aURlY2tDb21wb25lbnQ7XG4gIEBPdXRwdXQoKSBvbk9wdGlvbnNDaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyPGFueT4oKTtcblxuICBwcml2YXRlIGlzQWRkZWQgPSBmYWxzZTtcbiAgcHJpdmF0ZSBvcHRpb25zJCA9IG5ldyBSZXBsYXlTdWJqZWN0PElDb21tb25EZWNrTGF5ZXJPcHRpb25zPigxKTtcbiAgcHJvdGVjdGVkIGRlc3Ryb3lSZWYgPSBpbmplY3QoRGVzdHJveVJlZik7XG4gIGNvbnN0cnVjdG9yKCkge31cblxuICBwdWJsaWMgb25Ib3ZlcihpbmZvOiBhbnkpIHtcbiAgICBpZiAodGhpcy5vcHRpb25zLm9uSG92ZXIpIHtcbiAgICAgIHRoaXMub3B0aW9ucy5vbkhvdmVyKGluZm8pO1xuICAgIH1cbiAgICB0aGlzLmRlY2suc2V0SG92ZXJlZExheWVyPFQ+KHRoaXMpO1xuICB9XG5cbiAgcHVibGljIG9uQ2xpY2soaXRlbTogYW55LCBldmVudDogYW55KSB7XG4gICAgaWYgKGl0ZW0ub2JqZWN0ICYmICdvbkNsaWNrJyBpbiB0aGlzLm9wdGlvbnMgJiYgdGhpcy5vcHRpb25zLm9uQ2xpY2spIHtcbiAgICAgIHRoaXMub3B0aW9ucy5vbkNsaWNrKGl0ZW0ub2JqZWN0LCBldmVudCk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIGFic3RyYWN0IGdldExheWVyKCk6IGFueTtcblxuICBwdWJsaWMgZ2V0Q3Vyc29yKHN0YXRlOiBDdXJzb3JTdGF0ZSk6IHN0cmluZyB7XG4gICAgcmV0dXJuIHN0YXRlLmlzSG92ZXJpbmdcbiAgICAgID8gJ3BvaW50ZXInXG4gICAgICA6IHN0YXRlLmlzRHJhZ2dpbmdcbiAgICAgID8gJ2dyYWJiaW5nJ1xuICAgICAgOiAnZ3JhYic7XG4gIH1cblxuICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCkge1xuICAgIGNvbWJpbmVMYXRlc3QoW3RoaXMuZGVjay5vbkxvYWQkLCB0aGlzLm9wdGlvbnMkXSlcbiAgICAgIC5waXBlKHRha2VVbnRpbERlc3Ryb3llZCh0aGlzLmRlc3Ryb3lSZWYpKVxuICAgICAgLnN1YnNjcmliZSgoW18sIG9wdGlvbnNdKSA9PiB7XG4gICAgICAgIGlmICghdGhpcy5pc0FkZGVkKSB7XG4gICAgICAgICAgdGhpcy5kZWNrLmFkZExheWVyKHRoaXMpO1xuICAgICAgICAgIHRoaXMuaXNBZGRlZCA9IHRydWU7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGhpcy5kZWNrLnJlZnJlc2hMYXllcih0aGlzKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gIH1cblxuICBwdWJsaWMgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgIGlmICgnb3B0aW9ucycgaW4gY2hhbmdlcyAmJiBjaGFuZ2VzLm9wdGlvbnMuY3VycmVudFZhbHVlKSB7XG4gICAgICBjb25zdCBvcHRpb25zID0ge1xuICAgICAgICAuLi5jaGFuZ2VzLm9wdGlvbnMuY3VycmVudFZhbHVlLFxuICAgICAgICBpc0VuYWJsZWQ6IGlzTmlsKGNoYW5nZXMub3B0aW9ucy5jdXJyZW50VmFsdWU/LmlzRW5hYmxlZClcbiAgICAgICAgICA/ICEhY2hhbmdlcy5vcHRpb25zLmN1cnJlbnRWYWx1ZVxuICAgICAgICAgIDogY2hhbmdlcy5vcHRpb25zLmN1cnJlbnRWYWx1ZS5pc0VuYWJsZWQsXG4gICAgICB9O1xuICAgICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICAgIHRoaXMub3B0aW9ucyQubmV4dCh0aGlzLm9wdGlvbnMpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBuZ09uRGVzdHJveSgpIHtcbiAgICBpZiAodGhpcy5kZWNrKSB7XG4gICAgICB0aGlzLmRlY2sucmVtb3ZlTGF5ZXIodGhpcyk7XG4gICAgfVxuICAgIGlmICh0aGlzLm9wdGlvbnMkKSB7XG4gICAgICB0aGlzLm9wdGlvbnMkLmNvbXBsZXRlKCk7XG4gICAgfVxuICB9XG59XG4iXX0=