import * as i0 from '@angular/core';
import { Injectable } from '@angular/core';

/**
 * Service to streamline access to localStorage a bit, especially with JSON-objects.
 * When using this service, you don't need to manually stringify and parse javascript-objects, but it's handled automatically.
 */
class OuiLocalStorageService {
    constructor() { }
    setItem(key, value) {
        localStorage.setItem(key, JSON.stringify(value));
    }
    getItem(key) {
        const item = localStorage.getItem(key);
        if (item) {
            try {
                return JSON.parse(item);
            }
            catch (e) {
                return item;
            }
        }
        else {
            return null;
        }
    }
    removeItem(key) {
        localStorage.removeItem(key);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiLocalStorageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiLocalStorageService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiLocalStorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiLocalStorageService };
//# sourceMappingURL=orbital-ui-local-storage.mjs.map
