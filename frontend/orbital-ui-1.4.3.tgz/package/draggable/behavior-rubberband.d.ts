import { OuiDraggableDirective } from './draggable.directive';
import { BehaviorBase } from './behavior-default';
export interface IRubberbandBehaviorOptions {
    tightness?: number;
    velocityMultiplier?: number;
}
export declare class RubberbandBehavior extends BehaviorBase {
    private options?;
    private startPosition;
    constructor(draggable: OuiDraggableDirective, options?: IRubberbandBehaviorOptions | undefined);
    onDragStart(event: MouseEvent | TouchEvent): void;
    onDragEnd(event: MouseEvent | TouchEvent): void;
}
//# sourceMappingURL=behavior-rubberband.d.ts.map