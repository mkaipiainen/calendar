import * as i0 from '@angular/core';
import { Injectable, signal, Component, ChangeDetectionStrategy, ViewChildren, Input, ViewContainerRef, ViewChild, computed } from '@angular/core';
import { NgTemplateOutlet, NgClass, NgStyle, JsonPipe, SlicePipe } from '@angular/common';
import { BehaviorSubject, ReplaySubject, combineLatest, take, skip, filter } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { OuiHoverDirective } from 'orbital-ui/hover';
import { debounce } from 'lodash-es';
import { OuiIconComponent } from 'orbital-ui/icon';
import { NgxResize } from 'ngxtension/resize';

class TableService {
    items = [];
    visibleItems = [];
    tableHeight = 0;
    scrollTopRefreshLimit = 0;
    options;
    scrollTop = {
        value: 0,
        stringValue: '0px',
    };
    visibleItemIndices = {
        from: 0,
        to: 0,
    };
    sortOrder = [];
    scrollTopSubject = new BehaviorSubject(this.scrollTop);
    dataSubject = new ReplaySubject(1);
    indexToSubject = new ReplaySubject(1);
    tableHeightSubject = new ReplaySubject(1);
    columnsSubject = new ReplaySubject(1);
    itemsSubject = new ReplaySubject(1);
    sortOrderSubject = new BehaviorSubject([]);
    scrollTop$ = this.scrollTopSubject.asObservable();
    sortOrder$ = this.sortOrderSubject.asObservable();
    columns$ = this.columnsSubject.asObservable();
    indexTo$ = this.indexToSubject.asObservable();
    items$ = this.itemsSubject.asObservable();
    constructor() {
        combineLatest([
            this.scrollTop$,
            this.dataSubject.asObservable(),
            this.tableHeightSubject.asObservable(),
        ])
            .pipe(take(1))
            .subscribe(() => {
            this.setVisibleItems();
        });
        this.scrollTop$
            .pipe(skip(1), filter(() => this.options.hasVirtualScroll))
            .subscribe(() => {
            this.setVisibleItems();
        });
    }
    setItems(items) {
        this.items = items;
        this.visibleItemIndices = this.getVisibleItemIndices();
        this.indexToSubject.next(this.visibleItemIndices.to);
        this.itemsSubject.next(this.items);
    }
    setColumns(columns) {
        this.columnsSubject.next(columns);
    }
    toggleSort(column) {
        const currentSortOrderIndex = this.sortOrder.findIndex(singleSort => {
            return singleSort.column.id === column.id;
        });
        if (currentSortOrderIndex > -1) {
            const currentDirection = this.sortOrder[currentSortOrderIndex].direction;
            if (currentDirection === 'DESC') {
                this.sortOrder[currentSortOrderIndex].direction = 'ASC';
            }
            else {
                this.sortOrder.splice(currentSortOrderIndex, 1);
            }
        }
        else {
            this.sortOrder.push({
                column: column,
                direction: 'DESC',
            });
        }
        this.sortData();
        this.sortOrderSubject.next(this.sortOrder);
    }
    sortData() {
        this.items = this.items.sort((a, b) => {
            let result = 0;
            for (const sortOrder of this.sortOrder) {
                let sortFunction = sortOrder.column?.sortFunction ?? this.defaultSortFunction;
                sortFunction = sortFunction.bind(this);
                result = sortFunction(a, b, sortOrder);
                if (result !== 0) {
                    break;
                }
            }
            return result;
        });
        this.itemsSubject.next(this.items);
    }
    defaultSortFunction(a, b, sortOrder) {
        const multiplier = sortOrder.direction === 'DESC' ? 1 : -1;
        if (a.item[sortOrder.column.valueKey] > b.item[sortOrder.column.valueKey]) {
            return 1 * multiplier;
        }
        else if (a.item[sortOrder.column.valueKey] < b.item[sortOrder.column.valueKey]) {
            return -1 * multiplier;
        }
        else {
            return 0;
        }
    }
    setTableHeight(height) {
        this.tableHeight = height.height;
        this.tableHeightSubject.next(this.tableHeight);
        this.setVisibleItems();
    }
    setScrollTop(scrollTop) {
        this.scrollTop = scrollTop;
        if (this.scrollTop.value > this.scrollTopRefreshLimit ||
            !this.visibleItems.length) {
            this.scrollTopSubject.next(scrollTop);
            this.scrollTopRefreshLimit = this.scrollTop.value + this.tableHeight / 2;
        }
    }
    setOptions(options) {
        this.options = {
            ...options,
        };
    }
    setVisibleItems() {
        this.visibleItemIndices = this.getVisibleItemIndices();
        this.indexToSubject.next(this.visibleItemIndices.to);
        // if (this.options.hasVirtualScroll) {
        //   const newVisibleItemIndices = this.getVisibleItemIndices();
        //   const itemsToAppend = this.items.slice(this.visibleItemIndices.to, newVisibleItemIndices.to);
        //   this.itemsToAppendSubject.next(itemsToAppend);
        //   this.visibleItemIndices = newVisibleItemIndices;
        // } else {
        //   this.itemsToAppendSubject.next(this.items);
        // }
    }
    getVisibleItemIndices() {
        if (this.options.hasVirtualScroll) {
            const bottom = this.scrollTop.value + this.tableHeight * 2;
            // const visibleItemsFrom = Math.floor(top / this.options.itemHeight);
            const visibleItemsTo = Math.ceil(bottom / this.options.itemHeight);
            return {
                from: 0,
                to: visibleItemsTo,
            };
        }
        else {
            return {
                from: 0,
                to: this.items.length,
            };
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: TableService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: TableService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: TableService, decorators: [{
            type: Injectable
        }], ctorParameters: () => [] });

class OuiTableRowComponent {
    elementRef;
    destroyRef;
    cdr;
    columnRefs;
    item;
    options;
    tableService;
    isClickable = false;
    isLoaded = signal(false);
    columns = signal([]);
    constructor(elementRef, destroyRef, cdr) {
        this.elementRef = elementRef;
        this.destroyRef = destroyRef;
        this.cdr = cdr;
    }
    ngAfterViewInit() {
        this.isClickable = !!this.options.onItemClick;
        if (this.options.onItemClick) {
            this.elementRef.nativeElement.classList.add('clickable');
        }
        this.tableService.columns$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(columns => {
            this.columns.set(columns);
            setTimeout(() => {
                this.initColumnWidths();
                this.isLoaded.set(true);
            });
        });
    }
    trackById(index, column) {
        return column.id;
    }
    onItemClick(event) {
        if (this.options.onItemClick) {
            this.options.onItemClick(this.item, event);
        }
    }
    initColumnWidths() {
        for (const column of this.columns()) {
            const element = this.columnRefs.find(columnRef => {
                return columnRef.nativeElement.id === `row-${column.id}`;
            });
            if (!element) {
                continue;
            }
            if (column.flex) {
                element.nativeElement.style.flex = column.flex;
            }
            else {
                element.nativeElement.style.flex = '1';
            }
        }
    }
    ngOnChanges(changes) {
        if ('options' in changes) {
            this.options = changes['options'].currentValue;
            if (this.options.onItemClick) {
                this.elementRef.nativeElement.classList.add('clickable');
            }
            else {
                this.elementRef.nativeElement.classList.remove('clickable');
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTableRowComponent, deps: [{ token: i0.ElementRef }, { token: i0.DestroyRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiTableRowComponent, isStandalone: true, selector: "oui-table-row", inputs: { item: "item", options: "options", tableService: "tableService" }, viewQueries: [{ propertyName: "columnRefs", predicate: ["columnRef"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"table-row\" (click)=\"onItemClick($event)\" [ngClass]=\"{'is-loaded': isLoaded}\">\n  @for (column of columns(); track trackById($index, column)) {\n    <div #columnRef id=\"row-{{column.id}}\" class=\"item\" [ngStyle]=\"{overflow: column.overflow ?? 'auto'}\">\n      @if (!column.cellTemplate) {\n        <span [ngStyle]=\"{textOverflow: column.textOverflow ?? 'clip', overflow: column.overflow ?? 'auto'}\" class=\"body-cell\">{{item[column.valueKey]}}</span>\n      }\n      @if (column.cellTemplate) {\n        <ng-container\n          *ngTemplateOutlet=\"\n                    column.cellTemplate;\n                    context: { $implicit: item, item: item }\n                  \"\n        ></ng-container>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{flex:var(--oui-table-row-flex);display:flex;height:var(--oui-table-item-height);min-height:var(--oui-table-item-height);border-width:var(--oui-table-row-border-width-top) 0 var(--oui-table-row-border-width-bottom) 0;border-style:var(--oui-table-row-border-style);border-color:var(--oui-table-row-border-color);background-color:var(--oui-table-row-background-color);color:var(--oui-table-row-text-color);transition:background-color .3s;font-size:var(--oui-table-cell-font-size)}:host:hover{background-color:var(--oui-table-row-hover-background-color);color:var(--oui-table-row-hover-text-color)}:host .table-row{width:100%;display:flex;align-items:center;opacity:0;transition:opacity .3s}:host .table-row.is-loaded{opacity:1}:host .table-row .item{flex:1;padding:var(--oui-table-cell-padding);display:flex;align-items:center;justify-content:var(--oui-table-cell-alignment)}:host.cell-hovered{background-color:var(--oui-table-cell-hover-background-color);color:var(--oui-table-cell-hover-text-color)}:host.row-hovered{background-color:var(--oui-table-row-hover-background-color);color:var(--oui-table-row-hover-text-color)}:host.clickable{cursor:pointer}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTableRowComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-table-row', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgTemplateOutlet, JsonPipe, OuiHoverDirective, NgClass, NgStyle], template: "<div class=\"table-row\" (click)=\"onItemClick($event)\" [ngClass]=\"{'is-loaded': isLoaded}\">\n  @for (column of columns(); track trackById($index, column)) {\n    <div #columnRef id=\"row-{{column.id}}\" class=\"item\" [ngStyle]=\"{overflow: column.overflow ?? 'auto'}\">\n      @if (!column.cellTemplate) {\n        <span [ngStyle]=\"{textOverflow: column.textOverflow ?? 'clip', overflow: column.overflow ?? 'auto'}\" class=\"body-cell\">{{item[column.valueKey]}}</span>\n      }\n      @if (column.cellTemplate) {\n        <ng-container\n          *ngTemplateOutlet=\"\n                    column.cellTemplate;\n                    context: { $implicit: item, item: item }\n                  \"\n        ></ng-container>\n      }\n    </div>\n  }\n</div>\n", styles: [":host{flex:var(--oui-table-row-flex);display:flex;height:var(--oui-table-item-height);min-height:var(--oui-table-item-height);border-width:var(--oui-table-row-border-width-top) 0 var(--oui-table-row-border-width-bottom) 0;border-style:var(--oui-table-row-border-style);border-color:var(--oui-table-row-border-color);background-color:var(--oui-table-row-background-color);color:var(--oui-table-row-text-color);transition:background-color .3s;font-size:var(--oui-table-cell-font-size)}:host:hover{background-color:var(--oui-table-row-hover-background-color);color:var(--oui-table-row-hover-text-color)}:host .table-row{width:100%;display:flex;align-items:center;opacity:0;transition:opacity .3s}:host .table-row.is-loaded{opacity:1}:host .table-row .item{flex:1;padding:var(--oui-table-cell-padding);display:flex;align-items:center;justify-content:var(--oui-table-cell-alignment)}:host.cell-hovered{background-color:var(--oui-table-cell-hover-background-color);color:var(--oui-table-cell-hover-text-color)}:host.row-hovered{background-color:var(--oui-table-row-hover-background-color);color:var(--oui-table-row-hover-text-color)}:host.clickable{cursor:pointer}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.DestroyRef }, { type: i0.ChangeDetectorRef }], propDecorators: { columnRefs: [{
                type: ViewChildren,
                args: ['columnRef']
            }], item: [{
                type: Input,
                args: [{ required: true }]
            }], options: [{
                type: Input,
                args: [{ required: true }]
            }], tableService: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class OuiTableBodyComponent {
    destroyRef;
    cdr;
    elementRef;
    renderer;
    bodyWrapper;
    rowVCR;
    tableService;
    options;
    unlisteners = [];
    throttledSetScrollTop = debounce(this.setScrollTop.bind(this), 0);
    items = signal([]);
    indexTo = signal(0);
    constructor(destroyRef, cdr, elementRef, renderer) {
        this.destroyRef = destroyRef;
        this.cdr = cdr;
        this.elementRef = elementRef;
        this.renderer = renderer;
    }
    ngAfterViewInit() {
        this.destroyRef.onDestroy(() => {
            for (const unlistener of this.unlisteners) {
                if (unlistener) {
                    unlistener();
                }
            }
        });
        const unlistener = this.renderer.listen(this.elementRef.nativeElement, 'scroll', event => {
            this.throttledSetScrollTop({
                value: event.target.scrollTop,
                stringValue: `${event.target.scrollTop}px`,
            });
        });
        this.unlisteners.push(unlistener);
        this.elementRef.nativeElement.classList.add('oui-scrollbar');
        this.elementRef.nativeElement.classList.add('scroll-y');
        this.tableService.items$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(visibleItems => {
            this.items.set([...visibleItems]);
        });
        this.tableService.indexTo$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(index => {
            this.indexTo.set(index);
        });
    }
    trackItem = (index, item) => {
        return item.item[this.options.trackBy];
    };
    setScrollTop(scrollTop) {
        this.tableService.setScrollTop(scrollTop);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTableBodyComponent, deps: [{ token: i0.DestroyRef }, { token: i0.ChangeDetectorRef }, { token: i0.ElementRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiTableBodyComponent, isStandalone: true, selector: "oui-table-body", inputs: { tableService: "tableService", options: "options" }, viewQueries: [{ propertyName: "bodyWrapper", first: true, predicate: ["bodyWrapper"], descendants: true }, { propertyName: "rowVCR", first: true, predicate: ["rowVCR"], descendants: true, read: ViewContainerRef }], ngImport: i0, template: "@if (options) {\n  <div class=\"oui-table-body\" #bodyWrapper>\n    <!--  <ng-container class=\"row-parent\" id=\"x\" #rowVCR></ng-container>-->\n    @for (item of (items() | slice: 0:indexTo()); track trackItem($index, item)) {\n      <oui-table-row [item]=\"item.item\" [options]=\"options\" [tableService]=\"tableService\"></oui-table-row>\n    }\n  </div>\n}\n", styles: [":host{flex:1;border-width:0 var(--oui-table-column-border-width-right) 0 var(--oui-table-column-border-width-left);border-style:var(--oui-table-column-border-style);border-color:var(--oui-table-column-border-color)}:host .oui-table-column-wrapper{display:flex;flex-direction:column;overflow:hidden}:host .oui-table-body{position:relative;display:flex;flex-direction:column}\n"], dependencies: [{ kind: "component", type: OuiTableRowComponent, selector: "oui-table-row", inputs: ["item", "options", "tableService"] }, { kind: "pipe", type: SlicePipe, name: "slice" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTableBodyComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-table-body', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgTemplateOutlet, OuiTableRowComponent, SlicePipe], template: "@if (options) {\n  <div class=\"oui-table-body\" #bodyWrapper>\n    <!--  <ng-container class=\"row-parent\" id=\"x\" #rowVCR></ng-container>-->\n    @for (item of (items() | slice: 0:indexTo()); track trackItem($index, item)) {\n      <oui-table-row [item]=\"item.item\" [options]=\"options\" [tableService]=\"tableService\"></oui-table-row>\n    }\n  </div>\n}\n", styles: [":host{flex:1;border-width:0 var(--oui-table-column-border-width-right) 0 var(--oui-table-column-border-width-left);border-style:var(--oui-table-column-border-style);border-color:var(--oui-table-column-border-color)}:host .oui-table-column-wrapper{display:flex;flex-direction:column;overflow:hidden}:host .oui-table-body{position:relative;display:flex;flex-direction:column}\n"] }]
        }], ctorParameters: () => [{ type: i0.DestroyRef }, { type: i0.ChangeDetectorRef }, { type: i0.ElementRef }, { type: i0.Renderer2 }], propDecorators: { bodyWrapper: [{
                type: ViewChild,
                args: ['bodyWrapper']
            }], rowVCR: [{
                type: ViewChild,
                args: ['rowVCR', { read: ViewContainerRef }]
            }], tableService: [{
                type: Input,
                args: [{ required: true }]
            }], options: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class OuiTableHeadComponent {
    destroyRef;
    cdr;
    tableService;
    columnRefs;
    sortRank = undefined;
    columns = signal([]);
    sortOrder = signal({});
    constructor(destroyRef, cdr) {
        this.destroyRef = destroyRef;
        this.cdr = cdr;
    }
    ngAfterViewInit() {
        this.tableService.columns$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(columns => {
            this.columns.set(columns);
            setTimeout(() => {
                this.initColumnWidths();
            });
        });
        this.tableService.sortOrder$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(sortOrders => {
            const newSortOrders = {};
            for (let i = 0; i < sortOrders.length; i++) {
                newSortOrders[sortOrders[i].column.id] = {
                    rank: i + 1,
                    direction: sortOrders[i].direction,
                };
            }
            this.sortOrder.set(newSortOrders);
        });
    }
    initColumnWidths() {
        for (const column of this.columns()) {
            const element = this.columnRefs.find(columnRef => {
                return columnRef.nativeElement.id === `header-${column.id}`;
            });
            if (!element) {
                continue;
            }
            if (column.flex) {
                element.nativeElement.style.flex = column.flex;
            }
            else {
                element.nativeElement.style.flex = '1';
            }
        }
    }
    trackById(index, column) {
        return column.id;
    }
    toggleSort(column) {
        if (column.isSortable) {
            this.tableService.toggleSort(column);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTableHeadComponent, deps: [{ token: i0.DestroyRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiTableHeadComponent, isStandalone: true, selector: "oui-table-head", inputs: { tableService: "tableService" }, viewQueries: [{ propertyName: "columnRefs", predicate: ["columnRef"], descendants: true }], ngImport: i0, template: "<div class=\"oui-table-head-wrapper\">\n  @for (column of columns(); track trackById($index, column)) {\n    <div #columnRef id=\"header-{{column.id}}\" class=\"column-header\" (click)=\"toggleSort(column)\" [ngClass]=\"{'sortable': column.isSortable}\">\n      @if (!column.headerCellTemplate) {\n        <span class=\"header-label\">{{column.label}}</span>\n      }\n      @if (column.headerCellTemplate) {\n        <ng-container [ngTemplateOutlet]=\"column.headerCellTemplate!\"> </ng-container>\n      }\n      <div class=\"sort\">\n        @if (sortOrder()[column.id]) {\n          <div class=\"sort-rank\">{{sortOrder()[column.id].rank}}</div>\n        }\n        @if (column.isSortable && sortOrder()[column.id]) {\n          <div class=\"sort-icon\">\n            @if (sortOrder()[column.id].direction === 'DESC') {\n              <oui-icon\n                icon=\"assets/icons/caret_down.svg\"\n              ></oui-icon>\n            }@else if (sortOrder()[column.id].direction === 'ASC') {\n              <oui-icon\n                icon=\"assets/icons/caret_up.svg\"\n              ></oui-icon>\n            }\n            @else if (!sortOrder()[column.id]) {\n              <oui-icon icon=\"assets/icons/unfold_more.svg\">\n              </oui-icon>\n            }\n          </div>\n        }\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{flex:1;display:flex;width:100%}:host .oui-table-head-wrapper{display:flex;flex:1;width:100%;background-color:var(--oui-table-header-background-color);height:var(--oui-table-header-height)}:host .oui-table-head-wrapper .column-header{flex:1;display:flex;height:auto;justify-content:var(--oui-table-header-alignment);align-items:center;overflow:hidden;box-sizing:border-box;font-size:var(--oui-table-header-font-size);font-weight:var(--oui-table-header-font-weight);margin:var(--oui-table-header-padding);flex-wrap:nowrap;-webkit-user-select:none;user-select:none;background-color:var(--oui-table-header-background-color);color:var(--oui-table-header-text-color)}:host .oui-table-head-wrapper .column-header.sortable{cursor:pointer;transition:background-color .3s}:host .oui-table-head-wrapper .column-header.sortable:hover{background-color:var(--oui-table-header-background-color-hover)}:host .oui-table-head-wrapper .column-header .header-label{white-space:nowrap}:host .oui-table-head-wrapper .column-header .sort{display:flex;align-items:center;position:relative}:host .oui-table-head-wrapper .column-header .sort .sort-rank{border-radius:50%;background-color:var(--oui-table-sort-rank-background-color);color:var(--oui-table-sort-rank-text-color);font-size:1rem;display:flex;justify-content:center;border:1px dashed var(--oui-table-sort-rank-border-color);align-items:center;width:1.4rem;height:1.4rem}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTableHeadComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-table-head', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgTemplateOutlet, OuiIconComponent, NgClass], template: "<div class=\"oui-table-head-wrapper\">\n  @for (column of columns(); track trackById($index, column)) {\n    <div #columnRef id=\"header-{{column.id}}\" class=\"column-header\" (click)=\"toggleSort(column)\" [ngClass]=\"{'sortable': column.isSortable}\">\n      @if (!column.headerCellTemplate) {\n        <span class=\"header-label\">{{column.label}}</span>\n      }\n      @if (column.headerCellTemplate) {\n        <ng-container [ngTemplateOutlet]=\"column.headerCellTemplate!\"> </ng-container>\n      }\n      <div class=\"sort\">\n        @if (sortOrder()[column.id]) {\n          <div class=\"sort-rank\">{{sortOrder()[column.id].rank}}</div>\n        }\n        @if (column.isSortable && sortOrder()[column.id]) {\n          <div class=\"sort-icon\">\n            @if (sortOrder()[column.id].direction === 'DESC') {\n              <oui-icon\n                icon=\"assets/icons/caret_down.svg\"\n              ></oui-icon>\n            }@else if (sortOrder()[column.id].direction === 'ASC') {\n              <oui-icon\n                icon=\"assets/icons/caret_up.svg\"\n              ></oui-icon>\n            }\n            @else if (!sortOrder()[column.id]) {\n              <oui-icon icon=\"assets/icons/unfold_more.svg\">\n              </oui-icon>\n            }\n          </div>\n        }\n      </div>\n    </div>\n  }\n</div>\n", styles: [":host{flex:1;display:flex;width:100%}:host .oui-table-head-wrapper{display:flex;flex:1;width:100%;background-color:var(--oui-table-header-background-color);height:var(--oui-table-header-height)}:host .oui-table-head-wrapper .column-header{flex:1;display:flex;height:auto;justify-content:var(--oui-table-header-alignment);align-items:center;overflow:hidden;box-sizing:border-box;font-size:var(--oui-table-header-font-size);font-weight:var(--oui-table-header-font-weight);margin:var(--oui-table-header-padding);flex-wrap:nowrap;-webkit-user-select:none;user-select:none;background-color:var(--oui-table-header-background-color);color:var(--oui-table-header-text-color)}:host .oui-table-head-wrapper .column-header.sortable{cursor:pointer;transition:background-color .3s}:host .oui-table-head-wrapper .column-header.sortable:hover{background-color:var(--oui-table-header-background-color-hover)}:host .oui-table-head-wrapper .column-header .header-label{white-space:nowrap}:host .oui-table-head-wrapper .column-header .sort{display:flex;align-items:center;position:relative}:host .oui-table-head-wrapper .column-header .sort .sort-rank{border-radius:50%;background-color:var(--oui-table-sort-rank-background-color);color:var(--oui-table-sort-rank-text-color);font-size:1rem;display:flex;justify-content:center;border:1px dashed var(--oui-table-sort-rank-border-color);align-items:center;width:1.4rem;height:1.4rem}\n"] }]
        }], ctorParameters: () => [{ type: i0.DestroyRef }, { type: i0.ChangeDetectorRef }], propDecorators: { tableService: [{
                type: Input,
                args: [{ required: true }]
            }], columnRefs: [{
                type: ViewChildren,
                args: ['columnRef']
            }] } });

class OuiTableComponent {
    tableService;
    outerColumnWrapper;
    innerColumnWrapper;
    componentWrapper;
    items = [];
    set columns(newColumns) {
        this.columnsSignal.set(newColumns);
    }
    get columns() {
        return this.columnsSignal();
    }
    set options(newOptions) {
        this.optionsSignal.set(newOptions);
        this.onOptionsChanged();
    }
    get options() {
        return this.optionsSignal();
    }
    columnsSignal = signal([]);
    defaultOptions = {
        hasVirtualScroll: true,
        itemHeight: 50,
        trackBy: 'id',
    };
    optionsSignal = signal({});
    combinedOptions = computed(() => {
        return {
            ...this.defaultOptions,
            ...this.optionsSignal(),
        };
    });
    constructor(tableService) {
        this.tableService = tableService;
    }
    onResize(result) {
        this.tableService.setTableHeight(result);
    }
    onItemsChanged() {
        this.tableService.setItems(this.items.map((item, index) => {
            return {
                item,
                index,
            };
        }));
    }
    onOptionsChanged() {
        this.tableService.setOptions(this.combinedOptions());
    }
    onColumnsChanged() {
        this.tableService.setColumns(this.columnsSignal());
    }
    ngOnChanges(changes) {
        if ('items' in changes) {
            this.items = changes.items.currentValue;
            this.onItemsChanged();
        }
        if ('columns' in changes) {
            this.columns = changes.columns.currentValue;
            this.onColumnsChanged();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTableComponent, deps: [{ token: TableService }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiTableComponent, isStandalone: true, selector: "oui-table", inputs: { items: "items", columns: "columns", options: "options" }, providers: [TableService], viewQueries: [{ propertyName: "outerColumnWrapper", first: true, predicate: ["outerColumnWrapper"], descendants: true, static: true }, { propertyName: "innerColumnWrapper", first: true, predicate: ["innerColumnWrapper"], descendants: true, static: true }, { propertyName: "componentWrapper", first: true, predicate: ["componentWrapper"], descendants: true, static: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"table-wrapper\" #componentWrapper (ngxResize)=\"onResize($event)\">\n  <div class=\"table-inner-wrapper\">\n    <div class=\"column-header-wrapper\">\n      <oui-table-head [tableService]=\"tableService\"></oui-table-head>\n    </div>\n    <div class=\"column-body-wrapper\">\n      <oui-table-body [tableService]=\"tableService\" [options]=\"combinedOptions()\"></oui-table-body>\n    </div>\n  </div>\n</div>\n", styles: [":host{width:100%;height:100%}:host .table-wrapper{width:100%;height:100%;max-height:100%;position:relative}:host .table-wrapper .table-inner-wrapper{width:100%;height:100%;display:flex;flex-direction:column;position:relative}:host .table-wrapper .table-inner-wrapper .column-header-wrapper{display:flex;flex:0 0 var(--oui-table-header-height);border-width:var(--oui-table-header-border-width);border-style:var(--oui-table-header-border-style);border-color:var(--oui-table-header-border-color);border-radius:var(--oui-table-border-radius);height:auto;position:relative}:host .table-wrapper .table-inner-wrapper .column-body-wrapper{display:flex;flex:1;position:relative;flex-direction:column;overflow:hidden}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .row{display:flex}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .row .item{flex:1;height:var(--oui-table-item-height)}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .inner-column-body-wrapper{flex:1;position:absolute;top:0;width:100%;left:0;transition:transform .3s;display:flex}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .inner-column-body-wrapper .scrollDummy{position:relative;width:100%;height:100%}\n"], dependencies: [{ kind: "component", type: OuiTableBodyComponent, selector: "oui-table-body", inputs: ["tableService", "options"] }, { kind: "component", type: OuiTableHeadComponent, selector: "oui-table-head", inputs: ["tableService"] }, { kind: "directive", type: NgxResize, selector: "[ngxResize]", inputs: ["ngxResizeOptions"], outputs: ["ngxResize"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-table', standalone: true, imports: [
                        NgTemplateOutlet,
                        OuiTableBodyComponent,
                        OuiTableHeadComponent,
                        NgxResize,
                    ], providers: [TableService], template: "<div class=\"table-wrapper\" #componentWrapper (ngxResize)=\"onResize($event)\">\n  <div class=\"table-inner-wrapper\">\n    <div class=\"column-header-wrapper\">\n      <oui-table-head [tableService]=\"tableService\"></oui-table-head>\n    </div>\n    <div class=\"column-body-wrapper\">\n      <oui-table-body [tableService]=\"tableService\" [options]=\"combinedOptions()\"></oui-table-body>\n    </div>\n  </div>\n</div>\n", styles: [":host{width:100%;height:100%}:host .table-wrapper{width:100%;height:100%;max-height:100%;position:relative}:host .table-wrapper .table-inner-wrapper{width:100%;height:100%;display:flex;flex-direction:column;position:relative}:host .table-wrapper .table-inner-wrapper .column-header-wrapper{display:flex;flex:0 0 var(--oui-table-header-height);border-width:var(--oui-table-header-border-width);border-style:var(--oui-table-header-border-style);border-color:var(--oui-table-header-border-color);border-radius:var(--oui-table-border-radius);height:auto;position:relative}:host .table-wrapper .table-inner-wrapper .column-body-wrapper{display:flex;flex:1;position:relative;flex-direction:column;overflow:hidden}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .row{display:flex}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .row .item{flex:1;height:var(--oui-table-item-height)}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .inner-column-body-wrapper{flex:1;position:absolute;top:0;width:100%;left:0;transition:transform .3s;display:flex}:host .table-wrapper .table-inner-wrapper .column-body-wrapper .inner-column-body-wrapper .scrollDummy{position:relative;width:100%;height:100%}\n"] }]
        }], ctorParameters: () => [{ type: TableService }], propDecorators: { outerColumnWrapper: [{
                type: ViewChild,
                args: ['outerColumnWrapper', { static: true }]
            }], innerColumnWrapper: [{
                type: ViewChild,
                args: ['innerColumnWrapper', { static: true }]
            }], componentWrapper: [{
                type: ViewChild,
                args: ['componentWrapper', { static: true }]
            }], items: [{
                type: Input,
                args: [{ required: true }]
            }], columns: [{
                type: Input,
                args: [{ required: true }]
            }], options: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiTableComponent };
//# sourceMappingURL=orbital-ui-table.mjs.map
