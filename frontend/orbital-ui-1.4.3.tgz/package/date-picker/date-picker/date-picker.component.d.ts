import { AfterViewInit, ChangeDetectorRef, OnChanges, SimpleChanges, TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export interface IOuiDatePickerOptions {
    translations?: IDateLabelTranslations;
    getDateClass?: (date: Date, mode: 'day' | 'month' | 'year') => string;
    getHoverClass?: (date: Date, mode: 'day' | 'month' | 'year') => string;
    isDateUnsetEnabled?: boolean;
}
export interface IDateLabelTranslations {
    months: string[];
    days: string[];
}
export interface IOuiDatePickerCombinedOptions {
    translations: IDateLabelTranslations;
    getDateClass: (date: Date, mode: 'day' | 'month' | 'year') => string;
    getHoverClass: (date: Date, mode: 'day' | 'month' | 'year') => string;
    isDateUnsetEnabled: boolean;
}
/**
 * Component for a calendar date-picker.
 *
 */
export declare class OuiDatePickerComponent implements AfterViewInit, OnChanges {
    private cdr;
    dayTemplate: TemplateRef<any>;
    monthTemplate: TemplateRef<any>;
    yearTemplate: TemplateRef<any>;
    /**
     *   The selected date in the datepicker
     */
    date: import("@angular/core").ModelSignal<Date | undefined>;
    /**
     *   The options to pass to the calendar. getDateClass let's you assign custom classes to specific dates. The only input parameter
     *   to the function is a date, and the return value is the entire classname to be added to the date.
     *   getHoverClass works the same, except adds classes to specific dates when hovering over them.
     */
    options: IOuiDatePickerOptions;
    dateSelectionOptions: Date[][];
    mode: 'year' | 'month' | 'day';
    selectedCalendarDate: Date;
    currentTemplate: TemplateRef<any>;
    private defaultOptions;
    combinedOptions: IOuiDatePickerCombinedOptions;
    constructor(cdr: ChangeDetectorRef);
    ngAfterViewInit(): void;
    select(): void;
    changeModeSelection(): void;
    private generateDateSelection;
    selectDay(date: Date): void;
    selectMonth(date: Date): void;
    selectYear(date: Date): void;
    goBackParent(): void;
    goForwardParent(): void;
    getDateClass(date: Date): string;
    onDateHover(date: Date, element: HTMLElement): void;
    onDateUnhover(date: Date, element: HTMLElement): void;
    private combineOptions;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiDatePickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiDatePickerComponent, "oui-date-picker", never, { "date": { "alias": "date"; "required": true; "isSignal": true; }; "options": { "alias": "options"; "required": false; }; }, { "date": "dateChange"; }, never, never, true, never>;
}
//# sourceMappingURL=date-picker.component.d.ts.map