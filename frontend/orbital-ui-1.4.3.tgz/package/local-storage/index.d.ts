/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/local-storage" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-local-storage.d.ts.map