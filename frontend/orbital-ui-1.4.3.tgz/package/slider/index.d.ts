/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/slider" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-slider.d.ts.map