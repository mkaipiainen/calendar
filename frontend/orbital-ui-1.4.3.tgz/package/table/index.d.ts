/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/table" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-table.d.ts.map