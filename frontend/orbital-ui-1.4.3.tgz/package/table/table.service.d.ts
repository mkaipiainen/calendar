import { IOuiTableColumn, IOuiTableCombinedOptions, IOuiTableInternalItem, IScrollTop } from './types';
import { ResizeResult } from 'ngxtension/resize';
import * as i0 from "@angular/core";
export declare class TableService {
    private items;
    private visibleItems;
    private tableHeight;
    private scrollTopRefreshLimit;
    private options;
    private scrollTop;
    private visibleItemIndices;
    private sortOrder;
    private scrollTopSubject;
    private dataSubject;
    private indexToSubject;
    private tableHeightSubject;
    private columnsSubject;
    private itemsSubject;
    private sortOrderSubject;
    readonly scrollTop$: import("rxjs").Observable<IScrollTop>;
    readonly sortOrder$: import("rxjs").Observable<{
        column: IOuiTableColumn;
        direction: 'ASC' | 'DESC';
    }[]>;
    readonly columns$: import("rxjs").Observable<IOuiTableColumn[]>;
    readonly indexTo$: import("rxjs").Observable<number>;
    readonly items$: import("rxjs").Observable<IOuiTableInternalItem[]>;
    constructor();
    setItems(items: IOuiTableInternalItem[]): void;
    setColumns(columns: IOuiTableColumn[]): void;
    toggleSort(column: IOuiTableColumn): void;
    private sortData;
    private defaultSortFunction;
    setTableHeight(height: ResizeResult): void;
    setScrollTop(scrollTop: IScrollTop): void;
    setOptions(options: IOuiTableCombinedOptions): void;
    private setVisibleItems;
    private getVisibleItemIndices;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TableService>;
}
//# sourceMappingURL=table.service.d.ts.map