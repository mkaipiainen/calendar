import { Component, EventEmitter, Inject, Input, Output, ViewChild, } from '@angular/core';
import { CommonModule, DOCUMENT } from '@angular/common';
import { OuiIconComponent } from 'orbital-ui/icon';
import { zip } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i0 from "@angular/core";
import * as i1 from "@angular/common";
/**
 * Component to display two maps side-by-side with a comparison slider
 * Requires the maps inside the parent container to have position absolute, and full width + height.
 */
export class MapboxSideBySideComponent {
    renderer;
    document;
    destroyRef;
    cdr;
    defaultOptions = {
        orientation: 'vertical',
    };
    usedOptions = this.defaultOptions;
    currentDragPosition = {
        left: 0,
        top: 0,
    };
    isDragging = false;
    offsetAtDragStart = 0;
    resizeObserver;
    dragLeftRatio = 0;
    isInitialisationStarted = false;
    #isPassiveSupported = {
        passive: false,
    };
    isVertical = true;
    leftMap;
    rightMap;
    mapContainer;
    options = this.defaultOptions;
    leftLabelTemplate;
    rightLabelTemplate;
    dragged = new EventEmitter();
    clicked = new EventEmitter();
    released = new EventEmitter();
    dragContainer;
    drag;
    imageLabelRight;
    imageLabelLeft;
    unlisteners = [];
    isInitialised = false;
    constructor(renderer, document, destroyRef, cdr) {
        this.renderer = renderer;
        this.document = document;
        this.destroyRef = destroyRef;
        this.cdr = cdr;
        try {
            window.addEventListener('test', null, Object.defineProperty({}, 'passive', {
                get: () => {
                    this.#isPassiveSupported = { passive: true };
                },
            }));
        }
        catch (err) { }
    }
    ngAfterViewInit() {
        if (this.rightMap && this.leftMap && !this.isInitialisationStarted) {
            this.subscribeToMapLoad();
        }
    }
    subscribeToMapLoad() {
        zip([this.rightMap.onLoad$, this.leftMap.onLoad$])
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => {
            this.initialiseComponent();
            setTimeout(() => {
                this.isInitialised = true;
                this.cdr.detectChanges();
            });
        });
    }
    initialiseComponent() {
        this.usedOptions = { ...this.defaultOptions, ...this.options };
        this.isVertical = this.usedOptions.orientation === 'vertical';
        setTimeout(() => {
            this.initializeSideBySide();
            this.initializeEventListeners();
        });
        this.initializeResizeObserver();
    }
    initializeSideBySide() {
        this.currentDragPosition = {
            top: this.isVertical ? 0 : this.getHeightMidpoint(),
            left: this.isVertical ? this.getWidthMidpoint() : 0,
        };
        this.calculateDragRatio();
        this.setDragPositionAndClip();
    }
    calculateDragRatio() {
        this.dragLeftRatio =
            this.currentDragPosition.left / this.getMapContainerWidth();
    }
    getMapContainerWidth() {
        return this.mapContainer.getBoundingClientRect().width;
    }
    getMapContainerHeight() {
        return this.mapContainer.getBoundingClientRect().height;
    }
    getWidthMidpoint() {
        return this.getMapContainerWidth() / 2 - this.getDragContainerWidthOffset();
    }
    getHeightMidpoint() {
        return (this.getMapContainerHeight() / 2 - this.getDragContainerWidthOffset());
    }
    getDragWidthOffset() {
        return this.drag.nativeElement.offsetWidth / 2;
    }
    getDragHeightOffset() {
        return this.drag.nativeElement.offsetHeight / 2;
    }
    getDragContainerWidthOffset() {
        return this.dragContainer.nativeElement.offsetWidth / 2;
    }
    getDragContainerHeightOffset() {
        return this.dragContainer.nativeElement.offsetHeight / 2;
    }
    setDragPositionAndClip() {
        if (this.leftMap?.map && this.rightMap?.map) {
            this.setTransform(this.currentDragPosition.left, this.currentDragPosition.top);
            this.renderer.setStyle(this.leftMap.elementRef.nativeElement, 'clipPath', this.getLeftMapClip());
            this.renderer.setStyle(this.rightMap.elementRef.nativeElement, 'clipPath', this.getRightMapClip());
            this.setLeftLabelPosition();
        }
        else {
            console.warn('Tried to initialize side by side without maps');
        }
    }
    setTransform(x, y) {
        this.renderer.setStyle(this.dragContainer.nativeElement, 'transform', `translate(${x}px, ${y}px)`);
    }
    getLeftMapClip() {
        let clip = '';
        if (this.isVertical) {
            const mapWidth = this.getMapContainerWidth();
            const percentage = ((this.currentDragPosition.left + this.getDragContainerWidthOffset()) /
                mapWidth) *
                100;
            clip = `polygon(0 0, ${percentage}% 0, ${percentage}% 100%, 0% 100%)`;
        }
        else {
            const mapHeight = this.getMapContainerHeight();
            const percentage = ((this.currentDragPosition.top - this.getDragContainerHeightOffset()) /
                mapHeight) *
                100;
            clip = `polygon(0 ${percentage}%, 100% ${percentage}%, 100% 100%, 0% 100%)`;
        }
        return clip;
    }
    getRightMapClip() {
        let clip = '';
        if (this.isVertical) {
            const mapWidth = this.getMapContainerWidth();
            const percentage = ((this.currentDragPosition.left + this.getDragContainerWidthOffset()) /
                mapWidth) *
                100;
            clip = `polygon(${percentage}% 0%, 100% 0%, 100% 100%, ${percentage}% 100%)`;
        }
        else {
            const mapHeight = this.getMapContainerHeight();
            const percentage = ((this.currentDragPosition.top - this.getDragContainerHeightOffset()) /
                mapHeight) *
                100;
            clip = `polygon(0% 100%, 100% 100%, 100% ${percentage}%, 0% ${percentage}%)`;
        }
        return clip;
    }
    initializeEventListeners() {
        this.unlisteners.push(this.renderer.listen(this.dragContainer.nativeElement, 'mousedown', this.onMouseDown.bind(this)));
        this.unlisteners.push(this.renderer.listen(this.dragContainer.nativeElement, 'touchstart', this.onMouseDown.bind(this)));
        this.unlisteners.push(this.renderer.listen(this.document, 'mouseup', this.onMouseUp.bind(this)));
        this.unlisteners.push(this.renderer.listen(this.document, 'touchend', this.onMouseUp.bind(this)));
        this.unlisteners.push(this.renderer.listen(this.document, 'mousemove', this.onMouseMove.bind(this)));
        this.unlisteners.push(this.renderer.listen(this.document, 'touchmove', this.onMouseMove.bind(this)));
    }
    onMouseDown(event) {
        this.renderer.addClass(this.document.body, 'user-select-none');
        this.isDragging = true;
        const clientX = event instanceof MouseEvent ? event.clientX : event.touches[0].clientX;
        const clientY = event instanceof MouseEvent ? event.clientY : event.touches[0].clientY;
        const dragBbox = this.dragContainer.nativeElement.getBoundingClientRect();
        this.offsetAtDragStart = this.isVertical
            ? clientX - dragBbox.left
            : clientY - dragBbox.top;
        this.clicked.emit(event);
    }
    onMouseUp(event) {
        this.renderer.removeClass(this.document.body, 'user-select-none');
        this.isDragging = false;
        this.released.emit(event);
    }
    onMouseMove(event) {
        if (this.isDragging &&
            (event instanceof MouseEvent ||
                (window.TouchEvent && event instanceof TouchEvent))) {
            event.stopPropagation();
            if (!this.#isPassiveSupported.passive) {
                event.preventDefault();
                event.returnValue = false;
            }
            event.cancelBubble = true;
            const clientX = event instanceof MouseEvent ? event.clientX : event.touches[0].clientX;
            this.dragged.emit(event);
            const mapBbox = this.mapContainer.getBoundingClientRect();
            const left = clientX -
                mapBbox.left -
                this.getDragWidthOffset() -
                this.offsetAtDragStart;
            const containerWidth = this.dragContainer.nativeElement.getBoundingClientRect().width;
            const isLeftEdge = left < containerWidth / 2;
            const isRightEdge = left + containerWidth > mapBbox.width;
            if (isLeftEdge || isRightEdge) {
                return;
            }
            this.currentDragPosition = {
                top: 0,
                left,
            };
            this.calculateDragRatio();
            this.setDragPositionAndClip();
        }
    }
    setLeftLabelPosition() {
        if (!this.imageLabelLeft) {
            return;
        }
        const left = this.currentDragPosition.left -
            this.imageLabelLeft.nativeElement.getBoundingClientRect().width +
            this.getDragContainerWidthOffset() -
            this.getDragWidthOffset();
        this.renderer.setStyle(this.imageLabelLeft.nativeElement, 'transform', `translate(${left}px, ${0}px)`);
    }
    resizeSideBySide() {
        const mapContainerWidth = this.getMapContainerWidth();
        let newLeft = mapContainerWidth * this.dragLeftRatio;
        const leftEdge = this.getDragContainerWidthOffset();
        const rightEdge = mapContainerWidth - this.getDragContainerWidthOffset();
        if (newLeft < leftEdge) {
            newLeft = leftEdge;
        }
        else if (newLeft > rightEdge) {
            newLeft = rightEdge;
        }
        this.currentDragPosition = {
            left: newLeft,
            top: this.currentDragPosition.top,
        };
        this.setDragPositionAndClip();
    }
    initializeResizeObserver() {
        this.resizeObserver = new ResizeObserver(() => {
            this.resizeSideBySide();
        });
        this.resizeObserver.observe(this.mapContainer);
    }
    ngOnDestroy() {
        for (const unlistener of this.unlisteners) {
            unlistener();
        }
        if (this.resizeObserver) {
            this.resizeObserver.unobserve(this.mapContainer);
        }
    }
    ngOnChanges(changes) {
        if ('leftMap' in changes) {
            this.leftMap = changes['leftMap'].currentValue;
        }
        if ('rightMap' in changes) {
            this.rightMap = changes['rightMap'].currentValue;
        }
        if (this.rightMap && this.leftMap && !this.isInitialisationStarted) {
            this.subscribeToMapLoad();
        }
        this.cdr.detectChanges();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: MapboxSideBySideComponent, deps: [{ token: i0.Renderer2 }, { token: DOCUMENT }, { token: i0.DestroyRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: MapboxSideBySideComponent, isStandalone: true, selector: "mapbox-side-by-side", inputs: { leftMap: "leftMap", rightMap: "rightMap", mapContainer: "mapContainer", options: "options", leftLabelTemplate: "leftLabelTemplate", rightLabelTemplate: "rightLabelTemplate" }, outputs: { dragged: "dragged", clicked: "clicked", released: "released" }, viewQueries: [{ propertyName: "dragContainer", first: true, predicate: ["dragContainer"], descendants: true }, { propertyName: "drag", first: true, predicate: ["drag"], descendants: true }, { propertyName: "imageLabelRight", first: true, predicate: ["imageLabelRight"], descendants: true }, { propertyName: "imageLabelLeft", first: true, predicate: ["imageLabelLeft"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"side-by-side-wrapper\" [ngClass]=\"{'no-show': !isInitialised}\">\n  <div\n    class=\"drag-container\"\n    #dragContainer\n    [ngClass]=\"{ vertical: isVertical, horizontal: !isVertical }\"\n    >\n    <div class=\"drag shadow\" #drag></div>\n    <div class=\"drag-caret-container\">\n      <oui-icon\n        icon=\"assets/icons/caret-left.svg\"\n        [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n        class=\"drag-caret-left\"\n      ></oui-icon>\n      <oui-icon\n        icon=\"assets/icons/caret-right.svg\"\n        [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n        class=\"drag-caret-right\"\n      ></oui-icon>\n    </div>\n  </div>\n\n  @if (leftLabelTemplate) {\n    <div class=\"side-by-side-label-wrapper left\">\n      <ng-content *ngTemplateOutlet=\"leftLabelTemplate\"></ng-content>\n    </div>\n  }\n\n  @if (rightLabelTemplate) {\n    <div class=\"side-by-side-label-wrapper right\">\n      <ng-content *ngTemplateOutlet=\"rightLabelTemplate\"></ng-content>\n    </div>\n  }\n</div>\n", styles: [":host{width:100%;height:100%}:host .side-by-side-wrapper{width:100%;height:100%;opacity:1;transition:opacity .3s}:host .side-by-side-wrapper.no-show{opacity:0;pointer-events:none;transition:opacity 0s}:host .side-by-side-wrapper .drag-container{position:absolute;width:var(--mapbox-side-by-side-caret-container-width)}:host .side-by-side-wrapper .drag-container .drag-caret-container{display:flex;justify-content:space-between;align-items:center;position:absolute;border-width:var(--oui-mapbox-side-by-side-caret-container-border-width);border-style:var(--oui-mapbox-side-by-side-caret-container-border-style);border-color:var(--oui-mapbox-side-by-side-caret-container-border-color);height:var(--mapbox-side-by-side-caret-container-height);width:var(--mapbox-side-by-side-caret-container-width);background-color:var(--mapbox-side-by-side-caret-container-background-color);border-radius:var(--mapbox-side-by-side-caret-container-border-radius)}:host .side-by-side-wrapper .drag-container .drag-caret-container oui-icon{filter:var(--oui-mapbox-side-by-side-caret-icon-filter)}:host .side-by-side-wrapper .drag-container:hover{cursor:col-resize}:host .side-by-side-wrapper .drag-container.vertical{height:100%;width:40px;display:flex;justify-content:center;align-items:center}:host .side-by-side-wrapper .drag-container.vertical .drag{width:var(--mapbox-side-by-side-drag-width);background-color:var(--mapbox-side-by-side-drag-background-color);border:solid var(--border-color-primary);border-width:0 1px;height:100%}:host .side-by-side-wrapper .drag-container.horizontal{width:100%;height:40px;display:flex;justify-content:center}:host .side-by-side-wrapper .drag-container.horizontal .drag{height:4px;background-color:#fff;width:100%}:host .side-by-side-wrapper .side-by-side-dropdown{display:flex;align-items:center;position:absolute;top:20px;right:0;width:110px;height:24px;justify-content:center;-webkit-user-select:none;user-select:none}:host .side-by-side-wrapper .side-by-side-dropdown.left{left:0;right:auto}:host .side-by-side-wrapper .side-by-side-label-wrapper{display:flex;align-items:center;position:absolute;top:2rem;flex:0;min-height:3rem;-webkit-user-select:none;user-select:none;font-size:var(--font-size-body-smaller);border-radius:var(--border-radius-default);color:var(--color-dark)}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-content{line-height:1px}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-icon{margin-right:10px}:host .side-by-side-wrapper .side-by-side-label-wrapper.left{z-index:1;right:var(--oui-mapbox-side-by-side-left-label-left)}:host .side-by-side-wrapper .side-by-side-label-wrapper.right{z-index:0;right:var(--oui-mapbox-side-by-side-right-label-right)}:host .side-by-side-wrapper .side-by-side-label-wrapper.right.has-geolocate{right:5rem;margin-right:1rem}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: MapboxSideBySideComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mapbox-side-by-side', standalone: true, imports: [OuiIconComponent, CommonModule], template: "<div class=\"side-by-side-wrapper\" [ngClass]=\"{'no-show': !isInitialised}\">\n  <div\n    class=\"drag-container\"\n    #dragContainer\n    [ngClass]=\"{ vertical: isVertical, horizontal: !isVertical }\"\n    >\n    <div class=\"drag shadow\" #drag></div>\n    <div class=\"drag-caret-container\">\n      <oui-icon\n        icon=\"assets/icons/caret-left.svg\"\n        [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n        class=\"drag-caret-left\"\n      ></oui-icon>\n      <oui-icon\n        icon=\"assets/icons/caret-right.svg\"\n        [options]=\"{\n          strokeColor: 'oui-mapbox-side-by-side-icon-color',\n          fillColor: 'oui-mapbox-side-by-side-icon-color',\n          viewBox: '0 0 48 48'\n        }\"\n        class=\"drag-caret-right\"\n      ></oui-icon>\n    </div>\n  </div>\n\n  @if (leftLabelTemplate) {\n    <div class=\"side-by-side-label-wrapper left\">\n      <ng-content *ngTemplateOutlet=\"leftLabelTemplate\"></ng-content>\n    </div>\n  }\n\n  @if (rightLabelTemplate) {\n    <div class=\"side-by-side-label-wrapper right\">\n      <ng-content *ngTemplateOutlet=\"rightLabelTemplate\"></ng-content>\n    </div>\n  }\n</div>\n", styles: [":host{width:100%;height:100%}:host .side-by-side-wrapper{width:100%;height:100%;opacity:1;transition:opacity .3s}:host .side-by-side-wrapper.no-show{opacity:0;pointer-events:none;transition:opacity 0s}:host .side-by-side-wrapper .drag-container{position:absolute;width:var(--mapbox-side-by-side-caret-container-width)}:host .side-by-side-wrapper .drag-container .drag-caret-container{display:flex;justify-content:space-between;align-items:center;position:absolute;border-width:var(--oui-mapbox-side-by-side-caret-container-border-width);border-style:var(--oui-mapbox-side-by-side-caret-container-border-style);border-color:var(--oui-mapbox-side-by-side-caret-container-border-color);height:var(--mapbox-side-by-side-caret-container-height);width:var(--mapbox-side-by-side-caret-container-width);background-color:var(--mapbox-side-by-side-caret-container-background-color);border-radius:var(--mapbox-side-by-side-caret-container-border-radius)}:host .side-by-side-wrapper .drag-container .drag-caret-container oui-icon{filter:var(--oui-mapbox-side-by-side-caret-icon-filter)}:host .side-by-side-wrapper .drag-container:hover{cursor:col-resize}:host .side-by-side-wrapper .drag-container.vertical{height:100%;width:40px;display:flex;justify-content:center;align-items:center}:host .side-by-side-wrapper .drag-container.vertical .drag{width:var(--mapbox-side-by-side-drag-width);background-color:var(--mapbox-side-by-side-drag-background-color);border:solid var(--border-color-primary);border-width:0 1px;height:100%}:host .side-by-side-wrapper .drag-container.horizontal{width:100%;height:40px;display:flex;justify-content:center}:host .side-by-side-wrapper .drag-container.horizontal .drag{height:4px;background-color:#fff;width:100%}:host .side-by-side-wrapper .side-by-side-dropdown{display:flex;align-items:center;position:absolute;top:20px;right:0;width:110px;height:24px;justify-content:center;-webkit-user-select:none;user-select:none}:host .side-by-side-wrapper .side-by-side-dropdown.left{left:0;right:auto}:host .side-by-side-wrapper .side-by-side-label-wrapper{display:flex;align-items:center;position:absolute;top:2rem;flex:0;min-height:3rem;-webkit-user-select:none;user-select:none;font-size:var(--font-size-body-smaller);border-radius:var(--border-radius-default);color:var(--color-dark)}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-content{line-height:1px}:host .side-by-side-wrapper .side-by-side-label-wrapper .side-by-side-label-icon{margin-right:10px}:host .side-by-side-wrapper .side-by-side-label-wrapper.left{z-index:1;right:var(--oui-mapbox-side-by-side-left-label-left)}:host .side-by-side-wrapper .side-by-side-label-wrapper.right{z-index:0;right:var(--oui-mapbox-side-by-side-right-label-right)}:host .side-by-side-wrapper .side-by-side-label-wrapper.right.has-geolocate{right:5rem;margin-right:1rem}\n"] }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.DestroyRef }, { type: i0.ChangeDetectorRef }], propDecorators: { leftMap: [{
                type: Input,
                args: [{ required: true }]
            }], rightMap: [{
                type: Input,
                args: [{ required: true }]
            }], mapContainer: [{
                type: Input,
                args: [{ required: true }]
            }], options: [{
                type: Input
            }], leftLabelTemplate: [{
                type: Input
            }], rightLabelTemplate: [{
                type: Input
            }], dragged: [{
                type: Output
            }], clicked: [{
                type: Output
            }], released: [{
                type: Output
            }], dragContainer: [{
                type: ViewChild,
                args: ['dragContainer']
            }], drag: [{
                type: ViewChild,
                args: ['drag']
            }], imageLabelRight: [{
                type: ViewChild,
                args: ['imageLabelRight']
            }], imageLabelLeft: [{
                type: ViewChild,
                args: ['imageLabelLeft']
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2lkZS1ieS1zaWRlLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvbWFwYm94L3NpZGUtYnktc2lkZS9tYXBib3gtc2lkZS1ieS1zaWRlL3NpZGUtYnktc2lkZS5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL21hcGJveC9zaWRlLWJ5LXNpZGUvbWFwYm94LXNpZGUtYnktc2lkZS9zaWRlLWJ5LXNpZGUuY29tcG9uZW50Lmh0bWwiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUdMLFNBQVMsRUFHVCxZQUFZLEVBQ1osTUFBTSxFQUNOLEtBQUssRUFHTCxNQUFNLEVBSU4sU0FBUyxHQUNWLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxZQUFZLEVBQUUsUUFBUSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDekQsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDbkQsT0FBTyxFQUFFLEdBQUcsRUFBRSxNQUFNLE1BQU0sQ0FBQztBQUMzQixPQUFPLEVBQUUsa0JBQWtCLEVBQUUsTUFBTSw0QkFBNEIsQ0FBQzs7O0FBWWhFOzs7R0FHRztBQVFILE1BQU0sT0FBTyx5QkFBeUI7SUF5QzFCO0lBQ2tCO0lBQ2xCO0lBQ0E7SUF6Q0YsY0FBYyxHQUF1QjtRQUMzQyxXQUFXLEVBQUUsVUFBVTtLQUN4QixDQUFDO0lBQ00sV0FBVyxHQUF1QixJQUFJLENBQUMsY0FBYyxDQUFDO0lBQ3RELG1CQUFtQixHQUFrQjtRQUMzQyxJQUFJLEVBQUUsQ0FBQztRQUNQLEdBQUcsRUFBRSxDQUFDO0tBQ1AsQ0FBQztJQUNNLFVBQVUsR0FBRyxLQUFLLENBQUM7SUFDbkIsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDO0lBQ3RCLGNBQWMsQ0FBaUI7SUFDL0IsYUFBYSxHQUFHLENBQUMsQ0FBQztJQUNsQix1QkFBdUIsR0FBRyxLQUFLLENBQUM7SUFDeEMsbUJBQW1CLEdBQUc7UUFDcEIsT0FBTyxFQUFFLEtBQUs7S0FDZixDQUFDO0lBRUssVUFBVSxHQUFHLElBQUksQ0FBQztJQUVTLE9BQU8sQ0FBcUI7SUFDNUIsUUFBUSxDQUFxQjtJQUM3QixZQUFZLENBQWlCO0lBQy9DLE9BQU8sR0FBdUIsSUFBSSxDQUFDLGNBQWMsQ0FBQztJQUNsRCxpQkFBaUIsQ0FBbUI7SUFDcEMsa0JBQWtCLENBQW1CO0lBRTNDLE9BQU8sR0FBRyxJQUFJLFlBQVksRUFBRSxDQUFDO0lBQzdCLE9BQU8sR0FBRyxJQUFJLFlBQVksRUFBRSxDQUFDO0lBQzdCLFFBQVEsR0FBRyxJQUFJLFlBQVksRUFBRSxDQUFDO0lBRUosYUFBYSxDQUFhO0lBQ25DLElBQUksQ0FBYTtJQUNOLGVBQWUsQ0FBYTtJQUM3QixjQUFjLENBQWE7SUFFeEQsV0FBVyxHQUFtQixFQUFFLENBQUM7SUFDbEMsYUFBYSxHQUFHLEtBQUssQ0FBQztJQUM3QixZQUNVLFFBQW1CLEVBQ0QsUUFBa0IsRUFDcEMsVUFBc0IsRUFDdEIsR0FBc0I7UUFIdEIsYUFBUSxHQUFSLFFBQVEsQ0FBVztRQUNELGFBQVEsR0FBUixRQUFRLENBQVU7UUFDcEMsZUFBVSxHQUFWLFVBQVUsQ0FBWTtRQUN0QixRQUFHLEdBQUgsR0FBRyxDQUFtQjtRQUU5QixJQUFJLENBQUM7WUFDSCxNQUFNLENBQUMsZ0JBQWdCLENBQ3JCLE1BQU0sRUFDTixJQUFXLEVBQ1gsTUFBTSxDQUFDLGNBQWMsQ0FBQyxFQUFFLEVBQUUsU0FBUyxFQUFFO2dCQUNuQyxHQUFHLEVBQUUsR0FBRyxFQUFFO29CQUNSLElBQUksQ0FBQyxtQkFBbUIsR0FBRyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQztnQkFDL0MsQ0FBQzthQUNGLENBQUMsQ0FDSCxDQUFDO1FBQ0osQ0FBQztRQUFDLE9BQU8sR0FBRyxFQUFFLENBQUMsQ0FBQSxDQUFDO0lBQ2xCLENBQUM7SUFFRCxlQUFlO1FBQ2IsSUFBSSxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztZQUNuRSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUM1QixDQUFDO0lBQ0gsQ0FBQztJQUVPLGtCQUFrQjtRQUN4QixHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQy9DLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDekMsU0FBUyxDQUFDLEdBQUcsRUFBRTtZQUNkLElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1lBQzNCLFVBQVUsQ0FBQyxHQUFHLEVBQUU7Z0JBQ2QsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7Z0JBQzFCLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDM0IsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNQLENBQUM7SUFFTyxtQkFBbUI7UUFDekIsSUFBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLGNBQWMsRUFBRSxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUMvRCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxLQUFLLFVBQVUsQ0FBQztRQUM5RCxVQUFVLENBQUMsR0FBRyxFQUFFO1lBQ2QsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7WUFDNUIsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUM7UUFDbEMsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRU8sb0JBQW9CO1FBQzFCLElBQUksQ0FBQyxtQkFBbUIsR0FBRztZQUN6QixHQUFHLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsaUJBQWlCLEVBQUU7WUFDbkQsSUFBSSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3BELENBQUM7UUFDRixJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUMxQixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztJQUNoQyxDQUFDO0lBRU8sa0JBQWtCO1FBQ3hCLElBQUksQ0FBQyxhQUFhO1lBQ2hCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7SUFDaEUsQ0FBQztJQUVPLG9CQUFvQjtRQUMxQixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxLQUFLLENBQUM7SUFDekQsQ0FBQztJQUVPLHFCQUFxQjtRQUMzQixPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMscUJBQXFCLEVBQUUsQ0FBQyxNQUFNLENBQUM7SUFDMUQsQ0FBQztJQUVPLGdCQUFnQjtRQUN0QixPQUFPLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztJQUM5RSxDQUFDO0lBRU8saUJBQWlCO1FBQ3ZCLE9BQU8sQ0FDTCxJQUFJLENBQUMscUJBQXFCLEVBQUUsR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQ3RFLENBQUM7SUFDSixDQUFDO0lBRU8sa0JBQWtCO1FBQ3hCLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBRU8sbUJBQW1CO1FBQ3pCLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQztJQUNsRCxDQUFDO0lBRU8sMkJBQTJCO1FBQ2pDLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBRU8sNEJBQTRCO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQztJQUMzRCxDQUFDO0lBRU8sc0JBQXNCO1FBQzVCLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLElBQUksSUFBSSxDQUFDLFFBQVEsRUFBRSxHQUFHLEVBQUUsQ0FBQztZQUM1QyxJQUFJLENBQUMsWUFBWSxDQUNmLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLEVBQzdCLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLENBQzdCLENBQUM7WUFDRixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FDcEIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUNyQyxVQUFVLEVBQ1YsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUN0QixDQUFDO1lBQ0YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQ3BCLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFDdEMsVUFBVSxFQUNWLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FDdkIsQ0FBQztZQUNGLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQzlCLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxDQUFDLElBQUksQ0FBQywrQ0FBK0MsQ0FBQyxDQUFDO1FBQ2hFLENBQUM7SUFDSCxDQUFDO0lBRU8sWUFBWSxDQUFDLENBQVMsRUFBRSxDQUFTO1FBQ3ZDLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUNwQixJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFDaEMsV0FBVyxFQUNYLGFBQWEsQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUM1QixDQUFDO0lBQ0osQ0FBQztJQUVPLGNBQWM7UUFDcEIsSUFBSSxJQUFJLEdBQUcsRUFBRSxDQUFDO1FBQ2QsSUFBSSxJQUFJLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDcEIsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixFQUFFLENBQUM7WUFDN0MsTUFBTSxVQUFVLEdBQ2QsQ0FBQyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUM7Z0JBQ25FLFFBQVEsQ0FBQztnQkFDWCxHQUFHLENBQUM7WUFDTixJQUFJLEdBQUcsZ0JBQWdCLFVBQVUsUUFBUSxVQUFVLGtCQUFrQixDQUFDO1FBQ3hFLENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7WUFDL0MsTUFBTSxVQUFVLEdBQ2QsQ0FBQyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLDRCQUE0QixFQUFFLENBQUM7Z0JBQ25FLFNBQVMsQ0FBQztnQkFDWixHQUFHLENBQUM7WUFDTixJQUFJLEdBQUcsYUFBYSxVQUFVLFdBQVcsVUFBVSx3QkFBd0IsQ0FBQztRQUM5RSxDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0lBRU8sZUFBZTtRQUNyQixJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7UUFDZCxJQUFJLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUNwQixNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztZQUM3QyxNQUFNLFVBQVUsR0FDZCxDQUFDLENBQUMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsMkJBQTJCLEVBQUUsQ0FBQztnQkFDbkUsUUFBUSxDQUFDO2dCQUNYLEdBQUcsQ0FBQztZQUNOLElBQUksR0FBRyxXQUFXLFVBQVUsNkJBQTZCLFVBQVUsU0FBUyxDQUFDO1FBQy9FLENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixFQUFFLENBQUM7WUFDL0MsTUFBTSxVQUFVLEdBQ2QsQ0FBQyxDQUFDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHLEdBQUcsSUFBSSxDQUFDLDRCQUE0QixFQUFFLENBQUM7Z0JBQ25FLFNBQVMsQ0FBQztnQkFDWixHQUFHLENBQUM7WUFDTixJQUFJLEdBQUcsb0NBQW9DLFVBQVUsU0FBUyxVQUFVLElBQUksQ0FBQztRQUMvRSxDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0lBRU8sd0JBQXdCO1FBQzlCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUNuQixJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FDbEIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxhQUFhLEVBQ2hDLFdBQVcsRUFDWCxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FDNUIsQ0FDRixDQUFDO1FBQ0YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQ25CLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUNsQixJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsRUFDaEMsWUFBWSxFQUNaLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUM1QixDQUNGLENBQUM7UUFDRixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FDbkIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FDMUUsQ0FBQztRQUNGLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUNuQixJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLFVBQVUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUMzRSxDQUFDO1FBQ0YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQ25CLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUNsQixJQUFJLENBQUMsUUFBUSxFQUNiLFdBQVcsRUFDWCxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FDNUIsQ0FDRixDQUFDO1FBQ0YsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQ25CLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUNsQixJQUFJLENBQUMsUUFBUSxFQUNiLFdBQVcsRUFDWCxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FDNUIsQ0FDRixDQUFDO0lBQ0osQ0FBQztJQUVPLFdBQVcsQ0FBQyxLQUE4QjtRQUNoRCxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO1FBQy9ELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1FBQ3ZCLE1BQU0sT0FBTyxHQUNYLEtBQUssWUFBWSxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQ3pFLE1BQU0sT0FBTyxHQUNYLEtBQUssWUFBWSxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQ3pFLE1BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYSxDQUFDLHFCQUFxQixFQUFFLENBQUM7UUFDMUUsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxVQUFVO1lBQ3RDLENBQUMsQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDLElBQUk7WUFDekIsQ0FBQyxDQUFDLE9BQU8sR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDO1FBQzNCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzNCLENBQUM7SUFFTyxTQUFTLENBQUMsS0FBWTtRQUM1QixJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxrQkFBa0IsQ0FBQyxDQUFDO1FBQ2xFLElBQUksQ0FBQyxVQUFVLEdBQUcsS0FBSyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUFFTyxXQUFXLENBQUMsS0FBWTtRQUM5QixJQUNFLElBQUksQ0FBQyxVQUFVO1lBQ2YsQ0FBQyxLQUFLLFlBQVksVUFBVTtnQkFDMUIsQ0FBQyxNQUFNLENBQUMsVUFBVSxJQUFJLEtBQUssWUFBWSxVQUFVLENBQUMsQ0FBQyxFQUNyRCxDQUFDO1lBQ0QsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ3RDLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztnQkFDdkIsS0FBSyxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUM7WUFDNUIsQ0FBQztZQUNELEtBQUssQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1lBQzFCLE1BQU0sT0FBTyxHQUNYLEtBQUssWUFBWSxVQUFVLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1lBQ3pFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3pCLE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMscUJBQXFCLEVBQUUsQ0FBQztZQUMxRCxNQUFNLElBQUksR0FDUixPQUFPO2dCQUNQLE9BQU8sQ0FBQyxJQUFJO2dCQUNaLElBQUksQ0FBQyxrQkFBa0IsRUFBRTtnQkFDekIsSUFBSSxDQUFDLGlCQUFpQixDQUFDO1lBQ3pCLE1BQU0sY0FBYyxHQUNsQixJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUssQ0FBQztZQUNqRSxNQUFNLFVBQVUsR0FBRyxJQUFJLEdBQUcsY0FBYyxHQUFHLENBQUMsQ0FBQztZQUM3QyxNQUFNLFdBQVcsR0FBRyxJQUFJLEdBQUcsY0FBYyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUM7WUFDMUQsSUFBSSxVQUFVLElBQUksV0FBVyxFQUFFLENBQUM7Z0JBQzlCLE9BQU87WUFDVCxDQUFDO1lBQ0QsSUFBSSxDQUFDLG1CQUFtQixHQUFHO2dCQUN6QixHQUFHLEVBQUUsQ0FBQztnQkFDTixJQUFJO2FBQ0wsQ0FBQztZQUNGLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1lBQzFCLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ2hDLENBQUM7SUFDSCxDQUFDO0lBRU8sb0JBQW9CO1FBQzFCLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDekIsT0FBTztRQUNULENBQUM7UUFDRCxNQUFNLElBQUksR0FDUixJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSTtZQUM3QixJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLEtBQUs7WUFDL0QsSUFBSSxDQUFDLDJCQUEyQixFQUFFO1lBQ2xDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQzVCLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUNwQixJQUFJLENBQUMsY0FBYyxDQUFDLGFBQWEsRUFDakMsV0FBVyxFQUNYLGFBQWEsSUFBSSxPQUFPLENBQUMsS0FBSyxDQUMvQixDQUFDO0lBQ0osQ0FBQztJQUVPLGdCQUFnQjtRQUN0QixNQUFNLGlCQUFpQixHQUFHLElBQUksQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQ3RELElBQUksT0FBTyxHQUFHLGlCQUFpQixHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7UUFDckQsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUM7UUFDcEQsTUFBTSxTQUFTLEdBQUcsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLDJCQUEyQixFQUFFLENBQUM7UUFDekUsSUFBSSxPQUFPLEdBQUcsUUFBUSxFQUFFLENBQUM7WUFDdkIsT0FBTyxHQUFHLFFBQVEsQ0FBQztRQUNyQixDQUFDO2FBQU0sSUFBSSxPQUFPLEdBQUcsU0FBUyxFQUFFLENBQUM7WUFDL0IsT0FBTyxHQUFHLFNBQVMsQ0FBQztRQUN0QixDQUFDO1FBQ0QsSUFBSSxDQUFDLG1CQUFtQixHQUFHO1lBQ3pCLElBQUksRUFBRSxPQUFPO1lBQ2IsR0FBRyxFQUFFLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxHQUFHO1NBQ2xDLENBQUM7UUFDRixJQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQztJQUNoQyxDQUFDO0lBRU8sd0JBQXdCO1FBQzlCLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxjQUFjLENBQUMsR0FBRyxFQUFFO1lBQzVDLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1FBQzFCLENBQUMsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ2pELENBQUM7SUFFTSxXQUFXO1FBQ2hCLEtBQUssTUFBTSxVQUFVLElBQUksSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1lBQzFDLFVBQVUsRUFBRSxDQUFDO1FBQ2YsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUNuRCxDQUFDO0lBQ0gsQ0FBQztJQUVNLFdBQVcsQ0FBQyxPQUFzQjtRQUN2QyxJQUFJLFNBQVMsSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUN6QixJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxZQUFZLENBQUM7UUFDakQsQ0FBQztRQUNELElBQUksVUFBVSxJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQzFCLElBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDLFVBQVUsQ0FBQyxDQUFDLFlBQVksQ0FBQztRQUNuRCxDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsUUFBUSxJQUFJLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztZQUNuRSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztRQUM1QixDQUFDO1FBQ0QsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUMzQixDQUFDO3VHQXhXVSx5QkFBeUIsMkNBMEMxQixRQUFROzJGQTFDUCx5QkFBeUIsZ3ZCQzNDdEMsc3hDQXlDQSxvMkZEQVksZ0JBQWdCLGlGQUFFLFlBQVk7OzJGQUU3Qix5QkFBeUI7a0JBUHJDLFNBQVM7K0JBQ0UscUJBQXFCLGNBR25CLElBQUksV0FDUCxDQUFDLGdCQUFnQixFQUFFLFlBQVksQ0FBQzs7MEJBNEN0QyxNQUFNOzJCQUFDLFFBQVE7a0dBcEJnQixPQUFPO3NCQUF4QyxLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFDUyxRQUFRO3NCQUF6QyxLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFDUyxZQUFZO3NCQUE3QyxLQUFLO3VCQUFDLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRTtnQkFDVCxPQUFPO3NCQUF0QixLQUFLO2dCQUNVLGlCQUFpQjtzQkFBaEMsS0FBSztnQkFDVSxrQkFBa0I7c0JBQWpDLEtBQUs7Z0JBRUksT0FBTztzQkFBaEIsTUFBTTtnQkFDRyxPQUFPO3NCQUFoQixNQUFNO2dCQUNHLFFBQVE7c0JBQWpCLE1BQU07Z0JBRTZCLGFBQWE7c0JBQWhELFNBQVM7dUJBQUMsZUFBZTtnQkFDQyxJQUFJO3NCQUE5QixTQUFTO3VCQUFDLE1BQU07Z0JBQ3FCLGVBQWU7c0JBQXBELFNBQVM7dUJBQUMsaUJBQWlCO2dCQUNTLGNBQWM7c0JBQWxELFNBQVM7dUJBQUMsZ0JBQWdCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgQ2hhbmdlRGV0ZWN0b3JSZWYsXG4gIENvbXBvbmVudCxcbiAgRGVzdHJveVJlZixcbiAgRWxlbWVudFJlZixcbiAgRXZlbnRFbWl0dGVyLFxuICBJbmplY3QsXG4gIElucHV0LFxuICBPbkNoYW5nZXMsXG4gIE9uRGVzdHJveSxcbiAgT3V0cHV0LFxuICBSZW5kZXJlcjIsXG4gIFNpbXBsZUNoYW5nZXMsXG4gIFRlbXBsYXRlUmVmLFxuICBWaWV3Q2hpbGQsXG59IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlLCBET0NVTUVOVCB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBPdWlJY29uQ29tcG9uZW50IH0gZnJvbSAnb3JiaXRhbC11aS9pY29uJztcbmltcG9ydCB7IHppcCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgdGFrZVVudGlsRGVzdHJveWVkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZS9yeGpzLWludGVyb3AnO1xuaW1wb3J0IHsgT3VpTWFwYm94Q29tcG9uZW50IH0gZnJvbSAnLi4vLi4vbWFwYm94LmNvbXBvbmVudCc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgSVNpZGVCeVNpZGVPcHRpb25zIHtcbiAgb3JpZW50YXRpb24/OiAndmVydGljYWwnIHwgJ2hvcml6b250YWwnO1xufVxuXG5pbnRlcmZhY2UgSURyYWdQb3NpdGlvbiB7XG4gIHRvcDogbnVtYmVyO1xuICBsZWZ0OiBudW1iZXI7XG59XG5cbi8qKlxuICogQ29tcG9uZW50IHRvIGRpc3BsYXkgdHdvIG1hcHMgc2lkZS1ieS1zaWRlIHdpdGggYSBjb21wYXJpc29uIHNsaWRlclxuICogUmVxdWlyZXMgdGhlIG1hcHMgaW5zaWRlIHRoZSBwYXJlbnQgY29udGFpbmVyIHRvIGhhdmUgcG9zaXRpb24gYWJzb2x1dGUsIGFuZCBmdWxsIHdpZHRoICsgaGVpZ2h0LlxuICovXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdtYXBib3gtc2lkZS1ieS1zaWRlJyxcbiAgdGVtcGxhdGVVcmw6ICcuL3NpZGUtYnktc2lkZS5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL3NpZGUtYnktc2lkZS5jb21wb25lbnQuc2NzcyddLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbT3VpSWNvbkNvbXBvbmVudCwgQ29tbW9uTW9kdWxlXSxcbn0pXG5leHBvcnQgY2xhc3MgTWFwYm94U2lkZUJ5U2lkZUNvbXBvbmVudFxuICBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSwgT25DaGFuZ2VzXG57XG4gIHByaXZhdGUgZGVmYXVsdE9wdGlvbnM6IElTaWRlQnlTaWRlT3B0aW9ucyA9IHtcbiAgICBvcmllbnRhdGlvbjogJ3ZlcnRpY2FsJyxcbiAgfTtcbiAgcHJpdmF0ZSB1c2VkT3B0aW9uczogSVNpZGVCeVNpZGVPcHRpb25zID0gdGhpcy5kZWZhdWx0T3B0aW9ucztcbiAgcHJpdmF0ZSBjdXJyZW50RHJhZ1Bvc2l0aW9uOiBJRHJhZ1Bvc2l0aW9uID0ge1xuICAgIGxlZnQ6IDAsXG4gICAgdG9wOiAwLFxuICB9O1xuICBwcml2YXRlIGlzRHJhZ2dpbmcgPSBmYWxzZTtcbiAgcHJpdmF0ZSBvZmZzZXRBdERyYWdTdGFydCA9IDA7XG4gIHByaXZhdGUgcmVzaXplT2JzZXJ2ZXI6IFJlc2l6ZU9ic2VydmVyO1xuICBwcml2YXRlIGRyYWdMZWZ0UmF0aW8gPSAwO1xuICBwcml2YXRlIGlzSW5pdGlhbGlzYXRpb25TdGFydGVkID0gZmFsc2U7XG4gICNpc1Bhc3NpdmVTdXBwb3J0ZWQgPSB7XG4gICAgcGFzc2l2ZTogZmFsc2UsXG4gIH07XG5cbiAgcHVibGljIGlzVmVydGljYWwgPSB0cnVlO1xuXG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pIHB1YmxpYyBsZWZ0TWFwOiBPdWlNYXBib3hDb21wb25lbnQ7XG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pIHB1YmxpYyByaWdodE1hcDogT3VpTWFwYm94Q29tcG9uZW50O1xuICBASW5wdXQoeyByZXF1aXJlZDogdHJ1ZSB9KSBwdWJsaWMgbWFwQ29udGFpbmVyOiBIVE1MRGl2RWxlbWVudDtcbiAgQElucHV0KCkgcHVibGljIG9wdGlvbnM6IElTaWRlQnlTaWRlT3B0aW9ucyA9IHRoaXMuZGVmYXVsdE9wdGlvbnM7XG4gIEBJbnB1dCgpIHB1YmxpYyBsZWZ0TGFiZWxUZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PjtcbiAgQElucHV0KCkgcHVibGljIHJpZ2h0TGFiZWxUZW1wbGF0ZTogVGVtcGxhdGVSZWY8YW55PjtcblxuICBAT3V0cHV0KCkgZHJhZ2dlZCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiAgQE91dHB1dCgpIGNsaWNrZWQgPSBuZXcgRXZlbnRFbWl0dGVyKCk7XG4gIEBPdXRwdXQoKSByZWxlYXNlZCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICBAVmlld0NoaWxkKCdkcmFnQ29udGFpbmVyJykgcHJpdmF0ZSBkcmFnQ29udGFpbmVyOiBFbGVtZW50UmVmO1xuICBAVmlld0NoaWxkKCdkcmFnJykgcHJpdmF0ZSBkcmFnOiBFbGVtZW50UmVmO1xuICBAVmlld0NoaWxkKCdpbWFnZUxhYmVsUmlnaHQnKSBwcml2YXRlIGltYWdlTGFiZWxSaWdodDogRWxlbWVudFJlZjtcbiAgQFZpZXdDaGlsZCgnaW1hZ2VMYWJlbExlZnQnKSBwcml2YXRlIGltYWdlTGFiZWxMZWZ0OiBFbGVtZW50UmVmO1xuXG4gIHByaXZhdGUgdW5saXN0ZW5lcnM6ICgoKSA9PiB2b2lkKVtdID0gW107XG4gIHB1YmxpYyBpc0luaXRpYWxpc2VkID0gZmFsc2U7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgcmVuZGVyZXI6IFJlbmRlcmVyMixcbiAgICBASW5qZWN0KERPQ1VNRU5UKSBwcml2YXRlIGRvY3VtZW50OiBEb2N1bWVudCxcbiAgICBwcml2YXRlIGRlc3Ryb3lSZWY6IERlc3Ryb3lSZWYsXG4gICAgcHJpdmF0ZSBjZHI6IENoYW5nZURldGVjdG9yUmVmXG4gICkge1xuICAgIHRyeSB7XG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcbiAgICAgICAgJ3Rlc3QnLFxuICAgICAgICBudWxsIGFzIGFueSxcbiAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHt9LCAncGFzc2l2ZScsIHtcbiAgICAgICAgICBnZXQ6ICgpID0+IHtcbiAgICAgICAgICAgIHRoaXMuI2lzUGFzc2l2ZVN1cHBvcnRlZCA9IHsgcGFzc2l2ZTogdHJ1ZSB9O1xuICAgICAgICAgIH0sXG4gICAgICAgIH0pXG4gICAgICApO1xuICAgIH0gY2F0Y2ggKGVycikge31cbiAgfVxuXG4gIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICBpZiAodGhpcy5yaWdodE1hcCAmJiB0aGlzLmxlZnRNYXAgJiYgIXRoaXMuaXNJbml0aWFsaXNhdGlvblN0YXJ0ZWQpIHtcbiAgICAgIHRoaXMuc3Vic2NyaWJlVG9NYXBMb2FkKCk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBzdWJzY3JpYmVUb01hcExvYWQoKSB7XG4gICAgemlwKFt0aGlzLnJpZ2h0TWFwLm9uTG9hZCQsIHRoaXMubGVmdE1hcC5vbkxvYWQkXSlcbiAgICAgIC5waXBlKHRha2VVbnRpbERlc3Ryb3llZCh0aGlzLmRlc3Ryb3lSZWYpKVxuICAgICAgLnN1YnNjcmliZSgoKSA9PiB7XG4gICAgICAgIHRoaXMuaW5pdGlhbGlzZUNvbXBvbmVudCgpO1xuICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICB0aGlzLmlzSW5pdGlhbGlzZWQgPSB0cnVlO1xuICAgICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgaW5pdGlhbGlzZUNvbXBvbmVudCgpIHtcbiAgICB0aGlzLnVzZWRPcHRpb25zID0geyAuLi50aGlzLmRlZmF1bHRPcHRpb25zLCAuLi50aGlzLm9wdGlvbnMgfTtcbiAgICB0aGlzLmlzVmVydGljYWwgPSB0aGlzLnVzZWRPcHRpb25zLm9yaWVudGF0aW9uID09PSAndmVydGljYWwnO1xuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgdGhpcy5pbml0aWFsaXplU2lkZUJ5U2lkZSgpO1xuICAgICAgdGhpcy5pbml0aWFsaXplRXZlbnRMaXN0ZW5lcnMoKTtcbiAgICB9KTtcbiAgICB0aGlzLmluaXRpYWxpemVSZXNpemVPYnNlcnZlcigpO1xuICB9XG5cbiAgcHJpdmF0ZSBpbml0aWFsaXplU2lkZUJ5U2lkZSgpIHtcbiAgICB0aGlzLmN1cnJlbnREcmFnUG9zaXRpb24gPSB7XG4gICAgICB0b3A6IHRoaXMuaXNWZXJ0aWNhbCA/IDAgOiB0aGlzLmdldEhlaWdodE1pZHBvaW50KCksXG4gICAgICBsZWZ0OiB0aGlzLmlzVmVydGljYWwgPyB0aGlzLmdldFdpZHRoTWlkcG9pbnQoKSA6IDAsXG4gICAgfTtcbiAgICB0aGlzLmNhbGN1bGF0ZURyYWdSYXRpbygpO1xuICAgIHRoaXMuc2V0RHJhZ1Bvc2l0aW9uQW5kQ2xpcCgpO1xuICB9XG5cbiAgcHJpdmF0ZSBjYWxjdWxhdGVEcmFnUmF0aW8oKSB7XG4gICAgdGhpcy5kcmFnTGVmdFJhdGlvID1cbiAgICAgIHRoaXMuY3VycmVudERyYWdQb3NpdGlvbi5sZWZ0IC8gdGhpcy5nZXRNYXBDb250YWluZXJXaWR0aCgpO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRNYXBDb250YWluZXJXaWR0aCgpIHtcbiAgICByZXR1cm4gdGhpcy5tYXBDb250YWluZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkud2lkdGg7XG4gIH1cblxuICBwcml2YXRlIGdldE1hcENvbnRhaW5lckhlaWdodCgpIHtcbiAgICByZXR1cm4gdGhpcy5tYXBDb250YWluZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCkuaGVpZ2h0O1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRXaWR0aE1pZHBvaW50KCkge1xuICAgIHJldHVybiB0aGlzLmdldE1hcENvbnRhaW5lcldpZHRoKCkgLyAyIC0gdGhpcy5nZXREcmFnQ29udGFpbmVyV2lkdGhPZmZzZXQoKTtcbiAgfVxuXG4gIHByaXZhdGUgZ2V0SGVpZ2h0TWlkcG9pbnQoKSB7XG4gICAgcmV0dXJuIChcbiAgICAgIHRoaXMuZ2V0TWFwQ29udGFpbmVySGVpZ2h0KCkgLyAyIC0gdGhpcy5nZXREcmFnQ29udGFpbmVyV2lkdGhPZmZzZXQoKVxuICAgICk7XG4gIH1cblxuICBwcml2YXRlIGdldERyYWdXaWR0aE9mZnNldCgpIHtcbiAgICByZXR1cm4gdGhpcy5kcmFnLm5hdGl2ZUVsZW1lbnQub2Zmc2V0V2lkdGggLyAyO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXREcmFnSGVpZ2h0T2Zmc2V0KCkge1xuICAgIHJldHVybiB0aGlzLmRyYWcubmF0aXZlRWxlbWVudC5vZmZzZXRIZWlnaHQgLyAyO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXREcmFnQ29udGFpbmVyV2lkdGhPZmZzZXQoKSB7XG4gICAgcmV0dXJuIHRoaXMuZHJhZ0NvbnRhaW5lci5uYXRpdmVFbGVtZW50Lm9mZnNldFdpZHRoIC8gMjtcbiAgfVxuXG4gIHByaXZhdGUgZ2V0RHJhZ0NvbnRhaW5lckhlaWdodE9mZnNldCgpIHtcbiAgICByZXR1cm4gdGhpcy5kcmFnQ29udGFpbmVyLm5hdGl2ZUVsZW1lbnQub2Zmc2V0SGVpZ2h0IC8gMjtcbiAgfVxuXG4gIHByaXZhdGUgc2V0RHJhZ1Bvc2l0aW9uQW5kQ2xpcCgpIHtcbiAgICBpZiAodGhpcy5sZWZ0TWFwPy5tYXAgJiYgdGhpcy5yaWdodE1hcD8ubWFwKSB7XG4gICAgICB0aGlzLnNldFRyYW5zZm9ybShcbiAgICAgICAgdGhpcy5jdXJyZW50RHJhZ1Bvc2l0aW9uLmxlZnQsXG4gICAgICAgIHRoaXMuY3VycmVudERyYWdQb3NpdGlvbi50b3BcbiAgICAgICk7XG4gICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKFxuICAgICAgICB0aGlzLmxlZnRNYXAuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LFxuICAgICAgICAnY2xpcFBhdGgnLFxuICAgICAgICB0aGlzLmdldExlZnRNYXBDbGlwKClcbiAgICAgICk7XG4gICAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKFxuICAgICAgICB0aGlzLnJpZ2h0TWFwLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCxcbiAgICAgICAgJ2NsaXBQYXRoJyxcbiAgICAgICAgdGhpcy5nZXRSaWdodE1hcENsaXAoKVxuICAgICAgKTtcbiAgICAgIHRoaXMuc2V0TGVmdExhYmVsUG9zaXRpb24oKTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc29sZS53YXJuKCdUcmllZCB0byBpbml0aWFsaXplIHNpZGUgYnkgc2lkZSB3aXRob3V0IG1hcHMnKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHNldFRyYW5zZm9ybSh4OiBudW1iZXIsIHk6IG51bWJlcikge1xuICAgIHRoaXMucmVuZGVyZXIuc2V0U3R5bGUoXG4gICAgICB0aGlzLmRyYWdDb250YWluZXIubmF0aXZlRWxlbWVudCxcbiAgICAgICd0cmFuc2Zvcm0nLFxuICAgICAgYHRyYW5zbGF0ZSgke3h9cHgsICR7eX1weClgXG4gICAgKTtcbiAgfVxuXG4gIHByaXZhdGUgZ2V0TGVmdE1hcENsaXAoKSB7XG4gICAgbGV0IGNsaXAgPSAnJztcbiAgICBpZiAodGhpcy5pc1ZlcnRpY2FsKSB7XG4gICAgICBjb25zdCBtYXBXaWR0aCA9IHRoaXMuZ2V0TWFwQ29udGFpbmVyV2lkdGgoKTtcbiAgICAgIGNvbnN0IHBlcmNlbnRhZ2UgPVxuICAgICAgICAoKHRoaXMuY3VycmVudERyYWdQb3NpdGlvbi5sZWZ0ICsgdGhpcy5nZXREcmFnQ29udGFpbmVyV2lkdGhPZmZzZXQoKSkgL1xuICAgICAgICAgIG1hcFdpZHRoKSAqXG4gICAgICAgIDEwMDtcbiAgICAgIGNsaXAgPSBgcG9seWdvbigwIDAsICR7cGVyY2VudGFnZX0lIDAsICR7cGVyY2VudGFnZX0lIDEwMCUsIDAlIDEwMCUpYDtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc3QgbWFwSGVpZ2h0ID0gdGhpcy5nZXRNYXBDb250YWluZXJIZWlnaHQoKTtcbiAgICAgIGNvbnN0IHBlcmNlbnRhZ2UgPVxuICAgICAgICAoKHRoaXMuY3VycmVudERyYWdQb3NpdGlvbi50b3AgLSB0aGlzLmdldERyYWdDb250YWluZXJIZWlnaHRPZmZzZXQoKSkgL1xuICAgICAgICAgIG1hcEhlaWdodCkgKlxuICAgICAgICAxMDA7XG4gICAgICBjbGlwID0gYHBvbHlnb24oMCAke3BlcmNlbnRhZ2V9JSwgMTAwJSAke3BlcmNlbnRhZ2V9JSwgMTAwJSAxMDAlLCAwJSAxMDAlKWA7XG4gICAgfVxuICAgIHJldHVybiBjbGlwO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRSaWdodE1hcENsaXAoKSB7XG4gICAgbGV0IGNsaXAgPSAnJztcbiAgICBpZiAodGhpcy5pc1ZlcnRpY2FsKSB7XG4gICAgICBjb25zdCBtYXBXaWR0aCA9IHRoaXMuZ2V0TWFwQ29udGFpbmVyV2lkdGgoKTtcbiAgICAgIGNvbnN0IHBlcmNlbnRhZ2UgPVxuICAgICAgICAoKHRoaXMuY3VycmVudERyYWdQb3NpdGlvbi5sZWZ0ICsgdGhpcy5nZXREcmFnQ29udGFpbmVyV2lkdGhPZmZzZXQoKSkgL1xuICAgICAgICAgIG1hcFdpZHRoKSAqXG4gICAgICAgIDEwMDtcbiAgICAgIGNsaXAgPSBgcG9seWdvbigke3BlcmNlbnRhZ2V9JSAwJSwgMTAwJSAwJSwgMTAwJSAxMDAlLCAke3BlcmNlbnRhZ2V9JSAxMDAlKWA7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IG1hcEhlaWdodCA9IHRoaXMuZ2V0TWFwQ29udGFpbmVySGVpZ2h0KCk7XG4gICAgICBjb25zdCBwZXJjZW50YWdlID1cbiAgICAgICAgKCh0aGlzLmN1cnJlbnREcmFnUG9zaXRpb24udG9wIC0gdGhpcy5nZXREcmFnQ29udGFpbmVySGVpZ2h0T2Zmc2V0KCkpIC9cbiAgICAgICAgICBtYXBIZWlnaHQpICpcbiAgICAgICAgMTAwO1xuICAgICAgY2xpcCA9IGBwb2x5Z29uKDAlIDEwMCUsIDEwMCUgMTAwJSwgMTAwJSAke3BlcmNlbnRhZ2V9JSwgMCUgJHtwZXJjZW50YWdlfSUpYDtcbiAgICB9XG4gICAgcmV0dXJuIGNsaXA7XG4gIH1cblxuICBwcml2YXRlIGluaXRpYWxpemVFdmVudExpc3RlbmVycygpIHtcbiAgICB0aGlzLnVubGlzdGVuZXJzLnB1c2goXG4gICAgICB0aGlzLnJlbmRlcmVyLmxpc3RlbihcbiAgICAgICAgdGhpcy5kcmFnQ29udGFpbmVyLm5hdGl2ZUVsZW1lbnQsXG4gICAgICAgICdtb3VzZWRvd24nLFxuICAgICAgICB0aGlzLm9uTW91c2VEb3duLmJpbmQodGhpcylcbiAgICAgIClcbiAgICApO1xuICAgIHRoaXMudW5saXN0ZW5lcnMucHVzaChcbiAgICAgIHRoaXMucmVuZGVyZXIubGlzdGVuKFxuICAgICAgICB0aGlzLmRyYWdDb250YWluZXIubmF0aXZlRWxlbWVudCxcbiAgICAgICAgJ3RvdWNoc3RhcnQnLFxuICAgICAgICB0aGlzLm9uTW91c2VEb3duLmJpbmQodGhpcylcbiAgICAgIClcbiAgICApO1xuICAgIHRoaXMudW5saXN0ZW5lcnMucHVzaChcbiAgICAgIHRoaXMucmVuZGVyZXIubGlzdGVuKHRoaXMuZG9jdW1lbnQsICdtb3VzZXVwJywgdGhpcy5vbk1vdXNlVXAuYmluZCh0aGlzKSlcbiAgICApO1xuICAgIHRoaXMudW5saXN0ZW5lcnMucHVzaChcbiAgICAgIHRoaXMucmVuZGVyZXIubGlzdGVuKHRoaXMuZG9jdW1lbnQsICd0b3VjaGVuZCcsIHRoaXMub25Nb3VzZVVwLmJpbmQodGhpcykpXG4gICAgKTtcbiAgICB0aGlzLnVubGlzdGVuZXJzLnB1c2goXG4gICAgICB0aGlzLnJlbmRlcmVyLmxpc3RlbihcbiAgICAgICAgdGhpcy5kb2N1bWVudCxcbiAgICAgICAgJ21vdXNlbW92ZScsXG4gICAgICAgIHRoaXMub25Nb3VzZU1vdmUuYmluZCh0aGlzKVxuICAgICAgKVxuICAgICk7XG4gICAgdGhpcy51bmxpc3RlbmVycy5wdXNoKFxuICAgICAgdGhpcy5yZW5kZXJlci5saXN0ZW4oXG4gICAgICAgIHRoaXMuZG9jdW1lbnQsXG4gICAgICAgICd0b3VjaG1vdmUnLFxuICAgICAgICB0aGlzLm9uTW91c2VNb3ZlLmJpbmQodGhpcylcbiAgICAgIClcbiAgICApO1xuICB9XG5cbiAgcHJpdmF0ZSBvbk1vdXNlRG93bihldmVudDogTW91c2VFdmVudCB8IFRvdWNoRXZlbnQpIHtcbiAgICB0aGlzLnJlbmRlcmVyLmFkZENsYXNzKHRoaXMuZG9jdW1lbnQuYm9keSwgJ3VzZXItc2VsZWN0LW5vbmUnKTtcbiAgICB0aGlzLmlzRHJhZ2dpbmcgPSB0cnVlO1xuICAgIGNvbnN0IGNsaWVudFggPVxuICAgICAgZXZlbnQgaW5zdGFuY2VvZiBNb3VzZUV2ZW50ID8gZXZlbnQuY2xpZW50WCA6IGV2ZW50LnRvdWNoZXNbMF0uY2xpZW50WDtcbiAgICBjb25zdCBjbGllbnRZID1cbiAgICAgIGV2ZW50IGluc3RhbmNlb2YgTW91c2VFdmVudCA/IGV2ZW50LmNsaWVudFkgOiBldmVudC50b3VjaGVzWzBdLmNsaWVudFk7XG4gICAgY29uc3QgZHJhZ0Jib3ggPSB0aGlzLmRyYWdDb250YWluZXIubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICB0aGlzLm9mZnNldEF0RHJhZ1N0YXJ0ID0gdGhpcy5pc1ZlcnRpY2FsXG4gICAgICA/IGNsaWVudFggLSBkcmFnQmJveC5sZWZ0XG4gICAgICA6IGNsaWVudFkgLSBkcmFnQmJveC50b3A7XG4gICAgdGhpcy5jbGlja2VkLmVtaXQoZXZlbnQpO1xuICB9XG5cbiAgcHJpdmF0ZSBvbk1vdXNlVXAoZXZlbnQ6IEV2ZW50KSB7XG4gICAgdGhpcy5yZW5kZXJlci5yZW1vdmVDbGFzcyh0aGlzLmRvY3VtZW50LmJvZHksICd1c2VyLXNlbGVjdC1ub25lJyk7XG4gICAgdGhpcy5pc0RyYWdnaW5nID0gZmFsc2U7XG4gICAgdGhpcy5yZWxlYXNlZC5lbWl0KGV2ZW50KTtcbiAgfVxuXG4gIHByaXZhdGUgb25Nb3VzZU1vdmUoZXZlbnQ6IEV2ZW50KSB7XG4gICAgaWYgKFxuICAgICAgdGhpcy5pc0RyYWdnaW5nICYmXG4gICAgICAoZXZlbnQgaW5zdGFuY2VvZiBNb3VzZUV2ZW50IHx8XG4gICAgICAgICh3aW5kb3cuVG91Y2hFdmVudCAmJiBldmVudCBpbnN0YW5jZW9mIFRvdWNoRXZlbnQpKVxuICAgICkge1xuICAgICAgZXZlbnQuc3RvcFByb3BhZ2F0aW9uKCk7XG4gICAgICBpZiAoIXRoaXMuI2lzUGFzc2l2ZVN1cHBvcnRlZC5wYXNzaXZlKSB7XG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG4gICAgICAgIGV2ZW50LnJldHVyblZhbHVlID0gZmFsc2U7XG4gICAgICB9XG4gICAgICBldmVudC5jYW5jZWxCdWJibGUgPSB0cnVlO1xuICAgICAgY29uc3QgY2xpZW50WCA9XG4gICAgICAgIGV2ZW50IGluc3RhbmNlb2YgTW91c2VFdmVudCA/IGV2ZW50LmNsaWVudFggOiBldmVudC50b3VjaGVzWzBdLmNsaWVudFg7XG4gICAgICB0aGlzLmRyYWdnZWQuZW1pdChldmVudCk7XG4gICAgICBjb25zdCBtYXBCYm94ID0gdGhpcy5tYXBDb250YWluZXIuZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7XG4gICAgICBjb25zdCBsZWZ0ID1cbiAgICAgICAgY2xpZW50WCAtXG4gICAgICAgIG1hcEJib3gubGVmdCAtXG4gICAgICAgIHRoaXMuZ2V0RHJhZ1dpZHRoT2Zmc2V0KCkgLVxuICAgICAgICB0aGlzLm9mZnNldEF0RHJhZ1N0YXJ0O1xuICAgICAgY29uc3QgY29udGFpbmVyV2lkdGggPVxuICAgICAgICB0aGlzLmRyYWdDb250YWluZXIubmF0aXZlRWxlbWVudC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS53aWR0aDtcbiAgICAgIGNvbnN0IGlzTGVmdEVkZ2UgPSBsZWZ0IDwgY29udGFpbmVyV2lkdGggLyAyO1xuICAgICAgY29uc3QgaXNSaWdodEVkZ2UgPSBsZWZ0ICsgY29udGFpbmVyV2lkdGggPiBtYXBCYm94LndpZHRoO1xuICAgICAgaWYgKGlzTGVmdEVkZ2UgfHwgaXNSaWdodEVkZ2UpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgdGhpcy5jdXJyZW50RHJhZ1Bvc2l0aW9uID0ge1xuICAgICAgICB0b3A6IDAsXG4gICAgICAgIGxlZnQsXG4gICAgICB9O1xuICAgICAgdGhpcy5jYWxjdWxhdGVEcmFnUmF0aW8oKTtcbiAgICAgIHRoaXMuc2V0RHJhZ1Bvc2l0aW9uQW5kQ2xpcCgpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgc2V0TGVmdExhYmVsUG9zaXRpb24oKSB7XG4gICAgaWYgKCF0aGlzLmltYWdlTGFiZWxMZWZ0KSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGxlZnQgPVxuICAgICAgdGhpcy5jdXJyZW50RHJhZ1Bvc2l0aW9uLmxlZnQgLVxuICAgICAgdGhpcy5pbWFnZUxhYmVsTGVmdC5uYXRpdmVFbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLndpZHRoICtcbiAgICAgIHRoaXMuZ2V0RHJhZ0NvbnRhaW5lcldpZHRoT2Zmc2V0KCkgLVxuICAgICAgdGhpcy5nZXREcmFnV2lkdGhPZmZzZXQoKTtcbiAgICB0aGlzLnJlbmRlcmVyLnNldFN0eWxlKFxuICAgICAgdGhpcy5pbWFnZUxhYmVsTGVmdC5uYXRpdmVFbGVtZW50LFxuICAgICAgJ3RyYW5zZm9ybScsXG4gICAgICBgdHJhbnNsYXRlKCR7bGVmdH1weCwgJHswfXB4KWBcbiAgICApO1xuICB9XG5cbiAgcHJpdmF0ZSByZXNpemVTaWRlQnlTaWRlKCkge1xuICAgIGNvbnN0IG1hcENvbnRhaW5lcldpZHRoID0gdGhpcy5nZXRNYXBDb250YWluZXJXaWR0aCgpO1xuICAgIGxldCBuZXdMZWZ0ID0gbWFwQ29udGFpbmVyV2lkdGggKiB0aGlzLmRyYWdMZWZ0UmF0aW87XG4gICAgY29uc3QgbGVmdEVkZ2UgPSB0aGlzLmdldERyYWdDb250YWluZXJXaWR0aE9mZnNldCgpO1xuICAgIGNvbnN0IHJpZ2h0RWRnZSA9IG1hcENvbnRhaW5lcldpZHRoIC0gdGhpcy5nZXREcmFnQ29udGFpbmVyV2lkdGhPZmZzZXQoKTtcbiAgICBpZiAobmV3TGVmdCA8IGxlZnRFZGdlKSB7XG4gICAgICBuZXdMZWZ0ID0gbGVmdEVkZ2U7XG4gICAgfSBlbHNlIGlmIChuZXdMZWZ0ID4gcmlnaHRFZGdlKSB7XG4gICAgICBuZXdMZWZ0ID0gcmlnaHRFZGdlO1xuICAgIH1cbiAgICB0aGlzLmN1cnJlbnREcmFnUG9zaXRpb24gPSB7XG4gICAgICBsZWZ0OiBuZXdMZWZ0LFxuICAgICAgdG9wOiB0aGlzLmN1cnJlbnREcmFnUG9zaXRpb24udG9wLFxuICAgIH07XG4gICAgdGhpcy5zZXREcmFnUG9zaXRpb25BbmRDbGlwKCk7XG4gIH1cblxuICBwcml2YXRlIGluaXRpYWxpemVSZXNpemVPYnNlcnZlcigpIHtcbiAgICB0aGlzLnJlc2l6ZU9ic2VydmVyID0gbmV3IFJlc2l6ZU9ic2VydmVyKCgpID0+IHtcbiAgICAgIHRoaXMucmVzaXplU2lkZUJ5U2lkZSgpO1xuICAgIH0pO1xuXG4gICAgdGhpcy5yZXNpemVPYnNlcnZlci5vYnNlcnZlKHRoaXMubWFwQ29udGFpbmVyKTtcbiAgfVxuXG4gIHB1YmxpYyBuZ09uRGVzdHJveSgpIHtcbiAgICBmb3IgKGNvbnN0IHVubGlzdGVuZXIgb2YgdGhpcy51bmxpc3RlbmVycykge1xuICAgICAgdW5saXN0ZW5lcigpO1xuICAgIH1cbiAgICBpZiAodGhpcy5yZXNpemVPYnNlcnZlcikge1xuICAgICAgdGhpcy5yZXNpemVPYnNlcnZlci51bm9ic2VydmUodGhpcy5tYXBDb250YWluZXIpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XG4gICAgaWYgKCdsZWZ0TWFwJyBpbiBjaGFuZ2VzKSB7XG4gICAgICB0aGlzLmxlZnRNYXAgPSBjaGFuZ2VzWydsZWZ0TWFwJ10uY3VycmVudFZhbHVlO1xuICAgIH1cbiAgICBpZiAoJ3JpZ2h0TWFwJyBpbiBjaGFuZ2VzKSB7XG4gICAgICB0aGlzLnJpZ2h0TWFwID0gY2hhbmdlc1sncmlnaHRNYXAnXS5jdXJyZW50VmFsdWU7XG4gICAgfVxuICAgIGlmICh0aGlzLnJpZ2h0TWFwICYmIHRoaXMubGVmdE1hcCAmJiAhdGhpcy5pc0luaXRpYWxpc2F0aW9uU3RhcnRlZCkge1xuICAgICAgdGhpcy5zdWJzY3JpYmVUb01hcExvYWQoKTtcbiAgICB9XG4gICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xuICB9XG59XG4iLCI8ZGl2IGNsYXNzPVwic2lkZS1ieS1zaWRlLXdyYXBwZXJcIiBbbmdDbGFzc109XCJ7J25vLXNob3cnOiAhaXNJbml0aWFsaXNlZH1cIj5cbiAgPGRpdlxuICAgIGNsYXNzPVwiZHJhZy1jb250YWluZXJcIlxuICAgICNkcmFnQ29udGFpbmVyXG4gICAgW25nQ2xhc3NdPVwieyB2ZXJ0aWNhbDogaXNWZXJ0aWNhbCwgaG9yaXpvbnRhbDogIWlzVmVydGljYWwgfVwiXG4gICAgPlxuICAgIDxkaXYgY2xhc3M9XCJkcmFnIHNoYWRvd1wiICNkcmFnPjwvZGl2PlxuICAgIDxkaXYgY2xhc3M9XCJkcmFnLWNhcmV0LWNvbnRhaW5lclwiPlxuICAgICAgPG91aS1pY29uXG4gICAgICAgIGljb249XCJhc3NldHMvaWNvbnMvY2FyZXQtbGVmdC5zdmdcIlxuICAgICAgICBbb3B0aW9uc109XCJ7XG4gICAgICAgICAgc3Ryb2tlQ29sb3I6ICdvdWktbWFwYm94LXNpZGUtYnktc2lkZS1pY29uLWNvbG9yJyxcbiAgICAgICAgICBmaWxsQ29sb3I6ICdvdWktbWFwYm94LXNpZGUtYnktc2lkZS1pY29uLWNvbG9yJyxcbiAgICAgICAgICB2aWV3Qm94OiAnMCAwIDQ4IDQ4J1xuICAgICAgICB9XCJcbiAgICAgICAgY2xhc3M9XCJkcmFnLWNhcmV0LWxlZnRcIlxuICAgICAgPjwvb3VpLWljb24+XG4gICAgICA8b3VpLWljb25cbiAgICAgICAgaWNvbj1cImFzc2V0cy9pY29ucy9jYXJldC1yaWdodC5zdmdcIlxuICAgICAgICBbb3B0aW9uc109XCJ7XG4gICAgICAgICAgc3Ryb2tlQ29sb3I6ICdvdWktbWFwYm94LXNpZGUtYnktc2lkZS1pY29uLWNvbG9yJyxcbiAgICAgICAgICBmaWxsQ29sb3I6ICdvdWktbWFwYm94LXNpZGUtYnktc2lkZS1pY29uLWNvbG9yJyxcbiAgICAgICAgICB2aWV3Qm94OiAnMCAwIDQ4IDQ4J1xuICAgICAgICB9XCJcbiAgICAgICAgY2xhc3M9XCJkcmFnLWNhcmV0LXJpZ2h0XCJcbiAgICAgID48L291aS1pY29uPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cblxuICBAaWYgKGxlZnRMYWJlbFRlbXBsYXRlKSB7XG4gICAgPGRpdiBjbGFzcz1cInNpZGUtYnktc2lkZS1sYWJlbC13cmFwcGVyIGxlZnRcIj5cbiAgICAgIDxuZy1jb250ZW50ICpuZ1RlbXBsYXRlT3V0bGV0PVwibGVmdExhYmVsVGVtcGxhdGVcIj48L25nLWNvbnRlbnQ+XG4gICAgPC9kaXY+XG4gIH1cblxuICBAaWYgKHJpZ2h0TGFiZWxUZW1wbGF0ZSkge1xuICAgIDxkaXYgY2xhc3M9XCJzaWRlLWJ5LXNpZGUtbGFiZWwtd3JhcHBlciByaWdodFwiPlxuICAgICAgPG5nLWNvbnRlbnQgKm5nVGVtcGxhdGVPdXRsZXQ9XCJyaWdodExhYmVsVGVtcGxhdGVcIj48L25nLWNvbnRlbnQ+XG4gICAgPC9kaXY+XG4gIH1cbjwvZGl2PlxuIl19