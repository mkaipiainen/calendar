/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/file-dropzone" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-file-dropzone.d.ts.map