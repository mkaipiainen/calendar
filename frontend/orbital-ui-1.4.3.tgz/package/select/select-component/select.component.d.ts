import { AfterViewInit, DestroyRef, ElementRef, EventEmitter, OnChanges, SimpleChanges, TemplateRef, ViewContainerRef, WritableSignal } from '@angular/core';
import { OuiSelectService } from '../select.service';
import * as i0 from "@angular/core";
export type OuiSelectOptions = {
    labelKey?: string;
    idKey?: string;
    type?: 'standard' | 'underlined';
    isMultiple?: boolean;
    search?: {
        isEnabled: boolean;
        isFocusedOnOpen?: boolean;
    };
    contentClass?: string;
    getToggleLabel?: (item: any) => string;
    dropdownHeight?: string;
    isSelectingWithKeyboardActive?: boolean;
};
/**
 * Component that can be used to create select-dropdowns.You can either pass simple strings in an array as the options to choose from,
 * or alternatively pass in objects with an additionally defined label-key and id-key.
 *
 * Example use:
 * <oui-select [(model)]="selectedItem" [idKey]="'value'" [labelKey]="'name'" [options]="selectValues"></oui-select>
 */
export declare class OuiSelectComponent implements AfterViewInit, OnChanges {
    private vcr;
    private ouiSelectService;
    private destroyRef;
    private document;
    private cdr;
    /**
     *   labelKey       - The key in each object that's used to display a text in the dropdown.
     *   idKey          - The key in each object that is used to define which item is selected. Essentially the key in each object which should be used to differentiate each itme from each other item.
     *   type:          - The type of the select. Can be either 'standard' or 'underlined'. Defaults to 'standard'
     */
    options: import("@angular/core").InputSignal<OuiSelectOptions | undefined>;
    isOpen: import("@angular/core").ModelSignal<boolean>;
    /**
     *   The options the user can choose from in the dropdown. If given a list of strings, simply shows those strings, and binds
     *   the model to the selected string. If given an array of objects, also need to pass in a labelKey and and idKey -input
     *   (although they are by default 'label' and 'id').
     */
    items: import("@angular/core").InputSignal<any[]>;
    disabled: boolean;
    /**
     *   The model that's bound to the selected item
     */
    model: any;
    /**
     *   A template that should be used for each item. If none is given, then uses a default. This can be used if you need
     *   heavily customized dropdown-items
     */
    template: TemplateRef<any> | null;
    /**
     *   Triggered when model changes
     */
    modelChange: EventEmitter<any>;
    /**
     *   Triggered when dropdown closes
     */
    closed: EventEmitter<any>;
    dropdownContent: TemplateRef<any>;
    origin: ElementRef;
    private defaultOptions;
    private currentDropdown;
    private closed$;
    combinedOptions: import("@angular/core").Signal<{
        labelKey: string;
        idKey: string;
        type?: "standard" | "underlined" | undefined;
        isMultiple: boolean;
        search?: {
            isEnabled: boolean;
            isFocusedOnOpen?: boolean | undefined;
        } | undefined;
        isSelectingWithKeyboardActive: boolean;
        contentClass: string;
        getToggleLabel: (item: any) => string;
        dropdownHeight?: string | undefined;
    } & {
        labelKey?: string | undefined;
        idKey?: string | undefined;
        type?: "standard" | "underlined" | undefined;
        isMultiple?: boolean | undefined;
        search?: {
            isEnabled: boolean;
            isFocusedOnOpen?: boolean | undefined;
        } | undefined;
        contentClass?: string | undefined;
        getToggleLabel?: ((item: any) => string) | undefined;
        dropdownHeight?: string | undefined;
        isSelectingWithKeyboardActive?: boolean | undefined;
    }>;
    view: any;
    popperRef: any;
    isClosing: boolean;
    id: string;
    dropdownHeight: WritableSignal<string>;
    selectToggleLabel: WritableSignal<string>;
    searchValue: WritableSignal<string>;
    itemType: import("@angular/core").Signal<"object" | "simple">;
    candidateForSelectionIndex: WritableSignal<number>;
    filteredItems: import("@angular/core").Signal<any[]>;
    constructor(vcr: ViewContainerRef, ouiSelectService: OuiSelectService, destroyRef: DestroyRef, document: Document);
    ngAfterViewInit(): void;
    get label(): any;
    select(option: any): void;
    private updateToggleLabel;
    open(): void;
    toggle(): void;
    close(): void;
    onClick(event: MouseEvent, targetElement: HTMLElement): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiSelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiSelectComponent, "oui-select", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "isOpen": { "alias": "isOpen"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; }; "model": { "alias": "model"; "required": false; }; "template": { "alias": "template"; "required": false; }; }, { "isOpen": "isOpenChange"; "modelChange": "modelChange"; "closed": "closed"; }, never, never, true, never>;
}
//# sourceMappingURL=select.component.d.ts.map