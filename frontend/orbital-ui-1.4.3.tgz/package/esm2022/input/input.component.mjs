import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output, ViewChild, } from '@angular/core';
import { FormsModule, NG_VALIDATORS, NG_VALUE_ACCESSOR, } from '@angular/forms';
import { NgClass } from '@angular/common';
import { OuiIconComponent } from 'orbital-ui/icon';
import { GUID } from 'orbital-ui/helpers';
import anime from 'animejs';
import { IsNilPipe } from 'orbital-ui/pipes';
import { InputClassPipe } from './input-class.pipe';
import { merge } from 'lodash-es';
import * as i0 from "@angular/core";
import * as i1 from "./input.service";
import * as i2 from "@angular/cdk/text-field";
import * as i3 from "@angular/forms";
/**
 * Component to add input-fields.
 *
 *   Example use:
 *   <oui-input variant="underlined" [(model)]="myInputValue" placeholder="Please write your input..."></oui-input>
 */
export class OuiInputComponent {
    ouiInputService;
    cdr;
    elementRef;
    renderer;
    autofillMonitor;
    inputElement;
    autosizeSpan;
    inputWrapperElement;
    /**
     *   The model that's bound to the input field
     */
    model;
    /**
     * Options of the input-field. See IOuiInputOptions for more information
     */
    set options(options) {
        this.#combinedOptions = merge({
            ...this.#defaultOptions,
            ...options,
        });
    }
    get options() {
        return this.#combinedOptions;
    }
    /**
     *   The event emitted when input field changes.
     */
    modelChange = new EventEmitter();
    /**
     *   The event emitted when the hasError-field changes
     */
    hasErrorChange = new EventEmitter();
    #formOnChange = () => { };
    #formOnTouched = () => { };
    #isTouched = false;
    #defaultOptions = {
        type: 'text',
        placeholder: '',
        label: '',
        variant: 'standard',
        fontSize: '1.5rem',
        sizeToContent: false,
        maxLength: undefined,
        noPadding: false,
        endIcon: undefined,
    };
    #combinedOptions = {
        type: 'text',
        placeholder: '',
        label: '',
        variant: 'standard',
        fontSize: '1.5rem',
        sizeToContent: false,
        maxLength: undefined,
        noPadding: false,
        endIcon: undefined,
    };
    isFocused = false;
    isDisabled = false;
    isActive = false;
    id = GUID();
    isInitialized = false;
    sizeToContentModel = '';
    constructor(ouiInputService, cdr, elementRef, renderer, autofillMonitor) {
        this.ouiInputService = ouiInputService;
        this.cdr = cdr;
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.autofillMonitor = autofillMonitor;
        this.ouiInputService.register(this);
    }
    onModelChange(data) {
        if (this.options.maxLength && data.length > this.options.maxLength) {
            this.model = data.substring(0, this.options.maxLength);
            this.inputElement.nativeElement.value = this.model;
            anime({
                targets: this.elementRef.nativeElement,
                translateX: [
                    {
                        value: 0.5,
                    },
                    {
                        value: -0.5,
                    },
                ],
                loop: 5,
                direction: 'alternate',
                duration: 50,
                scale: 1,
            });
        }
        else {
            this.model = data;
        }
        // Hack to prevent angular from stripping whitespaces
        if (typeof this.model === 'string') {
            this.sizeToContentModel = this.model.replace(/ /g, '.');
        }
        this.#formOnChange(this.model);
        this.modelChange.emit(this.model);
        this.checkIsActive();
    }
    isAutoFilled() {
        const content = `"${String.fromCharCode(0xfeff)}"`;
        const style = window.getComputedStyle(this.inputElement.nativeElement);
        return this.inputElement.nativeElement.value
            ? false
            : content === style.content;
    }
    ngAfterViewInit() {
        const interval = setInterval(() => {
            const isAutoFilled = this.isAutoFilled();
            if (isAutoFilled) {
                this.isFocused = true;
                this.cdr.detectChanges();
                clearInterval(interval);
            }
        }, 200);
        setTimeout(() => {
            clearInterval(interval);
        }, 3000);
        this.checkIsActive();
        this.inputElement.nativeElement.style.fontSize = this.options.fontSize;
        if (this.options.sizeToContent) {
            this.autosizeSpan.nativeElement.style.fontSize = this.options.fontSize;
        }
        if (this.options.type === 'password' && !this.options.endIcon) {
            this.options.endIcon = {
                icon: 'assets/icons/visibility_off.svg',
                options: {
                    strokeColor: 'color-light',
                    size: '20px',
                },
                onClick: () => {
                    if (this.options.type === 'password') {
                        this.options.type = 'text';
                        if (this.options.endIcon) {
                            this.options.endIcon.icon = 'assets/icons/visibility_on.svg';
                        }
                    }
                    else {
                        this.options.type = 'password';
                        if (this.options.endIcon) {
                            this.options.endIcon.icon = 'assets/icons/visibility_off.svg';
                        }
                    }
                },
            };
            this.cdr.detectChanges();
        }
        // Hack to firstly make sure input is active if browser autofills it, and secondly
        // to make it so that the input doesn't flash due to initial content load
        setTimeout(() => {
            this.isInitialized = true;
            this.checkIsActive();
        }, 400);
    }
    setFocus(value) {
        this.isFocused = value;
        if (this.isFocused) {
            this.setError(false);
        }
        if (!this.#isTouched) {
            this.#isTouched = true;
            this.#formOnTouched();
        }
        this.checkIsActive();
    }
    checkIsActive() {
        this.isActive = this.isFocused || !!this.model;
        this.cdr.detectChanges();
    }
    setError(value) {
        // this.options.hasError = value;
        this.hasErrorChange.emit(value);
        this.cdr.detectChanges();
    }
    onEndIconClick() {
        if (this.options.endIcon?.onClick) {
            this.options.endIcon.onClick();
        }
    }
    writeValue(value) {
        this.model = value;
        this.#formOnChange(this.model);
        this.cdr.detectChanges();
    }
    registerOnChange(fn) {
        this.#formOnChange = fn;
    }
    registerOnTouched(fn) {
        this.#formOnTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.isDisabled = isDisabled;
        this.renderer.setAttribute(this.elementRef.nativeElement, 'disabled', `${isDisabled}`);
        this.cdr.detectChanges();
    }
    validate(control) {
        if (this.options.maxLength) {
            if (control.value.length > this.options.maxLength) {
                return {
                    maxLength: {
                        requiredLength: this.options.maxLength,
                        actualLength: control.value.length,
                    },
                };
            }
        }
        return null;
    }
    ngOnChanges(changes) {
        if ('model' in changes) {
            this.model = changes.model.currentValue;
            this.checkIsActive();
        }
    }
    ngOnDestroy() {
        this.ouiInputService.deregister(this);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiInputComponent, deps: [{ token: i1.OuiInputService }, { token: i0.ChangeDetectorRef }, { token: i0.ElementRef }, { token: i0.Renderer2 }, { token: i2.AutofillMonitor }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiInputComponent, isStandalone: true, selector: "oui-input", inputs: { model: "model", options: "options" }, outputs: { modelChange: "modelChange", hasErrorChange: "hasErrorChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                multi: true,
                useExisting: OuiInputComponent,
            },
            {
                provide: NG_VALIDATORS,
                multi: true,
                useExisting: OuiInputComponent,
            },
        ], viewQueries: [{ propertyName: "inputElement", first: true, predicate: ["inputElement"], descendants: true }, { propertyName: "autosizeSpan", first: true, predicate: ["autosizeSpan"], descendants: true }, { propertyName: "inputWrapperElement", first: true, predicate: ["inputWrapperElement"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<div class=\"{{ model | inputClass: options.variant:isInitialized:isFocused }}\" (click)=\"setFocus(true)\" #inputWrapperElement>\n  @if (options.label) {\n    <div class=\"oui-input-label\">\n      {{ options.label }}\n    </div>\n  }\n  @if (options.maxLength && !(model | isNil)) {\n    <div class=\"oui-input-max-length\">\n      {{ model.length }}/{{ options.maxLength }}\n    </div>\n  }\n  <div class=\"input-wrapper\">\n    @if (options.sizeToContent) {\n      <span #autosizeSpan class=\"autosize\">{{\n        sizeToContentModel\n      }}</span>\n    }\n    <input\n      [ngClass]=\"{\n        autosize: options.sizeToContent,\n        'no-padding': options.noPadding\n      }\"\n      class=\"input\"\n      [placeholder]=\"options.placeholder ?? ''\"\n      (focus)=\"setFocus(true)\"\n      (blur)=\"setFocus(false)\"\n      #inputElement\n      [type]=\"options.type\"\n      [ngModel]=\"model\"\n      (ngModelChange)=\"onModelChange($event)\"\n      />\n    @if (options.endIcon) {\n      <oui-icon\n        class=\"end-icon\"\n        [ngClass]=\"{ 'has-click': options.endIcon.onClick }\"\n        (click)=\"onEndIconClick()\"\n        [icon]=\"options.endIcon.icon\"\n        [options]=\"options.endIcon.options\"\n      ></oui-icon>\n    }\n  </div>\n\n  @if (options.variant === 'underlined') {\n    <div\n      class=\"oui-input-underline-wrapper\"\n      >\n      <div class=\"oui-input-underline-content\"></div>\n    </div>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";:host{flex:1;display:flex;flex-direction:column;position:relative;border-radius:var(--oui-input-border-radius)}:host ::placeholder{color:var(--oui-input-placeholder-color)}:host.ng-invalid.ng-touched .oui-input{border-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input .oui-input-underline-wrapper{background-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input .oui-input-label{color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused{border-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-label{top:-1.5rem;left:0rem;font-size:var(--oui-input-label-focused-font-size);color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-max-length{color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-underline-wrapper .oui-input-underline-content{background-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-label{color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input .oui-input-max-length{color:var(--color-danger)}:host[disabled=true]{opacity:.5;pointer-events:none}:host .oui-input-max-length{font-size:.8rem;position:absolute;top:var(--oui-input-max-length-top);right:var(--oui-input-max-length-right);z-index:1;color:var(--oui-input-max-length-color);transition:color .3s}:host .oui-input{border-radius:var(--oui-input-border-radius);border-color:var(--oui-input-border-color);border-width:var(--oui-input-border-width);border-style:var(--oui-input-border-style);flex:1;position:relative;display:flex;padding:2px;height:100%;transition:border-color .3s;color:var(--oui-input-text-color);background-color:var(--oui-input-background-color)}:host .oui-input.focused{border-color:var(--oui-input-border-active-color)}:host .oui-input.focused .oui-input-label{top:-1.5rem;left:0rem;font-size:var(--oui-input-label-focused-font-size);color:var(--oui-input-label-color-focused)}:host .oui-input.focused .oui-input-max-length{color:var(--oui-input-max-length-color)}:host .oui-input.focused .oui-input-underline-wrapper{height:var(--oui-input-underline-active-height)}:host .oui-input.focused .oui-input-underline-wrapper .oui-input-underline-content{transform:scaleX(1);background-color:var(--oui-input-underline-active-color);transition:transform .4s}:host .oui-input.focused .oui-input-label{color:var(--oui-input-label-color-focused)}:host .oui-input input:-webkit-autofill,:host .oui-input input:-webkit-autofill:hover,:host .oui-input input:-webkit-autofill:focus,:host .oui-input input:-webkit-autofill:active{transition:background-color 9999s ease-in-out 0s!important;transition-delay:9999s!important;-webkit-text-fill-color:var(--oui-input-standard-text-color)!important}:host .oui-input .oui-input-label{color:var(--oui-input-label-color)}:host .oui-input input{width:100%;max-width:100%;color:var(--oui-input-text-color);background-color:var(--oui-input-background-color)}:host .oui-input .input-wrapper .end-icon{margin-right:1rem}:host .oui-input *{transition:none}:host .oui-input.initialized{transition:background-color .3s}:host .oui-input.initialized *{transition:background-color .3s}:host .oui-input .oui-input-underline-wrapper{display:none}:host .oui-input.underlined{background-color:transparent;border:none}:host .oui-input.underlined input{background-color:transparent;padding:0}:host .oui-input .oui-input-underline-wrapper{width:100%;height:var(--oui-input-underline-height);position:absolute;bottom:-1px;left:0;display:flex;justify-content:center;align-items:center;background-color:var(--oui-input-underline-color)}:host .oui-input .oui-input-underline-wrapper .oui-input-underline-content{width:100%;transform:scaleX(0);height:100%;transition:transform .2s;transform-origin:center}:host .oui-input .oui-input-label{position:absolute;top:0;left:.5rem;color:var(--oui-input-text-color);transition:top .2s,left .2s,font-size .2s,color .2s;font-size:var(--oui-input-label-font-size);pointer-events:none;font-family:var(--font-primary);z-index:1}:host .oui-input .input-wrapper{display:flex;align-items:center;position:relative;flex:1}:host .oui-input .input-wrapper input{outline:none;border:none;flex:1;height:100%;font-family:var(--font-primary);font-size:13px;padding:0 1rem}:host .oui-input .input-wrapper input.no-padding{padding:0}:host .oui-input .input-wrapper input.autosize{position:absolute;width:100%}:host .oui-input .input-wrapper span{width:100%;height:100%;padding:0 1rem}:host .oui-input .input-wrapper span.autosize{font-family:var(--font-primary);font-size:13px;opacity:0;pointer-events:none}:host .oui-input .input-wrapper oui-icon.has-click:hover{cursor:pointer}:host input:-webkit-autofill{content:\"\\feff\"}\n"], dependencies: [{ kind: "component", type: OuiIconComponent, selector: "oui-icon", inputs: ["icon", "options"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i3.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i3.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i3.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "pipe", type: IsNilPipe, name: "isNil" }, { kind: "pipe", type: InputClassPipe, name: "inputClass" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-input', standalone: true, imports: [
                        OuiIconComponent,
                        FormsModule,
                        NgClass,
                        IsNilPipe,
                        InputClassPipe
                    ], changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            multi: true,
                            useExisting: OuiInputComponent,
                        },
                        {
                            provide: NG_VALIDATORS,
                            multi: true,
                            useExisting: OuiInputComponent,
                        },
                    ], template: "<div class=\"{{ model | inputClass: options.variant:isInitialized:isFocused }}\" (click)=\"setFocus(true)\" #inputWrapperElement>\n  @if (options.label) {\n    <div class=\"oui-input-label\">\n      {{ options.label }}\n    </div>\n  }\n  @if (options.maxLength && !(model | isNil)) {\n    <div class=\"oui-input-max-length\">\n      {{ model.length }}/{{ options.maxLength }}\n    </div>\n  }\n  <div class=\"input-wrapper\">\n    @if (options.sizeToContent) {\n      <span #autosizeSpan class=\"autosize\">{{\n        sizeToContentModel\n      }}</span>\n    }\n    <input\n      [ngClass]=\"{\n        autosize: options.sizeToContent,\n        'no-padding': options.noPadding\n      }\"\n      class=\"input\"\n      [placeholder]=\"options.placeholder ?? ''\"\n      (focus)=\"setFocus(true)\"\n      (blur)=\"setFocus(false)\"\n      #inputElement\n      [type]=\"options.type\"\n      [ngModel]=\"model\"\n      (ngModelChange)=\"onModelChange($event)\"\n      />\n    @if (options.endIcon) {\n      <oui-icon\n        class=\"end-icon\"\n        [ngClass]=\"{ 'has-click': options.endIcon.onClick }\"\n        (click)=\"onEndIconClick()\"\n        [icon]=\"options.endIcon.icon\"\n        [options]=\"options.endIcon.options\"\n      ></oui-icon>\n    }\n  </div>\n\n  @if (options.variant === 'underlined') {\n    <div\n      class=\"oui-input-underline-wrapper\"\n      >\n      <div class=\"oui-input-underline-content\"></div>\n    </div>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";:host{flex:1;display:flex;flex-direction:column;position:relative;border-radius:var(--oui-input-border-radius)}:host ::placeholder{color:var(--oui-input-placeholder-color)}:host.ng-invalid.ng-touched .oui-input{border-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input .oui-input-underline-wrapper{background-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input .oui-input-label{color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused{border-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-label{top:-1.5rem;left:0rem;font-size:var(--oui-input-label-focused-font-size);color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-max-length{color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-underline-wrapper .oui-input-underline-content{background-color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input.focused .oui-input-label{color:var(--color-danger)}:host.ng-invalid.ng-touched .oui-input .oui-input-max-length{color:var(--color-danger)}:host[disabled=true]{opacity:.5;pointer-events:none}:host .oui-input-max-length{font-size:.8rem;position:absolute;top:var(--oui-input-max-length-top);right:var(--oui-input-max-length-right);z-index:1;color:var(--oui-input-max-length-color);transition:color .3s}:host .oui-input{border-radius:var(--oui-input-border-radius);border-color:var(--oui-input-border-color);border-width:var(--oui-input-border-width);border-style:var(--oui-input-border-style);flex:1;position:relative;display:flex;padding:2px;height:100%;transition:border-color .3s;color:var(--oui-input-text-color);background-color:var(--oui-input-background-color)}:host .oui-input.focused{border-color:var(--oui-input-border-active-color)}:host .oui-input.focused .oui-input-label{top:-1.5rem;left:0rem;font-size:var(--oui-input-label-focused-font-size);color:var(--oui-input-label-color-focused)}:host .oui-input.focused .oui-input-max-length{color:var(--oui-input-max-length-color)}:host .oui-input.focused .oui-input-underline-wrapper{height:var(--oui-input-underline-active-height)}:host .oui-input.focused .oui-input-underline-wrapper .oui-input-underline-content{transform:scaleX(1);background-color:var(--oui-input-underline-active-color);transition:transform .4s}:host .oui-input.focused .oui-input-label{color:var(--oui-input-label-color-focused)}:host .oui-input input:-webkit-autofill,:host .oui-input input:-webkit-autofill:hover,:host .oui-input input:-webkit-autofill:focus,:host .oui-input input:-webkit-autofill:active{transition:background-color 9999s ease-in-out 0s!important;transition-delay:9999s!important;-webkit-text-fill-color:var(--oui-input-standard-text-color)!important}:host .oui-input .oui-input-label{color:var(--oui-input-label-color)}:host .oui-input input{width:100%;max-width:100%;color:var(--oui-input-text-color);background-color:var(--oui-input-background-color)}:host .oui-input .input-wrapper .end-icon{margin-right:1rem}:host .oui-input *{transition:none}:host .oui-input.initialized{transition:background-color .3s}:host .oui-input.initialized *{transition:background-color .3s}:host .oui-input .oui-input-underline-wrapper{display:none}:host .oui-input.underlined{background-color:transparent;border:none}:host .oui-input.underlined input{background-color:transparent;padding:0}:host .oui-input .oui-input-underline-wrapper{width:100%;height:var(--oui-input-underline-height);position:absolute;bottom:-1px;left:0;display:flex;justify-content:center;align-items:center;background-color:var(--oui-input-underline-color)}:host .oui-input .oui-input-underline-wrapper .oui-input-underline-content{width:100%;transform:scaleX(0);height:100%;transition:transform .2s;transform-origin:center}:host .oui-input .oui-input-label{position:absolute;top:0;left:.5rem;color:var(--oui-input-text-color);transition:top .2s,left .2s,font-size .2s,color .2s;font-size:var(--oui-input-label-font-size);pointer-events:none;font-family:var(--font-primary);z-index:1}:host .oui-input .input-wrapper{display:flex;align-items:center;position:relative;flex:1}:host .oui-input .input-wrapper input{outline:none;border:none;flex:1;height:100%;font-family:var(--font-primary);font-size:13px;padding:0 1rem}:host .oui-input .input-wrapper input.no-padding{padding:0}:host .oui-input .input-wrapper input.autosize{position:absolute;width:100%}:host .oui-input .input-wrapper span{width:100%;height:100%;padding:0 1rem}:host .oui-input .input-wrapper span.autosize{font-family:var(--font-primary);font-size:13px;opacity:0;pointer-events:none}:host .oui-input .input-wrapper oui-icon.has-click:hover{cursor:pointer}:host input:-webkit-autofill{content:\"\\feff\"}\n"] }]
        }], ctorParameters: () => [{ type: i1.OuiInputService }, { type: i0.ChangeDetectorRef }, { type: i0.ElementRef }, { type: i0.Renderer2 }, { type: i2.AutofillMonitor }], propDecorators: { inputElement: [{
                type: ViewChild,
                args: ['inputElement']
            }], autosizeSpan: [{
                type: ViewChild,
                args: ['autosizeSpan']
            }], inputWrapperElement: [{
                type: ViewChild,
                args: ['inputWrapperElement']
            }], model: [{
                type: Input
            }], options: [{
                type: Input
            }], modelChange: [{
                type: Output
            }], hasErrorChange: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5wdXQuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9pbnB1dC9pbnB1dC5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL2lucHV0L2lucHV0LmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFFTCx1QkFBdUIsRUFFdkIsU0FBUyxFQUVULFlBQVksRUFFWixLQUFLLEVBR0wsTUFBTSxFQUdOLFNBQVMsR0FDVixNQUFNLGVBQWUsQ0FBQztBQUV2QixPQUFPLEVBR0wsV0FBVyxFQUNYLGFBQWEsRUFDYixpQkFBaUIsR0FHbEIsTUFBTSxnQkFBZ0IsQ0FBQztBQUN4QixPQUFPLEVBQVksT0FBTyxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDcEQsT0FBTyxFQUFtQixnQkFBZ0IsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3BFLE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUMxQyxPQUFPLEtBQUssTUFBTSxTQUFTLENBQUM7QUFDNUIsT0FBTyxFQUFFLFNBQVMsRUFBRSxNQUFNLGtCQUFrQixDQUFDO0FBQzdDLE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSxvQkFBb0IsQ0FBQztBQUNwRCxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sV0FBVyxDQUFDOzs7OztBQXdCbEM7Ozs7O0dBS0c7QUEyQkgsTUFBTSxPQUFPLGlCQUFpQjtJQWtGbEI7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQTdFVixZQUFZLENBQWE7SUFHekIsWUFBWSxDQUFhO0lBR3pCLG1CQUFtQixDQUFhO0lBRWhDOztPQUVHO0lBRUgsS0FBSyxDQUFNO0lBRVg7O09BRUc7SUFDSCxJQUFhLE9BQU8sQ0FBQyxPQUF5QjtRQUM1QyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsS0FBSyxDQUFDO1lBQzVCLEdBQUcsSUFBSSxDQUFDLGVBQWU7WUFDdkIsR0FBRyxPQUFPO1NBQ1gsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUNELElBQUksT0FBTztRQUNULE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDO0lBQy9CLENBQUM7SUFFRDs7T0FFRztJQUNPLFdBQVcsR0FBRyxJQUFJLFlBQVksRUFBTyxDQUFDO0lBRWhEOztPQUVHO0lBQ2MsY0FBYyxHQUFHLElBQUksWUFBWSxFQUFXLENBQUM7SUFFOUQsYUFBYSxHQUF5QixHQUFHLEVBQUUsR0FBRSxDQUFDLENBQUM7SUFDL0MsY0FBYyxHQUFlLEdBQUcsRUFBRSxHQUFFLENBQUMsQ0FBQztJQUV0QyxVQUFVLEdBQUcsS0FBSyxDQUFDO0lBQ25CLGVBQWUsR0FBNkI7UUFDMUMsSUFBSSxFQUFFLE1BQU07UUFDWixXQUFXLEVBQUUsRUFBRTtRQUNmLEtBQUssRUFBRSxFQUFFO1FBQ1QsT0FBTyxFQUFFLFVBQVU7UUFDbkIsUUFBUSxFQUFFLFFBQVE7UUFDbEIsYUFBYSxFQUFFLEtBQUs7UUFDcEIsU0FBUyxFQUFFLFNBQVM7UUFDcEIsU0FBUyxFQUFFLEtBQUs7UUFDaEIsT0FBTyxFQUFFLFNBQVM7S0FDbkIsQ0FBQztJQUNGLGdCQUFnQixHQUE2QjtRQUMzQyxJQUFJLEVBQUUsTUFBTTtRQUNaLFdBQVcsRUFBRSxFQUFFO1FBQ2YsS0FBSyxFQUFFLEVBQUU7UUFDVCxPQUFPLEVBQUUsVUFBVTtRQUNuQixRQUFRLEVBQUUsUUFBUTtRQUNsQixhQUFhLEVBQUUsS0FBSztRQUNwQixTQUFTLEVBQUUsU0FBUztRQUNwQixTQUFTLEVBQUUsS0FBSztRQUNoQixPQUFPLEVBQUUsU0FBUztLQUNuQixDQUFDO0lBRUssU0FBUyxHQUFHLEtBQUssQ0FBQztJQUNsQixVQUFVLEdBQUcsS0FBSyxDQUFDO0lBQ25CLFFBQVEsR0FBRyxLQUFLLENBQUM7SUFFakIsRUFBRSxHQUFHLElBQUksRUFBRSxDQUFDO0lBQ1osYUFBYSxHQUFHLEtBQUssQ0FBQztJQUN0QixrQkFBa0IsR0FBRyxFQUFFLENBQUM7SUFFL0IsWUFDVSxlQUFnQyxFQUNoQyxHQUFzQixFQUN0QixVQUFzQixFQUN0QixRQUFtQixFQUNuQixlQUFnQztRQUpoQyxvQkFBZSxHQUFmLGVBQWUsQ0FBaUI7UUFDaEMsUUFBRyxHQUFILEdBQUcsQ0FBbUI7UUFDdEIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtRQUN0QixhQUFRLEdBQVIsUUFBUSxDQUFXO1FBQ25CLG9CQUFlLEdBQWYsZUFBZSxDQUFpQjtRQUV4QyxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN0QyxDQUFDO0lBRU0sYUFBYSxDQUFDLElBQVk7UUFDL0IsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsSUFBSSxJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDbkUsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3ZELElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDO1lBQ25ELEtBQUssQ0FBQztnQkFDSixPQUFPLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhO2dCQUN0QyxVQUFVLEVBQUU7b0JBQ1Y7d0JBQ0UsS0FBSyxFQUFFLEdBQUc7cUJBQ1g7b0JBQ0Q7d0JBQ0UsS0FBSyxFQUFFLENBQUMsR0FBRztxQkFDWjtpQkFDRjtnQkFDRCxJQUFJLEVBQUUsQ0FBQztnQkFDUCxTQUFTLEVBQUUsV0FBVztnQkFDdEIsUUFBUSxFQUFFLEVBQUU7Z0JBQ1osS0FBSyxFQUFFLENBQUM7YUFDVCxDQUFDLENBQUM7UUFDTCxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ3BCLENBQUM7UUFDRCxxREFBcUQ7UUFDckQsSUFBSSxPQUFPLElBQUksQ0FBQyxLQUFLLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDbkMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQztRQUMxRCxDQUFDO1FBQ0QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDL0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2xDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUN2QixDQUFDO0lBRU8sWUFBWTtRQUNsQixNQUFNLE9BQU8sR0FBRyxJQUFJLE1BQU0sQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztRQUNuRCxNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUN2RSxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLEtBQUs7WUFDMUMsQ0FBQyxDQUFDLEtBQUs7WUFDUCxDQUFDLENBQUMsT0FBTyxLQUFLLEtBQUssQ0FBQyxPQUFPLENBQUM7SUFDaEMsQ0FBQztJQUVNLGVBQWU7UUFDcEIsTUFBTSxRQUFRLEdBQUcsV0FBVyxDQUFDLEdBQUcsRUFBRTtZQUNoQyxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDekMsSUFBSSxZQUFZLEVBQUUsQ0FBQztnQkFDakIsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUM7Z0JBQ3RCLElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUM7Z0JBQ3pCLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUMxQixDQUFDO1FBQ0gsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1FBQ1IsVUFBVSxDQUFDLEdBQUcsRUFBRTtZQUNkLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMxQixDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFDVCxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDckIsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztRQUN2RSxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDL0IsSUFBSSxDQUFDLFlBQVksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztRQUN6RSxDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksS0FBSyxVQUFVLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQzlELElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxHQUFHO2dCQUNyQixJQUFJLEVBQUUsaUNBQWlDO2dCQUN2QyxPQUFPLEVBQUU7b0JBQ1AsV0FBVyxFQUFFLGFBQWE7b0JBQzFCLElBQUksRUFBRSxNQUFNO2lCQUNiO2dCQUNELE9BQU8sRUFBRSxHQUFHLEVBQUU7b0JBQ1osSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksS0FBSyxVQUFVLEVBQUUsQ0FBQzt3QkFDckMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFDO3dCQUMzQixJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7NEJBQ3pCLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxnQ0FBZ0MsQ0FBQzt3QkFDL0QsQ0FBQztvQkFDSCxDQUFDO3lCQUFNLENBQUM7d0JBQ04sSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEdBQUcsVUFBVSxDQUFDO3dCQUMvQixJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7NEJBQ3pCLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLElBQUksR0FBRyxpQ0FBaUMsQ0FBQzt3QkFDaEUsQ0FBQztvQkFDSCxDQUFDO2dCQUNILENBQUM7YUFDRixDQUFDO1lBQ0YsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUMzQixDQUFDO1FBRUQsa0ZBQWtGO1FBQ2xGLHlFQUF5RTtRQUN6RSxVQUFVLENBQUMsR0FBRyxFQUFFO1lBQ2QsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7WUFDMUIsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3ZCLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNWLENBQUM7SUFFTSxRQUFRLENBQUMsS0FBYztRQUM1QixJQUFJLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQztRQUN2QixJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUNuQixJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3ZCLENBQUM7UUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ3JCLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUN4QixDQUFDO1FBQ0QsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFFTSxhQUFhO1FBQ2xCLElBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztRQUMvQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFTSxRQUFRLENBQUMsS0FBYztRQUM1QixpQ0FBaUM7UUFDakMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRU0sY0FBYztRQUNuQixJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLE9BQU8sRUFBRSxDQUFDO1lBQ2xDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ2pDLENBQUM7SUFDSCxDQUFDO0lBRU0sVUFBVSxDQUFDLEtBQVU7UUFDMUIsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7UUFDbkIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDL0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRU0sZ0JBQWdCLENBQUMsRUFBd0I7UUFDOUMsSUFBSSxDQUFDLGFBQWEsR0FBRyxFQUFFLENBQUM7SUFDMUIsQ0FBQztJQUVNLGlCQUFpQixDQUFDLEVBQWM7UUFDckMsSUFBSSxDQUFDLGNBQWMsR0FBRyxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVNLGdCQUFnQixDQUFDLFVBQW1CO1FBQ3pDLElBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO1FBQzdCLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUN4QixJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFDN0IsVUFBVSxFQUNWLEdBQUcsVUFBVSxFQUFFLENBQ2hCLENBQUM7UUFDRixJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFFTSxRQUFRLENBQUMsT0FBd0I7UUFDdEMsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQzNCLElBQUksT0FBTyxDQUFDLEtBQUssQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDbEQsT0FBTztvQkFDTCxTQUFTLEVBQUU7d0JBQ1QsY0FBYyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUzt3QkFDdEMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxLQUFLLENBQUMsTUFBTTtxQkFDbkM7aUJBQ0YsQ0FBQztZQUNKLENBQUM7UUFDSCxDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDO0lBRU0sV0FBVyxDQUFDLE9BQXNCO1FBQ3ZDLElBQUksT0FBTyxJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUM7WUFDeEMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ3ZCLENBQUM7SUFDSCxDQUFDO0lBRU0sV0FBVztRQUNoQixJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN4QyxDQUFDO3VHQS9QVSxpQkFBaUI7MkZBQWpCLGlCQUFpQixtTEFiakI7WUFDVDtnQkFDRSxPQUFPLEVBQUUsaUJBQWlCO2dCQUMxQixLQUFLLEVBQUUsSUFBSTtnQkFDWCxXQUFXLEVBQUUsaUJBQWlCO2FBQy9CO1lBQ0Q7Z0JBQ0UsT0FBTyxFQUFFLGFBQWE7Z0JBQ3RCLEtBQUssRUFBRSxJQUFJO2dCQUNYLFdBQVcsRUFBRSxpQkFBaUI7YUFDL0I7U0FDRix5V0N0RkgsMDdDQWtEQSxvc0pEa0JJLGdCQUFnQixpRkFDaEIsV0FBVywrbUJBQ1gsT0FBTywrRUFDUCxTQUFTLHlDQUNULGNBQWM7OzJGQWdCTCxpQkFBaUI7a0JBMUI3QixTQUFTOytCQUNFLFdBQVcsY0FHVCxJQUFJLFdBQ1A7d0JBQ1AsZ0JBQWdCO3dCQUNoQixXQUFXO3dCQUNYLE9BQU87d0JBQ1AsU0FBUzt3QkFDVCxjQUFjO3FCQUNqQixtQkFDa0IsdUJBQXVCLENBQUMsTUFBTSxhQUNwQzt3QkFDVDs0QkFDRSxPQUFPLEVBQUUsaUJBQWlCOzRCQUMxQixLQUFLLEVBQUUsSUFBSTs0QkFDWCxXQUFXLG1CQUFtQjt5QkFDL0I7d0JBQ0Q7NEJBQ0UsT0FBTyxFQUFFLGFBQWE7NEJBQ3RCLEtBQUssRUFBRSxJQUFJOzRCQUNYLFdBQVcsbUJBQW1CO3lCQUMvQjtxQkFDRjttTUFXRCxZQUFZO3NCQURYLFNBQVM7dUJBQUMsY0FBYztnQkFJekIsWUFBWTtzQkFEWCxTQUFTO3VCQUFDLGNBQWM7Z0JBSXpCLG1CQUFtQjtzQkFEbEIsU0FBUzt1QkFBQyxxQkFBcUI7Z0JBT2hDLEtBQUs7c0JBREosS0FBSztnQkFNTyxPQUFPO3NCQUFuQixLQUFLO2dCQWFJLFdBQVc7c0JBQXBCLE1BQU07Z0JBS1UsY0FBYztzQkFBOUIsTUFBTSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XG4gIEFmdGVyVmlld0luaXQsXG4gIENoYW5nZURldGVjdGlvblN0cmF0ZWd5LFxuICBDaGFuZ2VEZXRlY3RvclJlZixcbiAgQ29tcG9uZW50LFxuICBFbGVtZW50UmVmLFxuICBFdmVudEVtaXR0ZXIsXG4gIEluamVjdCxcbiAgSW5wdXQsXG4gIE9uQ2hhbmdlcyxcbiAgT25EZXN0cm95LFxuICBPdXRwdXQsXG4gIFJlbmRlcmVyMixcbiAgU2ltcGxlQ2hhbmdlcyxcbiAgVmlld0NoaWxkLFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE91aUlucHV0U2VydmljZSB9IGZyb20gJy4vaW5wdXQuc2VydmljZSc7XG5pbXBvcnQge1xuICBBYnN0cmFjdENvbnRyb2wsXG4gIENvbnRyb2xWYWx1ZUFjY2Vzc29yLFxuICBGb3Jtc01vZHVsZSxcbiAgTkdfVkFMSURBVE9SUyxcbiAgTkdfVkFMVUVfQUNDRVNTT1IsXG4gIFZhbGlkYXRpb25FcnJvcnMsXG4gIFZhbGlkYXRvcixcbn0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgRE9DVU1FTlQsIE5nQ2xhc3MgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuaW1wb3J0IHsgSU91aUljb25PcHRpb25zLCBPdWlJY29uQ29tcG9uZW50IH0gZnJvbSAnb3JiaXRhbC11aS9pY29uJztcbmltcG9ydCB7IEdVSUQgfSBmcm9tICdvcmJpdGFsLXVpL2hlbHBlcnMnO1xuaW1wb3J0IGFuaW1lIGZyb20gJ2FuaW1lanMnO1xuaW1wb3J0IHsgSXNOaWxQaXBlIH0gZnJvbSAnb3JiaXRhbC11aS9waXBlcyc7XG5pbXBvcnQgeyBJbnB1dENsYXNzUGlwZSB9IGZyb20gJy4vaW5wdXQtY2xhc3MucGlwZSc7XG5pbXBvcnQgeyBtZXJnZSB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBBdXRvZmlsbE1vbml0b3IgfSBmcm9tICdAYW5ndWxhci9jZGsvdGV4dC1maWVsZCc7XG5leHBvcnQgdHlwZSBJT3VpSW5wdXRWYXJpYW50ID0gJ3N0YW5kYXJkJyB8ICd1bmRlcmxpbmVkJztcblxuZXhwb3J0IHR5cGUgSU91aUlucHV0T3B0aW9ucyA9IFBhcnRpYWw8SU91aUlucHV0Q29tYmluZWRPcHRpb25zPjtcblxuZXhwb3J0IGludGVyZmFjZSBJT3VpSW5wdXRDb21iaW5lZE9wdGlvbnMge1xuICBsYWJlbDogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICBwbGFjZWhvbGRlcjogc3RyaW5nIHwgdW5kZWZpbmVkO1xuICB2YXJpYW50OiBJT3VpSW5wdXRWYXJpYW50O1xuICBtYXhMZW5ndGg6IG51bWJlciB8IHVuZGVmaW5lZDtcbiAgdHlwZTogJ3RleHQnIHwgJ251bWJlcicgfCAncGFzc3dvcmQnO1xuICBmb250U2l6ZTogc3RyaW5nO1xuICBzaXplVG9Db250ZW50OiBib29sZWFuO1xuICBub1BhZGRpbmc6IGJvb2xlYW47XG4gIGVuZEljb246XG4gICAgfCB7XG4gICAgICAgIGljb246IHN0cmluZztcbiAgICAgICAgb3B0aW9uczogSU91aUljb25PcHRpb25zO1xuICAgICAgICBvbkNsaWNrPzogKCkgPT4gdm9pZDtcbiAgICAgIH1cbiAgICB8IHVuZGVmaW5lZDtcbn1cblxuLyoqXG4gKiBDb21wb25lbnQgdG8gYWRkIGlucHV0LWZpZWxkcy5cbiAqXG4gKiAgIEV4YW1wbGUgdXNlOlxuICogICA8b3VpLWlucHV0IHZhcmlhbnQ9XCJ1bmRlcmxpbmVkXCIgWyhtb2RlbCldPVwibXlJbnB1dFZhbHVlXCIgcGxhY2Vob2xkZXI9XCJQbGVhc2Ugd3JpdGUgeW91ciBpbnB1dC4uLlwiPjwvb3VpLWlucHV0PlxuICovXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdvdWktaW5wdXQnLFxuICB0ZW1wbGF0ZVVybDogJy4vaW5wdXQuY29tcG9uZW50Lmh0bWwnLFxuICBzdHlsZVVybHM6IFsnLi9pbnB1dC5jb21wb25lbnQuc2NzcyddLFxuICBzdGFuZGFsb25lOiB0cnVlLFxuICBpbXBvcnRzOiBbXG4gICAgT3VpSWNvbkNvbXBvbmVudCxcbiAgICBGb3Jtc01vZHVsZSxcbiAgICBOZ0NsYXNzLFxuICAgIElzTmlsUGlwZSxcbiAgICBJbnB1dENsYXNzUGlwZVxuXSxcbiAgY2hhbmdlRGV0ZWN0aW9uOiBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneS5PblB1c2gsXG4gIHByb3ZpZGVyczogW1xuICAgIHtcbiAgICAgIHByb3ZpZGU6IE5HX1ZBTFVFX0FDQ0VTU09SLFxuICAgICAgbXVsdGk6IHRydWUsXG4gICAgICB1c2VFeGlzdGluZzogT3VpSW5wdXRDb21wb25lbnQsXG4gICAgfSxcbiAgICB7XG4gICAgICBwcm92aWRlOiBOR19WQUxJREFUT1JTLFxuICAgICAgbXVsdGk6IHRydWUsXG4gICAgICB1c2VFeGlzdGluZzogT3VpSW5wdXRDb21wb25lbnQsXG4gICAgfSxcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgT3VpSW5wdXRDb21wb25lbnRcbiAgaW1wbGVtZW50c1xuICAgIEFmdGVyVmlld0luaXQsXG4gICAgT25DaGFuZ2VzLFxuICAgIENvbnRyb2xWYWx1ZUFjY2Vzc29yLFxuICAgIFZhbGlkYXRvcixcbiAgICBPbkRlc3Ryb3lcbntcbiAgQFZpZXdDaGlsZCgnaW5wdXRFbGVtZW50JylcbiAgaW5wdXRFbGVtZW50OiBFbGVtZW50UmVmO1xuXG4gIEBWaWV3Q2hpbGQoJ2F1dG9zaXplU3BhbicpXG4gIGF1dG9zaXplU3BhbjogRWxlbWVudFJlZjtcblxuICBAVmlld0NoaWxkKCdpbnB1dFdyYXBwZXJFbGVtZW50JylcbiAgaW5wdXRXcmFwcGVyRWxlbWVudDogRWxlbWVudFJlZjtcblxuICAvKipcbiAgICogICBUaGUgbW9kZWwgdGhhdCdzIGJvdW5kIHRvIHRoZSBpbnB1dCBmaWVsZFxuICAgKi9cbiAgQElucHV0KClcbiAgbW9kZWw6IGFueTtcblxuICAvKipcbiAgICogT3B0aW9ucyBvZiB0aGUgaW5wdXQtZmllbGQuIFNlZSBJT3VpSW5wdXRPcHRpb25zIGZvciBtb3JlIGluZm9ybWF0aW9uXG4gICAqL1xuICBASW5wdXQoKSBzZXQgb3B0aW9ucyhvcHRpb25zOiBJT3VpSW5wdXRPcHRpb25zKSB7XG4gICAgdGhpcy4jY29tYmluZWRPcHRpb25zID0gbWVyZ2Uoe1xuICAgICAgLi4udGhpcy4jZGVmYXVsdE9wdGlvbnMsXG4gICAgICAuLi5vcHRpb25zLFxuICAgIH0pO1xuICB9XG4gIGdldCBvcHRpb25zKCk6IElPdWlJbnB1dENvbWJpbmVkT3B0aW9ucyB7XG4gICAgcmV0dXJuIHRoaXMuI2NvbWJpbmVkT3B0aW9ucztcbiAgfVxuXG4gIC8qKlxuICAgKiAgIFRoZSBldmVudCBlbWl0dGVkIHdoZW4gaW5wdXQgZmllbGQgY2hhbmdlcy5cbiAgICovXG4gIEBPdXRwdXQoKSBtb2RlbENoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8YW55PigpO1xuXG4gIC8qKlxuICAgKiAgIFRoZSBldmVudCBlbWl0dGVkIHdoZW4gdGhlIGhhc0Vycm9yLWZpZWxkIGNoYW5nZXNcbiAgICovXG4gIEBPdXRwdXQoKSBwdWJsaWMgaGFzRXJyb3JDaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyPGJvb2xlYW4+KCk7XG5cbiAgI2Zvcm1PbkNoYW5nZTogKHZhbHVlOiBhbnkpID0+IHZvaWQgPSAoKSA9PiB7fTtcbiAgI2Zvcm1PblRvdWNoZWQ6ICgpID0+IHZvaWQgPSAoKSA9PiB7fTtcblxuICAjaXNUb3VjaGVkID0gZmFsc2U7XG4gICNkZWZhdWx0T3B0aW9uczogSU91aUlucHV0Q29tYmluZWRPcHRpb25zID0ge1xuICAgIHR5cGU6ICd0ZXh0JyxcbiAgICBwbGFjZWhvbGRlcjogJycsXG4gICAgbGFiZWw6ICcnLFxuICAgIHZhcmlhbnQ6ICdzdGFuZGFyZCcsXG4gICAgZm9udFNpemU6ICcxLjVyZW0nLFxuICAgIHNpemVUb0NvbnRlbnQ6IGZhbHNlLFxuICAgIG1heExlbmd0aDogdW5kZWZpbmVkLFxuICAgIG5vUGFkZGluZzogZmFsc2UsXG4gICAgZW5kSWNvbjogdW5kZWZpbmVkLFxuICB9O1xuICAjY29tYmluZWRPcHRpb25zOiBJT3VpSW5wdXRDb21iaW5lZE9wdGlvbnMgPSB7XG4gICAgdHlwZTogJ3RleHQnLFxuICAgIHBsYWNlaG9sZGVyOiAnJyxcbiAgICBsYWJlbDogJycsXG4gICAgdmFyaWFudDogJ3N0YW5kYXJkJyxcbiAgICBmb250U2l6ZTogJzEuNXJlbScsXG4gICAgc2l6ZVRvQ29udGVudDogZmFsc2UsXG4gICAgbWF4TGVuZ3RoOiB1bmRlZmluZWQsXG4gICAgbm9QYWRkaW5nOiBmYWxzZSxcbiAgICBlbmRJY29uOiB1bmRlZmluZWQsXG4gIH07XG5cbiAgcHVibGljIGlzRm9jdXNlZCA9IGZhbHNlO1xuICBwdWJsaWMgaXNEaXNhYmxlZCA9IGZhbHNlO1xuICBwdWJsaWMgaXNBY3RpdmUgPSBmYWxzZTtcblxuICBwdWJsaWMgaWQgPSBHVUlEKCk7XG4gIHB1YmxpYyBpc0luaXRpYWxpemVkID0gZmFsc2U7XG4gIHB1YmxpYyBzaXplVG9Db250ZW50TW9kZWwgPSAnJztcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIG91aUlucHV0U2VydmljZTogT3VpSW5wdXRTZXJ2aWNlLFxuICAgIHByaXZhdGUgY2RyOiBDaGFuZ2VEZXRlY3RvclJlZixcbiAgICBwcml2YXRlIGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsXG4gICAgcHJpdmF0ZSByZW5kZXJlcjogUmVuZGVyZXIyLFxuICAgIHByaXZhdGUgYXV0b2ZpbGxNb25pdG9yOiBBdXRvZmlsbE1vbml0b3JcbiAgKSB7XG4gICAgdGhpcy5vdWlJbnB1dFNlcnZpY2UucmVnaXN0ZXIodGhpcyk7XG4gIH1cblxuICBwdWJsaWMgb25Nb2RlbENoYW5nZShkYXRhOiBzdHJpbmcpIHtcbiAgICBpZiAodGhpcy5vcHRpb25zLm1heExlbmd0aCAmJiBkYXRhLmxlbmd0aCA+IHRoaXMub3B0aW9ucy5tYXhMZW5ndGgpIHtcbiAgICAgIHRoaXMubW9kZWwgPSBkYXRhLnN1YnN0cmluZygwLCB0aGlzLm9wdGlvbnMubWF4TGVuZ3RoKTtcbiAgICAgIHRoaXMuaW5wdXRFbGVtZW50Lm5hdGl2ZUVsZW1lbnQudmFsdWUgPSB0aGlzLm1vZGVsO1xuICAgICAgYW5pbWUoe1xuICAgICAgICB0YXJnZXRzOiB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCxcbiAgICAgICAgdHJhbnNsYXRlWDogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIHZhbHVlOiAwLjUsXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICB2YWx1ZTogLTAuNSxcbiAgICAgICAgICB9LFxuICAgICAgICBdLFxuICAgICAgICBsb29wOiA1LFxuICAgICAgICBkaXJlY3Rpb246ICdhbHRlcm5hdGUnLFxuICAgICAgICBkdXJhdGlvbjogNTAsXG4gICAgICAgIHNjYWxlOiAxLFxuICAgICAgfSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHRoaXMubW9kZWwgPSBkYXRhO1xuICAgIH1cbiAgICAvLyBIYWNrIHRvIHByZXZlbnQgYW5ndWxhciBmcm9tIHN0cmlwcGluZyB3aGl0ZXNwYWNlc1xuICAgIGlmICh0eXBlb2YgdGhpcy5tb2RlbCA9PT0gJ3N0cmluZycpIHtcbiAgICAgIHRoaXMuc2l6ZVRvQ29udGVudE1vZGVsID0gdGhpcy5tb2RlbC5yZXBsYWNlKC8gL2csICcuJyk7XG4gICAgfVxuICAgIHRoaXMuI2Zvcm1PbkNoYW5nZSh0aGlzLm1vZGVsKTtcbiAgICB0aGlzLm1vZGVsQ2hhbmdlLmVtaXQodGhpcy5tb2RlbCk7XG4gICAgdGhpcy5jaGVja0lzQWN0aXZlKCk7XG4gIH1cblxuICBwcml2YXRlIGlzQXV0b0ZpbGxlZCgpIHtcbiAgICBjb25zdCBjb250ZW50ID0gYFwiJHtTdHJpbmcuZnJvbUNoYXJDb2RlKDB4ZmVmZil9XCJgO1xuICAgIGNvbnN0IHN0eWxlID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUodGhpcy5pbnB1dEVsZW1lbnQubmF0aXZlRWxlbWVudCk7XG4gICAgcmV0dXJuIHRoaXMuaW5wdXRFbGVtZW50Lm5hdGl2ZUVsZW1lbnQudmFsdWVcbiAgICAgID8gZmFsc2VcbiAgICAgIDogY29udGVudCA9PT0gc3R5bGUuY29udGVudDtcbiAgfVxuXG4gIHB1YmxpYyBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgY29uc3QgaW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgICBjb25zdCBpc0F1dG9GaWxsZWQgPSB0aGlzLmlzQXV0b0ZpbGxlZCgpO1xuICAgICAgaWYgKGlzQXV0b0ZpbGxlZCkge1xuICAgICAgICB0aGlzLmlzRm9jdXNlZCA9IHRydWU7XG4gICAgICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcbiAgICAgICAgY2xlYXJJbnRlcnZhbChpbnRlcnZhbCk7XG4gICAgICB9XG4gICAgfSwgMjAwKTtcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIGNsZWFySW50ZXJ2YWwoaW50ZXJ2YWwpO1xuICAgIH0sIDMwMDApO1xuICAgIHRoaXMuY2hlY2tJc0FjdGl2ZSgpO1xuICAgIHRoaXMuaW5wdXRFbGVtZW50Lm5hdGl2ZUVsZW1lbnQuc3R5bGUuZm9udFNpemUgPSB0aGlzLm9wdGlvbnMuZm9udFNpemU7XG4gICAgaWYgKHRoaXMub3B0aW9ucy5zaXplVG9Db250ZW50KSB7XG4gICAgICB0aGlzLmF1dG9zaXplU3Bhbi5uYXRpdmVFbGVtZW50LnN0eWxlLmZvbnRTaXplID0gdGhpcy5vcHRpb25zLmZvbnRTaXplO1xuICAgIH1cbiAgICBpZiAodGhpcy5vcHRpb25zLnR5cGUgPT09ICdwYXNzd29yZCcgJiYgIXRoaXMub3B0aW9ucy5lbmRJY29uKSB7XG4gICAgICB0aGlzLm9wdGlvbnMuZW5kSWNvbiA9IHtcbiAgICAgICAgaWNvbjogJ2Fzc2V0cy9pY29ucy92aXNpYmlsaXR5X29mZi5zdmcnLFxuICAgICAgICBvcHRpb25zOiB7XG4gICAgICAgICAgc3Ryb2tlQ29sb3I6ICdjb2xvci1saWdodCcsXG4gICAgICAgICAgc2l6ZTogJzIwcHgnLFxuICAgICAgICB9LFxuICAgICAgICBvbkNsaWNrOiAoKSA9PiB7XG4gICAgICAgICAgaWYgKHRoaXMub3B0aW9ucy50eXBlID09PSAncGFzc3dvcmQnKSB7XG4gICAgICAgICAgICB0aGlzLm9wdGlvbnMudHlwZSA9ICd0ZXh0JztcbiAgICAgICAgICAgIGlmICh0aGlzLm9wdGlvbnMuZW5kSWNvbikge1xuICAgICAgICAgICAgICB0aGlzLm9wdGlvbnMuZW5kSWNvbi5pY29uID0gJ2Fzc2V0cy9pY29ucy92aXNpYmlsaXR5X29uLnN2Zyc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMub3B0aW9ucy50eXBlID0gJ3Bhc3N3b3JkJztcbiAgICAgICAgICAgIGlmICh0aGlzLm9wdGlvbnMuZW5kSWNvbikge1xuICAgICAgICAgICAgICB0aGlzLm9wdGlvbnMuZW5kSWNvbi5pY29uID0gJ2Fzc2V0cy9pY29ucy92aXNpYmlsaXR5X29mZi5zdmcnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgIH07XG4gICAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XG4gICAgfVxuXG4gICAgLy8gSGFjayB0byBmaXJzdGx5IG1ha2Ugc3VyZSBpbnB1dCBpcyBhY3RpdmUgaWYgYnJvd3NlciBhdXRvZmlsbHMgaXQsIGFuZCBzZWNvbmRseVxuICAgIC8vIHRvIG1ha2UgaXQgc28gdGhhdCB0aGUgaW5wdXQgZG9lc24ndCBmbGFzaCBkdWUgdG8gaW5pdGlhbCBjb250ZW50IGxvYWRcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgIHRoaXMuaXNJbml0aWFsaXplZCA9IHRydWU7XG4gICAgICB0aGlzLmNoZWNrSXNBY3RpdmUoKTtcbiAgICB9LCA0MDApO1xuICB9XG5cbiAgcHVibGljIHNldEZvY3VzKHZhbHVlOiBib29sZWFuKSB7XG4gICAgdGhpcy5pc0ZvY3VzZWQgPSB2YWx1ZTtcbiAgICBpZiAodGhpcy5pc0ZvY3VzZWQpIHtcbiAgICAgIHRoaXMuc2V0RXJyb3IoZmFsc2UpO1xuICAgIH1cbiAgICBpZiAoIXRoaXMuI2lzVG91Y2hlZCkge1xuICAgICAgdGhpcy4jaXNUb3VjaGVkID0gdHJ1ZTtcbiAgICAgIHRoaXMuI2Zvcm1PblRvdWNoZWQoKTtcbiAgICB9XG4gICAgdGhpcy5jaGVja0lzQWN0aXZlKCk7XG4gIH1cblxuICBwdWJsaWMgY2hlY2tJc0FjdGl2ZSgpIHtcbiAgICB0aGlzLmlzQWN0aXZlID0gdGhpcy5pc0ZvY3VzZWQgfHwgISF0aGlzLm1vZGVsO1xuICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcbiAgfVxuXG4gIHB1YmxpYyBzZXRFcnJvcih2YWx1ZTogYm9vbGVhbikge1xuICAgIC8vIHRoaXMub3B0aW9ucy5oYXNFcnJvciA9IHZhbHVlO1xuICAgIHRoaXMuaGFzRXJyb3JDaGFuZ2UuZW1pdCh2YWx1ZSk7XG4gICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xuICB9XG5cbiAgcHVibGljIG9uRW5kSWNvbkNsaWNrKCkge1xuICAgIGlmICh0aGlzLm9wdGlvbnMuZW5kSWNvbj8ub25DbGljaykge1xuICAgICAgdGhpcy5vcHRpb25zLmVuZEljb24ub25DbGljaygpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyB3cml0ZVZhbHVlKHZhbHVlOiBhbnkpOiB2b2lkIHtcbiAgICB0aGlzLm1vZGVsID0gdmFsdWU7XG4gICAgdGhpcy4jZm9ybU9uQ2hhbmdlKHRoaXMubW9kZWwpO1xuICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcbiAgfVxuXG4gIHB1YmxpYyByZWdpc3Rlck9uQ2hhbmdlKGZuOiAodmFsdWU6IGFueSkgPT4gdm9pZCkge1xuICAgIHRoaXMuI2Zvcm1PbkNoYW5nZSA9IGZuO1xuICB9XG5cbiAgcHVibGljIHJlZ2lzdGVyT25Ub3VjaGVkKGZuOiAoKSA9PiB2b2lkKSB7XG4gICAgdGhpcy4jZm9ybU9uVG91Y2hlZCA9IGZuO1xuICB9XG5cbiAgcHVibGljIHNldERpc2FibGVkU3RhdGUoaXNEaXNhYmxlZDogYm9vbGVhbikge1xuICAgIHRoaXMuaXNEaXNhYmxlZCA9IGlzRGlzYWJsZWQ7XG4gICAgdGhpcy5yZW5kZXJlci5zZXRBdHRyaWJ1dGUoXG4gICAgICB0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCxcbiAgICAgICdkaXNhYmxlZCcsXG4gICAgICBgJHtpc0Rpc2FibGVkfWBcbiAgICApO1xuICAgIHRoaXMuY2RyLmRldGVjdENoYW5nZXMoKTtcbiAgfVxuXG4gIHB1YmxpYyB2YWxpZGF0ZShjb250cm9sOiBBYnN0cmFjdENvbnRyb2wpOiBWYWxpZGF0aW9uRXJyb3JzIHwgbnVsbCB7XG4gICAgaWYgKHRoaXMub3B0aW9ucy5tYXhMZW5ndGgpIHtcbiAgICAgIGlmIChjb250cm9sLnZhbHVlLmxlbmd0aCA+IHRoaXMub3B0aW9ucy5tYXhMZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBtYXhMZW5ndGg6IHtcbiAgICAgICAgICAgIHJlcXVpcmVkTGVuZ3RoOiB0aGlzLm9wdGlvbnMubWF4TGVuZ3RoLFxuICAgICAgICAgICAgYWN0dWFsTGVuZ3RoOiBjb250cm9sLnZhbHVlLmxlbmd0aCxcbiAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHB1YmxpYyBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKSB7XG4gICAgaWYgKCdtb2RlbCcgaW4gY2hhbmdlcykge1xuICAgICAgdGhpcy5tb2RlbCA9IGNoYW5nZXMubW9kZWwuY3VycmVudFZhbHVlO1xuICAgICAgdGhpcy5jaGVja0lzQWN0aXZlKCk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIG5nT25EZXN0cm95KCkge1xuICAgIHRoaXMub3VpSW5wdXRTZXJ2aWNlLmRlcmVnaXN0ZXIodGhpcyk7XG4gIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJ7eyBtb2RlbCB8IGlucHV0Q2xhc3M6IG9wdGlvbnMudmFyaWFudDppc0luaXRpYWxpemVkOmlzRm9jdXNlZCB9fVwiIChjbGljayk9XCJzZXRGb2N1cyh0cnVlKVwiICNpbnB1dFdyYXBwZXJFbGVtZW50PlxuICBAaWYgKG9wdGlvbnMubGFiZWwpIHtcbiAgICA8ZGl2IGNsYXNzPVwib3VpLWlucHV0LWxhYmVsXCI+XG4gICAgICB7eyBvcHRpb25zLmxhYmVsIH19XG4gICAgPC9kaXY+XG4gIH1cbiAgQGlmIChvcHRpb25zLm1heExlbmd0aCAmJiAhKG1vZGVsIHwgaXNOaWwpKSB7XG4gICAgPGRpdiBjbGFzcz1cIm91aS1pbnB1dC1tYXgtbGVuZ3RoXCI+XG4gICAgICB7eyBtb2RlbC5sZW5ndGggfX0ve3sgb3B0aW9ucy5tYXhMZW5ndGggfX1cbiAgICA8L2Rpdj5cbiAgfVxuICA8ZGl2IGNsYXNzPVwiaW5wdXQtd3JhcHBlclwiPlxuICAgIEBpZiAob3B0aW9ucy5zaXplVG9Db250ZW50KSB7XG4gICAgICA8c3BhbiAjYXV0b3NpemVTcGFuIGNsYXNzPVwiYXV0b3NpemVcIj57e1xuICAgICAgICBzaXplVG9Db250ZW50TW9kZWxcbiAgICAgIH19PC9zcGFuPlxuICAgIH1cbiAgICA8aW5wdXRcbiAgICAgIFtuZ0NsYXNzXT1cIntcbiAgICAgICAgYXV0b3NpemU6IG9wdGlvbnMuc2l6ZVRvQ29udGVudCxcbiAgICAgICAgJ25vLXBhZGRpbmcnOiBvcHRpb25zLm5vUGFkZGluZ1xuICAgICAgfVwiXG4gICAgICBjbGFzcz1cImlucHV0XCJcbiAgICAgIFtwbGFjZWhvbGRlcl09XCJvcHRpb25zLnBsYWNlaG9sZGVyID8/ICcnXCJcbiAgICAgIChmb2N1cyk9XCJzZXRGb2N1cyh0cnVlKVwiXG4gICAgICAoYmx1cik9XCJzZXRGb2N1cyhmYWxzZSlcIlxuICAgICAgI2lucHV0RWxlbWVudFxuICAgICAgW3R5cGVdPVwib3B0aW9ucy50eXBlXCJcbiAgICAgIFtuZ01vZGVsXT1cIm1vZGVsXCJcbiAgICAgIChuZ01vZGVsQ2hhbmdlKT1cIm9uTW9kZWxDaGFuZ2UoJGV2ZW50KVwiXG4gICAgICAvPlxuICAgIEBpZiAob3B0aW9ucy5lbmRJY29uKSB7XG4gICAgICA8b3VpLWljb25cbiAgICAgICAgY2xhc3M9XCJlbmQtaWNvblwiXG4gICAgICAgIFtuZ0NsYXNzXT1cInsgJ2hhcy1jbGljayc6IG9wdGlvbnMuZW5kSWNvbi5vbkNsaWNrIH1cIlxuICAgICAgICAoY2xpY2spPVwib25FbmRJY29uQ2xpY2soKVwiXG4gICAgICAgIFtpY29uXT1cIm9wdGlvbnMuZW5kSWNvbi5pY29uXCJcbiAgICAgICAgW29wdGlvbnNdPVwib3B0aW9ucy5lbmRJY29uLm9wdGlvbnNcIlxuICAgICAgPjwvb3VpLWljb24+XG4gICAgfVxuICA8L2Rpdj5cblxuICBAaWYgKG9wdGlvbnMudmFyaWFudCA9PT0gJ3VuZGVybGluZWQnKSB7XG4gICAgPGRpdlxuICAgICAgY2xhc3M9XCJvdWktaW5wdXQtdW5kZXJsaW5lLXdyYXBwZXJcIlxuICAgICAgPlxuICAgICAgPGRpdiBjbGFzcz1cIm91aS1pbnB1dC11bmRlcmxpbmUtY29udGVudFwiPjwvZGl2PlxuICAgIDwvZGl2PlxuICB9XG48L2Rpdj5cbiJdfQ==