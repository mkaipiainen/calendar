import { ChangeDetectionStrategy, Component, computed, EventEmitter, Input, Output, signal, ViewChild, } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { OuiIconComponent } from 'orbital-ui/icon';
import { merge } from 'lodash-es';
import * as i0 from "@angular/core";
import * as i1 from "@angular/forms";
/**
 * Component to add input-fields.
 *
 *   Example use:
 *   <oui-textarea [(model)]="model"></oui-input>
 */
export class OuiTextareaComponent {
    cdr;
    renderer;
    elementRef;
    textarea;
    autosizeWrapper;
    /**
     *   The model that's bound to the input field
     */
    model;
    /**
     * Options of the input-field. See IOuiInputOptions for more information
     */
    set options(newOptions) {
        this.optionsSignal.set(merge({ ...this.defaultOptions }, { ...newOptions }));
        if (this.resizeListener) {
            this.resizeListener();
            this.resizeListener = undefined;
        }
        if (newOptions.autoSizeOptions?.isEnabled) {
            this.initResizeListener();
        }
    }
    get options() {
        return this.optionsSignal();
    }
    /**
     *   The event emitted when input field changes.
     */
    modelChange = new EventEmitter();
    /**
     *   The event emitted when the hasError-field changes
     */
    hasErrorChange = new EventEmitter();
    defaultOptions = {
        placeholder: '',
        label: '',
        disabled: false,
        disableResize: false,
        hasError: false,
        autoSizeOptions: {
            isEnabled: false,
            maxHeight: undefined,
            minHeight: undefined,
        },
    };
    resizeListener;
    isFocused = signal(false);
    isInitialized = signal(false);
    optionsSignal = signal(this.defaultOptions);
    className = computed(() => {
        return `oui-textarea ${this.optionsSignal().hasError ? 'has-error' : ''} ${this.isInitialized() ? 'initialized' : ''} ${this.optionsSignal().disableResize ? 'disable-resize' : ''}`;
    });
    constructor(cdr, renderer, elementRef) {
        this.cdr = cdr;
        this.renderer = renderer;
        this.elementRef = elementRef;
    }
    onModelChange() {
        this.modelChange.emit(this.model);
    }
    updateHeight() {
        if (this.options.autoSizeOptions?.isEnabled && this.textarea) {
            this.textarea.nativeElement.style.height = '1px';
            this.textarea.nativeElement.style.height =
                25 + this.textarea.nativeElement.scrollHeight + 'px';
        }
    }
    initResizeListener() {
        if (this.textarea?.nativeElement) {
            this.textarea.nativeElement.setAttribute('style', 'height:' +
                this.textarea.nativeElement.scrollHeight +
                'px;overflow-y:hidden;');
            this.resizeListener = this.renderer.listen(this.textarea.nativeElement, 'input', this.onInput.bind(this));
        }
    }
    onInput() {
        this.textarea.nativeElement.style.height = 0;
        this.textarea.nativeElement.style.height =
            this.textarea.nativeElement.scrollHeight + 'px';
    }
    ngAfterViewInit() {
        this.isFocused.set(!!this.model);
        if (this.isFocused()) {
            this.renderer.addClass(this.elementRef.nativeElement, 'focused');
        }
        this.cdr.detectChanges();
        if (this.options.autoSizeOptions?.isEnabled && this.autosizeWrapper) {
            this.initResizeListener();
            if (this.options.autoSizeOptions.maxHeight) {
                this.autosizeWrapper.nativeElement.style.maxHeight =
                    this.options.autoSizeOptions.maxHeight;
            }
            if (this.options.autoSizeOptions.minHeight) {
                this.autosizeWrapper.nativeElement.style.minHeight =
                    this.options.autoSizeOptions.minHeight;
            }
        }
        setTimeout(() => {
            this.updateHeight();
            this.isInitialized.set(true);
        }, 400);
    }
    setFocus(value) {
        if (!this.model && !value) {
            this.isFocused.set(false);
            this.modelChange.emit(this.model);
            this.renderer.removeClass(this.elementRef.nativeElement, 'focused');
        }
        else if (value) {
            this.isFocused.set(true);
            this.setError(false);
            this.renderer.addClass(this.elementRef.nativeElement, 'focused');
        }
        this.cdr.detectChanges();
    }
    setError(value) {
        this.options.hasError = value;
        this.hasErrorChange.emit(value);
        this.cdr.detectChanges();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTextareaComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i0.Renderer2 }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "17.3.1", type: OuiTextareaComponent, isStandalone: true, selector: "oui-textarea", inputs: { model: "model", options: "options" }, outputs: { modelChange: "modelChange", hasErrorChange: "hasErrorChange" }, viewQueries: [{ propertyName: "textarea", first: true, predicate: ["textarea"], descendants: true }, { propertyName: "autosizeWrapper", first: true, predicate: ["autosizeWrapper"], descendants: true }], ngImport: i0, template: "<div class=\"{{ className() }}\" (click)=\"setFocus(true)\">\n  @if (optionsSignal().label) {\n    <div class=\"oui-textarea-label\">\n      {{ optionsSignal().label }}\n    </div>\n  }\n  <div class=\"textarea-wrapper\">\n    @if (!optionsSignal().autoSizeOptions?.isEnabled) {\n      <textarea\n        class=\"textarea\"\n        [placeholder]=\"optionsSignal().placeholder ?? ''\"\n        (focus)=\"setFocus(true)\"\n        (blur)=\"setFocus(false)\"\n        #textarea\n        [disabled]=\"optionsSignal().disabled ?? false\"\n        [(ngModel)]=\"model\"\n        (input)=\"onModelChange()\"\n      ></textarea>\n    }\n    @if (optionsSignal().autoSizeOptions?.isEnabled) {\n      <div\n        #autosizeWrapper class=\"grow-wrap oui-scrollbar oui-scrollbar-auto\">\n        <textarea\n          class=\"textarea\"\n          [placeholder]=\"optionsSignal().placeholder ?? ''\"\n          (focus)=\"setFocus(true)\"\n          (blur)=\"setFocus(false)\"\n          #textarea\n          [disabled]=\"optionsSignal().disabled ?? false\"\n          [(ngModel)]=\"model\"\n          (input)=\"onModelChange()\"\n        ></textarea>\n      </div>\n    }\n  </div>\n</div>\n", styles: [":host{flex:1;display:block;border-radius:var(--border-radius-default);border-color:var(--oui-textarea-border-color);border-width:var(--oui-textarea-border-width);border-style:var(--oui-textarea-border-style);overflow:hidden}:host.focused{border-color:var(--oui-textarea-border-active-color)}:host.focused .oui-textarea .oui-textarea-label{top:-1.5rem;left:0rem;font-size:9px;color:var(--oui-textarea-text-color-focused)}:host .oui-textarea{position:relative;display:flex;height:100%;transition:none;background-color:var(--oui-textarea-background-color)}:host .oui-textarea.disable-resize textarea{resize:none}:host .oui-textarea .grow-wrap{display:grid;width:100%}:host .oui-textarea .grow-wrap:after{content:attr(data-replicated-value) \" \";white-space:pre-wrap;visibility:hidden}:host .oui-textarea .grow-wrap>textarea{resize:none;overflow:hidden}:host .oui-textarea .grow-wrap>textarea,:host .oui-textarea .grow-wrap:after{padding:.5rem;font:inherit;grid-area:1/1/2/2}:host .oui-textarea .textarea{width:100%;max-width:100%;background-color:transparent}:host .oui-textarea .textarea-wrapper .end-icon{margin-right:1rem}:host .oui-textarea *{transition:none}:host .oui-textarea.initialized{transition:background-color .3s}:host .oui-textarea.initialized *{transition:background-color .3s}:host .oui-textarea .oui-textarea-label{position:absolute;top:0;left:.5rem;color:var(--oui-textarea-text-color);transition:top .2s,left .2s,color .3s,font-size .2s;font-size:11px;pointer-events:none;font-family:var(--font-primary);z-index:1}:host .oui-textarea .textarea-wrapper{display:flex;align-items:center;position:relative;flex:1;overflow:hidden}:host .oui-textarea .textarea-wrapper .grow-wrap textarea{padding:0}:host .oui-textarea .textarea-wrapper textarea{outline:none;border:none;flex:1;height:100%;font-family:var(--font-primary);font-size:13px;padding:1rem;color:var(--oui-textarea-text-color)}:host .oui-textarea .textarea-wrapper textarea.no-padding{padding:0}:host .oui-textarea .textarea-wrapper textarea.autosize{position:absolute;width:100%}:host .oui-textarea.has-error{outline:1px solid var(--color-danger)}:host .oui-textarea.has-error .oui-textarea-label{color:var(--color-danger)}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTextareaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-textarea', standalone: true, imports: [FormsModule, OuiIconComponent], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"{{ className() }}\" (click)=\"setFocus(true)\">\n  @if (optionsSignal().label) {\n    <div class=\"oui-textarea-label\">\n      {{ optionsSignal().label }}\n    </div>\n  }\n  <div class=\"textarea-wrapper\">\n    @if (!optionsSignal().autoSizeOptions?.isEnabled) {\n      <textarea\n        class=\"textarea\"\n        [placeholder]=\"optionsSignal().placeholder ?? ''\"\n        (focus)=\"setFocus(true)\"\n        (blur)=\"setFocus(false)\"\n        #textarea\n        [disabled]=\"optionsSignal().disabled ?? false\"\n        [(ngModel)]=\"model\"\n        (input)=\"onModelChange()\"\n      ></textarea>\n    }\n    @if (optionsSignal().autoSizeOptions?.isEnabled) {\n      <div\n        #autosizeWrapper class=\"grow-wrap oui-scrollbar oui-scrollbar-auto\">\n        <textarea\n          class=\"textarea\"\n          [placeholder]=\"optionsSignal().placeholder ?? ''\"\n          (focus)=\"setFocus(true)\"\n          (blur)=\"setFocus(false)\"\n          #textarea\n          [disabled]=\"optionsSignal().disabled ?? false\"\n          [(ngModel)]=\"model\"\n          (input)=\"onModelChange()\"\n        ></textarea>\n      </div>\n    }\n  </div>\n</div>\n", styles: [":host{flex:1;display:block;border-radius:var(--border-radius-default);border-color:var(--oui-textarea-border-color);border-width:var(--oui-textarea-border-width);border-style:var(--oui-textarea-border-style);overflow:hidden}:host.focused{border-color:var(--oui-textarea-border-active-color)}:host.focused .oui-textarea .oui-textarea-label{top:-1.5rem;left:0rem;font-size:9px;color:var(--oui-textarea-text-color-focused)}:host .oui-textarea{position:relative;display:flex;height:100%;transition:none;background-color:var(--oui-textarea-background-color)}:host .oui-textarea.disable-resize textarea{resize:none}:host .oui-textarea .grow-wrap{display:grid;width:100%}:host .oui-textarea .grow-wrap:after{content:attr(data-replicated-value) \" \";white-space:pre-wrap;visibility:hidden}:host .oui-textarea .grow-wrap>textarea{resize:none;overflow:hidden}:host .oui-textarea .grow-wrap>textarea,:host .oui-textarea .grow-wrap:after{padding:.5rem;font:inherit;grid-area:1/1/2/2}:host .oui-textarea .textarea{width:100%;max-width:100%;background-color:transparent}:host .oui-textarea .textarea-wrapper .end-icon{margin-right:1rem}:host .oui-textarea *{transition:none}:host .oui-textarea.initialized{transition:background-color .3s}:host .oui-textarea.initialized *{transition:background-color .3s}:host .oui-textarea .oui-textarea-label{position:absolute;top:0;left:.5rem;color:var(--oui-textarea-text-color);transition:top .2s,left .2s,color .3s,font-size .2s;font-size:11px;pointer-events:none;font-family:var(--font-primary);z-index:1}:host .oui-textarea .textarea-wrapper{display:flex;align-items:center;position:relative;flex:1;overflow:hidden}:host .oui-textarea .textarea-wrapper .grow-wrap textarea{padding:0}:host .oui-textarea .textarea-wrapper textarea{outline:none;border:none;flex:1;height:100%;font-family:var(--font-primary);font-size:13px;padding:1rem;color:var(--oui-textarea-text-color)}:host .oui-textarea .textarea-wrapper textarea.no-padding{padding:0}:host .oui-textarea .textarea-wrapper textarea.autosize{position:absolute;width:100%}:host .oui-textarea.has-error{outline:1px solid var(--color-danger)}:host .oui-textarea.has-error .oui-textarea-label{color:var(--color-danger)}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i0.Renderer2 }, { type: i0.ElementRef }], propDecorators: { textarea: [{
                type: ViewChild,
                args: ['textarea']
            }], autosizeWrapper: [{
                type: ViewChild,
                args: ['autosizeWrapper']
            }], model: [{
                type: Input
            }], options: [{
                type: Input
            }], modelChange: [{
                type: Output
            }], hasErrorChange: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGV4dGFyZWEuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS90ZXh0YXJlYS90ZXh0YXJlYS5jb21wb25lbnQudHMiLCIuLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3RleHRhcmVhL3RleHRhcmVhLmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFFTCx1QkFBdUIsRUFFdkIsU0FBUyxFQUNULFFBQVEsRUFFUixZQUFZLEVBQ1osS0FBSyxFQUNMLE1BQU0sRUFFTixNQUFNLEVBQ04sU0FBUyxHQUNWLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSxnQkFBZ0IsQ0FBQztBQUU3QyxPQUFPLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxpQkFBaUIsQ0FBQztBQUNuRCxPQUFPLEVBQUUsS0FBSyxFQUFFLE1BQU0sV0FBVyxDQUFDOzs7QUFnQmxDOzs7OztHQUtHO0FBU0gsTUFBTSxPQUFPLG9CQUFvQjtJQTZEckI7SUFDQTtJQUNBO0lBOURhLFFBQVEsQ0FBYTtJQUNkLGVBQWUsQ0FBYTtJQUMxRDs7T0FFRztJQUVILEtBQUssQ0FBTTtJQUVYOztPQUVHO0lBQ0gsSUFBYSxPQUFPLENBQUMsVUFBK0I7UUFDbEQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQ3BCLEtBQUssQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLGNBQWMsRUFBRSxFQUFFLEVBQUUsR0FBRyxVQUFVLEVBQUUsQ0FBQyxDQUNyRCxDQUFDO1FBQ0YsSUFBSSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUM7WUFDeEIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQ3RCLElBQUksQ0FBQyxjQUFjLEdBQUcsU0FBUyxDQUFDO1FBQ2xDLENBQUM7UUFDRCxJQUFJLFVBQVUsQ0FBQyxlQUFlLEVBQUUsU0FBUyxFQUFFLENBQUM7WUFDMUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLENBQUM7UUFDNUIsQ0FBQztJQUNILENBQUM7SUFFRCxJQUFJLE9BQU87UUFDVCxPQUFPLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBRUQ7O09BRUc7SUFDTyxXQUFXLEdBQUcsSUFBSSxZQUFZLEVBQU8sQ0FBQztJQUVoRDs7T0FFRztJQUNjLGNBQWMsR0FBRyxJQUFJLFlBQVksRUFBVyxDQUFDO0lBRXRELGNBQWMsR0FBd0I7UUFDNUMsV0FBVyxFQUFFLEVBQUU7UUFDZixLQUFLLEVBQUUsRUFBRTtRQUNULFFBQVEsRUFBRSxLQUFLO1FBQ2YsYUFBYSxFQUFFLEtBQUs7UUFDcEIsUUFBUSxFQUFFLEtBQUs7UUFDZixlQUFlLEVBQUU7WUFDZixTQUFTLEVBQUUsS0FBSztZQUNoQixTQUFTLEVBQUUsU0FBUztZQUNwQixTQUFTLEVBQUUsU0FBUztTQUNyQjtLQUNGLENBQUM7SUFDTSxjQUFjLENBQU07SUFDckIsU0FBUyxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMxQixhQUFhLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzlCLGFBQWEsR0FBRyxNQUFNLENBQXNCLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUNqRSxTQUFTLEdBQUcsUUFBUSxDQUFDLEdBQUcsRUFBRTtRQUMvQixPQUFPLGdCQUFnQixJQUFJLENBQUMsYUFBYSxFQUFFLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFDckUsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEVBQ3pDLElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDO0lBQ25FLENBQUMsQ0FBQyxDQUFDO0lBQ0gsWUFDVSxHQUFzQixFQUN0QixRQUFtQixFQUNuQixVQUFzQjtRQUZ0QixRQUFHLEdBQUgsR0FBRyxDQUFtQjtRQUN0QixhQUFRLEdBQVIsUUFBUSxDQUFXO1FBQ25CLGVBQVUsR0FBVixVQUFVLENBQVk7SUFDN0IsQ0FBQztJQUVHLGFBQWE7UUFDbEIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQ3BDLENBQUM7SUFFTyxZQUFZO1FBQ2xCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLEVBQUUsU0FBUyxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUM3RCxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQztZQUNqRCxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsTUFBTTtnQkFDdEMsRUFBRSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7UUFDekQsQ0FBQztJQUNILENBQUM7SUFFTyxrQkFBa0I7UUFDeEIsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFLGFBQWEsRUFBRSxDQUFDO1lBQ2pDLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FDdEMsT0FBTyxFQUNQLFNBQVM7Z0JBQ1AsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsWUFBWTtnQkFDeEMsdUJBQXVCLENBQzFCLENBQUM7WUFDRixJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUN4QyxJQUFJLENBQUMsUUFBUSxDQUFDLGFBQWEsRUFDM0IsT0FBTyxFQUNQLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUN4QixDQUFDO1FBQ0osQ0FBQztJQUNILENBQUM7SUFDTyxPQUFPO1FBQ2IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7UUFDN0MsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLE1BQU07WUFDdEMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQztJQUNwRCxDQUFDO0lBRU0sZUFBZTtRQUNwQixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2pDLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUM7WUFDckIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDbkUsQ0FBQztRQUNELElBQUksQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLENBQUM7UUFDekIsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsRUFBRSxTQUFTLElBQUksSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFDO1lBQ3BFLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1lBQzFCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQzNDLElBQUksQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxTQUFTO29CQUNoRCxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUM7WUFDM0MsQ0FBQztZQUNELElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxlQUFlLENBQUMsU0FBUyxFQUFFLENBQUM7Z0JBQzNDLElBQUksQ0FBQyxlQUFlLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxTQUFTO29CQUNoRCxJQUFJLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQyxTQUFTLENBQUM7WUFDM0MsQ0FBQztRQUNILENBQUM7UUFDRCxVQUFVLENBQUMsR0FBRyxFQUFFO1lBQ2QsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3BCLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQy9CLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztJQUNWLENBQUM7SUFFTSxRQUFRLENBQUMsS0FBYztRQUM1QixJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO1lBQzFCLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzFCLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLGFBQWEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN0RSxDQUFDO2FBQU0sSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUNqQixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN6QixJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3JCLElBQUksQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ25FLENBQUM7UUFDRCxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBRSxDQUFDO0lBQzNCLENBQUM7SUFDTSxRQUFRLENBQUMsS0FBYztRQUM1QixJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUM7UUFDOUIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDaEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUMzQixDQUFDO3VHQTFJVSxvQkFBb0I7MkZBQXBCLG9CQUFvQiw4WUMvQ2pDLDhwQ0FvQ0EsK3NFRFFZLFdBQVc7OzJGQUdWLG9CQUFvQjtrQkFSaEMsU0FBUzsrQkFDRSxjQUFjLGNBR1osSUFBSSxXQUNQLENBQUMsV0FBVyxFQUFFLGdCQUFnQixDQUFDLG1CQUN2Qix1QkFBdUIsQ0FBQyxNQUFNO3VJQUd4QixRQUFRO3NCQUE5QixTQUFTO3VCQUFDLFVBQVU7Z0JBQ1MsZUFBZTtzQkFBNUMsU0FBUzt1QkFBQyxpQkFBaUI7Z0JBSzVCLEtBQUs7c0JBREosS0FBSztnQkFNTyxPQUFPO3NCQUFuQixLQUFLO2dCQW9CSSxXQUFXO3NCQUFwQixNQUFNO2dCQUtVLGNBQWM7c0JBQTlCLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBDaGFuZ2VEZXRlY3Rpb25TdHJhdGVneSxcbiAgQ2hhbmdlRGV0ZWN0b3JSZWYsXG4gIENvbXBvbmVudCxcbiAgY29tcHV0ZWQsXG4gIEVsZW1lbnRSZWYsXG4gIEV2ZW50RW1pdHRlcixcbiAgSW5wdXQsXG4gIE91dHB1dCxcbiAgUmVuZGVyZXIyLFxuICBzaWduYWwsXG4gIFZpZXdDaGlsZCxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBGb3Jtc01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2Zvcm1zJztcblxuaW1wb3J0IHsgT3VpSWNvbkNvbXBvbmVudCB9IGZyb20gJ29yYml0YWwtdWkvaWNvbic7XG5pbXBvcnQgeyBtZXJnZSB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBldmVudExpc3RlbmVycyB9IGZyb20gJ0Bwb3BwZXJqcy9jb3JlJztcblxuZXhwb3J0IGludGVyZmFjZSBJT3VpVGV4dGFyZWFPcHRpb25zIHtcbiAgbGFiZWw/OiBzdHJpbmc7XG4gIHBsYWNlaG9sZGVyPzogc3RyaW5nO1xuICBkaXNhYmxlZD86IGJvb2xlYW47XG4gIGhhc0Vycm9yPzogYm9vbGVhbjtcbiAgZGlzYWJsZVJlc2l6ZT86IGJvb2xlYW47XG4gIGF1dG9TaXplT3B0aW9ucz86IHtcbiAgICBpc0VuYWJsZWQ6IGJvb2xlYW47XG4gICAgbWF4SGVpZ2h0Pzogc3RyaW5nO1xuICAgIG1pbkhlaWdodD86IHN0cmluZztcbiAgfTtcbn1cblxuLyoqXG4gKiBDb21wb25lbnQgdG8gYWRkIGlucHV0LWZpZWxkcy5cbiAqXG4gKiAgIEV4YW1wbGUgdXNlOlxuICogICA8b3VpLXRleHRhcmVhIFsobW9kZWwpXT1cIm1vZGVsXCI+PC9vdWktaW5wdXQ+XG4gKi9cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS10ZXh0YXJlYScsXG4gIHRlbXBsYXRlVXJsOiAnLi90ZXh0YXJlYS5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL3RleHRhcmVhLmNvbXBvbmVudC5zY3NzJ10sXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIGltcG9ydHM6IFtGb3Jtc01vZHVsZSwgT3VpSWNvbkNvbXBvbmVudF0sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlUZXh0YXJlYUNvbXBvbmVudCBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQge1xuICBAVmlld0NoaWxkKCd0ZXh0YXJlYScpIHRleHRhcmVhOiBFbGVtZW50UmVmO1xuICBAVmlld0NoaWxkKCdhdXRvc2l6ZVdyYXBwZXInKSBhdXRvc2l6ZVdyYXBwZXI6IEVsZW1lbnRSZWY7XG4gIC8qKlxuICAgKiAgIFRoZSBtb2RlbCB0aGF0J3MgYm91bmQgdG8gdGhlIGlucHV0IGZpZWxkXG4gICAqL1xuICBASW5wdXQoKVxuICBtb2RlbDogYW55O1xuXG4gIC8qKlxuICAgKiBPcHRpb25zIG9mIHRoZSBpbnB1dC1maWVsZC4gU2VlIElPdWlJbnB1dE9wdGlvbnMgZm9yIG1vcmUgaW5mb3JtYXRpb25cbiAgICovXG4gIEBJbnB1dCgpIHNldCBvcHRpb25zKG5ld09wdGlvbnM6IElPdWlUZXh0YXJlYU9wdGlvbnMpIHtcbiAgICB0aGlzLm9wdGlvbnNTaWduYWwuc2V0KFxuICAgICAgbWVyZ2UoeyAuLi50aGlzLmRlZmF1bHRPcHRpb25zIH0sIHsgLi4ubmV3T3B0aW9ucyB9KVxuICAgICk7XG4gICAgaWYgKHRoaXMucmVzaXplTGlzdGVuZXIpIHtcbiAgICAgIHRoaXMucmVzaXplTGlzdGVuZXIoKTtcbiAgICAgIHRoaXMucmVzaXplTGlzdGVuZXIgPSB1bmRlZmluZWQ7XG4gICAgfVxuICAgIGlmIChuZXdPcHRpb25zLmF1dG9TaXplT3B0aW9ucz8uaXNFbmFibGVkKSB7XG4gICAgICB0aGlzLmluaXRSZXNpemVMaXN0ZW5lcigpO1xuICAgIH1cbiAgfVxuXG4gIGdldCBvcHRpb25zKCkge1xuICAgIHJldHVybiB0aGlzLm9wdGlvbnNTaWduYWwoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiAgIFRoZSBldmVudCBlbWl0dGVkIHdoZW4gaW5wdXQgZmllbGQgY2hhbmdlcy5cbiAgICovXG4gIEBPdXRwdXQoKSBtb2RlbENoYW5nZSA9IG5ldyBFdmVudEVtaXR0ZXI8YW55PigpO1xuXG4gIC8qKlxuICAgKiAgIFRoZSBldmVudCBlbWl0dGVkIHdoZW4gdGhlIGhhc0Vycm9yLWZpZWxkIGNoYW5nZXNcbiAgICovXG4gIEBPdXRwdXQoKSBwdWJsaWMgaGFzRXJyb3JDaGFuZ2UgPSBuZXcgRXZlbnRFbWl0dGVyPGJvb2xlYW4+KCk7XG5cbiAgcHJpdmF0ZSBkZWZhdWx0T3B0aW9uczogSU91aVRleHRhcmVhT3B0aW9ucyA9IHtcbiAgICBwbGFjZWhvbGRlcjogJycsXG4gICAgbGFiZWw6ICcnLFxuICAgIGRpc2FibGVkOiBmYWxzZSxcbiAgICBkaXNhYmxlUmVzaXplOiBmYWxzZSxcbiAgICBoYXNFcnJvcjogZmFsc2UsXG4gICAgYXV0b1NpemVPcHRpb25zOiB7XG4gICAgICBpc0VuYWJsZWQ6IGZhbHNlLFxuICAgICAgbWF4SGVpZ2h0OiB1bmRlZmluZWQsXG4gICAgICBtaW5IZWlnaHQ6IHVuZGVmaW5lZCxcbiAgICB9LFxuICB9O1xuICBwcml2YXRlIHJlc2l6ZUxpc3RlbmVyOiBhbnk7XG4gIHB1YmxpYyBpc0ZvY3VzZWQgPSBzaWduYWwoZmFsc2UpO1xuICBwdWJsaWMgaXNJbml0aWFsaXplZCA9IHNpZ25hbChmYWxzZSk7XG4gIHB1YmxpYyBvcHRpb25zU2lnbmFsID0gc2lnbmFsPElPdWlUZXh0YXJlYU9wdGlvbnM+KHRoaXMuZGVmYXVsdE9wdGlvbnMpO1xuICBwdWJsaWMgY2xhc3NOYW1lID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIHJldHVybiBgb3VpLXRleHRhcmVhICR7dGhpcy5vcHRpb25zU2lnbmFsKCkuaGFzRXJyb3IgPyAnaGFzLWVycm9yJyA6ICcnfSAke1xuICAgICAgdGhpcy5pc0luaXRpYWxpemVkKCkgPyAnaW5pdGlhbGl6ZWQnIDogJydcbiAgICB9ICR7dGhpcy5vcHRpb25zU2lnbmFsKCkuZGlzYWJsZVJlc2l6ZSA/ICdkaXNhYmxlLXJlc2l6ZScgOiAnJ31gO1xuICB9KTtcbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSBjZHI6IENoYW5nZURldGVjdG9yUmVmLFxuICAgIHByaXZhdGUgcmVuZGVyZXI6IFJlbmRlcmVyMixcbiAgICBwcml2YXRlIGVsZW1lbnRSZWY6IEVsZW1lbnRSZWZcbiAgKSB7fVxuXG4gIHB1YmxpYyBvbk1vZGVsQ2hhbmdlKCkge1xuICAgIHRoaXMubW9kZWxDaGFuZ2UuZW1pdCh0aGlzLm1vZGVsKTtcbiAgfVxuXG4gIHByaXZhdGUgdXBkYXRlSGVpZ2h0KCkge1xuICAgIGlmICh0aGlzLm9wdGlvbnMuYXV0b1NpemVPcHRpb25zPy5pc0VuYWJsZWQgJiYgdGhpcy50ZXh0YXJlYSkge1xuICAgICAgdGhpcy50ZXh0YXJlYS5uYXRpdmVFbGVtZW50LnN0eWxlLmhlaWdodCA9ICcxcHgnO1xuICAgICAgdGhpcy50ZXh0YXJlYS5uYXRpdmVFbGVtZW50LnN0eWxlLmhlaWdodCA9XG4gICAgICAgIDI1ICsgdGhpcy50ZXh0YXJlYS5uYXRpdmVFbGVtZW50LnNjcm9sbEhlaWdodCArICdweCc7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBpbml0UmVzaXplTGlzdGVuZXIoKSB7XG4gICAgaWYgKHRoaXMudGV4dGFyZWE/Lm5hdGl2ZUVsZW1lbnQpIHtcbiAgICAgIHRoaXMudGV4dGFyZWEubmF0aXZlRWxlbWVudC5zZXRBdHRyaWJ1dGUoXG4gICAgICAgICdzdHlsZScsXG4gICAgICAgICdoZWlnaHQ6JyArXG4gICAgICAgICAgdGhpcy50ZXh0YXJlYS5uYXRpdmVFbGVtZW50LnNjcm9sbEhlaWdodCArXG4gICAgICAgICAgJ3B4O292ZXJmbG93LXk6aGlkZGVuOydcbiAgICAgICk7XG4gICAgICB0aGlzLnJlc2l6ZUxpc3RlbmVyID0gdGhpcy5yZW5kZXJlci5saXN0ZW4oXG4gICAgICAgIHRoaXMudGV4dGFyZWEubmF0aXZlRWxlbWVudCxcbiAgICAgICAgJ2lucHV0JyxcbiAgICAgICAgdGhpcy5vbklucHV0LmJpbmQodGhpcylcbiAgICAgICk7XG4gICAgfVxuICB9XG4gIHByaXZhdGUgb25JbnB1dCgpIHtcbiAgICB0aGlzLnRleHRhcmVhLm5hdGl2ZUVsZW1lbnQuc3R5bGUuaGVpZ2h0ID0gMDtcbiAgICB0aGlzLnRleHRhcmVhLm5hdGl2ZUVsZW1lbnQuc3R5bGUuaGVpZ2h0ID1cbiAgICAgIHRoaXMudGV4dGFyZWEubmF0aXZlRWxlbWVudC5zY3JvbGxIZWlnaHQgKyAncHgnO1xuICB9XG5cbiAgcHVibGljIG5nQWZ0ZXJWaWV3SW5pdCgpIHtcbiAgICB0aGlzLmlzRm9jdXNlZC5zZXQoISF0aGlzLm1vZGVsKTtcbiAgICBpZiAodGhpcy5pc0ZvY3VzZWQoKSkge1xuICAgICAgdGhpcy5yZW5kZXJlci5hZGRDbGFzcyh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ2ZvY3VzZWQnKTtcbiAgICB9XG4gICAgdGhpcy5jZHIuZGV0ZWN0Q2hhbmdlcygpO1xuICAgIGlmICh0aGlzLm9wdGlvbnMuYXV0b1NpemVPcHRpb25zPy5pc0VuYWJsZWQgJiYgdGhpcy5hdXRvc2l6ZVdyYXBwZXIpIHtcbiAgICAgIHRoaXMuaW5pdFJlc2l6ZUxpc3RlbmVyKCk7XG4gICAgICBpZiAodGhpcy5vcHRpb25zLmF1dG9TaXplT3B0aW9ucy5tYXhIZWlnaHQpIHtcbiAgICAgICAgdGhpcy5hdXRvc2l6ZVdyYXBwZXIubmF0aXZlRWxlbWVudC5zdHlsZS5tYXhIZWlnaHQgPVxuICAgICAgICAgIHRoaXMub3B0aW9ucy5hdXRvU2l6ZU9wdGlvbnMubWF4SGVpZ2h0O1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMub3B0aW9ucy5hdXRvU2l6ZU9wdGlvbnMubWluSGVpZ2h0KSB7XG4gICAgICAgIHRoaXMuYXV0b3NpemVXcmFwcGVyLm5hdGl2ZUVsZW1lbnQuc3R5bGUubWluSGVpZ2h0ID1cbiAgICAgICAgICB0aGlzLm9wdGlvbnMuYXV0b1NpemVPcHRpb25zLm1pbkhlaWdodDtcbiAgICAgIH1cbiAgICB9XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICB0aGlzLnVwZGF0ZUhlaWdodCgpO1xuICAgICAgdGhpcy5pc0luaXRpYWxpemVkLnNldCh0cnVlKTtcbiAgICB9LCA0MDApO1xuICB9XG5cbiAgcHVibGljIHNldEZvY3VzKHZhbHVlOiBib29sZWFuKSB7XG4gICAgaWYgKCF0aGlzLm1vZGVsICYmICF2YWx1ZSkge1xuICAgICAgdGhpcy5pc0ZvY3VzZWQuc2V0KGZhbHNlKTtcbiAgICAgIHRoaXMubW9kZWxDaGFuZ2UuZW1pdCh0aGlzLm1vZGVsKTtcbiAgICAgIHRoaXMucmVuZGVyZXIucmVtb3ZlQ2xhc3ModGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQsICdmb2N1c2VkJyk7XG4gICAgfSBlbHNlIGlmICh2YWx1ZSkge1xuICAgICAgdGhpcy5pc0ZvY3VzZWQuc2V0KHRydWUpO1xuICAgICAgdGhpcy5zZXRFcnJvcihmYWxzZSk7XG4gICAgICB0aGlzLnJlbmRlcmVyLmFkZENsYXNzKHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LCAnZm9jdXNlZCcpO1xuICAgIH1cbiAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XG4gIH1cbiAgcHVibGljIHNldEVycm9yKHZhbHVlOiBib29sZWFuKSB7XG4gICAgdGhpcy5vcHRpb25zLmhhc0Vycm9yID0gdmFsdWU7XG4gICAgdGhpcy5oYXNFcnJvckNoYW5nZS5lbWl0KHZhbHVlKTtcbiAgICB0aGlzLmNkci5kZXRlY3RDaGFuZ2VzKCk7XG4gIH1cbn1cbiIsIjxkaXYgY2xhc3M9XCJ7eyBjbGFzc05hbWUoKSB9fVwiIChjbGljayk9XCJzZXRGb2N1cyh0cnVlKVwiPlxuICBAaWYgKG9wdGlvbnNTaWduYWwoKS5sYWJlbCkge1xuICAgIDxkaXYgY2xhc3M9XCJvdWktdGV4dGFyZWEtbGFiZWxcIj5cbiAgICAgIHt7IG9wdGlvbnNTaWduYWwoKS5sYWJlbCB9fVxuICAgIDwvZGl2PlxuICB9XG4gIDxkaXYgY2xhc3M9XCJ0ZXh0YXJlYS13cmFwcGVyXCI+XG4gICAgQGlmICghb3B0aW9uc1NpZ25hbCgpLmF1dG9TaXplT3B0aW9ucz8uaXNFbmFibGVkKSB7XG4gICAgICA8dGV4dGFyZWFcbiAgICAgICAgY2xhc3M9XCJ0ZXh0YXJlYVwiXG4gICAgICAgIFtwbGFjZWhvbGRlcl09XCJvcHRpb25zU2lnbmFsKCkucGxhY2Vob2xkZXIgPz8gJydcIlxuICAgICAgICAoZm9jdXMpPVwic2V0Rm9jdXModHJ1ZSlcIlxuICAgICAgICAoYmx1cik9XCJzZXRGb2N1cyhmYWxzZSlcIlxuICAgICAgICAjdGV4dGFyZWFcbiAgICAgICAgW2Rpc2FibGVkXT1cIm9wdGlvbnNTaWduYWwoKS5kaXNhYmxlZCA/PyBmYWxzZVwiXG4gICAgICAgIFsobmdNb2RlbCldPVwibW9kZWxcIlxuICAgICAgICAoaW5wdXQpPVwib25Nb2RlbENoYW5nZSgpXCJcbiAgICAgID48L3RleHRhcmVhPlxuICAgIH1cbiAgICBAaWYgKG9wdGlvbnNTaWduYWwoKS5hdXRvU2l6ZU9wdGlvbnM/LmlzRW5hYmxlZCkge1xuICAgICAgPGRpdlxuICAgICAgICAjYXV0b3NpemVXcmFwcGVyIGNsYXNzPVwiZ3Jvdy13cmFwIG91aS1zY3JvbGxiYXIgb3VpLXNjcm9sbGJhci1hdXRvXCI+XG4gICAgICAgIDx0ZXh0YXJlYVxuICAgICAgICAgIGNsYXNzPVwidGV4dGFyZWFcIlxuICAgICAgICAgIFtwbGFjZWhvbGRlcl09XCJvcHRpb25zU2lnbmFsKCkucGxhY2Vob2xkZXIgPz8gJydcIlxuICAgICAgICAgIChmb2N1cyk9XCJzZXRGb2N1cyh0cnVlKVwiXG4gICAgICAgICAgKGJsdXIpPVwic2V0Rm9jdXMoZmFsc2UpXCJcbiAgICAgICAgICAjdGV4dGFyZWFcbiAgICAgICAgICBbZGlzYWJsZWRdPVwib3B0aW9uc1NpZ25hbCgpLmRpc2FibGVkID8/IGZhbHNlXCJcbiAgICAgICAgICBbKG5nTW9kZWwpXT1cIm1vZGVsXCJcbiAgICAgICAgICAoaW5wdXQpPVwib25Nb2RlbENoYW5nZSgpXCJcbiAgICAgICAgPjwvdGV4dGFyZWE+XG4gICAgICA8L2Rpdj5cbiAgICB9XG4gIDwvZGl2PlxuPC9kaXY+XG4iXX0=