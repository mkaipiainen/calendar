/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/pipes" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-pipes.d.ts.map