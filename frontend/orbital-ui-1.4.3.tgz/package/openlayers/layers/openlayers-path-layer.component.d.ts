import { Feature as OlFeature } from 'ol';
import { RGBA } from 'orbital-ui/core';
import { OpenlayersBaseLayerComponent } from './openlayers-base-layer.component';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import { OuiOpenlayersPathLayerOptions } from '../types';
import * as i0 from "@angular/core";
export declare class OpenlayersPathLayerComponent extends OpenlayersBaseLayerComponent<OuiOpenlayersPathLayerOptions> {
    options: import("@angular/core").InputSignal<OuiOpenlayersPathLayerOptions>;
    combinedOptions: import("@angular/core").Signal<{
        onClick?: ((feature: OlFeature<import("ol/geom").Geometry>) => void) | undefined;
        onHover?: ((feature: OlFeature<import("ol/geom").Geometry>) => void) | undefined;
        getCursor?: ((feature: OlFeature<import("ol/geom").Geometry>) => string) | undefined;
        id: string;
        order?: number | undefined;
        isVisible?: boolean | undefined;
        isEnabled?: boolean | undefined;
        sideBySideType?: "left" | "right" | undefined;
        data: Record<string, any>[];
        getLineColor: RGBA | ((feature: import("@turf/helpers").Feature<import("@turf/helpers").Geometry, import("@turf/helpers").Properties>) => RGBA);
        getLineWidth: number | ((feature: import("@turf/helpers").Feature<import("@turf/helpers").Geometry, import("@turf/helpers").Properties>) => number);
        autoHighlight?: boolean | undefined;
        highlightColor?: RGBA | undefined;
        getPath: (feature: any) => import("@turf/helpers").Position;
        pickable?: boolean | undefined;
    }>;
    source: import("@angular/core").WritableSignal<VectorSource<OlFeature<import("ol/geom").Geometry>>>;
    layer: import("@angular/core").WritableSignal<VectorLayer<VectorSource<OlFeature<import("ol/geom").Geometry>>>>;
    constructor();
    private getStyleForFeature;
    onHover(feature: OlFeature): void;
    onUnHover(feature: OlFeature): void;
    updateLayer(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpenlayersPathLayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpenlayersPathLayerComponent, "oui-openlayers-path-layer", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=openlayers-path-layer.component.d.ts.map