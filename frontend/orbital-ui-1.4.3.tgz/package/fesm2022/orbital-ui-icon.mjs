import * as i0 from '@angular/core';
import { signal, computed, effect, Component, ChangeDetectionStrategy, Inject, ViewChild, Input } from '@angular/core';
import SVGInjector from 'svg-injector/dist/svg-injector.min.js';
import { DOCUMENT, NgClass, NgOptimizedImage } from '@angular/common';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i1 from 'orbital-ui/themes';

/**
 * Component to be used to display icons. Streamlines use of especially svg-icons, but can also display images like pngs.
 * Created because configuration of svg-icons is cumbersome, and this component acts as an abstraction that does a lot of
 * the hard work automatically.
 *
 * Under the hood uses a method to 'unpack' a given svg-image, and inlines it directly into the DOM. This is done
 * to enable coloring the SVG on the fly.
 *
 *
 *  Example use:
 *
 *  <oui-icon icon="assets/icons/my-svg.svg" [options]={fillColor: 'color-white', strokeColor: 'color-white', viewBox: '0 0 48 48'}></oui-icon>
 */
class OuiIconComponent {
    ouiThemeService;
    renderer;
    elementRef;
    document;
    destroyRef;
    iconContainerElement;
    /**
     *   The path to the icon to be used
     */
    set icon(newIcon) {
        this.iconSignal.set(newIcon);
        if (this.iconContainerElement) {
            this.iconContainerElement.nativeElement.replaceChildren();
            const newImage = this.renderer.createElement('img');
            this.renderer.setAttribute(newImage, 'src', this.iconSignal());
            this.renderer.setAttribute(newImage, 'id', 'svg-inject-image');
            newImage.src = this.iconSignal();
            this.iconElement = newImage;
            this.renderer.appendChild(this.iconContainerElement.nativeElement, this.iconElement);
            this.setUsedColors(this.combinedOptions());
            this.doSvgInjection(this.combinedOptions());
        }
    }
    get icon() {
        return this.iconSignal();
    }
    iconElement;
    /**
     *   The options that are to be used with the icons. Important options are:
     *     fillColor: string - the fillColor of the svg. Can be a hex-color, or a css-variable
     *     strokeColor: string - the strokeColor of the svg. Can be a hex-color or a css-variable
     *     viewBox: string - Controls the viewbox of the svg. This is usually taken by default from the svg-image.
     *                       Sometimes SVGs don't have the viewbox proprety by default, in which case you might need to provide it yourself.
     *                       In these cases, you can usually look at the dimensions of the image and match the viewBox with that. For example,
     *                       if an image is 40 pixels wide and 30 pixels high, you can pass the following viewBox: '0 0 40 30'.
     *
     *     size: string - The size of the icon, for example '20px' or '2rem'. A quick way to pass a single proprety instead of height and width separately.
     *     height: string - The same as size, except only for height
     *     width: string - The same as size, except only for width
     *     disableTransform: boolean - If set to true, svg-injecting is disabled. This should be set to true for example for png-icons.
     *     disableColorChange: boolean - If set to true, color of the SVG isn't altered. This should be set to true if SVG already contains colors.
     *     preserveAspectRatio: string - alters the preserveAspectRatio-proprety of the svg. Rarely used.
     *     margin: string - way to pass a margin to be used for the icon if needed
     */
    set options(newOptions) {
        this.optionsSignal.set(newOptions);
    }
    get options() {
        return this.optionsSignal();
    }
    #actualFillColor;
    #actualStrokeColor;
    defaultOptions = {
        fillColor: 'color-primary-icons',
        strokeColor: 'color-primary-icons',
        size: '24px',
    };
    optionsSignal = signal(this.defaultOptions);
    iconSignal = signal('');
    combinedOptions = computed(() => {
        return {
            ...this.defaultOptions,
            ...this.optionsSignal(),
        };
    });
    fallbackSize = '24px';
    constructor(ouiThemeService, renderer, elementRef, document, destroyRef) {
        this.ouiThemeService = ouiThemeService;
        this.renderer = renderer;
        this.elementRef = elementRef;
        this.document = document;
        this.destroyRef = destroyRef;
        effect(() => {
            const options = this.combinedOptions();
            this.setElementSize(options);
            this.setUsedColors(options);
            this.doSvgInjection(options);
        });
    }
    ngAfterViewInit() {
        this.iconElement =
            this.iconContainerElement.nativeElement.querySelector('.svg-inject-image');
        this.ouiThemeService.theme$
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(() => {
            setTimeout(() => {
                this.setUsedColors(this.combinedOptions());
                this.colorSvgAndContents(this.combinedOptions());
            });
        });
    }
    setElementSize(options) {
        const height = options.height || options.size || this.fallbackSize;
        const width = options.width || options.size || this.fallbackSize;
        const heightCssVariableValue = getComputedStyle(this.document.documentElement).getPropertyValue(`--${height}`);
        const widthCssVariableValue = getComputedStyle(this.document.documentElement).getPropertyValue(`--${width}`);
        const actualHeight = heightCssVariableValue || height;
        const actualWidth = widthCssVariableValue || width;
        this.renderer.setStyle(this.iconContainerElement.nativeElement, 'height', actualHeight);
        this.renderer.setStyle(this.iconContainerElement.nativeElement, 'width', actualWidth);
    }
    doSvgInjection(options) {
        const height = options.height || options.size || this.fallbackSize;
        const width = options.width || options.size || this.fallbackSize;
        const heightCssVariableValue = getComputedStyle(this.document.documentElement).getPropertyValue(`--${height}`);
        const widthCssVariableValue = getComputedStyle(this.document.documentElement).getPropertyValue(`--${width}`);
        const actualHeight = heightCssVariableValue || height;
        const actualWidth = widthCssVariableValue || width;
        if (this.iconContainerElement && height) {
            this.renderer.setStyle(this.iconContainerElement.nativeElement, 'height', actualHeight);
        }
        if (this.iconContainerElement && width) {
            this.renderer.setStyle(this.iconContainerElement.nativeElement, 'width', actualWidth);
        }
        if (this.iconElement && height) {
            this.renderer.setStyle(this.iconElement, 'height', actualHeight);
        }
        if (this.iconElement && width) {
            this.renderer.setStyle(this.iconElement, 'width', actualWidth);
        }
        if (!options.disableTransform && this.iconElement) {
            SVGInjector(this.iconElement, {}, () => {
                const svg = this.iconContainerElement.nativeElement.querySelector('svg');
                if (options.preserveAspectRatio) {
                    this.renderer.setAttribute(svg, 'preserveAspectRatio', options.preserveAspectRatio);
                }
                const viewBox = options.viewBox;
                if (viewBox) {
                    this.renderer.setAttribute(svg, 'viewBox', viewBox);
                }
                else if (!svg.getAttribute('viewBox')) {
                    this.renderer.setAttribute(svg, 'viewBox', '0 0 48 48');
                }
                if (options.height) {
                    this.renderer.setAttribute(svg, 'height', actualHeight);
                }
                if (options.width) {
                    this.renderer.setAttribute(svg, 'width', actualWidth);
                }
                const margin = options.margin;
                if (margin) {
                    this.renderer.setAttribute(svg, 'margin', margin);
                }
                this.colorSvgAndContents(options);
            });
        }
    }
    setUsedColors(options) {
        const fillColor = options.fillColor;
        if (Array.isArray(fillColor)) {
            this.#actualFillColor = `rgba(${fillColor[0]}, ${fillColor[1]}, ${fillColor[2]}, ${fillColor.length > 3 ? fillColor[3] / 255 : '1'})`;
        }
        else {
            this.#actualFillColor = fillColor;
        }
        const strokeColor = options.strokeColor;
        if (Array.isArray(strokeColor)) {
            this.#actualStrokeColor = `rgba(${strokeColor[0]}, ${strokeColor[1]}, ${strokeColor[2]}, ${strokeColor.length > 3 ? strokeColor[3] / 255 : '1'})`;
        }
        else {
            this.#actualStrokeColor = strokeColor;
        }
    }
    colorSvgAndContents(options) {
        const paths = this.iconContainerElement.nativeElement.querySelectorAll('path');
        if (paths && paths.length) {
            for (const path of paths) {
                if (this.#actualFillColor !== 'original' &&
                    !options.disableColorChange) {
                    const cssFillVariableColor = getComputedStyle(this.document.documentElement).getPropertyValue(`--${this.#actualFillColor}`);
                    path.style.fill = cssFillVariableColor
                        ? `var(--${this.#actualFillColor})`
                        : this.#actualFillColor;
                }
                if (this.#actualStrokeColor !== 'original' &&
                    !options.disableColorChange) {
                    const cssStrokeVariableColor = getComputedStyle(this.document.documentElement).getPropertyValue(`--${this.#actualFillColor}`);
                    path.style.stroke = cssStrokeVariableColor
                        ? `var(--${this.#actualStrokeColor})`
                        : this.#actualStrokeColor;
                }
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiIconComponent, deps: [{ token: i1.OuiThemeService }, { token: i0.Renderer2 }, { token: i0.ElementRef }, { token: DOCUMENT }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiIconComponent, isStandalone: true, selector: "oui-icon", inputs: { icon: "icon", options: "options" }, viewQueries: [{ propertyName: "iconContainerElement", first: true, predicate: ["iconContainerElement"], descendants: true }], ngImport: i0, template: `
    <div #iconContainerElement class="oui-icon-container">
      <img
        class="svg-inject svg-inject-image"
        [ngClass]="{ 'disable-transform': combinedOptions().disableTransform }"
        src="{{ icon }}"
      />
    </div>
  `, isInline: true, styles: [":host{background-color:transparent;display:flex;justify-content:center;align-items:center}:host .oui-icon-container{display:flex;justify-content:center;align-items:center;background-color:transparent;position:relative}:host .oui-icon-container img{opacity:0}:host .oui-icon-container img.disable-transform{opacity:1}:host .oui-icon-container .svg-inject path{fill:var(--color-secondary)}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiIconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-icon', template: `
    <div #iconContainerElement class="oui-icon-container">
      <img
        class="svg-inject svg-inject-image"
        [ngClass]="{ 'disable-transform': combinedOptions().disableTransform }"
        src="{{ icon }}"
      />
    </div>
  `, standalone: true, imports: [NgOptimizedImage, NgClass], changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{background-color:transparent;display:flex;justify-content:center;align-items:center}:host .oui-icon-container{display:flex;justify-content:center;align-items:center;background-color:transparent;position:relative}:host .oui-icon-container img{opacity:0}:host .oui-icon-container img.disable-transform{opacity:1}:host .oui-icon-container .svg-inject path{fill:var(--color-secondary)}\n"] }]
        }], ctorParameters: () => [{ type: i1.OuiThemeService }, { type: i0.Renderer2 }, { type: i0.ElementRef }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.DestroyRef }], propDecorators: { iconContainerElement: [{
                type: ViewChild,
                args: ['iconContainerElement']
            }], icon: [{
                type: Input,
                args: [{ required: true }]
            }], options: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiIconComponent };
//# sourceMappingURL=orbital-ui-icon.mjs.map
