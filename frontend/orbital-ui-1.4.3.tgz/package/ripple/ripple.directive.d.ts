import { AfterViewInit, DestroyRef, ElementRef, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Can be used to add a ripple-element on an element when clicking on them. No options needed.
 */
export declare class OuiRippleDirective implements AfterViewInit {
    private elementRef;
    private renderer;
    private destroyRef;
    constructor(elementRef: ElementRef, renderer: Renderer2, destroyRef: DestroyRef);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiRippleDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OuiRippleDirective, "[ouiRipple]", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=ripple.directive.d.ts.map