import { AfterViewInit } from '@angular/core';
import { OpenlayersBaseLayerComponent } from './openlayers-base-layer.component';
import { Feature } from 'ol';
import { Geometry } from 'ol/geom';
import VectorSource from 'ol/source/Vector';
import VectorLayer from 'ol/layer/Vector';
import { OpenlayersComponent } from '../openlayers.component';
import * as i0 from "@angular/core";
export declare class OpenlayersGeolocateLayerComponent extends OpenlayersBaseLayerComponent<any> implements AfterViewInit {
    options: import("@angular/core").InputSignal<import("../types").OuiOpenLayersCommonOptions>;
    combinedOptions: import("@angular/core").Signal<{
        onClick?: ((feature: Feature<Geometry>) => void) | undefined;
        onHover?: ((feature: Feature<Geometry>) => void) | undefined;
        getCursor?: ((feature: Feature<Geometry>) => string) | undefined;
        id: string;
        order?: number | undefined;
        isVisible?: boolean | undefined;
        isEnabled?: boolean | undefined;
        sideBySideType?: "left" | "right" | undefined;
    }>;
    private geolocation;
    private positionFeature;
    private accuracyFeature;
    source: import("@angular/core").WritableSignal<VectorSource<Feature<Geometry>>>;
    layer: import("@angular/core").WritableSignal<VectorLayer<VectorSource<Feature<Geometry>>>>;
    private geolocationListeners;
    constructor();
    updateLayer(): void;
    onAdd(): void;
    onRemove(): void;
    onDestroy(openlayers: OpenlayersComponent): void;
    ngAfterViewInit(): void;
    private onAccuracyOrGeometryChange;
    private onPositionChange;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpenlayersGeolocateLayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpenlayersGeolocateLayerComponent, "oui-openlayers-geolocate-layer", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=openlayers-geolocate-layer.component.d.ts.map