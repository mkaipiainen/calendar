import { Pipe } from '@angular/core';
import { format, getMonth } from 'date-fns';
import * as i0 from "@angular/core";
export class ParentDateLabelPipe {
    transform(value, mode, translations) {
        if (!value) {
            return '';
        }
        if (mode === 'month') {
            return format(value, 'yyyy');
        }
        else if (mode === 'day') {
            const month = getMonth(value);
            return translations.months[month] + ' ' + format(value, 'yyyy');
        }
        else {
            return format(value, 'yyyy');
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: ParentDateLabelPipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: ParentDateLabelPipe, isStandalone: true, name: "parentDateLabel" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: ParentDateLabelPipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'parentDateLabel',
                    standalone: true,
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFyZW50LWRhdGUtbGFiZWwucGlwZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL29yYml0YWwtdWkvZGF0ZS1waWNrZXIvcGlwZXMvcGFyZW50LWRhdGUtbGFiZWwucGlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsSUFBSSxFQUFpQixNQUFNLGVBQWUsQ0FBQztBQUNwRCxPQUFPLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxNQUFNLFVBQVUsQ0FBQzs7QUFPNUMsTUFBTSxPQUFPLG1CQUFtQjtJQUM5QixTQUFTLENBQ1AsS0FBMkIsRUFDM0IsSUFBWSxFQUNaLFlBQW9DO1FBRXBDLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNYLE9BQU8sRUFBRSxDQUFDO1FBQ1osQ0FBQztRQUNELElBQUksSUFBSSxLQUFLLE9BQU8sRUFBRSxDQUFDO1lBQ3JCLE9BQU8sTUFBTSxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztRQUMvQixDQUFDO2FBQU0sSUFBSSxJQUFJLEtBQUssS0FBSyxFQUFFLENBQUM7WUFDMUIsTUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQzlCLE9BQU8sWUFBWSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxHQUFHLEdBQUcsTUFBTSxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztRQUNsRSxDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sTUFBTSxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztRQUMvQixDQUFDO0lBQ0gsQ0FBQzt1R0FqQlUsbUJBQW1CO3FHQUFuQixtQkFBbUI7OzJGQUFuQixtQkFBbUI7a0JBSi9CLElBQUk7bUJBQUM7b0JBQ0osSUFBSSxFQUFFLGlCQUFpQjtvQkFDdkIsVUFBVSxFQUFFLElBQUk7aUJBQ2pCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGlwZSwgUGlwZVRyYW5zZm9ybSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgZm9ybWF0LCBnZXRNb250aCB9IGZyb20gJ2RhdGUtZm5zJztcbmltcG9ydCB7IElEYXRlTGFiZWxUcmFuc2xhdGlvbnMgfSBmcm9tICcuLi9kYXRlLXBpY2tlci9kYXRlLXBpY2tlci5jb21wb25lbnQnO1xuXG5AUGlwZSh7XG4gIG5hbWU6ICdwYXJlbnREYXRlTGFiZWwnLFxuICBzdGFuZGFsb25lOiB0cnVlLFxufSlcbmV4cG9ydCBjbGFzcyBQYXJlbnREYXRlTGFiZWxQaXBlIGltcGxlbWVudHMgUGlwZVRyYW5zZm9ybSB7XG4gIHRyYW5zZm9ybShcbiAgICB2YWx1ZTogbnVtYmVyIHwgRGF0ZSB8IG51bGwsXG4gICAgbW9kZTogc3RyaW5nLFxuICAgIHRyYW5zbGF0aW9uczogSURhdGVMYWJlbFRyYW5zbGF0aW9uc1xuICApOiBzdHJpbmcge1xuICAgIGlmICghdmFsdWUpIHtcbiAgICAgIHJldHVybiAnJztcbiAgICB9XG4gICAgaWYgKG1vZGUgPT09ICdtb250aCcpIHtcbiAgICAgIHJldHVybiBmb3JtYXQodmFsdWUsICd5eXl5Jyk7XG4gICAgfSBlbHNlIGlmIChtb2RlID09PSAnZGF5Jykge1xuICAgICAgY29uc3QgbW9udGggPSBnZXRNb250aCh2YWx1ZSk7XG4gICAgICByZXR1cm4gdHJhbnNsYXRpb25zLm1vbnRoc1ttb250aF0gKyAnICcgKyBmb3JtYXQodmFsdWUsICd5eXl5Jyk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiBmb3JtYXQodmFsdWUsICd5eXl5Jyk7XG4gICAgfVxuICB9XG59XG4iXX0=