export * from './routing.service';
//# sourceMappingURL=public-api.d.ts.map