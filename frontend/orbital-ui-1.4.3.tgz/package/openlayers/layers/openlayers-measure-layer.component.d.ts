import { Feature as OlFeature } from 'ol';
import { OpenlayersBaseLayerComponent } from './openlayers-base-layer.component';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import { OuiOpenLayersCombinedIconLayerOptions, OuiOpenlayersMeasureLayerOptions } from '../types';
import * as i0 from "@angular/core";
export declare class OpenlayersMeasureLayerComponent extends OpenlayersBaseLayerComponent<OuiOpenlayersMeasureLayerOptions> {
    options: import("@angular/core").InputSignal<OuiOpenlayersMeasureLayerOptions>;
    combinedOptions: import("@angular/core").Signal<OuiOpenLayersCombinedIconLayerOptions>;
    source: import("@angular/core").WritableSignal<VectorSource<OlFeature<import("ol/geom").Geometry>>>;
    private drawInteraction;
    layer: import("@angular/core").WritableSignal<VectorLayer<VectorSource<OlFeature<import("ol/geom").Geometry>>>>;
    private dragChangeSubject;
    private auditedDragChange$;
    private distance;
    private startPoint;
    private targetPoint;
    private dragFeature;
    private measureTooltipElement;
    private measureTooltipOverlay;
    private drawEventListeners;
    private featureEventListeners;
    constructor();
    onHover(feature: OlFeature): void;
    onUnHover(feature: OlFeature): void;
    onAdd(): void;
    private addInteraction;
    private onDrawStart;
    private onDragChange;
    private onAuditedDragChange;
    private onDrawEnd;
    private formatLength;
    updateLayer(): void;
    private createMeasureTooltip;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpenlayersMeasureLayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpenlayersMeasureLayerComponent, "oui-openlayers-measure-layer", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=openlayers-measure-layer.component.d.ts.map