export declare function GetUrlWithQueryParams(baseUrl: string, params: Record<string, any>): string;
//# sourceMappingURL=query-param-formatter.d.ts.map