import { AfterViewInit } from '@angular/core';
import { RouterLinkActive } from '@angular/router';
import { MAIN_SIDEBAR_SECTION_TYPES, OuiMainSidebarService } from '../main-sidebar.service';
import { IOuiIconOptions } from 'orbital-ui/icon';
import { OuiMainSidebarCombinedOptions } from '../main-sidebar.component';
import * as i0 from "@angular/core";
export type OuiMainSidebarRouteSectionChildrenOptions = {
    backgroundColor?: string;
    className?: string;
};
type OuiMainSidebarRouteSectionRouteOptions = {
    commands: string[];
    queryParams?: Record<string, string>;
    queryParamsHandling?: 'merge' | 'preserve' | '';
};
export type OuiMainSidebarRouteSectionOptions = {
    icon: string;
    iconOptions?: IOuiIconOptions;
    label?: string;
    onClick?: () => void;
    type: typeof MAIN_SIDEBAR_SECTION_TYPES.ROUTE;
    routeOptions: OuiMainSidebarRouteSectionRouteOptions;
    children?: {
        options?: OuiMainSidebarRouteSectionChildrenOptions;
        routes: OuiMainSidebarRouteSectionOptions[];
    };
    id: string;
    isActive?: () => boolean;
    isDisabled?: boolean;
};
/**
 * Route-button for the main sidebar. Not used manually, only instantiated dynamically by the oui-main-sidebar-service
 * Options can be passed via the addRouteSection-method of the oui-main-sidebar-service.
 *
 * @Input() options: IOuiMainSidebarRouteSectionOptions
 */
export declare class OuiMainSidebarRouteSectionComponent implements AfterViewInit {
    ouiMainSidebarService: OuiMainSidebarService;
    private destroyRef;
    private elementRef;
    routerLinkActive: RouterLinkActive;
    isSidebarOpen: import("@angular/core").WritableSignal<boolean>;
    sidebarOptions: import("@angular/core").InputSignal<OuiMainSidebarCombinedOptions>;
    options: import("@angular/core").InputSignal<OuiMainSidebarRouteSectionOptions>;
    isDisabled: import("@angular/core").Signal<boolean>;
    constructor();
    ngAfterViewInit(): void;
    onClick(): void;
    private updateActiveClass;
    protected readonly MAIN_SIDEBAR_SECTION_TYPES: {
        ROUTE: string;
        SUBROUTE: string;
        ACTION: string;
        SUBSECTION: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiMainSidebarRouteSectionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiMainSidebarRouteSectionComponent, "oui-main-sidebar-route-section", never, { "sidebarOptions": { "alias": "sidebarOptions"; "required": true; "isSignal": true; }; "options": { "alias": "options"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
export {};
//# sourceMappingURL=main-sidebar-route-section.component.d.ts.map