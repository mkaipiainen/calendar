import * as i0 from '@angular/core';
import { ElementRef, Injectable, EventEmitter, Directive, Inject, Output, HostListener, Input } from '@angular/core';
import { DOCUMENT } from '@angular/common';
import { GUID } from 'orbital-ui/helpers';
import { Subject, ReplaySubject, auditTime, takeUntil, fromEvent, map, BehaviorSubject } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { merge, throttle } from 'lodash-es';
import anime from 'animejs';

function GetTransformDelta(startPosition, mousePosition) {
    const deltaX = mousePosition.x - startPosition.x;
    const deltaY = mousePosition.y - startPosition.y;
    return {
        x: deltaX,
        y: deltaY,
    };
}
function getDistanceBetweenPointAndElement(point, element) {
    if (!element) {
        return Number.MAX_SAFE_INTEGER;
    }
    else {
        const bbox = element.getBoundingClientRect();
        return Math.sqrt(Math.pow(bbox.left - point.x, 2) + Math.pow(bbox.top - point.y, 2));
    }
}
function GetTranslateXY(element) {
    const style = window.getComputedStyle(element);
    const matrix = new DOMMatrixReadOnly(style.transform);
    return {
        x: matrix.m41 ?? 0,
        y: matrix.m42 ?? 0,
    };
}
function GetElementViewportLocation(element) {
    const rect = element.getBoundingClientRect();
    return {
        x: rect.left,
        y: rect.top,
    };
}
function GetTranslatedBbox(draggable, delta) {
    const rect = draggable.getBbox();
    return {
        ...CopyBbox(rect),
        left: rect.left + delta.x,
        right: rect.right + delta.x,
        top: rect.top + delta.y,
        bottom: rect.bottom + delta.y,
        x: rect.x + delta.x,
        y: rect.y + delta.y,
        toJSON: () => { },
    };
}
function GetBboxMovedToXy(rect, targetXy) {
    return {
        left: targetXy.x,
        right: targetXy.x + rect.width,
        top: targetXy.y,
        bottom: targetXy.y + rect.height,
        width: rect.width,
        height: rect.height,
        x: targetXy.x,
        y: targetXy.y,
        toJSON: () => { },
    };
}
function CopyBbox(bbox) {
    return {
        x: bbox.x,
        y: bbox.y,
        width: bbox.width,
        height: bbox.height,
        left: bbox.left,
        right: bbox.right,
        top: bbox.top,
        bottom: bbox.bottom,
        toJSON: () => bbox.toJSON(),
    };
}
function GetBboxCenteredToAnotherBbox(bboxToMove, bboxToCenterOn) {
    const targetX = bboxToCenterOn.left + bboxToCenterOn.width / 2 - bboxToMove.width / 2;
    const targetY = bboxToCenterOn.top + bboxToCenterOn.height / 2 - bboxToMove.height / 2;
    return GetBboxMovedToXy(bboxToMove, { x: targetX, y: targetY });
}
function GetXyBetweenBboxes(bbox1, bbox2) {
    return {
        x: bbox1.left - bbox2.left,
        y: bbox1.top - bbox2.top,
    };
}
function GetViewportPointFromEvent(event) {
    return {
        x: event instanceof MouseEvent ? event.clientX : event.touches[0].clientX,
        y: event instanceof MouseEvent ? event.clientY : event.touches[0].clientY,
    };
}
function GetTransformRequiredToMoveElement(element, targetPoint) {
    // Get the element's current position relative to the viewport
    const rect = element.getBoundingClientRect();
    const currentX = rect.left;
    const currentY = rect.top;
    // Calculate the required translation
    const translateX = targetPoint.x - currentX;
    const translateY = targetPoint.y - currentY;
    // Return the transform style
    return {
        x: translateX,
        y: translateY,
    };
}

function ContainerConstraint(container, targetRect, anchor) {
    if (!container) {
        return targetRect;
    }
    if (!anchor) {
        anchor = 'edge';
    }
    const containerElement = container instanceof ElementRef ? container.nativeElement : container;
    const containerRect = containerElement.getBoundingClientRect();
    let recalculatedRect = {
        ...CopyBbox(targetRect),
    };
    let newX = recalculatedRect.left;
    let newY = recalculatedRect.top;
    // Calculate if center of object should be constrained
    if (anchor === 'center') {
        if (recalculatedRect.left + recalculatedRect.width / 2 <=
            containerRect.left) {
            newX = containerRect.left - recalculatedRect.width / 2;
        }
        if (recalculatedRect.left + recalculatedRect.width / 2 >=
            containerRect.left + containerRect.width) {
            newX =
                containerRect.left + containerRect.width - recalculatedRect.width / 2;
        }
        if (recalculatedRect.top <=
            containerRect.top - recalculatedRect.height / 2) {
            newY = containerRect.top - recalculatedRect.height / 2;
        }
        if (recalculatedRect.top >=
            containerRect.top + containerRect.height - recalculatedRect.height / 2) {
            newY =
                containerRect.top + containerRect.height - recalculatedRect.height / 2;
        }
    }
    else {
        if (recalculatedRect.left <= containerRect.left) {
            newX = containerRect.left;
        }
        if (recalculatedRect.left + recalculatedRect.width >=
            containerRect.left + containerRect.width) {
            newX = containerRect.left + containerRect.width - recalculatedRect.width;
        }
        if (recalculatedRect.top <= containerRect.top) {
            newY = containerRect.top;
        }
        if (recalculatedRect.top + recalculatedRect.height >=
            containerRect.top + containerRect.height) {
            newY = containerRect.top + containerRect.height - recalculatedRect.height;
        }
    }
    return { ...recalculatedRect, x: newX, left: newX, y: newY, top: newY };
}

class BehaviorBase {
    draggable;
    dragMoveSubject = new Subject();
    dragEndSubject = new Subject();
    dragEnd$ = this.dragEndSubject.asObservable();
    destroyed$ = new ReplaySubject(1);
    dragStartPosition = {
        x: 0,
        y: 0,
    };
    isPreventingClicks = false;
    dragStartTransform = {
        x: 0,
        y: 0,
    };
    defaultOptions = {
        throttle: 0,
    };
    combinedOptions = {
        throttle: 0,
    };
    preventClickListener = this.clickPreventer.bind(this);
    constructor(draggable, options) {
        this.draggable = draggable;
        this.combinedOptions = merge({ ...this.defaultOptions }, { ...options });
        this.dragMoveSubject
            .asObservable()
            .pipe(auditTime(this.combinedOptions.throttle), takeUntil(this.destroyed$))
            .subscribe((event) => {
            this.onDragMove(event);
        });
        fromEvent(this.draggable.elementRef.nativeElement, 'mousedown')
            .pipe(takeUntilDestroyed(draggable.destroyRef))
            .subscribe((event) => {
            this.onDragStart(event);
        });
        fromEvent(this.draggable.elementRef.nativeElement, 'touchstart')
            .pipe(takeUntilDestroyed(draggable.destroyRef))
            .subscribe((event) => {
            this.onDragStart(event);
        });
    }
    onDragStart(event) {
        const viewportPoint = GetViewportPointFromEvent(event);
        this.dragStartPosition = {
            x: viewportPoint.x,
            y: viewportPoint.y,
        };
        this.dragStartTransform = GetTranslateXY(this.draggable.elementRef.nativeElement);
        this.draggable.renderer.addClass(this.draggable.document.body, 'user-select-none');
        this.draggable.renderer.addClass(this.draggable.elementRef.nativeElement, 'dragging');
        event.stopPropagation();
        if (event.defaultPrevented) {
            event.preventDefault();
        }
        this.draggable.dragStart.emit(event);
        fromEvent(this.draggable.document, 'mousemove')
            .pipe(takeUntilDestroyed(this.draggable.destroyRef), takeUntil(this.destroyed$), takeUntil(this.dragEnd$))
            .subscribe((event) => {
            event.stopPropagation();
            if (event.defaultPrevented) {
                event.preventDefault();
            }
            if (!this.isPreventingClicks) {
                this.isPreventingClicks = true;
                window.addEventListener('click', this.preventClickListener, true);
            }
            this.dragMoveSubject.next(event);
        });
        fromEvent(this.draggable.document, 'touchmove')
            .pipe(takeUntilDestroyed(this.draggable.destroyRef), takeUntil(this.destroyed$), takeUntil(this.dragEnd$))
            .subscribe((event) => {
            event.stopPropagation();
            if (event.defaultPrevented) {
                event.preventDefault();
            }
            if (!this.isPreventingClicks) {
                this.isPreventingClicks = true;
                window.addEventListener('click', this.preventClickListener, true);
            }
            this.dragMoveSubject.next(event);
        });
        fromEvent(this.draggable.document, 'mouseup')
            .pipe(takeUntilDestroyed(this.draggable.destroyRef), takeUntil(this.destroyed$), takeUntil(this.dragEnd$))
            .subscribe((event) => {
            this.onDragEnd(event);
        });
        fromEvent(this.draggable.document, 'touchend')
            .pipe(takeUntilDestroyed(this.draggable.destroyRef), takeUntil(this.destroyed$), takeUntil(this.dragEnd$))
            .subscribe((event) => {
            this.onDragEnd(event);
        });
    }
    updateTransform(value) {
        const currentTranslate = GetTranslateXY(this.draggable.elementRef.nativeElement);
        const differenceInTranslate = {
            x: value.x - currentTranslate.x,
            y: value.y - currentTranslate.y,
        };
        const movedBbox = GetTranslatedBbox(this.draggable, differenceInTranslate);
        const targetTransform = GetXyBetweenBboxes(this.draggable.getBbox(), movedBbox);
        this.moveToTarget(movedBbox);
        this.draggable.dragMove.emit({
            event: undefined,
            viewportPoint: {
                x: movedBbox.left,
                y: movedBbox.top,
            },
            targetTransform: targetTransform,
            currentTranslate: GetTranslateXY(this.draggable.elementRef.nativeElement),
        });
    }
    onDragMove(event) {
        const viewportPoint = GetViewportPointFromEvent(event);
        let delta = GetTransformDelta(this.dragStartPosition, viewportPoint);
        let translatedRect = GetTranslatedBbox(this.draggable, delta);
        const rectAfterHooks = this.runHooks(event, translatedRect);
        const targetTransform = GetXyBetweenBboxes(this.draggable.getBbox(), rectAfterHooks);
        this.moveToTarget(rectAfterHooks);
        this.draggable.dragMove.emit({
            event,
            viewportPoint,
            targetTransform: targetTransform,
            currentTranslate: GetTranslateXY(this.draggable.elementRef.nativeElement),
        });
    }
    moveToTarget(target) {
        const translateDifference = GetXyBetweenBboxes(this.draggable.getBbox(), target);
        const currentTranslate = GetTranslateXY(this.draggable.elementRef.nativeElement);
        const finalTranslate = {
            x: currentTranslate.x - translateDifference.x,
            y: currentTranslate.y - translateDifference.y,
        };
        const left = this.dragStartPosition.x - translateDifference.x;
        const top = this.dragStartPosition.y - translateDifference.y;
        this.dragStartPosition = {
            x: left,
            y: top,
        };
        this.draggable.elementRef.nativeElement.style.transform = `translateX(${finalTranslate.x}px) translateY(${finalTranslate.y}px) translateZ(0)`;
    }
    onDragEnd(event) {
        this.dragEndSubject.next();
        this.draggable.renderer.removeClass(this.draggable.elementRef.nativeElement, 'dragging');
        this.draggable.renderer.removeClass(this.draggable.document.body, 'user-select-none');
        this.draggable.dragEnd.emit(event);
        setTimeout(() => {
            this.isPreventingClicks = false;
            window.removeEventListener('click', this.preventClickListener, true);
        });
    }
    runHooks(event, targetRectangle) {
        for (const hook of this.draggable.dragMoveHooks) {
            targetRectangle = hook(this.draggable, targetRectangle, event);
        }
        return targetRectangle;
    }
    cleanUp() {
        this.destroyed$.next(true);
        this.destroyed$.complete();
        this.dragMoveSubject.complete();
        this.isPreventingClicks = false;
        window.removeEventListener('click', this.preventClickListener, true);
    }
    clickPreventer(event) {
        event.preventDefault();
        event.stopPropagation();
        return;
    }
}
class DefaultBehavior extends BehaviorBase {
    constructor(draggable, options) {
        super(draggable, options);
    }
}

class InertiaBehavior extends BehaviorBase {
    options;
    previousTimeStamp;
    lastVelocities = [];
    isDragging = false;
    constructor(draggable, options) {
        super(draggable);
        this.options = options;
    }
    onDragStart(event) {
        super.onDragStart(event);
        this.isDragging = true;
        const transform = GetTranslateXY(this.draggable.elementRef.nativeElement);
        window.requestAnimationFrame(this.calculateVelocity.bind(this, transform));
    }
    onDragEnd(event) {
        this.isDragging = false;
        super.onDragEnd(event);
        const averageVelocity = {
            x: (this.lastVelocities.reduce((acc, curr) => acc + curr.x, 0) / 5) *
                (this.options?.velocityMultiplier ?? 0.5),
            y: (this.lastVelocities.reduce((acc, curr) => acc + curr.y, 0) / 5) *
                (this.options?.velocityMultiplier ?? 0.5),
        };
        this.lastVelocities = [];
        const zero = new Date().getTime();
        window.requestAnimationFrame(this.fireInertiaMovement.bind(this, averageVelocity, zero, zero));
    }
    fireInertiaMovement(averageVelocity, zero, previousTime) {
        const currentTime = new Date().getTime();
        const timePassed = currentTime - zero;
        const timeBetweenFrames = currentTime - previousTime;
        // Calculate distance reduced by inertia - the higher the inertia the less distance is reduced
        const inertia = this.options?.inertia ?? 0.5;
        const distanceXWithoutDampening = averageVelocity.x * timeBetweenFrames;
        const distanceYWithoutDampening = averageVelocity.y * timeBetweenFrames;
        const distanceXAfterDampening = distanceXWithoutDampening * Math.exp(-(1 / inertia) * (timePassed / 100));
        const distanceYAfterDampening = distanceYWithoutDampening * Math.exp(-(1 / inertia) * (timePassed / 100));
        if (Math.abs(distanceXAfterDampening) > 0.01 &&
            Math.abs(distanceYAfterDampening) > 0.01) {
            const bbox = this.draggable.getBbox();
            const viewportPoint = {
                x: bbox.left + distanceXAfterDampening,
                y: bbox.top + distanceYAfterDampening,
            };
            const targetBboxAfterHooks = this.runHooks(undefined, GetBboxMovedToXy(bbox, viewportPoint));
            const currentTranslate = GetTranslateXY(this.draggable.elementRef.nativeElement);
            this.moveToTarget(targetBboxAfterHooks);
            window.requestAnimationFrame(this.fireInertiaMovement.bind(this, averageVelocity, zero, currentTime));
        }
    }
    calculateVelocity(previousPosition, timestamp) {
        if (!this.previousTimeStamp) {
            this.previousTimeStamp = timestamp;
        }
        else {
            const newTranslate = GetTranslateXY(this.draggable.elementRef.nativeElement);
            const currentVelocity = {
                x: (newTranslate.x - previousPosition.x) /
                    (timestamp - this.previousTimeStamp),
                y: (newTranslate.y - previousPosition.y) /
                    (timestamp - this.previousTimeStamp),
            };
            this.lastVelocities.unshift(currentVelocity);
            this.previousTimeStamp = timestamp;
            if (this.lastVelocities.length > 5) {
                this.lastVelocities.pop();
            }
        }
        if (this.isDragging) {
            window.requestAnimationFrame(this.calculateVelocity.bind(this, GetTranslateXY(this.draggable.elementRef.nativeElement)));
        }
    }
    cleanUp() {
        super.cleanUp();
        this.isDragging = false;
    }
}

class SnapBehavior extends BehaviorBase {
    options;
    ouiDraggableService;
    snappables = [];
    throttledDragMove = throttle(this.doDragMove.bind(this), 100);
    currentSnapTarget;
    constructor(draggable, options, ouiDraggableService) {
        super(draggable);
        this.options = options;
        this.ouiDraggableService = ouiDraggableService;
        this.ouiDraggableService.snappables$
            .pipe(takeUntilDestroyed(draggable.destroyRef), takeUntil(this.destroyed$), map(snappables => snappables[options.groupId]))
            .subscribe(snappables => {
            if (snappables) {
                this.snappables = Array.from(snappables).map(elementRef => elementRef.nativeElement);
            }
        });
    }
    snapToClosest() {
        const rect = this.draggable.getBbox();
        const targetElement = this.getClosestSnapTarget({
            x: rect.left,
            y: rect.top,
        });
        if (!targetElement) {
            console.error('No closest element found');
            return;
        }
        this.snapTo(targetElement);
    }
    snapTo(targetElement, event, isEventPrevented = false) {
        const draggableRect = this.draggable.getBbox();
        const snapTargetRect = targetElement.getBoundingClientRect();
        const moveTargetRect = GetBboxCenteredToAnotherBbox(draggableRect, snapTargetRect);
        const targetRectAfterHooks = this.runHooks(event, moveTargetRect);
        this.moveToTarget(targetRectAfterHooks);
        if (!isEventPrevented) {
            this.draggable.dragMove.emit({
                x: targetRectAfterHooks.x,
                y: targetRectAfterHooks.y,
                target: targetElement,
            });
        }
    }
    onDragMove(event) {
        this.throttledDragMove(event);
    }
    doDragMove(event) {
        const viewportPoint = GetViewportPointFromEvent(event);
        const targetElement = this.getClosestSnapTarget(viewportPoint);
        if (!targetElement) {
            console.error('Could not find element to snap to');
            return;
        }
        this.snapTo(targetElement, event);
    }
    getClosestSnapTarget(viewportPoint) {
        const currentDistance = getDistanceBetweenPointAndElement(viewportPoint, this.currentSnapTarget);
        const currentBbox = this.currentSnapTarget?.getBoundingClientRect();
        const closest = this.snappables.reduce((currentClosest, nextElement) => {
            const nextElementDistance = getDistanceBetweenPointAndElement(viewportPoint, nextElement);
            const isNextElementCloser = nextElementDistance < currentClosest.distance;
            if (isNextElementCloser) {
                const nextElementBbox = nextElement.getBoundingClientRect();
                return {
                    location: {
                        x: nextElementBbox.left + nextElementBbox.width / 2,
                        y: nextElementBbox.top + nextElementBbox.height / 2,
                    },
                    snapTarget: nextElement,
                    distance: nextElementDistance,
                };
            }
            else {
                return currentClosest;
            }
        }, {
            location: {
                x: currentBbox ? currentBbox?.left + currentBbox.width / 2 : 0,
                y: currentBbox ? currentBbox?.top + currentBbox.height / 2 : 0,
            },
            snapTarget: this.currentSnapTarget,
            distance: currentDistance,
        });
        this.currentSnapTarget = closest.snapTarget;
        return closest.snapTarget;
    }
}

class RubberbandBehavior extends BehaviorBase {
    options;
    startPosition;
    constructor(draggable, options) {
        super(draggable);
        this.options = options;
    }
    onDragStart(event) {
        const rect = this.draggable.elementRef.nativeElement.getBoundingClientRect();
        this.startPosition = {
            x: rect.left,
            y: rect.top,
        };
        super.onDragStart(event);
    }
    onDragEnd(event) {
        event.preventDefault();
        event.stopPropagation();
        this.draggable.elementRef.nativeElement.classList.add('no-pointer-events');
        const currentTranslate = GetTranslateXY(this.draggable.elementRef.nativeElement);
        const currentBbox = this.draggable.getBbox();
        const transformRequired = GetTransformRequiredToMoveElement(this.draggable.elementRef.nativeElement, this.startPosition);
        const targetTransform = {
            x: currentTranslate.x + transformRequired.x,
            y: currentTranslate.y + transformRequired.y,
        };
        const targetBbox = GetBboxMovedToXy(this.draggable.getBbox(), {
            x: currentBbox.left + transformRequired.x,
            y: currentBbox.top + transformRequired.y,
        });
        const distance = Math.sqrt(Math.pow(transformRequired.x, 2) + Math.pow(transformRequired.y, 2));
        const distanceMultiplier = Math.max(Math.min(1, distance / 500), 0.3);
        const duration = distanceMultiplier * (1000 / (this.options?.tightness ?? 1));
        super.onDragEnd(event);
        anime({
            targets: this.draggable.elementRef.nativeElement,
            translateX: targetTransform.x,
            translateY: targetTransform.y,
            translateZ: 0,
            duration: duration,
            easing: 'easeOutElastic(1, .3)',
            complete: anim => {
                this.draggable.elementRef.nativeElement.classList.remove('no-pointer-events');
                // To make sure some kind of bug (for example main thread getting blocked during animation for a bit)
                // doesn't cause the element to be stuck in the wrong position, we move it to the target position
                setTimeout(() => {
                    this.moveToTarget(targetBbox);
                }, 500);
            },
        });
    }
}

class OuiDraggableService {
    snappables = {};
    snappablesSubject = new BehaviorSubject({});
    snappables$ = this.snappablesSubject.asObservable();
    constructor() { }
    addSnappable(elementRef, id) {
        if (this.snappables[id]) {
            this.snappables[id].add(elementRef);
        }
        else {
            this.snappables[id] = new Set([elementRef]);
        }
        this.snappablesSubject.next(this.snappables);
    }
    removeSnappable(elementRef, id) {
        if (this.snappables[id]) {
            this.snappables[id].delete(elementRef);
        }
        if (this.snappables[id].size === 0) {
            delete this.snappables[id];
        }
        this.snappablesSubject.next(this.snappables);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDraggableService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDraggableService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDraggableService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/**
 * Axis: Defines an axis by which dragging is restricted. By default dragging works on all axis.
 * constraint: A custom constraint by which dragging is restricted. This function is triggered on every dragMove. If returning false, dragging won't work.
 * container: An element inside of which dragging is restricted.
 * containerAnchor: Whether or not elements should be restricted inside the container by their edge or by their center
 * positionHook: This hook can be used to manually adjust how the object is dragged. The parameter is where the object WOULD ordinarily be dragged,
 *               and the return-value is where it will be dragged instead.
 */
// TODO: Remove dependency to this component from oui-slider. Duplicate code if needed, as long as side-effects don't propagate
/**
 * Directive that can be used to add functionality to any element that enables them to be dragged around.
 * NOTE: EXCERCISE GREAT CARE WHEN ADJUSTING THIS COMPONENT, AS OTHER COMPONENTS LIKE oui-SLIDER DEPEND ON IT
 *
 * @Input() ouiDraggableOptions: IOuiDraggableOptions
 *   Options passed to the directive
 *
 * @Output() dragMove: EventEmitter<IDragMove>
 *   Event triggered when dragged object is moved
 * @Output() dragStart: EventEmitter<MouseEvent|TouchEvent>
 *   Event triggered when dragging starts
 * @Output() dragEnd: EventEmitter<MouseEvent|TouchEvent>
 *   Event triggered when dragging ends
 */
// TODO: Change to work so that moved distance is taken from how much the mouse has moved between last move and now
//  This will make it so that it's possible to hook into that difference, making it possible to adjust the rate of dragging etc. Now this would be basically impossible
class OuiDraggableDirective {
    elementRef;
    document;
    destroyRef;
    renderer;
    ouiDraggableService;
    dragMove = new EventEmitter();
    dragStart = new EventEmitter();
    dragEnd = new EventEmitter();
    element;
    behavior = undefined;
    currentTransform = {
        x: 0,
        y: 0,
    };
    id = GUID();
    dragMoveHooks = [];
    constructor(elementRef, document, destroyRef, renderer, ouiDraggableService) {
        this.elementRef = elementRef;
        this.document = document;
        this.destroyRef = destroyRef;
        this.renderer = renderer;
        this.ouiDraggableService = ouiDraggableService;
    }
    ngAfterViewInit() {
        const currentPosition = this.elementRef.nativeElement.style.position;
        this.elementRef.nativeElement.style.position =
            currentPosition === 'fixed' ? 'fixed' : 'absolute';
        const currentTranslate = GetTranslateXY(this.elementRef.nativeElement);
        this.elementRef.nativeElement.style.transform = `translateX(${currentTranslate.x}px) translateY(${currentTranslate.y}px)`;
        this.currentTransform = currentTranslate;
        this.element = this.elementRef.nativeElement;
        this.element.style.touchAction = 'none';
    }
    updateTransform(value) {
        if (this.behavior) {
            this.behavior.updateTransform(value);
        }
    }
    addInertiaBehavior(options) {
        this.behavior = new InertiaBehavior(this, options);
        return this.behavior;
    }
    addRubberbandBehavior(options) {
        this.behavior = new RubberbandBehavior(this, options);
        return this.behavior;
    }
    addDefaultBehavior(options) {
        this.behavior = new DefaultBehavior(this, options);
        return this.behavior;
    }
    addSnapBehavior(options) {
        this.behavior = new SnapBehavior(this, options, this.ouiDraggableService);
        return this.behavior;
    }
    addContainerConstraint(options) {
        this.dragMoveHooks.push((draggable, targetRect) => {
            return ContainerConstraint(options.container, targetRect, options.anchor);
        });
    }
    addAxisConstraint(axis) {
        this.dragMoveHooks.push((draggable, targetRect, event) => {
            const x = axis === 'x' ? targetRect.x : draggable.getBbox().x;
            const y = axis === 'y' ? targetRect.y : draggable.getBbox().y;
            return {
                ...CopyBbox(targetRect),
                x,
                y,
                left: x,
                top: y,
            };
        });
    }
    addCustomConstraint(constraint) {
        this.dragMoveHooks.push(constraint);
    }
    getBbox() {
        return this.elementRef.nativeElement.getBoundingClientRect();
    }
    click(event) {
        event.stopPropagation();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDraggableDirective, deps: [{ token: i0.ElementRef }, { token: DOCUMENT }, { token: i0.DestroyRef }, { token: i0.Renderer2 }, { token: OuiDraggableService }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.1", type: OuiDraggableDirective, isStandalone: true, selector: "[oui-draggable]", outputs: { dragMove: "dragMove", dragStart: "dragStart", dragEnd: "dragEnd" }, host: { listeners: { "click": "click($event)" } }, exportAs: ["OuiDraggableDirective"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDraggableDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[oui-draggable]',
                    standalone: true,
                    exportAs: 'OuiDraggableDirective',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: Document, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.DestroyRef }, { type: i0.Renderer2 }, { type: OuiDraggableService }], propDecorators: { dragMove: [{
                type: Output
            }], dragStart: [{
                type: Output
            }], dragEnd: [{
                type: Output
            }], click: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

class OuiSnappableDirective {
    draggableService;
    elementRef;
    ouiSnappable;
    constructor(draggableService, elementRef) {
        this.draggableService = draggableService;
        this.elementRef = elementRef;
    }
    ngAfterViewInit() {
        this.draggableService.addSnappable(this.elementRef, this.ouiSnappable);
    }
    ngOnDestroy() {
        this.draggableService.removeSnappable(this.elementRef, this.ouiSnappable);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSnappableDirective, deps: [{ token: OuiDraggableService }, { token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.1", type: OuiSnappableDirective, isStandalone: true, selector: "[ouiSnappable]", inputs: { ouiSnappable: "ouiSnappable" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSnappableDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ouiSnappable]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: OuiDraggableService }, { type: i0.ElementRef }], propDecorators: { ouiSnappable: [{
                type: Input,
                args: [{ required: true }]
            }] } });

class DraggableBehavior {
    draggable;
    constructor(draggable) {
        this.draggable = draggable;
    }
}

/**
 * Generated bundle index. Do not edit.
 */

export { CopyBbox, DraggableBehavior, GetBboxCenteredToAnotherBbox, GetBboxMovedToXy, GetElementViewportLocation, GetTransformDelta, GetTransformRequiredToMoveElement, GetTranslateXY, GetTranslatedBbox, GetViewportPointFromEvent, GetXyBetweenBboxes, OuiDraggableDirective, OuiSnappableDirective, getDistanceBetweenPointAndElement };
//# sourceMappingURL=orbital-ui-draggable.mjs.map
