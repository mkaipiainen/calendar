export * from './stop-propagation.directive';
//# sourceMappingURL=public-api.d.ts.map