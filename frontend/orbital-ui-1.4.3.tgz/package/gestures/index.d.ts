/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/gestures" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-gestures.d.ts.map