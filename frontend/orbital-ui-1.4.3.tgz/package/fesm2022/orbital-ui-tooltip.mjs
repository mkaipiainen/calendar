import * as i0 from '@angular/core';
import { Component, Input, inject, ElementRef, Renderer2, DestroyRef, input, computed, Directive } from '@angular/core';
import { OuiPopupComponent, OuiPopupService } from 'orbital-ui/popup';
import { merge, debounce } from 'lodash-es';

class OuiDefaultTooltipComponent extends OuiPopupComponent {
    content;
    constructor() {
        super();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDefaultTooltipComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiDefaultTooltipComponent, isStandalone: true, selector: "oui-default-tooltip", inputs: { content: "content" }, usesInheritance: true, ngImport: i0, template: "<div class=\"tooltip-container\">\n  <div class=\"inner-container\">\n    {{ content }}\n  </div>\n</div>\n", styles: [":host{display:flex;background-color:var(--oui-tooltip-background-color);color:var(--oui-tooltip-text-color);max-width:20rem}:host .tooltip-container{display:flex;padding:1.5rem;flex:1}:host .tooltip-container .inner-container{display:flex;flex:1;justify-content:center;text-align:center}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDefaultTooltipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-default-tooltip', standalone: true, imports: [], template: "<div class=\"tooltip-container\">\n  <div class=\"inner-container\">\n    {{ content }}\n  </div>\n</div>\n", styles: [":host{display:flex;background-color:var(--oui-tooltip-background-color);color:var(--oui-tooltip-text-color);max-width:20rem}:host .tooltip-container{display:flex;padding:1.5rem;flex:1}:host .tooltip-container .inner-container{display:flex;flex:1;justify-content:center;text-align:center}\n"] }]
        }], ctorParameters: () => [], propDecorators: { content: [{
                type: Input
            }] } });

class OuiTooltipDirective {
    elementRef = inject(ElementRef);
    renderer = inject(Renderer2);
    popupService = inject(OuiPopupService);
    destroyRef = inject(DestroyRef);
    component;
    inputs;
    isTooltipDisabled = input(false);
    tooltip = input('');
    tooltipOptions = input();
    combinedOptions = computed(() => {
        return merge({
            mode: 'hover',
            popupOptions: {
                placement: 'top',
                modifiers: [
                    {
                        name: 'arrow',
                        options: {
                            color: 'var(--color-primary)',
                            padding: 10,
                        },
                    },
                    {
                        name: 'offset',
                        options: {
                            offset: [0, 10],
                        },
                    },
                ],
            },
        }, {
            ...this.tooltipOptions(),
        });
    });
    popup;
    isHoveringOnPopup = false;
    isHoveringOnOrigin = false;
    handleDebouncedMouseLeave = debounce(this.handleMouseLeave, 100);
    constructor() { }
    ngAfterViewInit() {
        this.destroyRef.onDestroy(() => {
            this.destroyTooltip();
        });
        if (this.combinedOptions().mode === 'hover') {
            this.renderer.listen(this.elementRef.nativeElement, 'mouseenter', () => {
                this.isHoveringOnOrigin = true;
                this.createTooltip();
            });
            this.renderer.listen(this.elementRef.nativeElement, 'mouseleave', () => {
                this.isHoveringOnOrigin = false;
                this.handleDebouncedMouseLeave();
            });
        }
        else if (this.combinedOptions().mode === 'click') {
            this.renderer.listen(this.elementRef.nativeElement, 'mouseenter', () => {
                this.isHoveringOnOrigin = true;
            });
            this.renderer.listen(this.elementRef.nativeElement, 'click', () => {
                this.createTooltip();
            });
            this.renderer.listen(this.elementRef.nativeElement, 'mouseleave', () => {
                this.isHoveringOnOrigin = false;
                this.handleDebouncedMouseLeave();
            });
        }
    }
    createTooltip() {
        if (this.popup || this.isTooltipDisabled()) {
            return;
        }
        if (this.component) {
            this.popup = this.popupService.openPopup(this.component, this.inputs, this.combinedOptions().popupOptions, this.elementRef.nativeElement);
        }
        else {
            this.popup = this.popupService.openPopup(OuiDefaultTooltipComponent, {
                content: this.tooltip(),
            }, this.combinedOptions().popupOptions, this.elementRef.nativeElement);
        }
        this.renderer.listen(this.popup.popupElement, 'mouseenter', () => {
            this.isHoveringOnPopup = true;
        });
        this.renderer.listen(this.popup.popupElement, 'mouseleave', () => {
            this.isHoveringOnPopup = false;
            this.handleDebouncedMouseLeave();
        });
    }
    handleMouseLeave() {
        if (!this.isHoveringOnOrigin && !this.isHoveringOnPopup) {
            this.destroyTooltip();
        }
    }
    destroyTooltip() {
        if (this.popup) {
            this.popupService.dispose(this.popup.id);
            this.popup = undefined;
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTooltipDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "17.1.0", version: "17.3.1", type: OuiTooltipDirective, isStandalone: true, selector: "[ouiTooltip]", inputs: { component: { classPropertyName: "component", publicName: "component", isSignal: false, isRequired: false, transformFunction: null }, inputs: { classPropertyName: "inputs", publicName: "inputs", isSignal: false, isRequired: false, transformFunction: null }, isTooltipDisabled: { classPropertyName: "isTooltipDisabled", publicName: "isTooltipDisabled", isSignal: true, isRequired: false, transformFunction: null }, tooltip: { classPropertyName: "tooltip", publicName: "tooltip", isSignal: true, isRequired: false, transformFunction: null }, tooltipOptions: { classPropertyName: "tooltipOptions", publicName: "tooltipOptions", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiTooltipDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ouiTooltip]',
                    standalone: true,
                }]
        }], ctorParameters: () => [], propDecorators: { component: [{
                type: Input
            }], inputs: [{
                type: Input
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiDefaultTooltipComponent, OuiTooltipDirective };
//# sourceMappingURL=orbital-ui-tooltip.mjs.map
