import * as i0 from "@angular/core";
export declare class OuiThemeService {
    private themeSubject;
    theme$: import("rxjs").Observable<string>;
    constructor();
    changeTheme(theme: string): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiThemeService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<OuiThemeService>;
}
//# sourceMappingURL=theme.service.d.ts.map