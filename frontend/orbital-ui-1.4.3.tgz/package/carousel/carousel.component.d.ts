import { OnInit, ElementRef, AfterViewInit, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { SafeUrl } from '@angular/platform-browser';
import * as i0 from "@angular/core";
export interface IOuiSwiperOptions {
    direction?: 'horizontal' | 'vertical';
    loop?: boolean;
    scrollbar?: {
        el: string;
    };
    modules?: any[];
    speed?: number;
    initialSlide?: number;
    preventClicks?: boolean;
    preventClicksPropagation?: boolean;
    autoHeight?: boolean;
    hasNavigation?: boolean;
    hasPagination?: boolean;
}
export interface IOuiCarouselOptions {
    swiperOptions: IOuiSwiperOptions;
    showName?: boolean;
    label?: {
        placement: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left';
        color: string;
    };
    navigationStyle?: string;
    trackByKey: string;
    fileNameKey: string;
}
export interface IOuiCarouselItem {
    item: any;
    src: string | SafeUrl;
}
/**
 * A component used for showing a carousel of images. Uses swiper.js under the hood https://swiperjs.com/swiper-api.
 * If you want to add more functionality to this wrapper, you can check the swiper documentation to see
 * if it's already supported out of the box. In that case, you can just add the corresponding option to the wrapper.
 */
export declare class OuiCarouselComponent implements OnInit, AfterViewInit {
    private cdr;
    /**
     * The options passed to the carousel
     */
    options: IOuiCarouselOptions;
    /**
     * the images you want to display in the carousel
     */
    items: IOuiCarouselItem[];
    /**
     * Outputs the currently selected item
     */
    slideChange: EventEmitter<IOuiCarouselItem>;
    onLoad: EventEmitter<boolean>;
    private defaultOptions;
    swiperRef: ElementRef;
    combinedOptions: IOuiCarouselOptions;
    constructor(cdr: ChangeDetectorRef);
    ngOnInit(): void;
    swiper: any;
    ngAfterViewInit(): void;
    private onSwiperSlideChange;
    slideTo(item: IOuiCarouselItem): void;
    trackById(index: number, item: any): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiCarouselComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiCarouselComponent, "oui-carousel", never, { "options": { "alias": "options"; "required": false; }; "items": { "alias": "items"; "required": false; }; }, { "slideChange": "slideChange"; "onLoad": "onLoad"; }, never, never, true, never>;
}
//# sourceMappingURL=carousel.component.d.ts.map