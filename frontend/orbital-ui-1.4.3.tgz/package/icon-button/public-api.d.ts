export * from './icon-button.component';
//# sourceMappingURL=public-api.d.ts.map