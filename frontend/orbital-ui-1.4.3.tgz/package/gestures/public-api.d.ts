export * from './gestures.directive';
//# sourceMappingURL=public-api.d.ts.map