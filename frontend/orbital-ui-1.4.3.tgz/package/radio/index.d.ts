/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/radio" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-radio.d.ts.map