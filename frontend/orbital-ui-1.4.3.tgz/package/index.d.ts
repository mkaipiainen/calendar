/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui" />
export * from './public-api';
//# sourceMappingURL=orbital-ui.d.ts.map