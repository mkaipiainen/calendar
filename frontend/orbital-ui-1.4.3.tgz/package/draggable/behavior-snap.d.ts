import { OuiDraggableDirective } from './draggable.directive';
import { BehaviorBase } from './behavior-default';
import { IPoint } from 'orbital-ui/core';
import { ISnapBehaviorOptions } from './behavior-inertia';
import { OuiDraggableService } from './draggable.service';
export declare class SnapBehavior extends BehaviorBase {
    private options;
    private ouiDraggableService;
    private snappables;
    private throttledDragMove;
    currentSnapTarget: HTMLElement | undefined;
    constructor(draggable: OuiDraggableDirective, options: ISnapBehaviorOptions, ouiDraggableService: OuiDraggableService);
    snapToClosest(): void;
    snapTo(targetElement: HTMLElement, event?: MouseEvent | TouchEvent, isEventPrevented?: boolean): void;
    onDragMove(event: MouseEvent | TouchEvent): void;
    private doDragMove;
    getClosestSnapTarget(viewportPoint: IPoint): HTMLElement | undefined;
}
//# sourceMappingURL=behavior-snap.d.ts.map