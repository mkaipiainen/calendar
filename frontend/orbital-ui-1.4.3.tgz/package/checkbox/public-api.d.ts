export * from './checkbox.component';
//# sourceMappingURL=public-api.d.ts.map