/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/collapsible" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-collapsible.d.ts.map