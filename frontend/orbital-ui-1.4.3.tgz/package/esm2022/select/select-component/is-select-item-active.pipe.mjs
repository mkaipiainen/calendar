import { Pipe } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Pipe to output either a caret up or down depending on value
 */
export class IsSelectItemActivePipe {
    transform(item, selectedItems, idKey) {
        const isArray = Array.isArray(selectedItems);
        if (item[idKey]) {
            if (isArray) {
                return selectedItems.find((selectedItem) => selectedItem[idKey] === item[idKey]);
            }
            else {
                return selectedItems === item;
            }
        }
        else {
            if (isArray) {
                return selectedItems.find((selectedItem) => selectedItem === item);
            }
            else {
                return selectedItems === item;
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsSelectItemActivePipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "17.3.1", ngImport: i0, type: IsSelectItemActivePipe, isStandalone: true, name: "isSelectItemActive" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: IsSelectItemActivePipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'isSelectItemActive',
                    standalone: true,
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaXMtc2VsZWN0LWl0ZW0tYWN0aXZlLnBpcGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL3NlbGVjdC9zZWxlY3QtY29tcG9uZW50L2lzLXNlbGVjdC1pdGVtLWFjdGl2ZS5waXBlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxJQUFJLEVBQWlCLE1BQU0sZUFBZSxDQUFDOztBQUdwRDs7R0FFRztBQUtILE1BQU0sT0FBTyxzQkFBc0I7SUFDakMsU0FBUyxDQUFDLElBQVMsRUFBRSxhQUFrQixFQUFFLEtBQWE7UUFDcEQsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUM3QyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ2hCLElBQUksT0FBTyxFQUFFLENBQUM7Z0JBQ1osT0FBTyxhQUFhLENBQUMsSUFBSSxDQUN2QixDQUFDLFlBQWlCLEVBQUUsRUFBRSxDQUFDLFlBQVksQ0FBQyxLQUFLLENBQUMsS0FBSyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQzNELENBQUM7WUFDSixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sT0FBTyxhQUFhLEtBQUssSUFBSSxDQUFDO1lBQ2hDLENBQUM7UUFDSCxDQUFDO2FBQU0sQ0FBQztZQUNOLElBQUksT0FBTyxFQUFFLENBQUM7Z0JBQ1osT0FBTyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUMsWUFBaUIsRUFBRSxFQUFFLENBQUMsWUFBWSxLQUFLLElBQUksQ0FBQyxDQUFDO1lBQzFFLENBQUM7aUJBQU0sQ0FBQztnQkFDTixPQUFPLGFBQWEsS0FBSyxJQUFJLENBQUM7WUFDaEMsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO3VHQWxCVSxzQkFBc0I7cUdBQXRCLHNCQUFzQjs7MkZBQXRCLHNCQUFzQjtrQkFKbEMsSUFBSTttQkFBQztvQkFDSixJQUFJLEVBQUUsb0JBQW9CO29CQUMxQixVQUFVLEVBQUUsSUFBSTtpQkFDakIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQaXBlLCBQaXBlVHJhbnNmb3JtIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBpc0FycmF5IH0gZnJvbSAnbG9kYXNoLWVzJztcblxuLyoqXG4gKiBQaXBlIHRvIG91dHB1dCBlaXRoZXIgYSBjYXJldCB1cCBvciBkb3duIGRlcGVuZGluZyBvbiB2YWx1ZVxuICovXG5AUGlwZSh7XG4gIG5hbWU6ICdpc1NlbGVjdEl0ZW1BY3RpdmUnLFxuICBzdGFuZGFsb25lOiB0cnVlLFxufSlcbmV4cG9ydCBjbGFzcyBJc1NlbGVjdEl0ZW1BY3RpdmVQaXBlIGltcGxlbWVudHMgUGlwZVRyYW5zZm9ybSB7XG4gIHRyYW5zZm9ybShpdGVtOiBhbnksIHNlbGVjdGVkSXRlbXM6IGFueSwgaWRLZXk6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgIGNvbnN0IGlzQXJyYXkgPSBBcnJheS5pc0FycmF5KHNlbGVjdGVkSXRlbXMpO1xuICAgIGlmIChpdGVtW2lkS2V5XSkge1xuICAgICAgaWYgKGlzQXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIHNlbGVjdGVkSXRlbXMuZmluZChcbiAgICAgICAgICAoc2VsZWN0ZWRJdGVtOiBhbnkpID0+IHNlbGVjdGVkSXRlbVtpZEtleV0gPT09IGl0ZW1baWRLZXldXG4gICAgICAgICk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gc2VsZWN0ZWRJdGVtcyA9PT0gaXRlbTtcbiAgICAgIH1cbiAgICB9IGVsc2Uge1xuICAgICAgaWYgKGlzQXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIHNlbGVjdGVkSXRlbXMuZmluZCgoc2VsZWN0ZWRJdGVtOiBhbnkpID0+IHNlbGVjdGVkSXRlbSA9PT0gaXRlbSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gc2VsZWN0ZWRJdGVtcyA9PT0gaXRlbTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cbiJdfQ==