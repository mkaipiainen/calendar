export declare function hexToByte(hex: string): Uint8Array;
export declare function byteToHex(byteArray: Uint8Array): string;
//# sourceMappingURL=hex-byte-helper.d.ts.map