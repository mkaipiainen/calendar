/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/stop-propagation" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-stop-propagation.d.ts.map