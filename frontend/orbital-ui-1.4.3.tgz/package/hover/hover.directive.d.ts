import { AfterViewInit, DestroyRef, ElementRef, EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Can be used to add a callback on any element that's triggered by hovering on the element
 *
 * @Output() hovered: EventEmitter<any>
 *   Triggered when hovering over the object
 *
 * @Output unhovered: EventEmitter<any>
 *   Triggered when unhovering object
 */
export declare class OuiHoverDirective implements AfterViewInit {
    private elementRef;
    private destroyRef;
    hovered: EventEmitter<any>;
    unhovered: EventEmitter<any>;
    constructor(elementRef: ElementRef, destroyRef: DestroyRef);
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiHoverDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OuiHoverDirective, "[ouiHover]", never, {}, { "hovered": "hovered"; "unhovered": "unhovered"; }, never, never, true, never>;
}
//# sourceMappingURL=hover.directive.d.ts.map