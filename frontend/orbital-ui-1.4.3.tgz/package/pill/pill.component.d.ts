import { EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
/**
 * Component to add a 'pill', or a simple bordered wrapper for a value with an x-button that can be clicked to close the pill.
 */
export declare class OuiPillComponent {
    /**
     *   The label shown on the pill
     */
    label: string;
    /**
     *   A value to be shown on the pill. This can be for example used in case where you want to see the amount of items
     *   applying to a specific filter (which is named by 'label')
     */
    value: number;
    /**
     *   Triggered when x-button is clicked. You probably want to trigger an action from this that removes the pill from view.
     */
    closed: EventEmitter<boolean>;
    constructor();
    close(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiPillComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiPillComponent, "oui-pill", never, { "label": { "alias": "label"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "closed": "closed"; }, never, never, true, never>;
}
//# sourceMappingURL=pill.component.d.ts.map