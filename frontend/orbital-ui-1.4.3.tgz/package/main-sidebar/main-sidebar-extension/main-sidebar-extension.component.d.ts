import { AfterViewInit, ChangeDetectorRef, ComponentRef, DestroyRef, ElementRef, ViewContainerRef } from '@angular/core';
import { OuiMainSidebarService } from '../main-sidebar.service';
import * as i0 from "@angular/core";
/**
 * A bit of a special-usecase component to be used in conjunction with the oui-main-sidebar and oui-main-sidebar-service.
 * This can be positioned anywhere in the application, and when a subSectionComponent on the main sidebar is clicked,
 * the dynamic content defined by that subsection gets injected here, and this component expands to the width/height of the dynamic content.
 * Right now only works properly horizontally. Not super well generalized, so will probably need some tweaking to get working.
 */
export declare class OuiMainSidebarExtensionComponent implements AfterViewInit {
    private ouiMainSidebarService;
    elementRef: ElementRef;
    private cdr;
    private destroyRef;
    content: ViewContainerRef;
    isOpen: import("@angular/core").WritableSignal<boolean>;
    innerComponentRef: ComponentRef<any> | null;
    constructor(ouiMainSidebarService: OuiMainSidebarService, elementRef: ElementRef, cdr: ChangeDetectorRef, destroyRef: DestroyRef);
    ngAfterViewInit(): void;
    private close;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiMainSidebarExtensionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiMainSidebarExtensionComponent, "oui-main-sidebar-extension", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=main-sidebar-extension.component.d.ts.map