import { FeatureCollection } from '@turf/helpers';
import { Feature as OlFeature } from 'ol';
import { RGBA } from 'orbital-ui/core';
import { OpenlayersBaseLayerComponent } from './openlayers-base-layer.component';
import VectorLayer from 'ol/layer/Vector';
import VectorSource from 'ol/source/Vector';
import { OuiOpenlayersGeoJsonLayerOptions } from '../types';
import * as i0 from "@angular/core";
export declare class OpenlayersGeoJsonLayerComponent extends OpenlayersBaseLayerComponent<OuiOpenlayersGeoJsonLayerOptions> {
    options: import("@angular/core").InputSignal<OuiOpenlayersGeoJsonLayerOptions>;
    combinedOptions: import("@angular/core").Signal<{
        onClick?: ((feature: OlFeature<import("ol/geom").Geometry>) => void) | undefined;
        onHover?: ((feature: OlFeature<import("ol/geom").Geometry>) => void) | undefined;
        getCursor?: ((feature: OlFeature<import("ol/geom").Geometry>) => string) | undefined;
        id: string;
        order?: number | undefined;
        isVisible?: boolean | undefined;
        isEnabled?: boolean | undefined;
        sideBySideType?: "left" | "right" | undefined;
        data: FeatureCollection<import("@turf/helpers").Geometry, any>;
        getFillColor: RGBA | ((feature: OlFeature<import("ol/geom").Geometry>) => RGBA);
        getStrokeColor: RGBA | ((feature: OlFeature<import("ol/geom").Geometry>) => RGBA);
        getLineWidth: number | ((feature: OlFeature<import("ol/geom").Geometry>) => number);
        pointRadius?: number | undefined;
        autoHighlight: boolean;
        highlightColor: RGBA;
        filled: boolean;
        stroked: boolean;
        pickable?: boolean | undefined;
    }>;
    source: import("@angular/core").WritableSignal<VectorSource<OlFeature<import("ol/geom").Geometry>>>;
    layer: import("@angular/core").WritableSignal<VectorLayer<VectorSource<OlFeature<import("ol/geom").Geometry>>>>;
    constructor();
    private getStyleForFeature;
    onHover(feature: OlFeature): void;
    onUnHover(feature: OlFeature): void;
    updateLayer(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OpenlayersGeoJsonLayerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OpenlayersGeoJsonLayerComponent, "oui-openlayers-geojson-layer", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=openlayers-geojson-layer.component.d.ts.map