/**
 * TinyGesture.js
 *
 * This service uses passive listeners, so you can't call event.preventDefault()
 * on any of the events.
 *
 * Adapted from https://gist.github.com/SleepWalker/da5636b1abcbaff48c4d
 * and https://github.com/uxitten/xwiper
 */
import { AfterViewInit, DestroyRef, ElementRef, OnDestroy, Renderer2 } from '@angular/core';
import * as i0 from "@angular/core";
export interface IOuiGestureOptions {
    disabled?: boolean;
    swipe?: IOuiGestureSwipeOptions;
    doubleTap?: IOuiDoubleTapOptions;
    longPress?: IOuiLongPressOptions;
}
export interface IOuiGestureDefaultOptions {
    disabled: boolean;
    swipe?: IOuiGestureSwipeDefaultOptions;
    doubleTap?: IOuiDoubleTapDefaultOptions;
    longPress?: IOuiLongPressDefaultOptions;
}
export interface IOuiGestureSwipeOptions {
    velocityThreshold?: number;
    hasDiagonalSwipes?: boolean;
    diagonalLimit?: number;
    requiredSwipeDistance?: number;
    distanceToDisregardVelocity?: number;
    onSwipe: (event: IOuiGestureSwipeEvent) => void;
}
export interface IOuiGestureSwipeDefaultOptions {
    velocityThreshold: number;
    hasDiagonalSwipes: boolean;
    requiredSwipeDistance: number;
    distanceToDisregardVelocity: number;
    diagonalLimit: number;
    onSwipe: (event: IOuiGestureSwipeEvent) => void;
}
export interface IOuiGestureSwipeEvent {
    type: SwipingDirection;
    event: MouseEvent | TouchEvent;
    distanceX: number;
    distanceY: number;
    velocityX: number;
    velocityY: number;
}
export interface IOuiDoubleTapOptions {
    time: number;
    onDoubleTap: (event: MouseEvent | TouchEvent) => void;
}
export interface IOuiDoubleTapDefaultOptions {
    time: number;
    onDoubleTap: (event: MouseEvent | TouchEvent) => void;
}
export interface IOuiLongPressOptions {
    time: number;
    onLongPress: (event: MouseEvent | TouchEvent) => void;
}
export interface IOuiLongPressDefaultOptions {
    time: number;
    pressThreshold: number;
    onLongPress: (event: MouseEvent | TouchEvent) => void;
}
export type SwipingDirection = 'up' | 'down' | 'left' | 'right';
export declare class OuiGesturesDirective implements AfterViewInit, OnDestroy {
    #private;
    private renderer;
    private elementRef;
    private document;
    private destroyRef;
    set gestureOptions(options: IOuiGestureOptions);
    get gestureOptions(): IOuiGestureOptions;
    touchStartX: number | null;
    touchStartY: number | null;
    touchEndX: number | null;
    touchEndY: number | null;
    touchMoveX: number | null;
    touchMoveY: number | null;
    velocityX: number;
    velocityY: number;
    longPressTimer: any | null;
    doubleTapTimer: any | null;
    doubleTapWaiting: boolean;
    swipingHorizontal: boolean;
    swipingVertical: boolean;
    swipingDirection: SwipingDirection | null;
    swipedHorizontal: boolean;
    swipedVertical: boolean;
    unlisteners: Record<string, () => void>;
    constructor(renderer: Renderer2, elementRef: ElementRef, document: Document, destroyRef: DestroyRef);
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    onTouchStart(event: MouseEvent | TouchEvent): void;
    onTouchMove(event: MouseEvent | TouchEvent): void;
    onTouchEnd(event: MouseEvent | TouchEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiGesturesDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<OuiGesturesDirective, "[oui-gestures]", never, { "gestureOptions": { "alias": "gestureOptions"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=gestures.directive.d.ts.map