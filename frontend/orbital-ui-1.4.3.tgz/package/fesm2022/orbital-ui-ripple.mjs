import * as i0 from '@angular/core';
import { Directive } from '@angular/core';
import { fromEvent } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

/**
 * Can be used to add a ripple-element on an element when clicking on them. No options needed.
 */
class OuiRippleDirective {
    elementRef;
    renderer;
    destroyRef;
    constructor(elementRef, renderer, destroyRef) {
        this.elementRef = elementRef;
        this.renderer = renderer;
        this.destroyRef = destroyRef;
    }
    ngAfterViewInit() {
        fromEvent(this.elementRef.nativeElement, 'click')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            const parentBbox = this.elementRef.nativeElement.getBoundingClientRect();
            const rippleContainer = this.renderer.createElement('div');
            this.renderer.addClass(rippleContainer, 'oui-ripple-container');
            this.renderer.setStyle(rippleContainer, 'width', `${parentBbox.width}px`);
            this.renderer.setStyle(rippleContainer, 'position', 'absolute');
            this.renderer.setStyle(rippleContainer, 'overflow', 'hidden');
            this.renderer.setStyle(rippleContainer, 'top', '0');
            this.renderer.setStyle(rippleContainer, 'left', '0');
            this.renderer.setStyle(rippleContainer, 'pointerEvents', 'none');
            this.renderer.setStyle(rippleContainer, 'height', `${parentBbox.height}px`);
            this.renderer.setStyle(rippleContainer, 'borderRadius', getComputedStyle(this.elementRef.nativeElement).borderRadius);
            const ripple = this.renderer.createElement('div');
            this.renderer.addClass(ripple, 'oui-ripple');
            this.renderer.setStyle(this.elementRef.nativeElement, 'position', 'relative');
            const squareEdge = Math.max(parentBbox.width, parentBbox.height);
            const left = event.clientX - parentBbox.left - squareEdge / 2;
            const top = event.clientY - parentBbox.top - squareEdge / 2;
            this.renderer.setStyle(ripple, 'left', `${left}px`);
            this.renderer.setStyle(ripple, 'top', `${top}px`);
            this.renderer.setStyle(ripple, 'width', `${squareEdge}px`);
            this.renderer.setStyle(ripple, 'height', `${squareEdge}px`);
            this.renderer.setStyle(ripple, 'position', 'absolute');
            this.renderer.setStyle(ripple, 'transform', 'scale(0)');
            this.renderer.setStyle(ripple, 'borderRadius', '100%');
            this.renderer.setStyle(ripple, 'background', 'radial-gradient(circle at 50% 50%, rgba(132, 144, 171, 1) 0%, rgba(255, 210, 210, 0) 80%)');
            this.renderer.setStyle(ripple, 'transition', 'transform 1s, opacity 0.8s');
            this.renderer.setStyle(ripple, 'zIndex', '9999');
            this.renderer.setStyle(ripple, 'opacity', '1');
            this.renderer.appendChild(this.elementRef.nativeElement, rippleContainer);
            this.renderer.appendChild(rippleContainer, ripple);
            setTimeout(() => {
                this.renderer.addClass(ripple, 'oui-ripple-active');
                this.renderer.setStyle(ripple, 'transform', 'scale(2)');
                this.renderer.setStyle(ripple, 'opacity', '0');
            });
            setTimeout(() => {
                this.renderer.removeChild(rippleContainer, ripple);
                this.renderer.removeChild(this.elementRef.nativeElement, rippleContainer);
            }, 1500);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiRippleDirective, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.1", type: OuiRippleDirective, isStandalone: true, selector: "[ouiRipple]", ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiRippleDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ouiRipple]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: i0.DestroyRef }] });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiRippleDirective };
//# sourceMappingURL=orbital-ui-ripple.mjs.map
