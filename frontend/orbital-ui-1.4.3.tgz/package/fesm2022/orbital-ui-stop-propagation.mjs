import * as i0 from '@angular/core';
import { Directive, HostListener } from '@angular/core';

/**
 * Can be used to make all click-events on the element stop propagation.
 */
class ClickStopPropagationDirective {
    onClick(event) {
        event.stopPropagation();
    }
    click(event) {
        event.stopPropagation();
    }
    hover(event) {
        event.stopPropagation();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: ClickStopPropagationDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.1", type: ClickStopPropagationDirective, isStandalone: true, selector: "[oui-stop-propagation]", host: { listeners: { "onClick": "onClick($event)", "click": "click($event)", "mouseover": "hover($event)" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: ClickStopPropagationDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[oui-stop-propagation]',
                    standalone: true,
                }]
        }], propDecorators: { onClick: [{
                type: HostListener,
                args: ['onClick', ['$event']]
            }], click: [{
                type: HostListener,
                args: ['click', ['$event']]
            }], hover: [{
                type: HostListener,
                args: ['mouseover', ['$event']]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { ClickStopPropagationDirective };
//# sourceMappingURL=orbital-ui-stop-propagation.mjs.map
