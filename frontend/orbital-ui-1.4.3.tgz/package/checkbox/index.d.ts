/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/checkbox" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-checkbox.d.ts.map