import { Directive, EventEmitter, Output, } from '@angular/core';
import { fromEvent } from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import * as i0 from "@angular/core";
/**
 * Can be used to add a callback on any element that's triggered by hovering on the element
 *
 * @Output() hovered: EventEmitter<any>
 *   Triggered when hovering over the object
 *
 * @Output unhovered: EventEmitter<any>
 *   Triggered when unhovering object
 */
export class OuiHoverDirective {
    elementRef;
    destroyRef;
    hovered = new EventEmitter();
    unhovered = new EventEmitter();
    constructor(elementRef, destroyRef) {
        this.elementRef = elementRef;
        this.destroyRef = destroyRef;
    }
    ngAfterViewInit() {
        fromEvent(this.elementRef.nativeElement, 'mouseenter')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            this.hovered.emit(event);
        });
        fromEvent(this.elementRef.nativeElement, 'touchenter')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            this.hovered.emit(event);
        });
        fromEvent(this.elementRef.nativeElement, 'mouseleave')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            this.unhovered.emit(event);
        });
        fromEvent(this.elementRef.nativeElement, 'touchleave')
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe((event) => {
            this.unhovered.emit(event);
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiHoverDirective, deps: [{ token: i0.ElementRef }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "17.3.1", type: OuiHoverDirective, isStandalone: true, selector: "[ouiHover]", outputs: { hovered: "hovered", unhovered: "unhovered" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiHoverDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ouiHover]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.DestroyRef }], propDecorators: { hovered: [{
                type: Output
            }], unhovered: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaG92ZXIuZGlyZWN0aXZlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vcHJvamVjdHMvb3JiaXRhbC11aS9ob3Zlci9ob3Zlci5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUdMLFNBQVMsRUFFVCxZQUFZLEVBQ1osTUFBTSxHQUNQLE1BQU0sZUFBZSxDQUFDO0FBQ3ZCLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxNQUFNLENBQUM7QUFDakMsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sNEJBQTRCLENBQUM7O0FBRWhFOzs7Ozs7OztHQVFHO0FBS0gsTUFBTSxPQUFPLGlCQUFpQjtJQUtsQjtJQUNBO0lBTEEsT0FBTyxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7SUFDN0IsU0FBUyxHQUFHLElBQUksWUFBWSxFQUFFLENBQUM7SUFFekMsWUFDVSxVQUFzQixFQUN0QixVQUFzQjtRQUR0QixlQUFVLEdBQVYsVUFBVSxDQUFZO1FBQ3RCLGVBQVUsR0FBVixVQUFVLENBQVk7SUFDN0IsQ0FBQztJQUVHLGVBQWU7UUFDcEIsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLFlBQVksQ0FBQzthQUNuRCxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ3pDLFNBQVMsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQ3hCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLFlBQVksQ0FBQzthQUNuRCxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ3pDLFNBQVMsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQ3hCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzNCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLFlBQVksQ0FBQzthQUNuRCxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ3pDLFNBQVMsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQ3hCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzdCLENBQUMsQ0FBQyxDQUFDO1FBQ0wsU0FBUyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsYUFBYSxFQUFFLFlBQVksQ0FBQzthQUNuRCxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ3pDLFNBQVMsQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFO1lBQ3hCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzdCLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQzt1R0E5QlUsaUJBQWlCOzJGQUFqQixpQkFBaUI7OzJGQUFqQixpQkFBaUI7a0JBSjdCLFNBQVM7bUJBQUM7b0JBQ1QsUUFBUSxFQUFFLFlBQVk7b0JBQ3RCLFVBQVUsRUFBRSxJQUFJO2lCQUNqQjt3R0FFVyxPQUFPO3NCQUFoQixNQUFNO2dCQUNHLFNBQVM7c0JBQWxCLE1BQU0iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBEZXN0cm95UmVmLFxuICBEaXJlY3RpdmUsXG4gIEVsZW1lbnRSZWYsXG4gIEV2ZW50RW1pdHRlcixcbiAgT3V0cHV0LFxufSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGZyb21FdmVudCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgdGFrZVVudGlsRGVzdHJveWVkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZS9yeGpzLWludGVyb3AnO1xuXG4vKipcbiAqIENhbiBiZSB1c2VkIHRvIGFkZCBhIGNhbGxiYWNrIG9uIGFueSBlbGVtZW50IHRoYXQncyB0cmlnZ2VyZWQgYnkgaG92ZXJpbmcgb24gdGhlIGVsZW1lbnRcbiAqXG4gKiBAT3V0cHV0KCkgaG92ZXJlZDogRXZlbnRFbWl0dGVyPGFueT5cbiAqICAgVHJpZ2dlcmVkIHdoZW4gaG92ZXJpbmcgb3ZlciB0aGUgb2JqZWN0XG4gKlxuICogQE91dHB1dCB1bmhvdmVyZWQ6IEV2ZW50RW1pdHRlcjxhbnk+XG4gKiAgIFRyaWdnZXJlZCB3aGVuIHVuaG92ZXJpbmcgb2JqZWN0XG4gKi9cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ1tvdWlIb3Zlcl0nLFxuICBzdGFuZGFsb25lOiB0cnVlLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlIb3ZlckRpcmVjdGl2ZSBpbXBsZW1lbnRzIEFmdGVyVmlld0luaXQge1xuICBAT3V0cHV0KCkgaG92ZXJlZCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiAgQE91dHB1dCgpIHVuaG92ZXJlZCA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYsXG4gICAgcHJpdmF0ZSBkZXN0cm95UmVmOiBEZXN0cm95UmVmXG4gICkge31cblxuICBwdWJsaWMgbmdBZnRlclZpZXdJbml0KCkge1xuICAgIGZyb21FdmVudCh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ21vdXNlZW50ZXInKVxuICAgICAgLnBpcGUodGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZikpXG4gICAgICAuc3Vic2NyaWJlKChldmVudDogYW55KSA9PiB7XG4gICAgICAgIHRoaXMuaG92ZXJlZC5lbWl0KGV2ZW50KTtcbiAgICAgIH0pO1xuICAgIGZyb21FdmVudCh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ3RvdWNoZW50ZXInKVxuICAgICAgLnBpcGUodGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZikpXG4gICAgICAuc3Vic2NyaWJlKChldmVudDogYW55KSA9PiB7XG4gICAgICAgIHRoaXMuaG92ZXJlZC5lbWl0KGV2ZW50KTtcbiAgICAgIH0pO1xuICAgIGZyb21FdmVudCh0aGlzLmVsZW1lbnRSZWYubmF0aXZlRWxlbWVudCwgJ21vdXNlbGVhdmUnKVxuICAgICAgLnBpcGUodGFrZVVudGlsRGVzdHJveWVkKHRoaXMuZGVzdHJveVJlZikpXG4gICAgICAuc3Vic2NyaWJlKChldmVudDogYW55KSA9PiB7XG4gICAgICAgIHRoaXMudW5ob3ZlcmVkLmVtaXQoZXZlbnQpO1xuICAgICAgfSk7XG4gICAgZnJvbUV2ZW50KHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LCAndG91Y2hsZWF2ZScpXG4gICAgICAucGlwZSh0YWtlVW50aWxEZXN0cm95ZWQodGhpcy5kZXN0cm95UmVmKSlcbiAgICAgIC5zdWJzY3JpYmUoKGV2ZW50OiBhbnkpID0+IHtcbiAgICAgICAgdGhpcy51bmhvdmVyZWQuZW1pdChldmVudCk7XG4gICAgICB9KTtcbiAgfVxufVxuIl19