/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/switch" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-switch.d.ts.map