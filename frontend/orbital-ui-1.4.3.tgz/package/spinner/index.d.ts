/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="orbital-ui/spinner" />
export * from './public-api';
//# sourceMappingURL=orbital-ui-spinner.d.ts.map