import { AfterViewInit, ElementRef, ViewContainerRef } from '@angular/core';
import { OuiMainSidebarRouteSectionOptions } from './main-sidebar-route-section/main-sidebar-route-section.component';
import { OuiMainSidebarSectionOptions } from './main-sidebar.service';
import { IOuiGestureOptions } from 'orbital-ui/gestures';
import * as i0 from "@angular/core";
export type OuiMainSidebarOptions = {
    side?: 'left' | 'right' | 'top' | 'bottom';
    positioning?: 'relative' | 'absolute';
    width?: string;
    disableToggle?: boolean;
    swipeToClose?: boolean;
    hasTooltip?: boolean;
};
export type OuiMainSidebarCombinedOptions = {
    side: 'left' | 'right' | 'top' | 'bottom';
    positioning: 'relative' | 'absolute';
    width: string;
    disableToggle: boolean;
    swipeToClose: boolean;
    hasTooltip: boolean;
};
/**
 * Component to create a main-sidebar for an application. Essentially an abstraction to create a sidebar that can contain
 * other predefined components inside of it. These include either buttons that trigger routing (so links to subpages),
 * buttons that trigger simple actions, buttons that trigger an extension to the sidebar with custom content inside of it, or
 * if really desired, an entire custom component. Sidebar is currently only functional as a left-attached sidebar.
 *
 * This component really only functions as a wrapper, and actual content is added via OuiMainSidebarService.
 * In other words, this component should be only be initialised with options, and the content should be entirely managed
 * via the service. By default the sidebar is left-attached with a relative positioning and a width of 250px;
 *
 * @Input() options: IOuiMainSidebarOptions
 *
 * Example use:
 *
 *  <div class="main-container">
 *    <oui-main-header></oui-main-header>
 *    <oui-main-sidebar></oui-main-sidebar>
 *    <router-outlet></router-outlet>
 *  </div>
 */
export declare class OuiMainSidebarComponent implements AfterViewInit {
    private ouiMainSidebarService;
    private elementRef;
    private destroyRef;
    private router;
    sidebarContainer: ElementRef;
    sidebarSubsectionContainer: ElementRef;
    componentContainerVCR: ViewContainerRef;
    gestureOptions: IOuiGestureOptions;
    options: import("@angular/core").InputSignal<OuiMainSidebarOptions>;
    sections: import("@angular/core").InputSignal<OuiMainSidebarSectionOptions[]>;
    isOpen: import("@angular/core").ModelSignal<boolean>;
    private defaultOptions;
    combinedOptions: import("@angular/core").Signal<OuiMainSidebarCombinedOptions>;
    activeRouteSectionOptions: import("@angular/core").WritableSignal<OuiMainSidebarRouteSectionOptions | undefined>;
    activeRouteSectionChildren: import("@angular/core").Signal<OuiMainSidebarRouteSectionOptions[]>;
    constructor();
    toggle(): void;
    ngAfterViewInit(): void;
    private setActiveRoute;
    protected readonly MAIN_SIDEBAR_SECTION_TYPES: {
        ROUTE: string;
        SUBROUTE: string;
        ACTION: string;
        SUBSECTION: string;
    };
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiMainSidebarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiMainSidebarComponent, "oui-main-sidebar", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; "sections": { "alias": "sections"; "required": true; "isSignal": true; }; "isOpen": { "alias": "isOpen"; "required": false; "isSignal": true; }; }, { "isOpen": "isOpenChange"; }, never, never, true, never>;
}
//# sourceMappingURL=main-sidebar.component.d.ts.map