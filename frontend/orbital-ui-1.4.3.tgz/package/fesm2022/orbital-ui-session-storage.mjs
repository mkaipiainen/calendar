import * as i0 from '@angular/core';
import { Injectable } from '@angular/core';

/**
 * Service to streamline access to sessionStorage a bit, especially with JSON-objects.
 * When using this service, you don't need to manually stringify and parse javascript-objects, but it's handled automatically.
 */
class OuiSessionStorageService {
    constructor() { }
    setItem(key, value) {
        sessionStorage.setItem(key, JSON.stringify(value));
    }
    getItem(key) {
        const item = sessionStorage.getItem(key);
        if (item) {
            try {
                return JSON.parse(item);
            }
            catch (e) {
                return item;
            }
        }
        else {
            return null;
        }
    }
    removeItem(key) {
        sessionStorage.removeItem(key);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSessionStorageService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSessionStorageService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiSessionStorageService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

/**
 * Generated bundle index. Do not edit.
 */

export { OuiSessionStorageService };
//# sourceMappingURL=orbital-ui-session-storage.mjs.map
