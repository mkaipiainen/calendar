import { OuiDialogService } from './dialog.service';
import * as i0 from "@angular/core";
/**
 * A parent-component for dialogs. Not meant to be used directly, only inherited.
 */
export declare class OuiDialogComponent {
    protected ouiDialogService: OuiDialogService;
    id: string;
    constructor();
    submit(data?: any): void;
    cancel(data?: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiDialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiDialogComponent, "oui-dialog", never, {}, {}, never, never, true, never>;
}
//# sourceMappingURL=dialog.component.d.ts.map