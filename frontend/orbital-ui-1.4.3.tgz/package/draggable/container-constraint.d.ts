import { ElementRef } from '@angular/core';
export declare function ContainerConstraint(container: HTMLElement | ElementRef<any> | undefined, targetRect: DOMRect, anchor: 'center' | 'edge' | undefined): DOMRect;
//# sourceMappingURL=container-constraint.d.ts.map