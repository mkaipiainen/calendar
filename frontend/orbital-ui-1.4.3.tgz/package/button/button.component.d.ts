import { AfterViewInit, ChangeDetectorRef, DestroyRef, ElementRef, EventEmitter, OnDestroy, Renderer2 } from '@angular/core';
import { Observable } from 'rxjs';
import * as i0 from "@angular/core";
export type OuiButtonVariant = 'primary' | 'secondary' | 'warning' | 'info' | 'tertiary' | 'light' | 'dark' | 'error' | 'success' | 'muted' | 'transparent' | 'text' | 'custom';
export interface IOuiButtonOptions extends Partial<IOuiButtonCombinedOptions> {
}
/**
 * Options to pass to the button
 * @property {boolean} disabled Whether the button should be disabled
 * @property {boolean} isLoading Whether the button should be in a loading state
 * @property {Observable<any>} isLoading$ If this option is passed, button automatically goes into a loading state when clicking on it,
 * and only exits once the observable emits a value. Useful for example when a button-click does an API-call, during
 * which the button needs to be disabled.
 * @property {OuiButtonVariant} variant The variant of the button. For example 'primary' or 'secondary' or 'success. Will change the visual look of the button according to defined
 * css-variables
 * @property {boolean} submitOnEnter Whether or not button should be clicked when hitting 'enter'.
 * @property {object} spinnerOptions Options to pass to the spinner
 */
export interface IOuiButtonCombinedOptions {
    disabled: boolean;
    isLoading: boolean;
    isLoading$: Observable<any> | undefined;
    variant: OuiButtonVariant;
    type: 'button' | 'submit' | 'reset';
    submitOnEnter: boolean;
    spinnerOptions: {
        size: string;
        color: string;
    };
}
/**
 * A component that can be used to add simple buttons. The buttons are configurable by passing in a variant. You can also
 * add an icon to the button, and to show a loading-spinner in case some asynchronous operation is in progress and you want to show it.
 *
 * Example use:
 *
 * <oui-button variant="primary" (onClick)="onButtonClick($event)">Click me!</oui-button>
 *
 */
export declare class OuiButtonComponent implements AfterViewInit, OnDestroy {
    #private;
    private renderer;
    private document;
    private destroyRef;
    private cdr;
    button: ElementRef;
    set options(options: IOuiButtonOptions);
    get options(): IOuiButtonCombinedOptions;
    /**
     *   Event emitted on buttons click. Usually you want to tie a function to this event.
     */
    onClick: EventEmitter<any>;
    innerContainerRef: ElementRef;
    private isLoadingSubscription;
    isInitialized: boolean;
    private unlistener;
    constructor(renderer: Renderer2, document: Document, destroyRef: DestroyRef, cdr: ChangeDetectorRef);
    ngAfterViewInit(): void;
    private onEnterClick;
    emitClick(event: any): void;
    ngOnDestroy(): void;
    private subscribeToDisabledObservable;
    private getSpinnerOptions;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiButtonComponent, "oui-button", never, { "options": { "alias": "options"; "required": false; }; }, { "onClick": "onClick"; }, never, ["*"], true, never>;
}
//# sourceMappingURL=button.component.d.ts.map