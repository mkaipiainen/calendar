import { ChangeDetectorRef, OnChanges, SimpleChanges, TemplateRef } from '@angular/core';
import { IOuiDateRangePickerOptions } from '../date-range-picker/date-range-picker.component';
import * as i0 from "@angular/core";
export interface IOuiDateRangePickerDropdownOptions {
    datePickerOptions: IOuiDateRangePickerOptions;
    dropdownOptions?: {
        className?: string;
    };
}
export declare class OuiDateRangePickerDropdownComponent implements OnChanges {
    private cdr;
    /**
     *   The first selected date of the date-range
     */
    dateFrom: import("@angular/core").ModelSignal<Date | undefined>;
    /**
     *   The second selected date of the date-range
     */
    dateTo: import("@angular/core").ModelSignal<Date | undefined>;
    /**
     * A template consisting of presets you can pass to the calendar
     */
    presetsTemplate: TemplateRef<any>;
    /**
     * Options to be passed to the datepicker
     */
    options: IOuiDateRangePickerDropdownOptions;
    translations: {
        months: string[];
        days: string[];
    };
    constructor(cdr: ChangeDetectorRef);
    onDateFromChange(date: Date | undefined): void;
    onDateToChange(date: Date | undefined): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiDateRangePickerDropdownComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiDateRangePickerDropdownComponent, "oui-date-range-picker-dropdown", never, { "dateFrom": { "alias": "dateFrom"; "required": true; "isSignal": true; }; "dateTo": { "alias": "dateTo"; "required": true; "isSignal": true; }; "presetsTemplate": { "alias": "presetsTemplate"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, { "dateFrom": "dateFromChange"; "dateTo": "dateToChange"; }, never, never, true, never>;
}
//# sourceMappingURL=date-range-picker-dropdown.component.d.ts.map