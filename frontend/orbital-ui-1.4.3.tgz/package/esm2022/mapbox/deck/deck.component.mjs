import { ChangeDetectionStrategy, Component, computed, effect, EventEmitter, Input, Output, signal, ViewChild, } from '@angular/core';
import { Deck, WebMercatorViewport } from '@deck.gl/core/typed';
import { combineLatest, ReplaySubject, Subject } from 'rxjs';
import { LngLat, LngLatBounds } from 'mapbox-gl';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { MapboxOverlay } from '@deck.gl/mapbox/typed';
import * as i0 from "@angular/core";
export class OuiDeckComponent {
    zone;
    elementRef;
    destroyRef;
    canvas;
    set options(options) {
        this.optionsSignal.set(options);
        if (options) {
            this.optionsSubject.next(options);
        }
    }
    get options() {
        return this.optionsSignal();
    }
    map;
    isInterleaved = true;
    onLoad = new EventEmitter();
    viewStateChangeSubject = new ReplaySubject(1);
    dragStartSubject = new Subject();
    mouseDownSubject = new Subject();
    mouseUpSubject = new Subject();
    webGlContext;
    optionsSignal = signal(undefined);
    boundsSubject = new ReplaySubject(1);
    onLoadSubject = new ReplaySubject(1);
    optionsSubject = new ReplaySubject(1);
    defaultEventListeners = {
        mouseup: {
            listener: (event) => {
                const x = event.screenX;
                const y = event.screenY;
                if (this.map) {
                    const coordinates = this.map.projectXyToLngLat([x, y]);
                    const data = {
                        latitude: coordinates.lat,
                        longitude: coordinates.lng,
                        point: {
                            x,
                            y,
                        },
                        type: 'mouseup',
                        originalEvent: event,
                    };
                    this.mouseUpSubject.next(data);
                }
            },
            options: { passive: true },
        },
        mousedown: {
            listener: (event) => {
                const x = event.screenX;
                const y = event.screenY;
                if (this.map) {
                    const coordinates = this.map.projectXyToLngLat([x, y]);
                    const data = {
                        latitude: coordinates.lat,
                        longitude: coordinates.lng,
                        point: {
                            x,
                            y,
                        },
                        type: 'mousedown',
                        originalEvent: event,
                    };
                    this.mouseDownSubject.next(data);
                }
            },
            options: { passive: true },
        },
        touchstart: {
            listener: (event) => {
                const x = event.changedTouches[0].clientX;
                const y = event.changedTouches[0].clientY;
                if (this.map) {
                    const coordinates = this.map.projectXyToLngLat([x, y]);
                    const data = {
                        latitude: coordinates.lat,
                        longitude: coordinates.lng,
                        point: {
                            x,
                            y,
                        },
                        type: 'mousedown',
                        originalEvent: event,
                    };
                    this.mouseDownSubject.next(data);
                }
            },
            options: { passive: true },
        },
        touchend: {
            listener: (event) => {
                const x = event.changedTouches[0].clientX;
                const y = event.changedTouches[0].clientY;
                if (this.map) {
                    const coordinates = this.map.projectXyToLngLat([x, y]);
                    const data = {
                        latitude: coordinates.lat,
                        longitude: coordinates.lng,
                        point: {
                            x,
                            y,
                        },
                        originalEvent: event,
                        type: 'mouseup',
                    };
                    this.mouseUpSubject.next(data);
                }
            },
            options: { passive: true },
        },
    };
    hoveredLayer = signal(undefined);
    cursorState = signal({
        isDragging: false,
        isHovering: false,
    });
    cursor = computed(() => {
        if (this.hoveredLayer()) {
            return this.hoveredLayer()?.getCursor(this.cursorState());
        }
        else {
            return this.options?.getCursor
                ? this.options?.getCursor(this.cursorState())
                : this.cursorState().isDragging
                    ? 'grabbing'
                    : 'grab';
        }
    });
    layers = signal([]);
    enabledLayers = computed(() => {
        return this.layers()
            .sort((a, b) => {
            // Sort by order if both layers have an order, otherwise put the layers on top that have an order
            if (a.options?.order && b.options?.order) {
                return b.options.order - a.options.order;
            }
            else if (a.options?.order) {
                return -1;
            }
            else if (b.options?.order) {
                return 1;
            }
            else {
                return -1;
            }
        })
            .map((layer) => {
            return layer.getLayer();
        });
    });
    options$ = this.optionsSubject.asObservable();
    isDestroying = false;
    deck = signal(undefined);
    deckOverlay = signal(undefined);
    onLoad$ = this.onLoadSubject.asObservable();
    viewStateChange$ = this.viewStateChangeSubject.asObservable();
    bounds$ = this.boundsSubject.asObservable();
    dragStart$ = this.dragStartSubject.asObservable();
    mousedown$ = this.mouseDownSubject.asObservable();
    mouseup$ = this.mouseUpSubject.asObservable();
    constructor(zone, elementRef, destroyRef) {
        this.zone = zone;
        this.elementRef = elementRef;
        this.destroyRef = destroyRef;
        effect(() => {
            if (this.isDestroying) {
                return;
            }
            if (!this.deck() && !this.deckOverlay()) {
                return;
            }
            if (this.isInterleaved && this.deckOverlay()) {
                this.deckOverlay().setProps({
                    layers: this.enabledLayers(),
                });
            }
            else if (this.deck()) {
                this.deck().setProps({
                    layers: this.enabledLayers(),
                });
            }
        });
    }
    getProps() {
        if (!this.deck()) {
            console.error('Attempted to fetch deck-props before initialisation');
            return undefined;
        }
        else {
            return this.deck().props;
        }
    }
    ngAfterViewInit() {
        if (!this.map) {
            console.error('Deck-component has no map assigned to it. You are probably missing an input');
        }
        if (this.isInterleaved) {
            this.elementRef.nativeElement.classList.add('interleaved');
        }
        combineLatest([this.map.onLoad$, this.options$])
            .pipe(takeUntilDestroyed(this.destroyRef))
            .subscribe(([map, options]) => {
            if (map && options && !this.deck() && !this.deckOverlay()) {
                this.initDeck();
            }
        });
        this.destroyRef.onDestroy(() => {
            this.finalize();
        });
    }
    initDeck() {
        this.zone.runOutsideAngular(() => {
            if (!this.options || !this.map.map) {
                console.error('Attempted to initialise DeckGL without options');
                return;
            }
            const initialViewState = {
                longitude: this.options.initialViewState['longitude'] ??
                    this.map.map.getCenter().lng,
                latitude: this.options.initialViewState['latitude'] ??
                    this.map.map.getCenter().lat,
                zoom: this.options.initialViewState['zoom'] ?? this.map.map.getZoom(),
                minZoom: this.options.initialViewState?.['minZoom'] ?? 1,
                maxZoom: this.options.initialViewState?.['maxZoom'] ?? 20,
                maxPitch: 0,
            };
            if (!this.isInterleaved) {
                this.deck.set(new Deck({
                    onClick: this.options.onClick ? this.options.onClick : () => { },
                    onDrag: this.options.onDrag ? this.options?.onDrag : () => { },
                    layerFilter: this.options.layerFilter,
                    onDragStart: (info, event) => {
                        this.dragStartSubject.next({
                            info,
                            event,
                        });
                        if (this.options?.onDragStart) {
                            this.options.onDragStart(info, event);
                        }
                    },
                    onDragEnd: this.options.onDragEnd
                        ? this.options.onDragEnd
                        : () => { },
                    getCursor: state => {
                        this.cursorState.set(state);
                        return this.cursor();
                    },
                    onHover: info => {
                        if (!info.picked) {
                            this.hoveredLayer.set(undefined);
                        }
                    },
                    views: this.options.views,
                    canvas: this.canvas.nativeElement,
                    initialViewState: initialViewState,
                    onWebGLInitialized: (webGlContext) => {
                        this.webGlContext = webGlContext;
                    },
                    controller: this.options.controller || true,
                    onViewStateChange: (viewState) => {
                        this.deck().setProps({
                            initialViewState: { ...viewState.viewState, maxPitch: 0 },
                        });
                        if (!viewState.viewState) {
                            return;
                        }
                        const bounds = this.getBoundsFromViewState(viewState.viewState);
                        this.viewStateChangeSubject.next({
                            oldViewState: viewState.oldViewState,
                            viewState: viewState.viewState,
                        });
                        this.boundsSubject.next(bounds);
                        if (this.options?.onViewStateChange) {
                            this.options.onViewStateChange(viewState);
                        }
                    },
                    effects: this.options.effects ?? [],
                    onBeforeRender: () => {
                        // const viewport: any = this.deck()!.getViewports(undefined)?.[0];
                        // if (viewport && this.map.map) {
                        //   this.map.map.jumpTo({
                        //     center: [viewport.longitude, viewport.latitude],
                        //     zoom: viewport.zoom,
                        //     bearing: viewport.bearing,
                        //     pitch: viewport.pitch,
                        //   });
                        //   this.map.map.resize();
                        // }
                    },
                }));
                for (const event in this.defaultEventListeners) {
                    this.zone.run(() => {
                        this.canvas.nativeElement.addEventListener(event, this.defaultEventListeners[event].listener, this.defaultEventListeners[event].options);
                    });
                }
                if (this.options.eventListeners) {
                    for (const event in this.options.eventListeners) {
                        this.zone.run(() => {
                            this.canvas.nativeElement.addEventListener(event, this.options.eventListeners[event].listener, this.options.eventListeners[event].options);
                        });
                    }
                }
                this.emitViewStateChange();
            }
            else {
                this.deckOverlay.set(new MapboxOverlay({
                    id: 'mapbox-overlay',
                    interleaved: true,
                    layers: [...this.enabledLayers()],
                    onClick: this.options.onClick ? this.options.onClick : () => { },
                    onDrag: this.options.onDrag ? this.options?.onDrag : () => { },
                    onDragStart: this.options.onDragStart
                        ? this.options.onDragStart
                        : () => { },
                    onDragEnd: this.options.onDragEnd
                        ? this.options.onDragEnd
                        : () => { },
                    getCursor: state => {
                        this.cursorState.set(state);
                        return this.cursor();
                    },
                    onHover: info => {
                        if (!info.picked) {
                            this.hoveredLayer.set(undefined);
                        }
                    },
                    onWebGLInitialized: (webGlContext) => {
                        this.webGlContext = webGlContext;
                    },
                    effects: this.options.effects ?? [],
                }));
                this.map.map.addControl(this.deckOverlay());
            }
            this.onLoadSubject.next(this);
            this.onLoad.emit(this);
        });
    }
    addLayer(layer) {
        this.layers.update(layers => {
            return [...layers, layer];
        });
    }
    refreshLayer(layer) {
        this.layers.update(layers => {
            const index = layers.findIndex(l => l.options?.id === layer.options?.id);
            if (index === -1) {
                return layers;
            }
            layers[index] = layer;
            return [...layers];
        });
    }
    removeLayer(layer) {
        this.layers.update(layers => {
            return layers.filter(l => l.options?.id !== layer.options?.id);
        });
    }
    setHoveredLayer(layer) {
        this.hoveredLayer.set(layer);
    }
    refreshLayers() {
        if (this.deck()) {
            this.deck().setProps({
                layers: [...this.enabledLayers()],
            });
        }
        else if (this.deckOverlay()) {
            this.deckOverlay().setProps({
                layers: this.enabledLayers(),
            });
        }
        else {
            console.error('Attempted to refresh deck-layers before initialisation');
        }
    }
    getBoundsFromViewState(viewState) {
        const viewport = new WebMercatorViewport(viewState);
        const ne = viewport.unproject([viewport.width, 0]);
        const sw = viewport.unproject([0, viewport.height]);
        const newNE = new LngLat(ne[0], ne[1]).wrap();
        const newSW = new LngLat(sw[0], sw[1]).wrap();
        const bounds = new LngLatBounds(newSW, newNE);
        return bounds;
    }
    emitViewStateChange() {
        const viewState = this.deck()?.props?.viewState ?? this.deck()?.props?.initialViewState;
        this.viewStateChangeSubject.next({
            viewState: viewState,
            oldViewState: viewState,
        });
        if (!viewState) {
            return;
        }
        const bounds = this.getBoundsFromViewState(viewState);
        this.boundsSubject.next(bounds);
    }
    ngOnChanges(changes) {
        if ('options' in changes && changes.options.currentValue) {
            this.options = changes.options.currentValue;
            this.updateChangedDeckOptions(this.options);
            this.optionsSubject.next(this.options);
        }
        if ('isInterleaved' in changes) {
            if (changes.isInterleaved.currentValue) {
                this.elementRef.nativeElement.classList.add('interleaved');
            }
            else {
                this.elementRef.nativeElement.classList.remove('interleaved');
            }
        }
    }
    // Difficult to dynamically update all props - some of them can be affected by external things like mapsync
    updateChangedDeckOptions(options) {
        if (this.deck()) {
            const oldViewState = { ...this.deck().props.initialViewState };
            const newViewState = {
                ...(options.initialViewState ?? this.deck().props.initialViewState),
                maxPitch: 0,
            };
            const newOptions = {
                initialViewState: newViewState,
                effects: options.effects ?? this.deck().props.effects,
                views: options.views ?? this.deck().props.views,
                onClick: this.options?.onClick ?? this.deck().props.onClick,
                onDrag: this.options?.onDrag ?? this.deck().props.onDrag,
            };
            this.deck()?.setProps({
                ...newOptions,
            });
            this.deck().props.onViewStateChange({
                viewState: {
                    ...options.initialViewState,
                    maxPitch: 0,
                },
                oldViewState: oldViewState,
                viewId: 'default-map-view',
                interactionState: {},
            });
        }
    }
    finalize() {
        this.isDestroying = true;
        if (this.webGlContext) {
            this.webGlContext.getExtension('WEBGL_lose_context')?.loseContext();
        }
        if (this.canvas?.nativeElement) {
            this.canvas.nativeElement.replaceWith(this.canvas.nativeElement.cloneNode(true));
        }
        if (this.deck()) {
            this.deck().setProps({
                layers: [],
            });
            this.deck().finalize();
            this.deck.set(undefined);
        }
        if (this.deckOverlay()) {
            this.deckOverlay().setProps({
                layers: [],
            });
            this.deckOverlay().finalize();
        }
    }
    reinitialize() {
        this.initDeck();
    }
    ngOnDestroy() {
        this.isDestroying = true;
        // this.finalize();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDeckComponent, deps: [{ token: i0.NgZone }, { token: i0.ElementRef }, { token: i0.DestroyRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "17.3.1", type: OuiDeckComponent, isStandalone: true, selector: "oui-deck", inputs: { options: "options", map: "map", isInterleaved: "isInterleaved" }, outputs: { onLoad: "onLoad" }, viewQueries: [{ propertyName: "canvas", first: true, predicate: ["canvas"], descendants: true, static: true }], usesOnChanges: true, ngImport: i0, template: '<canvas #canvas class="deck-canvas"></canvas>', isInline: true, styles: [":host{position:absolute;top:0;left:0;height:100%;width:100%}:host.interleaved{pointer-events:none}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "17.3.1", ngImport: i0, type: OuiDeckComponent, decorators: [{
            type: Component,
            args: [{ selector: 'oui-deck', template: '<canvas #canvas class="deck-canvas"></canvas>', standalone: true, imports: [], changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{position:absolute;top:0;left:0;height:100%;width:100%}:host.interleaved{pointer-events:none}\n"] }]
        }], ctorParameters: () => [{ type: i0.NgZone }, { type: i0.ElementRef }, { type: i0.DestroyRef }], propDecorators: { canvas: [{
                type: ViewChild,
                args: ['canvas', { static: true }]
            }], options: [{
                type: Input,
                args: [{ required: true }]
            }], map: [{
                type: Input,
                args: [{ required: true }]
            }], isInterleaved: [{
                type: Input
            }], onLoad: [{
                type: Output
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVjay5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy9vcmJpdGFsLXVpL21hcGJveC9kZWNrL2RlY2suY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFFTCx1QkFBdUIsRUFDdkIsU0FBUyxFQUNULFFBQVEsRUFFUixNQUFNLEVBRU4sWUFBWSxFQUNaLEtBQUssRUFJTCxNQUFNLEVBQ04sTUFBTSxFQUVOLFNBQVMsR0FDVixNQUFNLGVBQWUsQ0FBQztBQUV2QixPQUFPLEVBQUUsSUFBSSxFQUFXLG1CQUFtQixFQUFFLE1BQU0scUJBQXFCLENBQUM7QUFXekUsT0FBTyxFQUFFLGFBQWEsRUFBRSxhQUFhLEVBQUUsT0FBTyxFQUFFLE1BQU0sTUFBTSxDQUFDO0FBQzdELE9BQU8sRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLE1BQU0sV0FBVyxDQUFDO0FBQ2pELE9BQU8sRUFBRSxrQkFBa0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDO0FBQ2hFLE9BQU8sRUFBRSxhQUFhLEVBQUUsTUFBTSx1QkFBdUIsQ0FBQzs7QUFXdEQsTUFBTSxPQUFPLGdCQUFnQjtJQWlMakI7SUFDRDtJQUNDO0lBbEw2QixNQUFNLENBQWdDO0lBRTdFLElBQStCLE9BQU8sQ0FBQyxPQUFpQztRQUN0RSxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNoQyxJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQ1osSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDcEMsQ0FBQztJQUNILENBQUM7SUFDRCxJQUFJLE9BQU87UUFDVCxPQUFPLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUM5QixDQUFDO0lBQzBCLEdBQUcsQ0FBcUI7SUFDMUMsYUFBYSxHQUFHLElBQUksQ0FBQztJQUNwQixNQUFNLEdBQUcsSUFBSSxZQUFZLEVBQW9CLENBQUM7SUFDaEQsc0JBQXNCLEdBQUcsSUFBSSxhQUFhLENBQXlCLENBQUMsQ0FBQyxDQUFDO0lBQ3RFLGdCQUFnQixHQUFHLElBQUksT0FBTyxFQUFPLENBQUM7SUFDdEMsZ0JBQWdCLEdBQUcsSUFBSSxPQUFPLEVBQWdCLENBQUM7SUFDL0MsY0FBYyxHQUFHLElBQUksT0FBTyxFQUFnQixDQUFDO0lBQzdDLFlBQVksQ0FBd0I7SUFDcEMsYUFBYSxHQUFHLE1BQU0sQ0FBMkIsU0FBUyxDQUFDLENBQUM7SUFDNUQsYUFBYSxHQUFHLElBQUksYUFBYSxDQUFlLENBQUMsQ0FBQyxDQUFDO0lBQ25ELGFBQWEsR0FBRyxJQUFJLGFBQWEsQ0FBbUIsQ0FBQyxDQUFDLENBQUM7SUFDdkQsY0FBYyxHQUFHLElBQUksYUFBYSxDQUFlLENBQUMsQ0FBQyxDQUFDO0lBQ3BELHFCQUFxQixHQVV6QjtRQUNGLE9BQU8sRUFBRTtZQUNQLFFBQVEsRUFBRSxDQUFDLEtBQVUsRUFBRSxFQUFFO2dCQUN2QixNQUFNLENBQUMsR0FBSSxLQUFvQixDQUFDLE9BQU8sQ0FBQztnQkFDeEMsTUFBTSxDQUFDLEdBQUksS0FBb0IsQ0FBQyxPQUFPLENBQUM7Z0JBQ3hDLElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO29CQUNiLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDdkQsTUFBTSxJQUFJLEdBQWlCO3dCQUN6QixRQUFRLEVBQUUsV0FBVyxDQUFDLEdBQUc7d0JBQ3pCLFNBQVMsRUFBRSxXQUFXLENBQUMsR0FBRzt3QkFDMUIsS0FBSyxFQUFFOzRCQUNMLENBQUM7NEJBQ0QsQ0FBQzt5QkFDRjt3QkFDRCxJQUFJLEVBQUUsU0FBUzt3QkFDZixhQUFhLEVBQUUsS0FBSztxQkFDckIsQ0FBQztvQkFDRixJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDakMsQ0FBQztZQUNILENBQUM7WUFDRCxPQUFPLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFO1NBQzNCO1FBQ0QsU0FBUyxFQUFFO1lBQ1QsUUFBUSxFQUFFLENBQUMsS0FBVSxFQUFFLEVBQUU7Z0JBQ3ZCLE1BQU0sQ0FBQyxHQUFJLEtBQW9CLENBQUMsT0FBTyxDQUFDO2dCQUN4QyxNQUFNLENBQUMsR0FBSSxLQUFvQixDQUFDLE9BQU8sQ0FBQztnQkFDeEMsSUFBSSxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7b0JBQ2IsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUN2RCxNQUFNLElBQUksR0FBaUI7d0JBQ3pCLFFBQVEsRUFBRSxXQUFXLENBQUMsR0FBRzt3QkFDekIsU0FBUyxFQUFFLFdBQVcsQ0FBQyxHQUFHO3dCQUMxQixLQUFLLEVBQUU7NEJBQ0wsQ0FBQzs0QkFDRCxDQUFDO3lCQUNGO3dCQUNELElBQUksRUFBRSxXQUFXO3dCQUNqQixhQUFhLEVBQUUsS0FBSztxQkFDckIsQ0FBQztvQkFDRixJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNuQyxDQUFDO1lBQ0gsQ0FBQztZQUNELE9BQU8sRUFBRSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUU7U0FDM0I7UUFDRCxVQUFVLEVBQUU7WUFDVixRQUFRLEVBQUUsQ0FBQyxLQUFVLEVBQUUsRUFBRTtnQkFDdkIsTUFBTSxDQUFDLEdBQUksS0FBb0IsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUMxRCxNQUFNLENBQUMsR0FBSSxLQUFvQixDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7Z0JBQzFELElBQUksSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO29CQUNiLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDdkQsTUFBTSxJQUFJLEdBQWlCO3dCQUN6QixRQUFRLEVBQUUsV0FBVyxDQUFDLEdBQUc7d0JBQ3pCLFNBQVMsRUFBRSxXQUFXLENBQUMsR0FBRzt3QkFDMUIsS0FBSyxFQUFFOzRCQUNMLENBQUM7NEJBQ0QsQ0FBQzt5QkFDRjt3QkFDRCxJQUFJLEVBQUUsV0FBVzt3QkFDakIsYUFBYSxFQUFFLEtBQUs7cUJBQ3JCLENBQUM7b0JBQ0YsSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztZQUNILENBQUM7WUFDRCxPQUFPLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFO1NBQzNCO1FBQ0QsUUFBUSxFQUFFO1lBQ1IsUUFBUSxFQUFFLENBQUMsS0FBVSxFQUFFLEVBQUU7Z0JBQ3ZCLE1BQU0sQ0FBQyxHQUFJLEtBQW9CLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztnQkFDMUQsTUFBTSxDQUFDLEdBQUksS0FBb0IsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUMxRCxJQUFJLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztvQkFDYixNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3ZELE1BQU0sSUFBSSxHQUFpQjt3QkFDekIsUUFBUSxFQUFFLFdBQVcsQ0FBQyxHQUFHO3dCQUN6QixTQUFTLEVBQUUsV0FBVyxDQUFDLEdBQUc7d0JBQzFCLEtBQUssRUFBRTs0QkFDTCxDQUFDOzRCQUNELENBQUM7eUJBQ0Y7d0JBQ0QsYUFBYSxFQUFFLEtBQUs7d0JBQ3BCLElBQUksRUFBRSxTQUFTO3FCQUNoQixDQUFDO29CQUNGLElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUNqQyxDQUFDO1lBQ0gsQ0FBQztZQUNELE9BQU8sRUFBRSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUU7U0FDM0I7S0FDRixDQUFDO0lBQ00sWUFBWSxHQUFHLE1BQU0sQ0FHM0IsU0FBUyxDQUFDLENBQUM7SUFDTCxXQUFXLEdBQUcsTUFBTSxDQUFjO1FBQ3hDLFVBQVUsRUFBRSxLQUFLO1FBQ2pCLFVBQVUsRUFBRSxLQUFLO0tBQ2xCLENBQUMsQ0FBQztJQUNLLE1BQU0sR0FBRyxRQUFRLENBQUMsR0FBRyxFQUFFO1FBQzdCLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFFLENBQUM7WUFDeEIsT0FBTyxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUUsU0FBUyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBVyxDQUFDO1FBQ3RFLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVM7Z0JBQzVCLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQzdDLENBQUMsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsVUFBVTtvQkFDN0IsQ0FBQyxDQUFDLFVBQVU7b0JBQ1osQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUNmLENBQUM7SUFDSCxDQUFDLENBQUMsQ0FBQztJQUNLLE1BQU0sR0FBRyxNQUFNLENBRXJCLEVBQUUsQ0FBQyxDQUFDO0lBQ0UsYUFBYSxHQUFHLFFBQVEsQ0FBQyxHQUFHLEVBQUU7UUFDcEMsT0FBTyxJQUFJLENBQUMsTUFBTSxFQUFFO2FBQ2pCLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsRUFBRTtZQUNiLGlHQUFpRztZQUNqRyxJQUFJLENBQUMsQ0FBQyxPQUFPLEVBQUUsS0FBSyxJQUFJLENBQUMsQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFLENBQUM7Z0JBQ3pDLE9BQU8sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7WUFDM0MsQ0FBQztpQkFBTSxJQUFJLENBQUMsQ0FBQyxPQUFPLEVBQUUsS0FBSyxFQUFFLENBQUM7Z0JBQzVCLE9BQU8sQ0FBQyxDQUFDLENBQUM7WUFDWixDQUFDO2lCQUFNLElBQUksQ0FBQyxDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsQ0FBQztnQkFDNUIsT0FBTyxDQUFDLENBQUM7WUFDWCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sT0FBTyxDQUFDLENBQUMsQ0FBQztZQUNaLENBQUM7UUFDSCxDQUFDLENBQUM7YUFDRCxHQUFHLENBQ0YsQ0FDRSxLQUVDLEVBQ0QsRUFBRTtZQUNGLE9BQU8sS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQzFCLENBQUMsQ0FDRixDQUFDO0lBQ04sQ0FBQyxDQUFDLENBQUM7SUFDSyxRQUFRLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUM5QyxZQUFZLEdBQUcsS0FBSyxDQUFDO0lBQ3RCLElBQUksR0FBRyxNQUFNLENBQW1CLFNBQVMsQ0FBQyxDQUFDO0lBQzNDLFdBQVcsR0FBRyxNQUFNLENBQTRCLFNBQVMsQ0FBQyxDQUFDO0lBQzNELE9BQU8sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQzVDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUM5RCxPQUFPLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUM1QyxVQUFVLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ2xELFVBQVUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDbEQsUUFBUSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxFQUFFLENBQUM7SUFDckQsWUFDVSxJQUFZLEVBQ2IsVUFBc0IsRUFDckIsVUFBc0I7UUFGdEIsU0FBSSxHQUFKLElBQUksQ0FBUTtRQUNiLGVBQVUsR0FBVixVQUFVLENBQVk7UUFDckIsZUFBVSxHQUFWLFVBQVUsQ0FBWTtRQUU5QixNQUFNLENBQUMsR0FBRyxFQUFFO1lBQ1YsSUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7Z0JBQ3RCLE9BQU87WUFDVCxDQUFDO1lBQ0QsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDO2dCQUN4QyxPQUFPO1lBQ1QsQ0FBQztZQUNELElBQUksSUFBSSxDQUFDLGFBQWEsSUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQztnQkFDN0MsSUFBSSxDQUFDLFdBQVcsRUFBRyxDQUFDLFFBQVEsQ0FBQztvQkFDM0IsTUFBTSxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUU7aUJBQzdCLENBQUMsQ0FBQztZQUNMLENBQUM7aUJBQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQztnQkFDdkIsSUFBSSxDQUFDLElBQUksRUFBRyxDQUFDLFFBQVEsQ0FBQztvQkFDcEIsTUFBTSxFQUFFLElBQUksQ0FBQyxhQUFhLEVBQUU7aUJBQzdCLENBQUMsQ0FBQztZQUNMLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxRQUFRO1FBQ2IsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDO1lBQ2pCLE9BQU8sQ0FBQyxLQUFLLENBQUMscURBQXFELENBQUMsQ0FBQztZQUNyRSxPQUFPLFNBQVMsQ0FBQztRQUNuQixDQUFDO2FBQU0sQ0FBQztZQUNOLE9BQU8sSUFBSSxDQUFDLElBQUksRUFBRyxDQUFDLEtBQUssQ0FBQztRQUM1QixDQUFDO0lBQ0gsQ0FBQztJQUVNLGVBQWU7UUFDcEIsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNkLE9BQU8sQ0FBQyxLQUFLLENBQ1gsNkVBQTZFLENBQzlFLENBQUM7UUFDSixDQUFDO1FBRUQsSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7WUFDdkIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUM3RCxDQUFDO1FBRUQsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2FBQzdDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7YUFDekMsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsT0FBTyxDQUFDLEVBQUUsRUFBRTtZQUM1QixJQUFJLEdBQUcsSUFBSSxPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEVBQUUsQ0FBQztnQkFDMUQsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ2xCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztRQUVMLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRTtZQUM3QixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDbEIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU8sUUFBUTtRQUNkLElBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsR0FBRyxFQUFFO1lBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDbkMsT0FBTyxDQUFDLEtBQUssQ0FBQyxnREFBZ0QsQ0FBQyxDQUFDO2dCQUNoRSxPQUFPO1lBQ1QsQ0FBQztZQUNELE1BQU0sZ0JBQWdCLEdBQUc7Z0JBQ3ZCLFNBQVMsRUFDUCxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQztvQkFDMUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLENBQUMsR0FBRztnQkFDOUIsUUFBUSxFQUNOLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDO29CQUN6QyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsQ0FBQyxHQUFHO2dCQUM5QixJQUFJLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsSUFBSSxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUU7Z0JBQ3JFLE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixFQUFFLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztnQkFDeEQsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFO2dCQUN6RCxRQUFRLEVBQUUsQ0FBQzthQUNaLENBQUM7WUFFRixJQUFJLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2dCQUN4QixJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FDWCxJQUFJLElBQUksQ0FBQztvQkFDUCxPQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRSxDQUFDO29CQUMvRCxNQUFNLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsR0FBRSxDQUFDO29CQUM3RCxXQUFXLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXO29CQUNyQyxXQUFXLEVBQUUsQ0FBQyxJQUFTLEVBQUUsS0FBVSxFQUFFLEVBQUU7d0JBQ3JDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUM7NEJBQ3pCLElBQUk7NEJBQ0osS0FBSzt5QkFDTixDQUFDLENBQUM7d0JBQ0gsSUFBSSxJQUFJLENBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRSxDQUFDOzRCQUM5QixJQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7d0JBQ3hDLENBQUM7b0JBQ0gsQ0FBQztvQkFDRCxTQUFTLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTO3dCQUMvQixDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTO3dCQUN4QixDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUUsQ0FBQztvQkFDWixTQUFTLEVBQUUsS0FBSyxDQUFDLEVBQUU7d0JBQ2pCLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFDO3dCQUM1QixPQUFPLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQztvQkFDdkIsQ0FBQztvQkFDRCxPQUFPLEVBQUUsSUFBSSxDQUFDLEVBQUU7d0JBQ2QsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQzs0QkFDakIsSUFBSSxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7d0JBQ25DLENBQUM7b0JBQ0gsQ0FBQztvQkFDRCxLQUFLLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFLO29CQUN6QixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhO29CQUNqQyxnQkFBZ0IsRUFBRSxnQkFBZ0I7b0JBQ2xDLGtCQUFrQixFQUFFLENBQUMsWUFBbUMsRUFBRSxFQUFFO3dCQUMxRCxJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztvQkFDbkMsQ0FBQztvQkFDRCxVQUFVLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLElBQUksSUFBSTtvQkFDM0MsaUJBQWlCLEVBQUUsQ0FDakIsU0FBeUQsRUFDekQsRUFBRTt3QkFDRixJQUFJLENBQUMsSUFBSSxFQUFHLENBQUMsUUFBUSxDQUFDOzRCQUNwQixnQkFBZ0IsRUFBRSxFQUFFLEdBQUcsU0FBUyxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsQ0FBQyxFQUFFO3lCQUMxRCxDQUFDLENBQUM7d0JBQ0gsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLEVBQUUsQ0FBQzs0QkFDekIsT0FBTzt3QkFDVCxDQUFDO3dCQUNELE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUM7d0JBQ2hFLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUM7NEJBQy9CLFlBQVksRUFBRSxTQUFTLENBQUMsWUFBWTs0QkFDcEMsU0FBUyxFQUFFLFNBQVMsQ0FBQyxTQUFTO3lCQUMvQixDQUFDLENBQUM7d0JBQ0gsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7d0JBRWhDLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxDQUFDOzRCQUNwQyxJQUFJLENBQUMsT0FBTyxDQUFDLGlCQUFpQixDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUM1QyxDQUFDO29CQUNILENBQUM7b0JBQ0QsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxJQUFJLEVBQUU7b0JBQ25DLGNBQWMsRUFBRSxHQUFHLEVBQUU7d0JBQ25CLG1FQUFtRTt3QkFDbkUsa0NBQWtDO3dCQUNsQywwQkFBMEI7d0JBQzFCLHVEQUF1RDt3QkFDdkQsMkJBQTJCO3dCQUMzQixpQ0FBaUM7d0JBQ2pDLDZCQUE2Qjt3QkFDN0IsUUFBUTt3QkFDUiwyQkFBMkI7d0JBQzNCLElBQUk7b0JBQ04sQ0FBQztpQkFDRixDQUFDLENBQ0gsQ0FBQztnQkFDRixLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxDQUFDO29CQUMvQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUU7d0JBQ2pCLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUN4QyxLQUFLLEVBQ0wsSUFBSSxDQUFDLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsRUFDMUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sQ0FDMUMsQ0FBQztvQkFDSixDQUFDLENBQUMsQ0FBQztnQkFDTCxDQUFDO2dCQUNELElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsQ0FBQztvQkFDaEMsS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLGNBQWMsRUFBRSxDQUFDO3dCQUNoRCxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUU7NEJBQ2pCLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLGdCQUFnQixDQUN4QyxLQUFLLEVBQ0wsSUFBSSxDQUFDLE9BQVEsQ0FBQyxjQUFlLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxFQUM3QyxJQUFJLENBQUMsT0FBUSxDQUFDLGNBQWUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLENBQzdDLENBQUM7d0JBQ0osQ0FBQyxDQUFDLENBQUM7b0JBQ0wsQ0FBQztnQkFDSCxDQUFDO2dCQUNELElBQUksQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1lBQzdCLENBQUM7aUJBQU0sQ0FBQztnQkFDTixJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FDbEIsSUFBSSxhQUFhLENBQUM7b0JBQ2hCLEVBQUUsRUFBRSxnQkFBZ0I7b0JBQ3BCLFdBQVcsRUFBRSxJQUFJO29CQUNqQixNQUFNLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztvQkFDakMsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUUsQ0FBQztvQkFDL0QsTUFBTSxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUUsQ0FBQztvQkFDN0QsV0FBVyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVzt3QkFDbkMsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVzt3QkFDMUIsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFFLENBQUM7b0JBQ1osU0FBUyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUzt3QkFDL0IsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUzt3QkFDeEIsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFFLENBQUM7b0JBQ1osU0FBUyxFQUFFLEtBQUssQ0FBQyxFQUFFO3dCQUNqQixJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQzt3QkFDNUIsT0FBTyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBQ3ZCLENBQUM7b0JBQ0QsT0FBTyxFQUFFLElBQUksQ0FBQyxFQUFFO3dCQUNkLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7NEJBQ2pCLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO3dCQUNuQyxDQUFDO29CQUNILENBQUM7b0JBQ0Qsa0JBQWtCLEVBQUUsQ0FBQyxZQUFtQyxFQUFFLEVBQUU7d0JBQzFELElBQUksQ0FBQyxZQUFZLEdBQUcsWUFBWSxDQUFDO29CQUNuQyxDQUFDO29CQUNELE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sSUFBSSxFQUFFO2lCQUNwQyxDQUFDLENBQ0gsQ0FBQztnQkFDRixJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBUyxDQUFDLENBQUM7WUFDckQsQ0FBQztZQUVELElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzlCLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3pCLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLFFBQVEsQ0FFYixLQUF1QjtRQUN2QixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUMxQixPQUFPLENBQUMsR0FBRyxNQUFNLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDNUIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0sWUFBWSxDQUVqQixLQUF1QjtRQUN2QixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRTtZQUMxQixNQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLEtBQUssS0FBSyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQztZQUN6RSxJQUFJLEtBQUssS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDO2dCQUNqQixPQUFPLE1BQU0sQ0FBQztZQUNoQixDQUFDO1lBQ0QsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQztZQUN0QixPQUFPLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQztRQUNyQixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxXQUFXLENBRWhCLEtBQXVCO1FBQ3ZCLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFO1lBQzFCLE9BQU8sTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRSxLQUFLLEtBQUssQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDakUsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0sZUFBZSxDQUVwQixLQUF1QjtRQUN2QixJQUFJLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUMvQixDQUFDO0lBRU0sYUFBYTtRQUNsQixJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDO1lBQ2hCLElBQUksQ0FBQyxJQUFJLEVBQUcsQ0FBQyxRQUFRLENBQUM7Z0JBQ3BCLE1BQU0sRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO2FBQ2xDLENBQUMsQ0FBQztRQUNMLENBQUM7YUFBTSxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDO1lBQzlCLElBQUksQ0FBQyxXQUFXLEVBQUcsQ0FBQyxRQUFRLENBQUM7Z0JBQzNCLE1BQU0sRUFBRSxJQUFJLENBQUMsYUFBYSxFQUFFO2FBQzdCLENBQUMsQ0FBQztRQUNMLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxDQUFDLEtBQUssQ0FBQyx3REFBd0QsQ0FBQyxDQUFDO1FBQzFFLENBQUM7SUFDSCxDQUFDO0lBRU8sc0JBQXNCLENBQUMsU0FBeUI7UUFDdEQsTUFBTSxRQUFRLEdBQUcsSUFBSSxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNwRCxNQUFNLEVBQUUsR0FBRyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ25ELE1BQU0sRUFBRSxHQUFHLFFBQVEsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7UUFFcEQsTUFBTSxLQUFLLEdBQUcsSUFBSSxNQUFNLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQzlDLE1BQU0sS0FBSyxHQUFHLElBQUksTUFBTSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUM5QyxNQUFNLE1BQU0sR0FBRyxJQUFJLFlBQVksQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDOUMsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQztJQUVPLG1CQUFtQjtRQUN6QixNQUFNLFNBQVMsR0FDYixJQUFJLENBQUMsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLFNBQVMsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLEVBQUUsS0FBSyxFQUFFLGdCQUFnQixDQUFDO1FBRXhFLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxJQUFJLENBQUM7WUFDL0IsU0FBUyxFQUFFLFNBQVM7WUFDcEIsWUFBWSxFQUFFLFNBQVM7U0FDeEIsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO1lBQ2YsT0FBTztRQUNULENBQUM7UUFDRCxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDdEQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDbEMsQ0FBQztJQUVNLFdBQVcsQ0FBQyxPQUFzQjtRQUN2QyxJQUFJLFNBQVMsSUFBSSxPQUFPLElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUN6RCxJQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDO1lBQzVDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxJQUFJLENBQUMsT0FBdUIsQ0FBQyxDQUFDO1lBQzVELElBQUksQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxPQUF1QixDQUFDLENBQUM7UUFDekQsQ0FBQztRQUNELElBQUksZUFBZSxJQUFJLE9BQU8sRUFBRSxDQUFDO1lBQy9CLElBQUksT0FBTyxDQUFDLGFBQWEsQ0FBQyxZQUFZLEVBQUUsQ0FBQztnQkFDdkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUM3RCxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sSUFBSSxDQUFDLFVBQVUsQ0FBQyxhQUFhLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUNoRSxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRCwyR0FBMkc7SUFDcEcsd0JBQXdCLENBQUMsT0FBcUI7UUFDbkQsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQztZQUNoQixNQUFNLFlBQVksR0FBRyxFQUFFLEdBQUcsSUFBSSxDQUFDLElBQUksRUFBRyxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ2hFLE1BQU0sWUFBWSxHQUFHO2dCQUNuQixHQUFHLENBQUMsT0FBTyxDQUFDLGdCQUFnQixJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUcsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUM7Z0JBQ3BFLFFBQVEsRUFBRSxDQUFDO2FBQ1osQ0FBQztZQUNGLE1BQU0sVUFBVSxHQUFpQjtnQkFDL0IsZ0JBQWdCLEVBQUUsWUFBWTtnQkFDOUIsT0FBTyxFQUFFLE9BQU8sQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLElBQUksRUFBRyxDQUFDLEtBQUssQ0FBQyxPQUFPO2dCQUN0RCxLQUFLLEVBQUUsT0FBTyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFHLENBQUMsS0FBSyxDQUFDLEtBQUs7Z0JBQ2hELE9BQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLE9BQU8sSUFBSyxJQUFJLENBQUMsSUFBSSxFQUFHLENBQUMsS0FBSyxDQUFDLE9BQWU7Z0JBQ3JFLE1BQU0sRUFBRSxJQUFJLENBQUMsT0FBTyxFQUFFLE1BQU0sSUFBSyxJQUFJLENBQUMsSUFBSSxFQUFHLENBQUMsS0FBSyxDQUFDLE1BQWM7YUFDbkUsQ0FBQztZQUNGLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxRQUFRLENBQUM7Z0JBQ3BCLEdBQUcsVUFBVTthQUNkLENBQUMsQ0FBQztZQUNILElBQUksQ0FBQyxJQUFJLEVBQUcsQ0FBQyxLQUFLLENBQUMsaUJBQWlCLENBQUM7Z0JBQ25DLFNBQVMsRUFBRTtvQkFDVCxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0I7b0JBQzNCLFFBQVEsRUFBRSxDQUFDO2lCQUNaO2dCQUNELFlBQVksRUFBRSxZQUFZO2dCQUMxQixNQUFNLEVBQUUsa0JBQWtCO2dCQUMxQixnQkFBZ0IsRUFBRSxFQUFFO2FBQ3JCLENBQUMsQ0FBQztRQUNMLENBQUM7SUFDSCxDQUFDO0lBRU0sUUFBUTtRQUNiLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1FBQ3pCLElBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDO1lBQ3RCLElBQUksQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDLG9CQUFvQixDQUFDLEVBQUUsV0FBVyxFQUFFLENBQUM7UUFDdEUsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLE1BQU0sRUFBRSxhQUFhLEVBQUUsQ0FBQztZQUMvQixJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWEsQ0FBQyxXQUFXLENBQ25DLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FDMUMsQ0FBQztRQUNKLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDO1lBQ2hCLElBQUksQ0FBQyxJQUFJLEVBQUcsQ0FBQyxRQUFRLENBQUM7Z0JBQ3BCLE1BQU0sRUFBRSxFQUFFO2FBQ1gsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLElBQUksRUFBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ3hCLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzNCLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxXQUFXLEVBQUcsQ0FBQyxRQUFRLENBQUM7Z0JBQzNCLE1BQU0sRUFBRSxFQUFFO2FBQ1gsQ0FBQyxDQUFDO1lBQ0gsSUFBSSxDQUFDLFdBQVcsRUFBRyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ2pDLENBQUM7SUFDSCxDQUFDO0lBRU0sWUFBWTtRQUNqQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDbEIsQ0FBQztJQUVNLFdBQVc7UUFDaEIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUM7UUFDekIsbUJBQW1CO0lBQ3JCLENBQUM7dUdBbmhCVSxnQkFBZ0I7MkZBQWhCLGdCQUFnQixvVEFOakIsK0NBQStDOzsyRkFNOUMsZ0JBQWdCO2tCQVI1QixTQUFTOytCQUNFLFVBQVUsWUFDViwrQ0FBK0MsY0FDN0MsSUFBSSxXQUVQLEVBQUUsbUJBQ00sdUJBQXVCLENBQUMsTUFBTTs2SEFHUixNQUFNO3NCQUE1QyxTQUFTO3VCQUFDLFFBQVEsRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUU7Z0JBRU4sT0FBTztzQkFBckMsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUU7Z0JBU0UsR0FBRztzQkFBN0IsS0FBSzt1QkFBQyxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUU7Z0JBQ2hCLGFBQWE7c0JBQXJCLEtBQUs7Z0JBQ0ksTUFBTTtzQkFBZixNQUFNIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtcbiAgQWZ0ZXJWaWV3SW5pdCxcbiAgQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3ksXG4gIENvbXBvbmVudCxcbiAgY29tcHV0ZWQsXG4gIERlc3Ryb3lSZWYsXG4gIGVmZmVjdCxcbiAgRWxlbWVudFJlZixcbiAgRXZlbnRFbWl0dGVyLFxuICBJbnB1dCxcbiAgTmdab25lLFxuICBPbkNoYW5nZXMsXG4gIE9uRGVzdHJveSxcbiAgT3V0cHV0LFxuICBzaWduYWwsXG4gIFNpbXBsZUNoYW5nZXMsXG4gIFZpZXdDaGlsZCxcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBCYXNlRGVja0xheWVyIH0gZnJvbSAnLi4vYmFzZS1kZWNrLWxheWVyLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBEZWNrLCBNYXBWaWV3LCBXZWJNZXJjYXRvclZpZXdwb3J0IH0gZnJvbSAnQGRlY2suZ2wvY29yZS90eXBlZCc7XG5pbXBvcnQgeyBWaWV3U3RhdGVDaGFuZ2VQYXJhbWV0ZXJzIH0gZnJvbSAnQGRlY2suZ2wvY29yZS90eXBlZC9jb250cm9sbGVycy9jb250cm9sbGVyJztcbmltcG9ydCB7XG4gIEN1cnNvclN0YXRlLFxuICBJQ29tbW9uRGVja0xheWVyT3B0aW9ucyxcbiAgSURlY2tPcHRpb25zLFxuICBJRGVja1ZpZXdTdGF0ZSxcbiAgSU1vdXNlVXBEb3duLFxuICBJTWFwYm94Vmlld1N0YXRlQ2hhbmdlLFxuICBJU2xpbUNvbW1vbkRlY2tMYXllck9wdGlvbnMsXG59IGZyb20gJy4uL3R5cGluZ3MnO1xuaW1wb3J0IHsgY29tYmluZUxhdGVzdCwgUmVwbGF5U3ViamVjdCwgU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHsgTG5nTGF0LCBMbmdMYXRCb3VuZHMgfSBmcm9tICdtYXBib3gtZ2wnO1xuaW1wb3J0IHsgdGFrZVVudGlsRGVzdHJveWVkIH0gZnJvbSAnQGFuZ3VsYXIvY29yZS9yeGpzLWludGVyb3AnO1xuaW1wb3J0IHsgTWFwYm94T3ZlcmxheSB9IGZyb20gJ0BkZWNrLmdsL21hcGJveC90eXBlZCc7XG5pbXBvcnQgeyBEZWNrTWVhc3VyZUxheWVyIH0gZnJvbSAnLi4vbWVhc3VyaW5nLWxheWVyL2RlY2stbWVhc3VyZS1sYXllcic7XG5pbXBvcnQgeyBPdWlNYXBib3hDb21wb25lbnQgfSBmcm9tICcuLi9tYXBib3guY29tcG9uZW50JztcbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ291aS1kZWNrJyxcbiAgdGVtcGxhdGU6ICc8Y2FudmFzICNjYW52YXMgY2xhc3M9XCJkZWNrLWNhbnZhc1wiPjwvY2FudmFzPicsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHN0eWxlVXJsczogWycuL2RlY2suY29tcG9uZW50LnNjc3MnXSxcbiAgaW1wb3J0czogW10sXG4gIGNoYW5nZURldGVjdGlvbjogQ2hhbmdlRGV0ZWN0aW9uU3RyYXRlZ3kuT25QdXNoLFxufSlcbmV4cG9ydCBjbGFzcyBPdWlEZWNrQ29tcG9uZW50IGltcGxlbWVudHMgQWZ0ZXJWaWV3SW5pdCwgT25DaGFuZ2VzLCBPbkRlc3Ryb3kge1xuICBAVmlld0NoaWxkKCdjYW52YXMnLCB7IHN0YXRpYzogdHJ1ZSB9KSBjYW52YXM6IEVsZW1lbnRSZWY8SFRNTENhbnZhc0VsZW1lbnQ+O1xuXG4gIEBJbnB1dCh7IHJlcXVpcmVkOiB0cnVlIH0pIHNldCBvcHRpb25zKG9wdGlvbnM6IElEZWNrT3B0aW9ucyB8IHVuZGVmaW5lZCkge1xuICAgIHRoaXMub3B0aW9uc1NpZ25hbC5zZXQob3B0aW9ucyk7XG4gICAgaWYgKG9wdGlvbnMpIHtcbiAgICAgIHRoaXMub3B0aW9uc1N1YmplY3QubmV4dChvcHRpb25zKTtcbiAgICB9XG4gIH1cbiAgZ2V0IG9wdGlvbnMoKTogSURlY2tPcHRpb25zIHwgdW5kZWZpbmVkIHtcbiAgICByZXR1cm4gdGhpcy5vcHRpb25zU2lnbmFsKCk7XG4gIH1cbiAgQElucHV0KHsgcmVxdWlyZWQ6IHRydWUgfSkgbWFwOiBPdWlNYXBib3hDb21wb25lbnQ7XG4gIEBJbnB1dCgpIGlzSW50ZXJsZWF2ZWQgPSB0cnVlO1xuICBAT3V0cHV0KCkgb25Mb2FkID0gbmV3IEV2ZW50RW1pdHRlcjxPdWlEZWNrQ29tcG9uZW50PigpO1xuICBwcml2YXRlIHZpZXdTdGF0ZUNoYW5nZVN1YmplY3QgPSBuZXcgUmVwbGF5U3ViamVjdDxJTWFwYm94Vmlld1N0YXRlQ2hhbmdlPigxKTtcbiAgcHJpdmF0ZSBkcmFnU3RhcnRTdWJqZWN0ID0gbmV3IFN1YmplY3Q8YW55PigpO1xuICBwcml2YXRlIG1vdXNlRG93blN1YmplY3QgPSBuZXcgU3ViamVjdDxJTW91c2VVcERvd24+KCk7XG4gIHByaXZhdGUgbW91c2VVcFN1YmplY3QgPSBuZXcgU3ViamVjdDxJTW91c2VVcERvd24+KCk7XG4gIHByaXZhdGUgd2ViR2xDb250ZXh0OiBXZWJHTFJlbmRlcmluZ0NvbnRleHQ7XG4gIHByaXZhdGUgb3B0aW9uc1NpZ25hbCA9IHNpZ25hbDxJRGVja09wdGlvbnMgfCB1bmRlZmluZWQ+KHVuZGVmaW5lZCk7XG4gIHByaXZhdGUgYm91bmRzU3ViamVjdCA9IG5ldyBSZXBsYXlTdWJqZWN0PExuZ0xhdEJvdW5kcz4oMSk7XG4gIHByaXZhdGUgb25Mb2FkU3ViamVjdCA9IG5ldyBSZXBsYXlTdWJqZWN0PE91aURlY2tDb21wb25lbnQ+KDEpO1xuICBwcml2YXRlIG9wdGlvbnNTdWJqZWN0ID0gbmV3IFJlcGxheVN1YmplY3Q8SURlY2tPcHRpb25zPigxKTtcbiAgcHJpdmF0ZSBkZWZhdWx0RXZlbnRMaXN0ZW5lcnM6IHtcbiAgICBbZXZlbnQ6IHN0cmluZ106IHtcbiAgICAgIGxpc3RlbmVyOiAoZXZlbnQ6IHVua25vd24pID0+IHZvaWQ7XG4gICAgICBvcHRpb25zPzoge1xuICAgICAgICBjYXB0dXJlPzogYm9vbGVhbjtcbiAgICAgICAgb25jZT86IGJvb2xlYW47XG4gICAgICAgIHBhc3NpdmU/OiBib29sZWFuO1xuICAgICAgICBzaWduYWw/OiBBYm9ydFNpZ25hbDtcbiAgICAgIH07XG4gICAgfTtcbiAgfSA9IHtcbiAgICBtb3VzZXVwOiB7XG4gICAgICBsaXN0ZW5lcjogKGV2ZW50OiBhbnkpID0+IHtcbiAgICAgICAgY29uc3QgeCA9IChldmVudCBhcyBNb3VzZUV2ZW50KS5zY3JlZW5YO1xuICAgICAgICBjb25zdCB5ID0gKGV2ZW50IGFzIE1vdXNlRXZlbnQpLnNjcmVlblk7XG4gICAgICAgIGlmICh0aGlzLm1hcCkge1xuICAgICAgICAgIGNvbnN0IGNvb3JkaW5hdGVzID0gdGhpcy5tYXAucHJvamVjdFh5VG9MbmdMYXQoW3gsIHldKTtcbiAgICAgICAgICBjb25zdCBkYXRhOiBJTW91c2VVcERvd24gPSB7XG4gICAgICAgICAgICBsYXRpdHVkZTogY29vcmRpbmF0ZXMubGF0LFxuICAgICAgICAgICAgbG9uZ2l0dWRlOiBjb29yZGluYXRlcy5sbmcsXG4gICAgICAgICAgICBwb2ludDoge1xuICAgICAgICAgICAgICB4LFxuICAgICAgICAgICAgICB5LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHR5cGU6ICdtb3VzZXVwJyxcbiAgICAgICAgICAgIG9yaWdpbmFsRXZlbnQ6IGV2ZW50LFxuICAgICAgICAgIH07XG4gICAgICAgICAgdGhpcy5tb3VzZVVwU3ViamVjdC5uZXh0KGRhdGEpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgb3B0aW9uczogeyBwYXNzaXZlOiB0cnVlIH0sXG4gICAgfSxcbiAgICBtb3VzZWRvd246IHtcbiAgICAgIGxpc3RlbmVyOiAoZXZlbnQ6IGFueSkgPT4ge1xuICAgICAgICBjb25zdCB4ID0gKGV2ZW50IGFzIE1vdXNlRXZlbnQpLnNjcmVlblg7XG4gICAgICAgIGNvbnN0IHkgPSAoZXZlbnQgYXMgTW91c2VFdmVudCkuc2NyZWVuWTtcbiAgICAgICAgaWYgKHRoaXMubWFwKSB7XG4gICAgICAgICAgY29uc3QgY29vcmRpbmF0ZXMgPSB0aGlzLm1hcC5wcm9qZWN0WHlUb0xuZ0xhdChbeCwgeV0pO1xuICAgICAgICAgIGNvbnN0IGRhdGE6IElNb3VzZVVwRG93biA9IHtcbiAgICAgICAgICAgIGxhdGl0dWRlOiBjb29yZGluYXRlcy5sYXQsXG4gICAgICAgICAgICBsb25naXR1ZGU6IGNvb3JkaW5hdGVzLmxuZyxcbiAgICAgICAgICAgIHBvaW50OiB7XG4gICAgICAgICAgICAgIHgsXG4gICAgICAgICAgICAgIHksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgdHlwZTogJ21vdXNlZG93bicsXG4gICAgICAgICAgICBvcmlnaW5hbEV2ZW50OiBldmVudCxcbiAgICAgICAgICB9O1xuICAgICAgICAgIHRoaXMubW91c2VEb3duU3ViamVjdC5uZXh0KGRhdGEpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgb3B0aW9uczogeyBwYXNzaXZlOiB0cnVlIH0sXG4gICAgfSxcbiAgICB0b3VjaHN0YXJ0OiB7XG4gICAgICBsaXN0ZW5lcjogKGV2ZW50OiBhbnkpID0+IHtcbiAgICAgICAgY29uc3QgeCA9IChldmVudCBhcyBUb3VjaEV2ZW50KS5jaGFuZ2VkVG91Y2hlc1swXS5jbGllbnRYO1xuICAgICAgICBjb25zdCB5ID0gKGV2ZW50IGFzIFRvdWNoRXZlbnQpLmNoYW5nZWRUb3VjaGVzWzBdLmNsaWVudFk7XG4gICAgICAgIGlmICh0aGlzLm1hcCkge1xuICAgICAgICAgIGNvbnN0IGNvb3JkaW5hdGVzID0gdGhpcy5tYXAucHJvamVjdFh5VG9MbmdMYXQoW3gsIHldKTtcbiAgICAgICAgICBjb25zdCBkYXRhOiBJTW91c2VVcERvd24gPSB7XG4gICAgICAgICAgICBsYXRpdHVkZTogY29vcmRpbmF0ZXMubGF0LFxuICAgICAgICAgICAgbG9uZ2l0dWRlOiBjb29yZGluYXRlcy5sbmcsXG4gICAgICAgICAgICBwb2ludDoge1xuICAgICAgICAgICAgICB4LFxuICAgICAgICAgICAgICB5LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHR5cGU6ICdtb3VzZWRvd24nLFxuICAgICAgICAgICAgb3JpZ2luYWxFdmVudDogZXZlbnQsXG4gICAgICAgICAgfTtcbiAgICAgICAgICB0aGlzLm1vdXNlRG93blN1YmplY3QubmV4dChkYXRhKTtcbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIG9wdGlvbnM6IHsgcGFzc2l2ZTogdHJ1ZSB9LFxuICAgIH0sXG4gICAgdG91Y2hlbmQ6IHtcbiAgICAgIGxpc3RlbmVyOiAoZXZlbnQ6IGFueSkgPT4ge1xuICAgICAgICBjb25zdCB4ID0gKGV2ZW50IGFzIFRvdWNoRXZlbnQpLmNoYW5nZWRUb3VjaGVzWzBdLmNsaWVudFg7XG4gICAgICAgIGNvbnN0IHkgPSAoZXZlbnQgYXMgVG91Y2hFdmVudCkuY2hhbmdlZFRvdWNoZXNbMF0uY2xpZW50WTtcbiAgICAgICAgaWYgKHRoaXMubWFwKSB7XG4gICAgICAgICAgY29uc3QgY29vcmRpbmF0ZXMgPSB0aGlzLm1hcC5wcm9qZWN0WHlUb0xuZ0xhdChbeCwgeV0pO1xuICAgICAgICAgIGNvbnN0IGRhdGE6IElNb3VzZVVwRG93biA9IHtcbiAgICAgICAgICAgIGxhdGl0dWRlOiBjb29yZGluYXRlcy5sYXQsXG4gICAgICAgICAgICBsb25naXR1ZGU6IGNvb3JkaW5hdGVzLmxuZyxcbiAgICAgICAgICAgIHBvaW50OiB7XG4gICAgICAgICAgICAgIHgsXG4gICAgICAgICAgICAgIHksXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgb3JpZ2luYWxFdmVudDogZXZlbnQsXG4gICAgICAgICAgICB0eXBlOiAnbW91c2V1cCcsXG4gICAgICAgICAgfTtcbiAgICAgICAgICB0aGlzLm1vdXNlVXBTdWJqZWN0Lm5leHQoZGF0YSk7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBvcHRpb25zOiB7IHBhc3NpdmU6IHRydWUgfSxcbiAgICB9LFxuICB9O1xuICBwcml2YXRlIGhvdmVyZWRMYXllciA9IHNpZ25hbDxcbiAgICB8IHVuZGVmaW5lZFxuICAgIHwgQmFzZURlY2tMYXllcjxJQ29tbW9uRGVja0xheWVyT3B0aW9ucyB8IElTbGltQ29tbW9uRGVja0xheWVyT3B0aW9ucz5cbiAgPih1bmRlZmluZWQpO1xuICBwcml2YXRlIGN1cnNvclN0YXRlID0gc2lnbmFsPEN1cnNvclN0YXRlPih7XG4gICAgaXNEcmFnZ2luZzogZmFsc2UsXG4gICAgaXNIb3ZlcmluZzogZmFsc2UsXG4gIH0pO1xuICBwcml2YXRlIGN1cnNvciA9IGNvbXB1dGVkKCgpID0+IHtcbiAgICBpZiAodGhpcy5ob3ZlcmVkTGF5ZXIoKSkge1xuICAgICAgcmV0dXJuIHRoaXMuaG92ZXJlZExheWVyKCk/LmdldEN1cnNvcih0aGlzLmN1cnNvclN0YXRlKCkpIGFzIHN0cmluZztcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIHRoaXMub3B0aW9ucz8uZ2V0Q3Vyc29yXG4gICAgICAgID8gdGhpcy5vcHRpb25zPy5nZXRDdXJzb3IodGhpcy5jdXJzb3JTdGF0ZSgpKVxuICAgICAgICA6IHRoaXMuY3Vyc29yU3RhdGUoKS5pc0RyYWdnaW5nXG4gICAgICAgICAgPyAnZ3JhYmJpbmcnXG4gICAgICAgICAgOiAnZ3JhYic7XG4gICAgfVxuICB9KTtcbiAgcHJpdmF0ZSBsYXllcnMgPSBzaWduYWw8XG4gICAgQmFzZURlY2tMYXllcjxJQ29tbW9uRGVja0xheWVyT3B0aW9ucyB8IElTbGltQ29tbW9uRGVja0xheWVyT3B0aW9ucz5bXVxuICA+KFtdKTtcbiAgcHJpdmF0ZSBlbmFibGVkTGF5ZXJzID0gY29tcHV0ZWQoKCkgPT4ge1xuICAgIHJldHVybiB0aGlzLmxheWVycygpXG4gICAgICAuc29ydCgoYSwgYikgPT4ge1xuICAgICAgICAvLyBTb3J0IGJ5IG9yZGVyIGlmIGJvdGggbGF5ZXJzIGhhdmUgYW4gb3JkZXIsIG90aGVyd2lzZSBwdXQgdGhlIGxheWVycyBvbiB0b3AgdGhhdCBoYXZlIGFuIG9yZGVyXG4gICAgICAgIGlmIChhLm9wdGlvbnM/Lm9yZGVyICYmIGIub3B0aW9ucz8ub3JkZXIpIHtcbiAgICAgICAgICByZXR1cm4gYi5vcHRpb25zLm9yZGVyIC0gYS5vcHRpb25zLm9yZGVyO1xuICAgICAgICB9IGVsc2UgaWYgKGEub3B0aW9ucz8ub3JkZXIpIHtcbiAgICAgICAgICByZXR1cm4gLTE7XG4gICAgICAgIH0gZWxzZSBpZiAoYi5vcHRpb25zPy5vcmRlcikge1xuICAgICAgICAgIHJldHVybiAxO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJldHVybiAtMTtcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICAgIC5tYXAoXG4gICAgICAgIChcbiAgICAgICAgICBsYXllcjogQmFzZURlY2tMYXllcjxcbiAgICAgICAgICAgIElDb21tb25EZWNrTGF5ZXJPcHRpb25zIHwgSVNsaW1Db21tb25EZWNrTGF5ZXJPcHRpb25zXG4gICAgICAgICAgPlxuICAgICAgICApID0+IHtcbiAgICAgICAgICByZXR1cm4gbGF5ZXIuZ2V0TGF5ZXIoKTtcbiAgICAgICAgfVxuICAgICAgKTtcbiAgfSk7XG4gIHByaXZhdGUgb3B0aW9ucyQgPSB0aGlzLm9wdGlvbnNTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuICBwcml2YXRlIGlzRGVzdHJveWluZyA9IGZhbHNlO1xuICBwdWJsaWMgZGVjayA9IHNpZ25hbDxEZWNrIHwgdW5kZWZpbmVkPih1bmRlZmluZWQpO1xuICBwdWJsaWMgZGVja092ZXJsYXkgPSBzaWduYWw8TWFwYm94T3ZlcmxheSB8IHVuZGVmaW5lZD4odW5kZWZpbmVkKTtcbiAgcHVibGljIG9uTG9hZCQgPSB0aGlzLm9uTG9hZFN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XG4gIHB1YmxpYyB2aWV3U3RhdGVDaGFuZ2UkID0gdGhpcy52aWV3U3RhdGVDaGFuZ2VTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuICBwdWJsaWMgYm91bmRzJCA9IHRoaXMuYm91bmRzU3ViamVjdC5hc09ic2VydmFibGUoKTtcbiAgcHVibGljIGRyYWdTdGFydCQgPSB0aGlzLmRyYWdTdGFydFN1YmplY3QuYXNPYnNlcnZhYmxlKCk7XG4gIHB1YmxpYyBtb3VzZWRvd24kID0gdGhpcy5tb3VzZURvd25TdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuICBwdWJsaWMgbW91c2V1cCQgPSB0aGlzLm1vdXNlVXBTdWJqZWN0LmFzT2JzZXJ2YWJsZSgpO1xuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHpvbmU6IE5nWm9uZSxcbiAgICBwdWJsaWMgZWxlbWVudFJlZjogRWxlbWVudFJlZixcbiAgICBwcml2YXRlIGRlc3Ryb3lSZWY6IERlc3Ryb3lSZWZcbiAgKSB7XG4gICAgZWZmZWN0KCgpID0+IHtcbiAgICAgIGlmICh0aGlzLmlzRGVzdHJveWluZykge1xuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICBpZiAoIXRoaXMuZGVjaygpICYmICF0aGlzLmRlY2tPdmVybGF5KCkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMuaXNJbnRlcmxlYXZlZCAmJiB0aGlzLmRlY2tPdmVybGF5KCkpIHtcbiAgICAgICAgdGhpcy5kZWNrT3ZlcmxheSgpIS5zZXRQcm9wcyh7XG4gICAgICAgICAgbGF5ZXJzOiB0aGlzLmVuYWJsZWRMYXllcnMoKSxcbiAgICAgICAgfSk7XG4gICAgICB9IGVsc2UgaWYgKHRoaXMuZGVjaygpKSB7XG4gICAgICAgIHRoaXMuZGVjaygpIS5zZXRQcm9wcyh7XG4gICAgICAgICAgbGF5ZXJzOiB0aGlzLmVuYWJsZWRMYXllcnMoKSxcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgZ2V0UHJvcHMoKSB7XG4gICAgaWYgKCF0aGlzLmRlY2soKSkge1xuICAgICAgY29uc29sZS5lcnJvcignQXR0ZW1wdGVkIHRvIGZldGNoIGRlY2stcHJvcHMgYmVmb3JlIGluaXRpYWxpc2F0aW9uJyk7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gdGhpcy5kZWNrKCkhLnByb3BzO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBuZ0FmdGVyVmlld0luaXQoKSB7XG4gICAgaWYgKCF0aGlzLm1hcCkge1xuICAgICAgY29uc29sZS5lcnJvcihcbiAgICAgICAgJ0RlY2stY29tcG9uZW50IGhhcyBubyBtYXAgYXNzaWduZWQgdG8gaXQuIFlvdSBhcmUgcHJvYmFibHkgbWlzc2luZyBhbiBpbnB1dCdcbiAgICAgICk7XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuaXNJbnRlcmxlYXZlZCkge1xuICAgICAgdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnaW50ZXJsZWF2ZWQnKTtcbiAgICB9XG5cbiAgICBjb21iaW5lTGF0ZXN0KFt0aGlzLm1hcC5vbkxvYWQkLCB0aGlzLm9wdGlvbnMkXSlcbiAgICAgIC5waXBlKHRha2VVbnRpbERlc3Ryb3llZCh0aGlzLmRlc3Ryb3lSZWYpKVxuICAgICAgLnN1YnNjcmliZSgoW21hcCwgb3B0aW9uc10pID0+IHtcbiAgICAgICAgaWYgKG1hcCAmJiBvcHRpb25zICYmICF0aGlzLmRlY2soKSAmJiAhdGhpcy5kZWNrT3ZlcmxheSgpKSB7XG4gICAgICAgICAgdGhpcy5pbml0RGVjaygpO1xuICAgICAgICB9XG4gICAgICB9KTtcblxuICAgIHRoaXMuZGVzdHJveVJlZi5vbkRlc3Ryb3koKCkgPT4ge1xuICAgICAgdGhpcy5maW5hbGl6ZSgpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBpbml0RGVjaygpIHtcbiAgICB0aGlzLnpvbmUucnVuT3V0c2lkZUFuZ3VsYXIoKCkgPT4ge1xuICAgICAgaWYgKCF0aGlzLm9wdGlvbnMgfHwgIXRoaXMubWFwLm1hcCkge1xuICAgICAgICBjb25zb2xlLmVycm9yKCdBdHRlbXB0ZWQgdG8gaW5pdGlhbGlzZSBEZWNrR0wgd2l0aG91dCBvcHRpb25zJyk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGluaXRpYWxWaWV3U3RhdGUgPSB7XG4gICAgICAgIGxvbmdpdHVkZTpcbiAgICAgICAgICB0aGlzLm9wdGlvbnMuaW5pdGlhbFZpZXdTdGF0ZVsnbG9uZ2l0dWRlJ10gPz9cbiAgICAgICAgICB0aGlzLm1hcC5tYXAuZ2V0Q2VudGVyKCkubG5nLFxuICAgICAgICBsYXRpdHVkZTpcbiAgICAgICAgICB0aGlzLm9wdGlvbnMuaW5pdGlhbFZpZXdTdGF0ZVsnbGF0aXR1ZGUnXSA/P1xuICAgICAgICAgIHRoaXMubWFwLm1hcC5nZXRDZW50ZXIoKS5sYXQsXG4gICAgICAgIHpvb206IHRoaXMub3B0aW9ucy5pbml0aWFsVmlld1N0YXRlWyd6b29tJ10gPz8gdGhpcy5tYXAubWFwLmdldFpvb20oKSxcbiAgICAgICAgbWluWm9vbTogdGhpcy5vcHRpb25zLmluaXRpYWxWaWV3U3RhdGU/LlsnbWluWm9vbSddID8/IDEsXG4gICAgICAgIG1heFpvb206IHRoaXMub3B0aW9ucy5pbml0aWFsVmlld1N0YXRlPy5bJ21heFpvb20nXSA/PyAyMCxcbiAgICAgICAgbWF4UGl0Y2g6IDAsXG4gICAgICB9O1xuXG4gICAgICBpZiAoIXRoaXMuaXNJbnRlcmxlYXZlZCkge1xuICAgICAgICB0aGlzLmRlY2suc2V0KFxuICAgICAgICAgIG5ldyBEZWNrKHtcbiAgICAgICAgICAgIG9uQ2xpY2s6IHRoaXMub3B0aW9ucy5vbkNsaWNrID8gdGhpcy5vcHRpb25zLm9uQ2xpY2sgOiAoKSA9PiB7fSxcbiAgICAgICAgICAgIG9uRHJhZzogdGhpcy5vcHRpb25zLm9uRHJhZyA/IHRoaXMub3B0aW9ucz8ub25EcmFnIDogKCkgPT4ge30sXG4gICAgICAgICAgICBsYXllckZpbHRlcjogdGhpcy5vcHRpb25zLmxheWVyRmlsdGVyLFxuICAgICAgICAgICAgb25EcmFnU3RhcnQ6IChpbmZvOiBhbnksIGV2ZW50OiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgdGhpcy5kcmFnU3RhcnRTdWJqZWN0Lm5leHQoe1xuICAgICAgICAgICAgICAgIGluZm8sXG4gICAgICAgICAgICAgICAgZXZlbnQsXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICBpZiAodGhpcy5vcHRpb25zPy5vbkRyYWdTdGFydCkge1xuICAgICAgICAgICAgICAgIHRoaXMub3B0aW9ucy5vbkRyYWdTdGFydChpbmZvLCBldmVudCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvbkRyYWdFbmQ6IHRoaXMub3B0aW9ucy5vbkRyYWdFbmRcbiAgICAgICAgICAgICAgPyB0aGlzLm9wdGlvbnMub25EcmFnRW5kXG4gICAgICAgICAgICAgIDogKCkgPT4ge30sXG4gICAgICAgICAgICBnZXRDdXJzb3I6IHN0YXRlID0+IHtcbiAgICAgICAgICAgICAgdGhpcy5jdXJzb3JTdGF0ZS5zZXQoc3RhdGUpO1xuICAgICAgICAgICAgICByZXR1cm4gdGhpcy5jdXJzb3IoKTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBvbkhvdmVyOiBpbmZvID0+IHtcbiAgICAgICAgICAgICAgaWYgKCFpbmZvLnBpY2tlZCkge1xuICAgICAgICAgICAgICAgIHRoaXMuaG92ZXJlZExheWVyLnNldCh1bmRlZmluZWQpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgdmlld3M6IHRoaXMub3B0aW9ucy52aWV3cyxcbiAgICAgICAgICAgIGNhbnZhczogdGhpcy5jYW52YXMubmF0aXZlRWxlbWVudCxcbiAgICAgICAgICAgIGluaXRpYWxWaWV3U3RhdGU6IGluaXRpYWxWaWV3U3RhdGUsXG4gICAgICAgICAgICBvbldlYkdMSW5pdGlhbGl6ZWQ6ICh3ZWJHbENvbnRleHQ6IFdlYkdMUmVuZGVyaW5nQ29udGV4dCkgPT4ge1xuICAgICAgICAgICAgICB0aGlzLndlYkdsQ29udGV4dCA9IHdlYkdsQ29udGV4dDtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBjb250cm9sbGVyOiB0aGlzLm9wdGlvbnMuY29udHJvbGxlciB8fCB0cnVlLFxuICAgICAgICAgICAgb25WaWV3U3RhdGVDaGFuZ2U6IChcbiAgICAgICAgICAgICAgdmlld1N0YXRlOiBWaWV3U3RhdGVDaGFuZ2VQYXJhbWV0ZXJzICYgeyB2aWV3SWQ6IHN0cmluZyB9XG4gICAgICAgICAgICApID0+IHtcbiAgICAgICAgICAgICAgdGhpcy5kZWNrKCkhLnNldFByb3BzKHtcbiAgICAgICAgICAgICAgICBpbml0aWFsVmlld1N0YXRlOiB7IC4uLnZpZXdTdGF0ZS52aWV3U3RhdGUsIG1heFBpdGNoOiAwIH0sXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICBpZiAoIXZpZXdTdGF0ZS52aWV3U3RhdGUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgY29uc3QgYm91bmRzID0gdGhpcy5nZXRCb3VuZHNGcm9tVmlld1N0YXRlKHZpZXdTdGF0ZS52aWV3U3RhdGUpO1xuICAgICAgICAgICAgICB0aGlzLnZpZXdTdGF0ZUNoYW5nZVN1YmplY3QubmV4dCh7XG4gICAgICAgICAgICAgICAgb2xkVmlld1N0YXRlOiB2aWV3U3RhdGUub2xkVmlld1N0YXRlLFxuICAgICAgICAgICAgICAgIHZpZXdTdGF0ZTogdmlld1N0YXRlLnZpZXdTdGF0ZSxcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIHRoaXMuYm91bmRzU3ViamVjdC5uZXh0KGJvdW5kcyk7XG5cbiAgICAgICAgICAgICAgaWYgKHRoaXMub3B0aW9ucz8ub25WaWV3U3RhdGVDaGFuZ2UpIHtcbiAgICAgICAgICAgICAgICB0aGlzLm9wdGlvbnMub25WaWV3U3RhdGVDaGFuZ2Uodmlld1N0YXRlKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVmZmVjdHM6IHRoaXMub3B0aW9ucy5lZmZlY3RzID8/IFtdLFxuICAgICAgICAgICAgb25CZWZvcmVSZW5kZXI6ICgpID0+IHtcbiAgICAgICAgICAgICAgLy8gY29uc3Qgdmlld3BvcnQ6IGFueSA9IHRoaXMuZGVjaygpIS5nZXRWaWV3cG9ydHModW5kZWZpbmVkKT8uWzBdO1xuICAgICAgICAgICAgICAvLyBpZiAodmlld3BvcnQgJiYgdGhpcy5tYXAubWFwKSB7XG4gICAgICAgICAgICAgIC8vICAgdGhpcy5tYXAubWFwLmp1bXBUbyh7XG4gICAgICAgICAgICAgIC8vICAgICBjZW50ZXI6IFt2aWV3cG9ydC5sb25naXR1ZGUsIHZpZXdwb3J0LmxhdGl0dWRlXSxcbiAgICAgICAgICAgICAgLy8gICAgIHpvb206IHZpZXdwb3J0Lnpvb20sXG4gICAgICAgICAgICAgIC8vICAgICBiZWFyaW5nOiB2aWV3cG9ydC5iZWFyaW5nLFxuICAgICAgICAgICAgICAvLyAgICAgcGl0Y2g6IHZpZXdwb3J0LnBpdGNoLFxuICAgICAgICAgICAgICAvLyAgIH0pO1xuICAgICAgICAgICAgICAvLyAgIHRoaXMubWFwLm1hcC5yZXNpemUoKTtcbiAgICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9KVxuICAgICAgICApO1xuICAgICAgICBmb3IgKGNvbnN0IGV2ZW50IGluIHRoaXMuZGVmYXVsdEV2ZW50TGlzdGVuZXJzKSB7XG4gICAgICAgICAgdGhpcy56b25lLnJ1bigoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmNhbnZhcy5uYXRpdmVFbGVtZW50LmFkZEV2ZW50TGlzdGVuZXIoXG4gICAgICAgICAgICAgIGV2ZW50LFxuICAgICAgICAgICAgICB0aGlzLmRlZmF1bHRFdmVudExpc3RlbmVyc1tldmVudF0ubGlzdGVuZXIsXG4gICAgICAgICAgICAgIHRoaXMuZGVmYXVsdEV2ZW50TGlzdGVuZXJzW2V2ZW50XS5vcHRpb25zXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0aGlzLm9wdGlvbnMuZXZlbnRMaXN0ZW5lcnMpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IGV2ZW50IGluIHRoaXMub3B0aW9ucy5ldmVudExpc3RlbmVycykge1xuICAgICAgICAgICAgdGhpcy56b25lLnJ1bigoKSA9PiB7XG4gICAgICAgICAgICAgIHRoaXMuY2FudmFzLm5hdGl2ZUVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcbiAgICAgICAgICAgICAgICBldmVudCxcbiAgICAgICAgICAgICAgICB0aGlzLm9wdGlvbnMhLmV2ZW50TGlzdGVuZXJzIVtldmVudF0ubGlzdGVuZXIsXG4gICAgICAgICAgICAgICAgdGhpcy5vcHRpb25zIS5ldmVudExpc3RlbmVycyFbZXZlbnRdLm9wdGlvbnNcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB0aGlzLmVtaXRWaWV3U3RhdGVDaGFuZ2UoKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuZGVja092ZXJsYXkuc2V0KFxuICAgICAgICAgIG5ldyBNYXBib3hPdmVybGF5KHtcbiAgICAgICAgICAgIGlkOiAnbWFwYm94LW92ZXJsYXknLFxuICAgICAgICAgICAgaW50ZXJsZWF2ZWQ6IHRydWUsXG4gICAgICAgICAgICBsYXllcnM6IFsuLi50aGlzLmVuYWJsZWRMYXllcnMoKV0sXG4gICAgICAgICAgICBvbkNsaWNrOiB0aGlzLm9wdGlvbnMub25DbGljayA/IHRoaXMub3B0aW9ucy5vbkNsaWNrIDogKCkgPT4ge30sXG4gICAgICAgICAgICBvbkRyYWc6IHRoaXMub3B0aW9ucy5vbkRyYWcgPyB0aGlzLm9wdGlvbnM/Lm9uRHJhZyA6ICgpID0+IHt9LFxuICAgICAgICAgICAgb25EcmFnU3RhcnQ6IHRoaXMub3B0aW9ucy5vbkRyYWdTdGFydFxuICAgICAgICAgICAgICA/IHRoaXMub3B0aW9ucy5vbkRyYWdTdGFydFxuICAgICAgICAgICAgICA6ICgpID0+IHt9LFxuICAgICAgICAgICAgb25EcmFnRW5kOiB0aGlzLm9wdGlvbnMub25EcmFnRW5kXG4gICAgICAgICAgICAgID8gdGhpcy5vcHRpb25zLm9uRHJhZ0VuZFxuICAgICAgICAgICAgICA6ICgpID0+IHt9LFxuICAgICAgICAgICAgZ2V0Q3Vyc29yOiBzdGF0ZSA9PiB7XG4gICAgICAgICAgICAgIHRoaXMuY3Vyc29yU3RhdGUuc2V0KHN0YXRlKTtcbiAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuY3Vyc29yKCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgb25Ib3ZlcjogaW5mbyA9PiB7XG4gICAgICAgICAgICAgIGlmICghaW5mby5waWNrZWQpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmhvdmVyZWRMYXllci5zZXQodW5kZWZpbmVkKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIG9uV2ViR0xJbml0aWFsaXplZDogKHdlYkdsQ29udGV4dDogV2ViR0xSZW5kZXJpbmdDb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAgIHRoaXMud2ViR2xDb250ZXh0ID0gd2ViR2xDb250ZXh0O1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGVmZmVjdHM6IHRoaXMub3B0aW9ucy5lZmZlY3RzID8/IFtdLFxuICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgICAgIHRoaXMubWFwLm1hcC5hZGRDb250cm9sKHRoaXMuZGVja092ZXJsYXkoKSBhcyBhbnkpO1xuICAgICAgfVxuXG4gICAgICB0aGlzLm9uTG9hZFN1YmplY3QubmV4dCh0aGlzKTtcbiAgICAgIHRoaXMub25Mb2FkLmVtaXQodGhpcyk7XG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgYWRkTGF5ZXI8XG4gICAgVCBleHRlbmRzIElTbGltQ29tbW9uRGVja0xheWVyT3B0aW9ucyB8IElDb21tb25EZWNrTGF5ZXJPcHRpb25zLFxuICA+KGxheWVyOiBCYXNlRGVja0xheWVyPFQ+KSB7XG4gICAgdGhpcy5sYXllcnMudXBkYXRlKGxheWVycyA9PiB7XG4gICAgICByZXR1cm4gWy4uLmxheWVycywgbGF5ZXJdO1xuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIHJlZnJlc2hMYXllcjxcbiAgICBUIGV4dGVuZHMgSVNsaW1Db21tb25EZWNrTGF5ZXJPcHRpb25zIHwgSUNvbW1vbkRlY2tMYXllck9wdGlvbnMsXG4gID4obGF5ZXI6IEJhc2VEZWNrTGF5ZXI8VD4pIHtcbiAgICB0aGlzLmxheWVycy51cGRhdGUobGF5ZXJzID0+IHtcbiAgICAgIGNvbnN0IGluZGV4ID0gbGF5ZXJzLmZpbmRJbmRleChsID0+IGwub3B0aW9ucz8uaWQgPT09IGxheWVyLm9wdGlvbnM/LmlkKTtcbiAgICAgIGlmIChpbmRleCA9PT0gLTEpIHtcbiAgICAgICAgcmV0dXJuIGxheWVycztcbiAgICAgIH1cbiAgICAgIGxheWVyc1tpbmRleF0gPSBsYXllcjtcbiAgICAgIHJldHVybiBbLi4ubGF5ZXJzXTtcbiAgICB9KTtcbiAgfVxuXG4gIHB1YmxpYyByZW1vdmVMYXllcjxcbiAgICBUIGV4dGVuZHMgSVNsaW1Db21tb25EZWNrTGF5ZXJPcHRpb25zIHwgSUNvbW1vbkRlY2tMYXllck9wdGlvbnMsXG4gID4obGF5ZXI6IEJhc2VEZWNrTGF5ZXI8VD4pIHtcbiAgICB0aGlzLmxheWVycy51cGRhdGUobGF5ZXJzID0+IHtcbiAgICAgIHJldHVybiBsYXllcnMuZmlsdGVyKGwgPT4gbC5vcHRpb25zPy5pZCAhPT0gbGF5ZXIub3B0aW9ucz8uaWQpO1xuICAgIH0pO1xuICB9XG5cbiAgcHVibGljIHNldEhvdmVyZWRMYXllcjxcbiAgICBUIGV4dGVuZHMgSVNsaW1Db21tb25EZWNrTGF5ZXJPcHRpb25zIHwgSUNvbW1vbkRlY2tMYXllck9wdGlvbnMsXG4gID4obGF5ZXI6IEJhc2VEZWNrTGF5ZXI8VD4pIHtcbiAgICB0aGlzLmhvdmVyZWRMYXllci5zZXQobGF5ZXIpO1xuICB9XG5cbiAgcHVibGljIHJlZnJlc2hMYXllcnMoKSB7XG4gICAgaWYgKHRoaXMuZGVjaygpKSB7XG4gICAgICB0aGlzLmRlY2soKSEuc2V0UHJvcHMoe1xuICAgICAgICBsYXllcnM6IFsuLi50aGlzLmVuYWJsZWRMYXllcnMoKV0sXG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKHRoaXMuZGVja092ZXJsYXkoKSkge1xuICAgICAgdGhpcy5kZWNrT3ZlcmxheSgpIS5zZXRQcm9wcyh7XG4gICAgICAgIGxheWVyczogdGhpcy5lbmFibGVkTGF5ZXJzKCksXG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgY29uc29sZS5lcnJvcignQXR0ZW1wdGVkIHRvIHJlZnJlc2ggZGVjay1sYXllcnMgYmVmb3JlIGluaXRpYWxpc2F0aW9uJyk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBnZXRCb3VuZHNGcm9tVmlld1N0YXRlKHZpZXdTdGF0ZTogSURlY2tWaWV3U3RhdGUpOiBMbmdMYXRCb3VuZHMge1xuICAgIGNvbnN0IHZpZXdwb3J0ID0gbmV3IFdlYk1lcmNhdG9yVmlld3BvcnQodmlld1N0YXRlKTtcbiAgICBjb25zdCBuZSA9IHZpZXdwb3J0LnVucHJvamVjdChbdmlld3BvcnQud2lkdGgsIDBdKTtcbiAgICBjb25zdCBzdyA9IHZpZXdwb3J0LnVucHJvamVjdChbMCwgdmlld3BvcnQuaGVpZ2h0XSk7XG5cbiAgICBjb25zdCBuZXdORSA9IG5ldyBMbmdMYXQobmVbMF0sIG5lWzFdKS53cmFwKCk7XG4gICAgY29uc3QgbmV3U1cgPSBuZXcgTG5nTGF0KHN3WzBdLCBzd1sxXSkud3JhcCgpO1xuICAgIGNvbnN0IGJvdW5kcyA9IG5ldyBMbmdMYXRCb3VuZHMobmV3U1csIG5ld05FKTtcbiAgICByZXR1cm4gYm91bmRzO1xuICB9XG5cbiAgcHJpdmF0ZSBlbWl0Vmlld1N0YXRlQ2hhbmdlKCkge1xuICAgIGNvbnN0IHZpZXdTdGF0ZSA9XG4gICAgICB0aGlzLmRlY2soKT8ucHJvcHM/LnZpZXdTdGF0ZSA/PyB0aGlzLmRlY2soKT8ucHJvcHM/LmluaXRpYWxWaWV3U3RhdGU7XG5cbiAgICB0aGlzLnZpZXdTdGF0ZUNoYW5nZVN1YmplY3QubmV4dCh7XG4gICAgICB2aWV3U3RhdGU6IHZpZXdTdGF0ZSxcbiAgICAgIG9sZFZpZXdTdGF0ZTogdmlld1N0YXRlLFxuICAgIH0pO1xuICAgIGlmICghdmlld1N0YXRlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGJvdW5kcyA9IHRoaXMuZ2V0Qm91bmRzRnJvbVZpZXdTdGF0ZSh2aWV3U3RhdGUpO1xuICAgIHRoaXMuYm91bmRzU3ViamVjdC5uZXh0KGJvdW5kcyk7XG4gIH1cblxuICBwdWJsaWMgbmdPbkNoYW5nZXMoY2hhbmdlczogU2ltcGxlQ2hhbmdlcykge1xuICAgIGlmICgnb3B0aW9ucycgaW4gY2hhbmdlcyAmJiBjaGFuZ2VzLm9wdGlvbnMuY3VycmVudFZhbHVlKSB7XG4gICAgICB0aGlzLm9wdGlvbnMgPSBjaGFuZ2VzLm9wdGlvbnMuY3VycmVudFZhbHVlO1xuICAgICAgdGhpcy51cGRhdGVDaGFuZ2VkRGVja09wdGlvbnModGhpcy5vcHRpb25zIGFzIElEZWNrT3B0aW9ucyk7XG4gICAgICB0aGlzLm9wdGlvbnNTdWJqZWN0Lm5leHQodGhpcy5vcHRpb25zIGFzIElEZWNrT3B0aW9ucyk7XG4gICAgfVxuICAgIGlmICgnaXNJbnRlcmxlYXZlZCcgaW4gY2hhbmdlcykge1xuICAgICAgaWYgKGNoYW5nZXMuaXNJbnRlcmxlYXZlZC5jdXJyZW50VmFsdWUpIHtcbiAgICAgICAgdGhpcy5lbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnaW50ZXJsZWF2ZWQnKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoJ2ludGVybGVhdmVkJyk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgLy8gRGlmZmljdWx0IHRvIGR5bmFtaWNhbGx5IHVwZGF0ZSBhbGwgcHJvcHMgLSBzb21lIG9mIHRoZW0gY2FuIGJlIGFmZmVjdGVkIGJ5IGV4dGVybmFsIHRoaW5ncyBsaWtlIG1hcHN5bmNcbiAgcHVibGljIHVwZGF0ZUNoYW5nZWREZWNrT3B0aW9ucyhvcHRpb25zOiBJRGVja09wdGlvbnMpIHtcbiAgICBpZiAodGhpcy5kZWNrKCkpIHtcbiAgICAgIGNvbnN0IG9sZFZpZXdTdGF0ZSA9IHsgLi4udGhpcy5kZWNrKCkhLnByb3BzLmluaXRpYWxWaWV3U3RhdGUgfTtcbiAgICAgIGNvbnN0IG5ld1ZpZXdTdGF0ZSA9IHtcbiAgICAgICAgLi4uKG9wdGlvbnMuaW5pdGlhbFZpZXdTdGF0ZSA/PyB0aGlzLmRlY2soKSEucHJvcHMuaW5pdGlhbFZpZXdTdGF0ZSksXG4gICAgICAgIG1heFBpdGNoOiAwLFxuICAgICAgfTtcbiAgICAgIGNvbnN0IG5ld09wdGlvbnM6IElEZWNrT3B0aW9ucyA9IHtcbiAgICAgICAgaW5pdGlhbFZpZXdTdGF0ZTogbmV3Vmlld1N0YXRlLFxuICAgICAgICBlZmZlY3RzOiBvcHRpb25zLmVmZmVjdHMgPz8gdGhpcy5kZWNrKCkhLnByb3BzLmVmZmVjdHMsXG4gICAgICAgIHZpZXdzOiBvcHRpb25zLnZpZXdzID8/IHRoaXMuZGVjaygpIS5wcm9wcy52aWV3cyxcbiAgICAgICAgb25DbGljazogdGhpcy5vcHRpb25zPy5vbkNsaWNrID8/ICh0aGlzLmRlY2soKSEucHJvcHMub25DbGljayBhcyBhbnkpLFxuICAgICAgICBvbkRyYWc6IHRoaXMub3B0aW9ucz8ub25EcmFnID8/ICh0aGlzLmRlY2soKSEucHJvcHMub25EcmFnIGFzIGFueSksXG4gICAgICB9O1xuICAgICAgdGhpcy5kZWNrKCk/LnNldFByb3BzKHtcbiAgICAgICAgLi4ubmV3T3B0aW9ucyxcbiAgICAgIH0pO1xuICAgICAgdGhpcy5kZWNrKCkhLnByb3BzLm9uVmlld1N0YXRlQ2hhbmdlKHtcbiAgICAgICAgdmlld1N0YXRlOiB7XG4gICAgICAgICAgLi4ub3B0aW9ucy5pbml0aWFsVmlld1N0YXRlLFxuICAgICAgICAgIG1heFBpdGNoOiAwLFxuICAgICAgICB9LFxuICAgICAgICBvbGRWaWV3U3RhdGU6IG9sZFZpZXdTdGF0ZSxcbiAgICAgICAgdmlld0lkOiAnZGVmYXVsdC1tYXAtdmlldycsXG4gICAgICAgIGludGVyYWN0aW9uU3RhdGU6IHt9LFxuICAgICAgfSk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIGZpbmFsaXplKCkge1xuICAgIHRoaXMuaXNEZXN0cm95aW5nID0gdHJ1ZTtcbiAgICBpZiAodGhpcy53ZWJHbENvbnRleHQpIHtcbiAgICAgIHRoaXMud2ViR2xDb250ZXh0LmdldEV4dGVuc2lvbignV0VCR0xfbG9zZV9jb250ZXh0Jyk/Lmxvc2VDb250ZXh0KCk7XG4gICAgfVxuICAgIGlmICh0aGlzLmNhbnZhcz8ubmF0aXZlRWxlbWVudCkge1xuICAgICAgdGhpcy5jYW52YXMubmF0aXZlRWxlbWVudC5yZXBsYWNlV2l0aChcbiAgICAgICAgdGhpcy5jYW52YXMubmF0aXZlRWxlbWVudC5jbG9uZU5vZGUodHJ1ZSlcbiAgICAgICk7XG4gICAgfVxuICAgIGlmICh0aGlzLmRlY2soKSkge1xuICAgICAgdGhpcy5kZWNrKCkhLnNldFByb3BzKHtcbiAgICAgICAgbGF5ZXJzOiBbXSxcbiAgICAgIH0pO1xuICAgICAgdGhpcy5kZWNrKCkhLmZpbmFsaXplKCk7XG4gICAgICB0aGlzLmRlY2suc2V0KHVuZGVmaW5lZCk7XG4gICAgfVxuICAgIGlmICh0aGlzLmRlY2tPdmVybGF5KCkpIHtcbiAgICAgIHRoaXMuZGVja092ZXJsYXkoKSEuc2V0UHJvcHMoe1xuICAgICAgICBsYXllcnM6IFtdLFxuICAgICAgfSk7XG4gICAgICB0aGlzLmRlY2tPdmVybGF5KCkhLmZpbmFsaXplKCk7XG4gICAgfVxuICB9XG5cbiAgcHVibGljIHJlaW5pdGlhbGl6ZSgpIHtcbiAgICB0aGlzLmluaXREZWNrKCk7XG4gIH1cblxuICBwdWJsaWMgbmdPbkRlc3Ryb3koKSB7XG4gICAgdGhpcy5pc0Rlc3Ryb3lpbmcgPSB0cnVlO1xuICAgIC8vIHRoaXMuZmluYWxpemUoKTtcbiAgfVxufVxuIl19