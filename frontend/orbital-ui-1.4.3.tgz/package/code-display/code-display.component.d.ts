import { AfterViewInit, ChangeDetectorRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class OuiCodeDisplayComponent implements AfterViewInit {
    private cdr;
    typescriptPath: string;
    htmlPath: string;
    isOpen: boolean;
    typescriptCode: string;
    htmlCode: string;
    constructor(cdr: ChangeDetectorRef);
    ngAfterViewInit(): Promise<void>;
    static ɵfac: i0.ɵɵFactoryDeclaration<OuiCodeDisplayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<OuiCodeDisplayComponent, "oui-code-display", never, { "typescriptPath": { "alias": "typescriptPath"; "required": false; }; "htmlPath": { "alias": "htmlPath"; "required": false; }; }, {}, never, never, true, never>;
}
//# sourceMappingURL=code-display.component.d.ts.map